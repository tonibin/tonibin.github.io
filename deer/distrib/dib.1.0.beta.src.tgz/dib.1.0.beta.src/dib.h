/*dib.h
* Copyright (C) 2008-2009 Antonio Maschio @ <tbin at libero dot it>
* 
* This is dib, the Dartmouth 1966 BASIC intepreter, a very naive
* attempt to implement the original Dartmouth College BASIC language as 
* conceived by Kemeny & Kurz in 1964, in its 1966 version (why 1966? 
* I was born in 1966). The interpreter is implemented in a not interactive 
* environment; it is in plain C (for the gcc), and it works as a common 
* UNIX command. See the file "dib_manual.txt" for explanation about the 
* interpreter and the language, and about its history and influences.
*
* This file, in particular, is the header of the main C program. 
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
* General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*
* It's GPL! Enjoy!
*
* (Written with vim, tab stop = 8) */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <libgen.h>


/* Versioning constants */
#define VERSION "1.0.beta"
#define BUILD 2
#define AU "Antonio Maschio"			/* Author */
#define EM "ing.antonio.maschio@gmail.com"  	/* Email */
#define CY "2008-2026"		  		/* Copyright Year(s) */


/* System constants */
#define LIMIT   999	// dib's memory extension chunk
#define CHUNKS  120	// dib's chunks number
#define STRLIM   75	// string limit
#define SCRLIM   75	// screen limit
#define FORLIM   26	// FOR limit
#define DATLIM 1280	// DATA limit
#define TEMPVAR  24	// temp var for MAT calculations (don't change!)
#define ZONE     14	// width of printing zone
#define MINIZONE  3	// width of printing sub zone
#define TRUE      1
#define FALSE     0
#define MINFF -5.78960446187E76	 // greater negative real (-2^255)
#define INFF   5.78960446187E76	 // greater positive real (2^255)
#define ZERO   4.31808427754E-78 // smaller real different from 0 (2^-257)
#define PSTACK   64	// dimension of the inner RPN stack
#define INVCOLOR "[7;37;40m"
#define RESETCOLOR "[1;m"


/* INSPECTIVE MACROS - argument is always a char pointer */
// is *p a single variable A..Z
#define issv(p) (isalpha(*(p)) && !isalnum(*((p)+1))) 
// is *p a function
#define isfn(p) (isalpha(*(p)) && isalpha(*((p)+1))) 
// is *p a double variable A0..Z9
#define isdv(p) (isalpha(*(p)) && isdigit(*((p)+1)))
// is *p a number
#define isnm(p) (isdigit(*(p)) || *(p)=='.' || *(p)=='-')
// is *p an array item
#define isav(p) ((issv(p) && *((p)+1)=='(') || (isdv(p) && *((p)+2)=='('))
// is *p a math operator
#define ismo(p) (*(p)=='+'||*(p)=='-'||*(p)=='*'||*(p)=='/'||*(p)=='^'||*(p)=='}'||*(p)=='{')
// is *p a relational operator
#define isro(p) (*(p)=='<'||*(p)=='>'||*(p)=='='||*(p)=='#'||*(p)=='!'||*(p)=='$')
// is *p a logical operator (NOT is a unary operator)
#define islo(p) (*(p)=='&'||*(p)=='|'||*(p)=='_'||*(p)=='%'||*(p)=='~')
// is *p an operator (that is math, relational or logical)
#define isop(p) (ismo(p) || isro(p) || islo(p))
// is *p the comma or the semicolon
#define iscs(p) (*(p)==',' || *(p)==';')


/* DEF structure */
struct t_definition {
	int vars[LIMIT];	// variables as arguments holder
	char* def;		// pointer to the DEF string definition
};
typedef struct t_definition Tdef;


/* DIM structure */
struct t_array {
	int row;
	int col;
	int type; 		// type 0=undeclared, 1=vector, 2=matrix
	double *elem;		// pointer to the array base
};
typedef struct t_array Tarray;


/* error strings 
 * (cfr. 1966 Dartmouth BASIC manual, app. A, pages 35�37) 
 * Note: the Dartmouth compiler acted with one single pass over the entire
 * program before executing it, to check the syntax, tokenize statements and 
 * pack instructions before compiling (cfr. pages 16�18 of the 1964 manual).
 * dib, instead, while acting quite identically to the original with
 * respect to the execution of **correct** program lines, differs in the
 * error messages treatment, because it doesn't do any check before execution,
 * but rather **during** execution; some non-blockin error messages are 
 * transparent and let the interpreter go on, printing a message interspersed 
 * with program output. This is a behaviour that won't interfere with well 
 * written programs */
char *ers[]={
	/* Standard errors message as in the 1966 manual for version III */
	"",	 		 // 0 
	"ILLEGAL CONSTANT ",	 // 1
	"ILLEGAL FORMULA ",	 // 2
	"",	 		 // 3
	"ILLEGAL LINE NUMBER ",  // 4
	"ILLEGAL INSTRUCTION ",  // 5
	"ILLEGAL VARIABLE ",	 // 6
	"INCORRECT FORMAT ",	 // 7
	"END IS NOT LAST ",	 // 8
	"NO END INSTRUCTION ",   // 9
	"NO DATA ",		 // 10
	"UNDEFINED FUNCTION ",   // 11
	"UNDEFINED NUMBER ",	 // 12
	"",	 		 // 13 
	"TOO MUCH DATA ",	 // 14 
	"",	 		 // 15: NOT PRESENT ANY MORE IN VERSION III 
	"TOO MANY LOOPS ",	 // 16 
	"NOT MATCH WITH FOR ",   // 17
	"FOR WITHOUT NEXT ",	 // 18
	"", 			 // 19 
	"SUBSCRIPT ERROR ",	 // 20
	"RETURN BEFORE GOSUB ",	 // 21: WAS "ILLEGAL RETURN" IN VERSION II
	/* extra non-blocking warnings taken from the Dartmouth BASIC sources
	 * or introduced by myself in a 1966 style */
	"OUT OF DATA ",				// 22*
	"SQUARE ROOT OF A NEGATIVE NUMBER ", 	// 23*
	"LOG OF NEGATIVE NUMBER ",	  	// 24*
	"LOG OF ZERO ",			  	// 25*
	"ABSOLUTE VALUE RAISED TO POWER ", 	// 26*
	"DIVISION BY ZERO ",			// 27*
	"",					// 28*
	"MISMATCHED DIMENSIONS",		// 29*	
	"OVERFLOW ",				// 30*
	"UNDERFLOW ",				// 31*
	"ZERO TO A NEGATIVE POWER ",		// 32*
	"ZERO TO THE ZERO POWER ",		// 33*
	"GOSUB NESTED TOO DEEPLY ",		// 34*
	"",					// 35*
	"NO MATRIX INVERSION DONE YET ",	// 36
	"IGNORING ONE-ELEMENT LIST OR TABLE ",	// 37
	"",					// 38
	"",					// 39
	"",					// 40
	"NEARLY SINGULAR MATRIX ",		// 41*
	"DIMENSION ERROR ",			// 42*
	"EXP TOO LARGE ",			// 43*
	""
};

#define ERRN 44

/* SYSTEM ERROR STRINGS */
#define NOARRAYMEM "dib: out of memory for arrays.\n"
#define NODEFMEM   "dib: out of memory for DEF.\n"
#define NOFILE     "dib: file not found.\n"
#define NOCLOSE	   "dib: unable to close file.\n"
#define NODOMAIN   "dib: line %d is beyond domain.\n"
#define NOLINEMEM  "dib: out of memory for line %d.\n"
#define NOOPTION   "dib: -%c is an illegal option.\n"
#define NOFILENAME "dib: missing file name.\n"
#define NOENDMEM   "dib: out of memory for ultimate END.\n"
#define NOLINE     "dib: cannot get a valid starting line.\n"
#define NOSTRING   "dib: no string given to option -p.\n"

/* Functions prototypes */
double getVal(void);
double getFunc(void);
int priority(int op);	/* operator priority calculator */
double S(void);		/* the parser */
void G(void);		/* the storer */
void stripBlanks(char *src, char *dest);
int in(char c, char d);
int printSTR(char *s);			/* string formatter */
int printNUM(double num);		/* number formatter */
int emitNUM(char minus, char *num);	/* number output */
void doExp(char*n,double*b,int*e);      /* retrieve base and exponent */
void AC(void);		/* Advance Carriage */
void CR(void);		/* Carriage Return  */
int check(char *sb, char *sc);
void perror_(int e, int l, int g);
void perrorEx_(int e, int l);
void derror_(char* t);
void RUN(void);
void LOAD(char *f);
void PRINT(void);
void advance(void);		/* currently unused */
void advanceToMinizone(void);	/* currently unused */
void advanceToZone(void); 	/* currently unused */
void fill(int Width);		/* currently unused */
void CHANGE(void);	/* for CHANGE "STRING" TO C, where C is a vector */
void DATA(void);
void DEF(void);		
void READ(void);
void RESTORE(void);
void FOR(void);
void NEXT(void);
void GOSUB(void);
void GOTO(void);
void RETURN(void);
void IFTHEN(void);
void ONGOTO(void);
void INPUT(void);
int LET(void);		/* LET : here wrapper for assign/dimAssign*/
int assign(void);	/* assign values to variable */
void DIM(void);
double getRandom(void);
double getArrayVal(int var, int type, int M, int N);
void setArrayVal(int var, int type, int M, int N, double val);
void dimArray(int var, int type, int M, int N);
void dimAssign(void);	/* assign values to array variables */
int isod(char *p); 	/* is *p a one-dimensional array */
int isaa(char *p);	/* is *p an array assignment like A(X[,Y])=EXPR */
void matReadAssign(int var, int t, int m, int n); /* assign MAT READ values */
void matCopy(int dest, int source); /* MAT C = A */
void MATtype(void);	/* the MAT controller */
void MATREAD(void);	/* MAT READ A(M[,N]),B(M[,N])... */
void MATINPUT(void);	/* MAT INPUT A,B... */
void MATZER(int var, double op); /* MAT C=ZER(M[,N])|CON(M[,N])*/
void MATIDN(int var);   /* MAT C=IDN(M) */
void MATPRINT(void);	/* MAT PRINT A[;|,] */
void MATTRN(int var);	/* MAT C = TRN(A) */
void MATINV(int var);	/* MAT C = INV(A) - wrapper for matinvert() */
void matinvert(int varr, int var1); // inversion and determinant calculation
void MATDET(void);	/* C = DET(A) explicit determinant of square mat. A  */
void MATbyK(int var);	/* MAT C = (exp) * A */
void MATsum(int var, int var1, int var2, int op);	/* MAT C = A +|- B   */
void MATmul(int var, int var1, int var2);		/* MAT C = A * B     */
double MATdot(void);	/* C = DOT(A,B) dot product */
double normer(int var, int type); /* calculator for FNORM, RNORM and CNORM   */
double MATNORM(void);	/* C = [FNORM|RNORM|CNORM](A) - wrapper for normer() */	
double power(double base, double expon);
double GAMMA(void);
double FIX(void);
double dg(double rad);	/* convert from radians to degrees */
double rd(double deg);	/* convert from degrees to radians*/
void printHelp(void);
void printVersion(int flag);
void printWarraty(int flag);
void printConditions(int flag);
void tokenize(void);
void printHeader(void);
void stripBlanks(char *src, char *dest);

/* LOTSA GLOBAL VARIABLES! */

/* general data */
char FileName[257];
static char *month[]={"","JAN.","FEB.","MAR.","APR.","MAY","JUN.","JUL.",
	"AUG.","SEPT.","OCT.","NOV.","DEC." };

/* l holds the current program line number
 * P is an integer array holding variables contents 
 * startingLine holds the user specified starting line for RUN */
int l;
double P[LIMIT];
int startingLine = 1;

/* B is the general input buffer 
 * J is the input buffer used to store DEF formulas */
char B[STRLIM+1], J[STRLIM+1];

/* F is a character-holder used by the blank stripper */
char F[2];

/* m is an array holding pointers to program lines 
 * p is the main char pointer to the current buffer position
 * s and d are various char pointers used into RUN */
//char *m[CHUNKS*LIMIT+10], *p,*q,*x,*y,*z,*s,*d;
char *m[CHUNKS*LIMIT+10], *p,*s,*d;

/* printn is a flag for disabling printing CR after last ';' or ',' 
 * in PRINT statements (1=print CR; 0=don't print CR); printn means print '\n' 
 * counter is the current next printing column on the screen line 
 * isTab is the flag active when a TAB() function is met (used to avoid
 * interpreting the semicolon or the comma after the TAB)
 * cw is a temporary backup value for counter 
 * if cutOff is TRUE (enabled with -z option) all numbers lower than EPSILON 
 * are printed as zero, to avoid cluttered output; 
 * EPSILON contains the customizable limit */
int printn=1;
int counter=0;
int isTab=FALSE;
int cw;
int cutOff=FALSE;
double EPSILON=1E-10;

/* D is an array holding DATA values
 * dc (data counter) yields current pointer to data
 * dataLimit is the total of DATA values found into the listing 
 * noData is the destination to go in case a READ statement runs out of data */
double D[DATLIM];
int dc=0;
int dataLimit=0;
int noData=0;

/* fn holds the DEF FN definitions */ 
Tdef fn[LIMIT];

/* END features 
 * endl holds the last line number where an END appears 
 * endn holds the total number of END statements found
 * used into LOAD() */
int endl=0;
int endn=0;


/* GOSUB data management and storing 
 * isGOSUB is a flag to check if any jump out of a FOR..NEXT cycle is a GOSUB 
 * (and this won't interrupt the cycle) or a GOTO/IF..THEN (and this will 
 * break the cycle) */
int gosubStack[LIMIT];
int gosubTOS = 0;
int GOSLIM=80;
int isGOSUB=FALSE;

/* FOR..NEXT data storing 
 * forcount is a counter for contemporary nested FOR cycles */
double forStack[6*FORLIM+6];
int forTOS = 0;
int forcount=0;

/* error circuitation & error treatment
 * The error system is built in such a way it stops only with blocking errors; 
 * in other cases, it can safely go on, eventually printing a warning.
 * The flags involved are true_ and false_, which may or not point to TRUE
 * or FALSE; if they are coherent, the system will stop only on meeting
 * blocking errors; if they both point to TRUE, the system will *always*
 * block (this is the default case); to enable partial blocking, 
 * use option -c when starting dib */
int true_= TRUE;
int false_=TRUE;

/* DIM arrays holder */
Tarray dim[LIMIT];

/* debug flag */
int debug=FALSE;

/* OPTION BASE index (0 = index from 0; 1 = index from 1)
 * Default for BASIC I   (1964) arrays = 1; no MAT statements
 * Default for BASIC II  (1964) arrays = 0; MAT arrays = 1 (cardbasic)
 * Default for BASIC III (1966) arrays = 0; MAT arrays = 0
 * Default for BASIC IV  (1967) arrays = 0; MAT arrays = 1
 * Default for BASIC V   (1969) arrays = 0; MAT arrays = 1
 * Default for BASIC VI  (1971) arrays = 0; MAT arrays = 1
 * dib has a consistent base for array indexes as was version III, so that 
 * the weird differences of versions II and version IV-VI are banned. */

/* MAT variables*/
double detValue=0.0; 	// placeholder for DET (MAT INV determinant)
int isdetCalc=FALSE;	// has determinant been calculated by MAT INV routine?

/* random */
int RANDL = 32768;
int DIV = 16;

/* parser variables */
int opturn=0;		// (don't change!) true when an operator is expected

/* Header and timer strings (see September 1966 manual) */
#define TIMES           "TIME:    %d SECS.\n"
#define HEADER		"%-6s    %02d:%02d   %s %02d, %d\n"
int isPrintHeader=FALSE;
struct timeval tv;  
double beginS=-1.0, endS=0.0;
int beginM=0;
time_t now;
int isTiming=FALSE;

/* the flag for error 43 */
int isExp=FALSE;

/* the CHAIN flag */
int isChain=FALSE;

int isList=FALSE;

/* end of dib.h */

