" Vim syntax file
" Language:	Dartmouth BASIC (v.III - dib emulator)
" Creator:	Antonio Maschio <tbin at libero dot it>
" Maintainer:	Antonio Maschio <tbin at libero dot it>
" Last updated: agosto 09, 2026

" Based on Allan Kelly's BASIC vim file

" For version 5.x: Clear all syntax items
" For version 6.x: Quit when a syntax file was already loaded
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif


" The original set of BASIC keywords
syn keyword dibMAT	   MAT
syn match dibMAT	   /MAT\s*PRINT/
syn match dibMAT	   /MAT\s*INPUT/
syn match dibMAT	   /MAT\s*READ/
syn keyword dibMAT	   ZER CON IDN TRN INV 
syn match dibStatement     /DEFFN\a\{1\}/
syn match dibStatement     /FN\a\{1\}/
syn match dibStatement     /FN\s*END/
syn keyword dibStatement   DATA DEF DIM END FOR NEXT STEP GOSUB GOTO GO
syn keyword dibStatement   IF THEN INPUT LET PAGE PRINT 
syn keyword dibStatement   READ RESTORE RETURN STOP TO

" The original set of functions
syn keyword dibFunction	    ABS ATN COS EXP INT LOG RND SIN SQR TAN
syn keyword dibFunction	    DET SGN

" Facilities
syn keyword dibTodo contained	TODO

" operators
syn match   dibMathsOperator "[<>+\*^/=-]"

" number 
syn match  dibNumber            "[0-9]*\.\=[0-9]*"
syn match  dibNUmber            "[0-9]*\.\=[0-9]*[ ]*E-\=[0-9][0-9]\="
syn region  dibLineNumber	start="\_^" end="\d*"

" comments
syn region  dibComment	start=/#/ end=/$/ contains=dibTodo
syn region  dibComment	start="REM"  end="$" contains=dibTodo
syn region  dibComment	start="\'"   end="$" contains=dibTodo

" String and Character constants
syn region  dibString	start="\""  end="\""


" Define the default highlighting.
" For version 5.7 and earlier: only when not done already
" For version 5.8 and later: only when an item doesn't have highlighting yet
if version >= 508 || !exists("did_dib_syntax_inits")
  if version < 508
    let did_dib_syntax_inits = 1
    command -nargs=+ HiLink hi link <args>
  else
    command -nargs=+ HiLink hi def link <args>
  endif

  HiLink dibLineNumber		Comment
  HiLink dibNumber		Number
  HiLink dibStatement		Statement
  HiLink dibStatementExt	PreProc
  HiLink dibString		Constant
  HiLink dibComment		Comment
  HiLink dibTodo		Todo
  HiLink dibFunction		Identifier
  HiLink dibFunctionExt		Special
  HiLink dibMAT 		Type
  HiLink dibMathsOperator 	Identifier
 

  delcommand HiLink
endif

let b:current_syntax = "dib"
set ts=8
set nocin
set nosi
set columns=75

" vim: ts=8
