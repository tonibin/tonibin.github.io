Note:

All the programs in the GOTTFR/ folder may be run in default mode with
the option base set to 1:

$ dib -b <filename>

Usage of the -x option may cause a different output than expected, but the
1073 Pittsburgh mainframe on which all the examples were written differs
substantially from the Dartmouth Time Sharing System, so this cannot be a
relevant point. If you don't use the -b option, nothing should happen as long 
as the 0 index in arrays, vectors and matrices is never called.
Other options are freely usable.
