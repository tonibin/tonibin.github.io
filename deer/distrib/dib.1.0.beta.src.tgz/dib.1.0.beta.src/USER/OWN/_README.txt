Note:

All the programs in the OWN/ folder may be run in default mode:

$ dib <filename>

Usage of the -x or -b options may cause a different output than expected. 
Other options are freely usable.
