Note:

All the programs in the OWN/EXTEND folder may be run in default mode with
the extended features enabled:

$ dib -x <filename>

Usage of the -b option may cause a different output than expected. 
Other options are freely usable.
