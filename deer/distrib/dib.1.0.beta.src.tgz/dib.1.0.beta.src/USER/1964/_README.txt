Note:

All the programs in this 1964/ folder may be run in default mode:

$ dib <filename>

Usage of the -x or -b options though, may result in unpredictable or weird 
results. All other options may be used. 
