/*dib.c
* Copyright (C) 2008-2009 Antonio Maschio @ <tbin at libero dot it>
* Last updated: agosto 09, 2026
* 
* This is dib, the Dartmouth 1966 BASIC intepreter, a very naive
* attempt to implement the original Dartmouth College BASIC language as 
* conceived by Kemeny & Kurz in 1964, in its 1966 version (why 1966? 
* I was born in 1966). The interpreter is implemented in a not interactive 
* environment; it is in plain C (for the gcc), and it works as a common 
* UNIX command. See the file "dib_manual.txt" for explanation about the 
* interpreter and the language, and about its history and influences.
*
* This program is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
* General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program. If not, see <http://www.gnu.org/licenses/>.
*
* It's GPL! Enjoy!
*
* (Sources should be read bottom-up, so if you read it top-down you will
* go from last complex functions to first simple and main)
* (Written with vim, tab stop = 8) */

#include "dib.h"

/* The following routines define the behavior of the MAT statements which 
 * were included as standard on the 1966 version of the Dartmouth BASIC,
 * and as a CardBasic option in version II of 1964.
 * I base the following routines upon the September 1966 manual for version III,
 * which presents an exhaustive explanation upon matrices usage.
 * Many references and suggestions have been grabbed by the beautiful book
 * "Programming with BASIC" by Byron S. Gottfried (1975, Italian edition)
 * and on the 1978 historical essay "BASIC Session" by Thomas E. Kurtz. */

/* MATbyK(result-matrix)
 * multiply a matrix by an expression, both taken from stream */
void MATbyK(int varr){
	double exp=S();
	int var1, i,j,m,n,t;

	/* check syntax */
	if (*p++!= ')') {
		perror_(7,l,false_); 
		return;
	}
	if (*p++!= '*') {
		perror_(7,l,false_); 
		return;
	}
	
	/* get argument matrix code */
	if (issv(p)) var1=*p++;
	else {
		perror_(6,l,false_); 
		return;
	}

	/* check matrices existence */
	if (dim[varr].type==0 || dim[var1].type==0) perror_(42,l,true_);

	/* check dimensions validity */
	if (dim[varr].row!=dim[var1].row || dim[varr].col!=dim[var1].col)
		perror_(42,l,true_);

	/* perform multiplication by expression */
	m=dim[varr].row;
	n=dim[varr].col;
	t=dim[varr].type;
	i=0; j=0;
	while (i<=m) {
		setArrayVal(varr,t,i,j,exp*getArrayVal(var1,t,i,j));
		j++;
		if (j>n) {
			i++; j=0;
		}
	}
}


/* MATTRN(result-matrix)
 * The MAT TRN statement
 * Read argument matrix from stream, transpose it
 * and set result-matrix as the transposed matrix */
void MATTRN(int varr){
	int var1,i,j,t,t1;

	if (*p++=='(') {
		/* get argument matrix code */
		if (issv(p)) var1=*p++;
		else {perror_(6,l,false_); return;}
	}
	else {perror_(7,l,false_); return;}

	/* check equality */
	if (varr==var1) perror_(42,l,true_);

	/* check dimensions validity */
	if (dim[varr].row!=dim[var1].col || dim[varr].col!=dim[var1].row)
		perror_(42,l,true_);

	/* dimension temporary matrix as result matrix */
	t=dim[varr].type;
	t1=dim[var1].type;
	dimArray(TEMPVAR,t,dim[varr].row,dim[varr].col);
	
	/* transpose argument matrix over temporary; 
	 * I do this to enable MAT A=TRN(A) in extended mode */
	i=0;
	while (i<=dim[varr].col) {
		j=0;
		while (j<=dim[varr].row) {
			setArrayVal(TEMPVAR,t,j,i,getArrayVal(var1,t1,i,j));
			j++;
		}
		i++;
	}

	/* copy back to result matrix */
	for(i=0;i<=dim[varr].row;i++) {
		for(j=0;j<=dim[varr].col;j++) {
			setArrayVal(varr,t,i,j,getArrayVal(TEMPVAR,t,i,j));
		}
	}
}


/* MATINV(result-matrix)
 * The MAT INV statement
 * Read parameters from the stream, setup parameters 
 * and pass them to matinvert(), the real matrix inverter. */
void MATINV(int varr){
	int var1;

	if (*p++=='(') {
		/* get argument matrix code */
		if (issv(p)) var1=*p++;
		else {perror_(6,l,false_); return;}
	}
	else {perror_(6,l,false_); return;}

	/* check matrix existence */
	if (dim[varr].type!=2 || dim[var1].type!=2) perror_(42,l,true_);

	/* check equality 
	 * MAT A=INV(A) is available only as an extended feature */
	if (varr==var1) perror_(42,l,true_);
	
	/* check dimensions validity (only square matrices may be inverted) */
	if (dim[varr].row!=dim[varr].col || dim[var1].row!=dim[var1].col)
		perror_(42,l,true_);
	if (dim[varr].row != dim[var1].row) perror_(42,l,true_);

	/* delegate inversion */
	matinvert(varr,var1);

	/* set det flag after calculation */
	isdetCalc=TRUE;
}


/* matinvert(result-matrix, argument-matrix)
 * Inversion of matrix 'a' into matrix 'x' and calculation of the determinant
 * using the Gauss factorization scheme. Variables:
 * - varr is the unknown global inverted matrix (NxN) in the BASIC code
 * - var1 is the global knowns matrix to be inverted (NxN) in the BASIC code; 
 *   it's used to form ma
 * - ma is the local composed matrix (2NxN) (to the left the knowns matrix, 
 *   to the right the identity matrix); this matrix is invisible to BASIC
 * - x is the local calculated inverted matrix (NxN), invisible to BASIC
 *   and later copied back to varr. 
 * - detValue is the global determinant value, visible to BASIC through DET
 * Copyright Antonio Maschio - March 2008 */
void matinvert(int varr, int var1) {
	int n = (dim[var1].row), d=2*n+1; 	
	int i, j, k;
	double x[n+1][n+1],ma[n+1][d+1];
	double mul,piv;

	/* set determinant multiplier */
	detValue=1.0;
	
	/* create composed matrix AI, with the same rows number of A,
	 * and twice the columns number of A; in the second half lies I */
	for (i=0;i<=n;i++) {
		for(j=0;j<=n;j++) {
			ma[i][j]=getArrayVal(var1,2,i,j);
			/* setting I to all zeroes */
			ma[i][j+n+1]=0.0;
		}
	}
	/* set diagonal of I to all ones */
	for (i=0;i<=n;i++) {
		ma[i][i+n+1]=1.0;
	}
	
	/* erase destination matrix */
	for (i=0; i<=n; i++) {
		for (j=0; j<=n; j++) {
			x[i][j]=0.0;
		}
	}
	
	/* Gauss factorization over AI with partial pivoting */
	for (k=0;k<n;k++) {
		piv=ma[k][k];
		if (!piv) {
			double maxx=0;
			int r=k;
			/* k is the row where pivot is zero
			 * now find the row where pivot is max */
			for (i=k+1;i<=n;i++) {
				if (maxx<fabs(ma[i][k])){ 
					maxx=ma[i][k]; 
					r=i; 
				}
			}
			/* matrix is singular if r hasn't changed */
			if (r==k) { perrorEx_(41,l); detValue=0; return; }
			/* exchange rows r and k */
			for (i=0;i<=d;i++) {
				maxx=ma[r][i];
				ma[r][i]=ma[k][i];
				ma[k][i]=maxx;
			}
			piv=ma[k][k];
			/* matrix is singular if pivot is still null */
			if (!piv) { perror_(41,l, true_);}
			/* update determinant sign */
			detValue*=-1; 
		}
		/* update the rest of the rows */
		for (i=k+1;i<=n;i++) {
			mul=ma[i][k]/piv;
			for (j=k;j<=d;j++) {
				ma[i][j]=ma[i][j]-mul*ma[k][j];
			}
		} 
		
	}

	/* calculate determinant */
	for (i=0;i<=n;i++) {
		detValue*=ma[i][i];
	}
	
	/* check singularity (this should be useless, 
	 * but it's safer checking it the same) */
	if (detValue==0.0) { perror_(41,l,true_); }

	/* calculate the inverse of A through back-substitution */
	for (i=0;i<=n;i++) {
		x[n][i]=ma[n][i+n+1]/ma[n][n];
		for (j=n-1;j>=0;j--) {
			piv=0;
			for(k=j+1;k<=n;k++) {
				piv+=ma[j][k]*x[k][i];
			}
			x[j][i]=(ma[j][i+n+1]-piv)/ma[j][j];
		}
	}

	/* set varr to the resulting inverted matrix */
	for (i=0; i<=n; i++) {
		for (j=0; j<=n; j++) {
			setArrayVal(varr,2,i,j,x[i][j]);
		}
	}
}


/* MATIDN(result-matrix)
 * The MAT IDN statement
 * set a square array to identity matrix */
void MATIDN(int var){
	int m=0, i, j;

	/* check existence */
	if (dim[var].type==0) perror_(42,l,true_);

	/* IDN is only for square matrices */
	if (dim[var].col!=dim[var].row) perror_(42,l,true_);

	/* get redimensioning data */
	if (*p=='(') {
		p++;
		m=(int)S();
		if (m<0) perror_(20,l,true_);
		if (*p++!=')') {perror_(7,l,false_); return;}
		
		/* redimension */
		if (m<=dim[var].row) dim[var].row=dim[var].col=m;
		else perror_(42,l,true_);
	}
	/* set existing dimensioning data */
	else if (*p=='\0') m=dim[var].row;
	else {perror_(7,l,false_); return;}

	/* set values for IDN */
	for (i=0;i<=m;i++) {
		for (j=0;j<=m;j++) {
			setArrayVal(var,2,i,j,0.0);
		}
	}
	for (i=0;i<=m;i++) {
		setArrayVal(var,2,i,i,1.0);
	}
}


/* MATZER(result-matrix, option-value)
 * The MAT ZER and MAT CON statements
 * set (or reset) an array to zero (MAT ZER) or one (MAT CON)
 * depending on option value 'op' (0 for ZER, 1 for CON); */
void MATZER(int var, double op){
	int t=0, m=0, n=0;
	int i,j;

	/* check existence */
	if (dim[var].type==0) perror_(20,l,true_);

	/* get redimensioning data */
	if (*p=='(') {
		p++;
		m=(int)S();
		if (m<0) perror_(20,l,true_);
		/* second index? bidimensional array */
		if (*p==',') {
			if (dim[var].type==1) perror_(29,l,true_);
			p++;
			n=(int)S();
			if (n<0) perror_(20,l,true_);
		}
		else if (dim[var].type==2) perror_(42,l,true_);

		/* redimension */ 
		if (m<=dim[var].row) dim[var].row=m;
		else perror_(20,l,true_);
		if (dim[var].type==2) {
			if (n<=dim[var].col) dim[var].col=n;
			else perror_(42,l,true_);
		}
		if (*p++!=')') {perror_(7,l,false_); return;}
	}
	/* set existing dimensioning data */
	else if (*p=='\0') {
		m=dim[var].row;
		n=dim[var].col;
	}
	else {perror_(7,l,false_); return;}


	/* set values for ZER or CON */
	t=dim[var].type;
	i=0; j=0;
	while (i<=m) {
		setArrayVal(var,t,i,j,op);
		j++;
		if (j>n) {
			i++; j=0;
		}
	}
}


/* MATsum(result-matrix,matrix1,matrix2,option-value)
 * Add two matrices or subtract the second from the first;
 * option value is -1 for subtractions, +1 for additions */
void MATsum(int varr, int var1, int var2, int op){
	int i,j;
	int M=dim[varr].row;
	int N=dim[varr].col;
	int T=dim[varr].type;
	int T1=dim[var1].type;
	int T2=dim[var2].type;

	/* create dummy matrix dimensionally equal to varr */
	dimArray(TEMPVAR,T,M,N);
	
	/* check tables existence */
	if (T==0 || T1==0 || T2==0) perror_(42,l,true_);

	/* check matching of dimensions 
	 * Note: one can only sum vectors with vectors, matrices with
	 * matrices, and not use unidimensional vectors or
	 * degenerated matrices of one row or of one column */
	if ((M!=dim[var1].row) || M!=dim[var2].row\
			|| N!=dim[var1].col || N!=dim[var2].col)
		perror_(42,l,true_);

	/* Note: the 1966 manual, at page 32, reports that MAT A=A+B,
	 * MAT A=(2.5)*A, MAT A=A-A and MAT B=A*A are all legal, while
	 * MAT A=B*A results in nonsense, but it's not forbidden; I thus enable
	 * all methods, since in my system nothing results in a nonsense. 
	 * To do this, I here perform additions/subtractions on a temp var and 
	 * then I copy it back to varr */
	i=0; j=0;
	while (i<=M) {
		setArrayVal(TEMPVAR,T,i,j,\
				getArrayVal(var1,T1,i,j)+\
				op*getArrayVal(var2,T2,i,j));
		setArrayVal(varr,T,i,j,getArrayVal(TEMPVAR,T,i,j));
		j++;
		if (j>N) {
			i++; 
			j=0;
		}
	}

}


/* MATmul(result-matrix,matrix1,matrix2)
 * The cross-product between two matrices or vectors */
void MATmul(int varr, int var1, int var2){
	int i,j,k;
	int M=dim[varr].row;
	int Nr=dim[varr].col;
	int N=dim[var1].col;
	int P=dim[var2].col;
	int T=dim[varr].type;
	int T1=dim[var1].type;
	int T2=dim[var2].type;

	/* instantiate temporary matrix with result matrix dimensions */
	dimArray(TEMPVAR,T,M,Nr);

	/* check existence */
	if (T==0 || T1==0 || T2==0) perror_(42,l,true_);

	/* check dimensions validity */
	if ((dim[var1].col!=dim[var2].row) || dim[varr].row!=dim[var1].row\
			|| dim[var2].col!=dim[varr].col)
		perror_(42,l,true_);
	
	/* perform cross multiplication and copy data back to varr;
	 * this is done to enable MAT A=A*B or MAT A=B*A or MAT A=A*A */
	if (T==2) {
		for(i=0;i<=M;i++) {
			for(j=0;j<=P;j++) {
				double res=0.0;
				for(k=0;k<=N;k++) {
					res+=getArrayVal(var1,T1,i,k)*getArrayVal(var2,T2,k,j);
				}
				setArrayVal(TEMPVAR,T,i,j,res);
			}
		}
		for (i=0;i<=M;i++) {
			for (j=0;j<=P;j++) {
				setArrayVal(varr,T,i,j,getArrayVal(TEMPVAR,T,i,j));
			}
		}
	}
	else if (T==1) {
		for(i=0;i<=M;i++) {
			double res=0.0;
			for(k=0;k<=N;k++) {
				res+=getArrayVal(var1,T1,i,k)*getArrayVal(var2,T2,k,0);
			}
			setArrayVal(TEMPVAR,T,i,0,res);
		}
		for (i=0;i<=M;i++) {
			setArrayVal(varr,T,i,0,getArrayVal(TEMPVAR,T,i,0));
		}
	}
}


/* MATtype()
 * this function is invoked by RUN when a MAT statement is met
 * (other than MAT READ, MAT PRINT or MAT INPUT, which follow their way) 
 * to choose the correct command. */
void MATtype(void) {
	int varr=0; 
	int var1=0;
	int var2=0;
	int op=0;
	
	/* get result matrix code */
	if (issv(p)) varr=*p++;
	else {perror_(6,l,false_); return;}
	
	if (*p++!='=') {perror_(7,l,false_); return;} 

	/* mat operations */
	if (issv(p) || isdv(p)) {
		/* get first matrix operand code */
		if (issv(p)) var1=*p++;
		else {perror_(6,l,false_); return;}
		
		/* get op */
		if (*p!='+' && *p!='-' && *p!='*' && *p!='\0') 
			{perror_(7,l,false_); return;}
		else op=*p++;
		
		/* get second matrix operand code */
		if (op!='\0') {
			if (issv(p)) var2=*p++;
			else {perror_(6,l,false_); return;}
		}
		
		/* perform operations */
		     if (op=='-') MATsum(varr, var1, var2, -1);
		else if (op=='+') MATsum(varr, var1, var2, 1);
		else if (op=='*') MATmul(varr, var1, var2);
		else if (op=='\0') { 
			perror_(7,l,false_); 
			return;
		}
		else {
			perror_(7,l,false_); 
			return;
		}
	}
		
	/* mat functions */
	else {
		     if (!strncmp(p,"ZER",3)) p+=3, MATZER(varr,0.0);
		else if (!strncmp(p,"CON",3)) p+=3, MATZER(varr,1.0);
		else if (!strncmp(p,"TRN",3)) p+=3, MATTRN(varr);
		else if (!strncmp(p,"IDN",3)) p+=3, MATIDN(varr);
		else if (!strncmp(p,"INV",3)) p+=3, MATINV(varr);
		else if (*p=='(') p++, MATbyK(varr);
		else perror_(7,l,false_);
	}
}


/* matCopy(result-matrix, argument-matrix)
 * copy argument matrix into result matrix
 * extended mode only - the check is done into MATtype() */
void matCopy(int dst, int src){
	int ms=dim[src].row;
	int ns=dim[src].col;
	int ts=dim[src].type;
	int MD=dim[dst].row;
	int ND=dim[dst].col;
	int TD=dim[dst].type;
	int i,j;

	/* check compatibility */
	if (dst==src) return;
	if (ms!=MD || ns!=ND || ts!=TD || ts==0 || TD==0) perror_(20,l,true_);

	if (ts==2) {
		for (i=0;i<=ms;i++) {
			for (j=0;j<=ns;j++) {
				setArrayVal(dst,TD,i,j,getArrayVal(src,ts,i,j));
			}
		}
	}
	else if (ts==1) {
		for (i=0;i<=ms;i++) {
			setArrayVal(dst,TD,i,0,getArrayVal(src,ts,i,0));
		}
	}
}


/* matReadAssign(result-matrix,type,rows,columns)
 * iterate through matrix indexes to assign DATA values */
void matReadAssign(int var, int t, int m, int n){
	int i,j;
	/* vectors */
	if (1==t) {
		for(i=0;i<=m;i++) {
			if (dc>dataLimit) {
				/* NODATA has been used */
				if (noData) l=noData-1;
				/* normal behavior: print warning and exit */
				else {
					perrorEx_(22,l);
					l=-1; forcount=0; 
					return;
				}
			}
			setArrayVal(var,1,i,0,D[dc++]);
		}
	}
	/* matrices */
	else {
		for(i=0;i<=m;i++) {
			for (j=0;j<=n;j++) {
				/* if out of data, print warning or set NODATA*/
				if (dc>dataLimit) {
					/* NODATA has been used */
					if (noData) l=noData-1;
					/* is out of data, 
					 * print warning and exit */
					else {
						perrorEx_(22,l);
						l=-1;forcount=0;
					}
					return;
				}
				setArrayVal(var,2,i,j,D[dc++]);
			}
		}
	}
}


/* MATREAD()
 * The MAT READ statement 
 * Multiple-matrices reading enabled */
void MATREAD(void){
	int var=0, m=0, n=0;

	if (dataLimit==0) {
		perror_(10,l,false_);
		return;
	}
	/* start loop on all MAT READ arrays */	
	do {
		/* get variable code */
		if (issv(p)) var=*p++;
		else {perror_(6,l,false_); return;}

		/* check existence */
		if (dim[var].type==0) perror_(42,l,true_);
	
		/* get explicit data */
		if (*p=='(') {
			p++;
			m=(int)S();
			if (m<0) perror_(20,l,true_);

			/* second index? bidimensional array */
			if (*p==',') {
				if (dim[var].type==1) perror_(42,l,true_);
				p++;
				n=(int)S();
				if (n<0) perror_(20,l,true_);
			}
			else if (dim[var].type==2) perror_(42,l,true_);

			/* redimension */ 
			if (m<=dim[var].row) dim[var].row=m;
			else perror_(20,l,true_);
			if (dim[var].type==2) {
				if (n<=dim[var].col) dim[var].col=n;
				else perror_(20,l,true_);
			}
			if (*p++!=')') {perror_(7,l,false_); return;}
		}

		/* set implicit data */
		else if (*p=='\0' || *p==',') {
			m=dim[var].row;
			n=dim[var].col;
		}
		else {perror_(7,l,false_); return;}

		/* assign DATA values */
		matReadAssign(var,dim[var].type,m,n);


	} while (*p++==',');
}


/* MATPRINT()
 * The MAT PRINT statement 
 * Multiple-matrices printing enabled */
void MATPRINT(void){
	int var=0, m=0, n=0, t=0;
	/* get variable code */
	if (issv(p)) var=*p++;
	else {perror_(6,l,false_); return;}

 	m=dim[var].row;
	n=dim[var].col;
	t=dim[var].type;

	/* check if array was dimensioned */
	if (t!=1 && t!=2) perror_(42,l,true_);
	
	if (1==t) {
		int i;
		for (i=0;i<=m;i++) {
			counter=printNUM(getArrayVal(var,1,i,0));
			if (counter > SCRLIM) CR();
			if (*p==';');
			else if (*p==',') {
				while (counter%ZONE) AC();
				if (counter>SCRLIM) CR();
			}
			else if (*p=='\0') CR();
			else perror_(7,l,false_);
		}
	}
	else {
		int i,j;
		for (i=0;i<=m;i++) {
			for(j=0;j<=n;j++) {
				counter=printNUM(getArrayVal(var,2,i,j));
				if (counter > SCRLIM) CR();
				if (*p==';');
				else if (*p==',' || *p=='\0') 
					while (counter%ZONE) AC();
				else perror_(7,l,false_);
				if (counter>SCRLIM) CR();
			}
			CR();
			CR();
		}
	}
	if (counter) CR();
	/* if there's something else to print after advancing p
	 * (and if this new p is not null) iterate recalling itself */
	if (*p) p++;
	if (*p) MATPRINT();
}


/* The following routines define the behavior of the DIM statement, which 
 * was included as standard since the 1964 version of the Dartmouth BASIC. */

/* isod(string-position)
 * (IS a One Dimensional array)
 * test if the current string points to a one (TRUE) or two (FALSE) 
 * dimensions array
 * p (which is not touched) points to the character after the opening '('; 
 * To test eventually for a bidimensional array, use !isod() */
int isod(char *p){
	char *h=p-1;
	while(')'!=*h && '\0'!=*h) if(','==*h++) return FALSE;
	return TRUE;
}


/* isaa(string-position)
 * (IS an Array Assignment)
 * test if the current string **begins** with an array assignment
 * (a feature enabled only for extended features) */
int isaa(char *p) {
	char *h=p;
	if (issv(h)) h++;
	else return FALSE;

	if ('('!=*h) return FALSE;
	while (')'!=*h) h++;
	if ('\0'==*h) return FALSE;
	h++;
	if ('='!=*h) return FALSE;
	return TRUE;
}	


/* dimArray(matrix-index,type,rows-number,columns-number)
 * dimension an array allocating the necessary memory space; Variables:
 * - var is the index of the variable holding the matrix name
 * - M is the number of rows (=0 for one rows matrices)
 * - N is the number of columns (=0 for vectors and one columns matrices)
 * - T is the type, 1 for unidimensional vectors, 2 for matrices
 *   The one-dimensional vector is supposed to be vertical (one column);
 *   controls over M&N<=0 are supposed to happen elsewhere 
 *   All elements of declared array are set to 0.0 */
void dimArray(int var, int T, int M, int N) {
	int size1=sizeof(double)*((M+1)*2+1);
	int size2=sizeof(double)*((M+1)*(N+1)+1);
	dim[var].row  = M;
	dim[var].col  = N;
	dim[var].type = T;
	
	/* reserve memory space for the array */
	if (T==1) {
		dim[var].elem=malloc(size1);
		if (dim[var].elem) memset(dim[var].elem,0,size1);
	}
	else if (T==2) {
		dim[var].elem=malloc(size2);
		if (dim[var].elem) memset(dim[var].elem,0,size2);
	}
	else {
		perror_(7,l,false_); 
		return;
	}
	if (!dim[var].elem) derror_(NOARRAYMEM);
}		


/* getArrayVal(matrix-index,type,row-position,column-position)
 * get value of an element of an array, given its coordinates */
double getArrayVal(int var, int t, int m, int n) {
	if (1==t) {
		if (m<=10 && 0==dim[var].row && 0==dim[var].col) 
			dimArray(var,1,10,0);
		else if (m>10 && 0==dim[var].row) perror_(20,l,true_);
		else if (m>10 && dim[var].row<m) perror_(20,l,true_);
		else if (dim[var].row<m) perror_(20,l,true_);
		return *(dim[var].elem+m*(dim[var].col+1)+2);
	}
	else if (2==t) {
		if (m<=10 && 0==dim[var].row && n<=10 && dim[var].col==0) 
			dimArray(var,2,10,10);
		else if (dim[var].row<m || dim[var].col<n) perror_(20,l,true_);
		return *(dim[var].elem+(dim[var].col+1)*m+n); 
	}
	else perror_(20,l,true_);
	return 0;
}


/* setArrayVal(matrix-index,type,row-position,column-position,value)
 * set an element of an array to a specific value, 
 * given the value itself and the element coordinates */
void setArrayVal(int var, int t, int m, int n, double val){
	if (1==t) {
		if (m<=10 && 0==dim[var].row && 0==dim[var].col) 
			dimArray(var,1,10,0);
		else if (m>10 && 0==dim[var].row) perror_(20,l,true_);
		else if (m>10 && dim[var].row<m) perror_(20,l,true_);
		else if (dim[var].row<m) perror_(20,l,true_);
		*(dim[var].elem+m*(dim[var].col+1)+2)=val;
	}
	else if (2==t) {
		if (m<=10 && 0==dim[var].row && n<=10 && dim[var].col==0) 
			dimArray(var,2,10,10);
		else if (dim[var].row<m || dim[var].col<n) perror_(20,l,true_);
		*(dim[var].elem+(dim[var].col+1)*m+n)=val;
	}
	else perror_(20,l,true_);
	return;
}


/* dimAssign()
 * wrapper for setArrayVal to be called into LET()
 * for figures like A(N)=Expr1 or A(N,M)=Expr2 
 * As stated at page 10 of the 1966 manual for version III: "The variables 
 * which we use in BASIC consist of a single letter [...] followed by the
 * subscripts in parentheses".
 * I allow the usage of A0..Z9 as an extended feature */
void dimAssign(void) {
	int var=0, m=0, n=0;
	if (issv(p)) var=*p++;
	else {perror_(6,l,false_); return;}

	if ('('!=*p++) {perror_(7,l,false_); return;}
	m=(int)S();
	if (m<0) perror_(20,l,true_);

	/* unidimensional array */
	if (*p==')') {
		p++; // skip ')'
		if (*p++!= '=') {perror_(7,l,false_); return;}
		setArrayVal(var,1,m,0,S());
	}
	/* bidimensional array */
	else if (*p==',') {
		p++; // skip ','
		n=(int)S(); 
		if (n<0) perror_(20,l,true_);
		if (')'!=*p) {perror_(7,l,false_); return;}
		p++; // skip ')'
		if ('='!=*p) {perror_(7,l,false_); return;}
		p++; // skip '='
		setArrayVal(var,2,m,n,S());
	}
	else {perror_(7,l,false_); return;}
}


/* setINPUTarray(string_pos, value) 
 * on an INPUT line, if there's an array var, get its references and 
 * stores the user given value; pos is the position in the program line, 
 * value is the value already retrieved by user input line 
 * return updated position in program line */
char* setINPUTarray(char *pos, double value) {
	int M=0, N=0, T=0, var=0;
	char *h=pos;

	/* find closing parenthesis and replace it 
	 * with a space, to stop the parser */
	while (*h!=')') 
		h++; 
	*h=' ';

	/* get var index */
	if (issv(pos)) var=*pos, pos+=2;
	else if (isdv(pos)) var=in(*pos,*(pos+1)), pos+=3;
	else {perror_(6,l,false_); return NULL;}

	/* read array element coordinates */
	p=pos, M=S(), T=1;
	/* has more than one dimension? */
	if(*p==',') p++, T=2, N=S();
	setArrayVal(var,T,M,N,value);
	return ++p;
}


/* The following routines define the behavior of standard (and extended)
 * BASIC statements, as explained in the 1966 version of the manual */;


/* DIM()
 * The DIM statement */
void DIM(void){
	char *pp=p-1;
	
	do {
		int var=0, M=0, N=0, T=1;
		/* take var index */
		pp++;
		if (issv(pp)) var=*pp++;
		else {perror_(6,l,false_); return;}

		/* get M (and N) */
		if (*pp!='(') {perror_(7,l,false_); return;}
		pp++; // skip '('
		p=pp; M=(int)S(); pp=p;
		if (M<0) perror_(20,l,true_);
		if(*pp==',') {
			pp++; // skip ','
			p=pp; N=(int)S(); pp=p;
			if (N<0) perror_(20,l,true_);
			T=2;
		}
		/* since option base is 0 and both M and N are zero
		 * (using for instance DIM A(0) or DIM A(0,0) for
		 * respectively a vector with one element and a matrix
		 * with one element) the algorithm would set up a 11-elements
		 * vector or a 11x11 elements matrix; so, I must catch this
		 * fact to warn the programmer */
		if (!M && !N) perrorEx_(37,l);
		/*  check syntax */
		if (*pp++!=')') {perror_(7,l,false_); return;}
		dimArray(var,T,M,N);
		if (*(p+1)!=','&&*(p+1)!='\0'&&*(p+1)!='\n') {
			perror_(7,l,false_);return;}
	}
	while (*pp==','); 
}


/* INPUT()
 * The INPUT statement */
void INPUT(void) {
	char *pp; // pointer to program line
	char line[STRLIM+1], linens[STRLIM+1];  // user input
	char *dp=line, *dpns=linens; // pointer to user input
	int var=0;
	int retain=FALSE; // flag for void input of one-var

	/* check if last character is something else than comma 
	 * or semicolon, in which case it's an error */
	pp=p;
	while (*pp) pp++;
	if (iscs(pp)) { 
		perror_(5,l,false_); 
		return; 
	}
	
	/* enable string printing as an extended feature;
	 * semicolon, comma or nothing may separate the string 
	 * from the variable list */
	if (*p=='\"') {
		perror_(6,l,false_); 
		return;
	}
	else if (*p=='\"') {
		p++;
		while (*p!='\"') putchar(*p++);
		p++;
		if (iscs(p)) p++;
	}

	/* 'retain' is put to TRUE if there's only one variable to input;
	 * in this case the user is free to type ENTER on a void line,
	 * thus retaining the original variable value. */
	if (!strstr(p,",") && !strstr(p,";")) 
		retain=TRUE;

	pp=p-1;
	printf("? ");
	line[0]='\0';
	/* take user input */
	fgets(line, STRLIM, stdin);

	/* return if the user pressed ENTER on a void line
	 * with a one-variable input */
	if (line[0]=='\n' && retain) {
		printn=counter=0;
		return;
	}
	
	/* process normal input, turning it into a line without spaces */
	line[strlen(line)-1]='\0'; // get rid of '\n'
	stripBlanks(dp,dpns);
	/* repeat for all variables: */
	do {
		pp++;
		/* if not all values have been input
		 * take another user input line ...*/
		while (!*dpns) {
			int i;
			for(i=0;i<STRLIM;i++) {
				line[i]=linens[i]='\0';
			}
			printf("?? ");
			fgets(line, STRLIM, stdin);
			line[strlen(line)-1]='\0'; dp=line; dpns=linens;
			stripBlanks(dp,dpns);
		}
		/* set var value to input array var*/
		if (isav(pp)) {
			double value;
			p=dpns; value=S(); dpns=p;
			pp=setINPUTarray(pp,value);
			if (*pp) {
				if (!iscs(dpns) && *dpns!='\0') 
					{perror_(7,l,false_);return;}
				if (iscs(dpns)) dpns++;
				continue;
			}
			else break;
		}
		/* take var index of single vars */
		else if (issv(pp)) var=*pp++;
		else if (isdv(pp)) var=in(*pp,*(pp+1)), pp+=2;
		else {perror_(6,l,false_); return;}
		/* set var value to input single var */
		p=dpns; P[var]=S(); dpns=p; 
		if (!iscs(dpns) && *dpns!='\0') {perror_(7,l,false_);return;}
		if (iscs(dpns)) dpns++; // there's more in the user input
	}
	while (iscs(pp)); // there's more in the program line

	/* reset printing position */
	printn=counter=0;
}


/* IFTHEN()
 * The IF..THEN/IF..GOTO statements
 * IF..GOTO is available only as an extended feature
 * following assignments are available only as an extended feature */
void IFTHEN(void){
	int flag=0;
	if (!check(p,"THEN")) {
		perror_(7,l,false_); 
		return;
	}

	/* get expression result */
	flag=(int)S();
	
	/* else skip THEN or GOTO */
	if(!strncmp(p," HEN",4) || !strncmp(p," OTO",4)) p+=4;
	/* else it's an incorrect IF */
	else {
		perror_(12,l,true_);
		return;
	}
	
	/* if IF..THEN condition is true, perform what follows THEN/GOTO */
	if (flag) {
		/* if after THEN/GOTO there's a destination */
		if (isdigit(*p)) GOTO();
		/* or if after THEN there's a GOSUB */
		/* else it's an incorrect address */
		else (perror_(12,l,true_));
	}
}


/* GOTO()
 * The GOTO Statement - called also by IF..THEN
 * a jump outside of a FOR cycle is interpreted as a break for that cycle */
void GOTO(void){
        int num=(int)S();

        /* check if destination is legal */
        if (num<=0 || (!m[num])) perror_(12,l,true_);
        else l=num;
	/* if destination is outside of a FOR cycle domain, break */
	while (forTOS>0 && !isGOSUB) {
		if (l<forStack[forTOS-4] || l>forStack[forTOS-5]) {
			forTOS-=6;
			forcount--;
		}
		/* stop break if jump is inside another FOR */
		if (forTOS>0) {
			if (l>forStack[forTOS-4] && l<=forStack[forTOS-5])
				break;
		}
	}
	l--;
}


/* GOSUB()
 * The GOSUB Statement. 
 * I must confess a very stupid mistake: in 1964 version II manual I had
 * misinterpreted the words: "...The user must be very careful not to write a 
 * program in which a GOSUB appears inside a subroutine which itself is 
 * entered via a GOSUB; it just won't work." (page 43)
 * I wrongly assumed that this meant: one GOSUB per call. So I set one level 
 * depth only, increasing it to 80 levels for extended features.
 * The Sept. 1966 version III manual, page 28, is much more clear:
 * "You may use a GOSUB inside a subroutine to perform yet another subroutine.
 * This would be called 'nested GOSUBs' [...] The user must be very caseful
 * not to write a program in which a GOSUB appears inside a subroutine which
 * refers to one of the subroutines already entered. (Recursion is not 
 * allowed!)".
 * The first sentence was not in the version II manual, the second was changed,
 * (it's now clearer) but in the meantime I did a wrong thing.
 * dib version 2.0 adopts the limit of an 80 levels depth, chosen because 80 is
 * the limit for total GOTO and IF..THEN statement (page 38).
 * I admit recursion, instead, because this is an interpreter, and I cannot
 * scan the program to establish the range of each GOSUB/RETURN couple to
 * control against the address of the recursive GOSUB; it would affect the 
 * execution speed. */
void GOSUB(void){
        int num=(int)S();
        /* check if destination is legal */
        if (num<=0 || !m[num]) perror_(12,l,true_);
        if (gosubTOS >= GOSLIM) {perrorEx_(34,l); return;}
        else gosubStack[++gosubTOS]=l, l=num-1;
	isGOSUB=TRUE;
}


/* RETURN()
 * The RETURN Statement */ 
void RETURN(void){
	/* RETURN without GOSUB? */
        if (gosubTOS <= 0) {perror_(21,l,false_);return;} 
        /* restore pointers */
        l=gosubStack[gosubTOS--];
	if (gosubTOS==0) isGOSUB=FALSE;
}


/* FOR()
 * The FOR..TO..STEP statement */
void FOR(void){
        int var,i,ivar, nextstep=0;
        double start, end, step, varvalue;

	if(forcount >= FORLIM) perror_(16,l,true_);

        if (issv(p)) var=*p++;
	else if (isdv(p)) var=in(*p,*(p+1)),p+=2;
	else perror_(7,l,false_);

        if (*p++!='=') perror_(7,l,false_);

	/* save value of FOR variable index */
	varvalue = P[var];
        
	if (check(p,"TO")) start=S(), P[var]=start;
	else perror_(7,l,false_);

	if (*p != ' ' && *(p+1) !='O') perror_(7,l,false_);
	
	if (check(p,"STEP")) {
		p+=2;
		end=S();
		p+=4;
		if (!*p) perror_(7,l,false_);
		step=S();
	}
	else {
		p+=2;
		if (!*p) perror_(7,l,false_);
		end=S();
		step=1.0;
	}

	/* look for closing NEXT matching the variable */
	for(i=l;i<CHUNKS*LIMIT;i++) {
		if(m[i] && (p=strstr(m[i],"NEXT"))){
			p+=4;
			while (*p==' '||*p=='\t') p++;
			if (issv(p)) ivar=*p;
			else if (isdv(p)) ivar=in(*p,*(p+1));
			else ivar=0;
			if (ivar==var) {
				nextstep=i;
				break;
			}
		}
	}
	
	/* If nextstep is still null, no closing NEXT has been found,
	 * so end program emitting a warning */
	if (!nextstep) {
		perror_(18,l,false_);
		l=-1;
		return;
	}
	
	/* if step is meaningless and thus not executed, go beyond FOR..NEXT, 
	 * restoring index variable value */
	if ((end-start>0 && step<0) || (end-start<0 && step>0) || step==0) {
		l=nextstep;
		P[var]=varvalue;
                return;
	}

        /* update stack values */
	forStack[++forTOS]=nextstep;	// TOS-5 = NEXT program line
	forStack[++forTOS]=l;           // TOS-4 = next instruction
        forStack[++forTOS]=var;		// TOS-3 = var index
        forStack[++forTOS]=end;         // TOS-2 = end value
        forStack[++forTOS]=step;        // TOS-1 = step value
        forStack[++forTOS]=start;       // TOS   = start/current value
	forcount++;
}


/* NEXT()
 * The NEXT... Statement
 * it **must** be followed by the variable name */
void NEXT(void) {
        int var;
        double step = forStack[forTOS-1];
        double end  = forStack[forTOS-2];

        /* get index; if different from what stored with the previous
	 * FOR instruction => NEXT error */
        if (issv(p)) var=*p++;
	else if (isdv(p)) var=in(*p,*(p+1)),p+=2;
	else perror_(7,l,false_); // !
	if (var != (int)forStack[forTOS-3]) perror_(17,l,false_);

        /* if beyond, then end cycle */
        if(((step > 0) && (forStack[forTOS]+step > end)) || \
		((step < 0) && (forStack[forTOS]+step < end))) {
                        forTOS -= 6;
			forcount--;
			return;
	}
        /* else reiterate
	 * update counter and set counter variable */
        forStack[forTOS] += step; // current = current +/- step
        P[var]=forStack[forTOS];
        l=(int)forStack[forTOS-4];
}


/* DEF()
 * The DEF Statement 
 * handles one argument in default mode and multiple arguments in extended mode
 * The label for FN must be in the A..Z range and not subscripted
 * (storing only - actual command is performed into function FN) */
void DEF(void) {
	int len, ward=*(p+2);
	int done=FALSE;

	/* case of a normal DEFFN */
	if (*p=='F' && *(p+1)=='N' && isalpha(ward) && *(p+3)=='(') {
		int varcount=0;
		char *t;

		/* point to the first variable */
		p+=4;

		/* store all argument-variables; 
		 * in normal mode, only one variable in the range A..Z and
		 * A0..Z9 may be used; in extended mode, any number of any 
		 * variables in the range A..Z and A0..Z9 may be used */
		while (*p!=')' && !done) {
			if (issv(p)) {
				fn[ward].vars[0]=++varcount;
				fn[ward].vars[varcount]=*p;
				p++;
			}
			else if (isdv(p)) {
				fn[ward].vars[0]=++varcount;
				fn[ward].vars[varcount]=in(*p,*(p+1));
				p+=2;
			}
			else {perror_(7,l,false_); return;}

			/* check syntax */
			if (*p==',' && !done) p++;
			else if (*p!=')') {perror_(7,l,false_); return;}
		}
		p++;
		if (*p!='=') {perror_(7,l,false_); return;}
		p++;
		len=strlen(p);
		fn[ward].def=malloc(len+1);
		if (!fn[ward].def) derror_(NODEFMEM);
		strncpy(fn[ward].def,p,len);
		t=p;
		p=fn[ward].def;
		while (*p) {
			tokenize();
			p++;
		}
		p=t;
		fn[ward].def[len]='\0';
	}
	/* case of a void DEFFN */
	else if (*p=='F' && *(p+1)=='N' && isalpha(ward)) {
		p+=3;		
		if (*p!='=') {perror_(7,l,false_); return;}
		p++;
		len=strlen(p);
		fn[ward].def=malloc(len+1);
		if (!fn[ward].def) derror_(NODEFMEM);
		strncpy(fn[ward].def,p,len);
		fn[ward].def[len]='\0';
	}
	else perror_(7,l,false_);
}


/* READ()
 * The READ statement */
void READ(void) {
	/* there must be at least one DATA to read! */
	if (dataLimit==0) {
		perror_(10,l,false_);
		return;
	}
	do {
		if (dc>dataLimit) {
			/* NODATA has been used */
			if (noData) l=noData-1;
			/* normal behavior: print warning and exit */
			else { perrorEx_(22,l) ; l=-1; return; }
		}
		if (isav(p)) {
			int var, M=0, N=0, T=1;
			if (issv(p)) var=*p++;
			else if (isdv(p)) var=in(*p,*(p+1)), p+=2;
			else {perror_(6,l,false_); return;}
			if (*p!='(') {perror_(7,l,false_); return;}
			p++; // skip '('
			M=(int)S();
			if (M<0) perror_(20,l,true_);
			if(*p==',') {
				p++; // skip ','
				N=(int)S();
				if (N<0) perror_(20,l,true_);
				T=2;
			}
			if (*p!=')') {perror_(7,l,false_); return;}
			setArrayVal(var,T,M,N,D[dc++]);
			p++;
		}
		else if (issv(p)) { 
			P[(int)*p++]=D[dc++];
		}
		else if (isdv(p)) {
			P[in(*p,*(p+1))]=D[dc++], p+=2;
		}
	} while (*p++==',');
}


/* RESTORE
 * the RESTORE statement 
 * if used without DATA statement, emit a NO DATA warning only in case of
 * extended mode; this is the only case in which an error 0-21 is used as
 * a warning */
void RESTORE(void){
	if (dataLimit) dc=1;
	else {
		dc=0;
	}
}


/* PRINT()
 * The PRINT statement */
void PRINT(void) {
	double val=0.0;
	char BASEOUT[SCRLIM+1];
	/* PRINT without argument */
	printn=1;
	/* PRINT with argument */
	while (*p) {
		/* print a string */
		if (*p=='\"') {
			char *u=BASEOUT;
			p++;
			while (*p && *p!='\"') {
				*u++=*p++;
			}
			*u='\0';
			/* skip closing quotes */
			p++; // skip "
			counter=printSTR(BASEOUT);
			printn=1;
			/* An expression following the string (with no 
			 * semicolon or comma, is packed to the string
			 * (see example at page 12 of the 1966 manual) */
			if (!iscs(p) && *p) {
				*--p=';'; // force semicolon output
				continue;
			}
		}
		/* adjust comma-tab position */
		else if (*p==',') {
			AC();
			AC();
			while (counter%ZONE) AC();
			p++;
			printn=0;
		}
		/* adjust semicolon-tab position 
		 * examples in the version III manual suggest that the behavior 
		 * is different than that of version II; in particular, the 
		 * semicomma seems to pack strings and the following expression */
		else if (*p==';') {
			p++;
			printn=0;
		}
		/* print an expression (treating also following comma and 
		 * semicolon, which require a different work with respect to 
		 * the above routines, designed for separators putn after strings) */ 
		else {
			val=S();
			counter=printNUM(val);
			printn=1;
		}

	}
	if (printn) CR();
}


/* LOAD(filename-string)
 * the loader */
void LOAD(char *filename) {
	/* the following 'endl' work as a flag for the END statement, 
	 * holding the line number in which it appears,
	 * while 'endn' holds the number of END statements found */
	int i;
	FILE *f;

	/* trying to open file */
	f=fopen(filename,"r");
	if (!f) derror_(NOFILE);
	
	/* erase memory */
	for(i=0;i<CHUNKS*LIMIT;i++) {
		m[i]=0;
	}

	while(fgets(B,STRLIM+1,f)) {
		int i;
		/* strip away '\n' left by fgets() */
		B[strlen(B)-1]='\0';
		/* strip away ASCII 13 left by DOS files */
		if (B[strlen(B)-1]==13) B[strlen(B)-1]='\0';
		/* store line */
		G(); // in G() p is set equal to B
		while (isspace(*p)) p++;
		/* DATA Statement - saving elements */
		if (!strncmp(p,"DATA",4)) {
			p+=4;
			while (*p) {
				/* DATA values are 0-1280 */
				if(dc>=DATLIM-1){
                                        perror_(14,l,true_);
                                        break;
                                }
				while (isspace(*p)) p++;
				/* in DATA statement there should be only numbers */
				if (!(isdigit(*p)||*p=='.'||*p=='-'))
					perror_(2,l,true_);
				D[++dc]=S();
				while (isspace(*p)) p++;
				if (*p=='\'') while (*p) p++;
				if (*p!=',' && *p!='\0') {
					perror_(7,l,false_);
					break;
				}
				p++;
			}
		}
		/* DEF Statements - saving functions */
		else if (!strncmp(p,"DEF",3)) {
			char *x=J;
			p+=3;
			stripBlanks(p,x); p=J;
			DEF(); 
		}
		/* END statements - check */	
		else if (!strncmp(p,"END",3)) {
			endn++;
			/* check if END is unique */
			if (endn>1) perror_(8,endl,true_);
			endl=l;
		}
		/* clear buffer*/
		for (i=0;i<STRLIM;i++) {
			B[i]='\0';
		}
	} /* end reading and storing file lines */

	/* trying to close file */
	if (fclose(f)) derror_(NOCLOSE);

	/* set up parameters for READ */
	dataLimit=dc, dc=1;

	/* check if END exists */
	if (!endn) perror_(9,l,true_);

	/* check if END is not last */
	if (endl!=l) perror_(8,endl,true_);
}


/* LET()
 * The LET statement (even for implicit LET)
 * assignment status: 
 * - for single assignment, return assignment status unless an error
 *   is met, in this case return FALSE
 * - for multiple assignments, return last assignment status,
 *   or FALSE at the first non-working assignment */
int LET(void) {
	int res=TRUE;
	/* in default mode, only LET statements (with LET required)
	 * and a single assignment may be used*/
	/* if it doesn't begin with LET it's an error */
	if (strncmp(p,"LET",3)) res=FALSE;
	else {
		p+=3;
		res = assign();
		if (*p) res=FALSE;
	}
	return res;
}


/* assign()
 * The assign statement - called by LET() 
 * return TRUE if assingment went OK, false otherwise */
int assign(void) {
	char *e=p;
	if (isav(p)) dimAssign();
	else if (issv(p)) p+=2, P[(int)*e]=S();
	else if (isdv(p)) p+=3, P[in(*e,*(e+1))]=S();
	else return FALSE;
	return TRUE;
}


/* This function (used into RUN and for -p option)
 * substitute operators names with tokens; tokenize 
 * '^' for **
 * '#' for <>
 * '$' for <=
 * '!' for >=
 * (if they are not into a string)
 * also, put a '\0' where an apostrophe comment is found 
 * - NOT() is treated like a unary operator in getVal() 
 * - AND is tokenized if not into RANDOMIZE
 * - OR is tokenized if not into FOR or RESTORE */ 
void tokenize(void) {
	if (*p=='*' && *(p+1)=='*') *p++='^',*p=' ';
	else if (*p=='<' && *(p+1)=='>') *p++='#',*p=' ';
	else if (*p=='<'&& *(p+1)=='=') *p++='$',*p=' ';
	else if (*p=='>'&& *(p+1)=='=') *p++='!',*p=' ';
	else if (*p=='\'') *p='\0';
}

/* RUN()
 * The RUN Statement */
void RUN(void) {
	int i;

	/* record starting time if required */
        if (isTiming) {
        	gettimeofday(&tv, NULL);
           	beginS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
        }
    
	/* set starting line */
	l=startingLine;
	
	/* initialize variables */
	for(i=0; i<LIMIT;i++) {
		P[i++]=0.0;
	}

	/* execute line by line */
	while(l){
		/* sub means 'shall I substitute?' */
		int qq, sub=1;

		/* empty buffer */
		for (qq=0;qq<=STRLIM;qq++) {
			B[qq]='\0';
		}
		
		/* skip unexistent lines in memory */
		while(!(s=m[l])) l++;
	
		/* debug output - print unchanged line */
		if (debug) {
			if (!printn) putchar('\n');
			printf("%s%d %s%s\n",INVCOLOR,l,m[l],RESETCOLOR);
		}
		
		p=s; d=0;
		while (*p){
			if (*p=='\"') sub = (sub ? 0 : 1);
			if (sub) tokenize();		
			p++;
		}
		
		/* strip blanks; afterwards, buffer B will hold
		 * executing line */
		d=B; stripBlanks(s,d);
		
		/* if it's not an assignment, it's a statement,
		 * so process language */
		if(B[1]!='=' && B[2]!='=' && !isaa(B)) {
			     if (B[0]=='\0'); // nop for void lines
			else if (!strncmp(B,"DATA",4)); //nop
			else if (!strncmp(B,"DEBUG",5)) debug=TRUE; // !! 
			else if (!strncmp(B,"DEF",3)); //nop
			else if (!strncmp(B,"DIM",3)) p=B+3, DIM();
			else if (!strncmp(B,"END",3)) l=-1;
			else if (!strncmp(B,"FOR",3)) p=B+3,FOR();
			else if (!strncmp(B,"GOSUB",5))	p=B+5,GOSUB();
			else if (!strncmp(B,"GOTO",4)) p=B+4,GOTO();
			else if (!strncmp(B,"IF",2)) p=B+2, IFTHEN();
			else if (!strncmp(B,"INPUT",5))	p=B+5,INPUT();
			else if (!strncmp(p=B,"LET",3) && LET());
			else if (!strncmp(B,"MATPRINT",8)) p=B+8, MATPRINT();
			else if (!strncmp(B,"MATREAD",7)) p=B+7, MATREAD();
			else if (!strncmp(B,"MAT",3)) p=B+3, MATtype();
			else if (!strncmp(B,"NEXT",4)) p=B+4, NEXT();
			else if (!strncmp(B,"NODEBUG",7)) debug=FALSE; // !!
			else if (!strncmp(B,"PAGE",4)) system("clear");
			else if (!strncmp(B,"PRINT",5)) p=B+5, PRINT();
			else if (!strncmp(B,"READ",4)) p=B+4, READ();
			else if (!strncmp(B,"REM",3)); // nop
			else if (!strncmp(B,"RESTORE",7)) p=B+7, RESTORE();
			else if (!strncmp(B,"RETURN",6)) RETURN();
			else if (!strncmp(B,"STOP",4)) l=-1;
			/* all statements are discarded? 
			 * It's an illegal statement*/
			else perror_(5,l,false_);
		}
		/* if it's not a statement, it's an implicit assignment to 
		 * variable, enabled only with extended features */
		else if ((p=B) && LET());
		/* If it's not a statement nor an implicit assignment,
		 * it's an illegal instruction */
		else perror_(5,l,false_);
		l++;
	}
	/* check if some NEXT was forgotten */
	if (forcount) perror_(18,forStack[forTOS-4],false_);

	/* Carriage Return */
	//CR();
}


/* G()
 * store program line
 * the algorithm accepts lines as 10PRINT or 10 PRINT, being the statement
 * always PRINT; this is of little importance for non interactive usage, but 
 * in prevision to implement dib as a standalone system, I want to make
 * sure that the user is free to type what he likes; 
 * in the listing, empty lines are accepted, even if they contain blanks
 * lines beginning with zero are ignored, as lines beginning with # 
 * (scripting purposes) 
 * the limit to 99999 as the highest line number is not considered
 * in the extended features
 * This function G() is mainly due to Diomidis Spinellis, and retains
 * its original name, but it has been heavily managed by me */
void G(void){
	int sl=0;
	p=B;
	if(*p=='\0'||*p=='#') return;
	if(isalpha(*p)) perror_(4,0,true_);
	l=atoi(p);
	if(l>99999) perror_(4,l,true_);

	/* Erase line if existing */
	if (m[l]) {int i=0; while (m[l][i]) m[l][i++]='\0'; }
	
	/* skip line number digits */
	while(isdigit(*p)) p++;
	/* skip blanks */
	while(isspace(*p)) p++;
	/* store */
	if (*p!='\0') {
		sl=strlen(p);
		m[l]=malloc(sl+1);
		if (!m[l]) {
			char temp[40];
			sprintf(temp, NOLINEMEM,l);
			derror_(temp);
		}
		strncpy(m[l],p,sl+1);
	}
} 


/* The following functions constitute the whole parser engine:
 * S() 		: the expression parser
 * getVal()	: the single value parser 
 * getFunc()	: the function parser
 * priority()	: return operator precedence
 * These functions together have been completely rewritten on completely
 * different bases than those constituting the Spinellis version - actually,
 * they are a different thing
 * Copyright Antonio Maschio - April 2008 */


/* S()
 * The PARSER for expressions - an algebraic expression is turned into an 
 * RPN stack-based expression, with numbers and operators in order in their own
 * stack; operations are performed from higher priorities down to lower and 
 * left to right;  priorities are given by the priority() function, which is 
 * part of this tool. The name S() is retained from Spinellis version,
 * due to its wide usage in the code and also as a homage to him. */
double S(void) {
	double numStack[PSTACK];
	int opStack[PSTACK], prStack[PSTACK], numTOS=0, opTOS=0, ii,jj, level;

	/* clear stack buffer */
	//for (ii=0;ii<PSTACK;ii++) {
	//	numStack[ii]=0;
	//}

	/* catch unary plus at start (simply discarded because redundant) */
	if (*p=='+') p++;
	/* catch unary minus at start */
	else if (*p=='-') {
		double res;
		p++;
		res=getVal();
		if (*p=='^') {
			/* power following a unary minus has higher priority */
			double expon;
			int sign=1;
			p++;
			if (*p=='-') p++, sign=-1;
			else if (*p=='+') p++;
			expon=sign*getVal();
			res=-power(res,expon);
		}
		else res=-res;
		numStack[numTOS++]=res;
		opturn=1;
	}
	/* reverse algebraic expression into a stack-based structure */
	while (*p && !iscs(p) && *p!='\"' && *p!='\'' && !isspace(*p) \
			&& *p!=':'&&*p!='?'){
		/* catch an operator */
		if (isop(p) && opturn) {
			opStack[opTOS]=*p;
			prStack[opTOS]=priority(*p);
			opTOS++;
			p++;
			opturn=0;
			/* operator followed by void is an illegal formula */
			if (!*p) {perror_(2,l,false_);}
		}
		/* catch a closed parenthesis */
		else if (*p==')') break;
		/* catch the unary minus after an operator */
		else if (*p=='-' && !opturn) {
			p++;
			numStack[numTOS++]=-getVal();
			opturn=1;
		}
		/* catch the unary plus after an operator */
		else if (*p=='+' && !opturn) {
			p++;
			numStack[numTOS++]=getVal();
			opturn=1;
		}
		/* catch a number (literal or variable) */
		else {
			numStack[numTOS++]=getVal();
			opturn=1;
		}
	}

	/* perform calculations from higher priorities downward */
	for (ii=5;ii>=0;ii--) {
		/* calculations are performed from left to right */
		for (level=0;level<opTOS;level++) {
			if (prStack[level]==ii) {
				/* collapse stacks */
				switch(opStack[level]) {
/************** HERE BEGINS OPERATORS ANALYSIS *********************/
/* lesser than < */
case '<': numStack[level]=-(double)(numStack[level]<numStack[level+1]); break;
/* greater than > */
case '>': numStack[level]=-(double)(numStack[level]>numStack[level+1]); break;
/* not equal <> */
case '#': numStack[level]=-(double)(numStack[level]!=numStack[level+1]); break;
/* greater than or equal >= */
case '!': numStack[level]=-(double)(numStack[level]>=numStack[level+1]); break;
/* lesser than or equal <= */
case '$': numStack[level]=-(double)(numStack[level]<=numStack[level+1]); break;
/* lesser than */
case '=': numStack[level]=-(double)(numStack[level]==numStack[level+1]); break;
/* power ^ */
case '^': numStack[level]=power(numStack[level],numStack[level+1]); break;
/* plus + */
case '+': numStack[level]+=numStack[level+1]; break;
/* minus - */
case '-': numStack[level]-=numStack[level+1]; break;
/* times * */
case '*': numStack[level]*=numStack[level+1]; break;
/* normal division */
case '/': {
		double div=numStack[level+1];
		/* if divisor (div) is null, return INFF */
		if (div==0) {
			perrorEx_(27,l); 
			numStack[level]=numStack[level]>0?INFF:MINFF;
		}
		else numStack[level]/=div;  
	  }
	  break;
/* integer division */
case '}': { 
		int a=(int)numStack[level];
		int b=(int)numStack[level+1];
		/* if divisor is null, return INFF */
		if (b==0) {
			perrorEx_(27,l);
			numStack[level]=INFF;
		}
        	else {
			int c=(int)a/b;
	        	int k=(a-b*c!=0?1:0);
		        numStack[level]=((a<0)?((c<=0)?c-k:c+k):c);
		}
	}
	break; 
/************** HERE ENDS OPERATORS ANALYSIS *********************/
				}
				/* shift stack positions */
				for (jj=level;jj<opTOS-1;jj++) {
					numStack[jj+1]=numStack[jj+2];
					opStack[jj]=opStack[jj+1];
					prStack[jj]=prStack[jj+1];
				}
				opTOS--;
				level--;
			}
		}
	}
	/* At this point, we have the final result into [0] */
	return numStack[0];
}


/* getVal()
 * get single value (number, variable, function or array element) 
 * the case of the unary minus has been caught in S() */
double getVal(void){
	double o=0;
	/* case of a real number */
	if (isnm(p)) {
		char *basep=p;
		o=strtod(p,&p);

		/* error in number conversion */
		if (basep == p) {
			perror_(1,l,false_);
	        }	
	}
	/* case of unary minus 
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='-') {
		p++;
		o=-getVal();
	}
	/* case of open parenthesis */ 
	else if (*p=='(') { 
		p++;
		o=S();
		if (*(p)!=')') perror_(2,l,false_);
		else p++; 
	}
	/* case of array variable */
	else if (isav(p)) {
		int var=0,M=0,N=0,T=1;
		if (issv(p)) var=*p++;
		else if (isdv(p)) var=in(*(p),*(p+1)),p+=2;
		else perror_(2,l,false_);
		p++; // skip '('
		M=(int)S();
		if (M<0) perror_(20,l,true_);
		if(*p==',') {
			p++;
		        N=(int)S();
			if (N<0) perror_(20,l,true_);
			T=2;
		}
		o=getArrayVal(var,T,M,N); p++; 
	}
	/* case of variable A..Z */
	else if (issv(p)) { o=P[(int)*p++]; }
	/* case of variable A0..Z9 */
	else if (isdv(p)) { o=P[in(*(p),*(p+1))]; p+=2; }
	/* delegate function calculations to getFunc() */
	else if (isfn(p)) { o=getFunc(), p++; } 
	else perror_(2,l,true_);
	return o;
}


/* getFunc()
 * functions calculator */
double getFunc(void){
	double o;
	     if(!strncmp(p,"ABS(",4)) p+=4,o=fabs(S());
	else if(!strncmp(p,"ATN(",4)) p+=4,o=atan(S());
	else if(!strncmp(p,"COS(",4)) p+=4,o=cos(S());
	else if(!strncmp(p,"DET",3)) {
		if (!isdetCalc) perrorEx_(36,l);
		o=detValue;p+=2;*p=')';
	}
	/* overflow is detected here and printed into printNUM */
	else if(!strncmp(p,"EXP(",4)) {
		p+=4,o=exp(S());
		isExp=TRUE;
	}
	/* DEF FN */
	else if(!strncmp(p,"FN",2)) {
		int ward;
		/* case of a normal DEFFN */
		if (isalpha((ward=*(p+2))) && *(p+3)=='(') {
			int cnt=1;
			char *pp;
			p+=4;
			/* set DEF variables with arguments given 
			 * in the FN function */
			while (cnt <= fn[ward].vars[0]) {
				P[fn[ward].vars[cnt]]=S();
				p++; // skip comma;
				cnt++;
			}
			p--;
			/* save pointer (because p must point to stored FN 
			 * function copied to buffer) and executes function */
			pp=p; 
			if (*p==')') {
				char buf[STRLIM+1];
				//strncpy(buf, fn[ward].def, STRLIM);
				stripBlanks(fn[ward].def,buf);
				p=buf;
				if (*p) o=S();
				else perror_(7,l,false_);
			}
			else perror_(2,l,true_);
			p=pp; // restore pointer 
		}
		/* case of a void DEFFN */
		else if (isalpha((ward=*(p+2)))) {
			char* pp=p;
			char buf[STRLIM+1];
			strncpy(buf,fn[ward].def, STRLIM);
			p=buf;
			if (*p) o=S();
			else perror_(7,l,false_);
			p=pp+2; *p=')';	
		}
		else perror_(11,l,false_);
	}
	/* the INT function as performed by version III and later */
	else if(!strncmp(p,"INT(",4)) { p+=4, o=((o=(int)S())>=0)?o:o-1; }
	/* the absolute value of LOG was in the original BASIC */ 
	else if(!strncmp(p,"LOG(",4)) {
		p+=4, o=S();
		if (o<0)  {perrorEx_(24,l); o=log(fabs(o));}
		else if (o==0) {perrorEx_(25,l); o=MINFF;}
		else o=log(o);
	}
	/*  The RND with required parameter (default mode) 
	 *  Enhancement: an argument different from zero sets the new seed */
        else if(!strncmp(p,"RND(",4)) {
		int seed;
		p+=4; 
		seed=(int)S();
	        if (seed) {
			time_t now=time(NULL);
			srand((double)now);
			rand();
		}	
		o=getRandom(); 
	}
	/* the absolute value of SQR was in the original BASIC */ 
	else if(!strncmp(p,"SQR(",4)) {
		p+=4; o=S();
		if (o<0) { 
			/* print warning */
			perrorEx_(23,l); 
			o*=-1; 
		}
		o=sqrt(o);
	}			
	else if(!strncmp(p,"SIN(",4)) {
		p+=4;
		o=sin(S());
	}
	else if(!strncmp(p,"TAN(",4)) {
		p+=4;
		o=tan(S());
	}
	else perror_(2,l,true_);
	/* check closing parenthesis (advancing of p is done into getVal() )*/
	if (*p!=')') perror_(2,l,true_);
	return o;
}


/* priority(operator-char)
 * return math priority for operators, according to the following table
 * (operators marked with ** belong to the extended features)
 * 7: (..) (caught in getVal) have the higher precedence in absolute
 * 6: NOT** (caught in getVal) has the higher precedence among operators
 * 5: power
 * 4: multiplication, division, integer-division** and MOD**
 * 3: addition, subtraction
 * 2: <, >, =, <=, >=, <>
 * 1: AND**, OR**, XOR**
 * 0: EQV**, IMP**
 * */
int priority(const int op) {
	if (op=='^') return 5;
	else if (op=='*'||op=='/'||op=='}'||op=='{') return 4;
	else if (op=='+'||op=='-') return 3;
	else if (op=='<'||op=='>'||op=='='||op=='$'||op=='#'||op=='!')return 2;
	else if (op=='&'||op=='|'||op=='%') return 1;
	else return 0; // EQV and IMP
}


/* The following functions define system dib's features: 
 * number output, printer management, variable maintenance, errors printing, 
 * math operations, licensing, versioning, help and others */


/* AC()
 * Advance Carriage */
void AC(void) {
	counter++;
	putchar(' ');
}


/* CR()
 * Carriage Return */
void CR(void) {
	counter=0;
	putchar('\n');
}


/* getRandom()
 * return a random number */
double getRandom(void) {
	double o=(double)rand();
	while (o>RANDL) {
		o/=DIV;
	}
	return o/RANDL;
}


/* doExp(str, &base, &exp) 
 * find base and exponent of a number which must be printed in exponential 
 * form given the pointer to the string str containing the number in raw form.
 * See 1966 manual, page 25, for instance, for some output of numbers in
 * exponential form */
void doExp(char *pos, double *base, int *exp) {
	char *e = strstr(pos, "E");
	if (!e) return; // make error?
	*e=' ';
	*base=strtod(pos,NULL);
	*exp=strtol(e,NULL,10);
}


/* emitNUM(sign-char,number-string)
 * emit the string number calculated by printNUM(), checking screen limit;
 * - minus holds the character '-' in case of negative number or ' ' in case
 *   of positive number (sign has always its position in Dartmouth BASIC)
 * - num holds the string of the converted number to be printed 
 * return updated position of counter (which is passed through by printNUM) 
 * The number is printed as pictured at page 23 og the 1966 manual:
 * 	in six spaces if the number is 1/2/3 digits long 
 * 	in nine spaces if the number is 4/5/6 digits long 
 * 	in twelve spaces if the numberis 7/8/9 digits long */
int emitNUM(char minus, char *num) {
	int ret=strlen(num);
	char format[64],numstring[64];
	/* the sign is meaningful only for big numbers (??)*/
	if (strstr(num,"E")) ret++;
	/* format proper string */
	if (1<=ret && ret<=3) strcpy(format,"%c%-5s");
	else if (4<= ret && ret <= 6) strcpy(format,"%c%-8s");
	else if (7<= ret && ret <= 9) strcpy(format,"%c%-11s");
	else strcpy(format,"%c%-14s");
	sprintf(numstring,format, minus, num);
	if (counter+ret>SCRLIM) CR();
	printf("%s",numstring);
	ret=strlen(numstring);
	return counter+ret;
}


/* printNUM(number)
 * print number according to Dartmouth BASIC rules at page 24-25 (1966 manual)
 * return updated position of counter (as yielded by emitNum) */
int printNUM(double num) {
	int isFloat=TRUE;
	char minus=' ';
	char nums[STRLIM+1], *nump;
	double base;
	int exp;

	/* operate only with positive numbers, storing the sign aside */
	if (num<0) num=-num , minus='-';

	/* option -z activates cutOff, which causes numbers in output
	 * to be printed as zero if lower than EPSILON (1E-10 by default)
	 * these "fake" numbers have a negative or a positive sign, and
	 * so they can be distinguished by "real" zeroes */
	if (cutOff && num<EPSILON) {
		if (minus=='-') return emitNUM(minus,"0");
		else return emitNUM('+',"0");
	}

	/* number should actually never be lesser than ZERO; 
	 * the retaining of the sign is a dib feature. */
	if (num>0 && num<ZERO) {
		perrorEx_(31,l);
		return emitNUM(minus,"0."); 
	}

	/* the zero is simply a zero: no warnings. */
	else if (num==0.0) {
		return emitNUM(minus,"0");
	}

	/* the number should never be > INFF in absolute value */
	else if (num > INFF) {
		if (isExp) perrorEx_(43,l);
		else perrorEx_(30,l);
		num=INFF;
		isExp=FALSE;
	}

	/* temporarily, use exponential or normal form 
	 * in representing the number in a raw form */
	if (num < 1E-10 || num > 1E10) sprintf(nums, "%.5E", num);
	else sprintf(nums, "%21.10F", num);

	/* rule 4: suppress final zeroes */
	nump=nums+strlen(nums)-1;
	while('0'==*nump) {
		*nump--='\0';
	}

	/* rule 1 part 1: if there's a final dot in an integer, suppress it */
	if('.'==*nump) {
		*nump--='\0';
		isFloat=FALSE;
	}

	/* suppress any possible trailing nulls */
	nump=nums;
	while(*nump == '0' || *nump == ' ') {
		nump++;
	}

	/* print real number */
	if(isFloat){
		/* exception to rule 3: print real number as-is if it fits */
		if (num <= 0.1 && strlen(nump) < 8) return emitNUM(minus,nump);

		/* rule 3: print real with exponent */
		else if (num < 0.1) {
			sprintf(nums,"%.5E",num);
			doExp(nums,&base,&exp);
			if (exp<0) sprintf(nums,"%.5f E%d",base,exp);
			else sprintf(nums,"%.5f E %d",base,exp);
			return emitNUM(minus,nums);
		}
		/* rule 2: print real with 6 significant digits 
		 * retaining decimal dot (use of #)*/ 
		else {
			sprintf(nums,"%#.6G",num);
			nump=strstr(nums,"E");
			/* clean ending trailing zeroes if number is
			 * not in exponential form */
			if (!nump) {
				nump=nums+strlen(nums)-1;
				while (*nump=='0') {
					*nump--='\0';
				}
			}
			/* clean number if in exponential form */
			else {
				doExp(nums,&base,&exp);
				if (exp<0) sprintf(nums,"%.5f E%d",base,exp);
				else sprintf(nums,"%.5f E %d",base,exp);
			}
			/* skip leading trailing zero, e.g. 0.nnn -> .nnn */
			nump=nums;
			if(*nump=='0') nump++;
			return emitNUM(minus,nump);
		}
	}
	/* print integer number */
	else {
		/* rule 1 part 2: print integer till 9 significant digits */
		if (strlen(nump) < 10) return emitNUM(minus,nump);

		/* rule 1 part 2 (reverse case): print integer with exponent
		 * and 6 significant digits (that is, 5 decimals) */
		else { 
			sprintf(nums,"%.5E",num);
			nump=strstr(nums,"E");
			if (nump) {
				doExp(nums,&base,&exp);
				if (exp <0) sprintf(nums,"%.5f E%d",base,exp);
				else sprintf(nums,"%.5f E %d",base,exp);
			}
			return emitNUM(minus,nums);
		}
	}

	/* avoiding warnings.... 
	 * this routine should never gets here */
	return 0;
}


/* printSTR
 * emit a string returning the updated counter
 * - str is the string to be printed  */
int printSTR(char *str) {
	int ret=strlen(str);
	if (counter+ret>SCRLIM) CR();
	printf("%s",str);
	return counter+ret;
}


/* check(string1,string2)
 * check if sb syntax is correct against sc; if it is, put a space in the 
 * position found, so that a subsequent parsing by S() may stop without 
 * issuing an error message from getFunc() and return true; 
 * if syntax it's not correct, return false.
 * This is done in statements with some core-words, like IF <Test> THEN
 * where the parsing of <Test> must stop just before THEN; check() inserts 
 * a space in place of the T of THEN, causing the parser to stop there */
int check(char *sb, char *sc){
	char *qq=strstr(sb,sc);
	/* put a space to stop S() parsing */
	if (qq) { *qq=' '; return TRUE; }
	return FALSE;
}


/* power(base,exponent)
 * powering function */
double power(double base, double expon) {
	/* if base is negative, take some cautions... */
	if (base<0) {
		/* integer exponent is always evaluable */
		if (expon==(double)((int)expon)) {
			if ((int)expon%2) 
				// odd exponent
				return -pow(-base,expon);
				// even exponent
				else return pow(base,expon);
		}
		/* while real exponent is not if base < 0,
		 * so take absolute value */
		else {
			perrorEx_(26,l);
			/* the absolute value was in the original BASIC */
			return pow(fabs(base),expon);
		}
	}
	/* INFF is a safe result for 0^(<0) */
	else if (expon<0 && base==0) {
		perrorEx_(32,l);
		return INFF;
	}
	/* 1 is the limit of function x^x if x approaches zero from right */
	else if (expon==0 && base==0) {
		perrorEx_(33,l);
		return 1.0;
	}
	/* default case for base > 0 and any exponent */
	else return pow(base,expon);
}


/* stripBlanks(src, dest)
 * strip blanks from src and copy stripped string to dest
 * stop stripping while into a string */
void stripBlanks(char *src, char *dest) {
	int j=1; // strip flag/counter
	while (*src) {
		if (*src=='\"') j++;
		if (j&1) { if (*src!=' ' && *src!='\t') *dest++=*src; }
		else *dest++=*src;
		src++;
	}
	*dest='\0';
}


/* derror_(error-string)
 * print dib system error message */
void derror_(char* text) {
	fprintf(stderr, text);
	fprintf(stderr, "Type dib -h for help.\n");
	exit(EXIT_FAILURE);
}


/* perrorEx_(error-code,line-number)
 * print warnings, contextually, retain counter position and 
 * update printing position the new line*/ 
void perrorEx_(int error, int line){
	int diff=0;
	if (counter!=0) putchar('\n');
	if (line) {
		printf("\n%s IN  %d   IN %s\n", ers[error],line,FileName);
	}
	else printf("%s\n", ers[error]);
	/* rebuild position */
	while (diff++ < counter) {
		putchar(' ');
	}
}


/* perror_(error-code,line-number,exit-flag)
 * print the BASIC error message and exit if exit-flag go_away is TRUE
 * also, retain counter position and update printing position on the new line*/ 
void perror_(int error, int line, int go_away) {
	int diff=0;
	if (counter!=0) putchar('\n');
	if (line) {
		printf("\n%-21sIN %d   IN %s\n", ers[error],line,FileName);
	}
	else printf("%s\n", ers[error]);
	/* exit emitting error code as exit status
	 * the exit status is increased by 100, so subtract 100 to get
	 * the error condition. Just in case you need it... */
	if (go_away) exit(error+100);
	/* rebuild position */
	else while (diff < counter) {
		putchar(' '),diff++;
	}
}


/* in(letter-index,number-index)
 * return index for vars A0..Z9 using a math algorithm 
 * to ensure their memory space is not the same of 
 * variables A..Z, to avoid overwriting */
int in(char c, char d) {
	return (200+((int)c-'A')*10+(int)d);
}


/***************************************
 *      DOCUMENTATION AND LICENSE      *
 ***************************************/


/* printHelp()
 * help message */
void printHelp(void) {
	printf("Usage: dib [options] filename\n");
	printf("\nOptions:\n");
	printf("      --conditions  Print redistribution conditions from GPL3\n");
	printf("  -d  --debug       Activate debug mode\n");
	printf("      --errors-list Print a complete errors list and exit\n");
	printf("  -h, --help        Display this information and exit\n");
	printf("  -i, --id-line     Display program heading\n");
	printf("  -p 'expr'         Print BASIC expression 'expr' and exit\n");
	printf("  -s<n>             Start executing BASIC program from line <n>\n");
	printf("  -t, --timing      Print a time report after execution\n");
	printf("  -v, --version     Display version and exit\n");
	printf("      --warranty    Print warranty conditions from GPL3\n");
	printf("  -z                Print as zero numbers smaller than %G\n",EPSILON);
	printf("\nIf no file name is specified, dib will complain.\n");
    	printf("You should have received a copy of the GNU General Public License\n");
	printf("along with this program. If not, see <http://www.gnu.org/licenses/>.\n\n");
	printf("Email bugs reports to <ing dot antonio dot maschio at gmail dot com>.\n\n"); 
}


/* printVersion()
 * version message */
void printVersion(int flag) {
	printf("\ndib (dib is BASIC) - Dartmouth BASIC III (1966) interpreter\n");
	printf("version %s (build %d, %s, %s)\n", VERSION, BUILD, __DATE__, __TIME__);
	printf("Copyright (C) %s %s <%s>. ", CY, AU, EM);
	if (flag) printf("This program\ncomes with ABSOLUTELY NO WARRANTY; for details type 'dib --warranty'.\n");
	if (flag) printf("This is free software, and you are welcome to redistribute it under certain\n");
	if (flag) printf("conditions; type 'dib --conditions' for details.");
	printf("\nThis software is released under the terms of the GNU General Public License 3.\n\n");
}


/* printWarranty()
 * warranty message (required by GPL3) */
void printWarranty(int flag) {
	if (flag) printf("\ndib (dib is BASIC)\nDartmouth BASIC III (1966) interpreter");
	if (flag) printf(" - version %s (build %d)\n", VERSION, BUILD);
	if (flag) printf("Copyright (C) %s %s <%s>\nunder the terms of the GNU General Public License 3.\n\n", CY, AU, EM);
	printf("THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\n");
	printf("APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT\n");
	printf("HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT\n");
	printf("WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT\n");
	printf("LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A\n");
	printf("PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF\n");
	printf("THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME\n");
	printf("THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\n");
}


/* printConditions()
 * conditions message (required by GPL3) */
void printConditions(int flag) {
	if (flag) printf("\ndib (dib is BASIC)\nDartmouth BASIC III (1966) interpreter");
	if (flag) printf(" - version %s (build %d)\n", VERSION, BUILD);
	if (flag) printf("Copyright (C) %s %s <%s>\nunder the terms of the GNU General Public License 3.\n\n", CY, AU, EM);
	printf("You may make, run and propagate covered works that you do not convey,\n");
	printf("without conditions so long as your license otherwise remains in force.\n");
	printf("You may convey covered works to others for the sole purpose of having\n");
	printf("them make modifications exclusively for you, or provide you with\n");
	printf("facilities for running those works, provided that you comply with the\n");
	printf("terms of this License in conveying all material for which you do not\n");
	printf("control copyright. Those thus making or running the covered works for\n");
	printf("you must do so exclusively on your behalf, under your direction and\n");
	printf("control, on terms that prohibit them from making any copies of your\n");
	printf("copyrighted material outside their relationship with you.\n\n");
}


/* printHeader()
 * print a DTSS-like header with file name, date and hour */
void printHeader(void) {
	char nameonly[CHUNKS];
	int i=0;
	struct tm *dibtm;
	time_t st_lt;
	strncpy(nameonly,basename(FileName),CHUNKS-1);

	/* build up name without extension */
	while (nameonly[i]!='.' && i<CHUNKS)  {
		i++;
	}
	nameonly[i]='\0';

	st_lt=time(NULL);
	dibtm = localtime(&st_lt);

	printf(HEADER,nameonly,dibtm->tm_hour,dibtm->tm_min,
			month[dibtm->tm_mon+1],dibtm->tm_mday,
			1900+dibtm->tm_year);
	printf("\n");
}


/* s_exit()
 * safe exit - avoid messing up of colours, and force the screen resetting
 * return 'state' as current state
 * system function */
void s_exit(int state) {
	/* reset screen */
	fprintf(stdout,"%s",RESETCOLOR);
	exit(state);
}

/********************************
 *	 dib  MAIN	 *
 ********************************/
int main(int argc, char **argv) {
	int c, ac = argc;

	/* record starting time; beginS is used in the INFO function */
        gettimeofday(&tv, NULL);
        beginS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
        beginM = (int)(tv.tv_sec *1000 + tv.tv_usec / 1000);

	/* parse interpreter arguments */
	while (--ac > 0 && '-' == (*++argv)[0]) {
		/* parse double-dash options */
		     if (!strcmp(*argv, "--help")) 
			{printHelp(); exit(0);}
		else if (!strcmp(*argv, "--version")) 
			{printVersion(TRUE);exit(0);}
		else if (!strcmp(*argv, "--warranty")) 
			{printWarranty(TRUE);exit(0);}
		else if (!strcmp(*argv, "--conditions")) 
			{printConditions(TRUE);exit(0);}
		else if (!strcmp(*argv, "--errors-list")) {
			int c;
			printf("Errors list\n");
			printf("----------\n");
			for (c=0;c<ERRN;c++) {
				if (c==22) {
					printf("\nWarnings list\n");
					printf("-------------\n");
				}
				if (ers[c][0]) printf("#%2d: %s\n",c,ers[c]); 
			}
			exit(0);
		}
  	        else if (!strcmp(*argv,"--timing")) {
			isTiming=TRUE;
			continue;
		}
  	        else if (!strcmp(*argv,"--id-line")) {
			isPrintHeader=TRUE;
			continue;
		}
		/* this feature is intentionally undocumented 
		 * I use it to generate the README file */
		else if (!strcmp(*argv, "--greetings")) {
			printf("Welcome, dib user! I hope you\'ll like ");
			printf("this program.\n");
			printf("Here\'s some information about it ");
			printf("and its license...\n");
			printVersion(FALSE);
			printHelp();
			printf("To compile type 'make' as user in ");
			printf("dib source directory.\nTo install ");
			printf("type 'make install' as root after compiling.\n");
			printf("For help about dib's features, after");
			printf(" installation, see 'dib_manual.txt'.\n\n");
			printWarranty(FALSE);
			printConditions(FALSE);
			printf("It's GPL. Enjoy!\n");
			exit(EXIT_SUCCESS);
		}
	
		/* parse single-dash options */
		while ((c = *++argv[0])) {
			if (c=='c') false_=(false_==FALSE?TRUE:FALSE); 
			else if (c=='d') debug=TRUE; 
			else if (c=='h') {printHelp(); exit(0);}
			else if (c=='i') isPrintHeader=TRUE;
			else if (c=='p') {
				char line[LIMIT+1];
				char *q; // backup pointer
				int sub=1;

				/* get expression and store in p */
				if ('\0' == (*argv)[1])  
					if (NULL==*(argv+1)) {
						fprintf(stderr, NOSTRING);
						exit(EXIT_FAILURE);
					}
					else p = *(argv+1);
				else p = *argv+1;

				/* tokenize, saving pointer p */
				q=p;
				while (*p) {
					if (*p=='\"') sub = (sub ? 0 : 1);
					if (sub) tokenize();		
					p++;
				}

				/* strip blanks and print result */
				stripBlanks(q,line);
				p=line;
				printf("\n"); PRINT(); printf("\n");
				exit(0);
			} 
			else if (c=='s') {
                    		if ('\0' == (*argv)[1]) {
                		        fprintf(stderr, NOLINE);
					exit(EXIT_FAILURE);
	                    	}
                    		else startingLine=atoi(*argv+1);
				*argv+=strlen(*argv+1)+1;
				if (startingLine<=0) startingLine=1;
				break;
			}
			else if (c=='t') isTiming=TRUE;
			else if (c=='v') {
				printVersion(TRUE); 
				exit(0);
			}
			else if (c=='z') cutOff=TRUE;
			/* option -V (UNDOCUMENTED) */
			else if (c=='V') {
				fprintf(stdout,"%s",VERSION);
				exit(EXIT_SUCCESS); 
			}
			else {
				char t[40];
				sprintf(t,NOOPTION,c);
				derror_(t);
			}
		}
	}

	
	/* get input file name (discard following names) */ 
	strncpy(FileName,*argv,257);

	/* ok; now, if after any option there's no file name left
	 * (or if dib was launched with no parameters), issue an error */
	if (('\0'==*FileName)||(1==argc)) derror_(NOFILENAME);

	/* LOAD program in memory */
	LOAD(FileName);

	/* set up printer position and counter */
	CR();

	/* and finally RUN! */
	if (isPrintHeader) printHeader();
	RUN();

	/* exit */
	/* in case of timing, add the timed calculation string */
	if (isTiming) {
		int hour=0,min=0;
		double secs=endS;
		
		/* record end time */
		gettimeofday(&tv, NULL);
	       	endS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS=endS-beginS;

		/* pre-calculate intermediate time values */
		if (endS>60) {
			min=endS/60;
			endS=endS-min*60;
		}
		if (min>60) {
			hour=min/60;
			min=min-hour*60;
		}
		if (counter) fputc('\n',stdout);
		/* depict time in condensed form */
		if (!hour && !min) {
			if (secs<1) 
			     fprintf(stdout,"TIME:  %.2f MSECS.\n\n",endS*1000);
			else 
			     fprintf(stdout,"TIME:  %.2f SECS.\n\n",endS);
		}
		else if (!hour)
			fprintf(stdout,"TIME:  %.2d:%.2d MIN%c	(%.2f SECS).\n\n",min,(int)(endS+0.5),min!=1?'S':' ',secs);
		else 	
			fprintf(stdout,"TIME:  %.2d:%.2d:%.2d HOUR%c   (%.2f SECS).\n\n",hour,min,(int)(endS+0.5),hour!=1?'S':' ',secs);
	}
	
	s_exit(EXIT_SUCCESS);
    
	/* exit: the program gets here only if no error caused 
	 * anticipated exit in some line other than the last */
	return EXIT_SUCCESS;

} /* end main */

/* end of dib.c */
