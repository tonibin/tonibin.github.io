/* errors.h 
 * Copyleft (C) 2009-2014 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 20 febbraio 2021
 * 
 * This is dia, The Dartmouth ALGOL interpreter written for the UNIX world.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This file contains the errors and warnings messages issued by dia.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

char* error[]= {

/* ALGOL ERRORS */
/*  0 */ "",    // 
/*  1 */ "MISMATCHED PARENTHESES", 			// E01 (17 and 23)
/*  2 */ "MISSING OPERAND OR DELIMITER", 		// E02 (5)
/*  3 */ "IDENTIFIER TOO LONG", 			// E03 (2)
/*  4 */ "SYMBOL ALREADY DEFINED",	 		// E04 (28)
/*  5 */ "ILLEGAL DECLARATION", 			// E05 (27)
/*  6 */ "INCORRECT NUMBER OF SUBSCRIPTS",	 	// E06 (18)
/*  7 */ "ILLEGAL ASSIGNMENT", 				// E07
/*  8 */ "ILLEGAL STATEMENT", 				// E08 (26)
/*  9 */ "ILLEGAL STRING", 				// E09
/* 10 */ "UNEXPECTED END", 				// E10
/* 11 */ "ILLEGAL IDENTIFIER", 				// E11 (22)
/* 12 */ "DUPLICATED LABEL", 				// E12
/* 13 */ "ILLEGAL CONSTANT FORMAT",	 		// E13 (7)
/* 14 */ "EXPONENT OF CONSTANT TOO LARGE", 		// E14 (8)
/* 15 */ "DATA BLOCK NAME MISSING",	 		// E15 (24)
/* 16 */ "ILLEGAL DATA BLOCK NAME", 			// E16
/* 17 */ "OUT OF DATA", 				// E17
/* 18 */ "ILLEGAL SYMBOL SEQUENCE",	 		// E18 (11)
/* 19 */ "ARRAY NOT SUBSCRIPTED", 			// E19 (14)
/* 20 */ "DIVISION BY ZERO", 				// E20
/* 21 */ "OVERFLOW",	 				// E21 (43)
/* 22 */ "SQRT OF X",	 				// E22 (40)
/* 23 */ "LN OF X",	 				// E23 (39)
/* 24 */ "SUBSCRIPT OUT OF BOUNDS",	 		// E24 (41)
/* 25 */ "ERROR IN PROCEDURE CALL",	 		// E25 (25)
/* 26 */ "MEMORY OVERFLOW", 				// E26 
/* 27 */ "X^Y", 					// E27 (38)
/* 28 */ "UNDEFINED LABEL IN PROGRAM",	 		// E28 (34)
/* 29 */ "NON-BOOLEAN EXPRESSION FOLLOWING \"IF\"",	// E29 (20)
/* 30 */ "ILLEGAL LEFT PART VARIABLE",	 		// E30 (15)
/* 31 */ "ILLEGAL SUBSCRIPT", 				// E31 (16)
/* 32 */ "UPPER BOUND LESS THAN LOWER BOUND", 		// E32 (31)
/* 33 */ "NO COLON IN BOUND PAIR", 			// E33 (30)
/* 34 */ "SUSPECT MISSING \"THEN\" OR \"ELSE\"", 	// E34 (19)
/* 35 */ "ILLEGAL SYMBOL AFTER EXPRESSION", 		// E35 (10)
/* 36 */ "INTEGER TOO LARGE", 				// E36 (42)
/* 37 */ "ERROR IN \"FOR\" STATEMENT", 			// E37 (37)
/* 38 */ "PROGRAM INCOMPLETE", 				// E38 (36)
/* 39 */ "ILLEGAL TYPE",				// E39
/* 40 */ "ILLEGAL EXPRESSION IN CALL-BY-NAME",		// E40
/* 41 */ "FILE NOT OPEN",				// E41
/* 42 */ "CANNOT OPEN FILE",				// E42
/* 43 */ "FILE TYPE MISMATCH",				// E43
/* 44 */ "END OF FILE",					// E44
/* 45 */ "FILE ALREADY OPEN",				// E45
/* 46 */ "TOO MUCH FILES OPEN",				// E46
/* 47 */ "",
/* 48 */ "",
/* 49 */ "",
/* 50 */ "dia: file not found.",
/* 51 */ "dia: memory error.",
/* 52 */ " is an unrecognized option. Ignored.",
/* 53 */ "dia: I/O channel error.",
/*L+1 */ ""					/* last + 1 */
};

#define ERRLIM 54				/* L + 1 */

