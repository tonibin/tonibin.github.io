" Vim syntax file
" Language:	ALGOL - for tonibin's DEC ALGOL dia
" Creator:	Antonio Maschio <ing dot antonio dot maschio at gmail dot com>
" Maintainer:	Antonio Maschio <ing dot antonio dot maschio at gmail dot com>
" Last updated: agosto 09, 2026

" Language: dia (Algol)
" Maintainer:   Antonio Maschio <ing dot antonio dot maschio at gmail dot com>
" Latest Revision: August 2026

" Keywords
syn keyword diaKeyword 	PROCEDURE BEGIN STOP END FOR WHILE DO
syn keyword diaKeyword 	LABEL ARRAY IF OWN STEP SWITCH THEN UNTIL ELSE
syn keyword diaKeyword 	READATA PRINT WRITEDATA WRITE RESTORE CLOSE
syn match diaKeyword    "GO\s*TO"

" Types
syn keyword diaType 	REAL INTEGER BOOLEAN STRING VALUE DATA INFILE OUTFILE 

" Mathematical functions
syn keyword diaMathFunc ABS COS EXP SIN TAN SIGN LN SQRT ENTIER RANDOM

" String function SIZE (colored like string literals)
syn keyword diaString 	SIZE CONCAT EVAL

" String literals 
syn region diaString start=+\"+ end=+\"+
syn region diaString start=+\.\[+ end=+\]+
hi def link diaStringFunc diaString

" Label (iniziano con una lettera e terminano con : non seguito da =)
syn match diaLabel "\<[^\d*\s*][A-Z][A-Z0-9_]*:\([^=]\|$\)"me=e-1

" Numbers: integers, reals
syn keyword diaNumber  TRUE FALSE
syn match diaNumber "[+-]\=\<\d\+\>"
syn match diaFloat  "[+-]\=\<\d\+\(\.\d\+\)\=\([E\$]\+[+-]\=\d\+\)\=\>"

" Commenti introdotti da ! oppure COMMENT, fermandosi al primo ;
syn region diaComment start="!" end=";"
syn region diaComment start="COMMENT" end=";"
syn region diaComment start="END"lc=3 matchgroup=diaKeyword end="[\.;.*$]"

" Dartmouth Line numbers (solo all'inizio della riga)
syn match diaDartNumber "^\s*\d\+"

" Highlighting links
hi def link diaKeyword   	Statement
hi def link diaType      	Type
hi def link diaMathFunc  	Function
hi diaString                    ctermfg=Red guifg=Red ctermbg=NONE guibg=NONE
hi def link diaComment   	Comment
hi def link diaNumber    	Number
hi def link diaLabel     	Label
hi diaDartNumber 		ctermfg=Blue guifg=Blue ctermbg=NONE guibg=NONE
hi def link diaFloat     	Number

let b:current_syntax = "dia"
set ts=3
set nocin
set nosi
set columns=75

