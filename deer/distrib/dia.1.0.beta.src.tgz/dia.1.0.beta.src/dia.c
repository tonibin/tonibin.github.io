/* dia.c 
 * Copyleft (C) 2017 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 27 giugno 2026
 * 
 * This is dia, an Algol interpreter written in c99 for the UNIX world.
 * You must have at least gcc 3.X to compile (though version 2.9X may suffice).
 * 
 * This program is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) 
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with 
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */
#include "dia.h"	// catch-all file


/***************************************************************************
 * Dartmouth I/O procedures
 ***************************************************************************/

/* The following functions define system dia's features: 
 * number output, printer management, variable maintenance, errors printing, 
 * math operations, licensing, versioning, help and others */


/* AC()
 * Advance Carriage */
void AC(void) {
	counter++;
	strcat(GLOB," ");
}


/* CR()
 * Carriage Return */
void CR(void) {
	counter=0;
	putchar('\n');
}


/* FCR()
 * Carriage Return */
void FCR(FILE *ostream) {
	counter=0;
	fputc('\n',ostream);
}


/* getRandom()
 * return a random number */
double getRandom(void) {
	double o=(double)randSeed/RANDL;
	return o;
}


/* doExp(str, &base, &exp) 
 * find base and exponent of a number which must be printed in exponential 
 * form given the pointer to the string str containing the number in raw form.
 * See 1966 manual, page 25, for instance, for some output of numbers in
 * exponential form */
void doExp(char *pos, double *base, int *exp) {
	char *e = strstr(pos, "E");
	if (!e) return; // make error?
	*e=' ';
	*base=strtod(pos,NULL);
	*exp=strtol(e,NULL,10);
}


/* emitNUM(sign-char,number-string)
 * emit the string number calculated by printNUM(), checking screen limit;
 * - minus holds the character '-' in case of negative number or ' ' in case
 *   of positive number (sign has always its position in Dartmouth BASIC)
 * - num holds the string of the converted number to be printed 
 * return updated position of counter (which is passed through by printNUM) 
 * The number is printed as pictured at page 23 og the 1966 manual:
 * 	in six spaces if the number is 1/2/3 digits long 
 * 	in nine spaces if the number is 4/5/6 digits long 
 * 	in twelve spaces if the numberis 7/8/9 digits long 
 * the sign seems not comprised in this schema...; finally, if the number
 * is longer 12 or more characters, the counter is pushed to the next minizone;
 * see example at page 25 of the 1966 manual */
int emitNUM(char minus, char *num) {
	int ret=strlen(num);
	char format[64],numstring[64];
	if (resultType<BOOLEANTYPEBOX) {
		if (strstr(num,"E")) ret++;
		/* format proper string */
		if (1<=ret && ret<=3) strcpy(format,"%c%-5s");
		else if (4<= ret && ret <= 6) strcpy(format,"%c%-8s");
		else if (7<= ret && ret <= 9) strcpy(format,"%c%-11s");
		else strcpy(format,"%c%-14s");
		sprintf(numstring,format, minus, num);
		if (counter+ret>COMPSCR) CR();
	}
	else {
		strcpy(format," %-8s");
		if (num[0]=='0') sprintf(numstring,format,"false");
		else sprintf(numstring,format,"true");
	}
	strcat(GLOB,numstring);
	ret=strlen(numstring);
	return counter+ret;
}


/* printNUM(number)
 * print number according to Dartmouth BASIC rules at page 24-25 (1966 manual)
 * return updated position of counter (as yielded by emitNum) */
int printNUM(double num) {
	int isFloat=TRUE;
	char minus=' ';
	char nums[STRLIM+1], *nump;
	double base;
	int exp;

	/* if number is null, shorten the process! */
	if (num==0) return emitNUM(' ',"0");
	
	/* operate only with positive numbers, storing the sign aside */
	if (num<0) num=-num , minus='-';

	/* number should actually never be lesser than ZERO; 
	 * the retaining of the sign is a dia feature. */
	if (num<ZERO) {
		return emitNUM(minus,"0"); 
	}

	/* the number should never be > REALMAX in absolute value */
	else if (num > REALMAX) {
		num=REALMAX;
		isExp=FALSE;
	}

	/* temporarily, use exponential or normal form 
	 * in representing the number in a raw form */
	if (num < 1E-10 || num > 1E10) sprintf(nums, "%.5E", num);
	else sprintf(nums, "%21.10F", num);

	/* rule 4: suppress final zeroes */
	nump=nums+strlen(nums)-1;
	while('0'==*nump) *nump--='\0';

	/* rule 1 part 1: if there's a final dot in an integer, suppress it */
	if('.'==*nump) {
		*nump--='\0';
		isFloat=FALSE;
	}

	/* suppress any possible trailing nulls */
	nump=nums;
	while(*nump == '0' || *nump == ' ') nump++;

	/* print real number */
	if(isFloat){
		/* exception to rule 3: print real number as-is if it fits */
		if (num <= 0.1 && strlen(nump) < 8) return emitNUM(minus,nump);

		/* rule 3: print real with exponent */
		else if (num < 0.1) {
			sprintf(nums,"%.5E",num);
			doExp(nums,&base,&exp);
			if (exp<0) sprintf(nums,"%.5f E%d",base,exp);
			else sprintf(nums,"%.5f E %d",base,exp);
			return emitNUM(minus,nums);
		}
		/* rule 2: print real with 6 significant digits 
		 * retaining decimal dot (use of #)*/ 
		else {
			sprintf(nums,"%#.6G",num);
			nump=strstr(nums,"E");
			/* clean ending trailing zeroes if number is
			 * not in exponential form */
			if (!nump) {
				nump=nums+strlen(nums)-1;
				while (*nump=='0') *nump--='\0';
			}
			/* clean number if in exponential form */
			else {
				doExp(nums,&base,&exp);
				if (exp<0) sprintf(nums,"%.5f E%d",base,exp);
				else sprintf(nums,"%.5f E %d",base,exp);
			}
			/* skip leading trailing zero, e.g. 0.nnn -> .nnn */
			nump=nums;
			if(*nump=='0') nump++;
			return emitNUM(minus,nump);
		}
	}
	/* print integer number */
	else {
		/* rule 1 part 2: print integer till 9 significant digits */
		if (strlen(nump) < 10) return emitNUM(minus,nump);

		/* rule 1 part 2 (reverse case): print integer with exponent
		 * and 6 significant digits (that is, 5 decimals) */
		else { 
			sprintf(nums,"%.5E",num);
			nump=strstr(nums,"E");
			if (nump) {
				doExp(nums,&base,&exp);
				if (exp <0) sprintf(nums,"%.5f E%d",base,exp);
				else sprintf(nums,"%.5f E %d",base,exp);
			}
			return emitNUM(minus,nums);
		}
	}

	/* avoiding warnings.... */
	return 0;
}


/* printSTR
 * emit a string returning the updated counter
 * - str is the string to be printed  */
int printSTR(char *str) {
	int ret=strlen(str);
	if (counter+ret>COMPSCR) CR();
	strcat(GLOB,str);
	return counter+ret;
}


/* PRINT
 * The Dartmouth printing routine for ALGOL
 * directly from BASIC */
void PRINT(void) {
	double val=0.0;
	char BASEOUT[COMPSCR+1];
	static int isTab=TRUE;
	static int isNewLine=TRUE;
	GLOB[0]='\0';
	while (*p && *p!=')') {
		/* commas at the start (or multiple) move to the next zone */
		if (*p==',') {
			p++;
			AC();
			AC();
			while (counter%ZONE) AC();
			continue;
		}
		/* suppress new line */
		if (*p=='\"' && *(p+1)=='\"' && *(p+2)!=',') {
			isNewLine=FALSE;
			p+=2;
			break;
		}
		/* suppress tab (comma tab) */
		else if (*p=='\"' && *(p+1)=='\"') {
			isTab=FALSE;
			p+=2;
		}
		/* print any string */
		else if (isanystring(p)) {
			if (isTab) while (counter%ZONE) AC();
			strncpy_(BASEOUT,SS(),COMPSCR+1);
			counter=printSTR(BASEOUT);
			isTab=TRUE;
		}
		/* print math expression */
		else {
			if (isTab) while (counter%ZONE) AC();
			val=S();
			counter=printNUM(val);
			isTab=TRUE;
		}
		while (isblank(*p)) p++;
		if (*p==',') p++;
		while (isblank(*p)) p++;
		if (*p==';') pe(2,l);
	}
	if (*p==')') p++;
	else {
		printf("\n");
		pe(1,l); // E01
	}
	/* print line, and New Line if not suppressed*/
	printf("%s",GLOB);
	if (isNewLine) CR();
	isNewLine=TRUE;
	fflush(stdout);
}


/* WRITE
 * The apochryfal Dartmouth printing routine for ALGOL
 * for files directly from BASIC */
void WRITE(void) {
	int ns=0;
	double val=0.0;
	char BASEOUT[COMPSTR];
	static int isTab=TRUE;
	static int isNewLine=TRUE;
	GLOB[0]='\0';
	/* check for variable */
	ns=findDEC(p);
	if (vn[ns].type==INFILETYPEBOX) pe(43,l); // E43
	else if (vn[ns].type!=OUTFILETYPEBOX) pe(11,l); // E11
	else if (vn[ns].isopen==FALSE) pe(41,l); // E41
	p+=_len;
	if (*p==',') p++;
	while (*p && *p!=')') {
		/* commas at the start (or multiple) move to the next zone */
		if (*p==',') {
			p++;
			AC();
			AC();
			while (counter%ZONE) AC();
			continue;
		}
		/* suppress new line */
		if (*p=='\"' && *(p+1)=='\"' && *(p+2)!=',') {
			isNewLine=FALSE;
			p+=2;
			break;
		}
		/* suppress tab (comma tab) */
		else if (*p=='\"' && *(p+1)=='\"') {
			isTab=FALSE;
			p+=2;
		}
		/* print any string */
		else if (isanystring(p)) {
			if (isTab) while (counter%ZONE) AC();
			strncpy_(BASEOUT,SS(),COMPSTR);
			counter=printSTR(BASEOUT);
			isTab=TRUE;
		}
		/* print math expression */
		else {
			if (isTab) while (counter%ZONE) AC();
			val=S();
			counter=printNUM(val);
			isTab=TRUE;
		}
		while (isblank(*p)) p++;
		if (*p==',') p++;
		while (isblank(*p)) p++;
		if (*p==';') pe(2,l);
	}
	if (*p==')') p++;
	else {
		fprintf(vn[ns].stream,"\n");
		pe(1,l); // E01
	}
	/* print line, and New Line if not suppressed*/
	fprintf(vn[ns].stream,"%s",GLOB);
	if (isNewLine) FCR(vn[ns].stream);
	isNewLine=TRUE;
	fflush(vn[ns].stream);
}


/* WRITEDATA
 * The apochryfal Dartmouth printing routine for ALGOL
 * for files that must re-read with READATA  */
void WRITEDATA(void) {
	int ns=0;
	double val=0.0;
	char BASEOUT[COMPSTR];
	/* check for variable */
	ns=findDEC(p);
	if (vn[ns].type==INFILETYPEBOX) pe(43,l); // E43
	else if (vn[ns].type!=OUTFILETYPEBOX) pe(11,l); // E11
	else if (vn[ns].isopen==FALSE) pe(41,l); // E41
	p+=_len;
	if (*p==',') p++;
	while (*p && *p!=')') {
		while (isblank(*p)) p++;
		/* print any string */
		if (isanystring(p)) {
			strncpy_(BASEOUT,SS(),COMPSTR);
			fprintf(vn[ns].stream," \"%s\" ", BASEOUT);
		}
		/* print math expression */
		else {
			val=S();
			fprintf(vn[ns].stream," %.17G ", val);
		}
		while (isblank(*p)) p++;
		if (*p==',') p++;
		while (isblank(*p)) p++;
		if (*p==';') pe(2,l);
	}
	if (*p==')') p++;
	else pe(1,l); // E01
	/* print a Carriage Return at each WRITEDATA*/
	FCR(vn[ns].stream);
	fflush(vn[ns].stream);
}


/* readFile() 
 * the workhorse for READATA in case of reading from file 
 * Used in READATA() */
void readFile(int ns) {
	int nt, udim=1, narr;
	int ttype;
	int val[MAXDIM+1];
	/* load next line */
	if (jp==linebuffer) {
		if (feof(vn[ns].stream)) pe(44,l); // E44
		fgets(linebuffer,COMPSTR,vn[ns].stream);
	}
	/* parse objects */
	while (*p && *p!=')') {
		double nop;
		char str[COMPSTR], *s=str;
		int isNum=0;
		/* get values */
		isNum=TRUE;
		while (isblank(*jp)) jp++;
		/* load next line */
		if (!*jp) {
			if (feof(vn[ns].stream)) pe(44,l); // E44
			fgets(linebuffer,COMPSTR,vn[ns].stream);
		}
		if (*jp=='\"') {
			jp++;
			while (*jp && *jp!='\"') *s++=*jp++;
			*s='\0';
			if (*jp=='\"') jp++;
			isNum=FALSE;
		}
		else {
			while (*jp && *jp!=' ') *s++=*jp++;
			*s='\0';
			nop=strtod(str,NULL);
		}
		/* check destination */
		nt=findDEC(p);
		narr=_arr;
		if (!nt) pe(11,l); // E11
		p+=_len;
		ttype=vn[nt].type;
		/* get array indices */
		if (_arr && *p=='[') {
			udim=1;
			p++; // skip [
			val[udim]=(int)S();
			while (*p==',' && udim<MAXDIM) {
				p++;
				udim++;
				val[udim]=(int)S();
			}
			if (udim>=MAXDIM) pe(26,l); // E26
			if (*p==']') p++;
			else pe(1,l); // E01
		}
		_arr=narr;
		/* real variables */
		if (ttype==REALTYPEBOX && !_arr) {
			if (!isNum) pe(11,l); // E11
			P[vn[nt].ref]=nop;
		}
		/* real arrays */
		else if (ttype==REALTYPEBOX && _arr) {
			if (!isNum) pe(11,l); // E11
			setArrayVal(vn[nt].ref,udim,val,nop);
		}
		/* Boolean variables */
		else if (ttype==BOOLEANTYPEBOX && !_arr) {
			if (!isNum) pe(11,l); // E11
			P[vn[nt].ref]=((int)nop!=0);
		}
		/* Boolean arrays */
		else if (ttype==BOOLEANTYPEBOX && _arr) {
			if (!isNum) pe(11,l); // E11
			setArrayVal(vn[nt].ref,udim,val,((int)nop!=0));
		}
		/* integer variables */
		else if (ttype==INTEGERTYPEBOX && !_arr) {
			if (!isNum) pe(11,l); // E11
			P[vn[nt].ref]=(int)(nop+sign(nop)*0.5);
		}
		/* integer arrays */
		else if (ttype==INTEGERTYPEBOX && _arr) {
			if (!isNum) pe(11,l); // E11
			setArrayVal(vn[nt].ref,udim,val,(int)(nop+sign(nop)*0.5));
		}
		/* string variables */
		else if (ttype==STRINGTYPEBOX && !_arr) {
			if (isNum) pe(11,l); // E11
			strncpy_(PS[vn[nt].ref],str,COMPSTR);
		}
		/* string arrays */
		else if (ttype==STRINGTYPEBOX && _arr) {
			if (isNum) pe(11,l); // E11
			setArrayStr(vn[nt].ref,udim,val,str);
		}
		/* no other types are allowed here */
		else pe(11,l); // E11
		if (*p==',') p++;
	}
	if (*p==')') p++;
	else pe(1,l); // E01
}


/* READATA()
 * the Dartmouth READATA() for DATA lists or INFILE files */
void READATA(void) {
	int ns, nt, udim=1, narr;
	int ttype, keyb=FALSE;
	int val[MAXDIM+1];
	char *backp=NULL;
	char inputs[COMPSCR+1];
	/* input is from a DATA or INFILE object */
	if ((ns=findDEC(p)) && !_arr) {
		if (vn[ns].type==DATATYPEBOX) p+=_len;
		else if (vn[ns].type==OUTFILETYPEBOX) pe(43,l); // E43
		else if (vn[ns].type==INFILETYPEBOX && vn[ns].isopen) {
			p+=_len;
			if (*p==',') p++;
			readFile(ns);
			return;
		}
		else if (vn[ns].type==INFILETYPEBOX) pe(41,l); // E41
		else pe(11,l); // E11
	}
	/* input is from keyboard */
	else if (!strncmp(p,"TELETYPE",8) || !strncmp(p,"KEYBOARD",8)) {
		p+=8;
		strncpy_(inputs,getString(CONSOLE),COMPSCR);	
		backp=inputs;
		keyb=TRUE;
	}
	else pe(11,l); // E11
	if (*p==',') p++;
	while (*p && *p!=')') {
		double nop;
		if (vn[ns].dataCurr>vn[ns].dataEnd) pe(17,l); // E17
		nt=findDEC(p);
		narr=_arr;
		if (!nt) pe(11,l); // E11
		p+=_len;
		ttype=vn[nt].type;
		if (keyb) {
			char *pb=p;
			if (*backp) {
				p=backp;
				nop=S();
				while (isblank(*p)) p++;
				if (*p==',') p++;
				else if (*p) pe(2,l); // E02
				backp=p;
				p=pb;
			}
			else nop=0.0;
		}
		else nop=vn[ns].dataArray[vn[ns].dataCurr++];
		/* get array indices */
		if (_arr && *p=='[') {
			udim=1;
			p++; // skip [
			val[udim]=(int)S();
			while (*p==',' && udim<MAXDIM) {
				p++;
				udim++;
				val[udim]=(int)S();
			}
			if (udim>=MAXDIM) pe(26,l); // E26
			if (*p==']') p++;
			else pe(1,l); // E01
		}
		_arr=narr;
		/* real variables */
		if (ttype==REALTYPEBOX && !_arr) {
			P[vn[nt].ref]=nop;
		}
		/* real arrays */
		else if (ttype==REALTYPEBOX && _arr) {
			setArrayVal(vn[nt].ref,udim,val,nop);
		}
		/* Boolean variables */
		else if (ttype==BOOLEANTYPEBOX && !_arr) {
			P[vn[nt].ref]=((int)nop!=0);
		}
		/* Boolean arrays */
		else if (ttype==BOOLEANTYPEBOX && _arr) {
			setArrayVal(vn[nt].ref,udim,val,((int)nop!=0));
		}
		/* integer variables */
		else if (ttype==INTEGERTYPEBOX && !_arr) {
			P[vn[nt].ref]=(int)(nop+sign(nop)*0.5);
		}
		/* integer arrays */
		else if (ttype==INTEGERTYPEBOX && _arr) {
			setArrayVal(vn[nt].ref,udim,val,(int)(nop+sign(nop)*0.5));
		}
		/* no other types are allowed here */
		else pe(11,l); // E11
		if (*p==',') p++;
	}
	if (*p==')') p++;
	else pe(1,l); // E01
}


// RESTORE()
void RESTORE(void) {
	int ns;
	if ((ns=findDEC(p)) && !_arr) 
		if (vn[ns].type!=DATATYPEBOX) pe(16,l); // E16
	p+=_len;
	vn[ns].dataCurr=vn[ns].dataStart;
	if (*p==')') p++;
	else pe(1,l); // E01
}


/* CLOSE() */
void CLOSE(void) {
	int ns=0;
	/* check for variable */
	ns=findDEC(p);
	if (vn[ns].type!=INFILETYPEBOX && vn[ns].type!=OUTFILETYPEBOX) pe(11,l); // E11
	fclose(vn[ns].stream);
	vn[ns].stream=NULL;
	vn[ns].isopen=FALSE;
	p+=_len;
	linebuffer[0]='\0';
	jp=linebuffer;
	if (*p==')') p++;
	else pe(1,l); // E01
}


/***************************************************************************
 * SWITCH procedure
 ***************************************************************************/

/* getLabelIndex()
 * Analyze the string in current position, detecting if a label is there;
 * a label may be:
 * - a literal label: it's passed through setAddr()
 * - a label variable: its count is passed
 * - a switch: the index is read, the string is passed through setAddr()
 * In case of error, return 0 (not found) or a negative error code.
 * Otherwise, return label code
 * System function for GOTO()/assign() */
int getLabelIndex(void) {
	int ns=0;
	int res=0;
	int type;
	/* designational expression: literal label which begins with IF */
	if (!strncasecmp_(p,"IF",2)) {
		int cond=FALSE;
		p+=2;
		if (!check(p,"THEN")) return -2;
		cond=(int)S();
		if (*p==' ') *p='T';
		p+=4;
		if (!strncasecmp_(p,"IF",2)) return -22;
		if (!check(p,"ELSE")) return -2;
		if (cond) res=getLabelIndex();
		else {
			p=strcasestr_oq(p," LSE"); // advance till next ELSE
			if (*p==' ') *p='E';
			p+=4;
			res=getLabelIndex();
		}
	}
	/* label or string procedure */
	else if ((ns=findPROC(p,NULL,&type))) {
		double numres;
		char labelText[COMPSTR];
		if (type<STRINGTYPEBOX) return -11;
		p+=_len;
		execPROC(ns,p,&numres,labelText);
		res=numres;
	}
	/* label variable */
	else if ((ns=findDEC(p)) && !_arr) {
		if (_type==LABELTYPEBOX) {
			ns=vn[ns].ref;
			p+=_len;
			res=P[ns];
		}
		/* other variable */
		else res=-11;
	}
	/* switch item */
	else if ((ns=findDEC(p)) && _arr) {
		int val[2];
		char labelText[COMPSTR], *pb;
	       	if (_type==LABELTYPEBOX) {
			int ind=0;
			p+=_len;
			if (*p=='[') p++;
			ind=S();
			if (*p==']') p++;
			pb=p;
			val[0]=0;val[1]=ind;
			strncpy_(labelText,getArrayStr(ns,1,val),COMPSTR);
			p=labelText;
			res=getLabelIndex();
			p=pb;
		}
		else res=-11;
	}
	/* case of a literal with ELSE inside; check that is an effective
	 * label name and not a case such THEN GOTO <label> ELSE GOTO ...*/
	else if (strcasestr_oq(p,"ELSE")) {
		int code=0, count=0;
		char labelText[COMPSTR], *k=labelText;
		while (isnamechar(p)) *k++=*p++;
		*k='\0';
		code=setAddr(labelText,&k);
		while (*p && *p!=';' && strncasecmp_(p,"END",3)) p++;
		/* if found label, return its count */
		for(count=1;count<=labelTOS;count++) {
			if (label[count].code==code) {
				res=count;
			}
		}
		/* label not found: it's an ELSE case */
		if (!res) {
			char *pp;
			pp=strcasestr_(labelText,"ELSE");
			*pp='\0';
			code=setAddr(labelText,&k);
			while (*p && *p!=';' && strncasecmp_(p,"END",3)) p++;
			/* if found label, return its count */
			for(count=1;count<=labelTOS;count++) {
				if (label[count].code==code) {
					res=count;
				}
			}
			if (!res) res=-11;
		}
	}
	/* literal label which does not begin with IF */
	else {
		int code=0, count=0;
		char labelText[COMPSTR], *k=labelText;
		while (isnamechar(p)) *k++=*p++;
		*k='\0';
		code=setAddr(labelText,&k);
		while (*p && *p!=';' && strncasecmp_(p,"END",3)) {
			if (*p=='.') p++;
			p++;
		}
		/* if found label, return its count */
		for(count=1;count<=labelTOS;count++) {
			if (label[count].code==code) {
				res=count;
			}
		}
		/* label not found */
		if (!res) res=-11;
	}
	return res;
}


/* findInstance()
 * find if an instance of a variable/array name was already declared elsewhere.
 * Used in findDEC, array, SWITCH() 
 * return the variable index if found, zero otherwise */
int findInstance(char *name) {
	int i=0;
	while (i<=decCount) {
		if (!strcmp(vn[i].name,name)) {
			if (vn[i].beginlevel!=beginTOS) return 0;
			else if (pexecTOS==vn[i].level) return i;
		}
		i++;
	}
	return 0;
}


/* findLabelInstance()
 * find if an instance of a literal label name was already declared elsewhere.
 * Used in declare 
 * return the label index if found, zero otherwise */
int findLabelInstance(char *name) {
	int i=0, a=0;
	char s1[NAMEDIM], *s=s1; // dummy
	while (i<=labelTOS) {
		a=setAddr(name,&s);
		if (a==label[i].code) return i;
		i++;
	}
	return 0;
}


/* SWITCH()
 * reads the label in the stream queue, solve their address and store the
 * reference in an 1-dim array of strings, created with the given name. */
void SWITCH(void) {
	char decname[NAMEDIM], *sp=decname;
	int end=0, i=0,td, another=0;
	char temp[16][NAMEDIM];
	int val[2];

	/* get switch name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p) && i<NAMEDIM) {
			if (*p=='.') {
				p++;
				continue;
			}
			*sp++=*p++;
			i++;
		}
		*sp='\0';
	}
	else pe(8,l); // E08
	/* check for too long identifiers */
	if (i>=NAMEDIM && isnamechar(p-1)) pe(3,l); // E03
	
	/* found if there is another instance */
	another=findInstance(decname);
	if (another) {
		pe(4,l); // E04
		return;
	}

	/* name must be read all */
	if (*p!=PU) pe(8,l); // E08
	else p++;
	
	/* get and store elements, updating 'end' (which counts items) */
	while (*p!=';') {
		char labelText[NAMEDIM+1], *k=labelText;
		if (isbeginnamechar(p)) {
			end++;
			/* store IF-THEN-ELSE clause */
			if (!strncasecmp_(p,"IF",2)) {
				while (strncasecmp_(p,"ELSE",2)) *k++=*p++;
		       		while (isnamechar(p) || *p=='[' || *p==']')
					*k++=*p++;
			}
			/* store label, label var or switch item */
			else while (isnamechar(p) || *p=='[' || *p==']') 
				*k++=*p++;
			*k='\0';
			strncpy_(temp[end],labelText,NAMEDIM+1);
			if (*p==',') p++;
		}
	}


	/* declare label var */
	decCount++;
	if (decCount>=LIMIT) pe(26,l); // E26
	td=decCount;
	vn[td].type=LABELTYPEBOX;
	vn[td].dim=1;
	vn[td].ref=decCount;
	vn[td].refcode=decCount;
	vn[td].proccode=0;
	vn[td].isArr=TRUE;
	vn[td].isFunc=FALSE;
	vn[td].isFict=FALSE;
	vn[td].ldim[1]=end-1;
	vn[td].offset[1]=1;
	vn[td].coeff[1]=1;
	vn[td].isOwn=FALSE;
	vn[td].strmem=COMPSTR;
	vn[td].line=l;
	vn[td].level=pexecTOS;
	for (i=0;i<COMPSTR;i++) vn[td].valdata[i]=vn[td].strdata[i]='\0';
	vn[td].size=dimStrArray(td,1,vn[td].ldim);
	
	/* set name/type */
	strncpy_(vn[td].name,decname,NAMEDIM);

	/* copy back stored temporary values */
	for (i=1;i<=end;i++) {
		val[0]=0; val[1]=i;
		setArrayStr(td,1,val,temp[i]);
	}
}


/***************************************************************************
 * FOR-DO and WHILE-DO procedures, plus BREAK and CONTINUE
 ***************************************************************************/

void reload(void) {
	/* reload */
	if (!*p) {
		l++;
		while (!m[l]) l++;
		strncpy_(BASESTR,m[l],COMPSCR);
		p=BASESTR;
	}
}


/* WHILE()
 * Perform the WHILE-DO procedure; */
void WHILE(void) {
	char *k, *pb;
	int locTOS=1, cond;
	
	/* upgrade counter */
	whileExecTOS++;
	
	reload();
	while (Whilep[locTOS].varpL!=l||Whilep[locTOS].varpP!=(int)(p-BASESTR)){
		locTOS++;
		if (locTOS>whileTOS) pe(26,l); // E26
	}
	
	reload();
	k=Whilep[locTOS].cond;
	reload();
	check(p,"DO");
	pb=p;
	while(*p && *p!=' ') *k++=*p++;
	*k='\0';
	p=Whilep[locTOS].cond;
	cond=(int)S();
	sysRet;
	while (cond) {
		/* execute current type 1 */
		strncpy_(BASESTR,m[Whilep[locTOS].doexL],COMPSCR);
		p=BASESTR+Whilep[locTOS].doexP;
		l=Whilep[locTOS].doexL;
		go(l);
		sysRet;
		p=Whilep[locTOS].cond;
		cond=S();
		sysRet;
	}
	l=Whilep[locTOS].termL;
	p=m[l]+Whilep[locTOS].termP;
	
	/* upgrade counter */
	if (whileExecTOS>0) whileExecTOS--;
	*pb='D';
}


/* kcopy() */
void kcopy(char *t) {
	while (*p && *p!=',' && *p!=' ') {
		if (*p=='(') {
			int st=0;
			*t++=*p++; // copy (
			while (*p) {
				if (*p=='(') st++;
				else if (*p==')' && st) st--;
				else if (*p==')' && !st) break;
				*t++=*p++;
			}
		}
		else if (*p=='[') {
			int st=0;
			*t++=*p++; // copy [
			while (*p) {
				if (*p=='[') st++;
				else if (*p==']' && st) st--;
				else if (*p==']' && !st) break;
				*t++=*p++;
			}
		}
		*t++=*p++;
	}
	*t='\0';	
}


/* FOR()
 * Perform the FOR-DO procedure; */
void FOR(void) {
	TForItem foritem[LIMIT];
	int fi=0, ns=0, i; // type = 1,2,3
	double step,end;
	double prev;
	int locTOS=1;

	for (i=0;i<LIMIT;i++) {
		foritem[i].epos[0]='\0';
		foritem[i].val[0]='\0';
		foritem[i].cond[0]='\0';
		foritem[i].step[0]='\0';
	}

	/* search for related FOR cycle */
	reload();
	while (locTOS<=forTOS) {
		if (Forp[locTOS].varpL==l &&\
				(int)(p-BASESTR)==Forp[locTOS].varpP) break;
		locTOS++;
       		if (locTOS>forTOS) pe(37,l); // E37
	}		

	/* upgrade counter */
	forExecTOS++;

	reload();
	ns=findDEC(p);
	if (!ns) pe(11,l); // E11
	/* get to the original referenced item */
	while (ns!=vn[ns].ref) ns=vn[ns].ref;
	p+=_len;
	if (vn[ns].type>INTEGERTYPEBOX) pe(11,l); // E11
	if (vn[ns].isArr) pe(11,l); // E11
	reload();
	if (*p==PU) p++;
	else pe(37,l); // E37


	/* gather FOR indices */
	do {
		if (!strncasecmp_(p," O",2) || !strncasecmp_(p,"DO",2)) {
			*p='D';
			p+=2;
			break;
		}
		fi++;
		if (fi>64) pe(26,l); // E26
		reload();
		check(p,"STEP");
		check(p,"WHILE");
		check(p,"UNTIL");
		check(p,"DO");
		kcopy(foritem[fi].val);
		reload();
		check(p,"STEP");
		check(p,"WHILE");
		check(p,"UNTIL");
		check(p,"DO");
		/* type 1: FOR list (Ref 8.1 point 1) */
		if (*p==',' || !strncasecmp_(p," O",2) ||\
			       !strncasecmp_(p,"DO",2)) {
			foritem[fi].type=1;
			if (*p==',') p++;
		}
		/* type 2 shortened: FOR UNTIL (Ref 8.1, Note) */
		else if (!strncasecmp_(p," NTIL",5)) {
			foritem[fi].type=2;
			strncpy_(foritem[fi].step,"1",COMPSTR);
			*p='U';
			p+=5; // skip UNTIL
			reload();
			check(p,"DO");
			kcopy(foritem[fi].cond);
			if (*p==',') p++;
		}
		/* type 2: FOR STEP UNTIL (Ref 8.1 point 2) */
		else if (!strncasecmp_(p," TEP",4)) {
			foritem[fi].type=2;
			*p='S'; // skip STEP
			p+=4;
			reload();
			check(p,"UNTIL");
			kcopy(foritem[fi].step);
			reload();
			check(p,"UNTIL");
			if (!strncasecmp_(p," NTIL",5)) {
				*p='U';
				p+=5; // skip UNTIL
				reload();
				check(p,"DO");
				kcopy(foritem[fi].cond);
			}
			if (*p==',') p++;
		}
		/* type 3: FOR WHILE (Ref 8.1 point 3) */
		else if (!strncasecmp_(p," HILE",5)) {
			*p='W';
			p+=5; // skip WHILE
			foritem[fi].type=3;
			strncpy_(foritem[fi].epos,foritem[fi].val,COMPSTR);
			reload();
			check(p,"DO");
			kcopy(foritem[fi].cond);
			if (*p==',') p++;
		}
		
	} while (*p && strncasecmp_(p,"DO",2));
	
	i=1;
	/* perform the FOR procedure */
	while (i<=fi) {
		/* execute current type 2: STEP UNTIL */
		if (foritem[i].type==2) {
			p=foritem[i].val;
			P[ns]=S();
			sysRet;
			p=foritem[i].cond;
			end=S();
			sysRet;
			p=foritem[i].step;
			step=S();
			sysRet;
			if (!step) step=1;
			if (step>0) while (P[ns]<=end) {
				prev=P[ns];
				/* execute current type 1 - positive step */
				strncpy_(BASESTR,m[Forp[locTOS].doexL],COMPSCR);
				p=BASESTR+Forp[locTOS].doexP;
				l=Forp[locTOS].doexL;
				go(l);
				sysRet;
				p=foritem[i].step;
				step=S();
				sysRet;
				P[ns]+=step;
				p=foritem[i].cond;
				end=S();
				sysRet;
			}
			else while (P[ns]>=end) {
				prev=P[ns];
				/* execute current type 1 - negative step */
				strncpy_(BASESTR,m[Forp[locTOS].doexL],COMPSCR);
				p=BASESTR+Forp[locTOS].doexP;
				l=Forp[locTOS].doexL;
				go(l);
				sysRet;
				p=foritem[i].step;
				step=S();
				sysRet;
				P[ns]+=step;
				p=foritem[i].cond;
				end=S();
				sysRet;
			}
			P[ns]=prev;
			sysRet;
		}
		/* execute current type 3: WHILE */
		else if (foritem[i].type==3) {
			int cond;
			p=foritem[i].epos;
			P[ns]=S();
			sysRet;
			p=foritem[i].cond;
			cond=(int)S();
			sysRet;
			while (cond) {
				prev=P[ns];
				/* execute current type 1 */
				strncpy_(BASESTR,m[Forp[locTOS].doexL],COMPSCR);
				p=BASESTR+Forp[locTOS].doexP;
				l=Forp[locTOS].doexL;
				go(l);
				sysRet;
				p=foritem[i].epos;
				P[ns]=S();
				p=foritem[i].cond;
				cond=S();
				sysRet;
			}
			P[ns]=prev;
			sysRet;
		}
		/* execute current type 1: LIST */
		else if (foritem[i].type==1) {
			p=foritem[i].val;
			P[ns]=S();
			sysRet;
			strncpy_(BASESTR,m[Forp[locTOS].doexL],COMPSCR);
			p=BASESTR+Forp[locTOS].doexP;
			l=Forp[locTOS].doexL;
			go(l);
			sysRet;
			prev=P[ns];
		}
		i++;
	}
	strncpy_(BASESTR,m[Forp[locTOS].termL],COMPSCR);
	p=BASESTR+Forp[locTOS].termP;
	l=Forp[locTOS].termL;
	/* upgrade counter */
	if (forExecTOS>0) forExecTOS--;
}


/***************************************************************************
 * GOTO and IF-THEN-ELSE procedure
 ***************************************************************************/

/* ELSE()
 * This is a dummy function that prints an error message in case ELSE is
 * invoked out of an IF structure 
 * System function for exec() */
void ELSE(void) {
	pe(8,l); // E08
}


/* GOTO()
 * Perform the GOTO unconditional procedure by setting two global references
 * (LL and PL) which will alert doBegin() in order to set the new address. */
void GOTO(void) {
	int count=0;

	if (!*p) {
		l++;
		while (!m[l]) l++;
		if (l>endCore) pe(28,l); // E28
		strncpy_(BASESTR,m[l],COMPSCR);
		p=BASESTR;
	}
	
	/* get label index and set GOTO position */
	count=getLabelIndex();
	if (count>0) {
		int i;
		LL=label[count].ll;
		PL=label[count].pl;
		/* discard all BEGIN/IF/FOR/WHILE references of the cycles
		 * that we are leaving, by searching the right position */
		/* search for IF */
		for (i=ifExecTOS;i>0;i--) {
			if (Ifp[i].condL>LL || Ifp[i].termL<LL) { 
				if (ifExecTOS>0) ifExecTOS--;
			}
			else if (Ifp[i].condL==LL) {
				if (Ifp[i].condP>PL) {
					if (ifExecTOS>0) ifExecTOS--;
				}
			}
			else if (Ifp[i].termL==LL) {
				if (Ifp[i].termP<PL) {
					if (ifExecTOS>0) ifExecTOS--;
				}
			}
			else break;
		}
		/* search for FOR */
		for (i=forExecTOS;i>0;i--) {
			if (Forp[i].varpL>LL || Forp[i].termL<LL) {
				if (forExecTOS>0) forExecTOS--;
			}
			else if (Forp[i].varpL==LL) {
				if (Forp[i].varpP>PL) {
					if (forExecTOS>0) forExecTOS--;
				}
			}
			else if (Forp[i].termL==LL) {
				if (Forp[i].termP<PL) {
					if (forExecTOS>0) forExecTOS--;
				}
			}
			else break;
		}
		/* search for WHILE */
		for (i=whileExecTOS;i>0;i--) {
			if (Whilep[i].varpL>LL || Whilep[i].termL<LL) {
				if (whileExecTOS>0) whileExecTOS--;
			}
			else if (Whilep[i].varpL==LL) {
				if (Whilep[i].varpP>PL) {
					if (whileExecTOS>0) whileExecTOS--;
				}
			}
			else if (Whilep[i].termL==LL) {
				if (Whilep[i].termP<PL) {
					if (whileExecTOS>0) whileExecTOS--;
				}
			}
			else break;
		}
		/* search for BEGIN */
		for (i=beginTOS;i>0;i--) {
			if (Beginp[i].varpL>LL || Beginp[i].termL<LL) {
				if (beginTOS>0) beginTOS--;
			}
			else if (Beginp[i].varpL==LL) {
				if (Beginp[i].varpP>PL) {
					if (beginTOS>0) beginTOS--;
				}
			}
			else if (Beginp[i].termL==LL) {
				if (Beginp[i].termP<PL) {
					if (beginTOS>0) beginTOS--;
				}
			}
			else break;
		}
		if (isDebug) {
			fprintf(stdout,"%s",INVCOLOR);
			fprintf(stdout,"Jumping to line=%d, pos=%d\n",LL,PL);
			fprintf(stdout,"%s",RESETCOLOR);
		}
	}
	else if (count<=0) pe(28,l); // E28
	/* if LL is empty, no label was found */
	if (!LL) pe(28,l); // E28
}


/* IF()
 * Perform the IF-THEN-ELSE conditional statement. */
void IF(void) {
	char *k=p;
	int cond, locTOS=0;

	/* upgrade counter */
	ifExecTOS++;

	/* reload */
	if (!*p) {
		l++;
		while (!m[l]) l++;
		strncpy_(BASESTR,m[l],COMPSCR);
		p=BASESTR;
	}
		
	/* search the IF clause in this place */
	while (Ifp[locTOS].condL!=l || strcmp(m[l]+Ifp[locTOS].condP,p)){
		locTOS++;
		if (locTOS>ifTOS) pe(26,l); // E26
	}

	/* calculate condition*/
	check(p,"THEN");
	/* Note: strRel() (for string comparisons) is calculated in S() */
	cond=(int)S();
	if (resultType!=BOOLEANTYPEBOX) pe(29,l);
	sysRet;
	*p='T';
	if (*p==')') p++;

	/* in case the evaluated condition is true, execute the THEN part */
	if (cond) {
		strncpy_(BASESTR,m[Ifp[locTOS].thenL],COMPSCR);
		p=BASESTR+Ifp[locTOS].thenP;
		/* ELSE is on the same line, prepare for string evaluation */
		if (Ifp[locTOS].elseL==l) {
			k=BASESTR+Ifp[locTOS].elseP-4; // regain ELSE
			*k=' ';
		}
		if (!strncasecmp_(p,"IF",2)) pe(8,l); // E08
		if (!strncasecmp_(p,"FOR",3)) pe(8,l); // E08
		if (!strncasecmp_(p,"WHILE",5)) pe(8,l); // E08
		l=Ifp[locTOS].thenL;
		go(l);
		sysRet;
	}
	/* in case the evaluated condition is false and there is an ELSE clause,
	 * execute the ELSE part */
	else if (Ifp[locTOS].elseL>0) {
		strncpy_(BASESTR,m[Ifp[locTOS].elseL],COMPSCR);
		p=BASESTR+Ifp[locTOS].elseP;
		if (!strncasecmp_(p,"FOR",3)) pe(8,l); // E08
		if (!strncasecmp_(p,"WHILE",5)) pe(8,l); // E08
		l=Ifp[locTOS].elseL;
		go(l);
		sysRet;
	}
	/* at the end jump to the IF terminator */
	l=Ifp[locTOS].termL;
	strncpy_(BASESTR,m[l],COMPSCR);
	p=BASESTR+Ifp[locTOS].termP;
	
	/* upgrade counter */
	if (ifExecTOS>0) ifExecTOS--;
}
	

/***************************************************************************
 * READ procedure
 ***************************************************************************/

/* isEOF()
 * return TRUE if current file has passed the last character/item, or FALSE.
 * Note: it does NOT control if stream is open.
 * ch: the testing channel id 
 * System function for the file management */
int isEOF(int ch) {
	int res=FALSE, i=0;
	/* test for file open of file set for output */
	if (channel[ch].wayout!=VREAD) return res;
	if (!channel[ch].isopen) return res;
	/* test for channel range */
	if (ch<2) return res;
	else if (ch>STREAMS) return res;
	else {
		i=fgetc(channel[ch].stream);
		if (i<0 /*&& !*rb*/) res=TRUE, channel[ch].iochan+=0100;
		ungetc(i,channel[ch].stream);
	}
	return res;
}


/* getString()
 * ch: channel input number; if null, get string from keyboard
 * System function for the READ procedure */
char *getString(int ch) {
	char *lp=line;
	int i;

	/* get string */
	for (i=0; i<COMPSCR; i++) line[i]='\0';
	while (TRUE) {
		if (!ch || channel[ch].iochan & 0100000) *lp=getchar();
		else {
			if (!channel[ch].isopen) pe(53,l); // move to 53
			if (!(channel[ch].wayout & VREAD)) 
				pe(25,l); // E25
			*lp=fgetc(channel[ch].stream);
		}
		if (*lp==10 || *lp==13 || *lp==CRC) {
			*lp='\0';
			break;
		}
		else lp++;
	}

	/* force reading blanks */
	if (ch) {
		i=fgetc(channel[ch].stream);
		while (i>=0 && (i=='\0' || i=='\n' || i=='\t' || i==' ')) {
			if (isEOF(ch)) break;
			i=fgetc(channel[ch].stream);
		}
		ungetc(i, channel[ch].stream);
	}

	/* return string */
	return lp=line;
}


/****************************************************************************
 * The following routines define system function for variable declarations
 * declare()  - declare simple variables
 * array()    - declare arrays
 ****************************************************************************/

/* declare()
 * The inner statement for any-name variables declaration
 * Note: this function is not run-time.
 * Note: this function executes a storing only; the actual command (the 
 * function interpretation and execution) is performed by findDEC(), called
 * into getFunc() and SS() for function names and in assign() for assignments, 
 * and in all functions dealing with variables. */
void declare(void) {
	char decname[NAMEDIM], *sp=decname;
	int i=0;
	int code=0, doOwn=FALSE, another=0;

	/* store var code (based on position in the source) */
	code=l*1000000+(int)(p-BASESTR);

	/* get var name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p) && i<NAMEDIM) {
			if (*p=='.') {
				p++;
				continue;
			}
			*sp++=*p++;
			i++;
		}
		*sp='\0';
	}
	else pe(8,l); // E08

	/* check for too long identifiers */
	if (i>=NAMEDIM && isnamechar(p-1)) pe(3,l); // E03
	
	/* check if there is another instance with the same name */
	another=findInstance(decname);
	if (another) {
		pe(4,l); // E04
		return;
	}

	/* check if there is a label instance with that name */
	another=findLabelInstance(decname);
	if (another) {
		pe(4,l); // E04
	}

	/* update counter */
	decCount++;
	if (decCount>=LIMIT) pe(26,l); // E26
	vn[decCount].type=typeBox;
	vn[decCount].ref=decCount;
	vn[decCount].refcode=decCount;
	vn[decCount].proccode=0;
	vn[decCount].isArr=FALSE;
	vn[decCount].isFunc=FALSE;
	vn[decCount].isFict=FALSE;
	vn[decCount].line=l;
	vn[decCount].level=pexecTOS;
	vn[decCount].beginlevel=beginTOS;
	vn[decCount].dim=0;
	for (i=0;i<MAXDIM;i++) {
		vn[decCount].ldim[i]=0;
		vn[decCount].offset[i]=0;
		vn[decCount].coeff[i]=0;
	}
	for (i=0;i<COMPSTR;i++) {
		vn[decCount].strdata[i]='\0';
		vn[decCount].valdata[i]='\0';
	}
	
	/* set procedure reference */
	if (!pexecTOS) vn[decCount].proccode=0;
	else vn[decCount].proccode=pexec[pexecTOS-1];

	/* decide what base to use in case of OWN variables 
	 * If a variable is found, use that value, other set for nulls */
	if (isOwn) {
		int i=1;
		while (i<=ghostCount) {
			if (own[i].code==code) {
				doOwn=i;
				break;
			}
			i++;
		}
	}

	/* OWN variables with existing ghost */
	if (isOwn && doOwn) {
		/* numeric variables */
		if (typeBox<STRINGTYPEBOX) {
			P[decCount]=own[doOwn].num;
			vn[decCount].strmem=0;
		}
		/* string variables */
		else if (typeBox==STRINGTYPEBOX || typeBox==LABELTYPEBOX) { 
			PS[decCount]=salloc(COMPSTR);
			if (!PS[decCount]) pe(9,l); // E09
			strncpy_(PS[decCount],own[doOwn].str,COMPSTR);
			vn[decCount].strmem=COMPSTR;
		}
		vn[decCount].isOwn=code;
	}
	/* OWN variables created for the first time: create ghost */
	else if (isOwn && !doOwn) {
		ghostCount++;
		own[ghostCount].code=code;
		/* numeric variables */
		if (typeBox<STRINGTYPEBOX) {
			P[decCount]=0.0;
			own[ghostCount].num=0.0;
			vn[decCount].strmem=0;
		}
		/* string variables */
		else if (typeBox==STRINGTYPEBOX || typeBox==LABELTYPEBOX) {
			int j;
			PS[decCount]=salloc(COMPSTR);
			if (!PS[decCount]) pe(9,l); // E09
			for (j=0;j<COMPSTR;j++) PS[decCount][j]='\0',
				own[ghostCount].str[j]='\0';
			vn[decCount].strmem=COMPSTR;
		}
		vn[decCount].isOwn=code;
	}
	/* preset null values for uninstantiated variables
	 * Note: not guaranteed by DEC-ALGOL 20, but it's safer */
	else {
		/* numeric variables */
		if (typeBox<STRINGTYPEBOX) {
			P[decCount]=0.0;
			vn[decCount].strmem=0;
		}
		/* string variables */
		else if (typeBox==STRINGTYPEBOX || typeBox==LABELTYPEBOX) { 
			int j;
			PS[decCount]=salloc(COMPSTR);
			if (!PS[decCount]) pe(9,l); // E09
			for (j=0;j<COMPSTR;j++) PS[decCount][0]='\0';
			vn[decCount].strmem=COMPSTR;
		}
		vn[decCount].isOwn=FALSE;
	}

	/* set name/type */
	strncpy_(vn[decCount].name,decname,NAMEDIM);
	vn[decCount].size=0;

	/* next assignment */
	if (*p==',') {
		p++;
		declare();
	}

	typeBox=0;
	// Note: no check for ; here!
}


/* array()
 * The inner statement for any-name array declaration
 * Note: this function is not run-time.
 * Note: this function executes a storing only; the actual command (the 
 * function interpretation and execution) is performed by findDEC(), called
 * into getFunc() and SS() for function names and in assign() for assignments, 
 * and in all functions dealing with variables. */
void array(void) {
	char decname[COMPSTR], *sp=decname;
	int dimq=1;
	int start[MAXDIM+1], end[MAXDIM+1];
	int i=0,td;
	int code=0, doOwn=FALSE, another=0;

	/* store var code (based on position in the source) */
	code=l*1000000+(int)(p-BASESTR);

	/* get var name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p) && i<NAMEDIM) {
			if (*p=='.') {
				p++;
				continue;
			}
			*sp++=*p++;
			i++;
		}
		*sp='\0';
	}
	else pe(8,l); // E08

	/* check for too long identifier */
	if (i>=NAMEDIM && isnamechar(p-1)) pe(3,l); // E03

	/* found if there is another instance */
	another=findInstance(decname);
	if (another) {
		pe(4,l); // E04
		return;
	}

	/* update counter */
	decCount++;
	if (decCount>=LIMIT) pe(26,l); // E26
	td=decCount;
	
	/* dimensions are specified */
	if (*p=='[') {
		p++;
		start[dimq]=(int)S();
		sysRet;
		if (*p!=':') pe(33,l); // E33
		else p++;
		end[dimq]=(int)S();
		sysRet;
		if (end[dimq]<start[dimq]) pe(32,l); // E32
		while (*p==',') {
			p++;
			dimq++;
			start[dimq]=(int)S();
			sysRet;
			if (*p!=':') pe(33,l); // E33
			else p++;
			end[dimq]=(int)S();
			sysRet;
			if (end[dimq]<start[dimq]) pe(32,l); // E32
		}
		if (*p!=']') pe(1,l); // E01
		else p++;
	}
	/* defer dimensions */
	else if (*p==',') {
		p++;
		if (!*p) pe(8,l); // E08
		array();
		dimq=vn[td+1].dim;
		for (i=1;i<=dimq;i++) {
			start[i]=vn[td+1].offset[i];
			end[i]=vn[td+1].offset[i]+vn[td+1].ldim[i];
		}
	}
	/* these are not simple declare() variables! */
	else pe(6,l); // E06
	
	/* decide what base to use in case of OWN variables; if a ghost is 
	 * found, use that value, otherwise there are no ghosts */
	if (isOwn) {
		int i=1;
		while (i<=ghostCount) {
			if (own[i].code==code) {
				doOwn=i;
				break;
			}
			i++;
		}
	}

	/* build common attributes */
	vn[td].type=typeBox;
	vn[td].dim=dimq;
	vn[td].isArr=TRUE;
	vn[td].isFunc=FALSE;
	vn[td].isFict=FALSE;
	vn[td].ref=td;
	vn[td].refcode=td;
	vn[td].proccode=0;
	vn[td].strmem=COMPSTR;
	vn[td].line=l;
	vn[td].level=pexecTOS;
	for (i=1;i<=dimq;i++) {
		vn[td].ldim[i]=end[i]-start[i];
		vn[td].offset[i]=start[i];
	}
	vn[td].coeff[dimq]=1;
	for (i=dimq-1;i>=1;i--) {
		vn[td].coeff[i]=vn[td].coeff[i+1]*(vn[td].ldim[i+1]+1);
	}
	for (i=0;i<COMPSTR;i++) {
		vn[td].valdata[i]='\0';
		vn[td].strdata[i]='\0';
	}

	/* set procedure reference */
	if (!pexecTOS) vn[td].proccode=0;
	else vn[td].proccode=pexec[pexecTOS-1];


	/* OWN variables with existing ghost */
	if (isOwn && doOwn) {
		int asize;
		int gsize=own[doOwn].size;
		int size, nowcreate=FALSE;
		/* copy existing array ghost space on newly created array */
		/* numeric arrays */
		if (typeBox<STRINGTYPEBOX) {
			asize=dimArray(td,dimq,vn[td].ldim);
			if (asize>gsize) size=gsize, nowcreate=TRUE;
			else size=asize;
			memcpy_(dim[td].elem,own[doOwn].numarr,size);
		}
		/* string arrays */
		else {	
			asize=dimStrArray(td,dimq,vn[td].ldim);
			if (asize>gsize) size=gsize, nowcreate=TRUE;
			else size=asize;
			memcpy_(dimS[td].elem,own[doOwn].strarr,size);
		}
		vn[td].size=asize;
		/* in case newly created array is greater than existing
		 * ghost, recreate it as a bigger ghost */
		/* numeric arrays */
		if (nowcreate && typeBox<STRINGTYPEBOX) {
			if (own[ghostCount].numarr) 
				free(own[ghostCount].numarr);
			own[ghostCount].numarr=nalloc((size_t)asize);  
			if (!own[ghostCount].numarr) pe(11,l); // E11
			own[ghostCount].size=asize;			
		}
		/* string arrays */
		else if (nowcreate) {
			if (own[ghostCount].strarr) 
				free(own[ghostCount].strarr);
			own[ghostCount].strarr=salloc((size_t)asize);  
			if (!own[ghostCount].strarr) pe(9,l); // E09
			own[ghostCount].size=asize;			
		}
		else own[ghostCount].size=asize;
	}
	/* OWN variables created for the first time: create ghost */
	else if (isOwn && !doOwn) {
		int asize;
		ghostCount++;
		/* create ghost */
		/* numeric arrays */
		if (typeBox<STRINGTYPEBOX) {
			asize=dimArray(td,dimq,vn[td].ldim);
			own[ghostCount].numarr=nalloc((size_t)asize);  
			if (!own[ghostCount].numarr) pe(11,l); // E11
		}
		/* string arrays */
		else {	
			asize=dimStrArray(td,dimq,vn[td].ldim);
			own[ghostCount].strarr=salloc((size_t)asize);  
			if (!own[ghostCount].strarr) pe(9,l); // E09
		}
		own[ghostCount].size=asize;
		vn[td].size=asize;
		own[ghostCount].code=code;
		vn[td].isOwn=code;
	}
	/* simple arrays (no OWN) */
	else {
		/* numbers */
		if (typeBox<STRINGTYPEBOX) {
			vn[td].size=dimArray(td,dimq,vn[td].ldim);
		}
		/* strings */
		else {
			vn[td].size=dimStrArray(td,dimq,vn[td].ldim); 
		}
		vn[td].isOwn=FALSE;
	}
	
	/* set name/type */
	strncpy_(vn[td].name,decname,NAMEDIM);
	vn[td].valdata[0]='\0';

	/* next assignment */
	if (*p==',') {
		p++;
		array();
	}

	// Note: no check for ; here!
}


/******************************************
 *          RUNNING  INTERFACE            *
 ******************************************/

/* searchFirst()
 * wrapper for strcasestr_oq to check the first occurrence of term1 or term2 
 * and return its position in base as a char pointer
 * Return NIL in case none is found.
 * System function for storeSingleLineToCore() */
char *searchFirst(char *base, char *term1, char *term2) {
	char *y1, *y2;
	y1=strcasestr_oq(base,term1);
	y2=strcasestr_oq(base,term2);
	if (y1 && !y2) return y1;
	else if (!y1 && y2) return y2;
	else if (y1 && y2) {
		if (y1<y2) return y1;
		return y2;
	}
	return NIL;
}


/* storeSingleLineToCore()
 * saves into core memory the line in argument, storing also labels info;
 * return TRUE on successful storing;
 * line holds the textual statements part
 * lnum holds the physical line number
 * a void line is transparent for this command
 * return current updated line number (which changes only with EXTERNAL
 * procedures)
 * System function */ 
int storeSingleLineToCore(char *line, int lnum) {
	char *lp=line, *z, *cp;
	char thislabel[COMPSTR], *lab=thislabel;
	int lk=0;

	/* check NIL (empty line...) */
	if (!*line) return TRUE;

	/* adjust line */
	if ((int)strlen(line)>0) lp=line+(int)strlen(line)-1;
	else lp=line;
	/* get rid of final blanks */
	while ((int)(lp-line)>0 && isblank(*lp)) *lp--='\0';
	lp=line;

	/* store original line (debug and error printing purposes) */
	while (isblank(*lp)) lp++;
	lk=((int)strlen(lp)+1)*sizeof(char);
	mb[lnum]=salloc((size_t)lk);
	if (!mb[lnum]) pe(26,lnum); // E26
	strncpy_(mb[lnum],lp,lk);
	labelIndex[lnum]=0;
	
	/* remove comments */
	lp=line;
	/* remove comment on this line originated in a previous line */
	if (isDelComm) {
		while (*lp && *lp!=';') *lp++=' ';
		if (*lp==';') *lp=' ', isDelComm=FALSE;
	}
	/* start removing a comment */
	while ((cp=searchFirst(lp,"!","COMMENT"))) {
		/* the figure != is not a comment */
		if (*cp=='!' && *(cp+1)=='=') break;
		while (*cp && *cp!=';') *cp++=' ';
		if (*cp==';') *cp=' ', isDelComm=FALSE;
		else if (!*cp) isDelComm=TRUE;
	}
	/* take care of comments after END*/
	while (!isDelComm && (cp=searchFirst(lp,"END","<NULL>"))) {
		cp+=3; // skip END
		while (isblank(*cp)) cp++;
		if (strncasecmp_(cp,"ELSE",4)) {
			while (*cp && *cp!=';' && *cp!='.') *cp++=' ';
		}
		lp+=3;
	}

	/* get label code number 
	 * labels are terminated by colon and may be more than one on the
	 * same line, and may be followed by any legal statement; 
	 * labels are constituted by numbers, letters and the underscore */
	lp=line;
	while ((z=findLabel(lp))) {
		int code=0, pos=0, i=0;
		char *za,*zb;
		--z;
		lab=thislabel;
		while (z>lp && islabelnamechar(z)) z--;
		if (*z==';') z++;
		za=z;
		while (isblank(*z)) z++;
		while (*z!=':') *lab++=*z++;
		*lab='\0';
		code=setAddr(thislabel, &lab);
		labelTOS++;
		/* too much labels */
		if (labelTOS>LABELLIM) pe(26,l); // E26
		/* check if there is a duplicated value */
		i=0;
		while (i<labelTOS) {
			if (label[i].code==code) {
				printf("\n");
				pe(12,lnum); // E12
			}
			i++;
		}
		label[labelTOS].code=code;
		label[labelTOS].ll=lnum;
		label[labelTOS].pl=pos;
		strcpy(label[labelTOS].name,thislabel);
		labelIndex[lnum]=labelTOS;
		zb=z+1;
		while (z>=za) *z--=' ';
		pos=(int)(z-lp);
		if (pos<0) pos=0;
		lp=zb;
	}

	lp=line;
	stripBlanks(lp);
	/* evaluate DATA: load external file instead */
	if (!strncasecmp_(lp,"DATA",4)) {
		p = lp;
		DATA();
	}

	/* store line; if lp is a void line with only spaces and/or tabs, 
	 * it's stored anyway, but it won't be executed (see up) */
	if (*lp && (int)strlen(lp)>0) {
		lk=((int)strlen(lp)+1)*sizeof(char);
		m[lnum]=salloc((size_t)lk);
		if (!m[lnum]) pe(26,lnum); // E26
		strncpy_(m[lnum],lp,lk);
	}
	/* if line is void, fill it with the null string */
	else {
		lk=(3)*sizeof(char);
		m[lnum]=salloc((size_t)lk);
		if (!m[lnum]) pe(26,lnum); // E26
		strncpy_(m[lnum],"",lk); // null string
	}

	/* normal behavior */
	return lnum;
}


/* OLD() 
 * erase memory and call LOAD */
void OLD(void) {
	int i;

	/* erase core memory */
	for (i=0;i<MEMLIMIT;i++) {
		if (m[i]!=NIL && (int)strlen(m[i])>0) {
			free(m[i]);
			m[i]=NIL;
		}
	}

	/* LOAD */
	endCore=LOAD(m,filename,0);
	
}


/* getNextLine()
 * read file line, joins with next if ending with comma, deprive lines from
 * spurious characters left by DOS files, and from final blanks.
 * Return TRUE on correct reading, FALSE on missed reading */
/* TODO: specialize output:
 * - source not existing
 * - unsuitable lim
 * - unreferenced tank
 * - end of file on source
 * Return number of lines joined. 
 * Note: source for ASCII 10/13 in https://en.wikipedia.org/wiki/Newline */
int getNextLine(char *tank, int lim, FILE *source) {
	int count=1;
	if (!fgets(tank,lim,source)) return FALSE;
	/* strip away ASCII 13 left by DOS and Classic MacOS files */
	if (tank[(int)strlen(tank)-1]==13) tank[(int)strlen(tank)-1]='\0';
	/* strip away ASCII 10 left by DOS, UNIX, Linux, files */
	if (tank[(int)strlen(tank)-1]==10) tank[(int)strlen(tank)-1]='\0';
	/* strip away second ASCII 13 left by Acorn and Risc OS files */
	if (tank[(int)strlen(tank)-1]==13) tank[(int)strlen(tank)-1]='\0';
	/* strip away ending blanks */
	while (isblank(tank[(int)strlen(tank)-1])) 
		tank[(int)strlen(tank)-1]='\0';
	totchars+=strlen(tank);
	/* append next line if previous ends with comma */
	if (tank[(int)strlen(tank)-1]==',') {
		char addon[COMPSTR], *pA=addon;
		int incr;
		if(!(incr=getNextLine(addon,COMPSTR,source))) return FALSE;
		while (isblank(*pA)) pA++;
		strncat_(tank," ",COMPSTR);
		strncat_(tank,pA,COMPSTR);
		count+=incr;
	}
	return count;
}


/* checkForEND()
 * check if e points to the final dotted END 
 * system function for LOAD() */
int checkForEND(char *e) {
	if (!strncasecmp_(e,"END",3)) {
		e+=3;
		while (*e && *e!='.') e++;
		if (*e=='.') return TRUE;
	}
	return FALSE;
}

int countQuotes(char * str) {
	int res=0;
	while (*str) {
		if (*str++=='\"') res++;
	}
	return res;
}

/* LOAD() 
 * load file in memory, from position following 'stt'
 * filestr: name of file to open
 * m: memory where program is stored
 * Note: this statement is is not available as a programming statement.
 * If '#' is set as first non blank character of a line, loading is ignored;
 * this lets using shell commands; not belonging to the DEC ALGOL 60 */
int LOAD(char **m, char *filestr, int stt) {
	FILE *f;
	char B[COMPSCR], *pB=B;
	int linenum=stt,incr;

	/* option -b add BEGIN */
	if (addMainRootBlock) {
		int lk=6*sizeof(char);
		linenum++;
		m[linenum]=salloc((size_t)lk);
		if (!m[linenum]) pe(26,0); // E26
		strncpy_(m[linenum],"BEGIN",lk);
		mb[linenum]=salloc((size_t)lk);
		if (!mb[linenum]) pe(26,0); // E26
		strncpy_(mb[linenum],"BEGIN",lk);
		dartLin[linenum]=1;
	}

	/* open file */
	if (!(f=fopen(filestr,"r"))) {
		beginS=-1;
		if (stt) pe(50,stt); // move 1 to 50
		else {
			fprintf(stderr,"%s\n",error[50]); // move 1 to 50
			exit(EXIT_FAILURE);
		}
	}

	/* NOTE: if the file is a binary file, leave the error detection
	 * to the parsing phase (error #74 detection was removed because it interfered
	 * with execution under DOS and was meaningless)  */

	/* load lines one by one */
	while ((incr=getNextLine(B,COMPSCR,f)) && linenum<MEMLIMIT-1) {
		int stop=FALSE;
		linenum+=incr; pB=B;
		/* skip BASIC numbers */
		if (isdigit(*pB)) {
			char num[COMPSTR], *n=num;
			int ll;
			while (isdigit(*pB)) *n++=*pB++;
			*n='\0';
			ll=(int)strtod(num,NULL);
			dartLin[linenum]=ll;
		}
		while (isblank(*pB)) pB++;
		/* join subsequent lines in case of broken strings */
		while (countQuotes(pB)%2) {
			char *h, host[COMPSCR];
			linenum++;
			incr=getNextLine(host,COMPSCR,f);
			h=host;
			/* remove Dartmouth line numbers */
			while (isdigit(*h)) h++;
			while (isblank(*h)) h++;
			strncat(pB," ",COMPSCR);
			strncat(pB,h,COMPSCR);
		}
		/* discard void lines and lines beginning with # */
		if (!*pB || *pB=='#') continue;
		/* discard dash-commented lines (not ISO nor DEC) */
		if (*pB=='-') continue;
		/* set for stop at the final end */
		if (checkForEND(pB)) {
			stop=TRUE;
		}
		/* store line */
		linenum=storeSingleLineToCore(pB,linenum);
		incrLin[linenum]=incrementer-incr+1;

		if (stop) break;
	}

	/* check if file was entirely loaded */
	if (!feof(f) && linenum==MEMLIMIT-1) pe(26,-2); // E26
	
	/* option -b add final END */
	if (addMainRootBlock) {
		int lk=5*sizeof(char);
		linenum++;
		m[linenum]=salloc((size_t)lk);
		if (!m[linenum]) pe(26,0); // E26
		strncpy_(m[linenum],"END",lk);
		mb[linenum]=salloc((size_t)lk);
		if (!mb[linenum]) pe(26,0); // E26
		strncpy_(mb[linenum],"END",lk);
		dartLin[linenum]=dartLin[linenum-1]+1;
	}

	/* close file channel */
	if (f) fclose(f);

	return linenum;
}


/* RUN()
 * the RUN command 
 * Note: this statement is executed at start automatically and is not 
 * available as a programming statement */
void RUN(void) {
	int i;

	/* set numerical variables and relative flags*/
	for(i=0; i<LIMIT;i++) P[i]=pexec[i]=0.0;
	/* set numerical arrays references */
	for(i=0; i<LIMIT;i++) if (dim[i].elem) dim[i].elem=NIL;
	/* set string arrays references */
	for(i=0; i<LIMIT;i++) if (dimS[i].elem) dimS[i].elem=NIL;
	/* set PROCEDURE data */
	procTOS=pexecTOS;
	pexec[pexecTOS++]=0; // main level is zero, first proc call is one

	/* reset channels info specifics */
	for(i=1; i<=STREAMS; i++) {
		channel[i].type=NOUSE;
		channel[i].wayout=NOUSE;
		channel[i].isopen=FALSE;
	}
	rbuff[0]='\0'; rb=rbuff;

	/* set parameters for root level */
	Procp[0].procref=-1;		
	Procp[0].procL=0;		
	Procp[0].procP=0;
	Procp[0].begnL=0;
	Procp[0].begnP=0;
	Procp[0].termL=0;
	Procp[0].termP=0;
	Procp[0].numvars=0;		
	Procp[0].number=0;		
	Procp[0].type=0;		
	strcpy(Procp[0].name,"Root level - dia");

	/* enable channel 0 for input */
	channel[CONSOLE].stream=stdin;
	channel[CONSOLE].isopen=TRUE;
	channel[CONSOLE].type=SEQ;
	channel[CONSOLE].fcounter=0;
	channel[CONSOLE].fprintn=1;
	channel[CONSOLE].pageL=1;
	channel[CONSOLE].pageN=1;
	channel[CONSOLE].wayout=VREAD;
	channel[CONSOLE].margin=COMPSCR;
	channel[CONSOLE].iochan=0547675;

	/* enable channel 1 for output */
	channel[1].stream=stdout;
	channel[1].isopen=TRUE;
	channel[1].type=SEQ;
	channel[1].fcounter=0;
	channel[1].fprintn=1;
	channel[1].pageL=1;
	channel[1].pageN=1;
	channel[1].wayout=VREAD+VWRITE;
	channel[1].margin=COMPSCR;
	channel[1].iochan=0547675;
	currentINPUT=CONSOLE;
	currentOUTPUT=OCONSOLE;

	/* erase remaining channels */
	for (i=2; i<=STREAMS; i++) {
		channel[i].stream=NIL;
	}

	/* reset FOR references and FOR/NEXT address array 
	 * specific for each RUN(), and RANDOMIZE */
	forTOS=ifTOS=0;

	/* pre-parsing operations */
	preParse(m,1,endCore);
	isRunOn=TRUE;
	beginTOS=0;
	if (isNoExecute) return;

	/* print a void line to separate dia output */
	//fputc('\n',stdout);
	/* and finally, execute program if everything in preParse() is OK */
	algolstart();
}


/* END()
 * end program, accomplishing various tasks, such as closing opened channels,
 * fixing graphical stuff and closing regularly as C requires.
 * Note: as exit state, return the state passed to it as argument.
 * Note: as the returned states, I use:
 * EXIT_SUCCESS (which is 0) to indicate a proper successful execution
 * EXIT_FAILURE (which is 1) to indicate a stop after an error condition
 * EXIT_STOP (which is 2) to indicate an invoked STOP termination (CTRL-C) */
void END(int state) {
	int i; // open file remnants flag

	/* GRAPHICAL OPERATIONS */
	/* CTRL-C was pressed: print to signal */
	if (isInterrupt) fprintf(stdout, "\n\ndia stopped after user interrupt at line %d\n\n",l);
	/* CTRL-C was pressed: print to signal */
	else if (state==EXIT_STOP) 
		fprintf(stdout, "\ndia execution interrupted by STOP at line %d\n\n",dartLin[l]);
	/* add a Carriage Return in case of suspended PRINT */
	else if (channel[OCONSOLE].fcounter) fprintf(stdout, CRS);

	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		fprintf(stdout,"%s","Freeing memory... ");
		fprintf(stdout,"%s",RESETCOLOR);
	}

	for (i=0;i<=decCount;i++) {
		if (dim[i].elem) free(dim[i].elem);
		if (dimS[i].elem) free(dimS[i].elem);
		if (PS[i]) free(PS[i]);
		if (vn[i].type==INFILETYPEBOX && vn[i].isopen) {
			fclose(vn[i].stream);
		}
		if (vn[i].type==OUTFILETYPEBOX && vn[i].isopen) {
			fclose(vn[i].stream);
		}
	}
	for (i=0;i<=ghostCount;i++) {
		if (own[i].numarr) free(own[i].numarr);
		if (own[i].strarr) free(own[i].strarr);
	}
	for (i=0;i<=endCore;i++) {
		if (m[i]) free(m[i]);
		if (mb[i]) free(mb[i]);
	}

	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		fprintf(stdout,"%s","done\nClosing files... ");
		fprintf(stdout,"%s",RESETCOLOR);
	}
	/* close and setup all files */
	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		fprintf(stdout,"%s","done\n");
		fprintf(stdout,"%s",RESETCOLOR);
	}
	
	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		if (ifExecTOS+ifExecTOS+ifExecTOS+beginTOS) {
			fprintf(stdout,"%s","\ndebug: structures remnants:\n");
			if (beginTOS) 
				fprintf(stdout,"  left open BEGIN-END : %d\n",beginTOS);
			if (ifExecTOS) 
				fprintf(stdout,"  unterminated IF     : %d\n",ifExecTOS);
			if (forExecTOS)
				fprintf(stdout,"  still hooked FOR    : %d\n",forExecTOS);
			if (whileExecTOS)
				fprintf(stdout,"  still hooked WHILE  : %d\n",whileExecTOS);
		}
	
		fprintf(stdout,"%s",RESETCOLOR);
	}
	
	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		fprintf(stdout,"%s","Resetting all channels... ");
		fprintf(stdout,"%s",RESETCOLOR);
	}
	/* FILE OPERATIONS */
	/* close channels */
	for (i=1;i<=OSTREAMS;i++) {
		channel[i].stream=NULL;
		channel[i].ioname[0]='\0';
		channel[i].isopen=0;
		channel[i].type=0;
		channel[i].fcounter=0;
		channel[i].pageL=0;
		channel[i].pageN=0;
		channel[i].fprintn=0;
		channel[i].margin=0;
		channel[i].wayout=0;
		channel[i].iochan=0;
	}
	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		fprintf(stdout,"%s","done\nCompleting all printer jobs... ");
		fprintf(stdout,"%s",RESETCOLOR);
	}
	/* TIMING OPERATIONS */
	/* record end time 
	 * Note: if file was not found, beginS remains negative */
	if (beginS<0) endS=0.0;
	else {
		gettimeofday(&tv, NULL);
	       	endS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS=endS-beginS;
	}

	if (isDebug) {
		fprintf(stdout,"%s",INVCOLOR);
		fprintf(stdout,"%s","done\nClosing.\n\n");
		fprintf(stdout,"%s",RESETCOLOR);
	}
	/* in case of timing, add the timed calculation string */
	if (isTiming) {
		int hour=0,min=0;
		double secs=endS;
		printf("\n");
		/* pre-calculate intermediate time values */
		if (endS>60) {
			min=endS/60;
			endS=endS-min*60;
		}
		if (min>60) {
			hour=min/60;
			min=min-hour*60;
		}
		/* depict time in condensed form */
		if (!hour && !min) {
			if (secs<1) 
			     fprintf(stdout,"TIME:  %.2f MSECS.\n\n",endS*1000);
			else 
			     fprintf(stdout,"TIME:  %.2f SECS.\n\n",endS);
		}
		else if (!hour)
			fprintf(stdout,"TIME:  %.2d:%.2d MIN%c	(%.2f SECS).\n\n",min,(int)(endS+0.5),min!=1?'S':' ',secs);
		else 	
			fprintf(stdout,"TIME:  %.2d:%.2d:%.2d HOUR%c   (%.2f SECS).\n\n",hour,min,(int)(endS+0.5),hour!=1?'S':' ',secs);
	}
	
	/* QUITTING */
	/* flush all open streams, to ensure file data writing is completed */
	fflush(NULL);
	s_exit(state);
	system("reset");
}


/* s_exit()
 * safe exit - avoid messing up of colours, and force the screen resetting
 * return 'state' as current state
 * system function */
void s_exit(int state) {
	/* reset screen */
	fprintf(stdout,"%s",RESETCOLOR);
	exit(state);
}


/******************************************************************************
 * The following functions define the whole parser engine:
 * SS() 	   : the strings expression parser
 * strRel()        : the strings relation evaluator (returns a truth value)
 * S() 		   : the numerical expression parser
 * getVal()	   : the single numerical value parser 
 * getFunc()	   : the numerical function parser
 * priority()	   : return numerical operator precedence
 * setResultType() : set result type of an expression depending on a scale
 * conceived April 2008 for the dib project and adapted for dia in June 2026
 * modified for vibes with strings insertion September-November 2009
 * updated and verified for decb - February 2013, February-Summer 2014
 * updated and typized for tbas - February-Summer 2016
 * Copyleft Antonio Maschio - 2008-2016-2026
 ******************************************************************************/

/* SS()
 * The PARSER for string expression; it's a general routine.
 * The address of starting position into the flow stream is pointed by p 
 * The algorithm is as follows: 
 * until there is a string in any form, append it to mypad; return mypad */
char *SS(void) {
	int i,ns,type=0;
	double numres;
	char mypad[COMPSTR], strres[COMPSTR], *opT;

	/* create local pad and reset */
	for (i=0;i<COMPSTR;i++) mypad[i]='\0';

	/* calculate string result */
	do {
		/* literal or var label */
		if (isLabelAssign) {
			char lab[COMPSTR], *k;
			int count=0, code;
			strncat_(lab,SS(),COMPSTR);
			code=setAddr(lab,&k);
			for (count=1; count<=labelTOS; count++) {
				if (label[count].code==code) {
					isLabelAssign=count;
					break;
				}
			}
			if (isLabelAssign==-1) pe(9,l); // E09
		}
		/* open/close parenthesis */
		else if (*p=='(') {
			p++;
			strncat_(mypad,SS(),COMPSTR);
			if (*p==')') p++;
			else pe(1,l); // E01
		}
		/* IF..THEN..ELSE
		 * conditional expression statements" */
		else if (!strncasecmp_(p,"IF",2)) {
			int cond=FALSE;
			char op1[COMPSTR], op2[COMPSTR];
			p+=2;
			if (!check(p,"THEN") && !check(p," HEN")) pe(8,l); // E08
			cond=(int)S();
			*p='T';
			p+=4; // skip THEN
			if (!check(p,"ELSE") && !check(p," LSE")) pe(8,l); // E08
			strncpy_(op1,SS(),COMPSTR);
			*p='E';
			p+=4; // skip ELSE
			strncpy_(op2,SS(),COMPSTR);
			if (cond) {
				if((int)strlen(mypad)+(int)strlen(op1)>=COMPSTR)
					pe(26,l); // E26
				strncat_(mypad,op1,COMPSTR);
			}
			else {
				if((int)strlen(mypad)+(int)strlen(op2)>=COMPSTR)
					pe(26,l); // E26
				strncat_(mypad,op2,COMPSTR);
			}
		}
		/* expicit string surrounded by double quotes " */
		else if (*p=='\"') {
			char op[COMPSTR], *P1=op;
			int len=0;
			p++; // skip "
			while (*p && len<COMPSTR) {
				if (*p=='\"' && *(p+1)=='\"') p++;
				else if (*p==';' && *(p+1)==';') p++;
				else if (!*p || *p=='\"' || ister(p)) break;
				*P1++=*p++, len++; 
			}
			*P1='\0';
			if (*p=='\"') p++; // skip closing quotes
			/* join subsequent string */
			else if (ister(p)) while (ister(p)) {
				l++;
				while (!m[l]) l++;
				if (l>endCore) pe(26,l); // E26
				strncpy_(BASESTR,m[l],COMPSCR);
				p=BASESTR;
				while (*p && len<COMPSCR) {
					if (*p=='\"' && *(p+1)=='\"') p++;
					else if (*p==';' && *(p+1)==';') p++;
					else if (*p=='\"' || ister(p)) break;
					*P1++=*p++, len++; 
				}
				*P1='\0';
				if (*p=='\"') {
					p++;
					break;
				}
			}
			if ((int)strlen(mypad)+(int)strlen(op)>=COMPSTR) 
				pe(26,l); // E26
			strncat_(mypad,op,COMPSTR);
		}
		/* STRING VARIABLES */
		else if ((ns=findDEC(p)) && *(p+_len)!='(') {
			char op[COMPSTR];
			p+=_len;
			/* variable to which a function or a string expression
			 * is passed. In this case the string is
			 * taken from valdata */
			if (vn[ns].isFunc || vn[ns].refcode==2*DECADD){
				strncpy(op,vn[ns].valdata,COMPSTR);
				if ((int)strlen(mypad)+(int)strlen(op)>=COMPSTR)
					pe(26,l); // E26
				strncat_(mypad,op,COMPSTR);
				continue;
			}
			/* variable reference to an array element  */
			if (vn[ns].refcode<-DECADD){
				char *pp=p;
				p=vn[ns].valdata;
				strncpy(op,SS(),COMPSTR);
				p=pp;
				if ((int)strlen(mypad)+(int)strlen(op)>=COMPSTR)
					pe(26,l); // E26
				strncat_(mypad,op,COMPSTR);
				continue;
			}
			/* variable or array passed by reference */
			else if (vn[ns].refcode<0) {
				ns=vn[ns].ref;
			}
			
			/* return a string variable */
			if (*(p)!='[' && !_arr) {
				int var=vn[ns].ref;
				if ((int)strlen(mypad)+(int)strlen(PS[var])>=COMPSTR)
					pe(26,l); // E26
				strncat_(mypad,PS[var],COMPSTR);
			}
			/* return a string array element */
			else if (*(p)=='[' && _arr) {
				int val[MAXDIM+1];
				int T=1;
				p++;
				val[T]=(int)S();
				while (*p==',') {
					p++; T++;
					if (T>MAXDIM) pe(26,l); // E26
					val[T]=(int)S();
				}
				if (*p==']') p++;
				else pe(1,l); // E01
				strncpy_(op,getArrayStr(vn[ns].ref,vn[vn[ns].ref].dim,val),COMPSTR);
				if ((int)strlen(mypad)+(int)strlen(op)>=COMPSTR)
					pe(26,l); // E26
				strncat_(mypad,op,COMPSTR); 
			}
		}
		/* STRING PROCEDUREs  */
		else if ((ns=findPROC(p,&opT,&type))) {
			char op[COMPSTR];
			if (type==STRINGTYPEBOX)	{
				/* normal user procedure-delegate execPROC() */
				if (Procp[ns].procL>0) {
					p=execPROC(ns,opT,&numres,strres);
					strncpy_(op,strres,COMPSTR);
				}
				/* argument procedure - use SS() */
				else if (Procp[ns].procL<0) {
					char exstring[COMPSTR], *e;
					char *pb=p+strlen(Procp[ns].name);
					e=exstring;
					strncpy_(exstring,Procp[ns].strdata,COMPSTR);
					e+=strlen(Procp[ns].strdata);
					if (*pb=='(') {
						int beg=0;
						*e++=*pb++; // copy (
						while (*pb) {
							if (*pb=='(') beg++;
							else if (*pb==')' && beg) 
								beg--;
							else if (*pb==')' && !beg) 
								break;
							*e++=*pb++;
						}
						if (*pb==')') *e++=*pb++;
						else pe(1,l); // E01
						*e='\0';
					}
					else pe(1,l); // E01
					p=exstring;
					strncpy_(op,SS(),COMPSTR);
					p=pb;
				}
				else pe(8,l); // E08
				resultType=Procp[ns].type;
			}
			else pe(8,l); // E08
			if ((int)strlen(mypad)+(int)strlen(op)>=COMPSTR)
				pe(26,l); // E26
			strncat_(mypad,op,COMPSTR); 
		}
		/* CONCAT string function */
		else if (!strncmp(p,"CONCAT(",7))  {
			char op1[COMPSTR],op2[COMPSTR];
			p+=7;
			/* first string */
			strncpy_(op1,SS(),COMPSTR);
			/* further strings */
			while (*p==',') {
				if (*p==',') p++; // skip comma
				strncpy_(op2,SS(),COMPSTR);
				strncat_(op1,op2,COMPSTR);
			}
			if (*p==')') p++;
			else pe(1,l); // E01
			if ((int)strlen(mypad)+(int)strlen(op1)>=COMPSTR) {
				pe(9,l); // E09
			}
			strncat_(mypad,op1,COMPSTR);
		}		
		/* numeric variables cause error */
		else if ((ns=findDEC(p))&&(_type<STRINGTYPEBOX||_type==CHAR)){
			pe(11,l); // E11
		}
		/* no possible evaluation */
		else pe(8,l);  // E08
	} while (*p && *p=='\"');
	strncpy_(sspad,mypad,COMPSTR);
	strncpy_(output,sspad,COMPSTR);
	return MYPAD;
}


/* strRel()
 * evaluate a string expression; operators <, >, =, #, { (<=) and } (>=); 
 * always return a truth value
 * Note: in relations, any kind of string variable (even string arrays)
 * may be used into the formula.
 * Note: since evaluation of string relations returns a truth value, which is
 * a number, it is useful only into IF..THEN statements and into S(); so they 
 * are recognized/used there, and not into SS() */
int strRel(void) {
	int rel=FALSE, operator;
	char op1[COMPSTR], op2[COMPSTR], *P1=op1, *P2=op2;

	/* read operands and operator */
	strncpy_(op1,SS(),COMPSTR);
	if (isleq(p)) operator='{', p+=2;	// <=
	else if (isgeq(p)) operator='}', p+=2;	// >=
	else if (*p=='<') operator='<', p++;	// <
	else if (*p=='>') operator='>', p++;	// >
	else if (*p=='#') operator='#', p++;	// #
	else if (*p=='=') operator='=', p++;	// =
	else pe(2,l); // E02
	strncpy_(op2,SS(),COMPSTR);

	/* delete trailing spaces before and after strings */
	if ((int)strlen(op1)>0) {
		P1=op1+(int)strlen(op1)-1; 
		while ((int)(P1-op1)>0 && isblank(*P1)) *P1--='\0';
	}
	if ((int)strlen(op2)>0) {
		P2=op2+(int)strlen(op2)-1; 
		while ((int)(P2-op2)>0 && isblank(*P2)) *P2--='\0';
	}
	P1=op1; while ((int)(P1-op1)<COMPSTR && isblank(*P1)) P1++;
	P2=op2; while ((int)(P2-op2)<COMPSTR && isblank(*P2)) P2++;

	/* apply operator ; case matter, so we use strcmp() */
	switch(operator) {
		case '<': if (strcmp(P1,P2) < 0)  rel=TRUE; break;
		case '>': if (strcmp(P1,P2) > 0)  rel=TRUE; break;
		case '=': if (!strcmp(P1,P2))     rel=TRUE; break;
		case '#': if (strcmp(P1,P2))      rel=TRUE; break;
		case '{': if (strcmp(P1,P2) <= 0) rel=TRUE; break;
		case '}': if (strcmp(P1,P2) >= 0) rel=TRUE; break;
		default:  rel=FALSE;
	}
	return rel;
}


/* priority() 
 * return math priority for operator op, according to the following table:
 * 10: the minus and the NOT (caught in S()) are evaluated immediately
 * 9: (..) parentheses (caught in getVal) have the highest precedence
 * caught here:
 * 8: power
 * 7: multiplication, division, DIV \ � REM `
 * 6: addition, subtraction
 * 5: <, <= {, =, >, >= }, # 
 * 4: AND _
 * 3: OR |
 * 2: IMPLY %
 * 1: EQUIV &
 * 0: anything else has NIL priority and should cause error 
 * Note: The NOT operator has the higher precedence because it refers to the
 * term that immediately follows (in contrast to the ISO directives); 
 * the same for the minus sign. */
int priority(const int op) {
	if (op=='^') return 8;
	else if (op=='*'||op=='/'||op=='\\'||op=='`') return 7;
	else if (op=='+'||op=='-') return 6;
	else if (op=='<'||op=='{'||op=='='||op=='>'||op=='}'||op=='#') 
		return 5;
	else if (op=='_') return 4;
	else if (op=='|') return 3;
	else if (op=='%') return 2;
	else if (op=='&') return 1;
	return 0;
}
#define PRIOR 8

int isLogic(double g) {
	if (g==0.0 || g==-1.0) return TRUE;
	return FALSE;
}

/* S()
 * The PARSER for numerical expressions
 * The address of starting position into the flow stream is pointed by p 
 * The algorithm is as follows: 
 * an algebraic expression is turned into an RPN stack-based expression, 
 * with numbers and operators in order in their own stacks; operations are 
 * performed from higher priorities down to lower and from left to right;  
 * priorities are given by the priority() function, which is part of this tool.
 * Note: the < and > operators (with their companion <= and >=) may not give 
 * correct results with big numbers, because of the ways of storing numbers; 
 * for instance, 1E29*10 is not stored in the same way of 1E30, because of 
 * rounding errors in calculating the multiplication (the error propagates 
 * rapidly when big numbers are calculated in series) */
double S(void) {
	double numStack[PSTACK];
	int opStack[PSTACK], prStack[PSTACK], tpStack[PSTACK];
	int opturn=0, numTOS=0, opTOS=0, ii,jj, level;
	char *pcopy=NIL;

	/* reset result type */
	resultType=0;

	/* catch unary plus at start (simply discarded because redundant)
	 * Note: dia parser is built in such a way that the unary sign 
	 * (+ or -) is tightly bound to the entity following it, so that 
	 * operations like -3+-2, +3+-2, -3-+2, +3-+2 are accepted */
	if (*p=='+') p++;
	pcopy=p;
	/* reverse algebraic expression into a stack-based structure */
	while (*p && *p!=';' && !isblank(*p)){

		/* reload */
		if (!*p) {
			l++;
			while (!m[l]) l++;
			if (l>endCore) pe(26,l); // E26
			strncpy_(BASESTR,m[l],COMPSTR);
			p=BASESTR;
		}
		/* catch an operator */
		else if ((isop(p)) && opturn) {
			opStack[opTOS]=*p;
			prStack[opTOS]=priority(opStack[opTOS]);
			opTOS++;
			p++;
			opturn=0;
		}
		/* catch a closed parenthesis */
		else if (*p==')') break;
		/* catch the NOT as keyword after an operator */
		else if (!strncasecmp_(p,"NOT",3) && !opturn) {
			p+=3;
			numStack[numTOS]=-(double)(!((int)getVal()));
			tpStack[numTOS++]=BOOLEANTYPEBOX;
			opturn=1;
		}
		/* catch the NOT as symbol after an operator */
		else if (*p=='~' && !opturn) {
			p++;
			numStack[numTOS]=-(double)(!((int)getVal()));
			tpStack[numTOS++]=BOOLEANTYPEBOX;
			opturn=1;
		}
		/* catch the unary plus after an operator */
		else if (*p=='+' && !opturn) {
			p++;
			numStack[numTOS]=getVal();
			tpStack[numTOS++]=resultType;
			opturn=1;
		}
		/* catch a number (literal or variable) */
		else {
			double res=getVal();
			if (res>REALMAX || res<REALMIN) pe(21,l); // E21
			if (res==(int)res && (res>INTMAX || res<INTMIN)) pe(36,l); // E36
			numStack[numTOS]=res;
			tpStack[numTOS++]=resultType;
			opturn=1;
			if (*p && !isop(p) && opturn) break;
		}
		
		/* reload if number is followed by void */
		if (!*p && !opturn && l<endCore) {
			l++;
			while (!m[l]) l++;
			if (l>endCore) pe(26,l); // E26
			strncpy_(BASESTR,m[l],COMPSTR);
			p=BASESTR;
		}
		
		/* Since the string was evaluated, change pcopy to signal
		 * the work is done */
		pcopy=NIL;
		if (*p==',') break;
	}
	/* No parsing was done if the string is not void */
	if (pcopy==p && *p!=';' && strncasecmp_(p,"END",3) && strncasecmp_(p,"ELSE",4)) {
		pe(2,l); // E02 
	}
	/* reset again the type */
	resultType=0;
	/* perform calculations from higher priorities downward
	 * Note: for dia, any relation is also a math expression */
	for (ii=PRIOR;ii>=0;ii--) {
		/* calculations are performed from left to right */
		for (level=0;level<opTOS;level++) {
			if (prStack[level]==ii) {
				/* collapse stacks */
				switch(opStack[level]) {
// HERE BEGINS OPERATORS ANALYSIS
/* lesser than < */
case '<': numStack[level]=-(double)(numStack[level]<numStack[level+1]);
	  tpStack[level]=tpStack[level+1]=BOOLEANTYPEBOX;
	  setResultType(BOOLEANTYPEBOX); break; 
/* greater than > */
case '>': numStack[level]=-(double)(numStack[level]>numStack[level+1]); 
	  tpStack[level]=tpStack[level+1]=BOOLEANTYPEBOX;
	  setResultType(BOOLEANTYPEBOX); break; 
/* not equal # */
case '#': numStack[level]=-(double)(numStack[level]!=numStack[level+1]); 
	  tpStack[level]=tpStack[level+1]=BOOLEANTYPEBOX;
	  setResultType(BOOLEANTYPEBOX); break;
/* greater than or equal >= */
case '}': numStack[level]=-(double)(numStack[level]>=numStack[level+1]); 
	  tpStack[level]=tpStack[level+1]=BOOLEANTYPEBOX;
	  setResultType(BOOLEANTYPEBOX); break;
/* lesser than or equal <= */
case '{': numStack[level]=-(double)(numStack[level]<=numStack[level+1]); 
	  tpStack[level]=tpStack[level+1]=BOOLEANTYPEBOX;
	  setResultType(BOOLEANTYPEBOX); break;
/* equal to */
case '=': numStack[level]=-(double)(numStack[level]==numStack[level+1]); 
	  tpStack[level]=tpStack[level+1]=BOOLEANTYPEBOX;
	  setResultType(BOOLEANTYPEBOX); break;
/* power ^ */
case '^': if (numStack[level]<0 && numStack[level+1]!=(int)numStack[level+1])
	  	pe(26,l); // E27
	  numStack[level]=pow(numStack[level],numStack[level+1]); 
	  tpStack[level]=tpStack[level+1]=REALTYPEBOX;
	  setResultType(REALTYPEBOX);
	  break;
/* subtraction - */
case '-': numStack[level]-=numStack[level+1]; 
	  setResultType(tpStack[level]);
	  setResultType(tpStack[level+1]);
	  break;
/* addition + */
case '+': numStack[level]+=numStack[level+1]; 
	  setResultType(tpStack[level]);
	  setResultType(tpStack[level+1]);
	  break;
/* division */
case '/': {
		double div=numStack[level+1];
		if (fabsl(div)<ZERO) {
			pe(20,l); // E20
		}
		else numStack[level]/=div;
	  }
	  tpStack[level]=tpStack[level+1]=REALTYPEBOX;
	  setResultType(REALTYPEBOX);
	  break;
/* multiplication * */
case '*': numStack[level]*=numStack[level+1]; 
	  setResultType(tpStack[level]);
	  setResultType(tpStack[level+1]);
	  break;
/* bitwise AND */
case '_': {
		int thistype=INTEGERTYPEBOX;
		if (isLogic(numStack[level]) && isLogic(numStack[level+1]))
			thistype=BOOLEANTYPEBOX;
	  	numStack[level]=(double)((int)(numStack[level])&((int)numStack[level+1]));
	  	tpStack[level]=tpStack[level+1]=thistype;
	  	setResultType(thistype);
	  }
	  break;
/* bitwise OR */
case '|': {
		int thistype=INTEGERTYPEBOX;
		if (isLogic(numStack[level]) && isLogic(numStack[level+1]))
			thistype=BOOLEANTYPEBOX;
	  	numStack[level]=(double)((int)(numStack[level])|((int)numStack[level+1]));
	  	tpStack[level]=tpStack[level+1]=thistype;
	  	setResultType(thistype);
	  }
	  break;
/* logical IMPLY */
case '%': 
	  if (!(!numStack[level]) && !(!(!numStack[level+1]))) numStack[level]=FALSE;
	  else numStack[level]=TRUE;
	  tpStack[level]=tpStack[level+1]=INTEGERTYPEBOX;
	  setResultType(INTEGERTYPEBOX);
	  break;
/* logical EQUIV */
case '&': {
		int v0=!!numStack[level];
		int v1=!!numStack[level+1];
	  	if (v0 == v1) numStack[level]=TRUE;
		else numStack[level]=FALSE;
	  }
	  tpStack[level]=tpStack[level+1]=INTEGERTYPEBOX;
	  setResultType(INTEGERTYPEBOX);
	  break;
/* integer division  */
case '\\':{
		double div=numStack[level+1];
		if (tpStack[level]!=INTEGERTYPEBOX || tpStack[level+1]!=INTEGERTYPEBOX)
			pe(39,l); // E39
		if (fabsl(div)<ZERO) pe(20,l); // E20
		else numStack[level]=(int)(numStack[level]/numStack[level+1]); 
	  }
	  tpStack[level]=tpStack[level+1]=INTEGERTYPEBOX;
	  setResultType(INTEGERTYPEBOX);
	  break;
/* integer remainder MOD */
case '`': {
		int div=(int)numStack[level]/(int)numStack[level+1];
		numStack[level]=(int)(numStack[level]-div*(int)numStack[level+1]);
	  }
	  tpStack[level]=tpStack[level+1]=INTEGERTYPEBOX;
	  setResultType(INTEGERTYPEBOX);
	  break;
// HERE ENDS OPERATORS ANALYSIS
				}
				/* shift stack positions */
				for (jj=level;jj<opTOS-1;jj++) {
					numStack[jj+1]=numStack[jj+2];
					opStack[jj]=opStack[jj+1];
					prStack[jj]=prStack[jj+1];
					tpStack[jj]=tpStack[jj+1];
				}
				opTOS--;
				level--;
			}
		}
	}
	
	/* At this point, we have the final result into cell [0] */
	resultType=tpStack[0];
	return numStack[0];
}


/* setResultType()
 * update result type of an expression according to this rules:
 * ~- a REAL absorbs INTEGERS and BOOLEANS
 * ~- otherwise an INTEGER absorbs BOOLEANS 
 * ~- otherwise expression type is BOOLEAN
 * Note: this routine does not control if tpye is STRING or LABEL */
void setResultType(int n) {
	if (n<resultType || !resultType) resultType=n;
}


/* getVal()
 * get single value (number, variable, function or array element) 
 * the case of the unary minus for entities has been caught in S(); here is
 * treated the case of open parentheses
 * The address of starting position into the flow stream is pointed by p */
double getVal(void){
	double o=0;

	/* label assignment 
	 * evaluate string, and check if there's a label variable or
	 * a literal label string */
	if (isLabelAssign) {
		int ns=findDEC(p);
		if (ns && _type==LABELTYPEBOX) 
			isLabelAssign=vn[ns].strmem; // var label code
		else SS();  // consume string
		return 0.0; // unused
	}
	/* case of a literal real number 
	 * evaluate also the $ and E exponential characters */
	if (isnm(p)) {
		char *q, *pp=p;
		double mant;
		int exp, offset=1, isDot=FALSE;
		char num[COMPSTR], *n=num;
		/* get value */
		if (*p=='+' || *p=='-') *n++=*p++;
		if (*p=='.') *n++=*p++, isDot=TRUE;
		while (isdigit(*p)) *n++=*p++;
		if (*p=='.' && isDot) pe(13,l); // E13
		else if (*p=='.') *n++=*p++, isDot=TRUE;
		while (isdigit(*p)) *n++=*p++;
		if (*p=='.' && isDot) pe(13,l);
		if (*p=='E' || *p=='$') {
			*n++='E', *p++;
			if (*p=='+' || *p=='-') *n++=*p++;
			if (!isdigit(*p)) pe(13,l); // E13
			while (isdigit(*p)) *n++=*p++;
		}
		*n='\0';
		n=num;
		if ((q=strcasestr_oq(n,"E"))) {
			setResultType(REALTYPEBOX);
		}
		/* exponential (only exponent given) */
		if (q==n) {
			exp=strtol(q+offset,NULL,10);
			if (abs(exp)>75) pe(14,l); // E14
			o=1.0*pow(10.0,exp);
			setResultType(REALTYPEBOX);
		}
		/* exponential */
		else if (q) {
			*q='\0';
			mant=strtold(n,&n);
			exp=strtol(q+offset,NULL,10);
			if (abs(exp)>75) pe(14,l);
			o=mant*pow(10.0,exp);
			setResultType(REALTYPEBOX);
		}
		/* number */
		else {
			p=pp;
			o=strtold(p,&p);
			if (o==(int)o) setResultType(INTEGERTYPEBOX);
			else setResultType(REALTYPEBOX);
		}
	}
	/* RANDOM random number generator
	 * ~return the next random number
	 * Range:  y -> R */
	else if (!strncmp(p,"RANDOM",6)) {
		p+=6;
		o=getRandom();
		saveRand=o;
		resultType=0;
		setResultType(REALTYPEBOX);
	}
	/* case of unary minus 
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='-') {
		p++;
		o=-getVal();
	}
	/* case of NOT
	 * (for general cases, e.g. before a parenthesis) */
	else if (!strncasecmp_(p,"NOT",3)) {
		p+=3;
		o=-(double)(!((int)getVal()));
		setResultType(BOOLEANTYPEBOX);
	}
	/* case of ~ (NOT - machine token )
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='~') {
		p++;
		o=-(double)(!((int)getVal()));
		setResultType(BOOLEANTYPEBOX);
	}
	/* perform the inner assignment 
	 * Ref. 6.3 "Multiple Assignments" 
		else if
	 * Note: the result type here is the same of the assignment */
	else if (*p=='(' && isInnerAssign(p)) {
		int cs;
		p++;	// skip (
		isInn=TRUE;
		if (!(cs=assign())) pe(8,l); // E08
		else p++; 	// skip )
		o=P[vn[cs].ref];
		setResultType(vn[vn[cs].ref].type);
	}
	/* case of open parenthesis 
	 * Type does not change and is eventually set into the body of
	 * parentheses and passed bare */ 
	else if (*p=='(') { 
		p++;
		o=S();
		if (*p!=')') pe(1,l); // E01
		else p++;
	}
	/* case of a string relation (which returns a numeric truth value) */
	else if (isanystring(p)) {
		o=strRel();
		setResultType(BOOLEANTYPEBOX);
	}
	/* delegate function calculations to getFunc() */
	else if (isbeginnamechar(p)) { 
		o=getFunc();
		p++; 
	}
	/* unrecognized object */
	else pe(18,l); // E18
	return o;
}


/* skip()
 * ignores the characters that form the parameters comments */
int skip(void) {
	if (*p==')' && *(p+1)==';') return FALSE;
	else if (*p==')' && strchr(p,':')) {
		p++; // skip );
		while (*p!=':') p++;
		p++; // skip :
		if (*p=='(') p++;
		else return FALSE;
	}
	return TRUE;
}


/* getFunc()
 * math functions calculator
 * searched first for procedures, then for default math functions, and
 * last for numeric variables.
 * The address of starting position into the flow stream is pointed by p */
double getFunc(void) {
	double o=0.0;
	int paren=TRUE, ns=0, type=0;
	char strres[COMPSTR], *op;
	int ERRVAL=-1, isFunc=TRUE;

	/* check if it's a fictitious variable */
	if ((ns=findDEC(p)) && *(p+_len)!='(') {
		if (vn[ns].isFict) isFunc=FALSE;
	}

        /* NUMERIC PROCEDURES */
	if (isFunc && (ns=findPROC(p,&op,&type))) {
		if (type<STRINGTYPEBOX)	{
			/* normal user procedure  - delegate execPROC() */
			if (Procp[ns].procL>0) {
				p=execPROC(ns,op,&o,strres);
			}
			/* argument procedure - use S() */
			else if (Procp[ns].procL<0) {
				char exstring[COMPSTR], *e;
				char *pb=p+strlen(Procp[ns].name);
				e=exstring;
				strncpy_(exstring,Procp[ns].strdata,COMPSTR);
				e+=strlen(Procp[ns].strdata);
				if (*pb=='(') {
					int beg=0;
					*e++=*pb++; // copy (
					while (*pb) {
						if (*pb=='(') beg++;
						else if (*pb==')' && beg) 
							beg--;
						else if (*pb==')' && !beg) 
							break;
						*e++=*pb++;
					}
					if (*pb==')') *e++=*pb++;
					else pe(8,l); // E08
					*e='\0';
				}
				p=exstring;
				o=S();
				p=pb;
				paren=FALSE;
			}
			else pe(8,l); // E08
			paren=FALSE;
			p--;
		}
		else pe(9,l); // E09
		resultType=0;
		setResultType(type);
	}
	/* NUMERIC VARIABLES 
	 * (excluding those who are functions with the same name)  */
	else if ((ns=findDEC(p)) && *(p+_len)!='(') {
		char *pb=p;
		p+=_len;
		/* variables to which a function or expression is passed. In 
		 * this case the function is recalculated using valdata */
		if (vn[ns].isFunc || vn[ns].refcode==2*DECADD) {
			char *pb=p;
			p=vn[ns].valdata;
                        o=S();
			resultType=0;
			setResultType(vn[ns].type);
			paren=FALSE;
			p=pb;
			p--;
			return o;
		}
		/* variable reference to an array element
		 * or an entire expression that must be calculated 
		 * each time using valdata */
		else if (vn[ns].refcode<-DECADD) {
			char *pb=p;
			p=vn[ns].valdata;
                        o=S();
			resultType=0;
			setResultType(vn[ns].type);
			paren=FALSE;
			p=pb;
			p--;
			return o;
		}
		/* variable reference to a numeric variable or array;
		 * in this case, since the variable is passed by reference,
		 * we alter current ns to match the referenced variable */
		else if (vn[ns].refcode<0) {
			ns=vn[ns].ref;
		}

		/* byte subscripted string  */
		if (_type==CHAR) {
			int pos=0;
			p++; // skip dot
			if (*p!='[') pe(1,l); // E01
			else p++; // skip [
			pos=(int)S();
			if (*p!=']') pe(1,l); // E01
			else p++; // skip ]
			if (pos<1 || pos>strlen(PS[vn[ns].ref])) pe(24,l); // E24
			else o=PS[vn[ns].ref][pos-1];
			paren=FALSE;
			p--;
			resultType=0;
			setResultType(INTEGERTYPEBOX);
		}
		/* string relation  */
		else if (_type==STRINGTYPEBOX) {
			p=pb;
			o=strRel();
			paren=FALSE;
			resultType=0;
			setResultType(BOOLEANTYPEBOX);
		}
		/* return a variable content (not an array)  */
		else if (*(p)!='[' && !_arr) {
			resultType=0;
			if (vn[vn[ns].ref].type==INTEGERTYPEBOX) {
				o=(int)P[vn[ns].ref];
				setResultType(INTEGERTYPEBOX);
			}
			else if (vn[vn[ns].ref].type==BOOLEANTYPEBOX) {
				o=(int)P[vn[ns].ref]; 
				setResultType(BOOLEANTYPEBOX);
			}
			else {
				o=P[vn[ns].ref];
				setResultType(REALTYPEBOX);
			}
			p--;
			paren=FALSE;
		}
		/* return an array element  */
		else if (*(p)=='[' && _arr) {
			int val[MAXDIM+1];
			int T=1;
			p++; // skip [
			val[T]=(int)S();
			if (resultType==BOOLEANTYPEBOX) pe(31,l); // E31
			while (*p==',') {
				p++; T++;
				if (T>MAXDIM) pe(26,l); // E26
				val[T]=(int)S();
				if (resultType==BOOLEANTYPEBOX) pe(31,l); // E31
			}
			/* check types */
			resultType=0;
			if (T!=vn[vn[ns].ref].dim) pe(6,l); // E06
			if (vn[vn[ns].ref].type==INTEGERTYPEBOX) {
				o=(int)getArrayVal(vn[ns].ref,vn[vn[ns].ref].dim,val);
				setResultType(INTEGERTYPEBOX);
			}
			else if (vn[vn[ns].ref].type==BOOLEANTYPEBOX) {
				o=(int)getArrayVal(vn[ns].ref,vn[vn[ns].ref].dim,val);
				setResultType(BOOLEANTYPEBOX);
			}
			else {
				o=getArrayVal(vn[ns].ref,vn[vn[ns].ref].dim,val); 
				setResultType(REALTYPEBOX);
			}
			if (*p==']') p++;
			else pe(1,l); // E01
			paren=FALSE;
			p--;
		}
	}
	/* MATH FUNCTIONS AND CONSTANTS */ 
	else switch(*p) {
		case 'A':
			/* ABS(x) absolute value function
			 * Domain: x -> R 
			 * Range:  y -> R+ : y >= 0 
			 * Simple Functions"*/
			if (!strncmp(p,"ABS(",4)) {
				p+=4;
				o=S();
				o=o>=0.0?o:-o;
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			/* ARCTAN(y) arc tangent function
			 * Domain: x -> R
			 * Range:  y -> R : -pi/2 < y < pi/2  */
			else if (!strncmp(p,"ARCTAN(",7)) {
				p+=7;
				o=S();
				o=atan(o);
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			else ERRVAL=0;
			break;
		case 'C':
			/* COS(x) cosine function 
			 * Domain: x -> R (angular measure) 
			 * Range:  y -> R : -1 <= y <= 1  */
			if (!strncmp(p,"COS(",4)) {
				p+=4;
				o=S();
				o=cos(o);
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			else ERRVAL=0;
			break;
		case 'E':
			/* ENTIER(x) integer value
			 * return the largest integer value not exceeding the 
			 * argument
			 * Domain: x -> R 
			 * Range:  y -> R : y >= 0 
			 * Ref. AA-O196C-TK - "5.1.2 "Special Functions"  
			 * Ref. ISO 1538-1984 (E) "The environmental block: 
			 * Simple Functions"*/
			if (!strncmp(p,"ENTIER(",7)) {
				int j;
				p+=7;
				o=S();
				j=(int)o;
				if (j>o) o=(double)j-1.0;
				else o=(double)j;
				resultType=0;
				setResultType(INTEGERTYPEBOX);
			}
			/* EVAL(str) evaluate math expression in string */
			else if (!strncmp(p,"EVAL(",5)) {
				char *pb;
				char str[COMPSTR];
				p+=5;
				if (isanystring(p)) strncpy_(str,SS(),COMPSTR);
				else pe(9,l);
				pb=p;
				p=str;
				o=S();
				if (*p) pe(9,l);
				resultType=0;
				setResultType(resultType);
				p=pb;
			}
			/* EXP(x) exponential function (base e)
			 * Domain: x -> R 
			 * Range:  y -> R : y >= 0 
			 * Ref. AA-O196C-TK - 17.1 "Mathematical Procedures"   
			 * Ref. ISO 1538-1984 (E) "The environmental block: 
			 * Mathematical Functions" */
			else if (!strncmp(p,"EXP(",4)) {
				p+=4;
				o=S();
				if (o>176.75253104) pe(21,l); // E21
				o=exp(o);
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			else ERRVAL=0;
			break;
		case 'F':
			/* FALSE constant
			 * ~return the false condition 0 
			 * Ref. AA-O196C-TK - 4.2 "OCTAL AND BOOLEAN 
			 * CONSTANTS" */
			if (!strncasecmp_(p,"FALSE",5) && !isnamechar((p+5))) {
				o=FALSE;
				p+=4;
				paren=FALSE;
				resultType=0;
				setResultType(BOOLEANTYPEBOX);
			}
			else ERRVAL=0;
			break;			
		case 'I':
			/* IF..THEN..ELSE
			 * ~conditional expression
			 * Ref. AA-O196C-TK - 14 "CONDITIONAL EXPRESSIONS AND 
			 * STATEMENTS" */
			if (!strncasecmp_(p,"IF",2)) {
				int cond=FALSE;
				int res1,res2;
				double o1=0,o2=0;
				p+=2;
				if (!check(p,"THEN")) pe(34,l); // E34
				cond=(int)S();
				if (resultType!=BOOLEANTYPEBOX) pe(29,l); // E29
				*p='T';
				p+=4; // skip THEN
				/* reload */
				if (!check(p,"ELSE")) pe(34,l); // E34
				o1=S(); res1=resultType;
				if (!*p) {
					l++;
					while (!m[l]) l++;
					if (l>endCore) pe(26,l); // E26
					strncpy_(BASESTR,m[l],COMPSTR);
					p=BASESTR;
				}
				*p='E';
				p+=4; // skip ELSE
				o2=S(); res2=resultType;
				/* reload */
				if (!*p) {
					l++;
					while (!m[l]) l++;
					if (l>endCore) pe(26,l); // E26
					strncpy_(BASESTR,m[l],COMPSTR);
					p=BASESTR;
				}
				if (cond) {
					o=o1;
					setResultType(res1);
				}
				else {
					o=o2;
					setResultType(res2);
				}
				p--;
				paren=FALSE;
			}
			else ERRVAL=0;
			break;
		case 'L':
			/* LN(x) natural logarithm function
			 * ~return the natural logarithm
			 * Domain: x -> R : x > 0 
			 * Range:  y -> R 
			 * Note: the case x=0 is treated 
			 * Ref. AA-O196C-TK - 17.1 "Mathematical Procedures"   
			 * Ref. ISO 1538-1984 (E) "The environmental block: 
			 * Mathematical Functions" */
			if (!strncmp(p,"LN(",3)) {
				p+=3;
				o=S();
				/* domain errors (negative and equal to zero) */
				if (o<0 || o<ZERO) { // o>0 here!
					pe(23,l); // E23
					o=-REALMAX; 
				}
				else o=log(o);
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			else ERRVAL=0;
			break;
		case 'S':
			/* SIGN(x) sign function 
			 * Domain: x -> R
			 * Range   y -> N, : y = -1 or 0 or 1 
			 * Ref. AA-O196C-TK - "5.1.2 "Special Functions"  
			 * Ref. ISO 1538-1984 (E) "The environmental block: 
			 * Simple Functions"*/
			if (!strncmp(p,"SIGN(",5)) {
				p+=5;
				o=sign(S()); 
				resultType=0;
				setResultType(INTEGERTYPEBOX);
			}
			/* SIN(x) sin function 
			 * Domain: x -> R (angular measure) 
			 * Range:  y -> R : -1 <= y <= 1 
			 * Ref. AA-O196C-TK - 17.1 "Mathematical Procedures"  
			 * Ref. ISO 1538-1984 (E) "The environmental block: 
			 * Mathematical Functions" */
			else if (!strncmp(p,"SIN(",4)) {
				p+=4;
				o=S();
				o=sin(o);
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			/* SIZE(x) string length function 
			 * ~return size of x string memory
			 * Note: neither in the Dartmouth ALGOL
			 * nor in the ISO 1538-1984 (E) */
			else if (!strncasecmp_(p,"SIZE(",5)) {
				int ns;
				p+=5;
				ns=findDEC(p);
				if (!ns || vn[ns].type!=STRINGTYPEBOX) pe(9,l); // E09
				p+=_len;
				o=strlen(PS[vn[ns].ref]);
				resultType=0;
				setResultType(INTEGERTYPEBOX);
			}	
			/* SQRT(x) square root function 
			 * Domain: x -> R : x >= 0 
			 * Range:  y -> R : y >= 0 
			 * Ref. AA-O196C-TK - 17.1 "Mathematical Procedures"  
			 * Ref. ISO 1538-1984 (E) "The environmental block: 
			 * Mathematical Functions" */ 
			else if (!strncmp(p,"SQRT(",5)) {
				p+=5;
				o=S();
				/* domain error */
				if (o<0.0) pe(22,l); // E22
				else o=sqrt(o);
				resultType=0;
				setResultType(REALTYPEBOX);
			}
			else ERRVAL=0;
			break;
		case 'T':
			/* TRUE constant
			 * ~return the true condition 
			 * Ref. AA-O196C-TK - 4.2 "OCTAL AND BOOLEAN 
			 * CONSTANTS" */
			if (!strncasecmp_(p,"TRUE",4) && !isalnum(*(p+4))) {
				o=TRUE;
				p+=3;
				paren=FALSE;
				resultType=0;
				setResultType(BOOLEANTYPEBOX);
			}	
			else ERRVAL=0;
			break;
		default:
			ERRVAL=0;
	}
	/* any other sequence of characters is an illegal function or
	 * illegal variable name */
	if (!ERRVAL && *p) {
		resultType=0;
		pe(11,l); // E11
	}
	/* check closing parenthesis for functions requiring an argument;
	 * p is updated into getVal() */
	if (paren) {
		if (!*p) pe(1,l); // E01
		else if (*p!=')') pe(1,l); // E01
	}
	/* return the sweated value */  
	return o;
}


/* stripBlanks()
 * strip 'in site' blanks from str; stop stripping while into a string
 * Note: two consecutive literal strings are joined, removing the quotes
 * and the inner blanks. The quoting must be consistent.  */
void stripBlanks(char *str) {
	char *sp=str, *kp=str;
	static int isStr=0;

	while (*kp) {
		if (*kp=='\"' && *(kp+1)=='\"') *sp++=*kp++, *sp++=*kp++;
		else if (*kp=='\"' && !isStr) isStr=1;
		else if (*kp=='\"' && isStr==1) isStr=0;
		else if (isdc(kp) && !isStr) isStr=2;
		else if (isdc(kp) && isStr==2) isStr=0;
		
		if (isStr==1) {
			*sp++=*kp++;
			if (*(sp-1)=='\"' && *(sp-2)=='\"') sp-=2;
		}
		else if (isblank(*kp)) while (isblank(*kp)) kp++;
		else {
			optoken(kp);
			*sp++=*kp++;
		}

	}
	while (kp>=sp) *kp--='\0';
}


/* optoken()
 * substitute per-character all found operators names with establishes symbols,
 * according to the following list:
 * ~PU for := and <- (assignment)
 * ~# for <> != ( ~= is performed internally)
 * ~^ for **
 * ~_ for AND
 * ~| for OR
 * ~& for EQUIV
 * ~% for IMPLY
 * ~{ for <=
 * ~} for >=
 * ~The substitution has the advantage to consider operators as one-char items
 * Note: using option d (debug), current line is always printed after 
 * tokenizing and blank-stripping, to see the 'real' string under evaluation
 * System function */
void optoken(char *q) {
	/* assignment */
	if (!strncasecmp_(q,":=",2)) 
		*q++=PU, *q=' ';
	/* inequality */
	else if (!strncasecmp_(q,"<>",2)) 
		*q++='#', *q=' ';
	else if (!strncasecmp_(q,"=/",2)) 
		*q++='#', *q=' ';
	else if (!strncasecmp_(q,"/=",2)) 
		*q++='#', *q=' ';
	/* exponentiation */
	else if (!strncasecmp_(q,"**",2)) 
		*q++='^', *q=' ';
	/* AND */
	else if (!strncasecmp_(q,"AND",3) && isante(q) && ispost(q+2))
		*q++='_', *q++=' ', *q=' ';
	/* OR */
	else if (!strncasecmp_(q,"OR",2) && isante(q) && ispost(q+1))
		*q++='|', *q=' ';
	/* equivalence */
	else if (!strncasecmp_(q,"EQUIV",5))
		*q++='&', *q++=' ', *q++=' ', *q++=' ', *q=' ';
	/* implication */
	else if (!strncasecmp_(q,"IMPLY",5))
		*q++='%', *q++=' ', *q++=' ', *q++=' ', *q=' ';
	/* lesser or equal */
	else if (!strncasecmp_(q,"<=",2)) 
		*q++='{', *q=' ';
	/* greater or equal */
	else if (!strncasecmp_(q,">=",2)) 
		*q++='}', *q=' ';
	/* remainder */
	else if (!strncasecmp_(q,"MOD",3) && isante(q) && ispost(q+2))
		*q++='`', *q++=' ', *q=' ';
}


/******************************************************************************
 * The following functions define general system environment subroutines: 
 * they are internal routines not directly accessible as ALGOL 60 statements.
 ******************************************************************************/

/*****************************************
 *            STATEMENTS AID             *
 *****************************************/


/* setupName()
 * check file name, returning correct file name with extension "alg", if not
 * specified for an inexistent file
 * System function for file treatment */
void setupName(char *fn) {
	int isExt=TRUE;
        char *q=fn, ext[COMPSTR], tempf[COMPSCR];
	FILE *fd;

	/* setup defaults */
	ext[0]='\0';

	/* check if the input file is a directory */
	stat(fn, &statbuf);
	if (S_ISDIR(statbuf.st_mode)) {
		beginS=-1;
		fprintf(stderr,"%s\n",error[50]); // move 1 to 50
		exit(EXIT_FAILURE);
	}
	
	/* find extension start (and check eventual specifiers set after
	 * extension in place of after the name) */
	while (*q) q++;
	while (*fn=='.') fn++;
	while (*q !='.' && q > fn) q--;

	/* there is an extension */
	if (q > fn) {
		strncpy_(ext,q,COMPSTR);
		*q='\0';
		q--;
	}
	/* there's no extension */
	else {
		if ((int)strlen(q)>0) q=fn+(int)strlen(q)-1;
		isExt=FALSE;
	}

	/* if a dot was printed, but no extension specified, remove the dot */
	if (!strcasecmp(ext,".")) ext[0]='\0', isExt=FALSE;

	/* if an extension was given as input, attach it */
	if (isExt) strncat_(fn, ext, COMPSCR);
	/* search for implicit extension or check if it's needed */
	else {
		/* first attempt: the name alone, extension not present */
		sprintw(tempf,COMPSCR,"%s",fn);
		if ((fd=fopen(tempf,"r"))) {
			fclose(fd);
			return;
		}
		/* second attempt: .ALG extension not specified */
		sprintw(tempf,COMPSCR,"%s%s",fn,EXTU);
		if ((fd=fopen(tempf,"r"))) {
			fclose(fd);
			strncat_(fn,EXTU,COMPSCR);
			return;
		}
		/* third attempt: .alg extension not specified */
		sprintw(tempf,COMPSCR,"%s%s",fn,EXTL);
		if ((fd=fopen(tempf,"r"))) {
			fclose(fd);
			strncat_(fn,EXTL,COMPSCR);
			return;
		}
	}
}


/* isanystring(string-position)
 * System function */
int isanystring(char *lp) {
	int ftype=0, ns=0;
	ns=findPROC(lp,NULL,&ftype);
	ns=findDEC(lp);
	if (ns && _type==STRINGTYPEBOX) return TRUE;
	if (*lp=='\"') return TRUE;
	/* consider all string functions */
	else if (!strncmp(lp,"CONCAT(",7)) return TRUE;
	return FALSE;
}	


/* dimArray(matrix-index,type,dimensions width)
 * dimension a numerical array allocating the necessary memory space.
 * var: the index of the variable holding the matrix name
 * T: matrix type, 1 for unidimensional vectors, 2 for matrices
 * val: the array of dimensions
 * Note: all elements of declared array elements are set to 0.0 = zero. 
 * System function for the ARRAY management */
int dimArray(int var, int T, int *val) {
	int i;
	int size=1;
	for (i=1;i<=T;i++) size*=(val[i]+1);
	size+=1; // safety space
	size*=sizeof(double);

	/* reserve memory space for the array */
	dim[var].elem=nalloc((size_t)size);  
	if (!dim[var].elem) pe(13,l); // E26

	/* erase every element */
	for (i=0;i<=size;i++) *(dim[var].elem+i)=0;
	return size;
}	


/* getArrayVal(matrix-index,type,positions)
 * get value of an element of a numerical array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix dimension coming from the calling instance
 * val: the local dimensions required array
 * System function for the ARRAY management */
double getArrayVal(int var, int t, int *val) {
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) pe(6,l); // E06
	/* check bounds and update values to var offsets */
	for (i=1; i<=t; i++) {
		if (val[i]<vn[var].offset[i] || val[i]>vn[var].ldim[i]+vn[var].offset[i]) 
			pe(24,l); // E24
		res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	}
	return *(dim[var].elem+res);
}


/* setArrayVal(matrix-index,type,positions)
 * set an element of a numerical array to a specific value, given the value 
 * itself and the element coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix dimension coming from the calling instance
 * val: the local dimensions required array
 * num: the value to be stored
 * System function for the ARRAY management */
void setArrayVal(int var, int t, int *val, double num){
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) pe(6,l); // E06
	/* check bounds and update values to var offsets */
	for (i=1; i<=t; i++) {
		if (val[i]<vn[var].offset[i] || val[i]>vn[var].ldim[i]+vn[var].offset[i]) 
			pe(24,l); // E24
		res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	}
	*(dim[var].elem+res)=num;
}


/* dimStrArray(matrix-index,type,dimensions width)
 * dimension a string array, allocating the necessary memory space; 
 * var: the index of the variable holding the matrix name
 * T: the matrix type, 1 for unidimensional vectors, 2 for matrices (currently
 *    not available)
 * val: the array of dimensions
 * Note: all elements of declared array are set to the void string.
 * System function for the ARRAY management */
int dimStrArray(int var, int T, int *val) {
	int i;
	int size=1;
	for (i=1;i<=T;i++) size*=(val[i]+1);
	size+=1; // safety space
	size*=COMPSTR;

	/* reserve memory space for the array */
	dimS[var].elem=salloc((size_t)size);  
	if (!dimS[var].elem) pe(24,l); // E24

	/* erase all array elements */
	for (i=0;i<size;i++) *(dimS[var].elem+i)='\0';
	return size;
}		


/* getArrayStr(matrix-index,type,positions)
 * get value of an element of a string array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * T: matrix dimension, 1 for unidimensional vectors, 2 for matrices, 3,4,...
 * val: the local dimensions required numbers
 * System function for the ARRAY management */
char *getArrayStr(int var, int t, int *val) {
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) pe(6,l); // E06
	/* check bounds and update values to var offsets */
	for (i=1; i<=t; i++) {
		if (val[i]<vn[var].offset[i] || val[i]>vn[var].ldim[i]+vn[var].offset[i]) 
			pe(24,l); // E24
		res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	}
	res*=COMPSTR;
	return dimS[var].elem+res;
}


/* setArrayStr(matrix-index,type,positions,value)
 * set an element of a string array to a specific value, given the value itself 
 * and the element coordinates 
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices
 * var: the index of the variable holding the matrix name
 * val: the local dimensions required numbers
 * str: the value to be stored
 * System function for the ARRAY management */
void setArrayStr(int var, int t, int *val, char *str){
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) pe(6,l); // E06
	/* check bounds and update values to var offsets */
	for (i=1; i<=t; i++) {
		if (val[i]<vn[var].offset[i] || val[i]>vn[var].ldim[i]+vn[var].offset[i]) {
			pe(24,l); // E24
		}
		res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	}
	res*=COMPSTR;
	strncpy_(dimS[var].elem+res,str,COMPSTR);
}


/* getBound()
 * return the lowest or the upper bound of array in argument.
 * The request is in the form LB/UB(V,N), where V is the array name and
 * N is the dimension.
 * if mode = TRUE search for UB (upper bound)
 * if mode = FALSE, search for LB (lower bound)
 * if mode = MAXDIM return dimension for DIM
 * system function for the LB and UB functions */
int getBound(int mode) {
	int ub=0,cs=0;
	int alt=1;

	/* get array name */
	forceArray=TRUE;
	cs=findDEC(p);
	if (cs && _arr) p+=_len;
	else pe(5,l); // E05
	forceArray=FALSE;
	/* DIM returns dimension of the array */
	if (mode==MAXDIM) return vn[vn[cs].ref].dim;
	/* dimension index is expicit */
	if (*p==',') {
		p++;
		alt=(int)S();
	}
	else pe(2,l); // E02

	/* LB returns always the offset */
	if (!mode) ub=vn[vn[cs].ref].offset[alt];
	/* UB returns the upper value */
	else ub=vn[vn[cs].ref].offset[alt]+vn[vn[cs].ref].ldim[alt];
	return ub;
}


/* SETRAN()
 * perform the SETRAN procedure 
 * Ref. AA-O196C-TK - 17.8 "Random Number Routine" */
void SETRAN(void) {
	int ra=S();
	/* evaluate number */
	RANDOMIZE(ra);
	if (*p==')') p++;
	else pe(1,l); // E01
}


/* RANDOMIZE()
 * perform the SETRAN procedure.
 * If called with argument null, it set the random generation depending on
 * current time, according to the following algorithm:
 *   - divide current 'usec' measure with the sum of the value obtained summing 
 *     months (12), days (31), hours (23), minutes (59) and seconds (59), which 
 *     always gives 184;
 *   - divide this value (always in the range [1,184]) with the logarithm of 
 *     276.00 which is 184.00x1.5, obtaining a value between 0.177923252 and 
 *     32.73787838, a range with medium value 16.45790082, the starting default
 *     value of the getRandom() function 
 * if an argument different from zero is given, this argument is used to set 
 * the random generation.
 * Note: at start, ALGOL calls RANDOMIZE(0), whereas SETRAN(X) calls 
 * RANDOMIZE(x).
 * Used in conjunction with the getRandom() function. */
void RANDOMIZE(int seed) {
	int b;
	if (!seed) {
		gettimeofday(&tv, NULL);
	       	b = tv.tv_usec%184;
		randSeed=(int)(133.5611413*b+4095.875);
	}
	else randSeed=abs(seed);
	if (!randSeed%2) randSeed++;
}


/* findPROC() 
 * find procedure in current parsing line searching among data found by 
 * preParse()
 * p points to the PROC name in getFunc(), exec() or SS() 
 * return in p2 updated position of p (just after the proc name), unless
 * p2 is NIL
 * store in type and mode relative values for an immediate check 
 * type=TYPEBOX
 * System function for the PROCEDURE management */
int findPROC(char *p, char **p2, int *type) {
	int i=procTOS, dots=0,cn=0;
	char name[COMPSTR], *n=name;

	/* reset length */
	_len=0;

	if (!*p) return FALSE;

	/* get PROC name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p) && cn<NAMEDIM) {
			if (*p=='.' && isalnum(*(p+1))) {
				p++;
				dots++;
				continue;
			}
			*n++=*p++;
			cn++;
		}
		*n='\0';
	}
	else return FALSE;
	if (cn>=NAMEDIM) return FALSE;
	_len=(int)strlen(name)+dots;
	if (!_len || !name[0]) return FALSE;

	/* return immediately if it's last call */
	if (!strcmp(rememberName,name)) {
		if (p2) *p2=p;
		*type=Procp[rememberCode].type;
		return rememberCode;
	}

	/*  find PROC */
	while (i>0) {
		if (!strcmp(Procp[i].name,name)) {
			*type=Procp[i].type;
			if (p2) *p2=p;
			/* remember last... */
			strncpy_(rememberName,Procp[i].name,NAMEDIM);
			rememberCode=i;
			return i;
		}
		i--;
	}
	/* restore p: PROC not found */
	if (p2) *p2=p+strlen(name);
	return FALSE;
}


/* checkProcCall()
 * check if procedure is retrievable 
 * (basing on the fact that a recursive call must not see the 
 * sister procedures as proper */
int checkProcCall(int cnp) {
	if (pexec[pexecTOS-2]==pexec[pexecTOS-1]) return FALSE;
	return TRUE;
}


/* checkProcExec() 
 * check if procedure is callable (dependence) 
 * ~Step 1: at level pexecTOS-1 there's current procedure code,
 * at level pexecTOS-2 there's caller procedure code; if they
 * don't match the procedure is not calling itself.
 * ~Step 2: in Procp[cnp].procref there's the reference code
 * of the procedure (the code of the ambient where it lies); if it's
 * null no check is done because any procedure at level 0 is callable.
 * ~Step 3: in case a control has to be done, the check is done
 * by confronting the the caller procedure code with the reference
 * code of the current procedure: if they don't match the procedure
 * is not callable. */
int checkProcExec(void) {
	int this, caller, number, callernumber, procref, callerprocref;
	this=pexec[pexecTOS-1];
	caller=pexec[pexecTOS-2];
	procref=Procp[this].procref;
	number=Procp[this].number;
	callerprocref=Procp[caller].procref;
	callernumber=Procp[caller].number;
	do {
		if (procref<0) return TRUE;
		if (procref==callernumber) return TRUE;
		if (procref==callerprocref) return TRUE;
		if (number==callerprocref) return TRUE;
		caller=Procp[caller].procref;
		callerprocref=Procp[caller].procref;
		callernumber=Procp[caller].number;
	} while (callerprocref>=0);
	return FALSE;
}


/* execPROC() 
 * execute a subroutine; 
 * data relative to the PROC are preprocessed by preParse(), in order for 
 * execPROC to run. Must be run if findPROC returned a positive value.
 * cnp: the procedure number found by findPROC()
 * pc: the position in the incoming string where arguments (if any) are stored,
 *     pointing to the character after PROC name. pc is used local, instead of
 *     global p, because execPROC() is supposed to execute any type of string
 * numres: the double result pointer
 * strres; the string result pointer
 * return the updated position of program pointer in pc
 * manage the recursion
 * System function for the PROC management 
 * Ref. AA-0196C-TK - 11 "Procedures" */
char *execPROC(int cnp, char *pc, double *numres, char *strres) {
	char cnpname[COMPSTR], *pcb;
	char BB[COMPSTR]; // for BASESTR backup
	int decBack=decCount, procBack=procTOS, cnt, ic;
	int lb=l, isBackProcTime, i=0;
	TProcP backP;
	int wasPassedByName=FALSE; // to recover cnp data at the end 

	/* set execution reference */
	pexec[pexecTOS++]=cnp;
	if (pexecTOS>=LIMIT) {
		p=pc;
		pe(26,l); // E26
	}

	/* set for functions called by name-passing: in this case
	 * determine the original function and set this current cnp to
	 * be perfectly equal to the called qs */
	while (Procp[cnp].numvars<0) {
		int type;
		int qs=findPROC(Procp[cnp].strdata,NIL,&type);
		if (qs) {
			backP=Procp[cnp];	
			Procp[cnp]=Procp[qs];
			wasPassedByName=TRUE;
		}
	}

	/* PROC does not exist */
	if (!Procp[cnp].number) {
		p=pc;
		pe(11,l); // E11
	}
	
	/* create fictitious block */
	beginTOS++;
	if (beginTOS>=LIMIT) {
		p=pc;
		pe(26,l); // E26
	}
	beginDepth[beginTOS]=decCount;
	
	/* check if procedure is callable  */
	if (!checkProcExec()) {
		p=pc;
		pe(11,l); // E11
	}

	Procp[cnp].numres=0.0;
	Procp[cnp].strres[0]='\0';
	
	/* store current proc name for future usage */
	strncpy_(cnpname,Procp[cnp].name,NAMEDIM);

	/* in case of return value, declare a fictitious variable with 
	 * the same name of the procedure
	 * Note: return value for procedure is a simple value, not
	 * an array (at least I've never read of such feature neither in 
	 * the DEC manual nor in the ISO document. */
	decCount++;
	if (decCount>=LIMIT) {
		p=pc;
		pe(26,l); // E26
	}
	/* FICTITIOUS VARIABLE */
	strncpy_(vn[decCount].name,cnpname,NAMEDIM);
	vn[decCount].type=Procp[cnp].type;
	vn[decCount].isArr=FALSE;		
	vn[decCount].ref=decCount;
	vn[decCount].refcode=decCount;
	vn[decCount].proccode=0;
	vn[decCount].dim=0;
	vn[decCount].size=0;
	vn[decCount].strmem=COMPSTR;
	vn[decCount].isOwn=0;
	vn[decCount].proccode=Procp[cnp].number;
	vn[decCount].isFict=TRUE;
	vn[decCount].isFunc=FALSE;
	vn[decCount].line=l;
	vn[decCount].level=pexecTOS;
	for (i=0;i<MAXDIM;i++) {
		vn[decCount].ldim[i]=0;
		vn[decCount].offset[i]=0;
		vn[decCount].coeff[i]=0;
	}
	for (i=0;i<COMPSTR;i++) {
		vn[decCount].valdata[i]='\0';
		vn[decCount].strdata[i]='\0';
	}
	/* reserve memory for string variables and reset values */
	if (Procp[cnp].type==STRINGTYPEBOX || Procp[cnp].type==LABELTYPEBOX) {
		PS[decCount]=calloc(vn[decCount].strmem,sizeof(char)*vn[decCount].strmem);
		if (!PS[decCount]) {
			p=pc;
			pe(11,l); // E11
		}
		PS[decCount][0]='\0';
	}
	else P[decCount]=0.0;
	
	/* if there are arguments store them... */
	if (*pc=='(')  {
		cnt=0;
		ic=1;
		++pc; // skip '('
		/* cycle through PROC arguments and get values to be used in
		 * case of BYVAL; in case of BYREF, set reference to the one
		 * of the calling entity. 
		 * cnt holds number of arguments of called proc, stored by 
		 * preParse() in Proc[cnp].numvars (which must be respected) */
		while (cnt < Procp[cnp].numvars) {
			char wname[COMPSTR],*wp=wname;
			char ename[COMPSTR],*ep=ename;
			int isNotAFunc=FALSE;
			int type, mode, state;
			int isP=0;
			cnt++;
			if (cnt>MAXDIM) {
				p=pc;
				pe(26,l); // E26
			}
		
			/* wrong number of arguments */
			if (cnt>Procp[cnp].numvars) {
				p=pc;
				pe(25,l); // E25
			}
			if (*pc==')' && cnt<=Procp[cnp].numvars) {
				p=pc;
				pe(25,l); // E25
			}
			/* get name of runtime argument (WW) 
			 * Note: argument may be a variable name, a string
			 * enclosed in quotes or a number, whose first
			 * character is the dot, the minus or &,@ or a digit.*/
			while (*pc && *pc!=',' && *pc!=')' && *pc!=']') {
				if (*pc=='(') {
					int st=0;
					*wp++=*pc++; // copy (
					while (*pc) {
						if (*pc=='(') st++;
						else if (*pc==')' && st) st--;
						else if (*pc==')' && !st) break;
						*wp++=*pc++;
					}
				}
				else if (*pc=='[') {
					int st=0;
					*wp++=*pc++; // copy [
					while (*pc) {
						if (*pc=='[') st++;
						else if (*pc==']' && st) st--;
						else if (*pc==']' && !st) break;
						*wp++=*pc++;
					}
					if (*pc==',' || *pc==')');
					else isNotAFunc=TRUE;	
				}
				*wp++=*pc++;
			}
			*wp='\0';
			/* get name of stored argument (E) */
			while (Procp[cnp].vars[ic]>0) 
				*ep++=Procp[cnp].vars[ic++];
			*ep='\0';
			ic++; // skip -1
			type=Procp[cnp].vars[ic++]-DECADD;
			mode=Procp[cnp].vars[ic++]-DECADD;
			state=Procp[cnp].vars[ic++]-DECADD;
			ic++; // skip -2

			/* FUNCTION CALL IN PLACE */
			/* maybe a procedure is passed? */
			isP=findPROC(wname,NIL,&type);
			/* recognized: instantiate procedure; */
			if (state==ISPROC && isP && !isNotAFunc) {
				procTOS++;
				if (procTOS>=LIMIT) {
					p=pc;
					pe(26,l); // E26
				}
				strncpy_(Procp[procTOS].name,ename,NAMEDIM);
				strncpy_(Procp[procTOS].strdata,wname,COMPSTR);
				Procp[procTOS].procref=cnp;
				Procp[procTOS].procL=-1;
				Procp[procTOS].procP=-1;
				Procp[procTOS].begnL=-1;
				Procp[procTOS].begnP=-1;
				Procp[procTOS].termL=-1;
				Procp[procTOS].termP=-1;
				Procp[procTOS].numvars=-1;
				Procp[procTOS].number=procTOS;
				Procp[procTOS].type=type;
			}
			else if (state==ISPROC) {
				pe(25,l); // E25
			}
			/* INSTANTIATE VARIABLE OR ARRAY */
			else {
				int isEArr=FALSE; // is Array Element
				int isExpr=FALSE; // is an Expression
				double valres=0.0;
				char strres[COMPSTR];
				int labres=0, ns=0, j;
				int bforceArray=forceArray;
				int thisdecCount=decCount;

				/* FIND IF THERE IS AN ASSOCIATED VARIABLE
				 * (for possible later usage for BYREF)
				 * reduce decCount otherwise it would search 
				 * in the already declared variables... */
				decCount=decBack;
				if (state==ISARR) forceArray=TRUE;
				ns=findDEC(wname);
				if (state==ISARR) forceArray=bforceArray;
				decCount=thisdecCount;  // restore
				/* search if found */
				if (ns) {
					char *q=wname+_len;
					int st=0;
					while (ns!=vn[ns].ref) ns=vn[ns].ref; 
					/* the variable is an expicit array */
					if (*q=='[') {
						q++; // skip [
						while (*q && *q!=']') {
							if (*q=='[') st++;
							else if (*q==']'&&st) 
								st--;
							else if (*q==']'&&!st) 
								break;
							q++;
						}
						if (*q==']') q++; // skip ]
						if (!*q) isEArr=TRUE;
						else isExpr=TRUE;
					}
					/* variable is part of an expression */
					else if (*q && *q!=',' && *q!=')') {
						ns=0;
						isExpr=TRUE;
					}
				}
				else isExpr=TRUE;

				/* DETERMINE CURRENT BARE VALUE 
				 * of the item passed to the procedure */
				if (!isP && type<STRINGTYPEBOX && state!=ISARR && mode==BYVAL) {
					char *pb=p;
					p=wname;
					valres=S();
					p=pb;
				}
				else if (!isP && type==STRINGTYPEBOX && state!=ISARR) {
					char *pb=p;
					p=wname;
					strncpy_(strres,SS(),COMPSTR);
					p=pb;
				}
				else if (!isP && type==LABELTYPEBOX && state!=ISARR) {
					char *pb=p;
					p=wname;
					labres=getLabelIndex();
					p=pb;
				}
				else if (isExpr && mode==BYREF) pe(40,l);

				/* DO THE INSTANTIATION */
				decCount++;
				if (decCount>=LIMIT) {
					p=pc;
					pe(26,l); // E26
				}
				/* SET FUNDAMENTAL PARAMETERS
				 * name, type and procedure coding */
				for (j=0;j<COMPSTR;j++) vn[decCount].strdata[j]='\0';
				j=0;
				while (ename[j]) vn[decCount].name[j]=ename[j], j++;
				while (j<COMPSTR) vn[decCount].name[j]='\0', j++;
				vn[decCount].type=type;
				vn[decCount].proccode=Procp[cnp].number;
				vn[decCount].isFict=FALSE;
				vn[decCount].line=l;
				vn[decCount].level=pexecTOS;
				/* label items are always passed by value 
				 * TODO: decide if it's an error */
				if (type==LABELTYPEBOX) mode=BYVAL;
				
				/* SET THE ASSOCIATED FUNCTION IF ANY
				 * (for possible later usage as expression) */
				vn[decCount].isFunc=findPROC(wname,NIL,&type);
				/* DEFINE VARIABLE PARAMETERS:
				 * case of expression (we know that ns 
				 * is null or it does not matter)*/
				if (isExpr) {
					for (j=0;j<COMPSTR;j++) vn[decCount].valdata[j]=wname[j];
					vn[decCount].isOwn=FALSE;
					vn[decCount].isArr=FALSE;
					vn[decCount].strmem=COMPSTR;
					if (mode==BYVAL) {
					   vn[decCount].ref=decCount;
					   vn[decCount].refcode=decCount;
					}
					else if (mode==BYREF) {
					   vn[decCount].ref=decCount;
					   vn[decCount].refcode=-decCount-DECADD;
					}
				}
				/* DEFINE VARIABLE PARAMETERS:
				 * case of simple variable or array:
				 * isExpr FALSE and isEArr FALSE */
				else if (!isExpr && !isEArr) {
					for (j=0;j<COMPSTR;j++) vn[decCount].valdata[j]=wname[j];
					vn[decCount].isOwn=FALSE;
					vn[decCount].isArr=state==ISARR;
					vn[decCount].strmem=COMPSTR;
					if (mode==BYVAL) { 
					   vn[decCount].ref=decCount;
					   vn[decCount].refcode=decCount;
					}
					else if (mode==BYREF) {
					   vn[decCount].ref=ns;
					   vn[decCount].refcode=-ns;
					}
				}
				/* DEFINE VARIABLE PARAMETERS:
				 * case of an array element passed */
				else if (!isExpr && isEArr) {
					for (j=0;j<COMPSTR;j++) vn[decCount].valdata[j]=wname[j];
					vn[decCount].isOwn=FALSE;
					vn[decCount].isArr=FALSE;
					vn[decCount].strmem=COMPSTR;
					if (mode==BYVAL) {
					   vn[decCount].ref=decCount;
					   vn[decCount].refcode=-decCount-DECADD;
					}
					else if (mode==BYREF) {
					   vn[decCount].ref=ns;
					   vn[decCount].refcode=-ns-DECADD; 
					}
				}

				/* SET CURRENT VALUES: NUMERIC ARRAYS
				 * instantiate numeric array */
				if (state==ISARR && mode==BYVAL && type<STRINGTYPEBOX && !isExpr && !isEArr) {
					int j;
					for (j=0;j<MAXDIM;j++) {
					   vn[decCount].ldim[j]=vn[ns].ldim[j];
					   vn[decCount].offset[j]=vn[ns].offset[j];
					   vn[decCount].coeff[j]=vn[ns].coeff[j];
					}
					vn[decCount].size=vn[ns].size;
					vn[decCount].dim=vn[ns].dim;
					dimArray(decCount,vn[decCount].dim,vn[decCount].ldim);
					memcpy(dim[decCount].elem,dim[ns].elem,vn[ns].size);
				}
				/* SET CURRENT VALUES: STRING ARRAYS
				 * instantiate string array */
				else if (state==ISARR && mode==BYVAL && type<NOTYPEBOX && !isExpr && !isEArr) {
					int j;
					for (j=0;j<MAXDIM;j++) {
					   vn[decCount].ldim[j]=vn[ns].ldim[j];
					   vn[decCount].offset[j]=vn[ns].offset[j];
					   vn[decCount].coeff[j]=vn[ns].coeff[j];
					}
					vn[decCount].size=vn[ns].size;
					vn[decCount].dim=vn[ns].dim;
					dimStrArray(decCount,vn[decCount].dim,vn[decCount].ldim);
					memcpy(dimS[decCount].elem,dimS[ns].elem,vn[ns].size);
				}
				/* SET CURRENT VALUE: NUMERIC VARIABLE
				 * instantiate numeric variable */
				else if (type<STRINGTYPEBOX) {
					P[decCount]=valres;
					for (j=0;j<MAXDIM;j++) {
					   vn[decCount].ldim[j]=0;
					   vn[decCount].offset[j]=0;
					   vn[decCount].coeff[j]=0;
					}
					vn[decCount].dim=0;
					vn[decCount].size=0;
				}
				/* SET CURRENT VALUE: STRING VARIABLE
				 * instantiate string variable */
				else if (type==STRINGTYPEBOX) {
					PS[decCount]=salloc(strlen(strres)+1);
					if (!PS[decCount]) pe(9,l); // E09
					strncpy_(PS[decCount],strres,strlen(strres)+1);
					strncpy_(vn[decCount].valdata,strres,COMPSTR);
					for (j=0;j<MAXDIM;j++) {
					   vn[decCount].ldim[j]=0;
					   vn[decCount].offset[j]=0;
					   vn[decCount].coeff[j]=0;
					}
					vn[decCount].dim=0;
					vn[decCount].size=0;
				}
				/* SET CURRENT VALUE: LABEL VARIABLE
				 * instantiate label variable */
				else if (type<NOTYPEBOX) {
					P[decCount]=labres;
					for (j=0;j<MAXDIM;j++) {
					   vn[decCount].ldim[j]=0;
					   vn[decCount].offset[j]=0;
					   vn[decCount].coeff[j]=0;
					}
					vn[decCount].dim=0;
					vn[decCount].size=0;
				}

				/* a BYREF which is passed an expression
				 * can be read but not written 
				 * 2*DECADD forces assign() to emit an error */
				if (isExpr && mode==BYREF)
					vn[decCount].refcode=2*DECADD;
			}
			/* next variable */
			if (*pc==',') pc++;
			/* manage comments interspersed with arguments */
			else if (*pc==')' && cnt<Procp[cnp].numvars && strcasestr_oq(pc,":(")) {
				while (*pc!=':') pc++;
				pc++; // skip :
				pc++; // skip (
			}
		}
	}
	/* ...otherwise set current counter to void */
	else cnt=0;

	/* wrong number of arguments */
	if (Procp[cnp].numvars!=cnt) {
		p=pc;
		pe(25,l); // E25
	}
	if (cnt) {
	       if (*pc==')') pc++;
	       else {
		       p=pc;
		       pe(1,l); // E01
	       }
	}

	/* execute procedure */
	isBackProcTime=isProcTime;
	isProcTime=cnp;
	strncpy_(BB,BASESTR,COMPSTR);
	l=Procp[cnp].begnL;
	strncpy_(BASESTR,m[l],COMPSTR);
	p=BASESTR+Procp[cnp].begnP;
	pcb=pc;
	/* execute procedure.
	 * If a GOTO occurs, LL is set, signalling to the system that a
	 * a GOTO has occurred; it's doBegin() that, using LL and PL,
	 * will set the new Program Counter; so execPROC() ceases any 
	 * responsibility for what about the destination */
	go(l);

	/* restore line */
	l=lb;
	pc=pcb;

	/* assign results */
	if (Procp[cnp].type<NOTYPEBOX) {
		if (Procp[cnp].type==LABELTYPEBOX)
			*numres=Procp[cnp].numres;
		else if (Procp[cnp].type<STRINGTYPEBOX)
			*numres=Procp[cnp].numres;
		else strncpy_(strres,Procp[cnp].strres,COMPSTR);
	}
	
	/* restore and reset values as priorly to the procedure execution, 
	 * and reset variables used data */
	for (ic=decCount;ic>decBack;ic--) {
		int i;
		for (i=0;i<COMPSTR;i++) {
			vn[ic].name[i]='\0';
			vn[ic].strdata[i]='\0';
			vn[ic].valdata[i]='\0';
		}
		vn[ic].type=NOTYPEBOX;
		vn[ic].isArr=FALSE;
		vn[ic].ref=0;
		vn[ic].dim=0;
		for (i=0;i<MAXDIM;i++) {
			vn[ic].ldim[i]=0;
			vn[ic].offset[i]=0;
			vn[ic].coeff[i]=0;
		}
		vn[ic].size=0;
		vn[ic].strmem=0;
		vn[ic].isOwn=FALSE;
		vn[ic].refcode=0;
		vn[ic].proccode=0;
		vn[ic].isFunc=FALSE;
		vn[ic].isFict=0;
		vn[ic].line=0;
		vn[ic].level=-1;
	}
	decCount=decBack;
	isProcTime=isBackProcTime;
	strncpy_(BASESTR,BB,COMPSTR);
	procTOS=procBack;
	if (wasPassedByName) Procp[cnp]=backP;	
	pexecTOS--;
	if (beginTOS>0) beginTOS--;
	return p=pc;
} // end of execPROC


/* isValid()
 * return TRUE if str does not point to THEN, ELSE,DO,STEP,WHILE,UNTIL 
 * which interfere witht the parses */
int isValid(char *str) {
	if (!strncasecmp_(str,"THEN",4))  return FALSE;
	if (!strncasecmp_(str,"ELSE",4))  return FALSE;
	if (!strncasecmp_(str,"DO",2))    return FALSE;
	if (!strncasecmp_(str,"STEP",4))  return FALSE;
	if (!strncasecmp_(str,"WHILE",5)) return FALSE;
	if (!strncasecmp_(str,"UNTIL",5)) return FALSE;
	return TRUE;
}


/* findDEC() 
 * find a declared variable/array (DEC) in the vn[] structure;
 * lp points to the DEC name in getFunc(), assign() or SS() and get its value;
 * store in _len the length of the variable name
 * store in _type relative values for an immediate check
 * store in _arr the array flag
 * System function for the declare management */
int findDEC(char *lp) {
	int i=decCount, dots=0,cn=0;
	char name[COMPSTR], *n=name;
	int lArray=FALSE;	// locally detection of arrays
	int found=FALSE;
	int subscript=FALSE;

	/* set anyway a valid value as a safety measure */	
	_len=0;
	_arr=0;
	_type=0;

	if (!*lp) return FALSE;

	/* get DEC name (up to NAMEDIM characters) */
	if (isbeginnamechar(lp)) {
		while (isnamechar(lp) && cn<NAMEDIM && isValid(lp)) {
			if (*lp=='.' && isalnum(*(lp+1))) {
				lp++;
				dots++;
				continue;
			}
			*n++=*lp++, cn++;
		}
		*n='\0';
	}
	else return FALSE;
	if (cn>=NAMEDIM && isnamechar(lp)) return FALSE;
	_len=(int)strlen(name)+dots;
	if (!_len || !name[0]) return FALSE;
	/* determine byte subscript */
	if (*(lp-1)=='.' && *lp=='[') {
		subscript=TRUE;
		*--n='\0';
		_len--;
	}
	else if (*(lp-1)!='.' && *lp=='[') lArray=TRUE;

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (!strcmp(vn[i].name,name)) {
			if (!vn[i].isArr && !forceArray && !lArray)
				found=TRUE;
			else if (vn[i].isArr && lArray) 
				found=TRUE;
			else if (vn[i].isArr && !lArray && forceArray)
				found=TRUE;
			if (found) {
				if (!subscript) _type=vn[i].type;
				else _type=CHAR;
				_arr=vn[i].isArr;
				return i;
			}
		}
		found=FALSE;
		i--;
	}

	/* DEC irremediably not found */
	_type=0;
	_len=0;
	return FALSE;
}


/*****************************************
 *             MATH & TIME               *
 *****************************************/

/* sign()
 * if argument is positive, return 1
 * if argument is negative, return -1
 * if argument is exactly zero, return 0 */
int sign(double s) {
	if (s<0) return -1;
	else if (s>0) return 1;
	return 0;
}


/* getTime()
 * return current time structure */
struct tm *getTime(void) {
	time_t st_lt;
	st_lt=time(NULL);
	return localtime(&st_lt);
}


/* getMin()
 * return current min (0-59) */
int getMin(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_min;
}


/* getSec()
 * return current second (0-59) */
int getSec(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_sec;
}


/* getHour()
 * return current hour (0-23) */
int getHour(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_hour;
}


/* getDay()
 * return current day (1-31) */
int getDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_mday;
}


/* getMonth()
 * return current month (1-12) */
int getMonth(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_mon+1);
}


/* getYear()
 * return current year */
int getYear(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_year+1900);
}


/* getMonthString()
 * return current month string 
 * if t is TRUE perform FDATE (abbreviated month)
 * while if FALSE perform VDATE (complete month) */
char *getMonthString(int t) {
	if (t) return cmonth[getMonth()];
	return month[getMonth()];
}


/* exp_()
 * wrapper for the exp functions 
 * Ref. ISO 1538-1984 (E) - page 7, par. 3.3.4.3 */
double exp_(int typex, double x, int typei, double i) {
	/* real exponent on any base */
	if (typex<=INTEGERTYPEBOX && typei<INTEGERTYPEBOX) {
		if (x>0.0) return exp(i*log(x));
		else if (x==0.0 && i>0.0) return 0.0;
		else if (x==0.0 && i==0.0) return 1.0;
		else pe(27,l); // E27
	}
	/* integer exponent on integer base */
	else if (typex==INTEGERTYPEBOX && typei==INTEGERTYPEBOX) {
		if (i<0 || (x==0.0 && i==0)) pe(27,l); // E27
		else {
			int k, res=1.0;
			for (k=1;k<=i;k++) res=res*x;
			return res;
		}
	}
	/* integer exponenet on real base */
	else if (typex<INTEGERTYPEBOX && typei==INTEGERTYPEBOX) {
		if (i==0.0 && x==0.0) pe(27,l); // E27
		else {
			int k;
			double res=1.0;
			for (k=(int)fabsl(i);k>=1;k--) res=res*x;
			if (i<0) return 1.0/res;
			else return res;
		}
	}
	/* safe measure to avoid error in compilation */
	return 0.0;
}


/*****************************************
 *             ASSIGNMENTS               *
 *****************************************/

/* assign()
 * The assign procedure
 * perform the assignment; checks if iterate for assignments in series; set up
 * for embedded assignments (performed in S() and SS())
 * return var number if assignment went OK, false otherwise (currently unused)
 * Ref. AA-O196C-TK - 6.2 "Assignments"
 * Ref. AA-O196C-TK - 6.3 "Multiple Assignment" 
 * System function */
int assign(void) {
	int var=0, isArr=0, val[MAXDIM+1], isOwn=0;
	int ind=0, udim=1;
	int thistype;
	char *p1;

	reload();
	var=findDEC(p);
	p+=_len;
	reload();

	/* assign to variables */
	if (var) {
		int ttype, subscript, thislen, isRef=FALSE;
		char *pp;
		pp=p;
		/* case of referenced variable which was passed an
		 * expression, which cannot be reassigned */
		if (vn[var].refcode==2*DECADD) pe(7,l); // E07
		/* case of a variable of type INFILE */
		else if (vn[var].type==INFILETYPEBOX && !vn[var].isopen) {
			char fname[COMPSTR], *f=fname;
			if (*p==PU) p++;
			else pe(3,l); // E02
			if (*p=='\"') p++;
			else pe(9,l); // E09
			while (*p && *p!='\"') *f++=*p++;
			*f='\0';
			if (*p=='\"') p++;
			if (!vn[var].stream) vn[var].stream=fopen(fname,"r");
			else {
				fclose(vn[var].stream);
				vn[var].stream=fopen(fname,"r");
			}
			if (vn[var].stream == NULL) pe(42,l); // E42
			vn[var].isopen=TRUE;
			/* set channel for variables declared for the first time */
			if (vn[var].channel<0) {
				vn[var].channel=currChan;
				currChan++;
				if (currChan>STREAMS) pe(46,l); // E46
			}
			return var;
		}
		else if (vn[var].type==INFILETYPEBOX) pe(45,l); // E45
		/* case of a variable of type OUTFILE */
		else if (vn[var].type==OUTFILETYPEBOX && !vn[var].isopen) {
			char fname[COMPSTR], *f=fname;
			if (*p==PU) p++;
			else pe(3,l); // E02
			if (*p=='\"') p++;
			else pe(9,l); // E09
			while (*p && *p!='\"') *f++=*p++;
			*f='\0';
			if (*p=='\"') p++;
			if (!vn[var].stream) vn[var].stream=fopen(fname,"a");
			else vn[var].stream=freopen(fname,"a",vn[var].stream);
			if (vn[var].stream == NULL) pe(42,l); // E42
			vn[var].isopen=TRUE;
			/* set channel for variables declared for the first time */
			if (vn[var].channel<0) {
				vn[var].channel=currChan;
				currChan++;
				if (currChan>STREAMS) pe(46,l); // E46
			}
			return var;
		}
		else if (vn[var].type==OUTFILETYPEBOX) pe(46,l); // E45
		/* case of referenced array element */
		if (vn[var].refcode<-DECADD) {
			p=vn[var].valdata;
			while (*p && *p!='[') p++;
			/* reassign p for reading array values */
			var=vn[var].ref;
			isArr=TRUE;
			isOwn=FALSE;
			isRef=TRUE;
		}
		/* case of referenced variable/array */
		else if (vn[var].refcode<0) {
			var=vn[var].ref;
			isArr=vn[var].isArr;
			isOwn=vn[var].isOwn;
		}
		else {
			isArr=vn[vn[var].ref].isArr;
			isOwn=vn[vn[var].ref].isOwn;
		}
		ttype=vn[vn[var].ref].type;
		subscript=_type;
		thislen=vn[vn[var].ref].strmem;
		/* get string byte subscript index */
		if (subscript==CHAR) {
			char *pb;
			p++; // skip dot
			if (*p=='[') {
				p++; // skip [
				pb=p;
				ind=(int)S();
				if (*p==']') p++; // skip ]
				else pe(1,l); // E01
				thislen=strlen(PS[vn[var].ref]);
				if (ind<1 || ind>thislen) {
				       	p=pb; // for perror_
					pe(24,l); // E24
				}
			}
			else pe(8,l); // E08
			ttype=INTEGERTYPEBOX;
		}
		else if (isArr && *p!='[') pe(19,l); // E19
		/* get array indices */
		else if (isArr && *p=='[') {
			p++; // skip [
			val[udim]=(int)S();
			if (resultType==BOOLEANTYPEBOX) pe(31,l);
			while (*p==',' && udim<MAXDIM) {
				p++;
				udim++;
				val[udim]=(int)S();
				if (resultType==BOOLEANTYPEBOX) pe(31,l);
			}
			if (udim>=MAXDIM) pe(26,l); // E26
			if (*p==']') p++;
			else pe(1,l); // E01
		}
		/* restore p in case of array referencing */
		if (isRef) p=pp;
		reload();
		/* user value for variables */
		if (*p==PU) {
			/* the first part takes the value to instantiate 
			 * but does not instantiate */
			char sop[COMPSTR];
			double nop;
			p++; // skip @ (:=)
			reload();
			p1=p;
			/* string variables value */
			if (ttype==STRINGTYPEBOX) {
				strncpy_(sop,SS(),COMPSTR);
			}
			/* numeric variables value: consume it */
			else if (ttype<STRINGTYPEBOX) {
				nop=S();
				if (isLogic(nop)) thistype=BOOLEANTYPEBOX;
				else thistype=-1;
			}
			/* label variables value */
			else if (ttype==LABELTYPEBOX) {
				int count=0;
				if (*p=='\"') p++;
				count=getLabelIndex();
				if (*p=='\"') p++;
				if (!count) pe(11,l); // E11
				else if (count<0) pe(11,l); // E11
				else P[vn[var].ref]=count;
			}
			reload();	
			/* the expression is over, so now INSTANTIATE
			 * (also for embedded assignments) 
			 * Ref. AA-O196C-TK - 6.3 "Multiple Assignment" */
			if (*p!=PU || (*p==')' && isInn)) {
				isInn=FALSE;
				/* byte subscripts */
				if (subscript==CHAR) {
					PS[vn[var].ref][ind-1]=(char)nop;
				}
				/* string variables */
				else if (ttype==STRINGTYPEBOX && !isArr) {
					//if (ttype!=thistype) pe(9,l); // E09
					strncpy_(PS[vn[var].ref],sop,thislen);
					strncpy_(sres,sop,thislen);
				}
				/* string arrays */
				else if (ttype==STRINGTYPEBOX && isArr) {
					if (ttype!=thistype) pe(9,l); // E09
					setArrayStr(vn[var].ref,udim,val,sop);
					strncpy_(sres,sop,COMPSTR);
				}
				/* real variables */
				else if (ttype<INTEGERTYPEBOX && !isArr) {
					P[vn[var].ref]=nop;
					nres=nop;
				}
				/* real arrays */
				else if (ttype<INTEGERTYPEBOX && isArr) {
					setArrayVal(vn[var].ref,udim,val,nop);
					nres=nop;
				}
				/* Boolean variables */
				else if (ttype==BOOLEANTYPEBOX && !isArr) {
					if (ttype!=thistype) pe(7,l); // E07
					P[vn[var].ref]=(int)nop;
					nres=(int)nop;
				}
				/* Boolean arrays */
				else if (ttype==BOOLEANTYPEBOX && isArr) {
					if (ttype!=thistype) pe(7,l); // E07
					nres=(int)nop;
					setArrayVal(vn[var].ref,udim,val,nres);
				}
				/* Ref. AA-O196C-TK - 6.2 "If a real or long 
				 * real value is assigned to an integer type 
				 * variable, a rounding process occurs.
				 * I := X
				 * results in an integral value equal to 
				 * ENTIER(X + 0.5) being assigned to I.*/
				/* integer variables */
				else if (ttype==INTEGERTYPEBOX && !isArr) {
					nres=(int)(nop+sign(nop)*0.5);
					P[vn[var].ref]=nres;
				}
				/* integer arrays */
				else if (ttype==INTEGERTYPEBOX && isArr) {
					nres=(int)(nop+sign(nop)*0.5);
					setArrayVal(vn[var].ref,udim,val,nres);
				}
			}
			/* it is a multi-assignment, so iterate and then
			 * assign returned values 
			 * Ref. AA-O196C-TK - 6.3 "Multiple Assignments" */
			else if (*p==PU) {
				p=p1;
				assign();
				/* byte subscripts */
				if (subscript==CHAR) {
					*(PS[vn[var].ref]+ind-1)=(char)nres;
				}
				/* string variables */
				else if (ttype==STRINGTYPEBOX && !isArr) {
					strncpy_(PS[vn[var].ref],sres,thislen);
				}
				/* string arrays */
				else if (ttype==STRINGTYPEBOX && isArr) {
					setArrayStr(vn[var].ref,udim,val,sres);
				}
				/* real variables */
				else if (ttype<INTEGERTYPEBOX && !isArr) {
					P[vn[vn[var].ref].ref]=nres;
				}
				/* real arrays */
				else if (ttype<INTEGERTYPEBOX && isArr) {
					setArrayVal(vn[var].ref,udim,val,nres);
				}
				/* Boolean variables */
				else if (ttype==BOOLEANTYPEBOX && !isArr) {
					P[vn[var].ref]=(int)nres;
				}
				/* Boolean arrays */
				else if (ttype==BOOLEANTYPEBOX && isArr) {
					setArrayVal(vn[var].ref,udim,val,(int)nres);
				}
				/* Ref. AA-O196C-TK - 6.2 "If a real or long 
				 * real value is assigned to an integer type 
				 * variable, a rounding process occurs.
				 * I := X
				 * results in an integral value equal to 
				 * ENTIER(X + 0.5) being assigned to I.*/
				/* integer variables */
				else if (ttype==INTEGERTYPEBOX) {
					P[vn[var].ref]=nres;
				}
				/* integer arrays */
				else if (ttype==INTEGERTYPEBOX && isArr) {
					setArrayVal(vn[var].ref,udim,val,nres);
				}
			}
			/* treat OWN elements (variables and arrays) */
			if (isOwn) {
				int i=1;
				while (i<=ghostCount) {
				   /* if it's an OWN variable, assign the ghost 
				    * using the reference code in isOwn */
				   if (own[i].code==isOwn && !isArr) {
				      if (ttype<STRINGTYPEBOX)
				         own[i].num=nres;
				      else 
				         strncpy_(own[i].str,sres,COMPSTR);
				      break;
				   }
				   /* if it's an OWN array, assign the ghost 
				    * using the reference code in isOwn 
				    * and copying the memory portion */
				   else if (own[i].code==isOwn && isArr) {
				      if (ttype<STRINGTYPEBOX) {
				         memcpy_(own[i].numarr,dim[var].elem,vn[var].size);
				      }
				      else {
				         memcpy_(own[i].strarr,dimS[var].elem,vn[var].size);
				      }
				      break;
				   }
				   i++;
				}
			}
			
			/* treat assignment of PROCEDURE-pseudo-variables */
			if (isProcTime && !strcmp(vn[var].name,Procp[isProcTime].name)) {
				if (Procp[isProcTime].type==LABELTYPEBOX)
					Procp[isProcTime].numres=P[var];
				else if (Procp[isProcTime].type<STRINGTYPEBOX)
					Procp[isProcTime].numres=nres;
				else strncpy_(Procp[isProcTime].strres,sres,COMPSTR);
			}
		}
		else pe(2,l); // 1E02
	}
	else {
		if (!isalpha(*p)) pe(30,l); // E30
	}

	/* return TRUE, returning the variable code */
	return var;
}


/*****************************************
 *             MATH & STRINGS            *
 *****************************************/

/* setAddr()
 * calculate the numerical correspondence of any string label 
 * in chunks of 8 characters*/
int setAddr(char *lp, char **rp) {
	int val=0, c=0, i=0;
	while (islabelnamechar(lp) && i<NAMEDIM) {
		c=0;
		while (islabelnamechar(lp) && c<8) {
			if (islabelnamechar(lp) && *lp!='.')
				val+=pow(10,c++)*(toupper(*lp++)-'A'+1);
			else lp++;
			i++;
		}
	}
	if (**rp) *rp=lp;
	return val;
}


/* check(string1,string2)
 * check if sb syntax is correct against sc; if it is, put a space in the 
 * position found, so that a subsequent parsing by S() may stop without 
 * issuing an error message from getFunc() and return true; 
 * if syntax it's not correct, return false.
 * This is done in statements with some core-words, like IF <Test> THEN
 * where the parsing of <Test> must stop just before THEN; check() inserts 
 * a space in place of the T of THEN, causing the parser to stop there */
int check(char *sb, char *sc){
	char *qq=strcasestr_oq(sb,sc);
	/* put a space to stop S() parsing */
	if (qq) { 
		*qq=' '; 
		return TRUE; 
	}
	return FALSE;
}


/* Note
 * The following strncpy_() and strncat_() are my own personal versions for 
 * strcpy/strncpy and strcat/strncat respectively.
 * I must use mine because strncpy/strncat standard functions in C (gcc) have 
 * erratic behaviors within different operating systems like Linux-Suse, 
 * OpenBSD and Mac OS X 10.4 (the one I use).
 * Since many reported strange things happening because of strncpy/strncat
 * (from error in compilation to completely wrong string functions output), I 
 * made up my mind and built these substitutes for both. */

/* strncpy_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus a width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is also good.)
 * The process will take care of never going past the limit of dst; 
 * System function replacing strcpy/strncpy */
char *strncpy_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* check length of copy and source */
	if (dw<1) *dst='\0';
	else if (!src) {
		/* fill the whole string with nulls */
		if (!*src) while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	else {
		/* copy src onto dst but not past the end of dst */
		while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
		*dp++='\0';
		/* fill the rest with nulls */
		while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	/* Note: return the same value returned by strcpy/strncpy */
	return dst;
}



/* chrcat_()
 * str: the string to be appended
 * chr: the character to append
 * NOTE: this function does not control if there is space in str, so use
 * it with care and only before checking that adding a character is legal
 * System function for HEAD/TAIL/TAKE/DROP */
char *chrcat_(char *str, char chr) {
	char *bs=str;
	while (*bs) bs++;
	*bs++=chr;
	*bs='\0';
	return str;
}


/* strncat_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst.
 * If dst is found not initialized  (that is nowhere the terminator is found) 
 * it is initialized as void.
 * System function replacing strcat/strncat */
char *strncat_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* copy src onto dst but not past the end of dst */
	while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
	*dp='\0';
	/* Note: return the same value returned by strcat/strncat */
	return dst;
}


/* Note
 * The following sprintw() is my own personal version wrapper for snprintf(), 
 * which appear to behave erratically on my system (is does not work with 
 * function return values, but works with real arrays) and probably the same 
 * (with inverse properties) on other systems.
 * This wrapper assures that only physical arrays are treated by sprintw() */

/* sprintw() 
 * the snprintf wrapper 
 * dest is the destination string,
 * len is the string width (including the terminator character)
 * format is the formatting string (with the same printf rules)
 * '...' is the printing string argument (it may be a function return value) 
 * return the number of characters written in the host string 
 * System function replacing sprintf/snprintf */
int sprintw(char *dest, int len, char *format, ...) {
	va_list ap;
	char base[COMPSTR];
	va_start(ap,format);
	vsnprintf(base,COMPSTR,format,ap);
	snprintf(dest,len,"%s",base);
	va_end(ap);
	return (int)strlen(base);
}


/* Note
 * The following strncasecmp_() is my own personal version of strncasecmp.
 * I must use mine because strncasecmp seems to cause some problems if dia is
 * compiled under openSuse with gcc and or Linux/openBSD with gcc.
 * Since many reported errors in compiling when the standard strncasecmp is
 * used, I made up my mind and built this substitute. */

/* strncasecmp_()
 * the string compare function
 * dst and src are the strings to be compared;
 * N is the number of characters to be checked against;
 * return the flag for positive comparison result, 0 for match, -1 for failure.
 * Note: return values mimic the original return values, with the difference
 * that I don't check here for dst being greater or less than src, and in case
 * they differ, -1 is returned anyway; this is done for speed issues. */
int strncasecmp_(char *dst, char *src, int N) {
	if (N<=0) return -1;
	while (N && *dst && *src && toupper(*dst)==toupper(*src)) 
		src++, dst++, N--;
	if (!N) return 0;
	return -1;
}


/* Note
 * The following memcpy_() is my own personal version of memcpy and memmove.
 * I must use mine because memcpy seems to be sometimes rejected by openBSD.
 * Since many reported errors in compiling if the standard memcpy/memmove is
 * used, I made up my mind and built this substitute. */

/* memcpy_()
 * check if any of arrays are null, or if size is zero/negative; 
 * if not, copy a portion of memory from src to dst, using memmove (that takes 
 * care of overlapping), for the number of characters specified in size */
void memcpy_(void *dst, void *src, int size) {
	if (src==NIL || dst==NIL || size<=0) return;
	memmove(dst,src,size);
}


/* Note
 * The following strcasestr_() is my own personal version of strcasestr().
 * I must use mine because strcasestr() in C has someway an erratic behavior
 * with Linux.
 * Since many reported errors in compiling if the standard strcasestr() is
 * used, I made up my mind and built this substitute. */

/* strcasestr_()
 * find the first occurrence of the substring 'little' in string 'big', 
 * ignoring the case of both arguments.
 * The terminating null bytes (i.e. '\0') are not compared. 
 * If 'little' is null, return NIL; if the substring is found, return the 
 * updated address in 'big', otherwise return NIL. */
char *strcasestr_(char *big, char *little) {
	int l=(int)strlen(little);
	if (!l) return NIL;
	while (*big) {
		if (!strncasecmp_(big,little,l)) return big;
		big++;
	}
	return NIL;
}


/* strcasestr_oq()
 * find the first occurrence of the substring string 'pr' into string 'pl'
 * this function has the same usage of strcasestr_(), but it works only if 
 * outside of a string, in ALGOL 60 normally surrounded by double quotes or
 * two instances of single quotes.
 * (strcasestr_oq = strcasestr_ Out of Quotes) */
char *strcasestr_oq(char *pl, char *pr) {
	int valid=1, l=(int)strlen(pr);
	if (!l) return pl;
	while (*pl) {
		if (*pl=='\"') valid++;
		if (!strncasecmp_(pl,pr,l) && (valid & 1)) return pl;
		pl++;
	}
	return NIL;
}


/* findLabel()
 * find the first occurrence of the substring ":" into string 'pl'
 * this function has the same usage of strcasestr_(), but it works only if 
 * outside of a string, in ALGOL 60 normally surrounded by double quotes and
 * only out of square brackets (strcasestr_oq = strcasestr_ Out of Quotes),
 * discarding also the case of := (assignment) and :( (alternate comment) */
char *findLabel(char *pl) {
	int beg=0;
	while (*pl) {
		if (*pl=='\"' && *(pl+1)=='\"' && beg) pl++;
		else if (*pl==':' && *(pl+1)=='=') pl++;
		else if (*pl==':' && *(pl+1)=='(') pl++;
		else if (*pl=='\"' && !beg) beg++;
		else if (*pl=='\"' && beg) beg--;
		else if (*pl=='[') beg++;
		else if (*pl==']') beg--;
		if (*pl==':' && !beg) {
			return pl;
		}
		pl++;
	}
	return NIL;
}


/* sEND()
 * check if p points to END and not to something like THEN D... 
 * system function for doBegin() and preParse() */
int sEND(char *p) {
	return (!strncasecmp_(p,"END",3) && toupper(*(p-1))!='H');
}


/******************************************
 *                 PARSING                *
 ******************************************/

/* preParse()
 * A fundamental subroutine to be run BEFORE each process.
 * Scan source in core memory and executes setting addresses for all statements
 * that requires jumps and preprocesses PRECEDUREs.
 * m: the array of the string pointers containing the program lines to be
 * executed.
 * System basic function */
void preParse(char **m, int start, int end) {
	int l=start-1, evalProc=FALSE, proclen=0, procpos=0, k,y;
	char *q, *q2;

	/* scan source */
	do {

	    l++;
	    if (l>end) break;
	    if (!m[l]) continue;
	    q=m[l];

	    while (*q) {
		while (isblank(*q)) q++;
		/* skip strings */
		if (*q=='\"') {
			q++; // skip "
			while (*q && *q!='\"') q++;
			if (*q=='\"') q++;
		}
		/* last END. stops parsing
		 * Note: comments after END were removed 
		 * in storeSingleLineToCore() */ 
		else if ((!strncasecmp_(q,"END.",4))) {
			l=end;
			break;
		}
		/* IF-THEN-ELSE position search */ 
		else if ((!strncasecmp_(q,"IF",2))) {
			/* IF position is certain */
			int bt=l,be, beg=0, flip=0, flipd=0;
			int isThereElse;
			isThereElse=FALSE;
			ifTOS++;
			if (ifTOS>=LIMIT) pe(26,l); // E26
			Ifp[ifTOS].condL=Ifp[ifTOS].condP=-1;
			Ifp[ifTOS].thenL=Ifp[ifTOS].thenP=-1;
			Ifp[ifTOS].elseL=Ifp[ifTOS].elseP=-1;
			Ifp[ifTOS].termL=Ifp[ifTOS].termP=-1;
			q+=1; // skip IF
			q2=q+1;
			/* refill after IF*/
			if (!*q2 && bt<end) {
				bt++;
				while (!m[bt] && bt<end) bt++;
				q2=m[bt];
			}
			if (bt==end) break;
			Ifp[ifTOS].condL=bt;
			Ifp[ifTOS].condP=(int)(q2-m[bt]);
			/* look for next THEN */
			beg=flip=0;
			while(TRUE) {
				/* refill */
				if (!*q2 && bt<end) {
					bt++;
					while (!m[bt] && bt<end) bt++;
					q2=m[bt];
				}
				if (bt==end) break;
				if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flipd) q2++, flipd++;
				else if (isdc(q2) && flipd) q2++, flipd--;
				else if (!strncasecmp_(q2,"THEN",4) && !flip && ! flipd && !beg){ 
					break;
				}
				else if (!strncasecmp_(q2,"IF",2) && !flip && !flipd) 
					q2++, beg++;
				else if (!strncasecmp_(q2,"THEN",2) && !flip && !flipd && beg) 
					q2+=3, beg--;
				q2++;
			}
			q2+=4; // skip THEN
			/* refill */
			if (!*q2 && bt<end) {
				bt++;
				while (!m[bt] && bt<end) bt++;
				q2=m[bt];
			}
			if (bt==end) break;
			Ifp[ifTOS].thenL=bt;
			Ifp[ifTOS].thenP=(int)(q2-m[bt]);
			/* look for next ELSE or terminator */
			be=bt; beg=flip=flipd=0;
			while(TRUE) {
				/* refill */
				if (!*q2 && be<end) {
					be++;
					while (!m[be] && be<end) be++;
					q2=m[be];
				}
				if (be==end) break;
				if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flipd) q2++, flipd++;
				else if (isdc(q2) && flipd) q2++, flipd--;
				else if (!strncasecmp_(q2,"BEGIN",5) && !flip && !flipd) 
					q2+=4, beg++;
				else if (*q2==';' && !flip && !flipd && !beg) 
					break;
				else if (!strncasecmp_(q2,"ELSE",4) && !beg && !flip && !flipd) {
					isThereElse=TRUE;
					break;
				}
				else if (sEND(q2) && !beg && !flip && !flipd) {
					q2+=3;
					if (*q2 && *q2!=';' && *q2!='.') {
						continue;
					}
					else break;
				}
				else if (sEND(q2) && beg && !flip && !flipd) 
					q2+=2, beg--;
				q2++;
			}
			/* ELSE found */
			if (isThereElse) {
				q2+=4; // skip ELSE
				/* refill */
				if (!*q2 && be < end) {
					be++;
					while (!m[be] && be<end) be++;
					q2=m[be];
				}
				if (be==end) break;
				Ifp[ifTOS].elseL=be;
				Ifp[ifTOS].elseP=(int)(q2-m[be]);
			}
			beg=flip=0;
			/* look for terminator */
			while(TRUE) {
				/* refill */
				if (!*q2 && be<end) {
					be++;
					while (!m[be] && be<end) be++;
					q2=m[be];
				}
				if (be==end) break;
				if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flip) q2++, flip++;
				else if (isdc(q2) && flip) q2++, flip--;
				else if (!strncasecmp_(q2,"BEGIN",5) && !flip) 
					q2+=4, beg++;
				else if (sEND(q2) && !beg && !flip) 
					break;
				else if (sEND(q2) && beg && !flip) 
					q2+=2, beg--;
				else if (*q2==';' && !beg && !flip) break;
				q2++;
			}
			Ifp[ifTOS].termL=be;
			Ifp[ifTOS].termP=(int)(q2-m[be]);
		}
		/* FOR-DO position search */ 
		if (!strncasecmp_(q,"FOR",3)) {
			/* FOR position is certain */
			int bf=l, beg=0, flip=0, flipd=0, isForEnd=FALSE;
			forTOS++;
			if (forTOS>=LIMIT) pe(26,l); // E26
			Forp[forTOS].varpL=Forp[forTOS].varpP=-1;
			Forp[forTOS].doexL=Forp[forTOS].doexP=-1;
			Forp[forTOS].termL=Forp[forTOS].termP=-1;
			q+=2; // skip FOR
			q2=q+1; 
			if (!*q2) {
				bf++;
				while (!m[bf]) bf++;
				if (bf>end) isForEnd=TRUE;
				q2=m[bf];
			}
			if (isForEnd) continue;
			isForEnd=FALSE;
			Forp[forTOS].varpL=bf;
			Forp[forTOS].varpP=(int)(q2-m[bf]);
			/* look for DO */
			while(TRUE) {
				if (!*q2) {
					bf++;
					while (!m[bf]) bf++;
					if (bf>end) break;
					q2=m[bf];
				}
				if (!strncasecmp_(q2,"DO",2)) break;
				q2++;
			}
			if (bf>end) pe(8,l); // E08
			else if (isForEnd) continue;
			isForEnd=FALSE;
			q2+=2; // skip DO
			Forp[forTOS].doexL=bf;
			Forp[forTOS].doexP=(int)(q2-m[bf]);
			/* look for terminator */
			while(TRUE) {
				if (!*q2) {
					bf++;
					while (!m[bf]) bf++;
					if (bf>end) break;
					q2=m[bf];
				}
				if (bf>end) {isForEnd=TRUE; break;}
				else if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flipd) q2++, flipd++;
				else if (isdc(q2) && flipd) q2++, flipd--;
				else if (!strncasecmp_(q2,"BEGIN",5) && !flip && !flipd) 
					q2+=4, beg++;
				else if (sEND(q2) &&\
						!beg && !flip && !flipd) 
					break;
				else if (sEND(q2) &&\
					       beg && !flip && !flipd) 
					q2+=2, beg--;
				else if (*q2==';' && !beg && !flip && !flipd) break;
				q2++;
			}
			if (isForEnd) continue;
			isForEnd=FALSE;
			if (!*q2) {
				bf++;
				while (!m[bf]) bf++;
				if (bf>end) isForEnd=TRUE;
				q2=m[bf];
			}
			if (isForEnd) continue;
			Forp[forTOS].termL=bf;
			Forp[forTOS].termP=(int)(q2-m[bf]);
		}
		/* BEGIN-END position search 
		 * Note: here I don't take any countermeasure for letting
		 * the word BEGIN to be part of an identifier (like for IF,
		 * FOR or WHILE); this is because BEGIN and END may be misread
		 * by the parser and not correctly aligned. Thus I pose the
		 * rule to not use BEGIN in identifiers and strongly suggest
		 * not to use END (its counterpart) in identifiers as well. */ 
		else if ((!strncasecmp_(q,"BEGIN",5))) {
			/* BEGIN position is certain */
			int bs=l, beg=0, flip=0, flipd=0;
			beginTOS++;
			if (beginTOS>=LIMIT) pe(26,l); // E26
			q+=4; // skip BEGIN
			q2=q+1; 
			Beginp[beginTOS].varpL=bs;
			Beginp[beginTOS].varpP=(int)(q2-m[bs]);
			if (!*q2) {
				bs++;
				while (!m[bs]) bs++;
				if (bs>end) pe(8,l); // E08
				q2=m[bs];
			}
			/* look for terminator */
			while(TRUE) {
				if (!*q2) {
					bs++;
					while (!m[bs]) bs++;
					if (bs>end) break;
					q2=m[bs];
				}
				if (bs>end) pe(8,l); // E08
				else if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flipd) q2++, flipd++;
				else if (isdc(q2) && flipd) q2++, flipd--;
				else if (!strncasecmp_(q2,"BEGIN",5) && !flip && !flipd) 
					q2+=4, beg++;
				else if (sEND(q2) && beg && !flip && !flipd) 
					q2+=2, beg--;
				else if (sEND(q2) && !beg && !flip && !flipd) 
					break;
				q2++;
			}
			if (!*q2) {
				bs++;
				while (!m[bs]) bs++;
				if (bs>end) pe(36,l); // E36
				q2=m[bs];
			}
			Beginp[beginTOS].termL=bs;
			Beginp[beginTOS].termP=(int)(q2-m[bs]);
		}
		/* WHILE-DO position search */ 
		else if ((!strncasecmp_(q,"WHILE",5))) {
			/* WHILE position is certain */
			int wf=l, beg=0, flip=0, flipd=0, isWhileEnd=FALSE;
			whileTOS++;
			if (whileTOS>=LIMIT) pe(26,l); // E26
			Whilep[whileTOS].varpL=Whilep[whileTOS].varpP=-1;
			Whilep[whileTOS].doexL=Whilep[whileTOS].doexP=-1;
			Whilep[whileTOS].termL=Whilep[whileTOS].termP=-1;
			q+=4; // skip WHILE
			q2=q+1; 
			if (!*q2) {
				wf++;
				while (!m[wf]) wf++;
				if (wf>end) isWhileEnd=TRUE;
				q2=m[wf];
			}
			if (isWhileEnd) continue;
			isWhileEnd=FALSE;
			Whilep[whileTOS].varpL=wf;
			Whilep[whileTOS].varpP=(int)(q2-m[wf]);
			/* look for DO */
			while(TRUE) {
				if (!*q2) {
					wf++;
					while (!m[wf]) wf++;
					if (wf>end) break;
					q2=m[wf];
				}
				if (!strncasecmp_(q2,"DO",2)) break;
				q2++;
			}
			if (wf>end) pe(8,l); // E08
			else if (isWhileEnd) continue;
			isWhileEnd=FALSE;
			q2+=2; // skip DO
			Whilep[whileTOS].doexL=wf;
			Whilep[whileTOS].doexP=(int)(q2-m[wf]);
			/* look for terminator */
			while(TRUE) {
				if (!*q2) {
					wf++;
					while (!m[wf]) wf++;
					if (wf>end) break;
					q2=m[wf];
				}
				if (wf>end) {isWhileEnd=TRUE;break;}
				else if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flipd) q2++, flipd++;
				else if (isdc(q2) && flipd) q2++, flipd--;
				else if (!strncasecmp_(q2,"BEGIN",5) && !flip && !flipd) 
					q2+=4, beg++;
				else if (sEND(q2) &&\
						!beg && !flip && !flipd) 
					break;
				else if (sEND(q2) &&\
					       beg && !flip && ! flipd) 
					q2+=2, beg--;
				else if (*q2==';' && !beg && !flip && !flipd) 
					break;
				q2++;
			}
			if (isWhileEnd) continue;
			isWhileEnd=FALSE;
			if (!*q2) {
				wf++;
				while (!m[wf]) wf++;
				if (wf>end) isWhileEnd=FALSE;
				q2=m[wf];
			}
			if (isWhileEnd) continue;
			Whilep[whileTOS].termL=wf;
			Whilep[whileTOS].termP=(int)(q2-m[wf]);
		}
		/* PROCEDURE detection */
		else if ((!strncasecmp_(q,"INTEGERPROCEDURE",16))) {
			evalProc=INTEGERTYPEBOX;
			proclen=16;
		}
		else if ((!strncasecmp_(q,"REALPROCEDURE",13))) {
			evalProc=REALTYPEBOX;
			proclen=13;
		}
		else if ((!strncasecmp_(q,"BOOLEANPROCEDURE",16))) {
			evalProc=BOOLEANTYPEBOX;
			proclen=16;
		}
		else if ((!strncasecmp_(q,"STRINGPROCEDURE",15))) {
			evalProc=STRINGTYPEBOX;
			proclen=15;
		}
		else if ((!strncasecmp_(q,"LABELPROCEDURE",14))) {
			evalProc=LABELTYPEBOX;
			proclen=14;
		}
		else if ((!strncasecmp_(q,"PROCEDURE",9))) {
			evalProc=NOTYPEBOX;
			proclen=9;
		}
		/* PROCEDURES 
		 * Arguments, begin-end position and masking */ 
		if (evalProc) {
			int varcount=0, index=0;
			int bs=l, beg=0, flip=0, flipd=0, k;
			int types[MAXDIM], modes[MAXDIM],e;
			int state[MAXDIM];
			char names[MAXDIM][COMPSTR], *nm;
			char pname[COMPSTR], *pn=pname;

			for (e=0;e<MAXDIM;e++) 
				types[e]=modes[e]=state[e]=0;

			/* PROCEDURE starting position is certain */
			procpos=(int)(q-m[l]);
			procTOS++;
			if (procTOS>=LIMIT) pe(26,l); // E26
			Procp[procTOS].procL=l;
			Procp[procTOS].procP=procpos;
			q+=proclen; // skip PROCEDURE
			q2=q;
			/* get sub name */
			if (isbeginnamechar(q2)) 
				while (isnamechar(q2)) *pn++=*q2++;
			else pe(11,l); // E11
			*pn='\0';
			strncpy_(Procp[procTOS].name,pname,NAMEDIM);
			Procp[procTOS].type=evalProc;
			Procp[procTOS].number=procTOS;
			Procp[procTOS].procref=0; // by default
			/* there are arguments*/
			if (*q2=='(') {
				q2++;
				index=0;
				while (*q2!=')') {
					if (*q2==';') pe(35,l); // E35
					index++;
					nm=names[index];
					while (isnamechar(q2)) *nm++=*q2++;
					*nm='\0';
					types[index]=REALTYPEBOX;
					modes[index]=BYREF;
					if (*q2==',') q2++;
					/* after the arguments list there 
					 * must be the terminator */
					else if (*q2==')' && !*(q2+1)) {
						pe(1,l); // E01
					}
					/* enrichment 
					 * Ref. AA-196C-TK 11.9.2 */
					else if (*q2==')' && *(q2+1)!=';') {
						q2++; // skip )
					       	while (*q2!=':') q2++;
						q2++; // skip :
						if (*q2=='(') q2++;
						else pe(1,l); // E01
					}
				}
				if (*q2==')') q2++;
				else pe(1,l); // E01
				if (*q2==';') q2++;
				else pe(35,l); // E35
			}
			/* establish true type and mode of argument variables 
			 * OUTER circle */
			if (index) while (TRUE) {
				int deftype, defmode, defstat;
				int evaluate=0;
				deftype=REALTYPEBOX;
				defmode=BYREF;
				defstat=ISVAR;
				/* reload */
				while (!*q2) {
					bs++;
					while (!m[bs]) bs++;
					if (bs>end) pe(8,l); // E08
					q2=m[bs];
				}
				/* detect change of type/mode */
				if (!strncasecmp_(q2,"INTEGERARRAY",12)) {
					q2+=12;
					deftype=INTEGERTYPEBOX;
					defmode=0;
					defstat=ISARR;
				}
				else if (!strncasecmp_(q2,"INTEGERPROCEDURE",16)) {
					q2+=16;
					deftype=INTEGERTYPEBOX;
					defmode=0;
					defstat=ISPROC;
				}
				else if (!strncasecmp_(q2,"INTEGER",7)) {
					q2+=7;
					deftype=INTEGERTYPEBOX;
					defmode=0;
				}
				else if (!strncasecmp_(q2,"REALARRAY",9)) {
					q2+=9;
					deftype=REALTYPEBOX;
					defmode=0;
					defstat=ISARR;
				}
				else if (!strncasecmp_(q2,"ARRAY",5)) {
					q2+=5;
					deftype=REALTYPEBOX;
					defmode=0;
					defstat=ISARR;
				}
				else if (!strncasecmp_(q2,"REALPROCEDURE",13)) {
					q2+=13;
					deftype=REALTYPEBOX;
					defmode=0;
					defstat=ISPROC;
				}
				else if (!strncasecmp_(q2,"REAL",4)) {
					q2+=4;
					deftype=REALTYPEBOX;
					defmode=0;
				}
				else if (!strncasecmp_(q2,"BOOLEANARRAY",12)) {
					q2+=12;
					deftype=BOOLEANTYPEBOX;
					defmode=0;
					defstat=ISARR;
				}
				else if (!strncasecmp_(q2,"BOOLEANPROCEDURE",16)) {
					q2+=16;
					deftype=BOOLEANTYPEBOX;
					defmode=0;
					defstat=ISPROC;
				}
				else if (!strncasecmp_(q2,"BOOLEAN",7)) {
					q2+=7;
					deftype=BOOLEANTYPEBOX;
					defmode=0;
				}
				else if (!strncasecmp_(q2,"STRINGARRAY",11)) {
					q2+=11;
					deftype=STRINGTYPEBOX;
					defmode=0;
					defstat=ISARR;
				}
				else if (!strncasecmp_(q2,"SWITCH",6)) {
					q2+=6;
					deftype=LABELTYPEBOX;
					defmode=0;
					defstat=ISARR;
				}
				else if (!strncasecmp_(q2,"STRINGPROCEDURE",15)) {
					q2+=15;
					deftype=STRINGTYPEBOX;
					defmode=0;
					defstat=ISPROC;
				}
				else if (!strncasecmp_(q2,"PROCEDURE",9)) {
					q2+=9;
					deftype=NOTYPEBOX;
					defmode=0;
					defstat=ISPROC;
				}
				else if (!strncasecmp_(q2,"STRING",6)) {
					q2+=6;
					deftype=STRINGTYPEBOX;
					defmode=0;
				}
				else if (!strncasecmp_(q2,"LABELPROCEDURE",14)){
					q2+=14;
					deftype=LABELTYPEBOX;
					defmode=0;
					defstat=ISPROC;
				}
				else if (!strncasecmp_(q2,"LABEL",5)) {
					q2+=5;
					deftype=LABELTYPEBOX;
					defmode=BYVAL;
				}
				else if (!strncasecmp_(q2,"VALUE",5)) {
					q2+=5;
					deftype=0;
					defmode=BYVAL;
					defstat=0;
				}
				else break;
				/* INNER circle */
				while (*q2 && *q2!=';') {
					char tname[COMPSTR], *tn;
					int i;
					tn=tname;
					while (isnamechar(q2)) *tn++=*q2++;
					*tn='\0';
					if (*q2) {
					/* search among arguments */
 					   for (i=index;i>0;i--) {
						if (!strcmp(tname,names[i])) {
						  if(deftype) types[i]=deftype;
						  if(defmode) modes[i]=defmode;
						  if(defstat) state[i]=defstat;
						  evaluate++;
						  break;
						}
					   }
					   if (i<1) pe(26,bs); // E26
					   if (*q2==',') q2++;
					}
					/* reload */
					else {
						bs++;
						while (!m[bs]) bs++;
						if (bs>end) pe(8,bs); // E08
						q2=m[bs];
					}
				}
				if (!evaluate) pe(25,bs); // E25
				if (*q2==';') q2++;
				/* reload */
				if (!*q2) {
					bs++;
					while (!m[bs]) bs++;
					if (bs>end) pe(8,bs); // E08
					q2=m[bs];
				}
			}
			for (k=index;k>0;k--) if (!state[k]) state[k]=ISVAR;
			Procp[procTOS].numvars=index;
			Procp[procTOS].procref=-1;
			/* look for proc start */
			if (*q2==';') q2++;
			/* reload */
			if (!*q2) {
				bs++;
				while (!m[bs]) bs++;
				if (bs>end) pe(8,bs); // E08
				q2=m[bs];
			}
			Procp[procTOS].begnL=bs;
			Procp[procTOS].begnP=(int)(q2-m[bs]);;
			l=bs; q=m[l]+Procp[procTOS].begnP;
			q--;
			/* look for terminator */
			while(TRUE) {
				if (!*q2) {
					bs++;
					while (!m[bs]) bs++;
					if (bs>end) break;
					q2=m[bs];
				}
				if (bs>end) pe(8,l); // E08
				else if (*q2=='\"' && !flip) flip++;
				else if (*q2=='\"' && flip) flip--;
				else if (isdc(q2) && !flipd) q2++, flipd++;
				else if (isdc(q2) && flipd) q2++, flipd--;
				else if (!strncasecmp_(q2,"BEGIN",5) && !flip && !flipd) 
					q2+=4, beg++;
				else if (sEND(q2) && !beg && !flip && !flipd) 
					break;
				else if (sEND(q2) && beg && !flip && !flipd) 
					q2+=2, beg--;
				else if (*q2==';' && !beg && !flip && !flipd) 
					break;
				q2++;
			}
			if (!*q2) {
				bs++;
				while (!m[bs]) bs++;
				if (bs>end) pe(8,l); // E08
				q2=m[bs];
			}
			Procp[procTOS].termL=bs;
			Procp[procTOS].termP=(int)(q2-m[bs]);
			/* check body evidence */
			if (Procp[procTOS].begnL==Procp[procTOS].termL &&\
				Procp[procTOS].begnP==Procp[procTOS].termP)
				pe(8,bs); // E08
			/* build [].vars line */
			varcount=0;
			for (bs=1;bs<=index;bs++) {
			  nm=names[bs];
			  while (*nm) 
			  	Procp[procTOS].vars[++varcount]=*nm++;
			  Procp[procTOS].vars[++varcount]=-1; //end name
			  Procp[procTOS].vars[++varcount]=DECADD+types[bs];
			  Procp[procTOS].vars[++varcount]=DECADD+modes[bs];
			  Procp[procTOS].vars[++varcount]=DECADD+state[bs];
			  Procp[procTOS].vars[++varcount]=-2; //end var data  
			}
			evalProc=FALSE;
		}
	    q++;
	    }
	} while (TRUE);

	/* categorize procedures levels 
	 * Note: wq is used to print the title only before the first line */
	for (k=1;k<=procTOS;k++) {
		int tsl, tsp, tel, tep; // start end L,P of current base
		tsl=Procp[k].begnL;
		tsp=Procp[k].begnP;
		tel=Procp[k].termL;
		tep=Procp[k].termP;
		for (y=k+1;y<=procTOS;y++) {
			if (y==k) continue;
			if ((Procp[y].procL>tsl && Procp[y].termL<tel) ||\
				(Procp[y].procL==tsl && Procp[y].procP>tsp &&\
				Procp[y].termL==tel && Procp[y].termP<tep)) {
					Procp[y].procref=k;
			}
			else Procp[y].procref=0;
		}
	}
}


/* isInnerAssign() 
 * check if the string in t is an assignment enclosed in parenthesis to 
 * perform first the assignment in parenthesis (inner assignment) and then
 * to assign the external left part.
 * System function for getVal() */
int isInnerAssign(char *t) {
	char *f=NULL,*m=NULL,*e=NULL;
	char yt[2];
	int v=0;
	if (*t!='(') return FALSE;
	f=t++; // jump to ( and skip it
	yt[0]=PU;
	yt[1]='\0';
	m=strcasestr_(t,yt);
	if (!m) return FALSE;
	t=m+1; // jump to � and skip it
	while (*t) {
		if (*t=='(') v++;
		else if (*t==')' && v) v--;
		else if (*t==')' && !v) {
			e=t-1;
			break;
		}
		t++;
	}
	if (f<m && m<e) return (int)(e-f+1);
	return FALSE;
}


/* SKIPPROCEDURE()
 * skips procedure body during runtime */
void SKIPPROCEDURE(void) {
	/* get position */
	int L=l, P=strlen(m[l])-strlen(p), i;
	/* look for data in Procp[] with the same position */
	LL=PL=0;
	for (i=1;i<=procTOS;i++) {
		/* jump to term position */
		if (L==Procp[i].procL && P==Procp[i].procP) {
			LL=Procp[i].termL;
			PL=Procp[i].termP;
			if (isDebug) {
				fprintf(stdout,"%s",INVCOLOR);
				fprintf(stdout,"Skipping procedure %s\n",Procp[i].name);
				fprintf(stdout,"%s",RESETCOLOR);
			}
			break;
		}
	}
	if (i>procTOS) pe(26,l); // E26
	/* if LL is still empty, no data was found */
	if (!LL) pe(11,l); // E11
}


/* parseComment()
 * parse text at current program pointer, assuming it is a comment, until
 * first ; and in case the current line comes to an end without a comment
 * end, check on next line, parsing it again. 
 * Used in algolstart() as a comment pre-BEGIN and in exec() for standard
 * COMMENT and ! procedures keyword. */
void parseComment(void) {
	while (*p && *p!=';') {
		p++;
		if (!*p) {
			l++;
			if (l>endCore) return;
			while ((!m[l] || !m[l][0])) l++;
			if (l>endCore) return;
			strncpy_(BASESTR,m[l],COMPSCR);
			p=BASESTR;
		}
	}
}


/* parseDATA()
 * parse text at current program pointer, assuming it is a DATA statement, 
 * untilfirst ; 
 * Used in algolstart() */
void parseDATA(void) {
	while (*p && *p!=';') {
		p++;
	}
}


/* isIn()
 * check if a destination jump is beyond the scope of a BEGIN-END block
 * l = current line 
 * LL,PL = line and position in line
 * System procedure for doBegin() to check block position */
int isIn(int l, int LL, int PL) {
	/* tl,tp = line and position in line of BEGIN+5 */
	/* te,pe = line and position in line of END */
	int tl, tp, te, pe; 
	int locTOS=1;
	while (Beginp[locTOS].varpL!=l) locTOS++;
	tl=Beginp[locTOS].varpL;
	tp=Beginp[locTOS].varpP;
	te=Beginp[locTOS].termL;
	pe=Beginp[locTOS].termP;
	if ((LL>te) || (LL==te && PL>pe) || (LL<tl) || (LL==tl && PL<tp))
	       return FALSE;
	return TRUE;	
}


/* depured()
 * separate a statement string from the following statements, saving return
 * string in a global server-string
 * System procedure for doBegin() in case the debug line is to be printed */
char *depured(char *f) {
	char *o=dline, *t;
	/* return null on void line */
	if (!f || !*f) {
		*o='\0';
		return dline;
	}
	/* check for terminator */
	t=strcasestr_oq(f,";");
	/* return null only if argument is empty */
	if (!t && !strlen(f)) {
		*o='\0';
		return dline;
	}
	/* line is full but terminator absent */
	else t=f+strlen(f)-1;
	/* copy string */
	while (f<=t) *o++=*f++;
	*o='\0';
	return dline;
}


/* normal variables declarative procedures 
 * Ref. AA-0196C-TK 3.2 "Scalar declarations" */
void INTEGER(void) {
	isOwn=FALSE;
	typeBox=INTEGERTYPEBOX;
	declare();
}
void REAL(void) {
	isOwn=FALSE;
	typeBox=REALTYPEBOX;
	declare();
}
void BOOLEAN(void) {
	isOwn=FALSE;
	typeBox=BOOLEANTYPEBOX;
	declare();
}
void STRING(void) {
	isOwn=FALSE;
	typeBox=STRINGTYPEBOX;
	declare();
}
void LABEL(void) {
	isOwn=FALSE;
	typeBox=LABELTYPEBOX;
	declare();
}
void DATA(void) {
	double val=0;
	isOwn=FALSE;
	/* skip command if running */
	typeBox=DATATYPEBOX;
	p+=4; // skip DATA
	if (*p==PU || isnm(p) || *p=='=') pe(15,l); // E15
	declare();
	if (*p!=PU) pe(2,l); // E02
	else p++;
	vn[decCount].dataStart=vn[decCount].dataIndex;
	while (*p && *p!=';') {
		val=S();
		vn[decCount].dataArray[vn[decCount].dataIndex]=val;
		vn[decCount].dataIndex++;
		if (vn[decCount].dataIndex>DATALIM) pe(26,l); // E26
		if (*p==',') p++;
	}
	vn[decCount].dataEnd=vn[decCount].dataIndex-1;
	vn[decCount].dataCurr=vn[decCount].dataStart;
}
void INFILE(void) {
	isOwn=FALSE;
	typeBox=INFILETYPEBOX;
	declare();
	vn[decCount].isopen=FALSE;
	vn[decCount].channel=NOCHAN;
}
void OUTFILE(void) {
	isOwn=FALSE;
	typeBox=OUTFILETYPEBOX;
	declare();
	vn[decCount].isopen=FALSE;
	vn[decCount].channel=NOCHAN;
}

/* array variables declarative procedures 
 * Ref. AA-0196C-TK 9.2 "Array declarations" */
void INTEGERARRAY(void) {
	isOwn=FALSE;
	typeBox=INTEGERTYPEBOX;
	array();
	typeBox=0;
}
void REALARRAY(void) {
	isOwn=FALSE;
	typeBox=REALTYPEBOX;
	array();
	typeBox=0;
}
void BOOLEANARRAY(void) {
	isOwn=FALSE;
	typeBox=BOOLEANTYPEBOX;
	array();
	typeBox=0;
}
void STRINGARRAY(void) {
	isOwn=FALSE;
	typeBox=STRINGTYPEBOX;
	array();
	typeBox=0;
}


/* own (static) variables declarative procedures  
 * Ref. AA-0196C-TK 15 "Own variables" */
void OWNINTEGER(void) {
	isOwn=TRUE;
	typeBox=INTEGERTYPEBOX;
	declare();
	isOwn=FALSE;
}
void OWNREAL(void) {
	isOwn=TRUE;
	typeBox=REALTYPEBOX;
	declare();
	isOwn=FALSE;
}
void OWNBOOLEAN(void) {
	isOwn=TRUE;
	typeBox=BOOLEANTYPEBOX;
	declare();
	isOwn=FALSE;
}
void OWNSTRING(void) {
	isOwn=TRUE;
	typeBox=STRINGTYPEBOX;
	declare();
	isOwn=FALSE;
}
void OWNLABEL(void) {
	isOwn=TRUE;
	typeBox=LABELTYPEBOX;
	declare();
	isOwn=FALSE;
}


/* own (static) array variables declarative procedures 
 * Ref. AA-0196C-TK 15 "Own variables" */
void OWNINTEGERARRAY(void) {
	isOwn=TRUE;
	typeBox=INTEGERTYPEBOX;
	array();
	typeBox=0;
	isOwn=FALSE;
}
void OWNREALARRAY(void) {
	isOwn=TRUE;
	typeBox=REALTYPEBOX;
	array();
	typeBox=0;
	isOwn=FALSE;
}
void OWNBOOLEANARRAY(void) {
	isOwn=TRUE;
	typeBox=BOOLEANTYPEBOX;
	array();
	typeBox=0;
	isOwn=FALSE;
}
void OWNSTRINGARRAY(void) {
	isOwn=TRUE;
	typeBox=STRINGTYPEBOX;
	array();
	typeBox=0;
	isOwn=FALSE;
}


/*****************************************
 *             ALGOL ENGINE              *
 *****************************************/

/* go()
 * the runner...
 * evaluates first if the expression at the program pointer is a procedure
 * and then if it's an assignment.
 * line is used only to print the error message */
void go(int line) {
	if (*p==';' || *p<0) return;
	if (exec());
	else if (assign());
	else {
		// error condition; look if it is a missed assignment
		// otherwise it is a wrong statement
		while (isalpha(*p)) p++;
		if (*p==PU) pe(7,l); // E=7
		else pe(8,line); // E08
	}
	if (currentINPUT>0 && currentINPUT<=STREAMS && !checkstd(currentINPUT))
		isEOF(currentINPUT);
}


/* doBegin()
 * This is the block evaluator, and it works even in case of a single 
 * instructions; in case of a block, it executes every instruction in the 
 * inside, and stops and the END found, that may contain any character 
 * different from ';' as a free-text specifier but must end in the same line 
 * and with ';'. If a BEGIN is found, call itself again (via go() ). */
void doBegin(void) {
	int decBackup=decCount;
	int thisl=l, ic;

	/* update */
	beginTOS++;
	if (beginTOS>=LIMIT) pe(26,l); // E26

	beginDepth[beginTOS]=decCount;

	/* cycle: exit only after END or after a GOTO out of block */
	while (TRUE) {
		if (isQuit) break;
		/* a GOTO occurred */
		if (LL) {
			/* the jump occurs inside the BEGIN-END block */
			if (isIn(thisl,LL,PL)) {
				l=LL;
				strncpy_(BASESTR,m[l],COMPSTR);
				p=BASESTR+PL;
				LL=PL=0;
				if (!*p) {
					l++;
					if (l>endCore) pe(8,l); // E08
					while ((!m[l] || !m[l][0])) 
						l++;
					if (l>endCore) pe(8,l); // E08
					strncpy_(BASESTR,m[l],COMPSCR);
					p=BASESTR;
				}
			}
			/* the jump occurs outside of the BEGIN-END block */
			else break;
		}
		/* an END ends current block*/
		else if (sEND(p)) {
			p+=3;
			while (*p && !isterm(p) && isalnum(*p)) p++;
			resultType=0;
			break;
		}
		/* any other procedure is executed
		 * Note: a GOTO sets a new address that is evaluated at 
		 * the start of the cycle */
		else {
			/* reload in case of void string */
			if (!*p) {
				l++;
				while (l<=endCore && (!m[l]||!m[l][0])) 
					l++;
				if (l>endCore) pe(8,l); // E08
				strncpy_(BASESTR,m[l],COMPSCR);
				p=BASESTR;
			}
			/* DEBUGGING PURPOSES - print pure/stripped line 
			 * Note: in case of ontrace/offtrace, since a proper 
			 * string is printed by TRACE() for each one, their
			 * debug output is disabled */
			if (isDebug && *p && !strncasecmp_(p,"IF",2)) 	{
				char output[COMPSTR], *o=output;
				char *pb=p;
				while (*pb && strncasecmp_(pb,"THEN",4))
					*o++=*pb++;
				*o='\0';
				fprintf(stdout,"%s",INVCOLOR);
				if (output[0] && strcmp(output,";")) 
					fprintf(stdout,"\n%0d [%s]\n",dartLin[l],output);
				fprintf(stdout,"%s",RESETCOLOR);
			}
			else if (isDebug && *p) {
				char output[COMPSTR], *o;
				strncpy_(output,depured(p),COMPSTR);
				o=strcasestr_oq(output,";");
				if (o && *o) *o='\0';
				fprintf(stdout,"%s",INVCOLOR);
				if (output[0] && strcmp(output,";")) 
					fprintf(stdout,"\n%0d [%s]\n",dartLin[l],output);
				fprintf(stdout,"%s",RESETCOLOR);
			}
			/* execute procedure
			 * Note: in exec() if a BEGIN is found, doBegin()
			 * is called again */
			go(l);
			if (!LL) {
				/* reload */
				if (!*p || *p<0) {
					l++;
					if (l>endCore) pe(8,l); // E08
					while ((!m[l] || !m[l][0])) 
						l++;
					if (l>endCore) pe(8,l); // E08
					strncpy_(BASESTR,m[l],COMPSCR);
					p=BASESTR;
				}
				/*  look for the terminator */
				if (!(*p==';' || sEND(p) ||\
					       !strncasecmp_(p,"ELSE",4)))
					pe(35,l); // E35
				if (*p==';') p++;
			}
		}
		if (!strncasecmp_(p,"END",3) && *(p+3)==';' && beginTOS==1) pe(35,l);
	}

	/* if a GOTO occurred and the new address is out of the block, 
	 * the cycle-break jumps here and the new address is set, 
	 * but references of LL and PL are not erased */
	if (LL) {
		l=LL;
		strncpy_(BASESTR,m[l],COMPSTR);
		p=BASESTR+PL;
		if (!*p) {
			l++;
			if (l>endCore) pe(8,l); // E08
			while ((!m[l] || !m[l][0])) 
				l++;
			if (l>endCore) pe(8,l); // E08
			strncpy_(BASESTR,m[l],COMPSCR);
			p=BASESTR;
		}
	}

	/* reset variables created in the block, and reset decCount */
	for (ic=decCount;ic>decBackup;ic--) {
		int i;
		for (i=0;i<COMPSTR;i++) {
			vn[ic].name[i]='\0';
			vn[ic].strdata[i]='\0';
			vn[ic].valdata[i]='\0';
		}
		vn[ic].type=NOTYPEBOX;
		vn[ic].isArr=FALSE;
		vn[ic].ref=0;
		vn[ic].dim=0;
		for (i=0;i<MAXDIM;i++) {
			vn[ic].ldim[i]=0;
			vn[ic].offset[i]=0;
			vn[ic].coeff[i]=0;
		}
		vn[ic].size=0;
		vn[ic].strmem=0;
		vn[ic].isOwn=FALSE;
		vn[ic].refcode=0;
		vn[ic].proccode=0;
		vn[ic].isFunc=FALSE;
		vn[ic].isFict=0;
		vn[ic].line=0;
		vn[ic].level=-1;
		vn[ic].beginlevel=-1;
		if (vn[ic].isopen) {
			fflush(vn[ic].stream);
			fclose(vn[ic].stream);
			vn[ic].stream=NULL;
		}
		vn[ic].isopen=FALSE;
		vn[ic].channel=NOCHAN;
		vn[ic].dataIndex=0;
		vn[ic].dataStart=0;
		vn[ic].dataCurr=0;
		vn[ic].dataEnd=0;	
	}
	decCount=decBackup;
	if (beginTOS>0) beginTOS--;
}


/* algolstart()
 * This is the main outer cycle; in this cycle only comments and BEGIN are 
 * admitted; the first BEGIN begins the main BEGIN-END cicle by calling
 * Here doBegin(). */
void algolstart(void) {
	l=0;
	/* read first useful line */
	while (!m[l] || !m[l][0]) {
		l++;
		if (l>endCore) break; // error
		while ((!m[l] || !m[l][0])) 
			l++;
		if (l>endCore) break; // error
		strncpy_(BASESTR,m[l],COMPSCR);
		p=BASESTR;
	}

	while (l<=endCore) {
		/* a COMMENT pre-comment starts */
		if (!strncasecmp_(p,"COMMENT",7)) {
			p+=7;
			parseComment();
			if (*p==';') p++;
			else pe(35,l); // E35
		}
		/* a ! pre-comment starts */
		else if (*p=='!') {
			p++;
			parseComment();
			if (*p==';') p++;
			else pe(35,l); // E35
		}
		/* BEGIN main structure */
		else if (!strncasecmp_(p,"BEGIN",5)) {
			p+=5;
			doBegin();
			/* discard main block final comment */
			while (*p && *p!='.' && isalnum(*p)) p++;
			p++;
			break;
		}
		/* illegal command */
		else {
			pe(8,l); // E08
		}

		/* reload string */
		if (!*p) {
			l++;
			if (l>endCore) break; // error
			while ((!m[l] || !m[l][0])) 
				l++;
			if (l>endCore) break; // error
			strncpy_(BASESTR,m[l],COMPSCR);
			p=BASESTR;
		}
	}
	END(EXIT_SUCCESS);
}


/* checkProc()
 * check procedure name, discarding dots 
 * return updated position of lp after proc name, or NULL if 
 * check failed 
 * System procedure for the exec() system function */
char *checkProc(char *lp, char *test, int len) {
	while (*lp && *test && len>0) {
		if (*lp=='.') lp++;
		if (*lp==*test) lp++, test++, len--;
		else break;
	}
	if (!len) return lp;
	return NULL;
}


/* exec()
 * the statement execution subroutine (the core of the engine, which calls
 * all the statements references in order to execute the commands)
 * lpc is the address of the execution line (the first character after the
 * line number)
 * return TRUE if execution goes well, FALSE otherwise
 * System basic function */
int exec(void) {
	int ns, type, ERRVAL=-1;
	char *lpr;

	/* reload */
	if (!*p) {
		l++;
		if (l>endCore) return FALSE;
		while ((!m[l] || !m[l][0])) l++;
		if (l>endCore) return FALSE;
		strncpy_(BASESTR,m[l],COMPSTR);
		p=BASESTR;
	}

	/* check user procedures before builtin statements */
	if ((ns=findPROC(p,&lpr,&type))) {
		/* it's an assignment to the fictitious procedure variable */
		if (*(p+_len)==PU) return FALSE;
		lpr=execPROC(ns,lpr,&numRes,NIL);
	}
	/* perform builtin statements */
	else switch(*p) {
		case 'A':
			/* ARRAY RESERVED */
			if ((lpr=checkProc(p,"ARRAY",5))) 
				p=lpr, REALARRAY();
			else ERRVAL=0;
			break;
		case 'B':
			/* BEGIN RESERVED */
			if ((lpr=checkProc(p,"BEGIN",5))) 
				p=lpr, doBegin();
			/* BOOLEAN and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"BOOLEANARRAY",12))) 
				p=lpr, BOOLEANARRAY();
			/* BOOLEAN and PROCEDURE RESERVED */
			else if ((lpr=checkProc(p,"BOOLEANPROCEDURE",16))) 
				SKIPPROCEDURE();
			/* BOOLEAN */
			else if ((lpr=checkProc(p,"BOOLEAN",7))) 
				p=lpr, BOOLEAN();
			else ERRVAL=0;
			break;
		case 'C':
			/* COMMENT RESERVED */
			if ((lpr=checkProc(p,"COMMENT",7))) 
				p=lpr, parseComment();
			/* CLOSE RESERVED */
			else if ((lpr=checkProc(p,"CLOSE(",6))) 
				p=lpr, CLOSE();
			else ERRVAL=0;
			break;
		case 'D':
			/* DATA RESERVED */
			if ((lpr=checkProc(p,"DATA",4)))
				p=lpr, parseDATA();
			else ERRVAL=0;
			break;
		case 'E':
			/* ELSE RESERVED */
			if ((lpr=checkProc(p,"ELSE",4))) 
				p=lpr, ELSE();
			/* END RESERVED */
			else if ((lpr=checkProc(p,"END",3)));
			else ERRVAL=0;
			break;
		case 'F':
			/* FOR RESERVED */
			if ((lpr=checkProc(p,"FOR",3))) 
				p=lpr, FOR();
			else ERRVAL=0;
			break;
		case 'G':
			/* GOTO and GO TO RESERVED */
			if ((lpr=checkProc(p,"GOTO",4))) 
				p=lpr, GOTO();
			else ERRVAL=0;
			break;
		case 'I':
			/* IF RESERVED */
			if ((lpr=checkProc(p,"IF",2))) 
				p=lpr, IF();
			/* INFILE RESERVED */
			else if ((lpr=checkProc(p,"INFILE",6))) 
				p=lpr, INFILE();
			/* INTEGER and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"INTEGERARRAY",12))) 
				p=lpr, INTEGERARRAY();
			/* INTEGER and PROCEDURE RESERVED */
			else if ((lpr=checkProc(p,"INTEGERPROCEDURE",16))) 
				SKIPPROCEDURE();
			/* INTEGER RESERVED */
			else if ((lpr=checkProc(p,"INTEGER",7))) 
				p=lpr, INTEGER();
			else ERRVAL=0;
			break;
		case 'L':
			/* LABEL AND PROCEDURE RESERVED */
			if ((lpr=checkProc(p,"LABELPROCEDURE",14))) 
				SKIPPROCEDURE();
			/* LABEL RESERVED */
			else if ((lpr=checkProc(p,"LABEL",5))) 
				p=lpr, LABEL();
			else ERRVAL=0;
			break;
		case 'O':
			/* OUTFILE RESERVED */
			if ((lpr=checkProc(p,"OUTFILE",7))) 
				p=lpr, OUTFILE();
			/* OWN and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"OWNARRAY",8))) 
				p=lpr, OWNREALARRAY();
			/* OWN, BOOLEAN and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"OWNBOOLEANARRAY",15))) 
				p=lpr, OWNBOOLEANARRAY();
			/* OWN and BOOLEAN RESERVED */
			else if ((lpr=checkProc(p,"OWNBOOLEAN",10))) 
				p=lpr, OWNBOOLEAN();
			/* OWN, INTEGER and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"OWNINTEGERARRAY",15))) 
				p=lpr, OWNINTEGERARRAY();
			/* OWN and INTEGER RESERVED */
			else if ((lpr=checkProc(p,"OWNINTEGER",10))) 
				p=lpr, OWNINTEGER();
			/* OWN and LABEL RESERVED */
			else if ((lpr=checkProc(p,"OWNLABEL",8))) 
				p=lpr, OWNLABEL();
			/* OWN, REAL and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"OWNREALARRAY",12))) 
				p=lpr, OWNREALARRAY();
			/* OWN and REAL RESERVED */
			else if ((lpr=checkProc(p,"OWNREAL",7))) 
				p=lpr, OWNREAL();
			/* OWN, STRING and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"OWNSTRINGARRAY",14))) 
				p=lpr, OWNSTRINGARRAY();
			/* OWN and STRING RESERVED */
			else if ((lpr=checkProc(p,"OWNSTRING",9))) 
				p=lpr, OWNSTRING();
			/* OWN RESERVED */
			else if ((lpr=checkProc(p,"OWN",3))) 
				p=lpr, OWNREAL();
			else ERRVAL=0;
			break;
		case 'P':
			/* Dartmouth PRINT procedure*/
			if ((lpr=checkProc(p,"PRINT(",6))) 
				p=lpr, PRINT();
			/* PROCEDURE RESERVED */ 
			else if ((lpr=checkProc(p,"PROCEDURE",9))) 
				SKIPPROCEDURE();
			else ERRVAL=0;
			break;
		case 'R':
			/* RANDOMIZE RESERVED */
			if ((lpr=checkProc(p,"RANDOMIZE(",10))) 
				p=lpr, SETRAN();
			/* READATA RESERVED */
			else if ((lpr=checkProc(p,"READATA(",8)))
				p=lpr, READATA();
			/* REAL and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"REALARRAY",9))) 
				p=lpr, REALARRAY();
			/* REAL and PROCEDURE RESERVED */
			else if ((lpr=checkProc(p,"REALPROCEDURE",13))) 
				SKIPPROCEDURE();
			/* REAL RESERVED */
			else if ((lpr=checkProc(p,"REAL",4))) 
				p=lpr, REAL();
			/* RESTORE RESERVED */
			else if ((lpr=checkProc(p,"RESTORE(",8))) 
				p=lpr, RESTORE();
			else ERRVAL=0;
			break;
		case 'S':
			if ((lpr=checkProc(p,"STOP",4)) && (!isnamechar(lpr))) 
				p=lpr, END(EXIT_STOP);
			/* STRING and ARRAY RESERVED */
			else if ((lpr=checkProc(p,"STRINGARRAY",11))) 
				p=lpr, STRINGARRAY();
			/* STRING and PROCEDURE RESERVED */
			else if ((lpr=checkProc(p,"STRINGPROCEDURE",15))) 
				SKIPPROCEDURE();
			/* STRING RESERVED */
			else if ((lpr=checkProc(p,"STRING",6))) 
				p=lpr, STRING();
			/* SWITCH RESERVED */
			else if ((lpr=checkProc(p,"SWITCH",6))) 
				p=lpr, SWITCH();
			else ERRVAL=0;
			break;
		case 'W':
			/* WHILE RESERVED */
			if ((lpr=checkProc(p,"WHILE",5))) 
				p=lpr, WHILE();
			/* WRITE RESERVED */
			else if ((lpr=checkProc(p,"WRITE(",6))) 
				p=lpr, WRITE();
			/* WHILE RESERVED */
			else if ((lpr=checkProc(p,"WRITEDATA(",10))) 
				p=lpr, WRITEDATA();
			else ERRVAL=0;
			break;
		default:
			ERRVAL=0;
			break;
	}
	/* in case an error was found */
	if (!ERRVAL) return FALSE;

	return TRUE;
}


/*****************************************
 *      SIGNALS & ERROR TREATMENT        *
 *****************************************/

/* perror_()
 * print a string message based upon the following information data:
 * - errNum is the error code number defined in errors.h and must always be
 *   given as first argument 
 * - ll is the line number in which the error is occurred; if null, the 
 *   line reference is not printed (general errors); this must always be given 
 *   as the second argument */
void perror_(int line, int errNum, int ll) {
	/* reset color in case of debug */
	fprintf(stdout,RESETCOLOR);
	fprintf(stderr,RESETCOLOR);

	/* print error message */
	if (!coded) {
		fprintf(stderr,"ERROR: %s AT LINE NO. %d",error[errNum], dartLin[ll]);
		fprintf(stderr,".");
	}
	else {
		fprintf(stderr,"ERROR CODE E%0d AT LINE NO. %d",errNum, dartLin[ll]);
		fprintf(stderr,".");
	}
	/* print error signal position in the code */
	if (isPrintSourceCode) fprintf(stderr," (code line=%d)",line);
	fprintf(stderr,CRS);
	fflush(stdout);
	/* stop execution */
	END(errNum);
}


/* sigtrap()
 * trap procedure for ON ATTENTION when an interrupt has been trapped */
void sigtrap(int sig) {
	/* reassign user destination SIGINT */
	sigint(sig);
}


/* sigquit()
 * end procedure for stopping when a SIGBUS or a SIGSEGV signal 
 * has been trapped */
void sigquit(int sig) {
	/* reassign the normal behavior to SIGINT */
	signal(SIGBUS, SIG_DFL);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGABRT, SIG_DFL);
	fprintf(stderr,"%s\n",error[51]); // move to 51
	exit(EXIT_FAILURE);
}


/* sigint()
 * end procedure if a SIGHUP or a SIGINT signal was trapped */
void sigint(int sig) {
	/* reassign the normal behavior to signals */
	signal(SIGINT, SIG_DFL);
	signal(SIGHUP, SIG_DFL);
	isInterrupt=TRUE;
	END(EXIT_STOP);
}


/* salloc()
 * create a memory space for strings
 * size is the size of the string (included the terminator) 
 * Note: this function was created to be portable among all UNIX systems
 * with gcc installed. */
char *salloc(int size) {
	char *value = calloc(1,(size_t)size);
	if (value == NIL) pe(26,l); // E26
	return value;
}


/* nalloc() - number alloc
 * create a memory space for numbers (double)
 * size is the size of the array (calculated elsewhere) 
 * Note: this function was created to be portable among all UNIX systems
 * with gcc installed. */
double*nalloc(size_t size) {
	double *value = calloc(sizeof(double),size);
	if (value == NIL) pe(26,l); // E26
	return value;
}


/* printHeader() */
void printHeader(void) {
	char nameonly[COMPSTR];
	int i=0;
	struct tm *dibtm;
	time_t st_lt;
	strncpy(nameonly,basename(filename),COMPSTR-1);

	/* build up name without extension */
	while (nameonly[i]!='.' && i<COMPSTR)  {
		i++;
	}
	nameonly[i]='\0';

	st_lt=time(NULL);
	dibtm = localtime(&st_lt);

	printf("\n");
	printf(HEADER,nameonly,dibtm->tm_hour,dibtm->tm_min,
			month[dibtm->tm_mon+1],dibtm->tm_mday,
			1900+dibtm->tm_year);
	printf("\n");
}


/***************************************
 *      DOCUMENTATION AND LICENSE      *
 ***************************************/

/* printHelp()
 * help message */
void printHelp(void) {
	printf("Usage: dia [options] filename\n");
	printf("\nOptions:\n");
	printf("  -b, --root-block  Add external main root block\n");
      	printf("      --coded       Print error codes, not error messages\n");
	printf("      --conditions  Print GPL3 redistribution conditions and exit\n");
	printf("  -d, --debug       Debug mode (run-time only)\n");
	printf("      --display     Activate -i and -t options\n");
	printf("      --errors-list Print a complete errors list and exit\n");
	printf("  -h, --help        Display this help and exit\n");
  	printf("      --id-line     Display program heading\n");
	printf("      --purge       Convert program to reserved mode (purging ticks)\n");
	printf("  -t, --timing      Display timing after execution\n");
	printf("  -v, --version     Display the version banner and exit\n");
	printf("      --warranty    Print warranty conditions from GPL3 and exit\n");
	printf("\nIf no file name is specified, dia will complain.\n");
    	printf("You should have received a copy of the GNU General Public License\n");
	printf("along with this program. If not, see <http://www.gnu.org/licenses/>.\n\n");
	printf("Email bugs reports to <ing dot antonio dot maschio at gmail dot com>.\n\n"); 
}


/* printVersion()
 * help banner */
void printVersion(int flag) {
	printf("\ndia (dia is ALGOL) - Dartmouth ALGOL (1965) interpreter\n");
	printf("version %s (build %d, %s, %s)\n", VERSION, BUILD, __DATE__, __TIME__);
	printf("Copyright (C) %s %s <%s>. ", CY, AU, EM);
	if (flag) printf("This program\ncomes with ABSOLUTELY NO WARRANTY; for details type 'dia --warranty'.\n");
	if (flag) printf("This is free software, and you are welcome to redistribute it under certain\n");
	if (flag) printf("conditions; type 'dia --conditions' for details.");
	printf("\nThis software is released under the terms of the GNU General Public License 3.\n\n");

}


/* printWarranty()
 * warranty message (required by GPL3) */
void printWarranty(int flag) {
	if (flag) printf("\ndia (dia is ALGOL) - Dartmouth ALGOL (1965) interpreter\n");
	if (flag) printf("version %s (build %d, %s, %s)\n", VERSION, BUILD, __DATE__, __TIME__);
	if (flag) printf("Copyright (C) %s %s <%s>. ", CY, AU, EM);
	printf("THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\n");
	printf("APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT\n");
	printf("HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT\n");
	printf("WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT\n");
	printf("LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A\n");
	printf("PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF\n");
	printf("THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME\n");
	printf("THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\n");

}


/* printConditions()
 * conditions message (required by GPL3) */
void printConditions(int flag) {
	if (flag) printf("\ndia (dia is ALGOL) - Dartmouth ALGOL (1965) interpreter\n");
	if (flag) printf("version %s (build %d, %s, %s)\n", VERSION, BUILD, __DATE__, __TIME__);
	if (flag) printf("Copyright (C) %s %s <%s>. ", CY, AU, EM);
	printf("You may make, run and propagate covered works that you do not convey,\n");
	printf("without conditions so long as your license otherwise remains in force.\n");
	printf("You may convey covered works to others for the sole purpose of having\n");
	printf("them make modifications exclusively for you, or provide you with\n");
	printf("facilities for running those works, provided that you comply with the\n");
	printf("terms of this License in conveying all material for which you do not\n");
	printf("control copyright. Those thus making or running the covered works for\n");
	printf("you must do so exclusively on your behalf, under your direction and\n");
	printf("control, on terms that prohibit them from making any copies of your\n");
	printf("copyrighted material outside their relationship with you.\n\n");

}


/******************************************************************************
 * MAIN SECTION
 ******************************************************************************/

/* main() 
 * parse options, get file name, setup environment and perform, at request, 
 * the following actions:
 * OLD to create the file in memory
 * RUN to execute the file
 * Here is where it all begins... and where it all ends */
int main(int argc, char **argv) {
	int c, ac=0;
	
	/* record starting time; beginS is used in the INFO function */
        gettimeofday(&tv, NULL);
        beginS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
        beginM = (int)(tv.tv_sec *1000 + tv.tv_usec / 1000);

	/* set features that depend on starting time and the PRINT string */
	now=time(NULL);
	GLOB[0]='\0';

	/* parse options; double and single dash options may be alternated,
	 * options requiring an argument may or not be attached (but must
	 * be the last options of that group);
	 * ~Antonio Maschio - March 2014 for the decb project */
	while (++ac < argc) {
		if (*argv[ac]=='-') {
			/* PARSE DOUBLE-DASH OPTIONS */
			/* option --help */
			if (!strcasecmp(argv[ac], "--help")) { 
				printHelp(); 
				exit(EXIT_SUCCESS); 
			}
			/* option --errors-list */
			else if (!strcasecmp(argv[ac], "--errors-list")) { 
				int i;
				char *y;
				fprintf(stdout,"\nErrors list for dia ");
				fprintf(stdout,"version %s\n\n",VERSION);
				for (i=0;i<ERRLIM;i++) {
				    y=error[i];
				    if (*y) fprintf(stdout,"%3d %s\n",i,y);
				}
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS); 
			}
			/* option --version */
			else if (!strcasecmp(argv[ac], "--version")) {
				printVersion(TRUE);
				exit(EXIT_SUCCESS); 
			}
			/* option --warranty */
			else if (!strcasecmp(argv[ac], "--warranty")) {
				printWarranty(TRUE);
				exit(EXIT_SUCCESS);
			}
			/* option --conditions */
			else if (!strcasecmp(argv[ac], "--conditions")) {
				printConditions(TRUE);
				exit(EXIT_SUCCESS);
			}
			/* option --root-block 
			 * set root block */
			else if (!strncmp(argv[ac],"--root-block",12)) {
				addMainRootBlock=TRUE;
				continue;
			}
			/* option --purge 
			 * purge program from ticks*/
			else if (!strncmp(argv[ac],"--purge",7)) {
				isPurge=TRUE;
				continue;
			}
			/* option --display
			 * set timing */
			else if (!strncmp(argv[ac],"--display",9)) {
				isPrintHeader=TRUE;
				isTiming=TRUE;
				continue;
			}
			/* option --timing 
			 * set timing */
			else if (!strncmp(argv[ac],"--timing",8)) {
				isTiming=TRUE;
				continue;
			}
			/* option --id-line 
			 * print heading */
			else if (!strncmp(argv[ac],"--id-line",9)) {
				isPrintHeader=TRUE;
				continue;
			}
			/* option --coded
			 * set normal Debug mode */
			else if (!strncmp(argv[ac],"--coded",7)) {
				coded=TRUE;
				continue;
			}
			/* option --debug 
			 * set normal Debug mode */
			else if (!strncmp(argv[ac],"--debug",7)) {
				isDebug=TRUE;
				continue;
			}
			/* option --greetings  (UNDOCUMENTED) */
			/* this feature is intentionally undocumented 
			 * I use it to generate the README file */
			else if (!strcasecmp(argv[ac], "--greetings")) {
				printf("Welcome, dia user! I hope you\'ll like ");
				printf("this program.\n");
				printf("Here\'s some information about it ");
				printf("and its license...\n");
				printVersion(FALSE);
				printHelp();
				printf("To compile type 'make' as user in ");
				printf("dia source directory.\nTo install ");
				printf("type 'make install' as root after compiling.\n");
				printf("For help about dia's features, after");
				printf(" installation, see 'dia_manual.pdf'.\n\n");
				printWarranty(FALSE);
				printConditions(FALSE);
				printf("It's GPL. Enjoy!\n");
				exit(EXIT_SUCCESS);
			}
			/* Ignore unrecognized options */
			else if (!strncmp(argv[ac],"--",2)) {
				fprintf(stderr,"(dia: %s%s)\n",argv[ac],error[52]); // move to 52
				continue;
			}
			
			/* PARSE SINGLE-DASH OPTIONS */
			while (*++argv[ac]) {
				c=*argv[ac];
				/* option -b 
				 * add root block */
				if (c=='b') {
					addMainRootBlock=TRUE;
				}
				/* option -d 
				 * set normal Debug mode */
				else if (c=='d') {
					isDebug=TRUE;
					stopKey=TRUE;
				}
				/* option -h 
				 * print help*/
				else if (c=='h') {
					printHelp(); 
					exit(EXIT_SUCCESS); 
				}
				/* option -i
				 * print heading */
				else if (c=='i') {
					isPrintHeader=TRUE;
				}
				/* option -S 
				 * print number of source-code line in error messages 
				 * (UNDOCUMENTED) */
				else if (c=='S') {
					isPrintSourceCode=TRUE;
				}
				/* option -t 
				 * set timing */
				else if (c=='t') {
					isTiming=TRUE;
				}
				/* option -v 
				 * print version */
				else if (c=='v') {
					printVersion(TRUE);
					exit(EXIT_SUCCESS); 
				}
				/* option -V 
				 * print only version numbers (version-number-release) 
				 * (UNDOCUMENTED) */
				else if (c=='V') {
					fprintf(stdout,"%s",VERSION);
					exit(EXIT_SUCCESS); 
				}
				/* 
				 * ignore unrecognized options */
				else fprintf(stderr,"\n(-%c%s)\n",c,error[52]); // move to 52
			}
		}
		else break;
	}

	/* Widen resources for recursion (*rlim are defined into dia.h)*/
	getrlimit(RLIMIT_STACK,&origrlim);
	setrlimit(RLIMIT_STACK,&diarlim);

	/* OK; now if, after any option, no file name was given
	 * (or if dia was launched with no parameters), issue an error */
	if ((ac==argc)||(1==argc)) {
		fprintf(stderr,"%s\n",error[50]); // move to 50
		exit(EXIT_FAILURE);
	}

	/* get input file name (discard following arguments) 
	 * and setup name, attaching extension if not present */ 
	strncpy_(filename, argv[ac], COMPSCR);
	setupName(filename);

	signal(SIGABRT, sigquit);
	signal(SIGSEGV, sigquit);
	signal(SIGBUS, sigquit);
	/* Trap interrupts */
	signal(SIGHUP, sigint);
	signal(SIGINT, sigint);

	/* Store tcgetattr values */
	tcgetattr(0, &modes);
	savemodes = modes;

	/* OLD (implicit!)
	 * store program in memory */
	OLD();

	/* --purge option
	 * purge the ALGOL program from ticks, spit it to stdout and exit */
	if (isPurge) {
		FILE *fd;
		char *w;
		int isComment=FALSE, isString=FALSE;
		fd=fopen(filename,"r");
		while(fgets(B,COMPSTR,fd)) {
			if (B[(int)strlen(B)-1]==13) B[(int)strlen(B)-1]='\0';
			if (B[(int)strlen(B)-1]==10) B[(int)strlen(B)-1]='\0';
			if (B[(int)strlen(B)-1]==13) B[(int)strlen(B)-1]='\0';
			w=B;
			while (*w) {
				/* try to avoid comments and strings
				 * from purging the ticks */
				char op[COMPSTR];
				if (!strncasecmp_(w,"COMMENT",7) && !isComment && !isString){
					isComment= TRUE;
					sprintw(op,8,"%s",w);
					w+=7;
					if (*w=='\'') w++;
					fprintf(stdout,"%s",op);
				}
				else if (*w==';' && isComment && !isString) {
					isComment= FALSE;
				}
				else if (*w=='\"' && !isString && !isComment) isString=TRUE;
				else if (*w=='\"' && isString && ! isComment) isString=FALSE;

				/* put character: always, in case of comments
				 * or strings, or only if not a tick in all other cases */
				if (isComment || isString) putc(*w,stdout);
				else {
					if (*w!='\'') putc(*w,stdout);
				}
				w++;

			}
			putc('\n',stdout);
		}
		END(EXIT_SUCCESS);
	} // end purge

	/* RUN (finally!)
	 * Note: RUN records also starting timer */
	if (isPrintHeader) printHeader();
	RUN();
    	
	/* END (safety measure, it should never happen here) */
	END(EXIT_SUCCESS);

	/* this is needed for C */
	return EXIT_SUCCESS; 

} /* end main */

