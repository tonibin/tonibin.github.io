/* soft.h
 * Copyleft (C) 2009-2018 Antonio Maschio
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 07 agosto 2021
 *
 * This is soft, a Snobol interpreter written in c99 for the UNIX world.
 * You must have gcc 4.X to compile (I suppose, though even 3.X may suffice).
 * This is the main header
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stddef.h>
#include <dirent.h>
#include <sys/dir.h>
#include <sys/param.h>
#include <errno.h>
#include "errors.h"
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <fnmatch.h>
#include <stdarg.h>
#include <sys/resource.h>
#include <libgen.h>
#include <pwd.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <termios.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <stdint.h>

/* customizable values -
 * Note: normally, the variables number VLIMIT is sufficient for any program.
 * Should you need more variable indices (in the assumption the memory of
 * your PC can stand it) you can increase and recompile. */
#define MEMLIMIT      15000      /* soft's memory unit magnitude */
#define VLIMIT        10000      /* variables number limit */
#define SHELLEX       "bash"     /* preferred shell */

/* Hardwired versioning strings (dont' change!) */
#define VERSION "1.0.Alpha report"
#define AU "Antonio Maschio"		                  /* Author */
#define EM "ing dot antonio dot maschio at gmail dot com" /* Email */
#define CY "2019-2022"		  	                  /* Years */

/* Hardwired constants (don't change!) */
#define TRUE  1
#define FALSE 0
#define INTEGER  	 100		// INTEGER data type code
#define REAL 		 200		// REAL data type code
#define STRING  	 300		// STRING data type code
#define PATTERN  	 400		// PATTERN data type code
#define NAME		 500		// NAME type code
#define CODE		 600		// CODE type code
#define ARRAY	  	 700		// ARRAY data type code
#define DATA		 800		// DATA type code
#define READFILE	1000
#define WRITEFILE	1100
#define PREDEF	       10000
#define MAXDIM            16		// max dimensions for arrays dim 1÷15
#define MAXINC            10		// max INCLUDE levels (0..9)
#define LISTTAB     	   8
#define INT_BITS	  32

char *types[]=
{"UNKNOWN", "INTEGER","REAL","STRING","PATTERN","NAME","CODE","ARRAY","DATA"};
#define RESFILE 	"soft_res.dat"

#define FAIL		10
#define SUCCESS		20
#define ECHAR		127
/* Note: COMPLETESET is the basic ASCII string, made of the characters from
 * ASCII 1 to ASCII 254 with 255 at start and end */
#define COMPLETESET	"\xFF\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F !\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}\x7E\x7F\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8A\x8B\x8C\x8D\x8E\x8F\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9A\x9B\x9C\x9D\x9E\x9F\xA0\xA1\xA2\xA3\xA4\xA5\xA6\xA7\xA8\xA9\xAA\xAB\xAC\xAD\xAE\xAF\xB0\xB1\xB2\xB3\xB4\xB5\xB6\xB7\xB8\xB9\xBA\xBB\xBC\xBD\xBE\xBF\xC0\xC1\xC2\xC3\xC4\xC5\xC6\xC7\xC8\xC9\xCA\xCB\xCC\xCD\xCE\xCF\xD0\xD1\xD2\xD3\xD4\xD5\xD6\xD7\xD8\xD9\xDA\xDB\xDC\xDD\xDE\xDF\xE0\xE1\xE2\xE3\xE4\xE5\xE6\xE7\xE8\xE9\xEA\xEB\xEC\xED\xEE\xEF\xF0\xF1\xF2\xF3\xF4\xF5\xF6\xF7\xF8\xF9\xFA\xFB\xFC\xFD\xFE\xFF"
#define lcase           "abcdefghijklmnopqrstuvwxyz"
#define ucase           "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
#define digits          "0123456789"
#define LOGO "	           _|   |\n                  /   _  _|\n    __|   _     _  _|   |\n   \\     /   \\    |     |\n  \\___/ \\____/   _|    _| %sS%snobol %sOF T%sony\n\n"

#define NIL 0
#define LIMIT 999			// soft's core extension chunk length
#define COMPSTR 2048			// maximum length of a C-string 0..2046+terminator
#define ZERO 8.6361685763E-78 		// smallest real not zero (2^-256)
#define RZERO 1.38777878078E-17 	// smallest random not zero (2^-56)
#define PSTACK 256			// dimension of the inner RPN stack
#define CORELIM 100000 	 		// limit for invalid line number
#define STREAMS 20			// max number of file channels
#define VWRITE 10
#define VREAD  20			// read/write modes
#define PATPAD 65			// number of patterns in a clause
#define CONTINUE -100
#define MAXARGS 16			// limit for alternations
#define SCREEN  40
#define SOFTPI  3.14159265358979323846	// pi
#define MAXRAN  32768
#define GREET "Notes:\n- to compile type \'make\' as user in soft\' source directory.\n- to install type \'make install\' as root after compiling.\n  (but I'm sure you know better than me what to do!)\n\n"
#define WELCOME "\nWelcome, user! I hope you\'ll like this program.\nHere\'s some information about it and its license...\n"
#define INVCOLOR   "[7;37;40m"
#define RESETCOLOR "[1;m"
#define BLUECOLOR  "[1;34m"
#define GREENCOLOR  "[1;32m"
#define REDCOLOR  "[1;31m"
#define ATTACH    "\n"
#define HISTORY	"./.soft_history"	// readline facility
#define PRINTF  "__temp_printer_soft.txt__.txt"
#define DEBUGHISTORY	"./.soft_debug_history"	// readline facility
#define VOIDS   ""
#define OFLOW  1.0/0.0
#define BANNER "\n-----------------------------------------------------------------------------\nWelcome to soft, an implementation of SNOBOL4 in C (version %s)\nbuilt according to the Berkeley Version implemented at the University of\nCalifornia (see the manual of Robert Gaskins and Laura Gould - Spring 1972)\nby Antonio Maschio <ing dot antonio dot maschio at gmail dot com> 2020-2021\nIt's GPL: Enjoy!\n-----------------------------------------------------------------------------\n\n"
#define EFF	21
#define FREEZECODE "#@||@#"
/* debugging */
#define WRONGDEBUG     -1
#define NODEBUG		0
#define ALLRESETDEBUG   1
#define ALLVARSDEBUG    2
#define BASEDEBUG 	3
#define BREAKDEBUG	4
#define CHANNELSDEBUG   5
#define CLISTDEBUG      6
#define CONTDEBUG	7
#define COUNTDEBUG	8
#define CURSORDEBUG	9 
#define DATASTRUCT     10
#define DEBUGMODE      11
#define DEFINFODEBUG   12
#define DIRDEBUG       13
#define DISABLEDEBUG   14
#define ERASEDEBUG     15
#define FILEDEBUG      16
#define HELPDEBUG      17
#define INFODEBUG      18
#define LABELSDEBUG    19
#define LISTDEBUG      20
#define LOADDEBUG      21
#define MEMORYDEBUG    22
#define MONITORDEBUG   23
#define NEXTDEBUG      24
#define NLISTDEBUG     25
#define ORIGINALDEBUG  26
#define PARAMDEBUG     27
#define PATTERNDEBUG   28
#define PIEMODE        29
#define QUITDEBUG      30
#define REMARKDEBUG    31
#define RESETDEBUG     32
#define RUNDEBUG       33
#define SETDEBUG       34
#define SHELLDEBUG     35
#define STATEDEBUG     36
#define TRACEDEBUG     37
#define TYPEDEBUG      38
#define UNTRACEDEBUG   39
#define VERSIONDEBUG   40
#define WATCHDEBUG     41
#define LASTDEBUG      42
#define DEBUGSCREEN    70
static char *debugCommand[]=
{"","ALLRESET","ALLVARS","BASE","BREAKPOINT","CHANNELS","CLIST","CONTINUE","COUNT","CURSOR","DATASTRUCT","DEBUGMODE","DEFINED","DIR","DISABLE","ERASE","FILE","HELP","INFO","LABELS","LIST","LOAD","MEMORY","MONITOR","NEXT","NLIST","ORIGINAL","PARAMETERS","PATTERN","PIEMODE","QUIT","REMARK","RESET","RUN","SET","SHELL","STATE","TRACE","TYPE","UNTRACE","VERSION","WATCH"};
int getDebugCommand(char *a, int *l, char *o);
#define ATNUM	       23
static char *classic[]=
{"","&ABORT","&ALPHABET","&ARB","&BAL","&DIGITS","&ERRTYPE","&FAIL","&FENCE","&FILE","&FNCLEVEL","&LASTNO","&LCASE","&LINESNO","&MEMLIMIT","&PARM","&PI","&REM","&RTNTYPE","&SPACE","&STCOUNT","&STFCOUNT","&STNO","&UCASE"};

/* Detect Windows (MSYS or Mingw) */
#ifdef _WIN16 
    #define NOUNIX
#endif
#ifdef _WIN32 
    #define NOUNIX
#endif
#ifdef _WIN64 
    #define NOUNIX
#endif
#ifdef WINDIR 
    #define NOUNIX
#endif
#ifdef windir 
    #define NOUNIX
#endif


/* DECLARE structure */
struct t_declare {
	char name[COMPSTR];	// declaration name
	int ref;		// array reference
	int datatype;		// = INTEGER|REAL|STRING|PATTERN
	int iotype;		// = VREAD|VWRITE
	int datachan;		// = integer 0..15
	char str[COMPSTR];
	double num;
	int dim; 		// type 0=undeclared, 1=vector, 2=matrix, etc..
	int ldim[MAXDIM];	// array dimensions widths
	int offset[MAXDIM];	// offsets for array dimensions, e.g. [-3:5]
	int coeff[MAXDIM];	// coefficient for the position calculus
	int size;		// array global space
	int strmem;		// dimension of string
	int isData;		// TRUE if a DATA item
	int isCode;		// TRUE if a CODE item
	char proto[COMPSTR];	// prototype
	char argparam[COMPSTR];
	int argtype;
};
typedef struct t_declare TDeclare;

/* DIM structure for array types */
struct t_array {
	int *elem;		// pointer to the array base
};
typedef struct t_array Tarray;

/* DIM structure for string arrays */
struct ts_array {
	char *elem;		// pointer to the array string
};
typedef struct ts_array TSarray;

/* stream structure for I/O channels */
struct t_iostream {
	/* general parameters */
	FILE * stream;		// file descriptor
	char ioname[COMPSTR];	// file name
	int wayout;		// VREAD | VWRITE
	int datalen;		// Length for INPUT()
	char attach[COMPSTR];	// Attach for OUTPUT()
	int isKYB;		// flag for getting input from keyboard
	int isCanon;		// flag for canonical features disabling
	int isPrinter;		// printer redirection flag
	int isLastWrite;	// flag for last write operation
};
typedef struct t_iostream Tiostream;

/* DATA structure */
struct t_data {
	char name[COMPSTR];	// constructor
	char proto[COMPSTR];	// proto
	int num;		// number of associated methods
};
typedef struct t_data TData;

/* DEFINE structure */
struct t_define {
	char name[COMPSTR];		// name of definition
	char argproto[COMPSTR];		// proto for arguments
	char otherproto[COMPSTR];	// proto for other aid variables
	char startlabel[COMPSTR];	// name of starting label
	int label;			// line number where the program starts
	//int decStart;			// first available variable code
	int nreturn;			// NRETURN was used
	int anum;			// arg num
	int lnum;			// local num
};
typedef struct t_define TDefine;

/* Functions prototypes (decidedly don't change!)*/
void OUTPUTPRINTS(int ch, int ns);
int INPUT(char *lp);
char *DO_INPUT(void);
int OUTPUT(char *lp);
void DO_OUTPUT(int ns);
int END(int s);
int LOAD(char **m, int from, int labelfrom, char *f);
int RUN(void) ;
char *GS(void);
int eval_options(int a, char **b);
void doPragma(char *p);
int copyArray(int t, int f);
int dimStrArray(int var, int T, int *M, char* i, int ty);
char *getArrayStr(int var, int t, int *m) ;
void setArrayStr(int var, int t, int *m, char *str);
double getArrayVal(int var, int t, int *m) ;
void setArrayVal(int var, int t, int *m, double val);
int assign(void) ;
int proceed(void) ;
int patterns(void) ;
char *scanner(char *FIRST, char *s, char **mm) ;
char *alt_scan(char *first, char *pat);
char *unveil(char *str);
char *AS(void);   // Assemble Strings in Pattern Evaluation
char *SS(void);   // Single String in Pattern Evaluation
char *JP(int *i); // Join Patterns in Assignments
char *GP(int *i); // Get Pattern in Assignments
int parseInt(char *str);
void evalDollar(char *p);
void evalDot(char *p);
void evalAt(void);
char *strchr_up(char *pl, char pr);
char *strcasestr_oq(char *pl, char *pr);
char *strcasechr_oq(char *pl, char pr);
char *strcasestr_(char *big, char *little);
int strncasecmp_(char *d, char *s, int N);
int strcomp(char *d, char *s);
char *strncpy_(char *dst, char *src, int dw);
char *strncat_(char *dst, char *src, int dw);
char *strstr_(char *b, char *p);
char *strstr_proper(char *b, char *p);
char *chrcat_(char *dst, int c, int dw);
//int sprintw(char *dest, int len, char *format, ...);
int fgets_(char *s, int n, FILE *f);
int isin(char *b, char c);
int checkBal(char *str);
void skipAlt(void);
double S(void) ;
double getFunc(char *p);
int flag(void) ;
int string(char *mypad) ;
char *getStr(void);
char *getString(int i);
double getVal(char *p);
int priority(const int op) ;
int findDEC(char *p);
int findDATA(char *p);
int findARRAY(char *p);
int findHidden(char *p);
void resetFileIndex(void);
int searchDEC(char *p, int s);
void declare(char *name, int type, int arr, int chan, int io);
char *getMonthString(void) ;
char *makechar(char *str) ;
char *spaces(int v);
int exec(char *lpc) ;
void data(int ns, int i);
void retdata(int n, int o, int e);
void copyItem(int n, int o);
char *code(void);
void s_exit(int state);
int getDay(void) ;
int getWDay(void) ;
int getHour(void) ;
int getMin(void) ;
int getMonth(void) ;
int getSec(void) ;
int getYear(void) ;
int sign(double h);
struct tm *getTime(void) ;
void parse(int s) ;
char *findNext(char *p);
void turnToUpper(char *str) ;
void turnToUpper_oq(char *str) ;
void sigint(int sig);
int setAddr(char *l);
void erase(char *d, int s);
void memcpy_(void *dst, void *src, int size);
int setup(void) ;
void erasemem(void) ;
int convert(FILE *fn, int n, int s);
int getLabelAddr(int val);
void doStats(double s);
void doTiming(double s);
void listLine(int i, int d);
void printCurState(void);
char *define(int n, char *c, int *f);
int findPROC(char *p);
int isOpenFile(char *s);
/* Error messaging system */
int perror_(int line, int errNum, int l, ...) ;
/* Info messaging collection */
void printConditions(void) ;
void printExistence(int i,int c);
void printHelp(int i) ;
void printVersion(int i) ;
void printHelpBanner(void) ;
void printUsage(void) ;
void printWarranty(void) ;

/* Inspective macros (imperatively don't change!) */
#define ispow(p)           ((*(p)=='*' && *(p+1)=='*'))
#define isender(p)         (*(p)==',' || *(p)==')' || *(p)==']' || *(p)=='=' || !*p || *p==':')
#define isnm(p)            (isdigit(*(p)) || ((*(p)=='+' || *(p)=='-') && (isdigit(*((p)+1)) || *((p)+1)=='.')))
#define isflot(p)          (isdigit(*(p)) || *(p)=='+' || *(p)=='-' || toupper(*(p))=='E' || *(p)=='.')
#define ismo(p)            (*(p)=='+' || *(p)=='-' || *(p)=='*' || *(p)=='/' || *(p)=='\\' || *(p)=='^' || *(p)=='!')
#define isop(p)            ismo(p)
#define isquote(p)         (*(p)=='\'' || *(p)=='\"')
#define isnamechar(p)      (*(p)=='.' || *(p)=='_' || (isalnum(*(p))))
#define isbeginnamechar(p) ((isalpha(*(p))))
#define isterm(p)          (*(p)=='=' || *(p)==':' || !*(p))
#define issuperblank(p)    (*(p)==' ' || *(p)=='\n' || *(p)=='\v' || *(p)=='\t' || *(p)=='\r')
#define ispat(p)	   (isblank(*(p)) || !*(p) || *(p)==')')

/* Lotsa global variables! */
/* System variables (Don't change at all!) */
char *BASETOT;
int doThePragma=TRUE;
int endCode=0;
int returnCode=0;
int freturnCode=0;
int nreturnCode=0;
char LOGNAME[COMPSTR];

/* dot assign*/
#define MAXDOT 17
int dotTOS=0;
char dotstr[MAXDOT][COMPSTR];
int dotval[MAXDOT][MAXDIM+1];
int dotvar[MAXDOT];
int dotudim[MAXDOT];
//int dataDetected=FALSE;

/* arbno data */
char *next[MAXARGS+1];
int nextscan[MAXARGS+1];
int use[COMPSTR];

/* random generation */
int randSeed=7139;
int randDivi=24424;
double getRandom(void);
void randomize(void);

/* system */
int isIF=FALSE;
int currentDECstart=0;
int currentDECstartBack=0;
int isFtrace=0;
int isTrace=0;
int isToAlter=FALSE;
int isPie=FALSE;
int isInterrupt=FALSE;
int isPreprocessOnly=FALSE;
int isBanner=FALSE;
int isRunAnyway=FALSE;
char userlist[COMPSTR];
int isUserList=FALSE;
char second[COMPSTR];
char pattern[COMPSTR];
char upattern[COMPSTR];
char AIDPAD[COMPSTR];
char UVPAD[COMPSTR];
char SSPAD[COMPSTR];
char GPPAD[COMPSTR];
char GSPAD[COMPSTR];
char SCNPAD[COMPSTR];
char ASCNPAD[COMPSTR];
char ASPAD[COMPSTR];
char GALTPAD[COMPSTR];
char JPPAD[COMPSTR];
char *MYPAD, *JSPAD, *DIPAD, *CSPAD, *SASPAD, *DAPAD, *CDPAD, *PRPAD, *RNPAD;
char instr[COMPSTR];
int  fileTOS=1;
int inF=1;
int outF=0;
char filename[COMPSTR];
char line[COMPSTR]; // needs to be global
int endCore=0;
int goPie=FALSE;
int isDebug=FALSE;
int isFinDebug=FALSE;
int isExDebug=FALSE;
int isCommandDebug=FALSE;
int isPrinter=FALSE;
int isQuit=FALSE; // goInt()
int isResFile=FALSE;
int isPrintSourceCode=FALSE;
//int forceArray=FALSE;
int isFreeze=FALSE;
int isFreezeOnExit=FALSE;
struct winsize wsz;
int sysWidth=80;
/* System strings */
static char *month[]=
{"", "JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC" };
int isListNumbered=FALSE;
int isListOriginal=FALSE;
int isListBefore=FALSE;
int isPrintComplete=FALSE;

/* Program flow and var variables
 * l holds the current program line number
 * a holds the current alternation in the line number
 * P is an double array holding variables contents
 * PS is a character-pointers-array holding references to strings
 * startingLine holds user specified starting line (for RUN)
 * pads are temporary string buffers */
int l=0,lo=0;
char pad[COMPSTR];
char prompt[COMPSTR];
char FIRST[COMPSTR];
int notAMathExpression=FALSE;
#define CFIRST (FIRST+scan)

/* findDEC aid
 * _len holds complete name length
 * _datatype hold return type code
 * _exprtype hold expressions return type code
 * _arr hold array flag */
int _len,_datatype,_exprtype;

/* DIM arrays data management
 * dim is the numerical array
 * dimS is the string array
 * BASE is the OPTION BASE code */
Tarray dim[VLIMIT+10];
TSarray dimS[VLIMIT+10];

/* Memory system
 * m is an array holding pointers to program lines
 * p is the main char pointer to the current buffer position
 * s and d are various char pointer helpers used into RUN
 * ln holds the addresses of a line number labels (ln[line]=linenum
 * alt holds the alternate choice point */
char *m[MEMLIMIT+10], *p,*s,*d;
char *mb[MEMLIMIT+10];
char *label[MEMLIMIT+10];
int ln[MEMLIMIT+10];
char argparam[COMPSTR];
int argtype;
int lnTOS=0;
int report=TRUE;
int rightPos=TRUE;
int isError=FALSE;
/* parser variable - TRUE when an operator is expected */
int opturn=0;	// don't change!
int scan=0;
int bscan=0;
int isNotExponential=1;
int isAnchored=FALSE;
int isGTrim=FALSE;
int isAbend=FALSE;
char parm[COMPSTR];
int isOutput=TRUE;
int isInput=TRUE;
int isStLimit=1000000;	// limit of executable lines;
int isDumping=FALSE;
int isListAfter=FALSE;
int isAvoidDirectives=FALSE;
int isCompleteUnload=FALSE;
int isCompleteList=FALSE;
int printState=FALSE;
int isFullscan=FALSE;
int isMaxlngth=FALSE;
int isAPattern=FALSE;
int isAnArray=FALSE;
int tot=0;
int btot=0;
//int fenceNeedle=-1;
char *fenceNeedle=NULL;
int trace[PSTACK];
int traceTOS=0;
char toBeTraced[MAXARGS][COMPSTR];
int toBeTracedTOS=0;
int resat[MAXARGS+1];
int dresat[MAXARGS+1];
char *presat[MAXARGS+1];
char patresat[MAXARGS+1][COMPSTR];
int resTOS=0;
int procCode=EXIT_SUCCESS;
int unveilSays=TRUE;
char startLabel[COMPSTR];
int parOrder=0;
char parNext[PSTACK][COMPSTR];
int ILEVEL=0;
int FFLAG=TRUE;
int SPFLAG=1;
int LIFLAG=0;

/* DECLARE management
 * vn holds the DECLARE definitions in a proper struct
 * decCount holds current number of declared variables */
TDeclare vn[VLIMIT+10];
#define BACKARR VLIMIT+3
int decCount=0;
int breaks[VLIMIT+10];
int breakTOS=0;

/* DEFINE management */
TDefine definefunc[PSTACK];
int defineTOS=0;
int funcTOS=0;
int nreturnActed=FALSE;

/* DATA management */
TData datafunc[PSTACK];
int dataTOS=0;

/* CODE management */
int finalCore=0;

/* Timing variables
 * tv is used for time calculations
 * beginS is calculated at start for the TIM() function and the timer
 * now contains seed for current number generator */
struct timeval tv;
double beginS=0.0, endS=0.0;
time_t now;
int isTiming=FALSE;

/* I/O variables
 * channel contains the channel 0-9 data (0 = console, 10 = route channel) */
Tiostream channel[STREAMS+2];		// BASIC channels 1-9
char openFiles[STREAMS+2][COMPSTR];
FILE *openStreams[STREAMS+2];
char joblog[COMPSTR];
char username[COMPSTR];
#define JOBLOG ".soft_log.txt"
int isDefJobLog=TRUE;
int noFile=FALSE;
int isFlow=FALSE;

/* control statements */
int ml[MEMLIMIT+10];	// -INCLUDE levels
int mf[MEMLIMIT+10];	// -FAIL/-NOFAIL flags
int md[MEMLIMIT+10];	// -SINGLE/-DOUBLE flags
int ms[MEMLIMIT+10];	// -LIST flags
char DTITLE[COMPSTR];	// -TITLE
char STITLE[COMPSTR];	// -STITLE
int isToListD=FALSE;	// -LIST activator

/* stats variables */
int sActive=0;	// counts program lines in LOAD()
int sLast=0;	// set to l (el) at every launch of assign()
int sLastNo=0;	// set to l (el) before assigning new l
int sStatms=0;	// number of statements executed
int sFail=0;	// number of failed statements
int sMaths=0; 	// number of math calculations
int sPatt=0;	// number of evaluated patterns
int sErr=0;	// code of last error code
int lErr=0;	// code of last error code line
int sMatches=0; // number of matching patterns
int sReads=0;	   // number of inputs
int sWrites=0;	   // number of outputs
int isStats=FALSE; // activator in option --isStats
char sReturn[COMPSTR];
int sDefVar=0;

/* -EJECT elements */
int isFormat=FALSE;
int isNoExecute=FALSE;
int nPage=1;
int nCurr=1;
#define EJPAGE 60

/* --trace-on-stop */
char onStop[MAXDIM+1][COMPSTR];
int isTraceOnStop=FALSE;
int stopTOS=0;

/* end of soft.h */


