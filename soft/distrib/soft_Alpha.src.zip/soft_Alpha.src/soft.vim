" Vim syntax file
" Language:     SNOBOL4 (soft version)
" Maintainer:   Antonio Maschio <ing.antonio.maschio@gmail.com>
" Creator:      Rafal Sulejman <rms@poczta.onet.pl>
" Note: Rafael created the Snobol4 version (thanks, Rafa!), and I adapted
"       his creation for soft.
" Update: 04 agosto 2021
" Changes: 

" For version 5.x: Clear all syntax items
" For version 6.x: Quit when a syntax file was already loaded
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif

syntax case ignore

syn keyword softTodo contained	TODO FIXME XXX

" Snobol4 keywords
syn keyword     softKeyword      abort any apply arb arbno array bal
syn keyword     softKeyword      break abs alphabet anchor atan arctan
syn keyword     softKeyword      asin acos arcsin arccos lshift rshift
syn keyword     softKeyword      not or and eqv imp xor backspace clear
syn keyword     softKeyword      echo endfile errtext filesize lpad rpad
syn keyword     softKeyword      char chop clock code cos convert debug replace
syn keyword     softKeyword      data datatype date define detach differ screen
syn keyword     softKeyword      dump dupl endgroup eoi eorlevel eq exp fail
syn keyword     softKeyword      ge gt ident input integer item family fence
syn keyword     softKeyword      lt ne notany file eval pragma remdr
syn keyword     softKeyword      first fnclevel freeze freturn ge gt ident
syn keyword     softKeyword      if include input item le left len leq lgt
syn keyword     softKeyword      load log ln maxlngth nextvar notany nreturn
syn keyword     softKeyword      ord output param pi pos prototype rem remark
syn keyword     softKeyword      rename rest return rewind right root put rpos
syn keyword     softKeyword      rtab selector sin size span sqrt sqr stoptr
syn keyword     softKeyword      stcount stlimit tab tan time trace trim
syn keyword     softKeyword      terminal type keyin return printer set seek
syn keyword     softKeyword      unload untrace random randomize forward

" escaping characters
syn match       softSpecChar     display contained "\\n"
syn match       softSpecChar     display contained "\\t"

" string
syn region      softString       matchgroup=Quote start=+"+ end=+"+ contains=softSpecChar
syn region      softString       matchgroup=Quote start=+'+ end=+'+ contains=softSpecChar
syn match       softConstant     /"[^a-z"']\.[a-z][a-z0-9\-]*"/hs=s+1
syn region      softGoto         start=":\s*[sf]\{0,1}(" end=")\|$\|;" contains=ALLBUT,softParenError
syn match       softNumber       "\<\d*\(\.\d\d*\)*\>" 
syn match       softBogusSysVar  "&\w\{1,}"
syn match       softSysVar       "&\(abend\|abort\|alphabet\|anchor\|arb\|bal\|code\|digits\|dump\|errtype\|errline\|fail\|fence\|file\|fnclevel\|ftrace\|fullscan\|input\|lastno\|lcase\|linesno\|output\|maxlngth\|memlimit\|parm\|pi\|real\|rem\|rtntype\|space\|stcount\|stfcount\|stlimit\|stno\|trace\|trim\|ucase\)"

" Parens matching
syn cluster     softParenGroup   contains=softParenError
syn region      softParen        transparent start='(' end=')' contains=ALLBUT,@softParenGroup,softErrInBracket
syn match       softParenError   display "[\])]"
syn match       softErrInParen   display contained "[\]{}]\|<%\|%>"
syn region      softBracket      transparent start='\[\|<:' end=']\|:>' contains=ALLBUT,@softParenGroup,softErrInParen
syn match       softErrInBracket display contained "[){}]\|<%\|%>"

" label
syn match       softLabel        "\(^\|;\)[^-\.\+ \t\*\.]\{1,}[^ \t\*\;]*"
syn match	softLabel	 "^END[_\a]*" contained
syn match	softEndLabel	 "^END\s"me=s+3 contained
" optional comment for everything after last END
" comment
syn match       softComment      "^\([\*#].*$\)" contains=softTODO
syn match       softComment      ";\([\*].*[;$]\)"ms=s+1,me=e-1 contains=softTODO
syn region	softComment	 start="^END\s" end="\%$" contains=softTodo,softEndLabel,softStartLabel

" control statements
syn match	softBogusSysVar "^-.*$"
syn match 	softControl	"^-LIST\s*$"
syn match 	softControl	"^-UNLIST\s*$"
syn match 	softControl	"^-NOLIST\s*$"
syn match 	softControl	"^-EJECT\s*$"
syn match 	softControl	"^-LIST\s*LEFT\s*$"
syn match 	softControl	"^-LIST\s*RIGHT\s*$"
syn match 	softControl	"^-SINGLE\s*$"
syn match 	softControl	"^-DOUBLE\s*$"
syn match 	softControl	"^-FAIL\s*$"
syn match 	softControl	"^-NOFAIL\s*$"
syn match 	softControl	"^-INCLUDE\s*"
syn match 	softControl	"^-COPY\s*"
syn match 	softControl	"^-NOEXECUTE\s*$"
syn match 	softControl	"^-TITLE.*$"
syn match 	softControl	"^-STITLE.*$"
syn match 	softControl	"^-PRAGMA.*$"

" Define the default highlighting.
" For version 5.7 and earlier: only when not done already
" For version 5.8 and later: only when an item doesn't have highlighting yet
if version >= 508 || !exists("did_soft_syntax_inits")
if version < 508
  let did_soft_syntax_inits = 1
  command -nargs=+ HiLink hi link <args>
else
  command -nargs=+ HiLink hi def link <args>
endif

  HiLink softTodo            Todo
  HiLink softConstant        Constant
  HiLink softLabel           Label
  HiLink softEndLabel        Label
  HiLink softGoto            Repeat
  HiLink softConditional     Conditional
  HiLink softRepeat          Repeat
  HiLink softNumber          Number
  HiLink softError           Error
  HiLink softControl  	     String
  HiLink softStatement       PreProc
  HiLink softSpecChar        SpecialChar
  HiLink softString          String
  HiLink softComment         Comment
  HiLink softSpecial         Special
  HiLink softKeyword         Keyword
  HiLink softFunction        Function
  HiLink softMathsOperator   Operator
  HiLink softParenError      Error
  HiLink softErrInParen      Error
  HiLink softErrInBracket    Error
  HiLink softSysVar          Keyword
  HiLink softBogusSysVar     Error
  HiLink softExtSysVar       softSysVar
  HiLink softExtKeyword      softKeyword

  delcommand HiLink
endif

let b:current_syntax = "soft"
" vim: ts=8
