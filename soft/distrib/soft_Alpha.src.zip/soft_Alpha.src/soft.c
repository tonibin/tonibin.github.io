/* soft.c
 * Copyleft (C) 2019-2021 Antonio Maschio
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 08 agosto 2021
 *
 * This is soft, (Snobol4 OF Tony), a Snobol4 interpreter written in c99 for
 * the UNIX world. You must have gcc 4.X to compile (though maybe 3.X may go).
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */
#include "soft.h"	// catch-all header file


/******************************************
 *	    Snobol4 INTERFACE	     *
 ******************************************/
/* checkTextFile()
 * check if file is probabilistically a text file or a binary file
 * The algorithm is heuristic */
int checkTextFile(FILE *fd) {
	int bTot=0, aTot=0, c=0;
	int percentAscii=0;

	fseek(fd, 0, SEEK_SET);
	if (ftell(fd) != 0) return -2;

	while ((c=fgetc(fd))!=EOF && bTot < 10000) {
		bTot++;
		aTot+=(c>7 && c<255);
	}
	if (bTot>0) {
		percentAscii=((aTot*100)/bTot);
		if (percentAscii<90) return FALSE;
	}
	else return FALSE;
	return TRUE;
}


/* getBellConvert()
 * use the original string in in ostr (COMPSTR wide), that contains the item
 * to be converted, with original data type otype and tries to convert ostr to
 * the converted string cstr (COMPSTR wide) and with converted data type ctype;
 * if the conversion is impossible (blank cases) return zero;
 * if the conversion is possible but fails, return -1 */
int getBellConvert(char *ostr, int otype, char *cstr, int ctype) {
	strncpy_(cstr,VOIDS,COMPSTR);
	if (otype==INTEGER) {
		int nstr;
		/* convert the real to integer */
		if (strchr(ostr,'E') || strchr(ostr,'e'))
			nstr=(int)strtod(ostr,NULL);
		else nstr=strtol(ostr,NULL,10);
		if (ctype==INTEGER) {
			snprintf(cstr,COMPSTR,"%d",nstr);
		}
		else if (ctype==REAL) {
			snprintf(cstr,COMPSTR,"%.15G",(double)nstr);
		}
		else if (ctype==STRING) {
			snprintf(cstr,COMPSTR,"%d",nstr);
		}
		else if (ctype==PATTERN) {
			snprintf(cstr,COMPSTR,"%d",nstr);
		}
		else return 0;
		return ctype;
	}
	else if (otype==REAL) {
		double nstr;
		/* convert the string to real */
		nstr=strtod(ostr,NULL);
		if (ctype==INTEGER) {
			snprintf(cstr,COMPSTR,"%d",(int)nstr);
		}
		else if (ctype==REAL) {
			snprintf(cstr,COMPSTR,"%.15G",nstr);
			if (!strchr(cstr,'.')) strncat_(cstr,".",COMPSTR);
		}
		else if (ctype==STRING) {
			snprintf(cstr,COMPSTR,"%.15G",nstr);
			if (!strchr(cstr,'.')) strncat_(cstr,".",COMPSTR);
		}
		else if (ctype==PATTERN) {
			snprintf(cstr,COMPSTR,"%.15G",nstr);
			if (!strchr(cstr,'.')) strncat_(cstr,".",COMPSTR);
		}
		else return 0;
		return ctype;
	}
	else if (otype==STRING) {
		if (ctype==INTEGER) {
			char *v;
			int val=strtol(ostr,&v,10);
			if (*v) return -1;
			snprintf(cstr,COMPSTR,"%d",val);
		}
		else if (ctype==REAL) {
			char *v;
			double val=strtod(ostr,&v);
			if (*v) return -1;
			snprintf(cstr,COMPSTR,"%.15G",val);
		}
		else if (ctype==STRING) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==PATTERN) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==NAME) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==CODE) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else return 0;
		return ctype;
	}
	else if (otype==PATTERN) {
		if (ctype==STRING) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==PATTERN) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else return 0;
		return ctype;
	}
	else if (otype==NAME) {
		if (ctype==STRING) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==PATTERN) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==NAME) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else return 0;
		return ctype;
	}
	else if (otype==CODE) {
		if (ctype==STRING) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==CODE) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else return 0;
		return ctype;
	}
	else if (otype==ARRAY) {
		if (ctype==STRING) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==ARRAY) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else return 0;
		return ctype;
	}
	else if (!otype) {
		int i=dataTOS;
		if (ctype==STRING) {
			strncpy_(cstr,ostr,COMPSTR);
		}
		else if (ctype==DATA) {
			int k=strtol(ostr,NULL,10);
			char proto[COMPSTR];
			strncpy_(proto,"[",COMPSTR);
			strncat_(proto,datafunc[k].name,COMPSTR);
			strncat_(proto,"]",COMPSTR);
			strncpy_(cstr,proto,COMPSTR);
			return ctype;
		}
		else {
			while (i>0) {
				if (!strcasecmp(datafunc[i].name,ostr)) break;
				i--;
			}
			if (i>0) {
				snprintf(cstr,COMPSTR,"%d",i);
				return DATA;
			}
		}
		return 0;
	}
	return 0;
}

/* blanks()
 * return a string composed by the number of blanks specified by bl */
char *blanks(int bl) {
        char str[COMPSTR];
        int lim, i=0;
        if (bl<0) lim=0;
        else if (bl>COMPSTR-1) lim=COMPSTR-1;
        else lim=bl;
        strncpy_(str,VOIDS,COMPSTR);
        while (i<lim) str[i++]=' ';
        str[i]='\0';
	strncpy_(AIDPAD,str,COMPSTR);
        return AIDPAD;
}


/* isOpenFile()
 * return the index of the already opened file
 * or zero if the file is new */
int isOpenFile(char *name) {
	int i=2;
	while (i<=fileTOS) {
		if (!strcmp(name,openFiles[i])) {
			return i;
		}
		i++;
	}
	return 0;
}


char *printQuoted(char *str) {
	char mypad[COMPSTR];
	strncpy_(mypad,VOIDS,COMPSTR);
	if (!strchr(str,'\'')) snprintf(mypad,COMPSTR,"\'%s\'",str);
	else if (!strchr(str,'\"')) snprintf(mypad,COMPSTR,"\"%s\"",str);
	else snprintf(mypad,COMPSTR,"{%s}",str);
	strncpy_(AIDPAD,mypad,COMPSTR);
        return AIDPAD;
}


/* printLast()
 * print last lines of pages (the one with the page number)
 * used for the -FORMAT control statement */
void printLast(FILE *fd, int pageFormat) {
        char page[COMPSTR], num[COMPSTR];
        int blank;
        if (pageFormat==1) {
                blank=(sysWidth-10-8-strlen(filename)-strlen(username))/2;
                strncpy_(page,"\n",COMPSTR);
                strncat_(page,filename,COMPSTR);
                strncat_(page,blanks(blank),COMPSTR);
                snprintf(num,COMPSTR,"%3d",nPage);
                strncat_(page,"Page ",COMPSTR);
                strncat_(page,num,COMPSTR);
                strncat_(page,num,COMPSTR);
                strncat_(page,blanks(blank),COMPSTR);
                strncat_(page,username,COMPSTR);
        }
        else if (pageFormat==2) {
                blank=sysWidth-10-8-strlen(filename);
                strncpy_(page,"\n",COMPSTR);
                strncat_(page,filename,COMPSTR);
                strncat_(page,blanks(blank),COMPSTR);
                snprintf(num,COMPSTR,"Page %3d",nPage);
                strncat_(page,num,COMPSTR);
        }
        else if (pageFormat==3) {
                blank=(sysWidth-10-8)/2;
                strncpy_(page,blanks(blank),COMPSTR);
                snprintf(num,COMPSTR,"\nPage %3d",nPage);
                strncat_(page,num,COMPSTR);
        }
        fprintf(fd,"%s\n\f",page);
}


/* saveArray()
 * save the array content of ns into the channel fd
 * turning all zeros to <80>
 * TO be used only in saveFreeze() */
void saveArray(FILE *fd, int ns) {
	int i, size=vn[ns].size;
	char c;
	i=0;
	while (i<=size) {
		c=*(dimS[ns].elem+i);
		if (c=='\0') c=-128;
		fputc(c,fd);
		i++;
	}
	fputc('\n',fd);
}


/* loadArray()
 * load the array content of ns from channel fd
 * into memory, turning all <80> to zeros
 * To be used only in loadFreeze() */
void loadArray(FILE *fd, int ns) {
	int i, size=vn[ns].size;
	char c;
	i=0;
	while (i<=size) {
		c=fgetc(fd);
		if (c==-128) c=0;
		*(dimS[ns].elem+i)=c;
		i++;
	}
	c=fgetc(fd); // consume last '\n'
}


/* createFreezeFile()
 * create a file name from the filename of
 * the current program; the name is:
 * - a dot
 * - the program name (without extension)
 * - the extension '.dat' */
char *createFreezeFile(void) {
	char freezefile[COMPSTR];
	char temp[COMPSTR], *t;
	strncpy_(temp,basename(filename),COMPSTR);
	t=temp+strlen(temp)-1;
	while (t>temp && *t!='.') t--;
	if (t>temp) *t='\0';
	strncpy_(freezefile,".",COMPSTR);
	strncat_(freezefile,temp,COMPSTR);
	strncat_(freezefile,".dat",COMPSTR);
	strncpy_(AIDPAD,freezefile,COMPSTR);
        return AIDPAD;
}


/* saveFreeze()
 * perform the FREEZE procedure */
void saveFreeze(char *freezecode) {
	char freezefile[COMPSTR];
	FILE *fd;
	int i,j;
	int dd,mm,yy,hr,min,sec;
	double beTime;
	/* create freeze file name */
	strncat_(freezefile,createFreezeFile(),COMPSTR);

	/* store time values */
	dd=getDay();
	mm=getMonth();
	yy=getYear();
	hr=getHour();
	min=getMin();
	sec=getSec();

	/* open the file */
	fd=fopen(freezefile,"w"); // confirmed "w"
	if (!fd) {
		perror_(__LINE__,96,l);
		return;
	}

	/* save general registers */
	fprintf(fd,"%s\n",FREEZECODE);
	fprintf(fd,"%s\n",freezecode);
	fprintf(fd,"%d\n",dd);
	fprintf(fd,"%d\n",mm);
	fprintf(fd,"%d\n",yy);
	fprintf(fd,"%d\n",hr);
	fprintf(fd,"%d\n",min);
	fprintf(fd,"%d\n",sec);
	gettimeofday(&tv, NULL);
	endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
	beTime=endS-beginS;
	fprintf(fd,"%.15G\n",beTime);
	fprintf(fd,"%s\n",filename);
	fprintf(fd,"%s\n",parm);
	fprintf(fd,"%d\n",l);
	fprintf(fd,"%d\n",report);
	fprintf(fd,"%d\n",rightPos);
	fprintf(fd,"%d\n",decCount);

	/* save variables */
	for (i=1;i<=decCount;i++) {
		fprintf(fd,"%s\n",vn[i].name);
		fprintf(fd,"%d\n",vn[i].ref);
		fprintf(fd,"%d\n",vn[i].datatype);
		fprintf(fd,"%d\n",vn[i].iotype);
		fprintf(fd,"%d\n",vn[i].datachan);
		fprintf(fd,"%s\n",vn[i].str);
		fprintf(fd,"%.15G\n",vn[i].num);
		fprintf(fd,"%d\n",vn[i].dim);
		for (j=1;j<=vn[i].dim;j++) {
			fprintf(fd,"%d\n",vn[i].ldim[j]);
			fprintf(fd,"%d\n",vn[i].offset[j]);
			fprintf(fd,"%d\n",vn[i].coeff[j]);
		}
		fprintf(fd,"%d\n",vn[i].size);
		fprintf(fd,"%d\n",vn[i].strmem);
		fprintf(fd,"%d\n",vn[i].isData);
		fprintf(fd,"%d\n",vn[i].isCode);
		fprintf(fd,"%s\n",vn[i].proto);
		fprintf(fd,"%s\n",vn[i].argparam);
		fprintf(fd,"%d\n",vn[i].argtype);
		if (vn[i].datatype==ARRAY) saveArray(fd,i);
	}

	/* save program structure */
	fprintf(fd,"%d\n",endCore);
	for (i=0;i<=endCore;i++) {
		fprintf(fd,"%s\n",m[i]);
		fprintf(fd,"%s\n",mb[i]);
		fprintf(fd,"%s\n",label[i]);
		fprintf(fd,"%d\n",ln[i]);
		fprintf(fd,"%d\n",ml[i]);
		fprintf(fd,"%d\n",mf[i]);
		fprintf(fd,"%d\n",md[i]);
		fprintf(fd,"%d\n",ms[i]);
	}

	/* save command options flags */
	fprintf(fd,"%d\n",isAnchored);
	fprintf(fd,"%d\n",isListOriginal);
	fprintf(fd,"%d\n",isListNumbered);
	fprintf(fd,"%d\n",isListAfter);
	fprintf(fd,"%d\n",isListBefore);
	fprintf(fd,"%d\n",doThePragma);
	fprintf(fd,"%d\n",isDebug);
	fprintf(fd,"%d\n",isDumping);
	fprintf(fd,"%d\n",isTiming);
	fprintf(fd,"%d\n",isToAlter);
	fprintf(fd,"%d\n",isBanner);
	fprintf(fd,"%d\n",isStats);
	fprintf(fd,"%d\n",isStLimit);
	fprintf(fd,"%d\n",printState);
	fprintf(fd,"%d\n",isFinDebug);
	fprintf(fd,"%d\n",isResFile);
	fprintf(fd,"%d\n",goPie);
	fprintf(fd,"%d\n",isFlow);
	fprintf(fd,"%d\n",isToListD);
	fprintf(fd,"%d\n",isPrintComplete);
	fprintf(fd,"%d\n",isDefJobLog);
	fprintf(fd,"%s\n",joblog);
	fprintf(fd,"%d\n",isRunAnyway);
	fprintf(fd,"%d\n",isCommandDebug);
	fprintf(fd,"%d\n",isPrintSourceCode);
	fprintf(fd,"%d\n",isPreprocessOnly);

	/* save trace and breakpoints */
	fprintf(fd,"%d\n",traceTOS);
	for (i=0;i<=traceTOS;i++)
		fprintf(fd,"%d\n",trace[i]);
	fprintf(fd,"%d\n",breakTOS);
	for (i=0;i<=breakTOS;i++)
		fprintf(fd,"%d\n",breaks[i]);

	/* save DATA structures */
	fprintf(fd,"%d\n",dataTOS);
	for (i=0;i<=dataTOS;i++) {
		fprintf(fd,"%s\n",datafunc[i].name);
		fprintf(fd,"%s\n",datafunc[i].proto);
		fprintf(fd,"%d\n",datafunc[i].num);
	}

	/* save DEFINE structures */
	fprintf(fd,"%d\n",defineTOS);
	fprintf(fd,"%d\n",funcTOS);
	for (i=0;i<=defineTOS;i++) {
		fprintf(fd,"%s\n",definefunc[i].name);
		fprintf(fd,"%s\n",definefunc[i].argproto);
		fprintf(fd,"%s\n",definefunc[i].otherproto);
		fprintf(fd,"%s\n",definefunc[i].startlabel);
		fprintf(fd,"%d\n",definefunc[i].label);
		//fprintf(fd,"%d\n",definefunc[i].decStart);
		fprintf(fd,"%d\n",definefunc[i].nreturn);
	}

	/* save remaining & variables */
	fprintf(fd,"%d\n",isAbend);
	fprintf(fd,"%d\n",lErr);
	fprintf(fd,"%d\n",sErr);
	fprintf(fd,"%d\n",isFullscan);
	fprintf(fd,"%d\n",isInput);
	fprintf(fd,"%d\n",isOutput);
	fprintf(fd,"%d\n",isNotExponential);
	fprintf(fd,"%d\n",sLastNo);
	fprintf(fd,"%s\n",sReturn);
	fprintf(fd,"%d\n",sStatms);
	fprintf(fd,"%d\n",isStLimit);
	fprintf(fd,"%d\n",sFail);
	fprintf(fd,"%d\n",sMaths);
	fprintf(fd,"%d\n",sPatt);
	fprintf(fd,"%d\n",sMatches);
	fprintf(fd,"%d\n",sReads);
	fprintf(fd,"%d\n",sWrites);
	fprintf(fd,"%d\n",sActive);
	fprintf(fd,"%d\n",sLast);
	fprintf(fd,"%s\n",DTITLE);
	fprintf(fd,"%s\n",STITLE);
	fprintf(fd,"%d\n",FFLAG);
	fprintf(fd,"%d\n",ILEVEL);
	fprintf(fd,"%d\n",LIFLAG);
	fprintf(fd,"%d\n",SPFLAG);
	fprintf(fd,"%s\n",argparam);
	fprintf(fd,"%d\n",argtype);
	fprintf(fd,"%d\n",finalCore);
	fprintf(fd,"%d\n",isAvoidDirectives);
	fprintf(fd,"%d\n",isCompleteUnload);
	fprintf(fd,"%d\n",isExDebug);
	fprintf(fd,"%d\n",isFormat);
	fprintf(fd,"%d\n",isFtrace);
	fprintf(fd,"%d\n",isGTrim);
	fprintf(fd,"%d\n",isMaxlngth);
	fprintf(fd,"%d\n",isNoExecute);
	fprintf(fd,"%d\n",isPrinter);
	fprintf(fd,"%d\n",isQuit);
	fprintf(fd,"%d\n",isRunAnyway);
	fprintf(fd,"%d\n",isTrace);
	fprintf(fd,"%d\n",isTraceOnStop);
	fprintf(fd,"%d\n",isUserList);
	fprintf(fd,"%s\n",joblog);
	fprintf(fd,"%d\n",lnTOS);
	fprintf(fd,"%d\n",nCurr);
	fprintf(fd,"%d\n",nPage);
	fprintf(fd,"%d\n",noFile);
	fprintf(fd,"%d\n",nreturnActed);
	fprintf(fd,"%d\n",procCode);
	fprintf(fd,"%s\n",startLabel);
	fprintf(fd,"%s\n",userlist);

	/* save on-stop parameters */
	fprintf(fd,"%d\n",stopTOS);
	for (i=0;i<=stopTOS;i++) {
		fprintf(fd,"%s\n",onStop[i]);
	}

	/* save channel parameters */
	fprintf(fd,"%d\n",fileTOS);
	fprintf(fd,"%d\n",inF);
	fprintf(fd,"%d\n",outF);
	for (i=2;i<=fileTOS;i++) {
		int k,pos;
		fprintf(fd,"%s\n",channel[i].ioname);
		fprintf(fd,"%d\n",channel[i].wayout);
		fprintf(fd,"%d\n",channel[i].datalen);
		k=strlen(channel[i].attach);
		fprintf(fd,"%d\n",k);
		pos=0;
		while (pos<=k)
			fprintf(fd,"%d\n",channel[i].attach[pos++]);
		fprintf(fd,"%d\n",channel[i].isKYB);
		fprintf(fd,"%d\n",channel[i].isCanon);
		fprintf(fd,"%d\n",channel[i].isPrinter);
		fprintf(fd,"%d\n",channel[i].isLastWrite);
		pos=ftell(channel[i].stream);
		fprintf(fd,"%d\n",pos);
	}
	fprintf(fd,"%s\n",FREEZECODE);
	/* print banner and end here */
 	fprintf(stdout,"System frozen on: %02d-%s-%d  %02d:%02d:%02d\n",dd,month[mm],yy,hr,min,sec);
 	fprintf(stdout,"%s\n",freezecode);
	isFreezeOnExit=TRUE;
	fclose(fd);
}


/* loadFreeze()
 * load the frozen data */
void loadFreeze(char *freezefile) {
	FILE *fd;
	char temp[COMPSTR], text[COMPSTR];
	int i,j;
	int dd,mm,yy,hr,min,sec;
	int wdd,wmm,wyy,whr,wmin,wsec;

	/* store time values */
	dd=getDay();
	mm=getMonth();
	yy=getYear();
	hr=getHour();
	min=getMin();
	sec=getSec();

	/* open the file */
	fd=fopen(freezefile,"r"); // confirmed "r"
	if (!fd) {
		perror_(__LINE__,96,l);
		return;
	}

	/* retrieve general registers */
	fgets_(temp,COMPSTR,fd); // FREEZECODE
	if (strcmp(temp,FREEZECODE)) {
		perror_(__LINE__,98,l);
		return;
	}
	fgets_(text,COMPSTR,fd); // user text
	fgets_(temp,COMPSTR,fd);
	wdd=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	wmm=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	wyy=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	whr=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	wmin=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	wsec=strtol(temp,NULL,10);

	/* print banner */
	fprintf(stdout,"Frozen on    : %02d-%s-%d  %02d:%02d:%02d\n",wdd,month[wmm],wyy,whr,wmin,wsec);
	fprintf(stdout,"Restart now  : %02d-%s-%d  %02d:%02d:%02d\n",dd,month[mm],yy,hr,min,sec);
 	fprintf(stdout,"With message : %s\n",text);

	fgets_(temp,COMPSTR,fd);
	beginS-=strtod(temp,NULL);
	fgets_(filename,COMPSTR,fd);
	fgets_(parm,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	l=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	report=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	rightPos=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	decCount=strtol(temp,NULL,10);

	/* retrieve variables */
	for (i=1;i<=decCount;i++) {
		fgets_(vn[i].name,COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		vn[i].ref=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		vn[i].datatype=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		vn[i].iotype=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		vn[i].datachan=strtol(temp,NULL,10);
		fgets_(vn[i].str,COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		vn[i].num=strtod(temp,NULL);
		fgets_(temp,COMPSTR,fd);
		vn[i].dim=strtol(temp,NULL,10);
		for (j=1;j<=vn[i].dim;j++) {
			fgets_(temp,COMPSTR,fd);
			vn[i].ldim[j]=strtol(temp,NULL,10);
			fgets_(temp,COMPSTR,fd);
			vn[i].offset[j]=strtol(temp,NULL,10);
			fgets_(temp,COMPSTR,fd);
			vn[i].coeff[j]=strtol(temp,NULL,10);
		}
		fgets_(temp,COMPSTR,fd);
		vn[i].size=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		vn[i].strmem=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		vn[i].isData=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		vn[i].isCode=strtol(temp,NULL,10);
		fgets_(vn[i].proto,COMPSTR,fd);
		fgets_(vn[i].argparam,COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		vn[i].argtype=strtol(temp,NULL,10);
		if (vn[i].datatype==ARRAY) {
			dimStrArray(i,vn[i].dim,vn[i].ldim,VOIDS,STRING);
			loadArray(fd,i);
		}
	}

	/* retrieve program structures */
	fgets_(temp,COMPSTR,fd);
	endCore=strtol(temp,NULL,10);
	for (i=0;i<=endCore;i++) {
		fgets_(temp,COMPSTR,fd);
		free(m[i]);
		m[i]=malloc(strlen(temp)+1);
		if (!m[i]) perror_(__LINE__,73,l);
		strncpy_(m[i],temp,strlen(temp)+1);
		fgets_(temp,COMPSTR,fd);
		free(mb[i]);
		mb[i]=malloc(strlen(temp)+1);
		if (!mb[i]) perror_(__LINE__,73,l);
		strncpy_(mb[i],temp,strlen(temp)+1);
		fgets_(temp,COMPSTR,fd);
		free(label[i]);
		label[i]=malloc(strlen(temp)+1);
		if (!label[i]) perror_(__LINE__,73,l);
		strncpy_(label[i],temp,strlen(temp)+1);
		fgets_(temp,COMPSTR,fd);
		ln[i]=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		ml[i]=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		mf[i]=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		md[i]=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		ms[i]=strtol(temp,NULL,10);
	}

	/* retrieve command options flags */
	fgets_(temp,COMPSTR,fd);
	isAnchored=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isListOriginal=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isListNumbered=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isListAfter=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isListBefore=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	doThePragma=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isDebug=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isDumping=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isTiming=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isToAlter=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isBanner=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isStats=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isStLimit=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	printState=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isFinDebug=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isResFile=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	goPie=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isFlow=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isToListD=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isPrintComplete=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isDefJobLog=strtol(temp,NULL,10);
	fgets_(joblog,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	isRunAnyway=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isCommandDebug=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isPrintSourceCode=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isPreprocessOnly=strtol(temp,NULL,10);

	/* retrieve trace and breakpoints */
	fgets_(temp,COMPSTR,fd);
	traceTOS=strtol(temp,NULL,10);
	for (i=0;i<=traceTOS;i++) {
		fgets_(temp,COMPSTR,fd);
		trace[i]=strtol(temp,NULL,10);
	}
	fgets_(temp,COMPSTR,fd);
	breakTOS=strtol(temp,NULL,10);
	for (i=0;i<=breakTOS;i++) {
		fgets_(temp,COMPSTR,fd);
		breaks[i]=strtol(temp,NULL,10);
	}

	/* retrieve DATA structures */
	fgets_(temp,COMPSTR,fd);
	dataTOS=strtol(temp,NULL,10);
	for (i=0;i<=dataTOS;i++) {
		fgets_(datafunc[i].name,COMPSTR,fd);
		fgets_(datafunc[i].proto,COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		datafunc[i].num=strtol(temp,NULL,10);
	}

	/* retrieve DEFINE structures */
	fgets_(temp,COMPSTR,fd);
	defineTOS=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	funcTOS=strtol(temp,NULL,10);
	for (i=0;i<=defineTOS;i++) {
		fgets_(definefunc[i].name,COMPSTR,fd);
		fgets_(definefunc[i].argproto,COMPSTR,fd);
		fgets_(definefunc[i].otherproto,COMPSTR,fd);
		fgets_(definefunc[i].startlabel,COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		definefunc[i].label=strtol(temp,NULL,10);
		//fgets_(temp,COMPSTR,fd);
		//definefunc[i].decStart=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		definefunc[i].nreturn=strtol(temp,NULL,10);
	}

	/* save remaining & variables */
	fgets_(temp,COMPSTR,fd);
	isAbend=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	lErr=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sErr=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isFullscan=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isInput=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isOutput=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isNotExponential=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sLastNo=strtol(temp,NULL,10);
	fgets_(sReturn,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	sStatms=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isStLimit=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sFail=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sMaths=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sPatt=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sMatches=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sReads=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sWrites=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sActive=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	sLast=strtol(temp,NULL,10);
	fgets_(DTITLE,COMPSTR,fd);
	fgets_(STITLE,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	FFLAG=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	ILEVEL=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	LIFLAG=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	SPFLAG=strtol(temp,NULL,10);
	fgets_(argparam,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	argtype=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	finalCore=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isAvoidDirectives=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isCompleteUnload=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isExDebug=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isFormat=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isFtrace=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isGTrim=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isMaxlngth=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isNoExecute=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isPrinter=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isQuit=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isRunAnyway=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isTrace=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isTraceOnStop=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isUserList=strtol(temp,NULL,10);
	fgets_(joblog,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	lnTOS=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	nCurr=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	nPage=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	noFile=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	nreturnActed=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	procCode=strtol(temp,NULL,10);
	fgets_(startLabel,COMPSTR,fd);
	fgets_(userlist,COMPSTR,fd);

	/* retrieve on-stop parameters */
	fgets_(temp,COMPSTR,fd);
	stopTOS=strtol(temp,NULL,10);
	for (i=0;i<=stopTOS;i++) {
		fgets_(onStop[i],COMPSTR,fd);
	}

	/* retrieve channel parameters */
	fgets_(temp,COMPSTR,fd);
	fileTOS=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	inF=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	outF=strtol(temp,NULL,10);
	for (i=2;i<=fileTOS;i++) {
		long k,pos;
		fgets_(channel[i].ioname,COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		channel[i].wayout=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		channel[i].datalen=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		k=strtol(temp,NULL,10);
		pos=0;
		while (pos<=k) {
			fgets_(temp,COMPSTR,fd);
			channel[i].attach[pos++]=strtol(temp,NULL,10);
		}
		fgets_(temp,COMPSTR,fd);
		channel[i].isKYB=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		channel[i].isCanon=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		channel[i].isPrinter=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		channel[i].isLastWrite=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		pos=strtol(temp,NULL,10);
		strncpy_(openFiles[i],VOIDS,COMPSTR);
		if ((k=isOpenFile(channel[i].ioname))) {
			channel[i].stream=openStreams[k];
			strncpy_(openFiles[i],channel[i].ioname,COMPSTR);
		}
		else {
			channel[i].stream=fopen(channel[i].ioname,"r+"); // "r+"
			if (!channel[i].stream) {
				perror_(__LINE__,8,l);
			}
			/* TODO check for error in fseek */
			fseek(channel[i].stream,pos,SEEK_SET);
			openStreams[k]=channel[i].stream;
			strncpy_(openFiles[i],channel[i].ioname,COMPSTR);
		}
	}

	fgets_(temp,COMPSTR,fd); // FREEZECODE
	if (strcmp(temp,FREEZECODE)) perror_(__LINE__,98,0);
}


/* is_dir()
 * return TRUE if the file in path is a directory.
 * used in parse() */
int is_dir(const char *path) {
	struct stat path_stat;
	stat(path, &path_stat);
	return S_ISDIR(path_stat.st_mode);
}


/* get_ext()
 * return the extension of the file name.
 * used in parse() */
char *get_ext(char *filename) {
	char *dot = strrchr(filename, '.');
	if (!dot || dot == filename) return VOIDS;
	return dot+1;
}


/* realName()
 * return the Snobol4 name of 'name'
 * e.g. return 'R(C)' from 'R(9)' */
char *realName(char *name) {
	int cs;
	char realname[COMPSTR], *v, *r;
	if (!strchr(name,'(')) strncpy_(realname,name,COMPSTR);
	else {
		v=name;
		while (*v!='(') v++;
		if (*v=='(') v++;
		cs=strtol(v,NULL,10);
		v=name;
		r=realname;
		while (*v!='(') *r++=*v++;
		*r++='(';
		v=vn[cs].name;
		while (*v) *r++=*v++;
		*r++=')';
		*r='\0';
	}
	strncpy_(AIDPAD,realname,COMPSTR);
        return AIDPAD;
}


/* process()
 * process the file name in fnam and if it begins
 * with ~ or $HOME this is changed to the HOME directory */
char *process(char *fnam) {
	char temp[COMPSTR];
	if (fnam[0]=='~') {
		char *vn=fnam;
		strncpy_(temp,getenv("HOME"),COMPSTR);
		strncat_(temp,++vn,COMPSTR);
	}
	else if (!strncmp(fnam,"$HOME",5)) {
		char *vn=fnam;
		strncpy_(temp,getenv("HOME"),COMPSTR);
		vn+=5;
		strncat_(temp,vn,COMPSTR);
	}
	strncpy_(AIDPAD,temp,COMPSTR);
        return AIDPAD;
}


/* deExtParen()
 * remove the external parenthesis of the string in t*/
char* deExtParen(char *t) {
	while (isblank(*t)) t++;
	if (*t=='(')  {
		while (isblank(*(t+strlen(t)-1))) *(t+strlen(t)-1)='\0';
		if (*(t+strlen(t)-1)==')') {
			*(t+strlen(t)-1)='\0';
			while (isblank(*(t+strlen(t)-1)))
				*(t+strlen(t)-1)='\0';
			t++;
		}
	}
	strncpy_(AIDPAD,t,COMPSTR);
        return AIDPAD;
}


/* deParen()
 * removes all the external parenthesis of the string in s */
char* deParen(char *s) {
	char this[COMPSTR], *t=this;
	strncpy_(this,s,COMPSTR);
	while (isblank(*t)) t++;
	while (isblank(*(t+strlen(t)-1))) *(t+strlen(t)-1)='\0';
	while (*t=='(') {
		if (*(t+strlen(t)-1)==')') *(t+strlen(t)-1)='\0';
		t++;
		while (isblank(*(t+strlen(t)-1))) *(t+strlen(t)-1)='\0';
		while (isblank(*t)) t++;
	}
	if (*t=='&') t++;
	strncpy_(AIDPAD,t,COMPSTR);
        return AIDPAD;
}


/* getPar()
 * get text until first unmatched closed parenthesis ) */
char *getPar(char *s) {
	int st=0;
	char right[COMPSTR], *r=right;
	while (*s) {
	       if (*s=='(') st++;
	       else if (*s==')' && st) st--;
	       else if (*s==')' && !st) break;
	       *r++=*s++;
	}
	*r='\0';
	strncpy_(AIDPAD,right,COMPSTR);
        return AIDPAD;
}


/* getAll()
 * get text including () and [] until first blank */
char *getAll(char *s) {
	int st=0, dt=0;
	char right[COMPSTR], *r=right;
	while (*s) {
		if (*s=='(') st++;
		else if (*s=='[') dt++;
		else if (*s==')') st--;
		else if (*s==']') dt--;
		else if (isblank(*s) && !st && !dt) break;
		*r++=*s++;
	}
	*r='\0';
	strncpy_(AIDPAD,right,COMPSTR);
        return AIDPAD;
}


/* family()
 * execute the FAMILY() search and return the object of type Name,
 * storing in type ARRAY or DATA in case of success
 * and zero in case of failure
 * suitable for FAMILY() */
char *family(char *t, int *type) {
	char base[COMPSTR];
	char name[COMPSTR], mypad[COMPSTR];
	char *n=name;
	strncpy_(mypad,VOIDS,COMPSTR);
	*type=0;
	if (*t=='.') {
		t++;
		strncpy_(base,t,COMPSTR);
	}
	else {
		int ns;
		strncpy_(base,t,COMPSTR);
		ns=searchDEC(base,decCount);
		if (!ns) {
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		if (vn[ns].datatype!=NAME) {
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		strncpy_(base,vn[ns].str,COMPSTR);
	}
	t=base;
	while (*t && *t!='(' && *t!='[') *n++=*t++;
	*n='\0';
	/* error: not a created variable */
	if (!*t) {
		*type=0;
	}
	/* array case */
	else if (*t=='[') {
		*type=ARRAY;
		strncpy_(mypad,name,COMPSTR);
	}
	/* data case */
	else if (*t=='(') {
		*type=DATA;
		strncpy_(mypad,getPar(++t),COMPSTR);
	}
	strncpy_(AIDPAD,mypad,COMPSTR);
        return AIDPAD;
}


/* getFirstRest()
 * analyse string t and stores the first part of an alternation
 * or of a concatenation in 'first' and the rest in 'rest',
 * to be used for FIRST() and REST()
 * t is supposed to have the global surrounding brackets removed;
 * first and rest are supposed to have COMPSTR total length;
 * return TRUE on success, FALSE on failure */
int getFirstRest(char *tw, char *first, char *rest) {
	char temp[COMPSTR], test[COMPSTR], *r, *x, *t;
	int map[COMPSTR], alt[COMPSTR], par=0, q, st, isAlt=FALSE;

	strncpy_(test,deExtParen(tw),COMPSTR);
	r=test;
	x=r;

	/* map parenthesis */
	while (*x) {
		if (*x=='(') map[(int)(x-r)]=++par;
		else if (*x==')') map[(int)(x-r)]=par--;
		else map[(int)(x-r)]=0;
		x++;
	}

	/* remove pattern parenthesis */
	q=0;
	while (q<=strlen(r)) {
		/* remove ( and correspondent ) */
		if (map[q] && test[q]=='(') {
			int e,w=q+1;
			int isToErase;
			isToErase=0;
			while (w<=strlen(r) && map[w]!=map[q]) w++;
			e=q+1;
			while (e<w) {
				if (map[e]) {
					if (map[e]==map[q]+1) isToErase++;
					else if (map[e]) isToErase+=3;
				}
				e++;
			}
			if (isToErase==2) {
				test[q]=test[w]=1;
			}
			else map[q]=map[w]=0;
		}
		q++;
	}

	/* depurate input string */
	t=test;
	x=temp;
	while (*t) {
		if (*t!=1) *x++=*t;
		t++;
	}
	*x='\0';

	/* map alternations (decide if they are enclosed
	 * in parenthesis or not (i.e. ground) */
	t=temp;
	isAlt=FALSE;
	st=0;
	for (q=0;q<COMPSTR;q++) alt[q]=0;
	while (*t) {
		if (*t=='(') st++;
		else if (*t==')') st--;
		else if (*t=='|' && !st) alt[t-temp]=1, isAlt=TRUE;
		t++;
	}

	/* if there is a ground alternation, take everything
	 * until the first | bar */
	t=temp; // source
	x=first; // destination
	while (isblank(*t)) t++;
	if (isAlt) {
		while (*t) {
			if (*t=='|' && alt[t-temp]) break;
			*x++=*t++;
		}
		*x='\0'; // first
	}

	/* it's a pure concatenation */
	else {
		/* get to the first space */
		strncpy_(first,getAll(t),COMPSTR); // check
		t+=strlen(first);
	}

	/* after getting First, discard possible next ground bar |
	 * and the rest is for Rest */
	while (isblank(*t)) t++;
	if (*t=='|') {
		t++;
		while (isblank(*t)) t++;
	}
	x=rest; // destination
	while (*t) *x++=*t++; // copy until end
	*x='\0';

	/* trim final spaces */
	strncpy_(temp,first,COMPSTR);
	t=temp;
	while (isblank(*t)) t++;
	while (isblank(*(t+strlen(t)-1))) *(t+strlen(t)-1)='\0';
	strncpy_(first,t,COMPSTR);

	strncpy_(temp,rest,COMPSTR);
	t=temp;
	while (isblank(*t)) t++;
	while (isblank(*(t+strlen(t)-1))) *(t+strlen(t)-1)='\0';
	strncpy_(rest,t,COMPSTR);
	return TRUE;
}


/* getParam()
 * find the parameter from literal pattern
 * suitable for PARAM() */
char *getParam(char *t) {
	char mypad[COMPSTR];
       	if (!strncasecmp_(t,"LEN(",4) || !strncasecmp_(t,"POS(",4) || !strncasecmp_(t,"RPOS(",5) || !strncasecmp_(t,"TAB(",4) || !strncasecmp_(t,"RTAB(",5)) {
		int n=0;
		char *pb=p;
		while (isalpha(*t)) t++;
		t++; // skip (
		p=t;
		n=(int)S();
		t=p;
		p=pb;
		if (*t==')') t++; // skip )
		snprintf(mypad,COMPSTR,"%d",n);
		_datatype=INTEGER;
	}
       	else if (!strncasecmp_(t,"SPAN(",5) || !strncasecmp_(t,"BREAK(",6) || !strncasecmp_(t,"ANY(",4) || !strncasecmp_(t,"NOTANY(",7)) {
		char res[COMPSTR], *pb=p;
		while (isalpha(*t)) t++;
		t++; // skip (
		p=t;
		strncpy_(res,AS(),COMPSTR);
		t=p;
		p=pb;
		if (*t==')') t++; // skip )
		snprintf(mypad,COMPSTR,"%s",res);
		_datatype=STRING;
	}
	else if (!strncasecmp_(t,"ARBNO(",6)) {
		char res[COMPSTR];
		t+=6;
		strncpy_(res,getPar(t),COMPSTR);
		t+=strlen(res);
		if (*t==')') t++; // skip )
		snprintf(mypad,COMPSTR,"%s",res);
		_datatype=PATTERN;
	}
	strncpy_(AIDPAD,mypad,COMPSTR);
        return AIDPAD;
}


/* getSelector()
 * find the selector of the string in b
 * suitable for SELECTOR() */
char *getSelector(char *b) {
	int ns=0;
	char mypad[COMPSTR], name[COMPSTR], *n=name;
	strncpy_(mypad,"[[UNKNOWN]]",COMPSTR);
	/* copy name */
	while (*b && *b!='[' && *b!='(') *n++=*b++;
	*n='\0';
	/* case of an array item */
	if (*b=='[') {
		int val[MAXDIM+1], T=1, q=1;
		char num[COMPSTR], *pb=p;
		ns=searchDEC(name,decCount);
		if (!ns) {
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		if (vn[ns].datatype!=ARRAY) {
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		p=b;
		p++; // skip [
		val[T]=(int)S();
		if (val[T]<vn[ns].offset[T] ||\
			       val[T]>vn[ns].ldim[T]+vn[ns].offset[T]) {
				strncpy_(AIDPAD,mypad,COMPSTR);
			        return AIDPAD;
			}
		while (*p==',') {
			p++; // skip comma
			T++;
			if (T>vn[ns].dim) {
				strncpy_(AIDPAD,mypad,COMPSTR);
			        return AIDPAD;
			}
			val[T]=(int)S();
			if (val[T]<vn[ns].offset[T] ||\
				       val[T]>vn[ns].ldim[T]+vn[ns].offset[T]) {
				strncpy_(AIDPAD,mypad,COMPSTR);
			        return AIDPAD;
			}
		}
		if (*p==']') p++;
		b=p;
		p=pb;
		if (T!=vn[ns].dim) {
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		strncpy_(mypad,VOIDS,COMPSTR);
		while (q<=T) {
			snprintf(num,COMPSTR,"%d",val[q]);
			strncat_(mypad,num,COMPSTR);
			if (q<T) strncat_(mypad,",",COMPSTR);
			q++;
		}
	}
	/* case of a data item */
	else if (*b=='(') {
		b++;
		ns=searchDEC(b,decCount);
		if (!ns || vn[ns].datatype!=DATA) perror_(__LINE__,43,l);
		b+=_len;
		if (*b==')') b++;
		strncpy_(mypad,vn[ns].name,COMPSTR);
	}
	strncpy_(AIDPAD,mypad,COMPSTR);
        return AIDPAD;
}


/* getProto()
 * evaluate s and establish the correct prototype return string
 * suitable for PROTOTYPE() */
char *getProto(char *s) {
	int ns=searchDEC(s,decCount);
	char base[COMPSTR], *b=base;
	char left[COMPSTR], *le=left;
	char right[COMPSTR], *ri=right;
	char mypad[COMPSTR];

	/* unknown at present */
	strncpy_(mypad,"UNKNOWN()",COMPSTR);
	strncpy_(left,VOIDS,COMPSTR);
	strncpy_(right,VOIDS,COMPSTR);

	/* array and data cases */
	if (ns) {
		if (vn[ns].datatype==ARRAY) {
			snprintf(mypad,COMPSTR,"%s",vn[ns].proto);
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		else if (vn[ns].datatype==DATA) {
			int dc=0;
			dc=vn[ns].dim;
			strncpy_(mypad,datafunc[dc].name,COMPSTR);
			strncat_(mypad,"(",COMPSTR);
			strncat_(mypad,vn[ns].proto,COMPSTR);
			strncat_(mypad,")",COMPSTR);
			strncpy_(AIDPAD,mypad,COMPSTR);
		        return AIDPAD;
		}
		else if (vn[ns].datatype==NAME) {
			strncpy_(base,".",COMPSTR);
			strncat_(base,vn[ns].str,COMPSTR);
		}
		else strncpy_(base,vn[ns].str,COMPSTR);
	}
	/* get base pattern */
	else strncpy_(base,s,COMPSTR);

	while (unveilSays) strncpy_(base,unveil(base),COMPSTR);
	unveilSays=TRUE;
	strncpy_(base,deParen(base),COMPSTR);

	/* select by first char */
	/* AT case */
	if (*b=='@' && !isblank(*(b+1))) {
		b++;
		snprintf(mypad,COMPSTR,"AT(%s)",getAll(b));
		b+=strlen(mypad);
	}
	/* star case */
	else if (*b=='*') {
		b++;
		snprintf(mypad,COMPSTR,"STAR(%s)",getAll(b));
		b+=strlen(mypad);
	}
	/* NAME cases */
	else if (*b=='.') {
		char name[COMPSTR], *n=name;
		b++; // skip dot
		while (*b && *b!='[' && *b!='(') *n++=*b++;
		*n='\0';
		/* case of simple natural variable */
		if (!*b) {
			strncpy_(mypad,"INDIRECT(",COMPSTR);
			strncat_(mypad,name,COMPSTR);
			strncat_(mypad,")",COMPSTR);
		}
		/* case of an array item */
		else if (*b=='[') {
			int val[MAXDIM+1], T=1, q=1;
			char num[COMPSTR],sel[COMPSTR], *pb=p;
			ns=searchDEC(name,decCount);
			if (!ns) perror_(__LINE__,57,l);
			if (vn[ns].datatype!=ARRAY) perror_(__LINE__,29,l);
			p=b;
			p++; // skip [
			val[T]=(int)S();
			if (val[T]<vn[ns].offset[T] ||\
				       val[T]>vn[ns].ldim[T]+vn[ns].offset[T])
				perror_(__LINE__,57,l);
			while (*p==',') {
				p++;
				T++;
				if (T>vn[ns].dim) perror_(__LINE__,57,l);
				val[T]=(int)S();
				if (val[T]<vn[ns].offset[T] ||\
					       val[T]>vn[ns].ldim[T]+vn[ns].offset[T])
					perror_(__LINE__,57,l);
			}
			if (*p==']') p++;
			b=p;
			p=pb;
			if (T!=vn[ns].dim) perror_(__LINE__,57,l);
			strncpy_(sel,VOIDS,COMPSTR);
			while (q<=T) {
				snprintf(num,COMPSTR,"%d",val[q]);
				strncat_(sel,num,COMPSTR);
				if (q<T) strncat_(sel,",",COMPSTR);
				q++;
			}
			strncpy_(mypad,"ITEM(",COMPSTR);
			strncat_(mypad,name,COMPSTR);
			strncat_(mypad,",'",COMPSTR);
			strncat_(mypad,sel,COMPSTR);
			strncat_(mypad,"')",COMPSTR);
		}
		/* case of a data item */
		else if (*b=='(') {
			char sel[COMPSTR];
			b++;
			ns=searchDEC(b,decCount);
			if (!ns) perror_(__LINE__,41,l);
			if (vn[ns].datatype!=DATA) perror_(__LINE__,42,l);
			b+=_len;
			if (*b==')') b++;
			strncpy_(sel,vn[ns].name,COMPSTR);
			strncpy_(mypad,"APPLY('",COMPSTR);
			strncat_(mypad,name,COMPSTR);
			strncat_(mypad,"',",COMPSTR);
			strncat_(mypad,sel,COMPSTR);
			strncat_(mypad,")",COMPSTR);
		}
	}
	/* ARBNO case */
	else if (!strncasecmp_(b,"ARBNO(",6)) {
		b+=6;
		snprintf(mypad,COMPSTR,"ARBNO(%s)",getPar(b));
		b+=strlen(mypad);
		if (*b==')') b++; // )
		strncpy_(left,mypad,COMPSTR);
	}
	/* string functions case */
	else if (!strncasecmp_(b,"SPAN(",5) || !strncasecmp_(b,"BREAK(",6) || !strncasecmp_(b,"ANY(",4) || !strncasecmp_(b,"NOTANY(",7)) {
		char *pb=p, temp[COMPSTR];
		while (*b!='(') *le++=*b++;
		*le++=*b++; // (
		*le='\0';
		strncpy_(temp,getPar(b),COMPSTR);
		p=temp;
		strncpy_(right,AS(),COMPSTR);
		if (!strchr(right,'\'')) {
			strncpy_(mypad,left,COMPSTR);
			strncat_(mypad,"'",COMPSTR);
			strncat_(mypad,right,COMPSTR);
			strncat_(mypad,"')",COMPSTR);
		}
		else {
			strncpy_(mypad,left,COMPSTR);
			strncpy_(mypad,"\"",COMPSTR);
			strncpy_(mypad,right,COMPSTR);
			strncpy_(mypad,"\")",COMPSTR);
		}
		b+=strlen(temp);
		if (*b==')') b++; // )
		p=pb;
		strncpy_(left,mypad,COMPSTR);
	}
	/* numeric functions case */
	else if (!strncasecmp_(b,"LEN(",4) || !strncasecmp_(b,"POS(",4) || !strncasecmp_(b,"RPOS(",5) || !strncasecmp_(b,"TAB(",4) || !strncasecmp_(b,"RTAB(",5)) {
		char *pb=p, snum[COMPSTR];
		int num;
		while (*b!='(') *le++=*b++;
		*le++=*b++; // (
		*le='\0';
		strncpy_(snum,getPar(b),COMPSTR);
		p=snum;
		b+=strlen(snum);
		num=(int)S();
		snprintf(snum,COMPSTR,"%d",num);
		strncpy_(mypad,left,COMPSTR);
		strncat_(mypad,snum,COMPSTR);
		strncat_(mypad,")",COMPSTR);
		while (isblank(*b)) b++;
		if (*b==')') b++; // )
		p=pb;
		strncpy_(left,mypad,COMPSTR);
	}
	/* system variables */
	else if (!strncasecmp_(b,"ARB",3) || !strncasecmp_(b,"BAL",3) || !strncasecmp_(b,"REM",3) || !strncasecmp_(b,"FENCE",5) || !strncasecmp_(b,"FAIL",4) || !strncasecmp_(b,"ABORT",4)) {
		char *pb=p;
		while (*b && *b!=')') *le++=*b++;
		*le='\0';
		if (!strchr(right,'\'')) {
			strncpy_(mypad,left,COMPSTR);
			strncat_(mypad,"()",COMPSTR);
		}
		b+=strlen(right);
		p=pb;
		strncpy_(left,mypad,COMPSTR);
	}
	/* literal string */
	else if (*b=='\'' || *b=='\"') {
		char *pb=p;
		p=b;
		strncpy_(left,SS(),COMPSTR);
		b=p;
		p=pb;
	}
	/* numeral item */
	else if (isnm(b)) { // check
		char *pb=p;
		p=b;
		snprintf(left,COMPSTR,"%.15G",S());
		b=p;
		p=pb;
	}

	/* multi cases: overwrite previous conclusions */
	while (isblank(*b)) b++;
	if (*b) {
		/* ALT CASE */
		if (*b=='|') {
			b++;
			while (isblank(*b)) b++;
			while (*b) *ri++=*b++;
			*ri='\0';
			strncpy_(mypad,"ALT('",COMPSTR);
			strncat_(mypad,left,COMPSTR);
			strncat_(mypad,"',",COMPSTR);
			strncat_(mypad,right,COMPSTR);
			strncat_(mypad,")",COMPSTR);
		}
		/*PRD case */
		else if (*b=='.' && isblank(*(b+1))) {
			b++;
			while (isblank(*b)) b++;
			while (*b) *ri++=*b++;
			*ri='\0';
			strncpy_(mypad,"PRD(",COMPSTR);
			strncat_(mypad,left,COMPSTR);
			strncat_(mypad,",",COMPSTR);
			strncat_(mypad,right,COMPSTR);
			strncat_(mypad,")",COMPSTR);
		}
		/* DOL case*/
		else if (*b=='$' && isblank(*(b+1))) {
			b++;
			while (isblank(*b)) b++;
			while (*b) *ri++=*b++;
			*ri='\0';
			strncpy_(mypad,"DOL(",COMPSTR);
			strncat_(mypad,left,COMPSTR);
			strncat_(mypad,",",COMPSTR);
			strncat_(mypad,right,COMPSTR);
			strncat_(mypad,")",COMPSTR);
		}
		/* CAT case */
		else {
			while (isblank(*b)) b++;
			while (*b) *ri++=*b++;
			*ri='\0';
			strncpy_(mypad,"CAT('",COMPSTR);
			strncat_(mypad,left,COMPSTR);
			strncat_(mypad,"',",COMPSTR);
			strncat_(mypad,right,COMPSTR);
			strncat_(mypad,")",COMPSTR);
		}
		/* wrong case */
		if (!left[0]) strncpy_(mypad,"UNKNOWN()",COMPSTR);
	}
	strncpy_(AIDPAD,mypad,COMPSTR);
        return AIDPAD;
}


/* printWide()
 * print text in b not exceeding the space width w
 * directing output to the stream 'stream',
 * breaking the string at the first useful space
 * avoiding breaking words or punctuation signs */
void printWide(FILE *stream, char *b, int w) {
	char nout[COMPSTR], *t;
	char base[COMPSTR], *s;
	int c=0;
	strncpy_(base,b,COMPSTR);
	s=base;
	while (*s) {
		/* treat next Space */
		if (*s==' ') {
			if (c+1>=w) {
				fputc('\n',stream);
				c=0;
				while (*s==' ') s++;
			}
			else {
				fputc(*s++,stream);
				c++;
			}
		}
		/* treat next Tab */
		else if (*s=='\t') {
			int k=c%8+1;
			if (k*8>=w) {
				fputc('\n',stream);
				c=0;
				k=1;
			}
			s++;
			while (c<k*8) {
				fputc(' ',stream);
				c++;
			}
		}
		/* treat next Vertical Tab */
		else if (*s=='\v') {
			fputc(*s++,stream);
		}
		/* treat next Carriage Return */
		else if (*s=='\r') {
			fputc(*s++,stream);
			c=0;
		}
		/* treat next New Line */
		else if (*s=='\n') {
			fputc(*s++,stream);
			c=0;
		}
		/* treat next Word */
		else {
			strncpy_(nout,VOIDS,COMPSTR);
			t=nout;
			while (*s && !issuperblank(s)) *t++=*s++;
			*t='\0';
			if (c+strlen(nout)>=w) {
				fputc('\n',stream);
				c=0;
			}
			fprintf(stream,"%s",nout);
			c+=strlen(nout);
		}
	}
}


/* parseInt()
 * check the string in str and if it is an integer
 * return TRUE */
int parseInt(char *str) {
	double val;
	char *s;
	if (!*str) return TRUE;
	if (strchr(str,'.')) return FALSE;
	val=strtod(str,&s);
	if (*s) return FALSE;
	if ((val/(int)val)>1.0) return FALSE;
	return TRUE;
}


/* listLine()
 * writes line identified by i; labels are printed in the field d,
 * statements and goto-sections are printed consecutively
 * System function for LIST in PIE */
void listLine(int i, int d) {
	char format[COMPSTR];
	if (isError) {
		fprintf(stdout,"[%03d] ",i);
	}

	/* if line is empty, ignore it
	 * (it may be a commented line from a file loaded with LOAD) */
	if (m[i] && !*m[i]) return;

	/* last line is by default END */
	if (i==endCore) {
		fprintf(stdout,"%s%s\n%s",REDCOLOR,label[i],RESETCOLOR);
		return;
	}

	/* print control statement */
	if (m[i] && *m[i] && m[i][0]=='-') {
		fprintf(stdout,"%s%s%s\n",GREENCOLOR,m[i],RESETCOLOR);
		return;
	}

	/* search for label and print it */
	snprintf(format,COMPSTR,"%%s%%-%ds%%s\t",d);
	if (ln[i]) {
		fprintf(stdout,format,REDCOLOR,label[i],RESETCOLOR);
	}
	else fprintf(stdout,format,"\0",VOIDS,"\0");

	/* print line */
	if (m[i] && *m[i] && m[i][0]!='-') {
		char *k;
		char rule[COMPSTR], gotos[COMPSTR];
		if ((k=strcasestr_oq(m[i],":"))) {
			*k='\0';
			strncpy_(rule, m[i],COMPSTR);
			*k=':'; // restore line
			strncpy_(gotos,k,COMPSTR);
		}
		else {
			strncpy_(rule,m[i],COMPSTR);
			strncpy_(gotos,VOIDS,COMPSTR);
		}
		fprintf(stdout,"%s%s%s%s\n",rule,BLUECOLOR,gotos,RESETCOLOR);
	}
	else fputc('\n',stdout);
}


/* resetFileIndex()
 * reset input and output files, setting all input-file-pointers to the start
 * of file, setting also file indices inF (in case no input files are opened,
 * set it to 1) and outF (in case no output files are opened, set it to 0)
 * Note: outF is set to the last defined output file, inF is set to the
 * first item in the input list. */
void resetFileIndex(void) {
	if (fileTOS>1) {
		int i=fileTOS;
		/* reset input-file pointer */
		while (i>1) {
			if (channel[i].wayout==VREAD)
			   fseek(channel[i].stream,0,SEEK_SET);
			i--;
		}
		/* search for the first input file */
		inF=2;
		while (inF<=fileTOS) {
			if (channel[inF].wayout==VREAD) break;
			inF++;
			if (inF>=STREAMS) perror_(__LINE__,81,l);
		}
		if (inF>fileTOS) inF=1;
		/* search for the last output file */
		outF=fileTOS;
		while (outF>0) {
			if (channel[outF].wayout==VWRITE) break;
			outF--;
		}
		if (outF<=1) outF=0;
	}
	else outF=0, inF=1;
}


/* reset_()
 * perform a complete reset before RUN in debug */
void reset_(void) {
	resetFileIndex();
	scan=bscan=0;
	rightPos=TRUE;
	dotTOS=0;
	defineTOS=0;
	dataTOS=0;
	funcTOS=0;
	l=0;
}


/* preproc()
 * print preprocessing data (options -x and -b */
void preproc(void) {
	int i;
	int formal=FALSE;
	int lab=0;
	printf("\nPreprocessing Analysis \nProgram %s has %d lines.\n",filename,endCore);
	printf("Found %d available channels\n",fileTOS+1);
	for (i=1;i<=endCore;i++) if (ln[i]) lab++;
	printf("Found %d registered label%s\n",lab,lab==1?"":"s");
	if (!strcasecmp(label[endCore],"END"))
		printf("END label regularly found in the last line.\n");
	else {

		printf("%sIt is advisable to put a final END label (not required, though).%s\n",REDCOLOR,RESETCOLOR);
	}
	formal=FALSE;
	for (i=1;i<=endCore;i++) {
		if (m[i] && *m[i] && !checkBal(m[i])) {
			formal=TRUE;
			break;
		}
	}

	if (!formal) printf("Parentheses and square brackets all regularly balanced.\n");
	else printf("%sUnbalanced parentheses or square brackets at line %d.%s\n",REDCOLOR,i,RESETCOLOR);

	if (!formal) printf("Result: No formal errors detected in source program.\n");
	else printf("%sResult: Formal errors were detected in source program.\nPlease, review the source.\n%s",REDCOLOR,RESETCOLOR);
	printf("\n");
}


/* buildFake()
 * build a fake program in order to let parse() work in PIE mode */
void buildFake(void) {
	noFile=TRUE;
	strncpy_(filename,"Pie session",COMPSTR);
	/* store two empty lines */
	m[1]=malloc(2);
	if (!m[1]) perror_(__LINE__,73,-1);
	strncpy_(m[1]," ",2);
	ln[2]=endCode; // END code
	endCore=finalCore=2;
}


/* checkTrace()
 * print the TRACE line
 * ns: the variable to check */
int checkTrace(int ns) {
	int i=0;
	if (isTrace<0) return TRUE;
	while (i<traceTOS) {
		if (trace[i]==ns) {
			double endS;
			gettimeofday(&tv, NULL);
			endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
			endS-=beginS;
			fprintf(stdout,"STATEMENT %d: %s = %s, TIME = %d\n",l,vn[ns].name,vn[ns].str,(int)(endS*1000.0));
			if (isTrace>0) isTrace--;
			break;
		}
		i++;
	}
	return TRUE; // no tracing
}


/* DO_OUTPUT()
 * perform the effective $ and . operators function,
 * that is checking if the variable assigned with $ or . is
 * OUTPUT, SCREEN or an output variable
 * System function for evalDollar() and evalDot() */
void DO_OUTPUT(int ns) {
	if (!isOutput) return;
	/* check if the variable name is exactly equal to OUTPUT */
	if (!strcasecmp(vn[ns].name,"OUTPUT")) {
		/* OUTPUT prints to default output */
		OUTPUTPRINTS(outF,ns);
		/* reassign channel data
		 * (this may be necessary the first time) */
		vn[ns].datachan=outF;
		vn[ns].iotype=WRITEFILE;
	}
	/* check if the variable name is exactly equal to SCREEN */
	else if (!strcasecmp(vn[ns].name,"SCREEN")) {
		/* SCREEN prints to screen */
		OUTPUTPRINTS(0,ns);
		/* reassign channel data
		 * (this may be necessary the first time) */
		vn[ns].datachan=0;
		vn[ns].iotype=WRITEFILE;
	}
	/* check if the variable name is an OUTPUT-family member */
	else if (vn[ns].iotype==WRITEFILE) {
		/* OUTPUT-family members have their own channels */
		OUTPUTPRINTS(vn[ns].datachan,ns);
	}
}


/* OUTPUTPRINTS()
 * This is used by the assignments to OUTPUT and all the output variables,
 * each printing on its channel (the screen for OUTPUT and the screen or
 * file or error channel for any declared output variable)
 * System function for DO_OUTPUT() */
void OUTPUTPRINTS(int ch, int ns) {
	int dt=vn[ns].datatype;
	if (channel[ch].wayout!=VWRITE) perror_(__LINE__,55,l);
	if (isExDebug) fprintf(stdout,"%s",RESETCOLOR);
	if (dt>PREDEF) dt-=PREDEF;
	if (dt==STRING) {
		if (isExDebug && !strlen(vn[ns].str))
			fprintf(channel[ch].stream,"%s","[null]");
		else {
			fprintf(channel[ch].stream,"%s",vn[ns].str);
		}
	}
	else if (dt==INTEGER) {
		fprintf(channel[ch].stream,"%s",vn[ns].str);
	}
	else if (dt==REAL) {
		if (isNotExponential) {
			char num[COMPSTR];
			snprintf(num,COMPSTR,"%.15G",vn[ns].num);
			if (!strchr(num,'.')) strncat_(num,".",COMPSTR);
			fprintf(channel[ch].stream,"%s",num);
		}
		else {
			int exp=0;
			char sign='+', num[COMPSTR];
			long double val=vn[ns].num;
			while (val<=1.0) val*=10.0L, exp--;
			while (val>=10.0) val/=10.0L, exp++;
			if (exp<0) exp*=-1, sign='-';
			snprintf(num,COMPSTR,"%.15LG",val);
			if (!strchr(num,'.')) strncat_(num,".",COMPSTR);
			fprintf(channel[ch].stream,"%s%cE%02d",num,sign,exp);
		}
	}
	else if (dt==PATTERN) {
		if (!isPrintComplete) fprintf(channel[ch].stream,"%s","[PATTERN]");
		else fprintf(channel[ch].stream,"%s = %s","[PATTERN]",deExtParen(vn[ns].str));
	}
	else if (dt==ARRAY) {
		if (!isPrintComplete) fprintf(channel[ch].stream,"%s","[ARRAY]");
		else fprintf(channel[ch].stream,"%s (%s)","[ARRAY]",vn[ns].proto);
	}
	else if (dt==CODE) {
		if (!isPrintComplete) fprintf(channel[ch].stream,"%s","[CODE]");
		else fprintf(channel[ch].stream,"%s = %s","[CODE]",vn[ns].str);
	}
	else if (dt==DATA) {
		char name[COMPSTR];
		int vs=strtol(vn[ns].str,NULL,10);
		strncpy_(name,datafunc[vs].name,COMPSTR);
		if (!isPrintComplete) fprintf(channel[ch].stream,"[%s]",name);
		else fprintf(channel[ch].stream,"[%s] (%s)",name,vn[ns].proto);
	}
	else if (dt==NAME) {
		fprintf(channel[ch].stream,"%s",vn[ns].str);
	}
	else fprintf(channel[ch].stream,"%s","[unknown data type]");
	/* print attach string set through OUTPUT() */
	fprintf(channel[ch].stream,"%s",channel[ch].attach);
	sWrites++; // for Stats
	if (isExDebug) fprintf(stdout,"%s",RESETCOLOR);
	/* for files */
	if (channel[ch].wayout==VWRITE) {
		if (channel[ch].stream!=stdout && channel[ch].stream!=stderr)
			channel[ch].isLastWrite=TRUE;
	}
}


/* DO_INPUT()
 * low level function that accepts a string from input and returns it.
 * the input channel is automatically detected by inF.
 * if this connects the input to the console, the input is taken from
 * the keyboard, while if this is linked to a file, the next line is
 * retrieved and returned */
char *DO_INPUT(void) {
	if (!isInput) return VOIDS;
	strncpy_(instr,VOIDS,COMPSTR);
	/* keyboard case (no input file) */
	if (channel[inF].isKYB) {
		/* do with echoing */
		if (channel[inF].isCanon) strcpy(instr, getString(TRUE));
		/* disable echoing */
		else {
			struct termios thismodes, thissavemodes;
			tcgetattr(0, &thismodes);
			thissavemodes = thismodes;
			thismodes.c_lflag &= ~ICANON;
			thismodes.c_lflag &= ~ECHO;
			tcsetattr(0, 0, &thismodes);
			strcpy(instr, getString(FALSE));
			tcsetattr(0, 0, &thissavemodes);
			fprintf(stdout,"%s","\n");
		}
		return instr;
	}
	/* errors in data */
	else if (inF>fileTOS) {
		report=FALSE;
		return VOIDS;
	}

	/* at least one file is opened */
	while (inF<=fileTOS && channel[inF].wayout==VREAD) {
		/* a further reading is possible */
		if (fgets_(instr,COMPSTR,channel[inF].stream)) {
			channel[inF].isLastWrite=FALSE;
			if (!instr[0]) continue;
			else if (!strncasecmp_(instr,FREEZECODE,6)) {
				char *level=instr+6;
				int lev=strtol(level,NULL,10);
				fprintf(stdout,error[46],lev);
				fprintf(stdout,"%s","\n");
				report=FALSE;
				return VOIDS;
			}
			return instr;
		}
		/* see if there is another input file */
		inF++;
	}
	report=FALSE;
	return VOIDS;
}


/* setOutputFile()
 * create a link between an output variable and a file
 * workhorse for OUTPUT()
 * Note: fileTOS is incremented in OUTPUT() */
int setOutputFile(char *filname, char *varname, char *att, int app) {
	int ns=findDEC(varname);
	vn[ns].iotype=WRITEFILE;
	vn[ns].datachan=fileTOS;
	/* open TTY */
	if (!strcasecmp(filname,"TTY")) {
		channel[fileTOS].stream=stdout;
		strncpy_(channel[fileTOS].ioname,"screen",COMPSTR);
		channel[fileTOS].isPrinter=FALSE;
	}
	/* open ERR */
	else if (!strcasecmp(filname,"ERR")) {
		channel[fileTOS].stream=stderr;
		strncpy_(channel[fileTOS].ioname,"error channel",COMPSTR);
		channel[fileTOS].isPrinter=FALSE;
	}
	/* open PRN or PUNCH*/
	else if (!strcasecmp(filname,"PRN") || !strcasecmp(filname,"PUNCH")) {
		char printername[COMPSTR];
		char num[COMPSTR];
		snprintf(num,COMPSTR,"%d",fileTOS);
		strncpy_(printername,vn[ns].name,COMPSTR);
		strncat_(printername,"_",COMPSTR);
		strncat_(printername,"_print_out",COMPSTR);
		strncat_(printername,num,COMPSTR);
		strncat_(printername,".dat",COMPSTR);
		/* opening of a temporary file to 'print' into */
		channel[fileTOS].stream=fopen(printername,"w"); // Ok "w"
		if (!channel[fileTOS].stream) perror_(__LINE__,76,l);
		strncpy_(channel[fileTOS].ioname,printername,COMPSTR);
		channel[fileTOS].isPrinter=TRUE;
		if (*att) strncpy_(att,"\\n",COMPSTR);

	}
	/* open file for OUTPUT() or --output */
	else if (!isOpenFile(filname)) {
		if (!app) {
			/* opening in write mode (create file) */
			channel[fileTOS].stream=fopen(filname,"w"); // "w"
			if (!channel[fileTOS].stream) perror_(__LINE__,76,l);
			fclose(channel[fileTOS].stream);
		}
		/* opening in read/write mode and set append mode */
		channel[fileTOS].stream=fopen(filname,"r+"); // "r+"
		if (!channel[fileTOS].stream) perror_(__LINE__,76,l);
		fseek(channel[fileTOS].stream,0,SEEK_END);
		strncpy_(channel[fileTOS].ioname,filname,COMPSTR);
		channel[fileTOS].isPrinter=FALSE;
		strncpy_(openFiles[fileTOS],filname,COMPSTR);
		openStreams[fileTOS]=channel[fileTOS].stream;
	}
	else {
		int i=isOpenFile(filname);
		strncpy_(channel[fileTOS].ioname,filname,COMPSTR);
		channel[fileTOS].isPrinter=FALSE;
		channel[fileTOS].stream=openStreams[i];

	}
	/* common parameters */
	channel[fileTOS].wayout=VWRITE;
	channel[fileTOS].isCanon=TRUE;
	channel[fileTOS].isKYB=FALSE;
	channel[fileTOS].isLastWrite=FALSE;
	strncpy_(channel[fileTOS].attach,att,COMPSTR);
	return TRUE;
}


/* setInputFile()
 * create a link between an input variable and a file
 * workhorse for INPUT()
 * Note: fileTOS is incremented in INPUT() */
int setInputFile(char *filname, char *varname, int len, int echo) {
	int ns=findDEC(varname);
	vn[ns].iotype=READFILE;
	vn[ns].datachan=fileTOS;
	vn[ns].datatype=STRING;
	/* open KYB */
	if (!strcasecmp(filname,"KYB")) {
		channel[fileTOS].stream=stdin;
		strncpy_(channel[fileTOS].ioname,"keyboard",COMPSTR);
		channel[fileTOS].isPrinter=FALSE;
		channel[fileTOS].isCanon=echo;
		channel[fileTOS].isKYB=TRUE;
	}
	/* open file for INPUT() or --input */
	else if (!isOpenFile(filname)) {
		channel[fileTOS].stream=fopen(filname,"r+"); // confirmed "r+"
		if (!channel[fileTOS].stream) perror_(__LINE__,77,l);
		strncpy_(channel[fileTOS].ioname,filname,COMPSTR);
		channel[fileTOS].isCanon=TRUE;
		channel[fileTOS].isKYB=FALSE;
		strncpy_(openFiles[fileTOS],filname,COMPSTR);
		openStreams[fileTOS]=channel[fileTOS].stream;
	}
	else {
		int i=isOpenFile(filname);
		strncpy_(channel[fileTOS].ioname,filname,COMPSTR);
		channel[fileTOS].isPrinter=FALSE;
		channel[fileTOS].stream=openStreams[i];
	}
	channel[fileTOS].wayout=VREAD;
	channel[fileTOS].datalen=len;
	channel[fileTOS].isLastWrite=FALSE;
	return TRUE;
}


/* setSourceFile()
 * builds and opens the resource file, made of all the contents of the
 * source file that is located beyond the line where the closing END
 * label is found. */
int setSourceFile(FILE *f) {
	char LINE[COMPSTR], TEXT[COMPSTR];
	FILE *fo;
	fileTOS++;
	if (fileTOS>STREAMS) perror_(__LINE__,81,l);
	/* generate name for temporary file */
	strncpy_(LINE,RESFILE,COMPSTR);
	/* open file and copy resource to it (temporary file) */
	fo=fopen(LINE,"w"); // confirmed "w"
	while(fgets(TEXT,COMPSTR,f)) {
		if (TEXT[0]=='#') break;
		fputs(TEXT,fo);
	}
	fclose(fo);
	/* open file for reading */
	channel[fileTOS].stream=fopen(LINE,"r+"); // confirmed only "r+"
	if (!channel[fileTOS].stream) perror_(__LINE__,77,l);
	channel[fileTOS].wayout=VREAD;
	channel[fileTOS].datalen=COMPSTR;
	channel[fileTOS].isCanon=TRUE;
	channel[fileTOS].isKYB=FALSE;
	strncpy_(channel[fileTOS].ioname,LINE,COMPSTR);
	return TRUE;
}


/* erasemem()
 * clear program */
void erasemem(void) {
	int i;
	/* erase core memory */
	for (i=0;i<MEMLIMIT;i++) {
		if (m[i] && *m[i]) {
			free(m[i]);
			m[i]=NULL;
		}
		if (mb[i] && *mb[i]) {
			free(mb[i]);
			mb[i]=NULL;
		}
		ml[i]=mf[i]=md[i]=0;
	}
	strncpy_(DTITLE,VOIDS,COMPSTR);
	strncpy_(STITLE,VOIDS,COMPSTR);
	reset_();
}


/* setup()
 * erase memory and call LOAD */
int setup(void) {
	/* erase core memory */
	erasemem();
	/* LOAD */
	return LOAD(m,0,0,filename);
}


/* isArrayDef()
 * check if the character pointed to by l is inside an ARRAY definition
 * contained into the string w
 * Note: this is necessary to make the colon inside ARRAY and out
 * of an explicit literal string not confused with the colon
 * used for the gotos */
int isArrayDef(char *w, char *l) {
	char *st, *en;
	st=strstr(w,"ARRAY(");
	/* there is no ARRAY*/
	if (!st) return FALSE;
	else {
		en=st+6; // skip ARRAY(
		st+=5; // st points to opening (
		while (*en && *en!=')') {
			int st=0;
			if (*en=='(') st++;
			else if (*en==')' && st) st--;
			else if (*en==')' && !st) break;
			en++;
		}
		/* now en points to final closing ) */
		if (l>st && l<en) return TRUE;
	}
	return FALSE;
}


/* list_control() */
void list_control(FILE *fd) {
	int i, iw=0, size=sysWidth-10, notitle=FALSE;
	char line[COMPSTR], num[COMPSTR], lev[COMPSTR];
	char output[COMPSTR];
	/* print title and subtitle */
	if (DTITLE[0] || STITLE[0]) {
		if (!DTITLE[0]) {
			notitle=TRUE;
			strncpy_(DTITLE,filename,COMPSTR);
			strncat_(DTITLE,": ",COMPSTR);
		}
		fprintf(fd,"\n%s\n",DTITLE);
		fprintf(fd,"%s\n\n",STITLE);
	}
	/* calculate longest label */
	for (i=1;i<=endCore;i++) {
		int k;
		if (ln[i]>0 && ms[i]) {
			k=strlen(label[i]);
			if (k>iw) iw=k;
		}
	}
	if (iw<LISTTAB) iw=LISTTAB;
	for (i=1;i<=endCore;i++) {
		if (!ms[i]) {
			putc('\n',stdout);
			nCurr++;
			continue;
		}
		if (m[i] && !strncasecmp_(m[i],"-TITLE",6)) {
			char *w=m[i]+6;
			while (isblank(*w)) w++;
			while (*w) putc(toupper(*w++),stdout);
			putc('\n',stdout);
			nCurr++;
			continue;
		}
		else if (m[i] && !strncasecmp_(m[i],"-STITLE",7)) {
			char *w=m[i]+7;
			while (isblank(*w)) w++;
			while (*w) putc(*w++,stdout);
			putc('\n',stdout);
			nCurr++;
			continue;
		}
		else if (m[i] && !strncasecmp_(m[i],"-EJECT",6)) {
			int blank1,blank2,pageFormat;
			while (nCurr<=EJPAGE-2) {
				nCurr++;
				putc('\n',stdout);
			}
	                blank1 = (size - 8 - strlen(filename) - strlen(username))/2;
	                blank2 = size - 8 - strlen(filename);
	                if (blank1>0) pageFormat = 1;
	                else if (blank2>0) pageFormat=2;
	                else pageFormat=3;
	                printLast(fd,pageFormat);
	                nCurr=1;
	                nPage++;
			continue;
		}
		else if (m[i] && !strncasecmp_(m[i],"-SPACE",6)) {
			char *w=m[i]+6;
			int i,num=1;
			while (isblank(*w)) w++;
			num=strtol(w,NULL,10);
			if (num<1) num=1;
			for (i=1;i<=num;i++) {
				putc('\n',stdout);
				nCurr++;
			}
		}
		/* build accessory strings */
		num[0]=lev[0]=line[0]=output[0]='\0';
		strncpy_(num,VOIDS,COMPSTR);
		strncpy_(lev,VOIDS,COMPSTR);
		strncpy_(line,VOIDS,COMPSTR);
		strncpy_(output,VOIDS,COMPSTR);
		if (ms[i]==1) {
			snprintf(num,COMPSTR,"[%03d]",i);
			snprintf(lev,COMPSTR,"-%d",ml[i]);
		}
		else {
			snprintf(num,COMPSTR,"%d-",ml[i]);
			snprintf(lev,COMPSTR,"[%03d]",i);
		}
		strncat_(num,lev,COMPSTR);
		/* build line of code */
		if (ln[i]) {
			int k=iw-strlen(label[i]);
			char temp[COMPSTR];
			snprintf(temp,COMPSTR,"%s",label[i]);
			strncat_(line,temp,COMPSTR);
			while (k-->0) strncat_(line," ",COMPSTR);
		}
		else if (m[i] && *m[i] && m[i][0]=='-') {
			char temp[COMPSTR];
			snprintf(temp,COMPSTR,"%s",m[i]);
			strncat_(line,temp,COMPSTR);
		}
		else {
			int k=iw;
			strncpy_(line,VOIDS,COMPSTR);
			while (k-->0) strncat_(line," ",COMPSTR);
		}
		if (m[i] && !m[i][0] && mb[i] && mb[i][0]=='*') {
			strncpy_(line,mb[i],COMPSTR);
		}
		else if (m[i] && *m[i] && m[i][0]!='-') {
			strncat_(line,m[i],COMPSTR);
		}
		/* emend line from tabs */
		if (strlen(line)>0) {
			char *k=line, newoutput[COMPSTR], *n=newoutput;
			while (*k) {
				if (*k=='\t') {
					int d=((int)((n-line)/8)+1)*8;
					while (d>(int)(n-line)) *n++=' ',d--;
					k++;
				}
				else *n++=*k++;
			}
			*n='\0';
			strncpy_(line,newoutput,COMPSTR);
		}
		/* build output string left */
		if (ms[i]==1) {
			char temp[COMPSTR];
			strncpy_(temp,num,COMPSTR);
			strncat_(temp," ",COMPSTR);
			strncat_(temp,line,COMPSTR);
			strncat_(output,temp,COMPSTR);
		}
		/* build output string right */
		else {
			int k, add=0;
			char temp[COMPSTR], *s, *e, c;
			s=line;
			while (strlen(s)>size) {
				e=s+size;
				while (e>line && *e && *e!='-' && !isblank(*e)) e--;
				c=*e;
				*e='\0';
				fprintf(fd,"%s\n",s);
				k=iw-1;
				fputc('+',fd);
				nCurr++;
				while ((k--)>0) fputc(' ',fd);
				*e=c;
				s=e;
				while (*s && isblank(*s)) s++;
				add=iw;
			}
			strncpy_(line,s,COMPSTR);
			k=strlen(line)+1;
			while (k++<size-add) strncat_(line," ",COMPSTR);
			strncpy_(temp,line,COMPSTR);
			strncat_(temp," ",COMPSTR);
			strncat_(temp,num,COMPSTR);
			strncat_(output,temp,COMPSTR);
		}
		fprintf(fd,"%s\n",output);
		nCurr++;
		if (md[i]==2) {
			fprintf(fd,"\n");
			nCurr++;
		}
		if (nCurr>EJPAGE-2 && isFormat) {
			int blank1,blank2,pageFormat;
	                blank1 = (size - 8 - strlen(filename) - strlen(username))/2;
	                blank2 = size - 8 - strlen(filename);
	                if (blank1>0) pageFormat = 1;
	                else if (blank2>0) pageFormat=2;
	                else pageFormat=3;
			fflush(fd);
	                printLast(fd,pageFormat);
	                nCurr=1;
	                nPage++;
	        }
	}
	if (md[i]==2) fprintf(fd,"\n");
	if (notitle) strncpy_(DTITLE,VOIDS,COMPSTR);
}


/* list_beauty()
 * list the program in colors
 * Used by options --list and --listing */
void list_beauty(void) {
	int i=0, w=3;
	for (i=1;i<=endCore;i++) {
		int len=0;
		if (ln[i]>0) {
			len=(int)strlen(label[i]);
			if (len>w) w=len;
		}
	}
	for (i=1;i<=endCore;i++) {
		listLine(i,w);
	}
	fprintf(stdout,"%s","\n");
}


/* LOAD()
 * load file in memory
 * filestr: name of file to open
 * m: memory where program is stored
 * Return 0 in case of correct execution */
int LOAD(char **m, int from, int labelfrom, char *filestr) {
	FILE *f, *fb[MAXINC];
	char B[COMPSTR], *pB=B;
	char L[COMPSTR], *lab, *w, *k;
	char inc[COMPSTR];
	char store[COMPSTR], bname[COMPSTR];
	int bin=0, linenum=from, isInclude=FALSE, st=0, dt=0;
	int ilevel=ILEVEL, fflag=FFLAG, spflag=SPFLAG,liflag=LIFLAG;
	lnTOS=labelfrom;
	lo=linenum;
	strncpy_(bname,filestr,COMPSTR);

	/* open file for reading */
	if (!(f=fopen(filestr,"r"))) { // confirmed "r"
		/* try appending ".sno" */
		strncat_(filestr,".sno",COMPSTR);
		if (!(f=fopen(filestr,"r"))) { // confirmed "r"
			/* try appending ".sbl" */
			char *w=filestr+strlen(filestr)-1;
			while (*w && *w!='.' && w>filestr) w--;
			*w='\0';
			strncat_(filestr,".sbl",COMPSTR);
			if (!(f=fopen(filestr,"r"))) { // confirmed "r"
				beginS=-1;
				perror_(__LINE__,68,-1);
				return FALSE;
			}
		}
	}

	/* check for binary file */
	bin=checkTextFile(f);
	if (bin==-2) perror_(__LINE__,106,-1);
	else if (bin==0) {
		char ans[COMPSTR];
		ans[0]='\0';
		fprintf(stdout,error[107],bname);
		strncpy_(ans,getString(TRUE),COMPSTR);
		if (toupper(ans[0])!='Y' && ans[0]!='\0') {
			fprintf(stdout,"\nOK. PLEASE, REVIEW FILE %s.\n\n",bname);
			fclose(f);
			return TRUE;
		}
	}
	fseek(f, 0, SEEK_SET);

	/* load lines one by one */
	while((fgets_(B,COMPSTR,f) || ilevel) && linenum<MEMLIMIT-1) {
		char pad[COMPSTR], *sm;
		/* fix line flags with default data
		 * (to be rewritten in case) */
		ml[linenum]=ilevel;
		mf[linenum]=fflag;
		md[linenum]=spflag;
		ms[linenum]=liflag;

		/* case of an empty line */
		if (!*B && ilevel) {
			f=fb[ilevel];
			ilevel--;
			if (!ilevel) isInclude=FALSE;
			continue;
		}
		/* strip away EOL */
		pB=w=B;
		if ((int)strlen(pB)>0) {
			if (*(w+strlen(w)-1)=='\r') *(w+strlen(w)-1)='\0';
			if (*(w+strlen(w)-1)=='\n') *(w+strlen(w)-1)='\0';
			if (*(w+strlen(w)-1)=='\r') *(w+strlen(w)-1)='\0';
		}
		/* bash-like comment */
		else if (*pB=='#') continue;
		/* continuation line */
		if (*pB=='+' || *pB=='.') {
			int len,blen;
			w++; // skip + or dot
			len=strlen(m[linenum])+strlen(w);
			blen=strlen(pB);
			/* attach program line */
			strncpy_(store,m[linenum],len+1);
			free(m[linenum]);
			m[linenum]=malloc(len+1);
			if (!m[linenum]) perror_(__LINE__,73,l);
			strncpy_(m[linenum],store,len+1);
			/* add a space in case of quotes */
			if (isquote(w)) {
				w--;
				*w=' ';
			}
			turnToUpper_oq(w);
			strncat_(m[linenum],w,len+1);
			/* store original execution line */
			lo++;
			mb[lo]=malloc(blen+1);
			if (!mb[lo]) perror_(__LINE__,73,l);
			strncpy_(mb[lo],pB,blen+1);
			/* realign line numbering */
			linenum++;
			continue;
		}
		/* control statements */
		else if (*pB=='-' && !isAvoidDirectives) {
			w++; // skip -
			while (isblank(*w)) w++;
			/* control -INCLUDE/-COPY */
			if (!strncasecmp_(w,"INCLUDE",7) || !strncasecmp_(w,"COPY",4)) {
				if (toupper(*w)=='I') w+=7;
				else w+=4;
				while (isblank(*w)) w++;
				ilevel++;
				if (ilevel>=MAXINC) perror_(__LINE__,75,l);
				p=w;
				strncpy_(inc,AS(),COMPSTR);
				fb[ilevel]=f;
				f=fopen(inc,"r"); // confirmed "r"
				if (!f) perror_(__LINE__,68,l);
				isInclude=TRUE;
				continue;
			}
			/* control -NOEXECUTE */
			else if (!strncasecmp_(w,"NOEXECUTE",5)) {
				isNoExecute=TRUE;
			}
			/* control -FORMAT */
			else if (!strncasecmp_(w,"FORMAT",5)) {
				isFormat=TRUE;
			}
			/* control -LIST */
			else if (!strncasecmp_(w,"LIST",4)) {
				liflag=2; // right
				w+=4;
				while (isblank(*w)) w++;
				if (!strncasecmp_(w,"LEFT",4)) liflag=1;
				else if (!*w) liflag=2;
				isToListD=TRUE;
			}
			/* control -UNLIST */
			else if (!strncasecmp_(w,"UNLIST",6)) {
				liflag=0;
			}
			/* control -NOLIST */
			else if (!strncasecmp_(w,"NOLIST",6)) {
				isToListD=FALSE;
			}
			/* control -SINGLE */
			else if (!strncasecmp_(w,"SINGLE",6)) {
				spflag=1;
			}
			/* control -DOUBLE */
			else if (!strncasecmp_(w,"DOUBLE",6)) {
				spflag=2;
			}
			/* control -FAIL */
			else if (!strncasecmp_(w,"FAIL",6)) {
				fflag=TRUE;
				continue;
			}
			/* control -NOFAIL */
			else if (!strncasecmp_(w,"NOFAIL",6)) {
				fflag=FALSE;
				continue;
			}
			/* control -PRAGMA */
			else if (!strncasecmp_(w,"PRAGMA",6)) {
				w+=6;
				while (isblank(*w)) w++;
				if (doThePragma) doPragma(w);
				continue;
			}
			w=pB;
		}
		else if (*pB=='-' && isAvoidDirectives) continue;
		
		/* make some proper substitutions */
		k=pB;
		st=0, dt=0;
		while (*k) {
			if (*k=='\'') st++;
			if (*k=='\"') dt++;
			if (*k=='<' && !(dt&1) && !(st&1)) *k='[';
			if (*k=='>' && !dt && !st) *k=']';
			k++;
		}

		/* store original execution line */
		lo++;
		mb[lo]=malloc(strlen(B)+1);
		if (!mb[lo]) perror_(__LINE__,73,l);
		strncpy_(mb[lo],B,strlen(B)+1);
		/* check if it's a void/NIL line (i.e. line with
		 * no line number and no statements) or a comment line  */
		linenum++;
		if (!*pB || *pB=='*') {
			m[linenum]=malloc(3);
			if (!m[linenum]) perror_(__LINE__,73,l);
			strncpy_(m[linenum],"",3);
			endCore=linenum;
			ln[linenum]=0;
			continue;
		}
		/* treat the label END */
		if (!strncasecmp_(pB,"END",3) &&\
				(isblank(*(pB+3)) || !*(pB+3))) {
			char *s=startLabel;
			mf[linenum]=fflag;
			if (isResFile) setSourceFile(f);
			ln[linenum]=endCode; // END label code
			label[linenum]=malloc(4);
			if (!label[linenum]) perror_(__LINE__,73,l);
			strncpy_(label[linenum],"END",4);
			endCore=finalCore=linenum;
			ms[linenum]=liflag;
			sActive++;
			pB+=3;
			while (isblank(*pB)) pB++;
			if (*pB) {
				while (*pB) *s++=*pB++;
				*s='\0';
			}
			break;
		}
		/* fix line flags */
		ml[linenum]=ilevel;
		mf[linenum]=fflag;
		md[linenum]=spflag;
		ms[linenum]=liflag;

		/* evaluate grouped lines */
		do {
			/* search for grouped lines */
			sm=strcasestr_oq(w,";");
			if (sm) {
				*sm='\0';
				sm++;
			}
			/* remove label and store in ln[]
			 * Note: the label must start at the first character */
			ln[linenum]=0;
			if (*w && isbeginnamechar(w)) {
				lab=L;
				while (isnamechar(w)) *lab++=toupper(*w++);
				*lab='\0';
				ln[linenum]=setAddr(L);
				lnTOS++;
				if (lnTOS>=VLIMIT) perror_(__LINE__,82,l);
				label[linenum]=malloc(strlen(L)+1);
				if (!label[linenum]) perror_(__LINE__,73,l);
				strncpy_(label[linenum],L,strlen(L)+1);
			}
			else {
				ln[linenum]=0;
				label[linenum]=malloc(2);
				if (!label[linenum]) perror_(__LINE__,73,l);
				label[linenum][0]='\0';
				label[linenum][1]='\0';
			}
			/* check for special names */
			if (!strcasecmp(L,"RETURN") || !strcasecmp(L,"NRETURN") || !strcasecmp(L,"FRETURN"))
				perror_(__LINE__,53,linenum);
			/* check for duplicated labels */
			if (ln[linenum]) {
				int i=linenum-1;
				if (i<1) i=0;
				while (i>=0) {
					if (ln[linenum]==ln[i])
						break;
					i--;
				}
				if (i>=0) perror_(__LINE__,59,linenum);
			}
			while (isblank(*w)) w++;
			/* remove final blanks */
			while (isblank(*(w+strlen(w)-1))) *(w+strlen(w)-1)='\0';
			/* store pure execution line */
			strncpy_(pad,w,COMPSTR);
			m[linenum]=malloc(strlen(pad)+1);
			if (!m[linenum]) perror_(__LINE__,73,linenum);
			turnToUpper_oq(pad);
			strncpy_(m[linenum],pad,strlen(pad)+1);
			endCore=finalCore=linenum;
			sActive++; // for Stats
			if (sm) {
				w=sm;
				linenum++;
			}
		} while (sm);
		int ch=fgetc(f);
		if ((feof(f) && isInclude)) {
			f=fb[ilevel];
			ilevel--;
			if (!ilevel) isInclude=FALSE;
			continue;
		}
		else ungetc(ch,f);
	}
	/* close file channel */
	if (f) fclose(f);

	if (linenum==from) perror_(__LINE__,106,-1);
	/* check for END */
	return 0;
} // end of LOAD()


/* RUN()
 * the RUN command
 * Note: this statement is executed at start automatically and is not
 * available as a programming statement */
int RUN(void) {
	opturn=0; // for safety
	if (!isQuit) {
		if (startLabel[0]=='\0') parse(1);
		else {
			int nl=setAddr(startLabel);
			l=getLabelAddr(nl);
			parse(l);
		}
	}
	return TRUE;
}


/* calcTime()
 * adjust the time in endS filling in case min and hour */
void calcTime(double *endS, int *min, int *hour) {
	if (*endS>60) {
		*min=*endS/60;
		*endS=*endS-*min*60;
	}
	if (*min>60) {
		*hour=*min/60;
		*min=*min-*hour*60;
	}
}


/* doTiming()
 * execute the timing feature */
void doTiming(double endS) {
	int hour=0,min=0;
	double secs=endS;
	calcTime(&endS,&min,&hour);
	fputc('\n',stdout);
	/* print timing */
	if (!hour && !min) {
		if (secs<1)
		     fprintf(stdout,"Time:  %.2f ms\n\n",endS*1000.0);
		else
		     fprintf(stdout,"Time:  %.2f s\n\n",endS);
	}
	else if (!hour)
		fprintf(stdout,"Time:  %.2d:%.2d minute%c (%.2f s).\n\n",min,(int)(endS+0.5),min!=1?'s':' ',secs);
	else
		fprintf(stdout,"Time:  %.2d:%.2d:%.2d hour%c (%.2f s).\n\n",hour,min,(int)(endS+0.5),hour!=1?'s':' ',secs);
}


/* memStatus()
 * get memory size of the whole program
 * For statistic scopes
 * Thanks for the algorithm to James and Thiton at
 * https://stackoverflow.com/questions/1558402/memory-usage-of-current-process-in-c*/
int memStatus(void) {
	const char* statm_path = "/proc/self/statm";
	int resident=0,share=0,text=0,lib=0,data=0,dt=0,size=0;

	FILE *f = fopen(statm_path,"r"); // confirmed "r"
	if(!f) return -1;
	if (7 != fscanf(f,"%d %d %d %d %d %d %d",&size,&resident,&share,&text,&lib,&data,&dt)) {
		return -1;
	}
  	fclose(f);
	return resident+share+text+lib+data+dt+size;
}


/* doStats()
 * execute the statistics feature */
void doStats(double endS) {
	int hour=0,min=0;
	double tendS=endS;
	double secs=endS;
	char str[COMPSTR];
	calcTime(&tendS,&min,&hour);
	strncpy_(str,"execution time                ",COMPSTR);
	fputc('\n',stdout);
	fprintf(stdout,"soft statistics summary\n-----------------------\n\n");
	fprintf(stdout,"interpreter version           : %s (compiled %s)\n",VERSION,__DATE__);
	fprintf(stdout,"file                          : %s\n",filename);
	if (!hour && !min) {
		if (secs<1)
			fprintf(stdout,"%s: %.2f ms\n",str,secs*1000.0);
		else
			fprintf(stdout,"%s: %.2f s\n",str,secs);
	}
	else if (!hour) fprintf(stdout,"%s: %02d:%02d minutes\n",str,min,(int)(tendS+0.5));
	else fprintf(stdout,"%s: %02d:%02d:%02d hours\n",str,hour,min,(int)(tendS+0.5));
	fprintf(stdout,"total program lines           : %d\n",endCore);
	fprintf(stdout,"last line executed            : %d\n",sLastNo);
	fprintf(stdout,"number of statements executed : %d\n",sStatms);
	fprintf(stdout,"math operations performed     : %d\n",sMaths);
	fprintf(stdout,"pattern-evaluations performed : %d\n",sPatt);
	fprintf(stdout,"pattern-matches found         : %d\n",sMatches);
	fprintf(stdout,"reads performed               : %d\n",sReads);
	fprintf(stdout,"writes performed              : %d\n",sWrites);
	fprintf(stdout,"average per-statement timing  : %.2f ms/statement\n",sStatms>0?tendS*1000.0/sStatms:0.0);
	fprintf(stdout,"used memory                   : %d bytes\n",memStatus());
	fprintf(stdout,"\n");
}


/* END()
 * end program, accomplishing various tasks, such as closing opened channels,
 * print timing, fixing graphical stuff and closing regularly as C requires.
 * Note: as exit state, return the state passed to it as argument.
 * Note: as the returned states, I use:
 * EXIT_SUCCESS (which is 0) to indicate a proper successful execution
 * EXIT_FAILURE (which is 1) to indicate a stop after an error condition
 * EXIT_STOP (which is 2) to indicate an invoked STOP termination */
int END(int state) {
	int i;

	/* close all opened files */
	for (i=2;i<=fileTOS;i++) {
		if (channel[i].stream && openStreams[i])
			fclose(channel[i].stream);
	}

	/* remove freeze file in case of error */
	if (!isFreezeOnExit && isFreeze) {
		char freezefile[COMPSTR];
		strncpy_(freezefile,createFreezeFile(),COMPSTR);
		remove(freezefile);
	}

	/* don't execute options in case of FREEZE() */
	if (isFreezeOnExit) goto goaway;

	/* if required, send to printer all printer files and remove them */
	for (i=2;i<=fileTOS;i++) {
		if (channel[i].isPrinter && isPrinter) {
			char command[COMPSTR];
			strncpy_(command,"cat ",COMPSTR);
			strncat_(command,channel[i].ioname,COMPSTR);
			strncat_(command," | lpr",COMPSTR);
	       		system(command);
			remove(channel[i].ioname);
		}
	}

	/* remove the resource file */
	if (isResFile) remove(RESFILE);

	/* TIMING OPERATIONS */
	/* record end time
	 * Note: if file was not found, beginS remains negative */
	if (beginS<0) endS=0.0;
	else {
		gettimeofday(&tv, NULL);
	       	endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS=endS-beginS;
	}

	/* in case of DUMP, print the content of all variables */
	if (isDumping) {
		int i, st=FALSE, beg=sDefVar+1;
		char nulls[COMPSTR];
		if (isDumping<4) strncpy_(nulls,"NON-NULL ",COMPSTR);
		else strncpy_(nulls,"ALL ",COMPSTR);
		if (isDumping==4) beg=1;
		fprintf(stdout,"\n\n\nDUMP OF %sVARIABLES AT TERMINATION\n\n",nulls);
		fprintf(stdout,"NATURAL VARIABLES\n");
		fprintf(stdout,"-----------------\n\n");
		for (i=beg;i<=decCount;i++) {
			int j,k,tt;
			tt=vn[i].datatype;
			if (tt>PREDEF) tt-=PREDEF;
			if (tt>CODE) continue;
			if (vn[i].isData>0 && (vn[i].str[0] || isDumping==4)) {
				char name[COMPSTR], *n=name, *v=vn[i].name;
				k=strlen(vn[i].str)>SCREEN?SCREEN:strlen(vn[i].str);
				while (*v && *v!='(') *n++=*v++;
				if (*v=='(') *n++=*v++;
				*n='\0';
				strncat_(name,vn[vn[i].isData].name,COMPSTR);
				strncat_(name,")",COMPSTR);
				fprintf(stdout,"%s = ",name);
				for (j=0;j<k;j++) fputc(vn[i].str[j],stdout);
				if (strlen(vn[i].str)>SCREEN) fprintf(stdout,"...");
				fprintf(stdout,"\n");
			}
			else if ((vn[i].str[0] || isDumping==4) && tt<STRING) {
				k=strlen(vn[i].str)>SCREEN?SCREEN:strlen(vn[i].str);
				fprintf(stdout,"%s = ",vn[i].name);
				for (j=0;j<k;j++) fputc(vn[i].str[j],stdout);
				if (strlen(vn[i].str)>SCREEN) fprintf(stdout,"...");
				fprintf(stdout,"\n");
			}
			else if ((vn[i].str[0] || isDumping==4) && tt==STRING) {
				k=strlen(vn[i].str)>SCREEN?SCREEN:strlen(vn[i].str);
				fprintf(stdout,"%s = '",vn[i].name);
				for (j=0;j<k;j++) fputc(vn[i].str[j],stdout);
				if (strlen(vn[i].str)>SCREEN) fprintf(stdout,"...");
				fprintf(stdout,"'\n");
			}
			else if (tt==PATTERN) {
				if (!isPrintComplete) fprintf(stdout,"%s = [PATTERN]\n",vn[i].name);
				else fprintf(stdout,"%s = %s [PATTERN]\n",vn[i].name,vn[i].str);
			}
			else if (tt==NAME) {
				fprintf(stdout,"%s = .%s\n",vn[i].name,vn[i].str);
			}
			else if (tt==CODE) {
				fprintf(stdout,"%s = [CODE]\n",vn[i].name);
			}
		}
		fprintf(stdout,"\n");
		for (i=beg;i<=decCount;i++) {
			int tt,ri;
			tt=vn[i].datatype;
			ri=vn[i].ref; // not for [].name
			if (tt>PREDEF) tt-=PREDEF;
			if (tt<=CODE) continue;
			if (!st) {
				fprintf(stdout,"%s","\n");
				fprintf(stdout,"CREATED VARIABLES\n");
				fprintf(stdout,"-----------------\n\n");
				st=TRUE;
			}
			if (vn[ri].datatype==DATA) {
				fprintf(stdout,"%s = ",vn[i].name);
				fprintf(stdout,"[%s] ('%s')",datafunc[vn[ri].dim].name,datafunc[vn[ri].dim].proto);
				if (i!=ri) fprintf(stdout,"%s"," (ref)");
				fprintf(stdout,"%s","\n");
			}
			else if (vn[ri].datatype==ARRAY) {
				fprintf(stdout,"%s = ",vn[i].name);
				fprintf(stdout,"[ARRAY] ('%s')",vn[ri].proto);
				if (i!=ri) fprintf(stdout,"%s"," (ref)");
				fprintf(stdout,"%s","\n");
			}
			else {
				fprintf(stdout,"%s = ",vn[i].name);
				fprintf(stdout,"[%s]",types[vn[ri].datatype/100]);
				if (vn[i].datatype==STRING && !vn[ri].str[0])
					fprintf(stdout," (empty string)");
				fprintf(stdout,"\n");
			}
		}
		/* add unprotected variables list */
		if (isDumping>=2) {
			fprintf(stdout,"%s","\n");
			fprintf(stdout,"UNPROTECTED VARIABLES\n");
			fprintf(stdout,"---------------------\n\n");
			fprintf(stdout,"&ABEND = %d\n",isAbend);
			fprintf(stdout,"&ANCHOR = %d\n",isAnchored);
			fprintf(stdout,"&CODE = %d\n",procCode);
			fprintf(stdout,"&DUMP = %d\n",isDumping);
			fprintf(stdout,"&FTRACE = %d\n",isFtrace);
			fprintf(stdout,"&FULLSCAN = %d\n",isFullscan);
			fprintf(stdout,"&INPUT = %d\n",isInput);
			fprintf(stdout,"&OUTPUT = %d\n",isOutput);
			fprintf(stdout,"&MAXLNGTH = %d\n",COMPSTR);
                        fprintf(stdout,"&REAL = %d\n",isNotExponential);
			fprintf(stdout,"&STLIMIT = %d\n",isStLimit);
			fprintf(stdout,"&TRACE = %d\n",isTrace);
			fprintf(stdout,"&TRIM = %d\n",isGTrim);
			fprintf(stdout,"\n");
		}
		/* add protected variables list */
		if (isDumping>=3) {
			fprintf(stdout,"%s","\n");
			fprintf(stdout,"PROTECTED VARIABLES\n");
			fprintf(stdout,"-------------------\n\n");
			fprintf(stdout,"&ABORT = [PATTERN]\n");
			fprintf(stdout,"&ALPHABET = %s\n",COMPLETESET);
			fprintf(stdout,"&ARB = [PATTERN]\n");
			fprintf(stdout,"&BAL = [PATTERN]\n");
			fprintf(stdout,"&DIGITS = %s\n",digits);
			fprintf(stdout,"&ERRLINE = %d\n",lErr);
			fprintf(stdout,"&ERRTYPE = %d\n",sErr);
			fprintf(stdout,"&FAIL = [PATTERN]\n");
			fprintf(stdout,"&FENCE = [PATTERN]\n");
			fprintf(stdout,"&FILE = %s\n",filename);
			fprintf(stdout,"&FNCLEVEL = %d\n",funcTOS);
			fprintf(stdout,"&LASTNO = %d\n",sLastNo);
			fprintf(stdout,"&LCASE = %s\n",lcase);
			fprintf(stdout,"&LINESNO = %d\n",endCore);
			fprintf(stdout,"&MEMLIMIT = %d\n",MEMLIMIT);
			fprintf(stdout,"&PARM = %s\n",parm);
			fprintf(stdout,"&PI = %.15G\n",SOFTPI);
			fprintf(stdout,"&REM = [PATTERN]\n");
			fprintf(stdout,"&RTNTYPE = %s\n",sReturn);
			fprintf(stdout,"&SPACE = %s\n"," \t");
			fprintf(stdout,"&STCOUNT = %d\n",sStatms);
			fprintf(stdout,"&STFCOUNT = %d\n",sFail);
			fprintf(stdout,"&STNO = %d\n",l);
			fprintf(stdout,"&UCASE = %s\n",ucase);
			fprintf(stdout,"\n\n");
		}
		fprintf(stdout,"\n");
	}

	/* timing or statistics */
	if (isTiming) doTiming(endS);
	else if (isStats) doStats(endS);


	/* LISTING OPERATIONS */
	if (isListAfter && !noFile) list_beauty();

	/* final state */
	if (isFinDebug) {
		printf("**********************************\n");
		printCurState();
		printf("**********************************\n");
	}

goaway:

	/* perform unload of all var data if required */
	if (isCompleteUnload) {
		int i=decCount, tt;
		printf("\nVariables data discharge for program %s:\n\n",filename);
		printf("Name        Code  Type         ref. dim. str              len           num    proto             method\n");
		printf("-------------------------------------------------------------------------------------------------------\n");
		while (i>0) {
			char num[COMPSTR];
			char *k, *h, prot[COMPSTR];
			tt=vn[i].datatype;
			if (tt>PREDEF) tt-=PREDEF;
			if (tt<=0) tt=0;
			else if (tt>DATA) tt=0;
			strncpy_(prot,vn[i].proto,COMPSTR);
			k=prot;
			h=vn[i].proto;
			while (*h) {
				if (*h=='\t') {
					h++; // skip tab
					while ((k-prot)%8) *k++=' '; 
				}
				else *k++=*h++;
			}
			*k='\0';
			snprintf(num,COMPSTR,"%.15G",vn[i].num);
			printf("%-10.10s  {%02d}  %-10.10s   %02d   %02d   {%10.10s}   [%04d]   %10.10s   {%-15.15s}  %s\n",vn[i].name,i,types[tt/100],vn[i].ref,vn[i].dim,vn[i].str,(int)strlen(vn[i].str),num,prot,vn[i].isData?vn[vn[i].isData].name:"-");
			i--;
		}
		printf("\nEnd of variable discharge\n\n");
		if (!dataTOS) 
			printf("No structure in this program.\n\n");
		else {
			for (i=1;i<=dataTOS;i++) {
				printf("Data struct %s with proto '%s' [%d]\n",datafunc[i].name,datafunc[i].proto,datafunc[i].num);
			}
			printf("\nEnd of data discharge\n\n");
		}
		if (!defineTOS) 
			printf("No defined procedure in this program.\n\n");
		else {
			for (i=1;i<=defineTOS;i++) {
				printf("Defined procedure %s with arguments proto '%s' [%d] and local proto '%s'\n",definefunc[i].name,definefunc[i].argproto,definefunc[i].anum,definefunc[i].otherproto);
			}
			printf("\nEnd of defined procs discharge\n\n");
		}
		
	}

	/* QUITTING */
	/* flush all open streams, to ensure file data writing is completed */
	fflush(NULL);
	if (!goPie) s_exit(state);
	else report=FALSE;
	return TRUE;
}


/* s_exit()
 * safe exit - avoid messing up of colours, and force the screen resetting
 * return 'state' as current state
 * system function */
void s_exit(int state) {
	/* check for closing brackets */
	if (isDebug) {
		fprintf(stdout,"%s",RESETCOLOR);
	}
	if (!isAbend) exit(state);
	else abort();
}


/******************************************************************************
 * The following functions define the whole parser engine:
 * SS() 	  : the strings expression parser
 * strRel()       : the strings relation evaluator (returns a truth value)
 * S() 		  : the numerical expression parser
 * getVal()	  : the single numerical value parser
 * getFunc()	  : the numerical function parser
 * priority()	  : return numerical operator precedence
 * conceived April 2008 for the dib project
 * modified for vibes with strings insertion September-November 2009
 * updated and verified for soft - November 2020
 * Copyleft Antonio Maschio - 2008-2021
 ******************************************************************************/
/* getString()
 * get a formatted string from user keyboard, excluding user delay
 * if isCanon is TRUE, echo the same characters string, otherwise
 * echo asterisks (for a hidden input) */
char * getString(int isCanon) {
	char *lp=line;
	int i;

	/* get string */
	for (i=0; i<COMPSTR; i++) line[i]='\0';
	while (TRUE) {
		*lp=getchar();
		if (*lp==10 || *lp==13 || *lp=='\n') {
			*lp='\0';
			break;
		}
		else if (*lp==EOF) {
			report=FALSE;
			break;
		}
		else lp++;
		if (!isCanon) fputc('*',stdout);
	}

	/* return string */
	return lp=line;
}


/* evalDot()
 * evaluate the dot-assignment; this function looks for the dot, and
 * assembles an array of variables codes and strings, that will be
 * instantiated only in case of report=TRUE at the moment of jump */
void evalDot(char *str) {
	int ns;
	while (isblank(*p)) p++;
	if (*p!='.') return;
	p++; // skip .
	if (*p && !isblank(*p)) return;
	while (isblank(*p)) p++;
	ns=findDEC(p);
	if (argtype) {
		vn[ns].argtype=argtype;
		strncpy_(vn[ns].argparam,argparam,COMPSTR);
	}
	if (ns && vn[ns].datatype==ARRAY) {
		p+=_len;
		dotTOS++;
		dotudim[dotTOS]=1;
		if (*p=='[') {
			p++; // skip [
			dotval[dotTOS][dotudim[dotTOS]]=(int)S();
			while (*p==',' && dotudim[dotTOS]<MAXDIM) {
				p++;
				dotudim[dotTOS]++;
				dotval[dotTOS][dotudim[dotTOS]]=(int)S();
			}
			if (dotudim[dotTOS]>=MAXDIM) perror_(__LINE__,33,l);
			if (*p==']') p++;
		}
		else perror_(__LINE__,33,l);
		strncpy_(dotstr[dotTOS],str,COMPSTR);
		dotvar[dotTOS]=ns;
		if (argtype) {
			vn[ns].argtype=argtype;
		}
	}
	else if (ns>0) {
		p+=_len;
		if (!rightPos || !report) return;
		dotTOS++;
		strncpy_(dotstr[dotTOS],str,COMPSTR);
		dotvar[dotTOS]=ns;
		dotudim[dotTOS]=-1;
	}
	else perror_(__LINE__,12,l);
	checkTrace(ns);
	while (isblank(*p)) p++;
}


/* evalDollar()
 * evaluate the dollar-assignment; this function looks for the dollar, and
 * assigns immediately to the following variable the value passed to it */
void evalDollar(char *str) {
	int ns;
	while (isblank(*p)) p++;
	if (*p!='$') return;
	p++; // skip $
	if (*p && !isblank(*p)) return;
	while (isblank(*p)) p++;
	ns=findDEC(p);
	if (argtype) {
		vn[ns].argtype=argtype;
		strncpy_(vn[ns].argparam,argparam,COMPSTR);
	}
	if (ns && vn[ns].datatype==ARRAY) {
		int val[MAXDIM+1], udim=1;
		p+=_len;
		if (*p=='[') {
			p++; // skip [
			ns=vn[ns].ref;
			val[udim]=(int)S();
			if (val[udim]<vn[ns].offset[udim] || val[udim]>vn[ns].ldim[udim]+vn[ns].offset[udim]) {
				report=FALSE;
				return;
			}
			while (*p==',') {
				p++;
				udim++;
				if (udim>vn[ns].dim) perror_(__LINE__,52,l);
				val[udim]=(int)S();
				if (val[udim]<vn[ns].offset[udim] || val[udim]>vn[ns].ldim[udim]+vn[ns].offset[udim]) {
					report=FALSE;
					return;
				}
			}
			if (*p==']') p++;
			else if (udim<vn[ns].dim) perror_(__LINE__,31,l);
			else {
				report=FALSE;
				return;
			}
			setArrayStr(ns,udim,val,str);
			setArrayVal(ns,udim,val,STRING);
		}
		else perror_(__LINE__,33,l);
	}
	else if (ns>0) {
		p+=_len;
		if (!rightPos || !report) return;
		strncpy_(vn[ns].str,str,COMPSTR);
		vn[ns].datatype=STRING;
		DO_OUTPUT(ns);
	}
	else perror_(__LINE__,12,l);
	checkTrace(ns);
	while (isblank(*p)) p++;
} // end evalDollar()


/* evalAt()
 * evaluate the at-assignment of scan; this function looks for the at, and
 * assigns to the following variable the passed scanning position*/
void evalAt(void) {
	int ns;
	char op[COMPSTR];
	if (!l) return;
	if (!p) return;
	while (isblank(*p)) p++;
	if (*p!='@') return;
	p++; // skip @: variable name must immediately follow
	if (*p && isblank(*p)) perror_(__LINE__,18,l);
	ns=findDEC(p);
	if (ns && vn[ns].datatype==ARRAY) {
		int val[MAXDIM+1], udim=1;
		p+=_len;
		if (*p=='[') {
			p++; // skip [
			ns=vn[ns].ref;
			val[udim]=(int)S();
			if (val[udim]<vn[ns].offset[udim] || val[udim]>vn[ns].ldim[udim]+vn[ns].offset[udim]) {
				report=FALSE;
				return;
			}
			while (*p==',') {
				p++;
				udim++;
				if (udim>vn[ns].dim) perror_(__LINE__,52,l);
				val[udim]=(int)S();
				if (val[udim]<vn[ns].offset[udim] || val[udim]>vn[ns].ldim[udim]+vn[ns].offset[udim]) {
					report=FALSE;
					return;
				}
			}
			if (*p==']') p++;
			else if (udim<vn[ns].dim) perror_(__LINE__,31,l);
			else {
				report=FALSE;
				return;
			}
			snprintf(op,COMPSTR,"%d",scan);
			setArrayStr(ns,udim,val,op);
			setArrayVal(ns,udim,val,STRING);
		}
		else perror_(__LINE__,33,l);
		DO_OUTPUT(ns);
		if (argtype) {
			vn[ns].argtype=argtype;
			strncpy_(vn[ns].argparam,argparam,COMPSTR);
		}
	}
	else if (ns>0) {
		p+=_len;
		if (!rightPos || !report) return;
		snprintf(op,COMPSTR,"%d",scan);
		strncpy_(vn[ns].str,op,COMPSTR);
		vn[ns].datatype=INTEGER;
		DO_OUTPUT(ns);
	}
	else perror_(__LINE__,12,l);
	checkTrace(ns);
	while (isblank(*p)) p++;
} // end evalAt()


/* isVar()
 * determine if the string pointed to by s is a variable in the form
 * ANNNNN where A is any alphabetic char for the first character
 * and N is any alphanumeric char for the rest of the string.
 * If the string is followed by a closure (that is a void, a blank or the
 * closing parenthesis) the string is effectively a possible variable name
 * System function for GP() */
int isVar(char *s) {
	if (!isbeginnamechar(s)) return FALSE;
	while (isnamechar(s)) s++;
	if (isblank(*s) || isender(s)) return TRUE;
	return FALSE;
}


/* isUniEvalFunc()
 * detects if the function starting in s is an argument-less inputfunction
 * that can be confused with a variable name */
int isUniEvalFunc(char *s) {
	if (!strncasecmp_(s,"TERMINAL",8) && isblank(*(s+5))) return TRUE;
	if (!strcasecmp(s,"TERMINAL")) return TRUE;
	if (!strncasecmp_(s,"INPUT",5) && isblank(*(s+5))) return TRUE;
	if (!strcasecmp(s,"INPUT")) return TRUE;
	return FALSE;
}


/* isarrvar()
 * check if the string starting in p points to an array variable name
 * System function for GP() */
int isarrvar(char *p) {
	int ns=0;
	char varname[COMPSTR], *v=varname;
	if (!*p) return FALSE;
	if (*p=='$') return TRUE;
	if (!isbeginnamechar(p)) return FALSE;
	while (isnamechar(p)) *v++=*p++;
	*v='\0';
	if (*p=='(') return FALSE; // it's a function
	ns=searchDEC(varname,decCount);
	if (!ns) return FALSE;
	ns=vn[ns].ref;
	if (vn[ns].datatype==ARRAY) return TRUE;
	return FALSE;
}


/* isnumvar()
 * check if the string starting in p points to a numeric variable name
 * System function for GP() */
int isnumvar(char *p) {
	int ns=0;
	char varname[COMPSTR], *v=varname;
	if (!*p) return FALSE;
	if (*p=='$') return TRUE;
	if (!isbeginnamechar(p)) return FALSE;
	while (*p && (isnamechar(p) || *p=='(' || *p==')')) *v++=*p++;
	*v='\0';
	if (*p=='(') return FALSE; // it's a function
	if (*p=='[') return TRUE; // it's an array item
	ns=searchDEC(varname,decCount);
	if (!ns) return FALSE;
	if (vn[ns].datatype==ARRAY) return TRUE;
	if (vn[ns].datatype>REAL) return FALSE;
	return TRUE;
}


/* isnumstr()
 * check if the string starting in p points to a 'string' or a "string"
 * containing only digits or elements like the +/-, the dot, the letter E
 * for exponents, that can be consumed by strtod() in their entirety.
 * In this case the string is a number in string form.
 * System function for GP() */
int isnumstr(char *p) {
	char q;
	char str[COMPSTR], *v=str;
	if (*p!='\'' && *p!= '\"') return FALSE;
	else q=*p++; // skip quote
	while (*p && *p!=q) *v++=*p++;
	*v='\0';
	strtod(str,&v);
	if (*v) return FALSE;
	return TRUE;
}


/* isnumpad()
 * check if the entire string starting in p contains a number.
 * System function for GP() */
int isnumpad(char *p) {
	char str[COMPSTR], *v=str;
	while (*p) *v++=*p++;
	*v='\0';
	strtod(str,&v);
	if (*v) return FALSE;
	return TRUE;
}


/* isnumfun()
 * check if the string pointed to by p
 * is the beginning of a math function */
int isnumfun(char *p) {
	if (!strncasecmp_(p,"ABS(",4)) return TRUE;
	if (!strncasecmp_(p,"ASIN(",5)) return TRUE;
	if (!strncasecmp_(p,"ACOS(",5)) return TRUE;
	if (!strncasecmp_(p,"ARCCOS(",7)) return TRUE;
	if (!strncasecmp_(p,"ARCSIN(",7)) return TRUE;
	if (!strncasecmp_(p,"ARCTAN(",7)) return TRUE;
	if (!strncasecmp_(p,"ATAN(",5)) return TRUE;
	if (!strncasecmp_(p,"CHOP(",5)) return TRUE;
	if (!strncasecmp_(p,"COS(",4)) return TRUE;
	if (!strncasecmp_(p,"EORLEVEL(",9)) return TRUE;
	if (!strncasecmp_(p,"EXP(",4)) return TRUE;
	if (!strncasecmp_(p,"FILESIZE(",9)) return TRUE;
	if (!strncasecmp_(p,"LN(",3)) return TRUE;
	if (!strncasecmp_(p,"LOG(",4)) return TRUE;
	if (!strncasecmp_(p,"ORD(",4)) return TRUE;
	if (!strncasecmp_(p,"PI(",3)) return TRUE;
	if (!strncasecmp_(p,"ROOT(",5)) return TRUE;
	if (!strncasecmp_(p,"RANDOM(",7)) return TRUE;
	if (!strncasecmp_(p,"SEEK(",5)) return TRUE;
	if (!strncasecmp_(p,"SIN(",4)) return TRUE;
	if (!strncasecmp_(p,"SIZE(",5)) return TRUE;
	if (!strncasecmp_(p,"SQRT(",5)) return TRUE;
	if (!strncasecmp_(p,"SQR(",4)) return TRUE;
	if (!strncasecmp_(p,"STCOUNT(",8)) return TRUE;
	if (!strncasecmp_(p,"TAN(",4)) return TRUE;
	if (!strncasecmp_(p,"TIME(",5)) return TRUE;
	return FALSE;
}


/* ispatfun()
 * check if the string pointed to by p
 * is the beginning of a pattern function */
int ispatfun(char *p) {
	if (!strncasecmp_(p,"NOTANY(",7)) return TRUE;
	if (!strncasecmp_(p,"ANY(",4)) return TRUE;
	if (!strncasecmp_(p,"TAB(",4)) return TRUE;
	if (!strncasecmp_(p,"RTAB(",5)) return TRUE;
	if (!strncasecmp_(p,"SPAN(",5)) return TRUE;
	if (!strncasecmp_(p,"BREAK(",6)) return TRUE;
	if (!strncasecmp_(p,"BREAKX(",7)) return TRUE;
	if (!strncasecmp_(p,"LEN(",4)) return TRUE;
	if (!strncasecmp_(p,"ARBNO(",6)) return TRUE;
	if (!strncasecmp_(p,"POS(",4)) return TRUE;
	if (!strncasecmp_(p,"RPOS(",5)) return TRUE;
	return FALSE;
}


/* isIntFunc()
 * evaluate internal system functions */
int isIntFunc(char *mypad) {
	char *pb=p;
	/* SIZE() function
	 * return the length of the string in argument */
	if (!strncasecmp_(p,"SIZE(",5)) {
		char op[COMPSTR];
		p+=5;
		while (isblank(*p)) p++;
		strncpy_(op,AS(),COMPSTR);
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",(int)strlen(op));
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* SEEK() function
	 * fseek pos on the file passed as argument
	 * SEEK(file) = TELL(file)
	 * SEEK(file,0) TELL(file)
	 * SEEK(file,48) set forward 48 chars
	 * SEEK(file,-48) set backward 48 chars */
	else if (!strncasecmp_(p,"SEEK(",5)) {
		char fname[COMPSTR];
		int ch=2, dist=0,fixed=FALSE,ns;
		FILE *fd;
		p+=5;
		strncpy_(fname,AS(),COMPSTR);
		if (*p==',') {
			p++;
			dist=(int)S();
		}
		while (isblank(*p)) p++;
		ns=searchDEC(p,decCount);
		if (isquote(p) || (ns && vn[ns].datatype==STRING)) {
			char pos[COMPSTR];
			strncpy_(pos,AS(),COMPSTR);
			if (!strcasecmp(pos,"START"))
				fixed=1;
			else if (!strcasecmp(pos,"END"))
				fixed=2;
		}
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				long int pos=0, extreme=0;
				fd=channel[ch].stream;
				if (fd==stdin || fd==stdout || fd==stderr) {
					report=FALSE;
					sErr=99;
					lErr=l;
					return TRUE;
				}
				else if (fixed==1) {
					fseek(fd,0,SEEK_SET);
				}
				else if (fixed==2) {
					fseek(fd,0,SEEK_END);
				}
				else {
					pos=ftell(fd);
					fseek(fd,0,SEEK_END);
					extreme=ftell(fd);
					if (pos+dist<0)
						dist=0;
					else if (pos+dist>extreme)
						dist=extreme;
					else dist=pos+dist;
					fseek(fd,dist,SEEK_SET);
				}
				snprintf(mypad,COMPSTR,"%ld",ftell(fd));
				break;
			}
			ch++;
		}
		if (ch>fileTOS) perror_(__LINE__,44,l);
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* FILESIZE() function
	 * return the size in bytes of the file passed as argument */
	else if (!strncasecmp_(p,"FILESIZE(",9)) {
		char fname[COMPSTR];
		long pos1,pos2;
		FILE *fd;
		p+=9;
		strncpy_(fname,AS(),COMPSTR);
		fd=fopen(fname,"r"); // confirmed "r"
		if (!fd) perror_(__LINE__,69,l);
		fseek(fd,0,SEEK_SET);
		pos1=ftell(fd);
		fseek(fd,0,SEEK_END);
		pos2=ftell(fd);
		snprintf(mypad,COMPSTR,"%ld",pos2-pos1);
		fclose(fd);
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* EORLEVEL() function
	 * return the end-of-groupd code if found */
	else if (!strncasecmp_(p,"EORLEVEL(",9)) {
		char fname[COMPSTR];
		int ch=2;
		FILE *fd;
		p+=9;
		strncpy_(fname,AS(),COMPSTR);
		while (ch<=fileTOS) {
			fd=channel[ch].stream;
			if (!strcmp(fname,channel[ch].ioname)) {
				if (fd==stdin || fd==stdout || fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				else {
					int pos=ftell(fd);
					char text[COMPSTR];
					if (feof(fd)) {
						snprintf(mypad,COMPSTR,"%d",-1);
					}
					else {
						fgets_(text,COMPSTR,fd);
						if (!strncasecmp_(text,FREEZECODE,6)) {
							snprintf(mypad,COMPSTR,"%ld",strtol(text+6,NULL,10));
						}
						else {
							snprintf(mypad,COMPSTR,"%d",-2);
						}
						fseek(fd,pos,SEEK_SET);
					}

				}
				break;
			}
			ch++;
		}
		if (ch>fileTOS) perror_(__LINE__,44,l);
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* REMDR() function
	 * return the remainder of the two integer numbers
	 * passed as arguments */
	else if (!strncasecmp_(p,"REMDR(",6)) {
		int op1, op2;
		p+=6;
		op1=(int)S();
		if (*p!=',') perror_(__LINE__,65,l);
		p++; // skip comma
		op2=(int)S();
		if (!op2) perror_(__LINE__,15,l);
		snprintf(mypad,COMPSTR,"%d",op1%op2);
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* NOT() biwise function
	 * return the 2-complement value of the integer number */
	else if (!strncasecmp_(p,"NOT(",4)) {
		int op1, res=0, val=0, isInt=FALSE;
		char sop1[COMPSTR], top1[COMPSTR], *pb;
		int sign=-1;
		p+=4;
		strncpy_(top1,AS(),COMPSTR);
		pb=p;
		p=top1;
		strncpy_(sop1,AS(),COMPSTR);
		if (!sop1[0]) op1=report;
		else op1=(int)strtod(sop1,NULL), isInt=TRUE;
		report=TRUE;
		p=pb;
		if (!isInt) {
			report=!op1;
			_datatype=STRING;
		}
		else {
			if (op1<0) sign=1, op1=-op1;
			val=0;
			while (val<31) {
				if (!(op1 & (int)pow(2,val)))
					res+=pow(2,val);
				val++;
			}
			snprintf(mypad,COMPSTR,"%d",res*sign);
			_datatype=INTEGER;
		}
		if (*p==')') p++;
		return TRUE;
	}
	/* OR() bitwise function
	 * return the bitwise OR result of the two integer numbers
	 * passed as arguments */
	else if (!strncasecmp_(p,"OR(",3)) {
		int op1, op2, isInt=FALSE;
		char sop1[COMPSTR], sop2[COMPSTR], *pb;
		char top1[COMPSTR], top2[COMPSTR];
		p+=3;
		strncpy_(top1,AS(),COMPSTR);
		pb=p;
		p=top1;
		strncpy_(sop1,AS(),COMPSTR);
		if (!sop1[0]) op1=report;
		else op1=(int)strtod(sop1,NULL), isInt=TRUE;
		report=TRUE;
		p=pb;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			strncpy_(top2,AS(),COMPSTR);
			pb=p;
			p=top2;
			strncpy_(sop2,AS(),COMPSTR);
			if (!sop2[0]) op2=report;
			else op2=(int)strtod(sop2,NULL);
			report=TRUE;
			p=pb;
		}
		if (!isInt) {
			report=op1 | op2;
			_datatype=STRING;
		}
		else {
			snprintf(mypad,COMPSTR,"%d",(op1 | op2));
			_datatype=INTEGER;
		}
		if (*p==')') p++;
		return TRUE;
	}
	/* AND() function
	 * return the AND result of the two integer numbers/states
	 * passed as arguments */
	else if (!strncasecmp_(p,"AND(",4)) {
		int op1, op2, isInt=FALSE;
		char sop1[COMPSTR], sop2[COMPSTR], *pb;
		char top1[COMPSTR], top2[COMPSTR];
		p+=4;
		strncpy_(top1,AS(),COMPSTR);
		pb=p;
		p=top1;
		strncpy_(sop1,AS(),COMPSTR);
		if (!sop1[0]) op1=report;
		else op1=(int)strtod(sop1,NULL), isInt=TRUE;
		report=TRUE;
		p=pb;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			strncpy_(top2,AS(),COMPSTR);
			pb=p;
			p=top2;
			strncpy_(sop2,AS(),COMPSTR);
			if (!sop2[0]) op2=report;
			else op2=(int)strtod(sop2,NULL);
			report=TRUE;
			p=pb;
		}
		if (!isInt) {
			report=op1 & op2;
			_datatype=STRING;
		}
		else {
			snprintf(mypad,COMPSTR,"%d",(op1 & op2));
			_datatype=INTEGER;
		}
		if (*p==')') p++;
		return TRUE;
	}
	/* XOR() function
	 * return the XOR result of the two integer numbers/states
	 * passed as arguments */
	else if (!strncasecmp_(p,"XOR(",4)) {
		int op1, op2, isInt=FALSE;
		char sop1[COMPSTR], sop2[COMPSTR], *pb;
		char top1[COMPSTR], top2[COMPSTR];
		p+=4;
		strncpy_(top1,AS(),COMPSTR);
		pb=p;
		p=top1;
		strncpy_(sop1,AS(),COMPSTR);
		if (!sop1[0]) op1=report;
		else op1=(int)strtod(sop1,NULL), isInt=TRUE;
		report=TRUE;
		p=pb;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			strncpy_(top2,AS(),COMPSTR);
			pb=p;
			p=top2;
			strncpy_(sop2,AS(),COMPSTR);
			if (!sop2[0]) op2=report;
			else op2=(int)strtod(sop2,NULL);
			report=TRUE;
			p=pb;
		}
		if (!isInt) {
			report=op1 ^ op2;
			_datatype=STRING;
		}
		else {
			snprintf(mypad,COMPSTR,"%d",(op1 ^ op2));
			_datatype=INTEGER;
		}
		if (*p==')') p++;
		return TRUE;
	}
	/* EQV() function
	 * return the EQV result of the two integer numbers/states
	 * passed as arguments */
	else if (!strncasecmp_(p,"EQV(",4)) {
		int op1, op2, isInt=FALSE;
		char sop1[COMPSTR], sop2[COMPSTR], *pb;
		char top1[COMPSTR], top2[COMPSTR];
		int res=0, val=0;
		int lim=0;
		p+=4;
		strncpy_(top1,AS(),COMPSTR);
		pb=p;
		p=top1;
		strncpy_(sop1,AS(),COMPSTR);
		if (!sop1[0]) op1=report;
		else lim=op1=(int)strtod(sop1,NULL), isInt=TRUE;
		report=TRUE;
		p=pb;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			strncpy_(top2,AS(),COMPSTR);
			pb=p;
			p=top2;
			strncpy_(sop2,AS(),COMPSTR);
			if (!sop2[0]) op2=report;
			else op2=(int)strtod(sop2,NULL);
			report=TRUE;
			p=pb;
		}
		if (!isInt) {
			if (!op1 && !op2) report=TRUE;
			else if (op1 && op2) report=TRUE;
			else report=FALSE;
			_datatype=STRING;
		}
		else {
			if (op2>lim) lim=op2;
			val=0;
			while (val<32) {
				if ((int)pow(2,val)>lim) break;
				if ((op1 & (int)pow(2,val)) == (op2 & (int)pow(2,val)))
					res+=pow(2,val);
				val++;
			}
			snprintf(mypad,COMPSTR,"%d",res);
			_datatype=INTEGER;
		}
		if (*p==')') p++;
		return TRUE;
	}
	/* IMP() function
	 * return the IMP result of the two integer numbers/states
	 * passed as arguments */
	else if (!strncasecmp_(p,"IMP(",4)) {
		int op1, op2, isInt=FALSE;
		char sop1[COMPSTR], sop2[COMPSTR], *pb;
		char top1[COMPSTR], top2[COMPSTR];
		int res=0, val=0;
		int lim=0;
		p+=4;
		strncpy_(top1,AS(),COMPSTR);
		pb=p;
		p=top1;
		strncpy_(sop1,AS(),COMPSTR);
		if (!sop1[0]) op1=report;
		else lim=op1=(int)strtod(sop1,NULL), isInt=TRUE;
		report=TRUE;
		p=pb;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			strncpy_(top2,AS(),COMPSTR);
			pb=p;
			p=top2;
			strncpy_(sop2,AS(),COMPSTR);
			if (!sop2[0]) op2=report;
			else op2=(int)strtod(sop2,NULL);
			report=TRUE;
			p=pb;
		}
		if (!isInt) {
			if (op2) report=TRUE;
			else if (!op1 && !op2) report=TRUE;
			else report=FALSE;
			_datatype=STRING;
		}
		else {
			if (op2>lim) lim=op2;
			val=0;
			while (val<32) {
				if ((int)pow(2,val)>lim) break;
				if ((!(op1 & (int)pow(2,val))) || (op2 & (int)pow(2,val)))
					res+=pow(2,val);
				val++;	
			}
			snprintf(mypad,COMPSTR,"%d",res);
			_datatype=INTEGER;
		}
		if (*p==')') p++;
		return TRUE;
	}
	/* LROLL() function
	 * return the left roll of the first integer number
	 * by the positions specified by the second argument 
	 * Thanks to GeeksForGeeks at 
	 * https://www.geeksforgeeks.org/rotate-bits-of-an-integer/ */
	else if (!strncasecmp_(p,"LROLL(",6) || !strncasecmp_(p,"ROL(",4)) {
		int op1, sign=1;
		unsigned int op2;
		if (toupper(*p)=='L') p+=6;
		else p+=4;
		op1=(int)S();
		if (op1<0) op1=-op1, sign=-1;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			op2=(unsigned int)S();
			op2%=32;
		}
		snprintf(mypad,COMPSTR,"%d",sign*((op1<<op2)|(op1>>(INT_BITS-op2))));
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* LSHIFT() function
	 * return the left shift of the first integer number
	 * by the positions specified by the second argument 
	 * (equivalent to a multiplication by 2^op2)*/
	else if (!strncasecmp_(p,"LSHIFT(",7) || !strncasecmp_(p,"SHL(",4)) {
		int op1, sign=1;
		unsigned int op2;
		if (toupper(*p)=='L') p+=7;
		else p+=4;
		op1=(int)S();
		if (op1<0) op1=-op1, sign=-1;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			op2=(unsigned int)S();
			op2%=32;
		}
		snprintf(mypad,COMPSTR,"%d",sign*(op1 << op2));
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* RROLL() function
	 * return the right roll of the first integer number
	 * by the positions specified by the second argument  
	 * Thanks to GeeksForGeeks at 
	 * https://www.geeksforgeeks.org/rotate-bits-of-an-integer/ */
	else if (!strncasecmp_(p,"RROLL(",6) || !strncasecmp_(p,"ROR(",4)) {
		int op1, sign=1;
		unsigned int op2;
		if (toupper(*(p+1))=='R') p+=6;
		else p+=4;
		op1=(int)S();
		if (op1<0) op1=-op1, sign=-1;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			op2=(unsigned int)S();
			op2%=32;
		}
		snprintf(mypad,COMPSTR,"%d",sign*((op1>>op2)|(op1<<(INT_BITS-op2))));
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* RSHIFT() function
	 * return the right shift of the first integer number
	 * by the positions specified by the second argument 
	 * (equivalent to a division by 2^op2)*/
	else if (!strncasecmp_(p,"RSHIFT(",7) || !strncasecmp_(p,"SHR(",4)) {
		int op1, sign=1;
		unsigned int op2;
		if (toupper(*p)=='R') p+=7;
		else p+=4;
		op1=(int)S();
		if (op1<0) op1=-op1, sign=-1;
		if (*p!=',') op2=0;
		else {
			p++; // skip comma
			op2=(unsigned int)S();
			op2%=32;
		}
		snprintf(mypad,COMPSTR,"%d",sign*(op1 >> op2));
		if (*p==')') p++;
		_datatype=INTEGER;
		return TRUE;
	}
	/* EVAL() function
	 * evaluate the argument expression */
	else if (!strncasecmp_(p,"EVAL(",5)) {
		char *pb, op[COMPSTR];
		int state;
		p+=5;
		strncpy_(op,AS(),COMPSTR);
		/* try with a math expression */
		pb=p;
		p=op;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",GP(&state));
		if (*p=='*') {
			char temp[COMPSTR];
			strncat_(temp,deExtParen(op),COMPSTR);
			p=temp;
			strncpy_(mypad,AS(),COMPSTR);
			_datatype=STRING;
		}
		else if (_datatype>REAL && (*p || notAMathExpression)) {
			report=FALSE;
			strncpy_(mypad,VOIDS,COMPSTR);
			_datatype=STRING;
		}
		else {
			if (parseInt(mypad)) _datatype=INTEGER;
			else _datatype=REAL;
		}
		p=pb;
		if (*p==')') p++;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ABEND",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isAbend);
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ABORT",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s","&ABORT");
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ALPHABET",9)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",COMPLETESET);
		_datatype=STRING;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ANCHOR",7)) {
		p+=7;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isAnchored);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ARB",4)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s","&ARB");
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&BAL",4)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s","&BAL");
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&CODE",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",procCode);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&DIGITS",7)) {
		p+=7;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",digits);
		_datatype=STRING;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&DUMP",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isDumping);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ERRLINE",8)) {
		p+=8;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",lErr);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&ERRTYPE",8)) {
		p+=8;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",sErr);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&FAIL",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s","&FAIL");
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&FENCE",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s","&FENCE");
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&FILE",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",filename);
		_datatype=STRING;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&FNCLEVEL",9)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",funcTOS);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&FTRACE",7)) {
		p+=7;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isFtrace);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&FULLSCAN",9)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isFullscan);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&INPUT",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isInput);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&LASTNO",7)) {
		p+=7;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",sLastNo);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&LCASE",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",lcase);
		_datatype=STRING;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&LINESNO",8)) {
		p+=8;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",endCore);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&MAXLNGTH",9)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",COMPSTR);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&MEMLIMIT",9)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",MEMLIMIT);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&OUTPUT",7)) {
		p+=7;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isOutput);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&PARM",5)) {
		p+=5;
		while (isblank(*p)) p++;
		strncpy_(mypad,parm,COMPSTR);
		_datatype=STRING;
		unveil(mypad);
		return TRUE;
	}
	else if (!strncasecmp_(p,"&PI",3)) {
		p+=3;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%.15G",SOFTPI);
		_datatype=REAL;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&REAL",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isNotExponential);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&REM",4)) {
		p+=4;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s","&REM");
		_datatype=PATTERN;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&RTNTYPE",8)) {
		p+=8;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",sReturn);
		_datatype=STRING;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&SPACE",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s"," \t");
		_datatype=STRING;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&STCOUNT",8)) {
		p+=8;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",sStatms);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&STLIMIT",8)) {
		p+=8;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isStLimit);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&STFCOUNT",9)) {
		p+=9;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",sFail);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&STNO",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",l);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&TRACE",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isTrace);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&TRIM",5)) {
		p+=5;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%d",isGTrim);
		_datatype=INTEGER;
		return TRUE;
	}
	else if (!strncasecmp_(p,"&UCASE",6)) {
		p+=6;
		while (isblank(*p)) p++;
		snprintf(mypad,COMPSTR,"%s",ucase);
		_datatype=STRING;
		return TRUE;
	}
	p=pb;
	return FALSE;
}


/* GP()
 * Get Pattern entity for assignment
 * The basic routing for JP() */
char *GP(int *state) {
	char temp[COMPSTR], mypad[COMPSTR], *t, *pb;
	int k;

	mypad[0]='\0';
	while (isblank(*p)) p++;
	if (!*p) {
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	pb=p;

	/* search for a command */
	if (proceed()) {
		*state=STRING;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	else p=pb;

	/* manage literal empty strings */
	if (*p=='\"' && *(p+1)=='\"' && *(p+2)!='\"') {
		p+=2;
		mypad[0]='\0';
		*state=STRING;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	else if (*p=='\'' && *(p+1)=='\'' && *(p+2)!='\'') {
		p+=2;
		mypad[0]='\0';
		*state=STRING;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* manage the &DIGITS keyword */
	else if (!strncasecmp_(p,"&DIGITS",7)) {
		p+=7;
		strncpy_(mypad,digits,COMPSTR);
		*state=STRING;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	else p=pb;



	if (*p==')') {
		mypad[0]=*p++;
		mypad[1]='\0';
		*state=INTEGER;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}

	/* a parenthesized expression is tried, evaluating a math expression
	 * using S() but if not part of math expression it is rejected  */
	if (*p=='(') {
		double val;
		char *pb=p;
		val=S(); // redefines _exprtype
		while (isblank(*p)) p++;
		if (!notAMathExpression && !isop(p)) {
			snprintf(mypad,COMPSTR,"%.15G",val);
			sMaths++; // for Stats
			*state=_exprtype;
			while (isblank(*p)) p++;
			turnToUpper(mypad); // convert e to E
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		/* in case the expression is not a math expression
		 * or it is followed by an operator
		 * use the next numeric clauses */
		p=pb;
	}

	/* a parenthesized expression is tried, evaluating a string expression
	 * using but if not part of a string expression it is rejected  */
	if (*p=='(') {
		char op[COMPSTR];
		char *pb=p;
		int cumstate, sinstate;
		strncpy_(op,VOIDS,COMPSTR);
		p++; // skip paren
		while (*p && *p!=')') {
			while (isblank(*p)) p++;
			strncat_(op,GP(&sinstate),COMPSTR);
			if (cumstate<sinstate) cumstate=sinstate;
		}
		if (*p==')' && cumstate<PATTERN) {
			p++; // skip )
			*state=STRING;
			strncpy_(mypad,op,COMPSTR);
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		/* in case the expression is not a string expression
		 * use the next clauses */
		p=pb;
	}

	/* special deferred evaluation operator on multiple items in GP() */
	if (!strncasecmp_(p,"*(",2)) {
		char *t=mypad;
		int st=0;
		p+=2;
		*t++='*';
		*t++='(';
		while (TRUE) {
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			*t++=*p++;
		}
		if (*p==')') *t++=*p++;
		*t='\0';
		*state=PATTERN;
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}

	/* special deferred evaluation operator on single items GP() */
	if (*p=='*' && (isbeginnamechar(p+1))) {
		char *t=mypad;
		*t++=*p++; // copy *
		while (*p=='$') *t++=*p++;
		while (isnamechar(p)) *t++=*p++;
		*t='\0';
		if (*p=='[' || *p=='(') {
			perror_(__LINE__,9,l);
			report=FALSE;
			*state=STRING;
			strncpy_(GPPAD,VOIDS,COMPSTR);
        		return GPPAD;
		}
		*state=PATTERN;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}

	/* a NAME attribution */
	if (*p=='.' && *(p+1) && !isblank(*(p+1)) && !isdigit(*(p+1))) {
		int ns;
		p++;
		ns=findDEC(p);
		if (ns) {
			p+=_len;
			strncpy_(mypad,vn[ns].name,COMPSTR);
			*state=NAME;
			while (isblank(*p)) p++;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		p=pb;
	}

	/* a REAL introduced by its decimal dot - uses S() */
	if (*p=='.' && *(p+1) && isdigit(*(p+1))) {
		snprintf(mypad,COMPSTR,"%15g",S());
		if (!notAMathExpression) {
			*state=REAL;
			while (isblank(*p)) p++;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		p=pb;
	}

	/* a numeric keyword may introduce a math expression - uses S() */
	if (*p=='&' && isnamechar(p+1)) {
		double val;
		val=S();
		/* it was a wrong keyword */
		if (!notAMathExpression) {
			snprintf(mypad,COMPSTR,"%.15G",val);
			*state=_exprtype;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		p=pb;
	}
	/* an array is taken and stored
	 * possible expression following */
	if (isarrvar(p) && !isUniEvalFunc(p) && *p!='$') {
		char *pb=p;
		int ns, val[MAXDIM+1];
		int T=1, allGood=TRUE;
		ns=searchDEC(p,decCount);
		if (!ns) allGood=FALSE;
		else p+=_len;
		if (*p!='[') {
			*state=ARRAY;
			snprintf(mypad,COMPSTR,"%d",ns);
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		else p++; // skip [
		ns=vn[ns].ref;
		val[T]=(int)S();
		if (val[T]<vn[ns].offset[T] || val[T]>(vn[ns].ldim[T]+vn[ns].offset[T])) {
			sErr=57;
			lErr=l;
			report=FALSE;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		while (*p==',') {
			p++; T++;
			if (T>vn[ns].dim) perror_(__LINE__,30,l);
			val[T]=(int)S();
			if (val[T]<vn[ns].offset[T] || val[T]>(vn[ns].ldim[T]+vn[ns].offset[T])) {
				sErr=57;
				lErr=l;
				report=FALSE;
				strncpy_(GPPAD,mypad,COMPSTR);
        			return GPPAD;
			}
		}
		if (*p==']') p++;
		else allGood=FALSE;
		while (isblank(*p)) p++;
		if (allGood && !isop(p)) {
			strncpy_(mypad,getArrayStr(ns,vn[ns].dim,val),COMPSTR);
			*state=getArrayVal(ns,vn[ns].dim,val);
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		/* possible expression following */
		else if (isop(p) && isblank(*(p+1))) {
			double val;
			p=pb;
			val=S();
			if (!notAMathExpression) {
				snprintf(mypad,COMPSTR,"%.15G",val);
				*state=_exprtype;
				strncpy_(GPPAD,mypad,COMPSTR);
        			return GPPAD;
			}
		}
		p=pb;
	}

	/* a number in digits is taken and stored without using S()
	 * because it is not a math expression but only a value
	 * POSSIBLE EXPRESSION FOLLOWING */
	if (isnm(p) && !isUniEvalFunc(p) && *p!='$') {
		char *v=mypad, *pb=p;
		while (*p && isflot(p)) *v++=*p++;
		*v='\0';
		while (isblank(*p)) p++;
		strtod(mypad,&v);
		if (!*v && !isop(p)) {
			if (parseInt(mypad)) *state=INTEGER;
			else *state=REAL;
			while (isblank(*p)) p++;
			/* possible expression following */
			if (isop(p) && isblank(*(p+1))) {
				double val;
				p=pb;
				val=S();
				if (!notAMathExpression) {
					snprintf(mypad,COMPSTR,"%.15G",val);
					*state=_exprtype;
					strncpy_(GPPAD,mypad,COMPSTR);
			        	return GPPAD;
				}
			}
			else {
				strncpy_(GPPAD,mypad,COMPSTR);
        			return GPPAD;
			}
		}
		/* in case the string is not entirely consumed
		 * or it is followed by an operator,
		 * use the next numeric clause */
		p=pb;
	}

	/* a number contained into a variable
	 * must be returned as its string part
	 * POSSIBLE EXPRESSION FOLLOWING */
	if (isnumvar(p) && !isUniEvalFunc(p) && *p!='$') {
		int ns;
		char temp[COMPSTR], *v=temp, *pb=p;
		while (isnamechar(p)) *v++=*p++;
		*v='\0';
		while (isblank(*p)) p++;
		ns=searchDEC(temp,decCount);
		if (ns && vn[ns].datatype<STRING && !isop(p) && *p!='(') {
			strncpy_(mypad,vn[ns].str,COMPSTR);
			*state=vn[ns].datatype;
			while (isblank(*p)) p++;
			/* possible expression following */
			if (isop(p) && isblank(*(p+1))) {
				double val;
				p=pb;
				val=S();
				if (!notAMathExpression) {
					snprintf(mypad,COMPSTR,"%.15G",val);
					*state=_exprtype;
					strncpy_(GPPAD,mypad,COMPSTR);
        				return GPPAD;
				}
			}
			else {
				strncpy_(GPPAD,mypad,COMPSTR);
        			return GPPAD;
			}
		}
		else if (ns && vn[ns].datatype==STRING && !vn[ns].str[0] && !isop(p) && *p!='(') {
			strncpy_(mypad,vn[ns].str,COMPSTR);
			*state=vn[ns].datatype;
			while (isblank(*p)) p++;
			/* possible expression following */
			if (isop(p) && isblank(*(p+1))) {
				double val;
				p=pb;
				val=S();
				if (!notAMathExpression) {
					snprintf(mypad,COMPSTR,"%.15G",val);
					*state=_exprtype;
					strncpy_(GPPAD,mypad,COMPSTR);
			        	return GPPAD;
				}
			}
			else {
				strncpy_(GPPAD,mypad,COMPSTR);
        			return GPPAD;
			}
		}
		/* in case the variable is not a numeric variable
		 * or it is followed by an operator,
		 * use the next numeric clause */
		p=pb;
	}

	/* a number in string form enclosed in quotes
	 * must be retained as string as-is
	 * POSSIBLE EXPRESSION FOLLOWING */
	if (isnumstr(p) && !isUniEvalFunc(p) && *p!='$') {
		char *v=mypad;
		char q=*p++; // skip quote
		while (*p && *p!=q) *v++=*p++;
		*v='\0';
		if (*p==q) p++;
		else perror_(__LINE__,21,l);
		while (isblank(*p)) p++;
		strtod(mypad,&v);
		if (!*v) {
			if (parseInt(mypad)) *state=INTEGER;
			else *state=REAL;
		}
		else *state=STRING;
		/* possible expression following */
		if (isop(p) && isblank(*(p+1))) {
			double val;
			p=pb;
			val=S();
			if (!notAMathExpression) {
				snprintf(mypad,COMPSTR,"%.15G",val);
				*state=_exprtype;
				strncpy_(GPPAD,mypad,COMPSTR);
        			return GPPAD;
			}
			else p=pb;
		}
		else {
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
	}

	/* numeric expression - uses S() */
	if ((isdigit(*p) || isnumvar(p) || isnumstr(p) || *p=='-' || *p=='+' || *p=='(' || isnumfun(p)) && !isUniEvalFunc(p)) {
		double val=0;
		char *pb=p;
		val=S(); // redefines _exprtype
		if (!notAMathExpression) {
			sMaths++; // for Stats
			snprintf(mypad,COMPSTR,"%.15G",val);
			*state=_exprtype;
			turnToUpper(mypad); // convert e to E
			while (isblank(*p)) p++;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		/* in case it is not a number
		 * use the next clauses */
		p=pb;
	}

	/* case of a flag function */
	if (flag()) {
		notAMathExpression=TRUE;
		*state=INTEGER;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}

	/* case of a string or a string function */
	if (string(mypad)) {
		*state=_datatype;
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}

	/* in case of =, it's a pattern: copy until the end or until :*/
	if (*p=='=') {
		t=temp;
		while (*p && *p!=':') *t++=*p++;
		*t='\0';
		strncpy_(mypad,temp,COMPSTR);
		*state=INTEGER; // this must not influence the rest
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* in case of :, it's a goto section: copy until the end */
	if (*p==':') {
		t=temp;
		while (*p) *t++=*p++;
		*t='\0';
		strncpy_(mypad,temp,COMPSTR);
		*state=INTEGER; // this must not influence the rest
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* special operators out of a math expression */
	if (*p=='*' && *(p+1)=='*') {
		mypad[0]=*p++;
		mypad[1]=*p++;
		mypad[2]='\0';
		*state=PATTERN;
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* operator out of a math expression */
	if (isop(p)) {
		mypad[0]=*p++;
		mypad[1]='\0';
		*state=PATTERN;
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* parenthesis opened or closed or alternator operator*/
	if (*p=='(' || *p==')') {
		mypad[0]=*p++;
		mypad[1]='\0';
		/* Note: INTEGER here because it cannot influence a
		 * math or string expression enclosed in parenthesis */
		*state=PATTERN;
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* parenthesis opened or closed or alternator operator*/
	if (*p=='|') {
		mypad[0]=*p++;
		mypad[1]='\0';
		/* Note: INTEGER here because it cannot influence a
		 * math or string expression enclosed in parenthesis */
		*state=PATTERN;
		while (isblank(*p)) p++;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* assignment operators GP() */
	if ((*p=='.' || *p=='$') && isblank(*(p+1))) {
		char *n=mypad;
		*n++=*p++; // copy symbol
		/* intercept possible errors */
		while (*p && isblank(*p)) *n++=*p++;
		while (*p && !isblank(*p)) *n++=*p++;
		*n='\0';
		*state=PATTERN;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* cursor operator */
	if ((*p=='@') && !isblank(*(p+1))) {
		char *n=mypad;
		*n++=*p++; // copy symbol
		while (*p && !isblank(*p)) *n++=*p++;
		*n='\0';
		*state=PATTERN;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* improper usage of @ */
	else if ((*p=='@') && isblank(*(p+1))) {
		perror_(__LINE__,18,l);
	}
	/* variable */
	else if ((k=searchDEC(p,decCount)) && isterm(p+_len)) {
		if (vn[k].datatype>CODE) {
			sErr=92;
			lErr=l;
			report=FALSE;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		strncpy_(mypad,vn[k].str,COMPSTR);
		*state=vn[k].datatype;
		strncpy_(GPPAD,mypad,COMPSTR);
        	return GPPAD;
	}
	/* unrecognized */
	else if (isalpha(*p) && !ispatfun(p)) {
		perror_(__LINE__,24,l);
	}
	/* copy without caring
	 * NOTE: IMPORTANT: this catch-all part must be put in the end
	 * and without any check (else void part) */
	t=temp;
	while (isnamechar(p)) *t++=*p++;
	*t='\0';
	if (*p=='(') {
		int st=0;
		*t++=*p++; // copy and skip (
		*t='\0';
		while (*p) {
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			*t++=*p++;
		}
		if (*p==')') *t++=*p++;
		*t='\0';
		strncpy_(temp,unveil(temp),COMPSTR);
	}
	strncpy_(mypad,temp,COMPSTR);
	if (!mypad[0]) *state=STRING;
	else *state=PATTERN;
	while (isblank(*p)) p++;
	strncpy_(GPPAD,mypad,COMPSTR);
       	return GPPAD;
} // end of GP()


/* JP()
 * the wrapper for GP() to group consecutive strings/patterns into one
 * as prescribed by SNOBOL4 conventions */
char *JP(int *state) {
	char mypad[COMPSTR],mypads[PATPAD][COMPSTR],temp[COMPSTR];
	int mystates[PATPAD];
	int is=0, was=0, co=0, k;

	mypad[0]='\0';
	for (k=0;k<PATPAD;k++) mypads[k][0]='\0';
	while (isblank(*p)) p++;

	/* GATHER ELEMENTS */
	k=0;
	while (*p && *p!=':' && *p!='=' && report) {
		strncpy_(temp,GP(&is),COMPSTR);
		if (was<is) was=is;
		strncpy_(mypads[k],temp,COMPSTR);
		mystates[k]=is;
		while (isblank(*p)) p++;
		k++;
		if (k>=PATPAD) {
			sErr=89;
			lErr=l;
			report=FALSE;
			return VOIDS;
		}
	}

	/* short-circuit for failure */
	if (!report || !rightPos) {
		*state=0;
		return VOIDS;
	}

	/* ASSEMBLE PATTERNS */
	if (was==PATTERN) {
		strncat_(mypad,"(",COMPSTR);
		while (co<k) {
			if (mystates[co]==PATTERN) {
				strncat_(mypad,mypads[co],COMPSTR);
			}
			else if (mystates[co]==STRING && strchr(mypads[co],'\'')) {
				strncat_(mypad,"\"",COMPSTR);
				strncat_(mypad,mypads[co],COMPSTR);
				strncat_(mypad,"\"",COMPSTR);
			}
			else if (mystates[co]==STRING) {
				strncat_(mypad,"\'",COMPSTR);
				strncat_(mypad,mypads[co],COMPSTR);
				strncat_(mypad,"\'",COMPSTR);
			}
			else strncat_(mypad,mypads[co],COMPSTR);
			strncat_(mypad," ",COMPSTR);
			co++;
		}
		strncat_(mypad,")",COMPSTR);
	}
	/* ASSEMBLE STRINGS and STRING-LIKE elements */
	else {
		while (co<k) {
			strncat_(mypad,mypads[co],COMPSTR);
			co++;
		}
	}

	/* SET VALUES FOR RETURN */
	*state=was;
#if 0
	/* try to evaluate a math expression */
	if (*state>REAL) {
		char *pb=p;
		double num;
		p=mypad;
		num=S();
		if (!*p) {
			snprintf(mypad,COMPSTR,"%.15G",num);
			if (parseInt(mypad)) *state=INTEGER;
			else *state=REAL;
		}
		p=pb;
	}
#endif
	strncpy_(JPPAD,mypad,COMPSTR);
       	return JPPAD;
} // end of JP()


/* GS() - gather Strings for scanner
 * the wrapper for scanner() to group consecutive strings into one
 * as prescribed by SNOBOL4 conventions */
char *GS(void) {
	char mypad[COMPSTR], temp[COMPSTR];
	strncpy_(temp,SS(),COMPSTR);
	while (TRUE) {
		int vs;
		if (isquote(p))
			strncat_(temp,SS(),COMPSTR);
		else if (isdigit(*p))
			strncat_(temp,SS(),COMPSTR);
		else if (*p=='$' && !isblank(*(p+1)))
			strncat_(temp,SS(),COMPSTR);
		else if (*p=='*' && !isblank(*(p+1)))
			strncat_(temp,SS(),COMPSTR);
		else if (*p=='.' && isdigit(*(p+1)))
			strncat_(temp,SS(),COMPSTR);
		else if ((vs=findDEC(p)) && vn[vs].datatype<=STRING) {
			strncat_(temp,SS(),COMPSTR);
		}
		else break;
	}
	strncpy_(mypad,temp,COMPSTR);
	strncpy_(GSPAD,mypad,COMPSTR);
       	return GSPAD;
}


/* AS() - Join Strings without updating scan
 * the wrapper for SS() to group consecutive strings into one
 * as prescribed by SNOBOL4 conventions and for checking
 * the living update of the match */
char *AS(void) {
	char mypad[COMPSTR], temp[COMPSTR];

	mypad[0]='\0';
	//strncpy_(mypad,VOIDS,COMPSTR);
	while (isblank(*p)) p++;

	/* cycle through strings */
	while (*p) {
		if (*p==')' || *p==',' || *p=='[' || *p==']' || *p=='=' || *p==':' || *p=='|') break;
		strncpy_(temp,SS(),COMPSTR);
		while (isblank(*p)) p++;
		strncat_(mypad,temp,COMPSTR);
	}
	strncpy_(ASPAD,mypad,COMPSTR);
        return ASPAD;
} // end of AS()


/* dropAlt()
 * skip n items of the alternation in argument pat
 * return the updated p position or NULL if there is no
 * other alternation item in the queue*/
char *dropAlt(int n) {
	char temp[COMPSTR];
	int i=1, status;
	while (i<=n) {
		while (isblank(*p)) p++;
		strncpy_(temp,GP(&status),COMPSTR);
		while (isblank(*p)) p++;
		if (*p=='|') p++;
		else return NULL;
		i++;
	}
	while (isblank(*p)) p++;
	return p;
}


/* alt_scan()
 * the main scanning procedure for the ARBNO evaluation
 * first is the base string passed
 * pat is the ARBNO argument, with all variables unveiled
 * Return the final pattern for scanner()
 * written by Antonio Maschio - May 2021 */
char *alt_scan(char *first, char *pat) {
	char *next[MAXARGS+1], lastmatch[COMPSTR], match[COMPSTR], *mm;
	int nextscan[MAXARGS+1], nextTOS=0;
	int nextParOrder[MAXARGS], nextDotTOS[MAXARGS];
	int sarOrder=0, tot=0, b1scan=bscan;
	int isQuit=FALSE, i, uscan=scan, usarOrder=0, dotTOS=0, udotTOS=0;
	char pattern[COMPSTR], upattern[COMPSTR], *up=p;
	char parNext[MAXARGS+1][COMPSTR];

	/* initialize */
	for (i=0;i<MAXARGS; i++) {
		next[i]=NULL, nextscan[i]=nextParOrder[i]=nextDotTOS[i]=0;
	}
	strncpy_(pattern,VOIDS,COMPSTR);

	/* the alternation scanning process */
	p=pat;
	while (*p && !isQuit) {	// Note: local isQuit is necessary
		int myuscan=scan, myudotTOS=0, myusarOrder;
		char *myup=pat, myupattern[COMPSTR];
		rightPos=TRUE;
		myuscan=scan;
		myusarOrder=sarOrder;
		myudotTOS=dotTOS;
		strncpy_(myupattern,pattern,COMPSTR);
		while (isblank(*p)) p++;
		if (*p=='(') {
			p++; // skip (
			while (isblank(*p)) p++;
			sarOrder++;
			if (sarOrder<PSTACK)
				strncpy_(parNext[sarOrder],VOIDS,COMPSTR);
			else sarOrder=PSTACK-1;
			continue;
		}
		if (*p==')') {
			p++; // skip )
			while (isblank(*p)) p++;
			while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
					(*p=='@' && !isblank(*(p+1)))) {
				if (*p=='$') evalDollar(parNext[sarOrder]);
				else if (*p=='.') {
					evalDot(parNext[sarOrder]);
				}
				else if (*p=='@') evalAt();
				while (isblank(*p)) p++;
			}
			if (sarOrder>0) sarOrder--;
			continue;
		}
		while (isblank(*p)) p++;
		if (*p=='@') evalAt();
		while (isblank(*p)) p++;
		myup=p;
		strncpy_(match,SS(),COMPSTR);
		mm=strstr_((first+scan),match);

		/* MATCH! */
		if (mm) {
			int i;
			/* set up match-yes variables */
			uscan=myuscan;
			usarOrder=myusarOrder;
			up=myup;
			udotTOS=myudotTOS;
			strncpy_(upattern,myupattern,COMPSTR);
			scan+=strlen(match);
			strncat_(pattern,match,COMPSTR);
			/* set up parenthesis arrays */
			for (i=1;i<=sarOrder;i++) {
				strncat_(parNext[i],match,COMPSTR);
			}
			/* indirect assignment */
			while (isblank(*p)) p++;
			strncpy_(lastmatch,match,COMPSTR);
			/* store data of next alternation for possible
			 * future usage */
			if (*p=='|') {
				char *pp=p+1;
				while (isblank(*pp)) pp++;
				next[nextTOS]=pp;
				nextscan[nextTOS]=uscan;
				nextDotTOS[nextTOS]=dotTOS;
				nextParOrder[nextTOS]=sarOrder;
				skipAlt();
				nextTOS++;
				if (nextTOS>=MAXARGS) {
					rightPos=FALSE;
					break;
				}
			}
			else {
				next[nextTOS]=NULL;
			}

			while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
					(*p=='@' && !isblank(*(p+1)))) {
				if (*p=='$') evalDollar(match);
				if (*p=='.') evalDot(match);
				if (*p=='@') evalAt();
				while (isblank(*p)) p++;
			}
			/* case of end of request string */
			if (!*p || *p==':' || *p=='=') {
				sMatches++;
				break;
			}
		}
		/* NO MATCH! */
		else {
			nextTOS--;
			if (nextTOS<0) nextTOS=0;
			while (isblank(*p)) p++;
			if (*p=='|') {
				p++; // skip |
				while (isblank(*p)) p++;
				nextTOS++;
				if (nextTOS>=MAXARGS) {
					rightPos=FALSE;
					break;
				}
				next[nextTOS]=p;
				nextscan[nextTOS]=uscan;
				nextParOrder[nextTOS]=sarOrder;
				nextDotTOS[nextTOS]=dotTOS;
			}
			else if (findNext(p)) {
				nextTOS++;
				if (nextTOS>=MAXARGS) {
					rightPos=FALSE;
					break;
				}
				if (!next[nextTOS]) {
					char *pp=findNext(p)+1;
					while (isblank(*pp)) pp++;
					next[nextTOS]=pp;
					nextParOrder[nextTOS]=sarOrder;
					nextscan[nextTOS]=uscan;
					nextDotTOS[nextTOS]=dotTOS;
				}
			}
			else {
				int i,len, sl=strlen(lastmatch);
				len=(int)(strlen(pattern)-sl);
				if (len<0) len=0;
				strncpy_(pattern,pattern,len+1);
				for (i=0;i<=MAXARGS;i++) {
					len=(int)(strlen(parNext[i])-sl);
					if (len<0) len=0;
					strncpy_(parNext[i],parNext[i],len+1);
				}
			}
			if (next[nextTOS]) {
				p=next[nextTOS];
				scan=nextscan[nextTOS];
				dotTOS=nextDotTOS[nextTOS];
				sarOrder=nextParOrder[nextTOS];
				next[nextTOS]=NULL;
				continue;
			}
			/* normal case:
			 * set for a match in a further position */
			else if (!tot) {
				b1scan++;
				scan=b1scan;
				if (uscan<scan) uscan=scan;
				p=pat;
				dotTOS=0;
				next[nextTOS]=NULL;
				for (i=0;i<=sarOrder;i++) {
					strncpy_(parNext[i],VOIDS,COMPSTR);
				}
			}
			/* rematch case:
			 * regain position after last match */
			else {
				int i;
				scan=uscan;
				for (i=usarOrder+1;i<=sarOrder;i++) {
					strncpy_(parNext[i],VOIDS,COMPSTR);
				}
				sarOrder=usarOrder;
				p=up;
				dotTOS=udotTOS;
				strncpy_(pattern,upattern,COMPSTR);
				next[nextTOS]=NULL;
			}
			if (scan>strlen(first)) rightPos=FALSE;
			if (!rightPos) break;
			tot=0;
		}
	}
	strncpy_(ASCNPAD,pattern,COMPSTR);
        return ASCNPAD;
} // end of alt_scan()


/* SS() - String Selector
 * The PARSER for strings expression for the pattern evaluation;
 * it's a general routine that parses also other functions.
 * The address of starting position into the flow stream is pointed to by p */
char *SS(void) {
	char mypad[COMPSTR], *pb;
	double val;

	/* setup starting variables */
	argtype=0;
	strncpy_(argparam,VOIDS,COMPSTR);
	strncpy_(mypad,VOIDS,COMPSTR);
	while (isblank(*p)) p++;
	if (!*p) {
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	pb=p;

	/* evaluate the parenthesis */
	if (*p=='(') {
		p++; // skip (
		while (isblank(*p)) p++;
		parOrder++;
		if (parOrder<=PSTACK)
			parNext[parOrder][0]='\0';
		else perror_(__LINE__,89,l);
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	else if (*p==')') {
		p++; // skip )
		while (isblank(*p)) p++;
		evalDollar(parNext[parOrder]);
		evalDot(parNext[parOrder]);
		evalAt();
		parOrder--;
		if (parOrder<0) parOrder=0;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}

	/* a NAME attribution */
	if (*p=='.' && *(p+1) && !isblank(*(p+1)) && !isdigit(*(p+1))) {
		int ns;
		p++;
		ns=findDEC(p);
		if (ns) {
			p+=_len;
			strncpy_(mypad,vn[ns].name,COMPSTR);
			_datatype=NAME;
			while (isblank(*p)) p++;
			strncpy_(SSPAD,mypad,COMPSTR);
        		return SSPAD;
		}
		p=pb;
	}

	/* a REAL introduced by its decimal dot */
	if (*p=='.' && *(p+1) && isdigit(*(p+1))) {
		snprintf(mypad,COMPSTR,"%15g",S());
		if (!notAMathExpression) {
			_datatype=REAL;
			while (isblank(*p)) p++;
			strncpy_(GPPAD,mypad,COMPSTR);
        		return GPPAD;
		}
		p=pb;
	}

	/* detect the wrong position of @ */
	if (*p=='@' && isblank(*(p+1))) {
		perror_(__LINE__,18,l);
	}

	/* deferred evaluation on multiple items performed in SS() */
	if (!strncasecmp_(p,"*(",2)) {
		int st=0;
		char temp[COMPSTR], *t=temp, *pb;
		p+=2;
		while (isblank(*p)) p++;
		while (*p) {
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			*t++=*p++;
		}
		*t='\0';
		pb=p;
		p=temp;
		/* try if it is a math expression */
		snprintf(mypad,COMPSTR,"%.15G",S());
		if (*p || notAMathExpression) {
			p=temp;
			strncpy_(mypad,AS(),COMPSTR);
			_datatype=STRING;
		}
		else {
			if (parseInt(mypad)) _datatype=INTEGER;
			else _datatype=REAL;
		}
		p=pb;
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* deferred evaluation performed in SS() */
	if (*p=='*' && (isbeginnamechar(p+1))) {
		char temp[COMPSTR], *t=temp;
		int ns;
		p++; // skip *
		*t='\0';
		while (*p=='$') *t++=*p++;
		while (isnamechar(p)) *t++=*p++;
		*t='\0';
		/* TODO maybe !temp[0] needs a different error message */
		if (!temp[0] || *p=='[' || *p=='(') {
			sErr=9;
			lErr=l;
			report=FALSE;
			strncpy_(SSPAD,VOIDS,COMPSTR);
        		return SSPAD;
		}
		ns=searchDEC(temp,decCount);
		_datatype=STRING;
		if (ns) {
			if(vn[ns].datatype<=CODE) {
				strncpy_(mypad,vn[ns].str,COMPSTR);
				_datatype=vn[ns].datatype;
			}
			else {
				sErr=9;
				lErr=l;
				report=FALSE;
				strncpy_(SSPAD,VOIDS,COMPSTR);
        			return SSPAD;
			}
		}
		else perror_(__LINE__,66,l);
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}

	/* REM predefined variable engine
	 * return a string that is the remainder of the base string
	 * starting from scan */
	if (!strncasecmp_(p,"&REM",4) && ispat(p+4)) {
		p+=4;
		strncpy_(mypad,CFIRST,COMPSTR);
		_datatype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* FAIL predefined variable engine
	 * return a void string and make fail any further match,
	 * causing backtracking in the same clause
	 * Note: parameters are updated into patterns() */
	if (!strncasecmp_(p,"&FAIL",5) && ispat(p+5)) {
		p+=5;
		while (isblank(*p)) p++;
		rightPos=FALSE;
		strncpy_(mypad,VOIDS,COMPSTR);
		_datatype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* ABORT predefined variable engine
	 * return a void string and make fail any further match */
	if (!strncasecmp_(p,"&ABORT",6) && ispat(p+6)) {
		p+=6;
		while (isblank(*p)) p++;
		report=FALSE;
		strncpy_(mypad,VOIDS,COMPSTR);
		_datatype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* FENCE predefined variable engine
	 * return a void string and make fail any further match
	 * if scan passes back the limit set by FENCE*/
	if (!strncasecmp_(p,"&FENCE",6) && ispat(p+6)) {
		if (!fenceNeedle) {
			fenceNeedle=p;
		}
		p+=6;
		while (isblank(*p)) p++;
		strncpy_(mypad,VOIDS,COMPSTR);
		_datatype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* ARB predefined variable engine
	 * return an arbitrary string, equivalent to repeated instances
	 * of LEN(1)  */
	if (!strncasecmp_(p,"&ARB",4) && ispat(p+4)) {
		int j, index=(int)(p-second);
		char *t=mypad;
		resTOS++;
		if (resTOS>MAXARGS)
			perror_(__LINE__,89,l);
		resat[resTOS]=scan;
		dresat[resTOS]=dotTOS;
		presat[resTOS]=p;
		strncpy_(patresat[resTOS],upattern,COMPSTR);
		p+=4; // skip ARB
		while (isblank(*p)) p++;
		if (index<0 || index>=COMPSTR) {
			strncpy_(SSPAD,mypad,COMPSTR);
        		return SSPAD;
		}
		if (use[index]<0) use[index]=0;
		/* first case matches always the empty string */
		if (!use[index]) {
			tot=1;
			use[index]++;
		}
		else if (use[index]>strlen(CFIRST)) {
			tot=0;
			use[index]=0;
			resat[resTOS]=0;
			dresat[resTOS]=0;
			presat[resTOS]=NULL;
			resTOS--;
			if (resTOS<0) resTOS=0;
			rightPos=FALSE;
		}
		else {
			tot=1;
			for (j=0;j<use[index];j++) {
				*t++=*(CFIRST+j);
			}
			use[index]++;
		}
		*t='\0';
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* BAL predefined variable engine
	 * return an arbitrary string, equivalent to repeated instances
	 * of a single charactere or the whole content
	 * between two matching open/close parentheses */
	if (!strncasecmp_(p,"&BAL",4) && ispat(p+4)) {
		int j, index=(int)(p-second);
		char *t=mypad;
		p+=4; // skip BAL
		while (isblank(*p)) p++;
		if (index<0 || index>=COMPSTR) {
			strncpy_(SSPAD,mypad,COMPSTR);
        		return SSPAD;
		}
		if (use[index]<1) use[index]=1;
		if (use[index]>strlen(CFIRST)) {
			tot=0;
			rightPos=FALSE;
			use[index]=1;
		}
		else {
			char *w=CFIRST;
			tot=1;
			for (j=0;j<use[index];j++) {
				/* case of closed parenthesis */
				if (*w==')') {
					rightPos=FALSE;
					tot=0;
					use[index]=-1;
					break;
				}
				/* case of open parenthesis that causes
				 * the whole string to be taken */
				else if (*w=='(') {
					int st=0;
					*t++=*w++; // copy (
					while (*w) {
						if (*w=='(') st++;
						else if (*w==')' && st) st--;
						else if (*w==')' && !st) break;
						*t++=*w++; // copy inside
					}
					/* unpaired */
					if (!*w) {
						strncpy_(mypad,VOIDS,COMPSTR);
						rightPos=FALSE;
						tot=0;
						break;
					}
					else *t++=*w++; // copy )
				}
				/* case of the single carachter */
				else *t++=*w++; // copy inside
			}
			use[index]++;
		}
		*t='\0';
		if (!mypad[0] && scan>=strlen(FIRST)) rightPos=FALSE;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}

	/* search for a command or for an implicit assignment &<VAL> = <set> */
	if (proceed()) {
		_datatype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	else p=pb;

	/* search for a flag function */
	if (flag()) {
		_datatype=INTEGER;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	else p=pb;

	/* search for a string function or variable */
	if (string(mypad)) {
		while (isblank(*p)) p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	else p=pb;

	/* set default datatype for all following functions */
	_datatype=STRING;

	/* NOTANY string function
	 * return the first available character which is not found
	 * in the argument queue */
	if (!strncasecmp_(p,"NOTANY(",7)) {
		char c, neg[COMPSTR];
		char *j=COMPLETESET;
		int i=0;
		p+=7; // skip NOTANY(
		/* copy negative pattern string */
		strncpy_(neg,AS(),COMPSTR);
		if (*p==')') p++;
		if (!neg[0]) perror_(__LINE__,94,l);
		/* store the set as difference with the complete set */
		while (*j) {
			if (!strchr(neg,*j))
				argparam[i++]=*j;
			j++;
		}
		argparam[i]='\0';
		/* start search */
		c=*CFIRST;
		if (scan>=strlen(FIRST)) {
			report=FALSE;
		}
		else if (!strchr(argparam,c)) {
			mypad[0]='\0';
			rightPos=FALSE;
		}
		else {
			mypad[0]=c;
			mypad[1]='\0';
		}
		argtype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* ANY string function
	 * \return the first available character which is found
	 * in the argument queue */
	else if (!strncasecmp_(p,"ANY(",4)) {
		char c;
		p+=4; // skip ANY(
		/* copy pattern string */
		strncpy_(argparam,AS(),COMPSTR);
		if (*p==')') p++;
		if (!argparam[0]) perror_(__LINE__,94,l);
		/* start search */
		c=*CFIRST;
		if (scan>=strlen(FIRST)) {
			report=FALSE;
		}
		else if (!strchr(argparam,c)) {
			mypad[0]='\0';
			rightPos=FALSE;
		}
		else {
			mypad[0]=c;
			mypad[1]='\0';
		}
		argtype=STRING;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* TAB string function
	 * return a string based on matching the character position;
	 * the match proceeds from left, the number argument counts
	 * from the start of string */
	else if (!strncasecmp_(p,"TAB(",4)) {
		char *mm, *v;
		int tab=0;
		p+=4;
		strncpy_(argparam,AS(),COMPSTR);
		argtype=INTEGER;
		tab=strtol(argparam,NULL,10);
		snprintf(argparam,COMPSTR,"%d",tab);
		if (tab<0 || tab>=COMPSTR) perror_(__LINE__,16,l);
		if (tab<scan || tab>strlen(FIRST)) {
			rightPos=FALSE;
		}
		else {
			tab=tab-scan;
			v=CFIRST;
			mm=mypad;
			while (*v && tab>0) {
				*mm++=*v++;
				tab--;
			}
			*mm='\0';
		}
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;

	}
	/* RTAB string function
	 * return a string based on matching the character position
	 * the match proceed from left, the number argument exclude
	 * the characteres counting from the end of string */
	else if (!strncasecmp_(p,"RTAB(",5)) {
		char *mm, *v;
		int rtab=0;
		p+=5;
		strncpy_(argparam,AS(),COMPSTR);
		argtype=INTEGER;
		rtab=strtol(argparam,NULL,10);
		snprintf(argparam,COMPSTR,"%d",rtab);
		if (rtab<0 || rtab>=COMPSTR) perror_(__LINE__,16,l);
		rtab=strlen(FIRST)-rtab;
		if (rtab<scan) {
			rightPos=FALSE;
		}
		else {
			v=CFIRST;
			mm=mypad;
			while (*v && rtab>scan) {
				*mm++=*v++;
				rtab--;
			}
			*mm='\0';
		}
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* SPAN string function
	 * return a string composed solely of characters belonging
	 * to the argument string, matching FIRST */
	else if (!strncasecmp_(p,"SPAN(",5)) {
		char *mm=mypad, *f=CFIRST;
		char arg[COMPSTR];
		p+=5;
		strncpy_(arg,AS(),COMPSTR);
		strncpy_(argparam,arg,COMPSTR);
		if (!argparam[0]) perror_(__LINE__,94,l);
		argtype=STRING;
		/* collect all useful characters */
		while (*f && strchr(arg,*f)) *mm++=*f++;
		*mm='\0';
		/* SPAN can never match the null string */
		if (!mypad[0]) rightPos=FALSE;
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* BREAK string function
	 * return a string composed solely of characters not belonging
	 * to the argument string, matching FIRST */
	else if (!strncasecmp_(p,"BREAK(",6)) {
		char *mm=mypad, *f=FIRST+scan;
		char arg[COMPSTR];
		p+=6;
		strncpy_(arg,AS(),COMPSTR);
		strncpy_(argparam,arg,COMPSTR);
		if (!argparam[0]) perror_(__LINE__,94,l);
		argtype=STRING;
		/* collect all characters not belonging to the set */
		while (*f && !strchr(arg,*f)) *mm++=*f++;
		*mm='\0';
		/* The match of BREAK must always be followed by a character
		 * of the base string which belogs to arg */
		if (!(*f && strchr(arg,*f))) rightPos=FALSE;
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* LEN() function
	 * return a fixed number of characters as from the number in CFIRST */
	else if (!strncasecmp_(p,"LEN(",4)) {
		char *mm, *v;
		int thislen=0;
		p+=4;
		/* get length of match */
		strncpy_(argparam,AS(),COMPSTR);
		thislen=strtol(argparam,NULL,10);
		if (thislen<0 || thislen>=COMPSTR) perror_(__LINE__,16,l);
		snprintf(argparam,COMPSTR,"%d",thislen);
		argtype=INTEGER;
		/* check if any match is possible */
		if (thislen>strlen(CFIRST)) rightPos=FALSE; // OK
		/* get the right string chunk */
		else {
			v=CFIRST;
			mm=mypad;
			while (*v && thislen>0) {
				*mm++=*v++;
				thislen--;
			}
			*mm='\0';
		}
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* ARBNO string function
	 * return an arbitrary string, equivalent to repeated instances
	 * of the pattern argument
	 * Note: uses a simplified version of scanner hardwired into the code */
	else if (!strncasecmp_(p,"ARBNO(",6)) {
		int index=(int)(p-second), st=0, dscan=scan;
		char pat[COMPSTR], *pt=pat, *pb;
		resTOS++;
		if (resTOS>MAXARGS)
			perror_(__LINE__,89,l);
		resat[resTOS]=scan;
		dresat[resTOS]=dotTOS;
		presat[resTOS]=p;
		strncpy_(patresat[resTOS],upattern,COMPSTR);
		p+=6; // skip ARBNO
		/* get pattern */
		while (*p) {
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			*pt++=*p++;
		}
		*pt='\0';
		if (!pat[0]) {
			sErr=87;
			lErr=l;
			report=FALSE;
			strncpy_(SSPAD,mypad,COMPSTR);
        		return SSPAD;
		}
		if (*p==')') p++;
		while (isblank(*p)) p++;
		pb=p;
		/* check registers */
		if (index<0 || index>=COMPSTR) {
			strncpy_(SSPAD,mypad,COMPSTR);
        		return SSPAD;
		}
		if (use[index]<0) use[index]=0;
		/* first case matches always the empty string */
		if (!use[index]) {
			tot=1;
			use[index]++;
		}
		else if (use[index]>strlen(CFIRST)) {
			tot=0;
			use[index]=0;
			resat[resTOS]=0;
			dresat[resTOS]=0;
			presat[resTOS]=NULL;
			resTOS--;
			if (resTOS<0) resTOS=0;
			rightPos=FALSE;
		}
		/* calculate iterations
		 * Note: scan is updated in alt_scan but restored in the end */
		else {
			int j;
			tot=1;
			strncpy_(mypad,VOIDS,COMPSTR);
			for (j=0;j<use[index];j++) {
				strncat_(mypad,alt_scan(FIRST,pat),COMPSTR);
				/* in case of something wrong, reset registers
				 * and cause rematch; it's responsability of
				 * scanner() to restore the correct values */
				if (!rightPos || !report ||\
					        scan>strlen(FIRST) ||\
						strlen(mypad)>strlen(FIRST)) {
					tot=0;
					use[index]=-1;
					resat[resTOS]=0;
					dresat[resTOS]=0;
					presat[resTOS]=NULL;
					resTOS--;
					if (resTOS<0) resTOS=0;
					rightPos=FALSE;
					strncpy_(mypad,VOIDS,COMPSTR);
					break;
				}
			}
			use[index]++;
		}
		p=pb;
		scan=dscan;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* POS function
	 * check current cursor position from the start */
	else if (!strncasecmp_(p,"POS(",4)) {
		int pos=0;
		p+=4;
		pos=strtol(AS(),NULL,10);
		snprintf(argparam,COMPSTR,"%d",pos);
		argtype=INTEGER;
		if (pos<0 || pos>COMPSTR) perror_(__LINE__,16,l);
		/* POS checks current cursor position from the left */
		if (scan!=pos) rightPos=FALSE;
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* RPOS string function
	 * check current cursor position from the bottom */
	else if (!strncasecmp_(p,"RPOS(",5)) {
		int rpos=0;
		p+=5;
		rpos=strtol(AS(),NULL,10);
		snprintf(argparam,COMPSTR,"%d",rpos);
		argtype=INTEGER;
		if (rpos<0 || rpos>COMPSTR) perror_(__LINE__,16,l);
		/* RPOS checks current cursor position from the right */
		if (scan!=strlen(FIRST)-rpos) rightPos=FALSE;
		if (*p==')') p++;
		strncpy_(SSPAD,mypad,COMPSTR);
        	return SSPAD;
	}
	/* check if it's a math expression
	 * IMPORTANT:
	 * in SS() the expression evaluator must be put in the end!!!! */
	else if ((isdigit(*p) || isnumvar(p) || isnumstr(p) || *p=='-' ||\
		       *p=='+' || *p=='(') && !isUniEvalFunc(p) &&\
		       !isnumfun(p)) {
		val=S(); // redefines _exprtype but uselee here
		if (!notAMathExpression) {
			snprintf(mypad,COMPSTR,"%.15G",val);
			while (isblank(*p)) p++;
			strncpy_(SSPAD,mypad,COMPSTR);
        		return SSPAD;
		}
		else {
			p=pb;
			rightPos=FALSE;
		}
	}
	else {
		p=pb;
		report=FALSE;
	}
	strncpy_(SSPAD,mypad,COMPSTR);
       	return SSPAD;
} // end of SS()


/* string()
 * Evaluate the string function under the program counter,
 * Return TRUE for a correct evaluation, FALSE if no string function was found.
 * Note: mypad must be a COMPSTR string.
 * Used in SS() and GP() and collateral */
int string(char *mypad) {
	int ns, k;
	while (isblank(*p)) p++;
	_datatype=STRING;
	/* search for a literal string */
	if (*p=='\"') {
		char *v=mypad;
		p++; // skip opening quote
		while (*p) {
			if (*p=='\\' && *(p+1)=='a') *v++='\a', p+=2;
			else if (*p=='\\' && *(p+1)=='b') *v++='\b', p+=2;
			else if (*p=='\\' && *(p+1)=='t') *v++='\t', p+=2;
			else if (*p=='\\' && *(p+1)=='n') *v++='\n', p+=2;
			else if (*p=='\\' && *(p+1)=='v') *v++='\v', p+=2;
			else if (*p=='\\' && *(p+1)=='f') *v++='\f', p+=2;
			else if (*p=='\\' && *(p+1)=='\'') *v++='\'', p+=2;
			else if (*p=='\\' && *(p+1)=='\"') *v++='\"', p+=2;
			else if (*p=='\"' && *(p+1)=='\"') *v++='\"', p+=2;
			else if (*p=='\"') break;
			else *v++=*p++;
		}
		*v='\0';
		if (*p=='\"') p++; // skip closing quote
		_datatype=STRING;
	}
	else if (*p=='\'') {
		char *v=mypad;
		p++; // skip opening quote
		while (*p) {
			if (*p=='\\' && *(p+1)=='a') *v++='\a', p+=2;
			else if (*p=='\\' && *(p+1)=='b') *v++='\b', p+=2;
			else if (*p=='\\' && *(p+1)=='t') *v++='\t', p+=2;
			else if (*p=='\\' && *(p+1)=='n') *v++='\n', p+=2;
			else if (*p=='\\' && *(p+1)=='v') *v++='\v', p+=2;
			else if (*p=='\\' && *(p+1)=='f') *v++='\f', p+=2;
			else if (*p=='\\' && *(p+1)=='r') *v++='\r', p+=2;
			else if (*p=='\\' && *(p+1)=='\'') *v++='\'', p+=2;
			else if (*p=='\\' && *(p+1)=='\"') *v++='\"', p+=2;
			else if (*p=='\'' && *(p+1)=='\'') *v++='\'', p+=2;
			else if (*p=='\'') break;
			else *v++=*p++;
		}
		*v='\0';
		if (*p=='\'') p++; // skip closing quote
		_datatype=STRING;
	}
	/* evaluate the user function */
	else if ((ns=findPROC(p))) {
		char strres[COMPSTR], *s=strres;
		int ftype=0;
		strncpy_(strres,VOIDS,COMPSTR);
		p=define(ns,s,&ftype);
		strncpy_(mypad,s,COMPSTR);
		_datatype=ftype;
		return TRUE;
	}
	/* evaluate integer functions (in string) */
	else if (isIntFunc(mypad)) {
		/* note: p is advanced in isIntFunc() */
		char *s=mypad;
		strtod(s,&s);
		if (!*s) {
			if (parseInt(mypad)) _datatype=INTEGER;
			else _datatype=REAL;
		}
	}
	/* evaluate the indirect reference in string() */
	else if (*p=='$' && *(p+1) && !isblank(*(p+1))) {
		char temp[COMPSTR];
		int ns, state;
		p++; // skip $
		if (*p=='(') {
			p++;
			strncpy_(temp,AS(),COMPSTR);
			if (*p==')') p++;
			ns=decCount;
			while (ns>0) {
				if (!strcasecmp(temp,vn[ns].name))
					break;
				ns--;
			}
			if (ns<1) {
				declare(temp,STRING,FALSE,0,0);
				ns=decCount;
			}
			strncpy_(mypad,vn[ns].str,COMPSTR);
			_datatype=vn[ns].datatype;
			return TRUE;
		}
		ns=searchDEC(p,decCount);
		if (ns && vn[ns].datatype==NAME) {
			char *pb=p+_len;
			p=vn[ns].str;
			strncpy_(mypad,GP(&state),COMPSTR);
			p=pb;
		}
		else {
			if (isquote(p)) {
				char *t=temp, q=*p++;
				while (*p && *p!=q) *t++=*p++;
				*t='\0';
				if (*p==q) p++;
			}
			else strncpy_(temp,SS(),COMPSTR);
			if (temp[0]) {
				ns=decCount;
				while (ns>0) {
					if (!strncasecmp_(temp,vn[ns].name,strlen(vn[ns].name))) {
						state=vn[ns].datatype;
						break;
					}
					ns--;
				}
				/* in string() */
				if (ns<1) {
					declare(temp,STRING,FALSE,0,0);
					ns=decCount;
					state=STRING;
				}
				if (vn[ns].datatype<=STRING)
					strncpy_(mypad,vn[ns].str,COMPSTR);
				else strncpy_(mypad,vn[ns].name,COMPSTR);
				state=vn[ns].datatype;
			}
			else {
				declare(temp,STRING,FALSE,0,0);
				ns=decCount;
				state=STRING;
			}
		}
		_datatype=state;
	}
	/* evaluate integer numbers (in string) */
	else if (isdigit(*p) || (*p=='.' && isdigit(*(p+1)))) {
		double val=S();
		snprintf(mypad,COMPSTR,"%.15G",val);
		_datatype=_exprtype;
	}
	/* check for an input variable (that must exist) */
	else if ((ns=searchDEC(p,decCount)) && vn[ns].iotype==READFILE) {
		char temp[COMPSTR];
		int backinF=inF;
		p+=_len;
		while (isblank(*p)) p++;
		inF=vn[ns].datachan;
		strncpy_(temp,DO_INPUT(),COMPSTR);
		sReads++; // for Stats
		/* if shorter than data length, fill with spaces */
		if (strlen(temp)<channel[inF].datalen) {
			int k=channel[inF].datalen-strlen(temp);
			while (k>0) {
				strncat_(temp," ",COMPSTR);
				k--;
			}
			strncpy_(mypad,temp,COMPSTR);
		}
		else if (strlen(temp)>channel[inF].datalen) {
			strncpy_(mypad,temp,channel[inF].datalen+1);
		}
		/* in case of &TRIM = 1, perform the removing of spaces;
		 * Note: since the user could have put spaces at the end of
		 * mypad, the removing is placed here to remove those also. */
		if (isGTrim) {
			char *opp=mypad;
			while (isblank(*(opp+strlen(opp)-1)))
				*(opp+strlen(opp)-1)='\0';
		}
		strncpy_(vn[ns].str,mypad,COMPSTR);
		_datatype=STRING;
		inF=backinF;
	}
	/* APPLY() function
	 * evaluate any function */
	else if (!strncasecmp_(p,"APPLY(",6)) {
		char output[COMPSTR], *o;
		int st=0;
		p+=6;
		/* copy name
		 * Note: the first item is either a literal string
		 * or a variable of datatype STRING, thus AS() is used
		 * here to collect the possible concatenation of items */
		strncpy_(output,AS(),COMPSTR);
		if (*p==',') p++;
		o=output+strlen(output);
		*o++='(';
		/* copy arguments (bare) */
		if (!strncasecmp_(p,"FAMILY(",7)) {
			char name[COMPSTR], var[COMPSTR], *v=var;
			int type;
			p+=7;
			strncpy_(name,getPar(p),COMPSTR);
			p+=strlen(name);
			if (*p==')') p++;
			strncpy_(var,family(name,&type),COMPSTR);
			ns=searchDEC(var,decCount);
			if (!ns) perror_(__LINE__,23,l);
			if (vn[ns].datatype!=DATA) perror_(__LINE__,23,l);
			while (*v) *o++=*v++;
			*o='\0';
		}
		else {
			while (*p) {
				st=0;
				if (*p=='(') st++;
				else if (*p==')' && st) st--;
				else if (*p==')' && !st) break;
				*o++=*p++;
			}
		}
		*o++=')';
		*o='\0';
		if (*p==')') p++;
		o=p;
		p=output;
		strncpy_(mypad,GP(&_datatype),COMPSTR);
		p=o;
	}
	/* FAMILY() function
	 * return family item of the argument */
	else if (!strncasecmp_(p,"FAMILY(",7)) {
		int type=0;
		char var[COMPSTR];
		p+=7;
		strncpy_(var,getPar(p),COMPSTR);
		p+=strlen(var);
		strncpy_(var,family(var,&type),COMPSTR);
		p+=strlen(var);
		if (!type) perror_(__LINE__,23,l);
		else {
			strncpy_(mypad,var,COMPSTR);
			/* Note: force attribution of the type to STRING:
			 * FAMILY would return ARRAY or DATA and this function
			 * is executed outside of ITEM() and APPLY() */
			_datatype=STRING;
		}
		if (*p==')') p++;
	}
	/* CHAR() function
	 * return the ASCII character = argument */
	else if (!strncasecmp_(p,"CHAR(",5)) {
		unsigned char asc=0;
		p+=5;
		while (isblank(*p)) p++;
		asc=(int)S();
		mypad[0]=asc;
		mypad[1]='\0';
		if (*p==')') p++;
		_datatype=STRING;
	}
	/* FIELD() function
	 * return field of DATA item */
	else if (!strncasecmp_(p,"FIELD(",6)) {
		char varname[COMPSTR], *a=NULL, *mm=mypad;
		int i,j,pos=0;
		p+=6;
		/* case of a Name entity */
		if (*p=='.') {
			char *v=varname;
			p++;
			while (*p && *p!=',') *v++=*p++;
			*v='\0';
		}
		/* case of variables or strings */
		else {
			int ns=findDEC(p);
			/* case of literal string */
			if (!ns) {
				strncpy_(varname,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME) perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(varname,vn[ns].str,COMPSTR);
			}
		}
		if (!varname[0]) perror_(__LINE__,64,l);
		while (isblank(*p)) p++;
		if (*p==',') {
			p++;
			pos=(int)S();
		}
		/* search among the DATA types */
		i=dataTOS;
		while (i>0) {
			if (!strcasecmp(varname,datafunc[i].name)) break;
			i--;
		}
		if (i<1 || pos<1) return report=FALSE;
		if (pos>datafunc[i].num) return report=FALSE;
		/* search among the DATA arguments */
		a=datafunc[i].proto;
		j=1;
		while (TRUE) {
			if (j==pos) {
				while (*a && *a!=',') *mm++=*a++;
				*mm='\0';
				break;
			}
			while (*a && *a!=',') a++;
			if (*a==',') a++;
			j++;
			if (j>pos) break;
		}
		_datatype=NAME;
		if (*p==')') p++;
	}
	/* ARG() function
	 * return argument name of DEFINE function */
	else if (!strncasecmp_(p,"ARG(",4)) {
		char varname[COMPSTR], *a=NULL, *mm=mypad;
		int i,j,pos=0;
		p+=4;
		/* case of a Name entity */
		if (*p=='.') {
			char *v=varname;
			p++;
			while (*p && *p!=',') *v++=*p++;
			*v='\0';
		}
		/* case of variables or strings */
		else {
			int ns=findDEC(p);
			/* case of literal string */
			if (!ns) {
				strncpy_(varname,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME) perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(varname,vn[ns].str,COMPSTR);
			}
		}
		if (!varname[0]) perror_(__LINE__,64,l);
		while (isblank(*p)) p++;
		if (*p==',') {
			p++;
			pos=(int)S();
		}
		/* search among the DATA types */
		i=defineTOS;
		while (i>0) {
			if (!strcasecmp(varname,definefunc[i].name)) break;
			i--;
		}
		if (i<1 || pos<1) return report=FALSE;
		if (pos>definefunc[i].anum) return report=FALSE;
		/* search among the DATA arguments */
		a=definefunc[i].argproto;
		j=1;
		while (TRUE) {
			if (j==pos) {
				while (*a && *a!=',') *mm++=*a++;
				*mm='\0';
				break;
			}
			while (*a && *a!=',') a++;
			if (*a==',') a++;
			j++;
			if (j>pos) break;
		}
		_datatype=NAME;
		if (*p==')') p++;
	}
	/* LOCAL() function
	 * return local name of DEFINE function */
	else if (!strncasecmp_(p,"LOCAL(",6)) {
		char varname[COMPSTR], *a=NULL, *mm=mypad;
		int i,j,pos=0;
		p+=6;
		/* case of a Name entity */
		if (*p=='.') {
			char *v=varname;
			p++;
			while (*p && *p!=',') *v++=*p++;
			*v='\0';
		}
		/* case of variables or strings */
		else {
			int ns=findDEC(p);
			/* case of literal string */
			if (!ns) {
				strncpy_(varname,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME) perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(varname,vn[ns].str,COMPSTR);
			}
		}
		if (!varname[0]) perror_(__LINE__,64,l);
		while (isblank(*p)) p++;
		if (*p==',') {
			p++;
			pos=(int)S();
		}
		/* search among the DATA types */
		i=defineTOS;
		while (i>0) {
			if (!strcasecmp(varname,definefunc[i].name)) break;
			i--;
		}
		if (i<1 || pos<1) return report=FALSE;
		if (pos>definefunc[i].lnum) return report=FALSE;
		/* search among the DATA arguments */
		a=definefunc[i].otherproto;
		j=1;
		while (TRUE) {
			if (j==pos) {
				while (*a && *a!=',') *mm++=*a++;
				*mm='\0';
				break;
			}
			while (*a && *a!=',') a++;
			if (*a==',') a++;
			j++;
			if (j>pos) break;
		}
		_datatype=NAME;
		if (*p==')') p++;
	}
	/* DATATYPE() function
	 * return the string which is the data type of the argument */
	else if (!strncasecmp_(p,"DATATYPE(",9)) {
		int k;
		p+=9;
		if ((k=findDEC(p)) && vn[k].datatype==DATA) {
			strncpy_(mypad,datafunc[vn[k].dim].name,COMPSTR);
			p+=_len;
		}
		else if ((k=findDEC(p)) && *(p+_len)==')') {
			int dt=vn[k].datatype;
			if (dt>PREDEF) dt-=PREDEF;
			strncpy_(mypad,types[dt/100],COMPSTR);
			p+=_len;
		}
		else if (*p==')') {
			strncpy_(mypad,types[STRING/100],COMPSTR);
		}
		else {
			int status;
			char temp[COMPSTR];
			strncpy_(temp,JP(&status),COMPSTR);
			strncpy_(mypad,types[status/100],COMPSTR);
		}
		if (*p==')') p++;
	}
	/* ERRTEXT() function
	 * return the error string */
	else if (!strncasecmp_(p,"ERRTEXT(",8)) {
		int cod=0;
		char arg[COMPSTR];
		p+=8;
		cod=(int)S();
		while (isblank(*p)) p++;
		if (*p==',') {
			p++; // skip comma
			strncpy_(arg,AS(),COMPSTR);
		}
		else strncpy_(arg,VOIDS,COMPSTR);
		if (cod<1 || cod > ERRLIM) {
			sErr=86;
			lErr=l;
			report=FALSE;
		}
		else if (cod==46) {
			int val=strtol(arg,NULL,10);
			sErr=0;
			lErr=0;
			snprintf(mypad,COMPSTR,error[cod],val);
		}
		else if (cod==78 || cod==79 || cod==107) {
			sErr=0;
			lErr=0;
			snprintf(mypad,COMPSTR,error[cod],arg);
		}
		else {
			sErr=0;
			lErr=0;
			strncpy_(mypad,error[cod],COMPSTR);
		}
		if (*p==')') p++;
	}
	/* PARAM() function */
	else if (!strncasecmp_(p,"PARAM(",6)) {
		char str[COMPSTR];
		int ns=0;
		p+=6;
		strncpy_(str,getPar(p),COMPSTR);
		p+=strlen(str);
		ns=findDEC(str);
		if (ns>0 && vn[ns].datatype<PATTERN) {
			strncpy_(mypad,vn[ns].argparam,COMPSTR);
			_datatype=argtype;
		}
		else if (ns>0 && vn[ns].datatype==PATTERN) {
			strncpy_(str,deExtParen(vn[ns].str),COMPSTR);
			strncpy_(mypad,getParam(str),COMPSTR);
			// getParam() defines _datatype
		}
		else if (isalpha(*p)) {
			strncpy_(mypad,getParam(str),COMPSTR);
			// getParam() defines _datatype
		}
		else {
			sErr=93;
			lErr=l;
			report=FALSE;
		}
		if (*p==')') p++;
	}
	/* ARRAY() function (dummy)
	 * return proto */
	else if (!strncasecmp_(p,"ARRAY(",6)) {
		p+=6;
		AS(); // consume argument
		strncpy_(mypad,"[ARRAY]",COMPSTR);
		_datatype=STRING;
		if (*p==')') p++;
	}
	/* data item function (dummy)
	 * return name */
	else if ((k=findDATA(p))) {
		p+=_len;
		if (*p=='(') p++;
		while (*p!=')') {
			AS();
			if (*p==',') p++;
		}
		strncpy_(mypad,"[",COMPSTR);
		strncat_(mypad,datafunc[k].name,COMPSTR);
		strncat_(mypad,"]",COMPSTR);
		_datatype=STRING;
		if (*p==')') p++;
	}
	/* COPY() function
	 * copy item */
	else if (!strncasecmp_(p,"COPY(",5)) {
		int ns=0, k=0;
		p+=5;
		ns=searchDEC(p,decCount);
		k=findDATA(p);
		if (ns) {
			p+=_len;
			if (vn[ns].datatype==ARRAY) {
				strncpy_(mypad,"[ARRAY]",COMPSTR);
			}
			else if (vn[ns].datatype==CODE) {
				strncpy_(mypad,"[CODE]",COMPSTR);
			}
			else if (vn[ns].datatype==DATA) {
				strncpy_(mypad,"[DATA]",COMPSTR);
			}
			else if (k) {
				strncpy_(mypad,"[",COMPSTR);
				strncat_(mypad,datafunc[k].name,COMPSTR);
				strncat_(mypad,"]",COMPSTR);
			}
			_datatype=STRING;
		}
		else {
			sErr=0; // TODO mettere errore
			lErr=l;
			report=FALSE;
		}
		if (*p==')') p++;
	}	
	/* REPLACE() function
	 * replace in base all characters occurring in 
	 * temp1 with the characters in temp2 */
	else if (!strncasecmp_(p,"REPLACE(",8)) {
		char base[COMPSTR], temp1[COMPSTR], temp2[COMPSTR];
		char out[COMPSTR], *d, *o, *f;
		p+=8;
		strncpy_(base,AS(),COMPSTR);
		if (*p==',') p++;
		else return report=FALSE;
		strncpy_(temp1,AS(),COMPSTR);
		if (*p==',') p++;
		else return report=FALSE;
		strncpy_(temp2,AS(),COMPSTR);
		if (strlen(temp1)!=strlen(temp2)) return report=FALSE;
		d=base;
		o=out;
		while (*d) {
			if ((f=strchr(temp1,*d))) {
				*o=*(temp2+(f-temp1));
			}
			else *o=*d;
			d++;
			o++;
		}
		*o='\0';
		strncpy_(mypad,out,COMPSTR);
		if (*p==')') p++;
	}
	/* SELECTOR() function
	 * return the selector of an ARRAY or a DATA item */
	else if (!strncasecmp_(p,"SELECTOR(",9)) {
		char var[COMPSTR];
		int ns=0;
		p+=9;
		while (isblank(*p)) p++;
		/* case of a NAME entity */
		if (*p=='.') {
			p++;
			strncpy_(var,getPar(p),COMPSTR);
			p+=strlen(var);
		}
		/* case of variables or strings */
		else {
			/* case of a literal string */
			if (isquote(p)) {
				int status;
				strncpy_(var,GP(&status),COMPSTR);
				if (status!=ARRAY && status!=DATA) {
					sErr=23;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
			}
			/* case of a variable */
			else ns=searchDEC(p,decCount);
			if (ns) {
				p+=_len;
				strncpy_(var,vn[ns].str,COMPSTR);
			}
			else {
				sErr=64;
				lErr=l;
				report=FALSE;
				return TRUE;
			}
		}
		ns=searchDEC(var,decCount);
		if (!ns) perror_(__LINE__,64,l); // ok, variable not existing
		strncpy_(mypad,getSelector(var),COMPSTR);
		/* element not suitable for SELECTOR() */
		if (!strcmp(mypad,"[[UNKNOWN]]")) {
			sErr=23;
			lErr=l;
			report=FALSE;
			strncpy_(mypad,VOIDS,COMPSTR);
		}
		_datatype=STRING;
		if (*p==')') p++;
	}
	/* ITEM() function
	 * equivalent to an array call */
	else if (!strncasecmp_(p,"ITEM(",5)) {
		char name[COMPSTR], *n=name, tval[COMPSTR];
		int ns=0, val[MAXDIM+1], T=0;
		p+=5;
		if (!strncasecmp_(p,"FAMILY(",7)) {
			char var[COMPSTR];
			int type;
			p+=7;
			strncpy_(name,getPar(p),COMPSTR);
			p+=strlen(name);
			if (*p==')') p++;
			strncpy_(var,family(name,&type),COMPSTR);
			ns=searchDEC(var,decCount);
		}
		else {
			/* get literal name of array */
			while (*p && *p!=')' && *p!=',') *n++=*p++;
			*n='\0';
			ns=searchDEC(name,decCount);
		}
		if (!ns) perror_(__LINE__,64,l);
		if (vn[ns].datatype!=ARRAY) perror_(__LINE__,57,l);
		if (*p!=',') perror_(__LINE__,38,l);
		else p++; // skip comma
		while (*p && *p!=')') {
			if (isdigit(*p)) {
				T++;
				val[T]=S();
			}
			else {
				char *tt=tval;
				strncpy_(tt,SS(),COMPSTR);
				while (*tt) {
					T++;
					val[T]=strtol(tt,&tt,10);
					if (*tt==',') tt++;
				}
			}
			if (*p==',') p++;
		}
		snprintf(mypad,COMPSTR,"%s",getArrayStr(ns,T,val));
		_datatype=getArrayVal(ns,T,val);
		if (*p==')') p++;
	}
	/* NEXTVAR() function
	 * return the next variable of variable in argument
	 * according to the family (natural, array, structure) as a Name */
	else if (!strncasecmp_(p,"NEXTVAR(",8)) {
		char var[COMPSTR], *pb;
		int ns=0, dback=1, dforw=decCount;
		if (currentDECstart) dback=currentDECstart;
		p+=8;
		while (isblank(*p)) p++;
		/* case of a Name entity */
		if (*p=='.') {
			p++;
			strncpy_(var,getPar(p),COMPSTR);
			p+=strlen(var);
		}
		/* case of variables or strings */
		else {
			ns=searchDEC(p,decCount);
			/* case of string */
			if (!ns) {
				strncpy_(var,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME)
					perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(var,vn[ns].str,COMPSTR);
			}
			if (*p!=')') perror_(__LINE__,64,l);
		}
		pb=p;
		p=var;
		ns=searchDEC(var,decCount);
		if (!ns) perror_(__LINE__,64,l);
		p+=_len;
		if (ns<dback) dforw=dback-1;
		/* data (skip methods) */
		if (vn[ns].datatype==DATA) {
			ns++;
			while (vn[ns].isData)
				ns++;
			if (ns>dforw) ns=dback;
			strncpy_(mypad,vn[ns].name,COMPSTR);
			_datatype=NAME;
		}
		/* array */
		else if (vn[ns].datatype==ARRAY) {
			int val[MAXDIM+1], T=1;
			if (*p=='[') p++; // skip [
			val[T]=(int)S();
			if (val[T]<vn[ns].offset[T] ||\
				       val[T]>vn[ns].ldim[T]+vn[ns].offset[T])
				perror_(__LINE__,57,l);
			while (*p==',') {
				p++;
				T++;
				if (T>vn[ns].dim) perror_(__LINE__,57,l);
				val[T]=(int)S();
				if (val[T]<vn[ns].offset[T] || val[T]>vn[ns].ldim[T]+vn[ns].offset[T])
					perror_(__LINE__,57,l);
			}
			if (*p==']') p++;
			/* increase the rightmost index */
			val[T]++;
			while (val[T]>vn[ns].ldim[T]+vn[ns].offset[T] && T>0) {
				val[T]=vn[ns].offset[T];
				T--;
				val[T]++;
			}
			/* compose mypad */
			strncpy_(mypad,vn[ns].name,COMPSTR);
			strncat_(mypad,"[",COMPSTR);
			T=1;
			while (T<=vn[ns].dim) {
				char num[COMPSTR];
				snprintf(num,COMPSTR,"%d",val[T]);
				strncat_(mypad,num,COMPSTR);
				if (T<vn[ns].dim) strncat_(mypad,",",COMPSTR);
				T++;
			}
			strncat_(mypad,"]",COMPSTR);
			_datatype=NAME;
		}
		/* structure's method */
		else if (vn[ns].isData) {
			int cs=vn[ns].isData;
			int dn=vn[cs].dim;
			int nm=datafunc[dn].num;
			ns++;
			if (!vn[ns].isData) ns-=nm;
			strncpy_(mypad,realName(vn[ns].name),COMPSTR);
			_datatype=NAME;
		}
		/* natural or other variable */
		else {
			ns++;
			while (vn[ns].datatype==ARRAY || vn[ns].isData)
				ns++;
			if (ns>dforw) ns=dback;
			strncpy_(mypad,vn[ns].name,COMPSTR);
			_datatype=NAME;
		}
		p=pb;
		while (isblank(*p)) p++;
		if (*p==')') p++;
	}
	/* FIRST() function
	 * return the first item of an alternation or concatenation
	 * the data type of the argument is PATTERN */
	else if (!strncasecmp_(p,"FIRST(",6)) {
		char temp[COMPSTR], *t=NULL;
		char test[COMPSTR], null[COMPSTR];
		p+=6;
		ns=searchDEC(p,decCount);
		if (ns && vn[ns].datatype==PATTERN && *(p+_len)==')') {
			p+=_len;
			strncpy_(temp,vn[ns].str,COMPSTR);
		}
		else if (ns && vn[ns].datatype!=PATTERN && *(p+_len)==')') {
			perror_(__LINE__,23,l);
		}
		else {
			strncpy_(temp,getPar(p),COMPSTR);
			p+=strlen(temp);
		}
		/* remove general extern parenthesis (one level) */
		while (isblank(*p)) p++;

		/* delegate getFirstRest() */
		if (!getFirstRest(temp,test,null))
			perror_(__LINE__,23,l);
		/* null is unused here */
		strncpy_(null,test,COMPSTR);
		t=null;
		while (isblank(*t)) t++;
		strncpy_(mypad,t,COMPSTR);

		if (*p==')') p++;
		while (isblank(*p)) p++;
		_datatype=PATTERN;
	}
	/* REST() function
	 * return the rest of items of an alternation or concatenation
	 * the data type of the argument is PATTERN */
	else if (!strncasecmp_(p,"REST(",5)) {
		char temp[COMPSTR], null[COMPSTR];
		char test[COMPSTR], *t=NULL;
		p+=5;
		ns=searchDEC(p,decCount);
		if (ns && vn[ns].datatype==PATTERN && *(p+_len)==')') {
			p+=_len;
			strncpy_(temp,vn[ns].str,COMPSTR);
		}
		else if (ns && vn[ns].datatype!=PATTERN && *(p+_len)==')') {
			perror_(__LINE__,23,l);
		}
		else {
			strncpy_(temp,getPar(p),COMPSTR);
			p+=strlen(temp);
		}
		while (isblank(*p)) p++;

		/* delegate getFirstRest() */
		if (!getFirstRest(temp,null,test))
			perror_(__LINE__,23,l);
		/* null is unused here */
		strncpy_(null,test,COMPSTR);
		t=null;
		while (isblank(*t)) t++;
		strncpy_(mypad,t,COMPSTR);

		if (*p==')') p++;
		while (isblank(*p)) p++;
		_datatype=PATTERN;
	}
	/* PUT() function
	 * return as string the content of the argument */
	else if (!strncasecmp_(p,"PUT(",4)) {
		char temp[COMPSTR];
		p+=4;
		ns=searchDEC(p,decCount);
		/* a variable is turned to its content */
		if (ns && vn[ns].datatype<ARRAY) {
			strncpy_(temp,vn[ns].str,COMPSTR);
			strncpy_(mypad,deParen(temp),COMPSTR);
			p+=_len;
		}
		/* anything else is passed as-is */
		else {
			p--;
			strncpy_(temp,AS(),COMPSTR);
			strncpy_(mypad,deParen(temp),COMPSTR);
		}
		_datatype=STRING;
		if (*p==')') p++;
	}
	/* LEFT() function
	 * return the first item of an immediate or conditional assignment
	 * the data type of the argument is a PATTERN */
	else if (!strncasecmp_(p,"LEFT(",5)) {
		char temp[COMPSTR], *t=temp, *w;
		int type, st=0, dt=0;
		p+=5;
		ns=searchDEC(p,decCount);
		/* it's a variable */
		if (ns && vn[ns].datatype==PATTERN && *(p+_len)==')') {
			p+=_len;
			strncpy_(temp,deParen(vn[ns].str),COMPSTR);
			type=vn[ns].datatype;
		}
		/* else store the content */
		else {
			strncpy_(temp,deParen(GP(&type)),COMPSTR);
			getPar(p);
		}
		/* analyse the pattern content */
		if (type==PATTERN) {
			w=mypad;
			/* get the first item */
			while (*t) {
				if (*t=='(') st++;
				else if (*t=='[') dt++;
				else if (*t==')' && st) st--;
				else if (*t==']' && dt) dt--;
				else if (isblank(*t) && !st && !dt) break;
				*w++=*t++;
			}
			*w='\0';
			while (isblank(*t)) t++;
			/* if no assignment is present, error for LEFT */
			if (*t!='.' && *t!='$') perror_(__LINE__,23,l);
			_datatype=PATTERN;
		}
		/* else it's an error */
		else perror_(__LINE__,23,l);

		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* RIGHT() function
	 * return the rest of items of an immediate or conditional assignment
	 * as a NAME, the variable of the deferred evaluation *VAR as a NAME,
	 * or convert a NAME object to STRING
	 * the data type of the argument is PATTERN or NAME */
	else if (!strncasecmp_(p,"RIGHT(",6)) {
		char temp[COMPSTR], *t=temp;
		char test[COMPSTR], *w=mypad;
		int type, st=0, dt=0;
		p+=6;
		ns=searchDEC(p,decCount);
		/* it's a variable */
		if (ns && *(p+_len)==')') {
			p+=_len;
			strncpy_(temp,deParen(vn[ns].str),COMPSTR);
			type=vn[ns].datatype;
		}
		/* else store the content */
		else {
			strncpy_(temp,deParen(GP(&type)),COMPSTR);
			getPar(p);
		}
		/* analyse the pattern content */
		if (type==PATTERN) {
			/* treat the *VAR case */
			if (*t=='*') {
				st=dt=0;
				//*w++='.';
				t++; // skip *
				while (*t) {
					if (*t=='(') st++;
					else if (*t=='[') dt++;
					else if (*t==')' && st) st--;
					else if (*t==']' && dt) dt--;
					else if (isblank(*t) && !st && !dt)
						break;
					*w++=*t++;
				}
				*w='\0';
			}
			/* treat the pattern */
			else {
				w=test;
				int st=0, dt=0;
				/* get the first item */
				while (*t) {
					if (*t=='(') st++;
					else if (*t=='[') dt++;
					else if (*t==')' && st) st--;
					else if (*t==']' && dt) dt--;
					else if (isblank(*t) && !st && !dt)
						break;
					*w++=*t++;
				}
				*w='\0';
				while (isblank(*t)) t++;
				/* if no assignment is present, error */
				if (*t!='.' && *t!='$') perror_(__LINE__,23,l);
				t++; // skip . or $
				while (isblank(*t)) t++;
				/* get the variable name */
				w=mypad;
				st=dt=0;
				while (*t) {
					if (*t=='(') st++;
					else if (*t=='[') dt++;
					else if (*t==')' && st) st--;
					else if (*t==']' && dt) dt--;
					else if (isblank(*t) && !st && !dt)
						break;
					*w++=*t++;
				}
				*w='\0';
			}
			_datatype=NAME;
		}
		/* analyse the name content */
		else if (type==NAME) {
			if (*t=='.') t++;
			strncpy_(mypad,t,COMPSTR);
			_datatype=STRING;
		}
		/* else it's an error */
		else perror_(__LINE__,23,l);

		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* SUBSTR() function
	 * extract sub string */
	else if (!strncasecmp_(p,"SUBSTR(",7)) {
	}
	/* TYPE() function
	 * return the string which is the data type of the argument */
	else if (!strncasecmp_(p,"TYPE(",5)) {
		int k;
		p+=5;
		if ((k=findDEC(p)) && *(p+_len)==')') {
			int dt=vn[k].datatype;
			if (dt>PREDEF) dt-=PREDEF;
			strncpy_(mypad,types[dt/100],COMPSTR);
			p+=_len;
		}
		else if (*p==')') {
			strncpy_(mypad,types[STRING/100],COMPSTR);
		}
		else {
			int status;
			char temp[COMPSTR];
			strncpy_(temp,JP(&status),COMPSTR);
			strncpy_(mypad,types[status/100],COMPSTR);
		}
		if (*p==')') p++;
	}
	/* PROTOTYPE() function
	 * return the prototype of the object, delegating getProto() */
	else if (!strncasecmp_(p,"PROTOTYPE(",10)) {
		char op[COMPSTR], *o=op;
		int st=0;
		p+=10;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"FAMILY(",7)) {
			char var[COMPSTR];
			int type=0;
			p+=7;
			strncpy_(var,getPar(p),COMPSTR);
			p+=strlen(var);
			strncpy_(op,family(var,&type),COMPSTR);
			if (type<ARRAY) perror_(__LINE__,23,l);
			while (isblank(*p)) p++;
			if (*p==')') p++;
		}
		else while (*p) {
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			*o++=*p++;
			*o='\0';
		}
		strncpy_(mypad,getProto(op),COMPSTR);
		while (isblank(*p)) p++;
		if (*p==')') p++;
	}
	/* ALPHABET() function
	 * return the complete ASCII set */
	else if (!strncasecmp_(p,"ALPHABET(",9)) {
		char op[COMPSTR];
		p+=9;
		while (isblank(*p)) p++;
		strncpy_(op,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (*p==')') p++;
		strncpy_(mypad,COMPLETESET,COMPSTR);
	}
	/* DEBUG() function
	 * return the length of the string in argument */
	else if (!strncasecmp_(p,"DEBUG(",6)) {
		char op[COMPSTR];
		p+=6;
		while (isblank(*p)) p++;
		strncpy_(op,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (!strcmp(op,"0")) op[0]='\0';
		isDebug=op[0]?TRUE:FALSE;
		if (*p==')') p++;
	}
	/* INPUT function
	 * return a string from the current input source
	 * Note: this is a special variable that in case
	 * is found it must be refined, since findDEC()
	 * does not specialize any i/o variable */
	else if (!strncasecmp_(p,"INPUT",5)) {
		int ns=findDEC(p);
		char *v;
		p+=5;
		while (isblank(*p)) p++;
		vn[ns].iotype=READFILE;
		vn[ns].datachan=inF;
		if (channel[inF].wayout!=VREAD) perror_(__LINE__,54,l);
		strncpy_(vn[ns].str,DO_INPUT(),COMPSTR);
		strncpy_(mypad,vn[ns].str,COMPSTR);
		/* in case of &TRIM = 1, perform the removing of spaces */
		if (isGTrim) {
			char *opp=mypad;
			while (isblank(*(opp+strlen(opp)-1)))
				*(opp+strlen(opp)-1)='\0';
		}
		sReads++; // for Stats
		strtod(mypad,&v);
		if (!*v) {
			if (parseInt(mypad)) vn[ns].datatype=INTEGER;
			else vn[ns].datatype=REAL;
		}
		else vn[ns].datatype=STRING;
	}
	/* MARK function
	 * DEBUGGING PURPOSES - to be amended
	 * print the mark |@| when encountered */
	else if (!strncasecmp_(p,"MARK",4)) {
		p+=4;
		fprintf(stdout,"%s","|@|");
		while (isblank(*p)) p++;
		strncpy_(mypad,VOIDS,COMPSTR);
	}
	/* TERMINAL function
	 * return a string from the keyboard
	 * Note: this is a special variable that in case
	 * is found it must be refined, since findDEC()
	 * does not specialize any i/o variable */
	else if (!strncasecmp_(p,"TERMINAL",8)) {
		int ns=findDEC(p), backinF=inF;
		double val;
		char *v;
		p+=8;
		inF=1;
		while (isblank(*p)) p++;
		vn[ns].iotype=READFILE;
		vn[ns].datachan=inF;
		strncpy_(vn[ns].str,DO_INPUT(),COMPSTR);
		strncpy_(mypad,vn[ns].str,COMPSTR);
		/* in case of &TRIM = 1, perform the removing of spaces */
		if (isGTrim) {
			char *opp=mypad;
			while (isblank(*(opp+strlen(opp)-1)))
				*(opp+strlen(opp)-1)='\0';
		}
		sReads++; // for Stats
		inF=backinF;
		val=strtod(mypad,&v);
		if (!*v) {
			if (val==(int) val) vn[ns].datatype=INTEGER;
			else vn[ns].datatype=REAL;
		}
		else vn[ns].datatype=STRING;
	}
	/* CLOCK() function
	 * return the time in the format HH:MM:SS */
	else if (!strncasecmp_(p,"CLOCK(",6)) {
		char str[COMPSTR];
		p+=6;
		while (isblank(*p)) p++;
		/* get argument */
		strncpy_(str,AS(),COMPSTR);
		if (!strcasecmp(str,"H") || !strcasecmp(str,"HOUR"))
			snprintf(mypad,COMPSTR,"%02d",getHour());
		else if (!strcasecmp(str,"M") || !strcasecmp(str,"MIN"))
			snprintf(mypad,COMPSTR,"%02d",getMin());
		else if (!strcasecmp(str,"S") || !strcasecmp(str,"SEC"))
			snprintf(mypad,COMPSTR,"%02d",getSec());
		else snprintf(mypad,COMPSTR,"%02d:%02d:%02d",getHour(),getMin(),getSec());
		while (isblank(*p)) p++;
		/* consume and ignore the rest if given */
		while (*p && *p!=')') {
			int st=0;
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			p++;
		}
		while (isblank(*p)) p++;
		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* DUPL() function
	 * return the first argument duplicated as many times
	 * as indicated in the second argument */
	else if (!strncasecmp_(p,"DUPL(",5)) {
		int i,times=0;
		char output[COMPSTR];
		p+=5;
		strncpy_(output,AS(),COMPSTR);
		if (*p==',') p++;
		while (isblank(*p)) p++;
		times=(int)S();
		if (*p==')') p++;
		/* compose string */
		for (i=1;i<=times;i++) strncat_(mypad,output,COMPSTR);
	}
	/* DATE() function
	 * return the date in the format DD:MON:YY */
	else if (!strncasecmp_(p,"DATE(",5)) {
		char str[COMPSTR];
		p+=5;
		while (isblank(*p)) p++;
		/* get argument */
		strncpy_(str,AS(),COMPSTR);
		if (!strcasecmp(str,"Y"))
			snprintf(mypad,COMPSTR,"%02d",getYear()-2000);
		else if (!strcasecmp(str,"YYYY") || !strcasecmp(str,"YEAR"))
			snprintf(mypad,COMPSTR,"%02d",getYear());
		else if (!strcasecmp(str,"M"))
			snprintf(mypad,COMPSTR,"%02d",getMonth());
		else if (!strcasecmp(str,"MMM") || !strcasecmp(str,"MONTH"))
			snprintf(mypad,COMPSTR,"%s",getMonthString());
		else if (!strcasecmp(str,"D") || !strcasecmp(str,"DAY"))
			snprintf(mypad,COMPSTR,"%02d",getDay());
		else if (!strcasecmp(str,"0"))
			snprintf(mypad,COMPSTR,"%02d/%02d/%02d %02d:%02d:%02d",getMonth(),getDay(),getYear()-2000,getHour(),getMin(),getSec());
		else if (!strcasecmp(str,"1"))
			snprintf(mypad,COMPSTR,"%02d/%02d/%02d %02d:%02d:%02d",getDay(),getMonth(),getYear()-2000,getHour(),getMin(),getSec());
		else snprintf(mypad,COMPSTR,"%02d %s %02d",getDay(),getMonthString(),getYear()-2000);
		while (isblank(*p)) p++;
		/* consume and ignore the rest if given */
		while (*p && *p!=')') {
			int st=0;
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			p++;
		}
		while (isblank(*p)) p++;
		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* TRIM() function
	 * return a string with trimmed trailing spaces */
	else if (!strncasecmp_(p,"TRIM(",5)) {
		char op[COMPSTR], *opp=op;
		p+=5;
		while (isblank(*p)) p++;
		strncpy_(op,AS(),COMPSTR);
		while (isblank(*p)) p++;
		/* remove spaces */
		while (isblank(*(opp+strlen(opp)-1)))
			*(opp+strlen(opp)-1)='\0';
		strncpy_(mypad,op,COMPSTR);
		if (*p==')') p++;
	}
	/* CONVERT() function
	 * Berkeley side
	 * return a string with a conversion of the argument:
	 * convert(Integer) --> Real
	 * convert(Real)    --> String
	 * convert(String)  --> Real
	 * convert(other)   --> fail
	 * Bell side
	 * delegate getBellConvert() */
	else if (!strncasecmp_(p,"CONVERT(",8)) {
		char op[COMPSTR];
		char stype[COMPSTR];
		int vs, mystate;
		p+=8;
		while (isblank(*p)) p++;
		vs=searchDEC(p,decCount);
		/* argument was a variable */
		if (vs) {
			p+=_len;
			strncpy_(op,vn[vs].str,COMPSTR);
			mystate=vn[vs].datatype;
		}
		/* argument was a literal or other type variable */
		else {
			strncpy_(op,GP(&mystate),COMPSTR);
		}
		while (isblank(*p)) p++;
		/* execute the Bell CONVERT() */
		if (*p==',') {
			int res, i=0;
			p++;
			strncpy_(stype,AS(),COMPSTR);
			if (*p==')') p++;
			if (!strcasecmp(stype,"NUMERIC")) {
				if (strchr(op,'.') || strchr(op,'E') || strchr(op,'e')) {
					res=getBellConvert(op,mystate,mypad,REAL);
					_datatype=REAL;
				}
				else {
					res=getBellConvert(op,mystate,mypad,INTEGER);
					_datatype=INTEGER;
				}
			}
			else {
				while (i<9) {
					if (!strcasecmp(stype,types[i])) {
						break;
					}
					i++;
				}
				if (i<9) {
					if (mystate!=DATA) {
						res=getBellConvert(op,mystate,mypad,i*100);
					}
					else {
						res=getBellConvert(op,0,mypad,i*100);
					}
					_datatype=i*100;
				}
				else {
					res=getBellConvert(stype,0,mypad,0);
					_datatype=DATA;
				}
			}
			if (res<0) {
				sErr=105;
				lErr=l;
				report=FALSE;
			}
			else if (!res) {
				sErr=104;
				lErr=l;
				report=FALSE;
			}
			return TRUE;
		}
		/* execute the Berkeley CONVERT() */
		if (mystate==INTEGER) {
			strncpy_(mypad,op,COMPSTR);
			_datatype=REAL;
		}
		else if (mystate==REAL) {
			strncpy_(mypad,op,COMPSTR);
			_datatype=STRING;
		}
		else if (mystate==STRING) {
			char *n=op;
			strtod(op,&n);
			if (!*n) {
				strncpy_(mypad,op,COMPSTR);
				_datatype=REAL;
			}
			else {
				sErr=22;
				lErr=l;
				report=FALSE;
			}
		}
		else {
			sErr=104;
			lErr=l;
			report=FALSE;
		}
		if (*p==')') p++;
		return TRUE; // due because of defined type
	}
	/* RPAD() function
	 * right pad the string argument */
	else if (!strncasecmp_(p,"RPAD(",5)) {
		char temp1[COMPSTR], temp2[COMPSTR], pad=' ';
		int i=0,times=0;
		p+=5;
		strncpy_(temp1,AS(),COMPSTR);
		if (*p==',') p++;
		else perror_(__LINE__,65,l);
		times=(int)S();
		if (*p==',') {
			p++;
			strncpy_(temp2,AS(),COMPSTR);
			pad=temp2[0];
			if (!pad) perror_(__LINE__,13,l);
		}
		strncat_(mypad,temp1,COMPSTR);
		i=strlen(temp1);
		if (i+times>=COMPSTR) times=COMPSTR-i-1;
		if (i<times) {
			while (i<times) mypad[i++]=pad;
			mypad[i]='\0';
		}
		if (*p==')') p++;
	}
	/* LPAD() function
	 * left pad the string argument */
	else if (!strncasecmp_(p,"LPAD(",5)) {
		char temp1[COMPSTR], temp2[COMPSTR], pad=' ';
		int i=0,times=0, l=0;
		p+=5;
		strncpy_(temp1,AS(),COMPSTR);
		if (*p==',') p++;
		else perror_(__LINE__,65,l);
		times=(int)S();
		if (*p==',') {
			p++;
			strncpy_(temp2,AS(),COMPSTR);
			pad=temp2[0];
			if (!pad) perror_(__LINE__,13,l);
		}
		l=i=strlen(temp1);
		if (l+times>=COMPSTR) times=COMPSTR-l-1;
		if (l<times) {
			while (l<times) mypad[l-i]=pad, l++;
			mypad[l-i]='\0';
		}
		strncat_(mypad,temp1,COMPSTR);
		if (*p==')') p++;
	}
	/* TRACE() function
	 * set argument name for tracing */
	else if (!strncasecmp_(p,"TRACE(",6)) {
		int ns, status;
		char name[COMPSTR];
		p+=6;
		strncpy_(name,GP(&status),COMPSTR);
		/* 1st case of exclusion */
		if (status!=NAME && status!=STRING) {
			sErr=62;
			lErr=l;
			fprintf(stdout,"%s: %s\n",name,error[62]);
			report=FALSE;
			if (*p==')') p++;
		}
		/* 3rd case of exclusion */
		else if (traceTOS>=PSTACK) {
			sErr=61;
			lErr=l;
			fprintf(stdout,"%s: %s\n",name,error[61]);
			report=FALSE;
			if (*p==')') p++;
			return FALSE;
		}
		else {
			ns=findDEC(name);
			if (ns) {
				int j=0;
				/* 2nd case of exclusion */
				if (vn[ns].datatype>=ARRAY) {
					sErr=62;
					lErr=l;
					fprintf(stdout,"%s: %s\n",name,error[62]);
					report=FALSE;
					if (*p==')') p++;
					return FALSE;
				}
				while (j<traceTOS) {
					if (!trace[j]) {
						trace[j]=ns;
						break;
					}
					j++;
				}
				if (j>=traceTOS) {
					trace[traceTOS]=ns;
					traceTOS++;
					if (traceTOS>=PSTACK)
						perror_(__LINE__,61,l);
				}
			}
		}
		if (*p==')') p++;
	}
	/* UNTRACE() function
	 * remove argument name from the tracing list */
	else if (!strncasecmp_(p,"UNTRACE(",8) || !strncasecmp_(p,"STOPTR(",7)) {
		int status;
		char name[COMPSTR];
		if (toupper(*p)=='U') p+=8;
		else p+=7;
		while (isblank(*p)) p++;
		/* disable all */
		if (*p==')') {
			int j=0;
			for (j=0;j<traceTOS;j++) trace[j]=0;
			traceTOS=0;
			return TRUE;
		}
		strncpy_(name,GP(&status),COMPSTR);
		/* 1st case of exclusion */
		if (status!=NAME && status!=STRING) {
			sErr=63;
			lErr=l;
			fprintf(stdout,"%s: %s\n",name,error[62]);
			report=FALSE;
			if (*p==')') p++;
			return FALSE;
		}
		else {
			int ns,j=0;
			/* disable one specific */
			ns=searchDEC(name,decCount);
			while (j<traceTOS) {
				if (trace[j]==ns) {
					trace[j]=0;
					break;
				}
				j++;
			}
			/* 2nd case of exclusion */
			if (j>=traceTOS) {
				sErr=63;
				lErr=l;
				fprintf(stdout,"%s: %s\n",name,error[63]);
				report=FALSE;
				if (*p==')') p++;
				return FALSE;
			}
		}
		if (*p==')') p++;
	}
	/* STLIMIT() function in string()
	 * set/get the limit mode
	 * The form STLIMIT() is accepted */
	else if (!strncasecmp_(p,"STLIMIT(",8)) {
		p+=8;
		if (*p==')') snprintf(mypad,COMPSTR,"%d",isStLimit);
		else {
			while (isblank(*p)) p++;
			isStLimit=(int)S();
			snprintf(mypad,COMPSTR,"%d",isStLimit);
		}
		if (*p==')') p++;
	}
	/* check for an output variable (that must exist)
	 * which returns simply its current content */
	else if ((ns=searchDEC(p,decCount)) && vn[ns].iotype==WRITEFILE) {
		p+=_len;
		strncpy_(mypad,vn[ns].str,COMPSTR);
	}
	/* case of array item */
	else if ((ns=searchDEC(p,decCount)) && vn[ns].datatype==ARRAY) {
		int val[MAXDIM+1];
	       	int T=1;
		p+=_len;
		if (*p=='[') p++; // skip [
		else return FALSE;
		ns=vn[ns].ref;
		val[T]=(int)S();
		if (val[T]<vn[ns].offset[T] || val[T]>vn[ns].ldim[T]+vn[ns].offset[T])
			return FALSE;
		while (*p==',') {
			p++; T++;
			if (T>vn[ns].dim) return FALSE;
			val[T]=(int)S();
			if (val[T]<vn[ns].offset[T] || val[T]>vn[ns].ldim[T]+vn[ns].offset[T])
				return FALSE;
		}
		if (*p==']') p++;
		else return FALSE;
		strncpy_(mypad,getArrayStr(ns,vn[ns].dim,val),COMPSTR);
		_datatype=getArrayVal(ns,vn[ns].dim,val);
	}
	/* case of any other variable in string() */
	else if ((ns=findDEC(p)) && vn[ns].datatype!=ARRAY) {
		char *pb=p;
		p+=_len; // skip var name
		while (isblank(*p)) p++;
		_datatype=vn[ns].datatype;
		if (_datatype>PREDEF) _datatype-=PREDEF;
		/* number or string */
		if (_datatype==STRING && !vn[ns].str[0]) {
			if (isop(p)) {
				double val;
				p=pb;
				val=S();
				snprintf(mypad,COMPSTR,"%.15G",val);
				if (parseInt(mypad)) _datatype=INTEGER;
				else _datatype=REAL;
				/* revert to the previous result */
				if (notAMathExpression) {
					p=pb;
					_datatype=STRING;
					strncpy_(mypad,vn[ns].str,COMPSTR);
				}
			}
		}
		else if (_datatype<CODE) {
			strncpy_(mypad,vn[ns].str,COMPSTR);
		}
		else if (_datatype==CODE) {
			strncpy_(mypad,vn[ns].proto,COMPSTR);
		}
		/* DATA */
		else if (_datatype==DATA) {
			strncpy_(mypad,vn[ns].str,COMPSTR);
		}
		//else return FALSE;
	}
	else return FALSE;

	/* detect type */
	if (mypad[0]) {
		char *y;
		strtod(mypad,&y);
		if (!*y) {
			if (parseInt(mypad)) _datatype=INTEGER;
			else _datatype=REAL;
		}
	}
	//else _datatype=STRING;

	return TRUE;
} // end of string()


/* flag()
 * evaluates the flag function under the program counter,
 * altering report on the need.
 * Return TRUE for a correct evaluation, FALSE if no flag function was found.
 * Used in SS() and JP()
 * Note: these functions return always the empty string */
int flag(void) {
	/* IDENT() function
	 * flag function: check string equality */
	if (!strncasecmp_(p,"IDENT(",6)) {
		char op1[COMPSTR];
		char op2[COMPSTR];
		int t1,t2;
		p+=6;
		strncpy_(op1,AS(),COMPSTR);
		t1=_datatype;
		if (!strlen(op1)) t1=STRING;
		if (*p==',') {
			p++;
			strncpy_(op2,AS(),COMPSTR);
			t2=_datatype;
			if (!strlen(op2)) t2=STRING;
		}
		else if (*p==')') {
			op2[0]='\0';
			t2=STRING;
		}
		if (report) report=strcomp(op1,op2) && t1==t2;
		if (*p==')') p++;
	}
	/* DIFFER() function
	 * flag function: check string inequality */
	else if (!strncasecmp_(p,"DIFFER(",7)) {
		char op1[COMPSTR];
		char op2[COMPSTR];
		int t1,t2;
		p+=7;
		strncpy_(op1,AS(),COMPSTR);
		t1=_datatype;
		if (!strlen(op1)) t1=STRING;
		if (*p==',') {
			p++;
			strncpy_(op2,AS(),COMPSTR);
			t2=_datatype;
			if (!strlen(op2)) t2=STRING;
		}
		else if (*p==')') {
			strncpy_(op2,VOIDS,COMPSTR);
			t2=STRING;
		}
		if (report) report=!(strcomp(op1,op2) && t1==t2);
		if (*p==')') p++;
	}
	/* IF string function
	 * evaluates the arguments,
	 * if the evaluates succeeds return nothing, even if a value was found;
	 * if the evaluation fails, fail silently without generating errors. */
	else if (!strncasecmp_(p,"IF(",3)) {
		char op[COMPSTR]; // dummy
		int state; // dummy
		p+=3;
		isIF=TRUE;
		/* try with JP() */
		strncpy_(op,JP(&state),COMPSTR);
		if (*p==')') p++;
	}
	/* INTEGER() Integer function
	 * flag function: check if argument is integer */
	else if (!strncasecmp_(p,"INTEGER(",8)) {
		char temp[COMPSTR];
		int status;
		p+=8;
		strncpy_(temp,GP(&status),COMPSTR);
		if (!temp[0]);
		else if (report) report=(status==INTEGER);
		if (*p==')') p++;
	}
	/* EQ() Equal function
	 * flag function: check numeric and type equality */
	else if (!strncasecmp_(p,"EQ(",3)) {
		double d1=0.0, d2=0.0;
		int t1=0, t2=0;
		p+=3;
		while (isblank(*p)) p++;
		d1=S();
		t1=_exprtype;
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			d2=S();
			t2=_exprtype;
		}
		if (*p==')') p++;
		if (report) report= (d1==d2) && (t1==t2);
	}
	/* NE() Not Equal function
	 * flag function: check numeric or type inequality */
	else if (!strncasecmp_(p,"NE(",3)) {
		double d1=0.0, d2=0.0;
		int t1=0, t2=0;
		p+=3;
		while (isblank(*p)) p++;
		d1=S();
		t1=_exprtype;
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			d2=S();
			t2=_exprtype;
		}
		if (*p==')') p++;
		if (report) report= (d1!=d2) || (t1!=t2);
	}
	/* LT() Lesser Than function
	 * flag function: check numeric order */
	else if (!strncasecmp_(p,"LT(",3)) {
		double d1=0.0, d2=0.0;
		p+=3;
		while (isblank(*p)) p++;
		d1=S();
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			d2=S();
		}
		if (*p==')') p++;
		if (report) report=(int)(d1<d2);
	}
	/* LE() Lesser Than or Equal function
	 * flag function: check numeric order */
	else if (!strncasecmp_(p,"LE(",3)) {
		double d1=0.0, d2=0.0;
		int t1=0, t2=0;
		p+=3;
		while (isblank(*p)) p++;
		d1=S();
		t1=_exprtype;
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			d2=S();
			t2=_exprtype;
		}
		if (*p==')') p++;
		if (report) report=(d1<d2) || (d1==d2 && t1==t2);
	}
	/* GT() Greater Than function
	 * flag function: check numeric order */
	else if (!strncasecmp_(p,"GT(",3)) {
		double d1=0.0, d2=0.0;
		p+=3;
		while (isblank(*p)) p++;
		d1=S();
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			d2=S();
		}
		if (*p==')') p++;
		if (report) report=(int)(d1>d2);
	}
	/* GE() Greater Than or Equal function
	 * flag function: check numeric order */
	else if (!strncasecmp_(p,"GE(",3)) {
		double d1=0.0, d2=0.0;
		int t1=0, t2=0;
		p+=3;
		while (isblank(*p)) p++;
		d1=S();
		t1=_exprtype;
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			d2=S();
			t2=_exprtype;
		}
		if (*p==')') p++;
		if (report) report=(d1>d2) || (d1==d2 && t2==t1);
	}
	/* LGT() function
	 * flag function: check string order
	 * Lexicographically Greater */
	else if (!strncasecmp_(p,"LGT(",4)) {
		char op1[COMPSTR];
		char op2[COMPSTR];
		p+=4;
		while (isblank(*p)) p++;
		strncpy_(op1,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (*p==',') {
			p++;
			while (isblank(*p)) p++;
			strncpy_(op2,AS(),COMPSTR);
			while (isblank(*p)) p++;
		}
		else if (*p==')') strncpy_(op2,"",COMPSTR);
		if (report) report=(strcmp(op1,op2))>0;
		if (*p==')') p++;
	}
	/* EOI() function
	 * check for file EOF */
	else if (!strncasecmp_(p,"EOI(",4)) {
		char fname[COMPSTR];
		FILE *fd;
		int ch=2, res=0;
		p+=4;
		strncpy_(fname,AS(),COMPSTR);
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				fd=channel[ch].stream;
				if (fd==stdin || fd==stdout || fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				else res=feof(fd);
				break;
			}
			ch++;
		}
		if (ch>fileTOS)  perror_(__LINE__,44,l);
                if (report) report=res;
		if (*p==')') p++;
	}
	/* FILE() function
	 * check for file existence */
	else if (!strncasecmp_(p,"FILE(",5)) {
		char fnam[COMPSTR];
		p+=5;
		strncpy_(fnam,process(AS()),COMPSTR);
		if (report) report=access(fnam, F_OK)==0;
		if (*p==')') p++;
	}
	else return FALSE;
	return TRUE;
} // end of flag()


/* unveil()
 * return the input string str substituting predefined variables and pattern
 * variables with their content (for instance, &ARB instead of ARB)
 * Note: str is of length << COMPSTR*/
char *unveil(char *str) {
	char mypad[COMPSTR], temp[COMPSTR], *mm=temp;
	char *bstr=str;
	int ns=0, acted=FALSE;
	strncpy_(mypad,VOIDS,COMPSTR);
	strncpy_(temp,VOIDS,COMPSTR);

	/* case of null string */
	if (!*str) {
		unveilSays=FALSE;
		strncpy_(UVPAD,mypad,COMPSTR);
        	return UVPAD;
	}

	while (*str && (int)(str-bstr)<COMPSTR) {
		/* literal strings */
		if (*str=='\"' || *str=='\'') {
			char q=*str;
			*mm++=*str++;
			while (*str && *str!=q) *mm++=*str++;
			*mm='\0';
			if (*str==q) *mm++=*str++;
			*mm='\0';
		}
		/* dot and dollar assignment */
		else if ((*str=='.' || *str=='$') && isblank(*(str+1))) {
			*mm++=*str++;
			while (isblank(*str)) *mm++=*str++;
			while (*str && !isblank(*str)) *mm++=*str++;
			*mm='\0';
		}
		/* 'at' assignment */
		else if (*str=='@' && !isblank(*(str+1))) {
			*mm++=*str++;
			while (*str && !isblank(*str)) *mm++=*str++;
			*mm='\0';
		}
		/* star items */
		else if (*str=='*' && !isblank(*(str+1))) {
			*mm++=*str++;
			while (*str && !isblank(*str)) *mm++=*str++;
			*mm='\0';
		}
		/* identifiers */
		else if (isbeginnamechar(str)) {
			/* copy body */
			while (isnamechar(str)) *mm++=*str++;
			*mm='\0';
			/* case of Snobol4 function */
			if (*str=='(') {
				char pad[COMPSTR], *q=pad;
				int st=0;
				*mm++=*str++; // copy (
				*mm='\0';
				while (*str && *str!=')') {
					if (*str=='(') st++;
					else if (*str==')' && st) st--;
					else if (*str==')' && !st) break;
					*q++=*str++;
				}
				*q='\0';
				strncpy_(pad,unveil(pad),COMPSTR);
				mm+=strlen(pad);
				strncat_(temp,pad,COMPSTR);
				if (*str==')') *mm++=*str++;
				*mm='\0';
			}
			/* case of Snobol4 array */
			else if (*str=='[') {
				char pad[COMPSTR], *q=pad;
				int st=0;
				*mm++=*str++; // copy (
				*mm='\0';
				while (*str && *str!=']') {
					if (*str=='[') st++;
					else if (*str==']' && st) st--;
					else if (*str==']' && !st) break;
					*q++=*str++;
				}
				*q='\0';
				strncpy_(pad,unveil(pad),COMPSTR);
				mm+=strlen(pad);
				strncat_(temp,pad,COMPSTR);
				if (*str==']') *mm++=*str++;
				*mm='\0';
			}
			/* case of natural variable without adornments */
			else {
				int type;
				ns=searchDEC(temp,decCount);
				if (ns>sDefVar) {
					type=vn[ns].datatype;
					if (type>PREDEF) type-=PREDEF;
					if (type==PATTERN) {
						strncpy_(temp,"(",COMPSTR);
						strncat_(temp,vn[ns].str,COMPSTR);
						strncat_(temp," )",COMPSTR);
					}
					else if (type==STRING && !strchr(vn[ns].str,'\'')) {
						strncpy_(temp,"\'",COMPSTR);
						strncat_(temp,vn[ns].str,COMPSTR);
						strncat_(temp,"\'",COMPSTR);
						acted=TRUE;
					}
					else if (type==STRING && !strchr(vn[ns].str,'\"')) {
						strncpy_(temp,"\"",COMPSTR);
						strncat_(temp,vn[ns].str,COMPSTR);
						strncat_(temp,"\"",COMPSTR);
						acted=TRUE;
					}
					else if (type==STRING && strchr(vn[ns].str,'\"') &&\
							strchr(vn[ns].str,'\'')) {
						char host[2*COMPSTR+2], *h=host, *s=vn[ns].str;
						while (*s) {
							if (*s=='\'') *h++='\'';
							*h++=*s++;
						}
						*h='\0';
						strncpy_(temp,"\'",COMPSTR);
						strncat_(temp,host,COMPSTR);
						strncat_(temp,"\'",COMPSTR);
						acted=TRUE;
					}
					else if (type<=CODE) {
						strncpy_(temp,vn[ns].str,COMPSTR);
					}
					/* TODO consider if NAME returns [].str or [].name */
				}
				else if (ns>0) {
					strncpy_(temp,vn[ns].str,COMPSTR);
					acted=TRUE;
				}

				/* else temp retains the original name */
			}
		}
		/* the single open/closed parenthesis must be copied */
		else if (*str=='(' || *str==')') {
			*mm++=*str++;
			*mm='\0';
		}
		/* blanks */
		else if (isblank(*str)) {
			while (isblank(*str)) *mm++=*str++;
			*mm='\0';
		}
		/* in case of = copy until the end
		 * Note: otherwise unveil() changes also variables that may happen 
		 * after the equal sign, making impossible using them if they are 
		 * instantiated during the pattern evaluation itself */
		else if (*str=='=') {
			while (*str) *mm++=*str++;
			*mm='\0';
		}
		/* anything else */
		else {
			while (*str && !isblank(*str)) *mm++=*str++;
			*mm='\0';
		}
		/* catenate */
		strncat_(mypad,temp,COMPSTR);
		if (!*str) break;
		mm=temp;
	}
	if (!acted) unveilSays=FALSE;
	strncpy_(UVPAD,mypad,COMPSTR);
       	return UVPAD;
} // end of unveil()


/* findNext()
 * search for the | sign after position p
 * return the position of | if found, NULL otherwise */
char *findNext(char *p) {
	int st=0;
	char *res=NULL;
	while (*p) {
		if (*p=='|') {
			res=p;
			break;
		}
		else if (*p=='(') {
			st=0;
			p++;
			while (*p) {
				if (*p=='(') st++;
				else if (*p==')' && st) st--;
				else if (*p==')' && !st) break;
				p++;
			}
			//if (*p==')') p++;
		}
		if (*p==')' || *p=='=' || *p==':') break;
		p++;
	}
	return res;
}


/* skipAlt()
 * skip all items of an alternation */
void skipAlt(void) {
	int st=0;
	while (*p && *p!='=' && *p!=':') {
		if (*p=='(') st++;
		else if (*p==')' && st) st--;
		else if (*p==')' && !st) {
			break;
		}
		p++;
	}
}


/* printLine()
 * print extended debug introductory line */
void printLine(void) {
	printf("\nline\tscan\tmatch\t\tstatus\taltern.\talt scan\tnext scan\tpattern\n");
	printf("---------------------------------------------------------------------------------------\n");

}


/* printWhite()
 * print the scan/match portion and the matching status */
void printWhite(int scan, char *match, char *mm) {
	int len=strlen(match);
	if (len<16)
		printf("L%d\t%d\t%-16s%s%s\t",l,scan,match[0]?match:"/",mm?GREENCOLOR:REDCOLOR,mm?"V":"NO");
	else
		printf("L%d\t%d\t%-.12s%s %s%s\t",l,scan,match[0]?match:"/","...",mm?GREENCOLOR:REDCOLOR,mm?"V":"NO");
}


/* printGet()
 * get the user input and in case of a command, perform it */
void printGet(void) {
	char inp[COMPSTR];
	strncpy_(inp,getString(TRUE),COMPSTR);
	if (tolower(inp[0])=='l') {
		int pos=strlen(FIRST) + 2, k;
		printf("\n%s  %s\n",FIRST,second);
		pos+=(int)(p-second);
		k=0;
		while (k<pos) fputc(' ',stdout), k++;
		fputc('^',stdout);
		fputc('\n',stdout);
		printf("											");
		printGet();
	}
	else if (tolower(inp[0])=='c') {
		fputc('\n',stdout);
		isExDebug=FALSE;
	}
	else if (tolower(inp[0])=='q') {
		fputc('\n',stdout);
		isExDebug=FALSE;
		isDebug=FALSE;
		printf("\nsoft debug: End of session. Ok.\n\n");
		END(procCode);
	}
	else if (tolower(inp[0])=='g') {
		fputc('\n',stdout);
		isDebug=FALSE;
		isExDebug=FALSE;
	}
}


/* printColor()
 * print the final colored part and ask for user */
void printColor(char *COLOR, char *next, int nextscan, int scan, char *pattern, int isFail) {
	char out[COMPSTR], len[COMPSTR];
	if (strlen(pattern)>10) {
		snprintf(out,COMPSTR,"%-.10s",pattern);
		strncat_(out,"...",COMPSTR);
	}
	else strncpy_(out,pattern,COMPSTR);
	if (*pattern) strncat_(out," ",COMPSTR);
	snprintf(len,COMPSTR,"[%d]",(int)strlen(pattern));
	strncat_(out,len,COMPSTR);
	printf("%s",COLOR);
	printf("%.6s\t%d\t\t%d\t\t%s\t",next?next:"/",next?nextscan:0,scan,out);
	printf("%s",RESETCOLOR);
	if (isFail) printf("*");
	if (fenceNeedle) {
		if (p<=fenceNeedle) printf("#");
	}
	if (!isCommandDebug) printGet();
	else printf("\n");
}


/* scanner()
 * the main scanning procedure for the Snobol4 evaluation
 * FIRST is the base string passed
 * second is the base matching command, with all variables unveiled
 * match is the container of the match
 * mm is the pointer to the match, or NULL in case of no-match
 * Return the final pattern
 * written by Antonio Maschio - November 2020/January 2021 */
char *scanner(char *FIRST, char *second, char **mm) {
	char *next[MAXARGS+1], lastmatch[COMPSTR];
	int nextscan[MAXARGS+1], nextTOS=0;
	int nextParOrder[MAXARGS], nextDotTOS[MAXARGS], i;
	char match[COMPSTR], pattern[COMPSTR], nextPattern[MAXARGS][COMPSTR];
	char *up, *mp;
	int uscan=0, udotTOS=0, uparOrder=0;
	int failIntervention=FALSE, exDebugOff=FALSE;

	/* initialize */
	for (i=0;i<MAXARGS; i++)
		next[i]=NULL, nextscan[i]=nextParOrder[i]=nextDotTOS[i]=0;
	parOrder=0;
	strncpy_(pattern,VOIDS,COMPSTR);
	p=second;

	/* option -p/--pattern-debug */
	if (isCommandDebug) isExDebug=TRUE;
	/* search for breakpoints */
	else if (isDebug) {
		for (i=1;i<=breakTOS;i++) {
			if (breaks[i]==l) {
				isExDebug=TRUE;
				break;
			}
		}
	}

	/* EXTENDED DEBUG */
	if (isExDebug && *p && report && rightPos) printLine();

	/* the real scanning process */
	while (p && *p && !isQuit) {	// Note: isQuit is necessary
		int myuscan=0, myudotTOS=0, myuparOrder;
		char *myup=second, myupattern[COMPSTR];
		failIntervention=exDebugOff=FALSE;
		rightPos=TRUE;
		myuscan=scan;
		myuparOrder=parOrder;
		myudotTOS=dotTOS;
		strncpy_(myupattern,pattern,COMPSTR);
		while (isblank(*p)) p++;

		/* check FENCE limit */
		if (fenceNeedle) {
			if (p<=fenceNeedle) {
				report=FALSE;
				break;
			}
		}

		if (!*p || *p=='=' || *p==':') {
			break;
		}
		if (*p=='(') {
			p++; // skip (
			while (isblank(*p)) p++;
			parOrder++;
			if (parOrder<PSTACK)
				strncpy_(parNext[parOrder],VOIDS,COMPSTR);
			else perror_(__LINE__,109,l);
			continue;
		}
		if (*p==')') {
			p++; // skip )
			while (isblank(*p)) p++;
			while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
					(*p=='@' && !isblank(*(p+1)))) {
				if (parNext[parOrder][0]) {
					evalDollar(parNext[parOrder]);
					evalDot(parNext[parOrder]);
				}
				else {
					evalDollar(myupattern);
					evalDot(myupattern);
				}
				evalAt();
				while (isblank(*p)) p++;
			}
			parOrder--;
			if (parOrder<0) parOrder=0;
			continue;
		}

		/* next is an implicit assignment */
		while (isblank(*p)) p++;
		while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
				(*p=='@' && !isblank(*(p+1)))) {
			if (parNext[parOrder][0]) {
				evalDollar(parNext[parOrder]);
				evalDot(parNext[parOrder]);
			}
			else {
				evalDollar(myupattern);
				evalDot(myupattern);
			}
			evalAt();
			while (isblank(*p)) p++;
		}

		/* check if next is a rightPos influencer */
		myup=p;
		if (!strncasecmp_(p,"FAIL",4) || !strncasecmp_(p,"&FAIL",5)) {
			failIntervention=TRUE;
		}
		else if (!strncasecmp_(p,"POS(",4)||!strncasecmp_(p,"RPOS(",5)){
			failIntervention=TRUE;
		}

		if (*p=='(') exDebugOff=TRUE;

		/* test match */
		mp=p;
		if (*p=='=') strncpy_(match,VOIDS,COMPSTR);
		else strncpy_(match,GS(),COMPSTR);
		if (isAPattern) {
			char new[COMPSTR];
			strncpy_(new,second,(int)(mp-second+1));
			strncat_(new,match,COMPSTR);
			strncat_(new,p-1,COMPSTR);
			strncpy_(second,new,COMPSTR);
			p=mp;
			isAPattern=FALSE;
			continue;
		}
		*mm=strstr_(CFIRST,match);

		/* EXTENDED DEBUG */
		if (isExDebug && !exDebugOff) printWhite(scan,match,*mm);

		/* MATCH! */
		if (*mm) {
			int i;
			/* set up match-yes variables */
			failIntervention=FALSE;
			uscan=myuscan;
			uparOrder=myuparOrder;
			up=myup;
			udotTOS=myudotTOS;
			strncpy_(upattern,myupattern,COMPSTR);
			uscan=scan;
			scan+=strlen(match);
			strncat_(pattern,match,COMPSTR);
			strncpy_(upattern,pattern,COMPSTR);
			strncpy_(lastmatch,match,COMPSTR);
			/* set up parenthesis arrays */
			for (i=1;i<=parOrder;i++) {
				strncat_(parNext[i],match,COMPSTR);
			}

			/* indirect assignment */
			while (isblank(*p)) p++;
			while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
					(*p=='@' && !isblank(*(p+1)))) {
				if (*p=='$') evalDollar(match);
				else if (*p=='.') evalDot(match);
				else if (*p=='@') evalAt();
				while (isblank(*p)) p++;
			}

			/* store data of next alternation
			 * for possible future usage */
			if (*p=='|') {
				char *pp=p+1;
				while (isblank(*pp)) pp++;
				next[nextTOS]=pp;
				nextscan[nextTOS]=uscan;
				nextDotTOS[nextTOS]=dotTOS;
				nextParOrder[nextTOS]=parOrder;
				strncpy_(nextPattern[nextTOS],pattern,COMPSTR);
				skipAlt();
				while (isblank(*p)) p++;
				nextTOS++;
				if (nextTOS>=MAXARGS) perror_(__LINE__,83,l);
			}
			else {
				next[nextTOS]=NULL;
			}

			/* EXTENDED DEBUG */
			if (isExDebug && !exDebugOff) {
				printColor(GREENCOLOR,next[nextTOS],nextscan[nextTOS],scan,pattern,failIntervention);
			}
		}
		/* NO MATCH! */
		else {
			nextTOS--;
			if (nextTOS<0) nextTOS=0;
			while (isblank(*p)) p++;
			/* failure on an alternation item in case there is
			 * another item following */
			if (findNext(p)) {
				nextTOS++;
				if (nextTOS>=MAXARGS) perror_(__LINE__,83,l);
				if (!next[nextTOS]) {
					char *pp=findNext(p)+1;
					while (isblank(*pp)) pp++;
					next[nextTOS]=pp;
					nextscan[nextTOS]=scan;
					nextParOrder[nextTOS]=parOrder;
					nextDotTOS[nextTOS]=dotTOS;
				}
			}
			/* general failure: amend pattern */
			else {
				int i,len, sl=strlen(lastmatch);
				len=(int)(strlen(pattern)-sl);
				if (len<0) len=0;
				strncpy_(pattern,pattern,len+1);
				for (i=0;i<=MAXARGS;i++) {
					len=(int)(strlen(parNext[i])-sl);
					if (len<0) len=0;
					strncpy_(parNext[i],parNext[i],len+1);
				}
			}

			/* special rematch cases: */
			/* rematch for ARB/ARBNO */
			if (resTOS>=1) {
				scan=uscan=resat[resTOS];
				p=up=presat[resTOS];
				dotTOS=udotTOS=dresat[resTOS];
				/* OK upattern! */
				strncpy_(upattern,patresat[resTOS],COMPSTR);
				/* EXTENDED DEBUG */
				if (isExDebug && !exDebugOff) {
					printColor(REDCOLOR,next[nextTOS],nextscan[nextTOS],scan,pattern,failIntervention);
				}

				resTOS--;
				continue;
			}
			/* rematch with an alternation item following:
			 * this may be caused by the succeeding part
			 * (followed by FAIL or a failing command)
			 * that fixed the next item, or by the failing
			 * part above, that found a next item to try,
			 * having failed the current one. */
			else if (next[nextTOS]) {
				p=next[nextTOS];
				scan=nextscan[nextTOS];
				dotTOS=nextDotTOS[nextTOS];
				parOrder=nextParOrder[nextTOS];
				/* EXTENDED DEBUG */
				if (isExDebug && !exDebugOff) {
					printColor(REDCOLOR,next[nextTOS],nextscan[nextTOS],scan,pattern,failIntervention);
				}

				next[nextTOS]=NULL;
				continue;
			}

			/* failure in normal case:
			 * set for a match in a further position */
			else if (!tot) {
				bscan++;
				scan=bscan;
				if (uscan<scan) uscan=scan;
				p=second;
				resTOS=dotTOS=0;
				next[nextTOS]=NULL;
				for (i=0;i<=parOrder;i++) {
					strncpy_(parNext[i],VOIDS,COMPSTR);
				}
			}
			/* failure in rematch case:
			 * regain position after last match */
			else {
				int i;
				scan=uscan;
				for (i=uparOrder+1;i<=parOrder;i++) {
					strncpy_(parNext[i],VOIDS,COMPSTR);
				}
				parOrder=uparOrder;
				p=up;
				dotTOS=udotTOS;
				next[nextTOS]=NULL;
			}
			/* EXTENDED DEBUG */
			if (isExDebug && !exDebugOff) {
				printColor(REDCOLOR,next[nextTOS],nextscan[nextTOS],scan,pattern,failIntervention);
			}

			if (scan>strlen(FIRST)) report=FALSE;
			if (isAnchored && scan>0) report=FALSE;
			if (!report) {
				break;
			}
			tot=0;
		}
	}

	if (isExDebug) {
		printf("%s",RESETCOLOR);
	}

	if (isCommandDebug) {
		printf("\n");
	}

	/* remove extended debug without altering debug */
	isExDebug=FALSE;
	strncpy_(upattern,pattern,COMPSTR);
	strncpy_(SCNPAD,pattern,COMPSTR);
       	return SCNPAD;
} // end of scanner()


/* patterns()
 * the pattern rules evaluator. The rules are taken from the input stream.
 * Return the state of report (TRUE/FALSE)
 * This routine is called only if the second parameter after the first is not
 *    the '=' sign (which identifies an assignment)
 * In Snobol4, this - and the subsidiary scanner() - are the main program core
 * routines, along with assign()/GP/JP and the string routines set SS/JS
 * written by Antonio Maschio April-December 2020 */
int patterns(void) {
	char temp[COMPSTR], *mm=NULL;
	int i,ns;
	/* reset main parameters */
	report=TRUE;
	if (!goPie) {
		scan=bscan=0;
		FIRST[0]='\0';
		second[0]='\0';
	}
	fenceNeedle=NULL;
	dotTOS=0;

	/* empty flag and strings  */
	strncpy_(pattern,VOIDS,COMPSTR);
	strncpy_(upattern,VOIDS,COMPSTR);

	/* get var index in case */
	while (isblank(*p)) p++;
	ns=searchDEC(p,decCount); // save for later

	/* perform the flag functions that can be found */
	while (flag()) {
		while (isblank(*p)) p++;
		if (*p=='=' || *p==':') {
			return report;
		}
	}

	/* get base string FIRST */
	if (isdigit(*p)) {
		char *t=FIRST;
		while (isdigit(*p) || *p=='.' || *p=='-' || *p=='+' || toupper(*p)=='E') {
			*t++=*p++;
			if (t-FIRST>=COMPSTR-1) break;
		}
		*t='\0';
	}
	else if (*p=='(') {
		p++;
		strncpy_(FIRST,AS(),COMPSTR);
		if (*p==')') p++;
	}
	else strncpy_(FIRST,SS(),COMPSTR);

	/* get pattern and set it in temp */
	i=0;
	strncpy_(temp,VOIDS,COMPSTR);
	while (isblank(*p)) p++;
	if (!*p || *p==':') {
		sPatt++;
		sMatches++;
		return report;
	}
	else while (*p && i<COMPSTR-1) {
		if (*p=='\"' || *p=='\'') {
			char q=*p;
			temp[i++]=*p++; // copy quote
			while (*p && *p!=q) temp[i++]=*p++;
			if (*p==q) temp[i++]=*p++; // copy quote
			else perror_(__LINE__,21,l);
		}
		else temp[i++]=*p++;
	}
	temp[i]='\0';
	while (isblank(*p)) p++;
	/* analyze the pattern, put result in second */
	strncpy_(second,temp,COMPSTR);
	strncpy_(second,unveil(second),COMPSTR);
	unveilSays=TRUE;
	/* for Stats; */
	sPatt++;

	/* start pattern evaluation */
	tot=0;
	parOrder=0;

	/* SCANNING */
	strncpy_(pattern,scanner(FIRST,second,&mm),COMPSTR);

	/* consume final spaces */
	if (p && *p) while (isblank(*p)) p++;

	/* treat interrupt case */
	if (isInterrupt) return report;

	/* perform the dot assignments gathered so far */
	if (report && rightPos && dotTOS) {
		int z=1;
		while (z<=dotTOS) {
			/* simple variables */
			if (dotudim[z]<0) {
				int vs=dotvar[z];
				strncpy_(vn[vs].str,dotstr[z],COMPSTR);
				vn[vs].datatype=STRING;
				DO_OUTPUT(vs);
			}
			/* arrays are managed with dotval and dotudim also */
			else {
				setArrayStr(dotvar[z],dotudim[z],dotval[z],dotstr[z]);
				setArrayVal(dotvar[z],dotudim[z],dotval[z],STRING);
			}
			z++;
			checkTrace(dotvar[z]);
		}
	}

	/* indirect assignment */
	while (isblank(*p)) p++;
	while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
			(*p=='@' && !isblank(*(p+1)))) {
		if (*p=='$') evalDollar(pattern);
		else if (*p=='.') evalDot(pattern);
		else if (*p=='@') evalAt();
		while (isblank(*p)) p++;
	}
	
	/* case of required substitution */
	if (report && rightPos && *p=='=') {
		char repl[COMPSTR], new[COMPSTR];
		p++; // skip =
		while (isblank(*p)) p++;
		strncpy_(repl,AS(),COMPSTR);
		if (report) {
			/* replace the occurrence */
			char *tt=FIRST+scan-strlen(pattern);
			strncpy_(new,FIRST,(int)(tt-FIRST)+1);
			strncat_(new,repl,COMPSTR);
			strncat_(new,tt+strlen(pattern),COMPSTR);
			if (ns) {
				strncpy_(vn[ns].str,new,COMPSTR);
			}
			else perror_(__LINE__,3,l);
			checkTrace(ns);
			/* redefine some var parameters in case */
			if (!vn[ns].str[0]) vn[ns].datatype=STRING;
			else if (vn[ns].datatype<=REAL) {
				vn[ns].num=strtod(vn[ns].str,NULL);
				if (parseInt(vn[ns].str))
					vn[ns].datatype=INTEGER;
				else vn[ns].datatype=REAL;
			}
		}
	}

	if (p && *p) while (isblank(*p)) p++;

	/* reset flags */
	rightPos=TRUE;
	resTOS=0;
	return report;
} // end of patterns()


/* array()
 * The inner statement for any-name array declaration
 * Note: this function is not run-time.
 * Note: this function executes a storing only; the actual command (the
 * function interpretation and execution) is performed by findDEC(), called
 * into getFunc() and SS() for function names and in assign() for assignments,
 * and in all functions dealing with variables. */
void array(int ns) {
	char dimstr[COMPSTR], *pp;
	char init[COMPSTR];
	int dimq=1, start[MAXDIM+1], end[MAXDIM+1], i, type=0;

	/* dimensions are specified */
	if (!strncasecmp_(p,"ARRAY(",6)) {
		p+=6; // skip ARRAY(
		/* copy dimensioning string in string format */
		if (*p=='\'' || *p=='\"') {
			char *d=dimstr, q=*p++; // skip quote
			while (*p && *p!=q) *d++=*p++;
			*d='\0';
			if (*p==q) p++; // skip quote
		}
		/* copy dimensioning string (1-dim) in numeric format */
		else if (isnm(p)) {
			char *d=dimstr;
			while (*p && isnm(p)) *d++=*p++;
			*d='\0';
		}
		else
		strncpy_(dimstr,AS(),COMPSTR);
		if (*p==')') {
			p++; // skip closing )
			strncpy_(init,VOIDS,COMPSTR);
		}
		else if (*p==',') {
			p++; // skip comma
			strncpy_(init,AS(),COMPSTR);
			type=_datatype;
			if (*p==')') p++; // skip closing )
		}
		else perror_(__LINE__,32,l);
		/* process string */
		pp=p;
		p=dimstr;
		start[dimq]=1;
		end[dimq]=(int)S();
		if (*p==':') {
			start[dimq]=end[dimq];
			p++; // skip :
			end[dimq]=(int)S();
		}
		if (end[dimq]<start[dimq]) perror_(__LINE__,34,l);
		/* from second dimension on*/
		while (*p==',') {
			p++; // skip comma
			dimq++;
			start[dimq]=1;
			end[dimq]=(int)S();
			if (*p==':') {
				start[dimq]=end[dimq];
				p++; // skip :
				end[dimq]=(int)S();
			}
			if (end[dimq]<start[dimq]) perror_(__LINE__,34,l);
		}
		p=pp;
	}
	/* these are not simple variables! */
	else perror_(__LINE__,33,l);

	/* build prototype */
	i=1;
	strncpy_(dimstr,VOIDS,COMPSTR);
	while (i<=dimq) {
		char temp[COMPSTR];
		snprintf(temp,COMPSTR,"%d:%d",start[i],end[i]);
		if (i!=dimq) strncat_(temp,",",COMPSTR);
		strncat_(dimstr,temp,COMPSTR);
		i++;
	}
	/* build common attributes */
	strncpy_(vn[ns].proto,dimstr,COMPSTR);
	vn[ns].datatype=ARRAY;
	vn[ns].dim=dimq;
	vn[ns].strmem=COMPSTR;
	for (i=1;i<=dimq;i++) {
		vn[ns].ldim[i]=end[i]-start[i];
		vn[ns].offset[i]=start[i];
	}
	vn[ns].coeff[dimq]=1;
	for (i=dimq-1;i>=1;i--) {
		vn[ns].coeff[i]=vn[ns].coeff[i+1]*(vn[ns].ldim[i+1]+1);
	}
	/* dimension array */
	vn[ns].size=dimStrArray(ns,dimq,vn[ns].ldim, init,type);
} // end of array()


/* checkBal()
 * check balancing of parenthesis and square brackets */
int checkBal(char *str) {
	int st=0, qst=0;
	while (*str) {
		if (*str=='\"' || *str=='\'') {
			char q=*str;
			str++;
			while (*str && *str!=q) str++;
		}
		else if (*str=='(') st++;
		else if (*str==')') st--;
		else if (*str=='[') qst++;
		else if (*str==']') qst--;
		str++;
	}
	if (st || qst) return FALSE;
	return TRUE;
}


/* find_assign()
 * find object to be assigned starting from position pl
 * return in pb the updated position
 * complete contains the complete name
 * isArr is TRUE if the element is an array element
 * udim and val[] pertain to the array element */
int find_assign(char *pl, char **pb, char *complete, int *isArr, int *udim, int val[]) {
	int ns=0;
	char num[COMPSTR], *bp;
	if ((ns=findDEC(pl))) {
		pl+=_len;
		strncpy_(complete,vn[ns].name,COMPSTR);
	}
	else {
		char temp[COMPSTR], *t=temp;
		while (!isblank(*pl)) *t++=*pl++;
		*t='\0';
		strncpy_(complete,temp,COMPSTR);
	}
	/* check for array */
	if (*pl=='[' && vn[ns].datatype==ARRAY) {
		ns=vn[ns].ref;
		*udim=1;
		strncat_(complete,"[",COMPSTR);
		pl++; // skip [
		bp=p;
		p=pl;
		val[*udim]=(int)S();
		pl=p;
		p=bp;
		snprintf(num,COMPSTR,"%d",val[*udim]);
		strncat_(complete,num,COMPSTR);
		if (val[*udim]<vn[ns].offset[*udim] || val[*udim]>vn[ns].ldim[*udim]+vn[ns].offset[*udim]) {
			sErr=57;
			lErr=l;
			return report=FALSE;
		}

		while (*pl==',') {
			pl++;
			strncat_(complete,",",COMPSTR);
			(*udim)++;
			if (*udim>vn[ns].dim) perror_(__LINE__,52,l);
			bp=p;
			p=pl;
			val[*udim]=(int)S();
			pl=p;
			p=bp;
			snprintf(num,COMPSTR,"%d",val[*udim]);
			strncat_(complete,num,COMPSTR);
			if (val[*udim]<vn[ns].offset[*udim] || val[*udim]>vn[ns].ldim[*udim]+vn[ns].offset[*udim]) {
				sErr=57;
				lErr=l;
				return report=FALSE;
			}

		}
		if (*pl==']') {
			pl++;
			strncat_(complete,"]",COMPSTR);
		}
		else return report=FALSE;
		*isArr=TRUE;
		/* Rif. ch. 7A Arrays, page 107-108, where it is stated:
		 * "Although [... LIST[1] = ARRAY('1000')...] creates
		 * an array of 1000 items and assigns it to as the value
		 * [of the variable 'LIST[1]'], the items of [this array]
		 * may not be referred to in the usual manner, since there
		 * is a restriction that the family part of an item reference
		 * must be a name in identifier form.  */
		if (*pl=='[') perror_(__LINE__,57,l); // ok 60
	}
	else *isArr=FALSE;
	if (pb) *pb=pl;
	return ns;
}


/* classicVar()
 * check if the string pointed by pl contains an implemented '&'-variable */
int classicVar(char *pl) {
	int i=ATNUM;
	while (i>0) {
		if (!strncasecmp_(pl,classic[i],strlen(classic[i]))) {
			return TRUE;
		}
		i--;
	}
	return FALSE;
}


/* assign()
 * The assign subroutine: assign a number, a string or a pattern to a variable.
 * Enhanced for ARRAY, CODE, DATA
 * variable name is taken from input string.
 * return TRUE if assignment went OK, false otherwise.
 * written by Antonio Maschio April-December 2020, and January 2021 */
int assign(void) {
	int ns=0, state=0, isArr=FALSE, vlim=sDefVar;
	int val[MAXDIM+1], udim=1;
	char *pb;
	char complete[COMPSTR];
	char itemside[COMPSTR];
	sLast=l; // for Stats
	complete[0]='\0';

	/* evaluate starting flag functions */
	while (report && flag());
	if (!report) return report;
	else {
		while (isblank(*p)) p++;
		if (!*p || *p==':') return TRUE;
	}
	
	/* reach the point */
	while (isblank(*p)) p++;
	pb=BASETOT=p;

	/* check balancing */
	if (!checkBal(p)) {
		perror_(__LINE__,56,l);
		return report=FALSE;
	}

	/* in case there is a multiple string collection, it is not
	 * an assignment, so proceed with pattern */
	if (*p=='(') return report=patterns();

	/* in case *p = '&' it is a system var assignment that
	 * must be coordinated through string() */
	if (*p=='&' && !classicVar(p)) {
		char pad[COMPSTR]; // dummy
		int state;
		strncpy_(pad,GP(&state),COMPSTR);
		return report=patterns();
	}
	/* unevaluated & means assignments on &VAR: wrong */
	if (*p=='&') {
		char *pp=p;
		while(!isblank(*pp)) pp++;
		while(isblank(*pp)) pp++;
	       	if (!*pp || *pp=='=' || *pp==':') {
			if (!classicVar(pp)) perror_(__LINE__,64,l);
			else perror_(__LINE__,67,l);
		}
	}

	/* in case there's no equal sign (out of a possible string),
	 * it's certainly not an assignment */
	if (!strcasechr_oq(p,'=')) return report=patterns();

	/* evaluate the user NRETURN function */
	if ((ns=findPROC(p))) {
		char strres[COMPSTR];
		int ftype;
		p=define(ns,strres,&ftype);
		if (!nreturnActed || ftype!=NAME) perror_(__LINE__,27,l);
		nreturnActed=FALSE;
		/* search NAME variable */
		ns=decCount;
		while (ns>0) {
			if (!strcasecmp(strres,vn[ns].name))
				break;
			ns--;
		}
		if (!ns) {
			declare(strres,STRING,FALSE,0,0);
			ns=decCount;
		}
	}
	/* find variable to be assigned */
	/* a. manage the indirect referencing on assignment */
	else if (*p=='$' && *(p+1) && !isblank(*(p+1))) {
		char temp[COMPSTR];

		p++; // skip $
		if (*p=='(') {
			p++; // skip (
			strncpy_(temp,GS(),COMPSTR);
			if (*p==')') p++;
			ns=decCount;
			while (ns>0) {
				if (!strcasecmp(temp,vn[ns].name))
					break;
				ns--;
			}
			if (ns<1) {
				declare(temp,STRING,FALSE,0,0);
				ns=decCount;
			}
		}
		else {
			/* first reading: */
			ns=searchDEC(p,decCount);
			if (ns && vn[ns].datatype==NAME) {
				p+=_len;
				ns=find_assign(vn[ns].str, NULL, complete, &isArr, &udim, val);
				if (!ns) return report=FALSE;
			}
			/* copy reference variable */
			else {
				if (isquote(p)) {
					char *t=temp, q=*p++;
					while (*p && *p!=q) *t++=*p++;
					*t='\0';
					if (*p==q) p++;
				}
				else strncpy_(temp,GS(),COMPSTR);
				/* search reference variable */
				ns=decCount;
				while (ns>0) {
					if (!strncasecmp_(temp,vn[ns].name,strlen(vn[ns].name)))
						break;
					ns--;
				}
				/* assign() */
				if (ns<1) {
					declare(temp,STRING,FALSE,0,0);
					ns=decCount;
				}
			}
		}
	}
	/* b. manage the APPLY side */
	else if (!strncasecmp_(p,"APPLY(",6)) {
		char sel[COMPSTR];
		char temp[COMPSTR];
		int fns=0;
		p+=6;
		strncpy_(sel,AS(),COMPSTR);
		if (*p==',') p++;
		else return report=FALSE;
		fns=searchDEC(p,decCount);
		p+=_len;
		while (isblank(*p)) p++;
		if (*p==')') p++;
		snprintf(temp,COMPSTR,"%s",sel);
		strncat_(temp,"(",COMPSTR);
		strncat_(temp,vn[fns].name,COMPSTR);
		strncat_(temp,")",COMPSTR);
		ns=findDEC(temp);//,decCount);
		if (!ns) return report=FALSE;
	}
	/* c. manage the ITEM side */
	else if (!strncasecmp_(p,"ITEM(",5)) {
		char name[COMPSTR], *n=name, tval[COMPSTR];
		int val[MAXDIM+1], T=0, i=1;
		p+=5;
		/* get name of array */
		while (*p && *p!=')' && *p!=',') *n++=*p++;
		*n='\0';
		ns=searchDEC(name,decCount);
		if (!ns) perror_(__LINE__,64,l);
		if (vn[ns].datatype!=ARRAY) perror_(__LINE__,57,l);
		if (*p!=',') perror_(__LINE__,38,l);
		else p++; // skip comma
		while (*p && *p!=')') {
			if (isdigit(*p)) {
				T++;
				val[T]=S();
			}
			else {
				char *tt=tval;
				strncpy_(tt,SS(),COMPSTR);
				while (*tt) {
					T++;
					val[T]=strtol(tt,&tt,10);
					if (*tt==',') tt++;
				}
			}
			if (*p==',') p++;
		}
		if (*p==')') p++;
		strncpy_(itemside,name,COMPSTR);
		strncat_(itemside,"[",COMPSTR);
		while(i<=T) {
			snprintf(tval,COMPSTR,"%d",val[T]);
			strncat_(itemside,tval,COMPSTR);
			if (i < T) strncat_(itemside,",",COMPSTR);
			i++;
		}
		strncat_(itemside,"]",COMPSTR);
		strncat_(itemside,p,COMPSTR);
		p=itemside;
		ns=find_assign(p, &p, complete, &isArr, &udim, val);
		if (!ns) return report=FALSE;
	}
	/* d. manage the simple variable name */
	else {
		ns=find_assign(p, &p, complete, &isArr, &udim, val);
		if (!ns) {
			perror_(__LINE__,91,l);
			return report=FALSE;
		}
	}

	/* calculate value to be assigned
	 * predefined variables are protected if isToAlter==FALSE */
	if (isToAlter) vlim=0;
	if (ns>vlim) {
		char temp[COMPSTR];
		int k=0;
		/* erase temp */
		for (k=0;k<COMPSTR;k++) temp[k]='\0';

		/* if there is no equal sign, try with a pattern again*/
		while (isblank(*p)) p++;
		if (*p!='=') {
			p=pb;
			while (isblank(*p)) p++;
			return report=patterns();
		}
		else p++; // skip =

		/* detect the NULL case */
		while (isblank(*p)) p++;
		if (!*p || *p==':') {
			state=STRING;
			strncpy_(temp,"",COMPSTR);
		}
		/* a REAL introduced by its decimal dot */
		else if (*p=='.' && *(p+1) && isdigit(*(p+1))) {
			snprintf(temp,COMPSTR,"%15g",S());
			if (!notAMathExpression) {
				state=REAL;
				while (isblank(*p)) p++;
			}
		}
		/* detect the literal NAME assignment */
		else if (*p=='.' && *(p+1) && !isblank(*(p+1)) && isbeginnamechar(p+1)) {
			char *t=temp;
			p++; // skip dot
			while (isnamechar(p)) *t++=*p++;
			if (*p=='(') {
				int st=0;
				*t++=*p++; // copy (
				while (*p) {
					if (*p=='(') st++;
					else if (*p==')' && st) st--;
					else if (*p==')' && !st) break;
					*t++=*p++;
				}
				if (*p==')') *t++=*p++;
				*t='\0';
			}
			else if (*p=='[') {
				int d;
				char num[COMPSTR];
				*t++=*p++;
				*t='\0';
				d=(int)S();
				snprintf(num,COMPSTR,"%d",d);
				strncat_(temp,num,COMPSTR);
				t=temp+strlen(temp);
				while (*p==',') {
					*t++=*p++;
					*t='\0';
					d=(int)S();
					snprintf(num,COMPSTR,"%d",d);
					strncat_(temp,num,COMPSTR);
					t=temp+strlen(temp);
				}
				if (*p==']') *t++=*p++;
				*t='\0';
			}
			else *t='\0';
			vn[ns].datatype=NAME;
			vn[ns].ref=ns;
			strncpy_(vn[ns].str,temp,COMPSTR);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			if (*p && *p!='=' && *p!=':')
				perror_(__LINE__,91,l);
			return report;
		}
		/* it's a DATA element copy ref */
		else if ((k=findDEC(p)) && vn[k].datatype==DATA) {
			p+=_len;
			vn[ns].datatype=DATA;
			vn[ns].ref=k;
			strncpy_(vn[ns].str,vn[k].str,COMPSTR);
			vn[ns].dim=vn[k].dim;
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			return report;
		}
		/* it's a constructor for DATA */
		else if ((k=findDATA(p))) {
			p+=_len;
			data(ns,k);
			vn[ns].datatype=DATA;
			vn[ns].dim=k;
			strncpy_(vn[ns].proto,datafunc[dataTOS].proto,COMPSTR);
			snprintf(vn[ns].str,COMPSTR,"%d",k);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			return report;
		}
		/* it's an indirect one-to-one ARRAY assignment */
		else if ((k=findHidden(p))) {
			vn[ns].datatype=ARRAY;
			vn[ns].ref=k;
			snprintf(vn[ns].str,COMPSTR,"%d",k);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			return report;
		}
		/* it's a direct one-to-one ARRAY assignment */
		else if ((k=findARRAY(p))) {
			vn[ns].datatype=ARRAY;
			vn[ns].ref=k;
			snprintf(vn[ns].str,COMPSTR,"%d",k);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			return report;
		}
		/* it's a CODE attribution */
		else if (!strncasecmp_(p,"CODE(",5)) {
			p+=5; // skip CODE(
			strncpy_(vn[ns].proto,code(),COMPSTR);
			vn[ns].datatype=CODE;
			vn[ns].ref=finalCore+1; // start of code
			vn[ns].dim=endCore;	// end of code
			snprintf(vn[ns].str,COMPSTR,"%d",vn[ns].ref);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			return report;
		}
		/* it's an ARRAY attribution */
		else if (!strncasecmp_(p,"ARRAY(",6)) {
			/* retrieve right ns code */
			if (complete[0]) {
				int i=decCount;
				ns=0;
				while (i>0) {
					if (vn[i].name[0] && !strcasecmp(vn[i].name,complete)) {
						ns=i;
						break;
					}
					i--;
				}
				if (!ns) {
					declare(complete,STRING,FALSE,0,0);
					ns=decCount;
				}
			}
			array(ns);
			snprintf(vn[ns].str,COMPSTR,"%d",ns);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			return report;
		}
		/* it's a COPY attribution */
		else if (!strncasecmp_(p,"COPY(",5)) {
			int oldns;
printf("111");
			p+=5;
			oldns=searchDEC(p,decCount);
			if (!oldns) perror_(__LINE__,64,l);
			else p+=_len;
			/* retrieve right ns code */
			if (complete[0]) {
				int i=decCount;
				ns=0;
				while (i>0) {
					if (vn[i].name[0] && !strcasecmp(vn[i].name,complete)) {
						ns=i;
						break;
					}
					i--;
				}
				if (!ns) {
					declare(complete,STRING,FALSE,0,0);
					ns=decCount;
				}
			}
			if (vn[oldns].datatype==CODE) 
				perror_(__LINE__,112,l);
			copyItem(ns, oldns);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			if (*p==')') p++;
			return report;
		}		
		/* it's a FAMILY attribution */
		else if (!strncasecmp_(p,"FAMILY(",7)) {
			int type=0;
			char var[COMPSTR];
			p+=7;
			strncpy_(var,getPar(p),COMPSTR);
			p+=strlen(var);
			strncpy_(var,family(var,&type),COMPSTR);
			if (!type) perror_(__LINE__,23,l);
			k=searchDEC(var,decCount);
			if (!k) perror_(__LINE__,23,l);
			if (type==ARRAY) {
				vn[ns].datatype=ARRAY;
				vn[ns].ref=k;
				snprintf(vn[ns].str,COMPSTR,"%d",k);
			}
			else {
				vn[ns].datatype=DATA;
				vn[ns].ref=k;
				strncpy_(vn[ns].str,vn[k].str,COMPSTR);
				vn[ns].dim=vn[k].dim;
			}
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			if (*p==')') p++;
			while(isblank(*p)) p++;
			if (*p && *p!=':') report=FALSE;
			return report;
		}
		/* determine the object of assignment */
		else {
			strncpy_(temp,JP(&state),COMPSTR);
		}
		
		/* exit if something went wrong*/
		if (isInterrupt) return TRUE;
		if (!report) {
			while(isblank(*p)) p++;
			return FALSE;
		}

		/* case of a returned array from define() */
		if (isAnArray) {
			int i;
			int size=vn[BACKARR].size;
			int usize=size/COMPSTR;
			int isize=usize*sizeof(int);
			copyArray(ns,BACKARR);	
			if (dimS[ns].elem) free(dimS[ns].elem);
			if (dim[ns].elem) free(dim[ns].elem);
			dimS[ns].elem=malloc((size_t)size);
			dim[ns].elem=calloc(sizeof(int),isize);
			for (i=0;i<usize;i++) {
				strncpy_(dimS[ns].elem+i*COMPSTR,dimS[BACKARR].elem+i*COMPSTR,COMPSTR);
				*(dim[ns].elem+i)=*(dim[BACKARR].elem+i);
			}
			snprintf(vn[ns].str,COMPSTR,"%d",ns);
			while(isblank(*p)) p++;
			DO_OUTPUT(ns);
			checkTrace(ns);
			isAnArray=FALSE;
			return report;
		}
		/* case of an assignment of an array */
		else if (state==ARRAY) {
			int vs=strtol(temp,NULL,10);
			vn[ns].ref=vs;
			vn[ns].datatype=vn[vs].datatype;
			while(isblank(*p)) p++;
		}
		/* case of an assignment of a data */
		else if (state==DATA) {
			int i=0;
			while (i<=decCount) {
				if (vn[i].datatype==DATA) {
					if (!strcmp(temp,vn[i].str)) break;
				}
				i++;
			}
			vn[ns].ref=i;
			vn[ns].dim=strtol(vn[i].str,NULL,10);
		}
		/* it's a code (through, for instance, CONVERT() ) */
		else if (state==CODE) {
			char *pb=p, ntemp[COMPSTR+2], *t=temp, *n=ntemp;
			*n++='\'';
			while (*t) {
				if (*t=='\'') *n++='\"', t++;
				else *n++=*t++;
			}
			*n++='\'';
			*n='\0';
			p=ntemp;
			strncpy_(vn[ns].proto,code(),COMPSTR);
			vn[ns].datatype=CODE;
			vn[ns].ref=finalCore+1; // start of code
			vn[ns].dim=endCore;	// end of code
			snprintf(vn[ns].str,COMPSTR,"%d",vn[ns].ref);
			p=pb;
			while(isblank(*p)) p++;
			checkTrace(ns);
		}
		/* set up for re-assignment of predefined variables */
		else if (ns<=sDefVar) {
			strncpy_(temp,deExtParen(temp),COMPSTR);
			if (temp[0]=='&') state=PATTERN+PREDEF;
			else state+=PREDEF;
		}
		/* assign an array item */
		if (isArr) {
			setArrayStr(ns,udim,val,temp);
			setArrayVal(ns,udim,val,state);
		}
		/* assign a variable */
		else {
			vn[ns].datatype=state;
			strncpy_(vn[ns].str,temp,COMPSTR);
			/* in case of a numeric assignment,
			 * set also the numeric part */
			if (state<STRING) {
				char *v;
				double val=strtod(temp,&v);
				if (!*v) vn[ns].num=val;
				else {
					vn[ns].num=0;
				       	vn[ns].datatype=STRING;
				}
			}
			if (state!=CODE && state!=ARRAY) {
				strncpy_(vn[ns].proto,VOIDS,COMPSTR);
				vn[ns].dim=0;
				vn[ns].ref=ns;
			}
		}
		k=vn[ns].datatype;
		if (k>PREDEF) k-=PREDEF;
		checkTrace(ns);
		DO_OUTPUT(ns);

	}
	/* try with a pattern */
	else {
		p=pb;
		while(isblank(*p)) p++;
		return report=patterns();
	}
	while(isblank(*p)) p++;

	return TRUE;
} // end of assign()


/* priority()
 * return math priority for operator op, according to the following table:
 * 5: the minus (caught in S()) is evaluated immediately
 * 4: (..) parentheses (caught in getVal) have the highest precedence
 * 3: power (^ and ** and !)
 * 2: multiplication, division (/ and \)
 * 1: addition, subtraction
 * 0: anything else has NIL priority and should cause error */
int priority(const int op) {
	if (op=='^')
		return 3;
	else if (op=='*'||op=='/'||op=='\\')
		return 2;
	else if (op=='+'||op=='-')
		return 1;
	else
		return 0;
}
#define PRIOR 3


/* S()
 * The PARSER for numerical expressions
 * The address of starting position into the flow stream is pointed by p
 * The algorithm is as follows:
 * an algebraic expression is turned into an RPN stack-based expression,
 * with numbers and operators in order in their own stack; operations are
 * performed from higher priorities down to lower and from left to right;
 * priorities are given by the priority() function, which is part of this tool.
 * Note: the name S() is retained from Mr. Spinellis version.
 * Note: the < and > operators (with their companion <= and >=) may not give
 * correct results with big numbers, because of the ways of storing numbers;
 * for instance, 1E29*10 is not stored in the same way of 1E30, because of
 * rounding errors in calculating the multiplication (the error propagates
 * rapidly when big numbers are calculated in series) */
double S(void) {
	int opStack[PSTACK], prStack[PSTACK], numTOS=0, opTOS=0, ii, jj, level;
	double numStack[PSTACK];
	char *pcopy=NIL,*pb;
	int opturn=0, ptype=0;
	notAMathExpression=FALSE;

	while (isblank(*p)) p++;
	pb=p;
	/* catch unary plus at start (simply discarded because redundant)
	 * Note: soft parser is built in such a way that the unary sign
	 * (+ or -) is tightly bound to the entity following it, so that
	 * operations like -3+-2, +3+-2, -3-+2, +3-+2 are accepted */
	if (*p=='+' && isdigit(*(p+1))) p++;
	/* catch unary minus at start */
	else if ((*p=='-' || *p=='+') && (isdigit(*(p+1)) || *(p+1)=='.')) {
		double res;
		p++; // skip sign
		res=getVal(p);
		if (notAMathExpression) {
			return 0.0;
		}
		if (ptype<_exprtype) ptype=_exprtype;
		numStack[numTOS++]=-res;
		if (numTOS>=PSTACK) {
			notAMathExpression=TRUE;
			return 0.0;
		}
		opturn=1;
		while (isblank(*p)) p++;
		/* short circuit: if number is followed by comma, semicolon
		 * or colon or closed parentheses return result immediately */
		if (isender(p))	return numStack[numTOS-1];
		/* short circuit #2: if the -a^x exponent is not followed
		 * by an operator, return result immediately */
		while (isblank(*p)) p++;
		if (!isop(p)) return numStack[numTOS-1];
	}
	/* an operator alone at start makes S() fail (not for the minus
	 * which may introduce a -N or a -VAR */
	else if (isop(p) && *p!='-' && *p!='+') {
		notAMathExpression=TRUE;
		return 0.0;
	}
	pcopy=p;

	/* reverse algebraic expression into a stack-based structure */
	while (*p && !notAMathExpression) {
		while (isblank(*p)) p++;
		/* case of parenthesized expression */
		if (*p=='(') {
			double val;
			char temp[COMPSTR];
			p++; // skip (
			while (isblank(*p)) p++;
			val=S();
			if (notAMathExpression || !report) {
				return 0.0;
			}
			if (ptype<_exprtype) ptype=_exprtype;
			numStack[numTOS++]=val;
			if (numTOS>=PSTACK) {
				notAMathExpression=TRUE;
				return 0.0;
			}
			opturn=1;
			while (isblank(*p)) p++;
			if (*p!=')') {
				notAMathExpression=TRUE;
				return 0.0;
			}
			else p++; // skip )
			while (isblank(*p)) p++;
			snprintf(temp,COMPSTR,"%.15G",numStack[numTOS-1]);
			while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
					(*p=='@' && !isblank(*(p+1)))) {
				evalDollar(temp);
				evalDot(temp);
				evalAt();
				while (isblank(*p)) p++;
			}
		}
		else if (*p==')') break;
		/* catch the exponential
		 * note: in Snobol4 the exponential has right
		 * precedence and must be treated separately */
		else if ((*p=='^' || *p=='!' || ispow(p)) && opturn) {
			double val,res;
			p++; // skip ^
			if (*p=='*') p++; // skip **
			while (isblank(*p)) p++;
			val=getVal(p);
			while (isblank(*p)) p++;
			while (*p=='^' || *p=='!' || ispow(p)) {
				double val2;
				p++; // skip ^
				if (*p=='*') p++; // skip **
				while (isblank(*p)) p++;
				val2=getVal(p);
				while (isblank(*p)) p++;
				res=pow(val,val2);
				val=res;
			}
			numStack[numTOS-1]=pow(numStack[numTOS-1],val);
			//opturn=1;
		}
		/* catch an operator */
		else if ((isop(p)) && opturn) {
			opStack[opTOS]=*p;
			prStack[opTOS]=priority(opStack[opTOS]);
			opTOS++;
			if (opTOS>=PSTACK) {
				notAMathExpression=TRUE;
				return 0.0;
			}
			p++;
			opturn=0;
		}
		/* catch an ender situation */
		else if (isender(p)) break;
		/* catch a number (literal or variable) */
		else if ((!isop(p) || *p=='-' || *p=='+') && !opturn) {
			int minus=1;
			char temp[COMPSTR];
			if (*p=='-') p++, minus=-1;
			else if (*p=='+') p++;
			numStack[numTOS++]=minus*getVal(p);
			if (numTOS>=PSTACK) {
				notAMathExpression=TRUE;
				return 0.0;
			}
			if (notAMathExpression || !report) {
				return 0.0;
			}
			snprintf(temp,COMPSTR,"%.15G",numStack[numTOS-1]);
			while (((*p=='$' || *p=='.') && isblank(*(p+1))) ||\
					(*p=='@' && !isblank(*(p+1)))) {
				evalDollar(temp);
				evalDot(temp);
				evalAt();
				while (isblank(*p)) p++;
			}
			if (ptype<_exprtype) ptype=_exprtype;
			opturn=1;
			while (isblank(*p)) p++;
		}
		else if ((isop(p) && !opturn) || (!isop(p) && opturn)) {
			break;
		}

		while (isblank(*p)) p++;

		/* Since the string was evaluated, change pcopy to signal
		 * the work is done */
		pcopy=NIL;
	}

	/* No parsing has been done if the string is not void */
	if (*p && pcopy==p) {
		notAMathExpression=TRUE;
	}

	/* end here if not a math expression*/
	if (notAMathExpression) {
		p=pb;
		return 0.0;
	}

	/* perform calculations from higher priorities downward
	 * Note: for soft, any relation is also a math expression */
	for (ii=PRIOR;ii>=0;ii--) {
		/* calculations are performed from left to right */
		for (level=0;level<opTOS;level++) {
			if (prStack[level]==ii) {
				/* collapse stacks */
				switch(opStack[level]) {
					/* HERE BEGINS OPERATORS ANALYSIS */
					/* exponential ^ or ! or ** */
					case '^':
						numStack[level]=pow(numStack[level],numStack[level+1]);
						break;
					/* subtraction - */
					case '-':
						numStack[level]-=numStack[level+1];
						break;
					/* addition + */
					case '+':
						numStack[level]+=numStack[level+1];
						break;
					/* division / */
					case '/': {
						double sor,dend;
						sor=numStack[level];
						dend=numStack[level+1];
						if (fabs(dend)<ZERO) perror_(__LINE__,15,l);
						else numStack[level]=sor/dend;
					}
						break;
					/* integer division / */
					case '\\': {
						double sor,dend;
						sor=numStack[level];
						dend=numStack[level+1];
						if (fabs(dend)<ZERO) perror_(__LINE__,15,l);
						else numStack[level]=(int)(sor/dend);
					}
						break;
					/* multiplication * */
					case '*':
						numStack[level]*=numStack[level+1];
						break;
				/* HERE ENDS OPERATORS ANALYSIS */
				}
				/* shift stack positions */
				for (jj=level;jj<opTOS-1;jj++) {
					numStack[jj+1]=numStack[jj+2];
					opStack[jj]=opStack[jj+1];
					prStack[jj]=prStack[jj+1];
				}
				opTOS--;
				level--;
			}
		}
	}

	/* At this point, we have the final result into cell [0]
	 * the type is stored in _exprtype */
	_exprtype=ptype;
	if (_exprtype==INTEGER) return (int)numStack[0];
	return numStack[0];
} // end of S()


/* getVal()
 * get single value (number, variable, function or array element)
 * the case of the unary minus for entities has been caught in S(); here is
 * treated the case of open parentheses
 * The double operators ++ and -- in the prefix notation are treated here
 * The address of starting position into the flow stream is pointed by p */
double getVal(char *b) {
	double o=0;
	char mypad[COMPSTR];
	notAMathExpression=FALSE;
	_exprtype=REAL;
	/* case of '' or "" */
	if (isquote(p) && isquote(p+1)) {
		p+=2;
		o=0.0;
	}
	/* case of 'number' or "number" */
	else if ((*p=='\'' || *p=='\"') && (isnm(p+1) || *(p+1)=='.')) {
		char q=*p++, *w=mypad, *v;
		while (*p && *p!=q) *w++=*p++;
		*w='\0';
		if (!strchr(mypad,'.')) _exprtype=INTEGER;
		o=strtod(mypad,&v);
		if (*v) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		if (*p==q) p++;
		else {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		while (isblank(*p)) p++;
	}
	/* case of a real number introduced by the decimal dot*/
	else if (*p=='.' && isdigit(*(p+1))) {
		char *w=mypad;
		*w++=*p++;
		while (isflot(p)) *w++=*p++;
		*w='\0';
		_exprtype=REAL;
		o=strtod(mypad,NULL);
		while (isblank(*p)) p++;
	}
	/* case of a real number */
	else if (isnm(p)) {
		char *w=mypad;
		while (isflot(p)) *w++=*p++;
		*w='\0';
		if (!strchr(mypad,'.')) _exprtype=INTEGER;
		o=strtod(mypad,NULL);
		while (isblank(*p)) p++;
	}
	/* case of unary minus
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='-' || *p=='+') {
		p++;
		o=-getVal(p);
		while (isblank(*p)) p++;
	}
	/* case of open parenthesis */
	else if (*p=='(') {
		p++;
		o=S(); // redefines _exprtype, no need to readdress it
		if (*p!=')') {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		else p++;
		while (isblank(*p)) p++;
	}
	/* evaluate &PARM (in getVal) */
	else if (!strncasecmp_(p,"&PARM",5)) {
		char *pb, *s;
		isIntFunc(mypad);
		pb=p;
		p=mypad;
		s=mypad+strlen(mypad)-1;
		while (isblank(*s)) *s--='\0';
		o=S();
		s=p;
		if (*s && *s!=' ') {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		p=pb;
	}
	/* evaluate integer system functions (in getVal) */
	else if (isIntFunc(mypad)) {
		char *s=mypad;
		o=strtod(s,&s);
		if (*s) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		if (parseInt(mypad)) _exprtype=INTEGER;
		else _exprtype=REAL;
	}
	/* delegate function calculations to getFunc() */
	else if ((*p=='$' && *(p+1) && !isblank(*(p+1))) || isalpha(*p)) {
		o=getFunc(p);
		if (o-(int)o!=0.0) _exprtype=REAL;
		else _exprtype=INTEGER;
	}
	else {
		notAMathExpression=TRUE;
		p=b;
		return 0.0;
	}
	/* normal end */
	return o;
} // end of getVal()


/* getFunc()
 * functions calculator
 * Note: since in soft mathematical calculations are subsidiary to string
 * recognition, this function does not return error messages; whenever
 * a math expression is not retrievable, the process stop to let a string
 * be taken as-is. This is done by activating the flag notAMathExpression.
 * When instead the calculation fails due to illegal values (for instance
 * the logarithm of a negative number, which is not really an invalid
 * expression, but an invalid input), the process terminates positively
 * but returning report = FALSE; this will inhibit any further processing
 * and possibly terminate the execution */
double getFunc(char *b) {
	double o=0.0;
	int ns=0;
	_exprtype=REAL;

	/* evaluate flag functions */
	if ((ns=flag())) {
		if (!report) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		else while (isblank(*p)) p++;
	}
	else p=b; // safe restore

	/* evaluate the user function */
	if ((ns=findPROC(p))) {
		char strres[COMPSTR], *s=strres;
		int ftype=0;
		strncpy_(strres,VOIDS,COMPSTR);
		p=define(ns,s,&ftype);
		if (ftype>=STRING) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		o=strtod(s,&s);
		if (*s) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		_exprtype=ftype;
		return o;
	}
	else p=b;

	/* MATH FUNCTIONS */
	/* TIME() function
	 * return the elapsed time since the beginning of the execution */
	if (!strncasecmp_(p,"TIME(",5)) {
		double endS;
		p+=5;
		while (isblank(*p)) p++;
		/* consume and ignore argument if given */
		while (*p!=')') {
			int st=0;
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			p++;
		}
		gettimeofday(&tv, NULL);
		endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS-=beginS;
		o=(int)(endS*1000.0);
		if (*p==')') p++;
		_exprtype=INTEGER;
	}
	/* STCOUNT() function
	 * return the count of the number of statements executed so far */
	else if (!strncasecmp_(p,"STCOUNT(",8)) {
		p+=8;
		while (isblank(*p)) p++;
		/* consume and ignore argument if given */
		while (*p && *p!=')') {
			int st=0;
			if (*p=='(') st++;
			else if (*p==')' && st) st--;
			else if (*p==')' && !st) break;
			p++;
		// TODO adottare questo metodo di parsing per tutte le
		// funzioni che ignorano l'argomento FIXME XXX
		}
		o=sStatms;
		if (*p==')') p++;
		_exprtype=INTEGER;
	}
	/* ABS(x) */
	else if (!strncasecmp_(p,"ABS(",4)) {
		p+=4;
		while (isblank(*p)) p++;
		// the following S() redefines _exprtype, so ABS retains it
		if (*p!=')') o=S();
		else o=0.0;
		while (isblank(*p)) p++;
		o=fabs(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* ARCSIN(x) with alias ASIN(x) */
	else if (!strncasecmp_(p,"ASIN(",5) || !strncasecmp_(p,"ARCSIN(",7)) {
		if (toupper(*(p+1))=='S') p+=5;
		else p+=7;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		if (o>1. || o<-1.) perror_(__LINE__,17,l);
		while (isblank(*p)) p++;
		o=asin(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* ARCCOS(x) with alias ACOS(x) */
	else if (!strncasecmp_(p,"ACOS(",5) || !strncasecmp_(p,"ARCCOS(",7)) {
		if (toupper(*(p+1))=='C') p+=5;
		else p+=7;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		if (o>1. || o<-1.) perror_(__LINE__,17,l);
		while (isblank(*p)) p++;
		o=acos(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* CHOP(x) */
	else if (!strncasecmp_(p,"CHOP(",5)) {
		p+=5;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		o=(double)((int)o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* EXP(x) */
	else if (!strncasecmp_(p,"EXP(",4)) {
		p+=4;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		o=exp(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* LOG(x) with alias LN(x) */
	else if (!strncasecmp_(p,"LOG(",4) || !strncasecmp_(p,"LN(",3)) {
		if (toupper(*(p+1))=='O') p+=4;
		else p+=3;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		if (o<=0.0) perror_(__LINE__,17,l);
		o=log(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* COS(x) */
	else if (!strncasecmp_(p,"COS(",4)) {
		p+=4;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		o=cos(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* TAN(x) */
	else if (!strncasecmp_(p,"TAN(",4)) {
		p+=4;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		o=tan(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* SIN(x) */
	else if (!strncasecmp_(p,"SIN(",4)) {
		p+=4;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		o=sin(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* ARCTAN(x) with alias ATAN(x) */
	else if (!strncasecmp_(p,"ARCTAN(",7) || !strncasecmp_(p,"ATAN(",5)) {
		if (toupper(*(p+1))=='R') p+=7;
		else p+=5;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		o=atan(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* ORD() function
	 * return the value of the ASCII character = argument */
	else if (!strncasecmp_(p,"ORD(",4)) {
		char str[COMPSTR];
		p+=4;
		while (isblank(*p)) p++;
		strncpy_(str,AS(),COMPSTR);
		o=str[0];
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=INTEGER;
	}
	/* PI(x) */
	else if (!strncasecmp_(p,"PI(",3)) {
		char val[COMPSTR];
		p+=3;
		while (isblank(*p)) p++;
		strncpy_(val,AS(),COMPSTR); // ignored
		while (isblank(*p)) p++;
		o=SOFTPI;
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* SQRT(x) with alias SQR(x) */
	else if (!strncasecmp_(p,"SQRT(",5) || !strncasecmp_(p,"SQR(",4)) {
		if (toupper(*(p+3))=='T') p+=5;
		else p+=4;
		while (isblank(*p)) p++;
		if (*p!=')') o=S(); // redefines _exprtype but must be REAL
		else o=0.0;
		while (isblank(*p)) p++;
		if (o<0.0) perror_(__LINE__,17,l);
		o=sqrt(o);
		if (*p==')') p++;
		while (isblank(*p)) p++;
		_exprtype=REAL;
	}
	/* RANDOM(n1,n2)
	 * generate a pseudo-random number */
	else if (!strncasecmp_(p,"RANDOM(",7)) {
		double code=0, endcode=0;
		int isdouble=FALSE, currType=0;
		p+=7;
		while (isblank(*p)) p++;
		if (*p==')') code=0;
		else code=S();
		if (currType<_exprtype) currType=_exprtype;
		if (*p==',') {
			p++; // skip comma
			isdouble=TRUE;
			endcode=S();
			if (currType<_exprtype) currType=_exprtype;
		}
		else if (*p!=')') perror_(__LINE__,14,l);
		if (isdouble) {
			double off=endcode-code;
			o=getRandom();
			o=o*off+code;
			if (currType==INTEGER) o=(int)(o+0.5);
			_exprtype=currType;
		}
		else if (code<0) {
			o=getRandom();
			_exprtype=REAL;
		}
		else if (!code) {
			o=(int)(getRandom()*MAXRAN)+1;
			_exprtype=INTEGER;
		}
		else {
			o=((int)(getRandom()*MAXRAN)+1)%100+1;
			_exprtype=INTEGER;
		}
		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* ROOT(x,i)
	 * i-th root of x */
	else if (!strncasecmp_(p,"ROOT(",5)) {
		double base,index;
		p+=5;
		while (isblank(*p)) p++;
		base=S();
		while (isblank(*p)) p++;
		if (*p==',') p++;
		else {
			fprintf(stdout,"%s\n",error[65]);
			return OFLOW;
		}
		while (isblank(*p)) p++;
		index=S(); // redefines _exprtype but must be real
		_exprtype=REAL;
		if (base==0.0 && index==0.0) {
			fprintf(stdout,"%s\n",error[17]);
			return OFLOW;
		}
		else if (base<0.0 && fabs(index-(int)index)>0) {
			fprintf(stdout,"%s\n",error[17]);
			return OFLOW;
		}
		else if (base<0.0 && fabs(index-(int)index)==0.0) {
			o=-pow(-base,1.0/index);
		}
		else if (base==0.0) o=0.0;
		else if (base>0.0 && index==0.0) o=1.0;
		else o=pow(base,1.0/index);
		while (isblank(*p)) p++;
		if (*p==')') p++;
		while (isblank(*p)) p++;
	}
	/* indirect referencing in getFunc() */
	else if (*p=='$' && *(p+1) && !isblank(*(p+1))) {
		char temp[COMPSTR], str[COMPSTR], *s=str, *pb;
		int ns;
		p++; // skip symbol
		if (*p=='(') {
			p++; // skip (
			strncpy_(temp,GS(),COMPSTR);
			if (*p==')') p++;
		}
		else {
			while (*p && !isblank(*p) && *p!=')') *s++=*p++;
			*s='\0';
			pb=p;
			p=str;
			string(temp);
			p=pb;
		}
		/* search for var */
		ns=decCount;
		while (ns>0) {
			if (!strcasecmp(temp,vn[ns].name))
				break;
			ns--;
		}
		/* getfunc() */
		if (ns<1) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		/* it's a null-string case, actually */
		if (!vn[ns].str[0] && vn[ns].datatype==STRING) {
			while (isblank(*p)) p++;
			if (isop(p)) {
				return 0.0;
				_exprtype=INTEGER;
			}
			else {
				notAMathExpression=TRUE;
				p=b;
				return 0.0;
			}
		}
		else if (vn[ns].datatype>REAL) {
			notAMathExpression=TRUE;
			p=b;
			return 0.0;
		}
		else {
			o=strtod(vn[ns].str,NULL);
			_exprtype=vn[ns].datatype;
		}
	}
	/* numeric variables */
	else if ((ns=findDEC(p))) {
		/* variable was created now... as string; let's convert it to
		 * integer zero */
		if (!vn[ns].str[0] && vn[ns].datatype==STRING) {
			vn[ns].datatype=INTEGER;
			vn[ns].num=0;
			_exprtype=INTEGER;
		}
		p+=_len;
		if (vn[ns].datatype<STRING) {
			o=vn[ns].num;
			_exprtype=vn[ns].datatype;
		}
		/* return an array */
		else if (vn[ns].datatype==ARRAY) {
			char op[COMPSTR];
			int val[MAXDIM+1];
			int T=1;
			ns=vn[ns].ref;
			if (*p!='[') perror_(__LINE__,29,l);
			else p++; // skip [
			val[T]=(int)S();
			if (val[T]<vn[ns].offset[T] || val[T]>vn[ns].ldim[T]+vn[ns].offset[T]) {
				sErr=57;
				lErr=l;
				report=FALSE;
				return 0.0;
			}
			while (*p==',') {
				p++; T++;
				if (T>vn[ns].dim) perror_(__LINE__,52,l);
				val[T]=(int)S();
				if (val[T]<vn[ns].offset[T] || val[T]>vn[ns].ldim[T]+vn[ns].offset[T]) {
					sErr=57;
					lErr=l;
					report=FALSE;
					return 0.0;
				}
			}
			if (*p==']') p++;
			strncpy_(op,getArrayStr(ns,vn[ns].dim,val),COMPSTR);
			o=strtod(op,NULL);
			_exprtype=getArrayVal(ns,vn[ns].dim,val);
		}
		else {
			notAMathExpression=TRUE;
		}
	}
	else notAMathExpression=TRUE;

	/* it was not a math expression; return pointer as it is
	 * to be used in another contest */
	if (notAMathExpression) {
		p=b;
		return 0.0;
	}
	/* return the sweated value if everything went ok! */
	return o;
} // end of getFunc()


/******************************************************************************
 * The following functions define general system environment subroutines:
 * they are internal routines not directly accessible as Snobol4 statements.
 ******************************************************************************/

/* dimStrArray(matrix-index,type,dimensions width)
 * dimension a string array, allocating the necessary memory space;
 * var: the index of the variable holding the matrix name
 * T: the matrix type, 1 for unidimensional vectors, 2 for matrices (currently
 *    not available)
 * val: the array of dimensions
 * Note: all elements of declared array are set to the void string.
 * System function for the ARRAY management */
int dimStrArray(int var, int T, int *val, char *init, int type) {
	int i;
	int size=1, isize=1;
	for (i=1;i<=T;i++) size*=(val[i]+1);
	size+=1; // safety space
	isize=size;
	size*=COMPSTR;
	isize*=sizeof(int);

	/* reserve memory space for the array */
	if (dimS[var].elem) free(dimS[var].elem);
	if (dim[var].elem) free(dim[var].elem);
	dimS[var].elem=malloc((size_t)size);
	dim[var].elem=calloc(sizeof(int),isize);
	if (!dimS[var].elem || !dim[var].elem) return report=FALSE;

	/* initialize to zero */
	if (!*init) {
		/* erase all array elements */
		for (i=0;i<size;i++) *(dimS[var].elem+i)='\0';
		/* set zero by default */
		for (i=0;i<=size/COMPSTR;i++) *(dim[var].elem+i)=STRING;
	}
	/* initialize to a value */
	else {
		int usize=size/COMPSTR, i;
		for (i=0;i<usize;i++) {
			strncpy_(dimS[var].elem+i*COMPSTR,init,COMPSTR);
			*(dim[var].elem+i)=type;
		}
		/* set zero by default */
	}

	return size;
}


/* getArrayStr(matrix-index,type,positions)
 * get value of an element of a string array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * T: matrix dimension, 1 for unidimensional vectors, 2 for matrices, 3,4,...
 * val: the local dimensions required numbers
 * System function for the ARRAY management */
char *getArrayStr(int var, int t, int *val) {
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) perror_(__LINE__,33,l);
	/* calculate position */
	for (i=1; i<=t; i++) res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	res*=COMPSTR;
	return dimS[var].elem+res;
}


/* setArrayStr(matrix-index,type,positions,value)
 * set an element of a string array to a specific value, given the value itself
 * and the element coordinates
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices
 * var: the index of the variable holding the matrix name
 * val: the local dimensions required numbers
 * str: the value to be stored
 * System function for the ARRAY management */
void setArrayStr(int var, int t, int *val, char *str){
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) perror_(__LINE__,33,l);
	/* calculate position */
	for (i=1; i<=t; i++) res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	res*=COMPSTR;
	strncpy_(dimS[var].elem+res,str,COMPSTR);
}

/* getArrayVal(matrix-index,type,positions)
 * get value of an element of a numerical array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix dimension coming from the calling instance
 * val: the local dimensions required array
 * System function for the ARRAY management */
double getArrayVal(int var, int t, int *val) {
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) perror_(__LINE__,33,l);
	/* calculate position */
	for (i=1; i<=t; i++) res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	return *(dim[var].elem+res);
}


/* setArrayVal(matrix-index,type,positions)
 * set an element of a numerical array to a specific value, given the value
 * itself and the element coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix dimension coming from the calling instance
 * val: the local dimensions required array
 * num: the value to be stored
 * System function for the ARRAY management */
void setArrayVal(int var, int t, int *val, double num){
	int i, res=0;
	/* check dimensions */
	if (t != vn[var].dim) perror_(__LINE__,33,l);
	/* calculate position */
	for (i=1; i<=t; i++) res+=vn[var].coeff[i]*(val[i]-vn[var].offset[i]);
	*(dim[var].elem+res)=num;
}


/* copyArray()
 * copy array in the second argument code to the first argument code 
 * it does not copy the name, and the reference is reset */
int copyArray(int to_ns, int from_ns) {
	int i;
	vn[to_ns].ref=to_ns;
	vn[to_ns].datatype=vn[from_ns].datatype;
	vn[to_ns].iotype=vn[from_ns].iotype;
	vn[to_ns].datachan=vn[from_ns].datachan;
	strncpy_(vn[to_ns].str, vn[from_ns].str,COMPSTR);
	vn[to_ns].num=vn[from_ns].num;
	vn[to_ns].dim=vn[from_ns].dim;
	for (i=0;i<MAXDIM;i++) {
		vn[to_ns].ldim[i]=vn[from_ns].ldim[i];
		vn[to_ns].offset[i]=vn[from_ns].offset[i];
		vn[to_ns].coeff[i]=vn[from_ns].coeff[i];
	}
	vn[to_ns].size=vn[from_ns].size;
	vn[to_ns].strmem=vn[from_ns].strmem;
	vn[to_ns].isData=vn[from_ns].isData;
	vn[to_ns].isCode=vn[from_ns].isCode;
	strncpy_(vn[to_ns].proto, vn[from_ns].proto,COMPSTR);
	strncpy_(vn[to_ns].argparam, vn[from_ns].argparam,COMPSTR);
	vn[to_ns].argtype=vn[from_ns].argtype;
	return TRUE;
}


/* searchDEC()
 * find a DECLAREd variable/array in the vn[] structure
 * lp points to the DEC name in getFunc(), LET() or SS() and get its value;
 * term is the last decCount to be counter
 * store in _len the length of the variable name
 * store in _rettype relative values for an immediate check
 * System function */
int searchDEC(char *lp, int term) {
	int i=term, cs;
	char name[COMPSTR], *n=name;

	/* set anyway a valid value as a safety measure */
	_len=0;
	if (!*lp || !lp) return FALSE;
	if (!(isnamechar(lp))) return FALSE;
	/* get DEC name */
	while (isnamechar(lp)) *n++=*lp++;
	*n='\0';
	_len=(int)strlen(name);
	if (!_len || !name[0]) return FALSE;

	/* check if it is a method */
	if (*lp=='(') {
		char *b=lp, constructor[COMPSTR], *c=constructor;
		char tnum[COMPSTR];
		int st=0, tlen=_len;
		b++; // skip (
		while (*b) {
			if (*b=='(') st++;
			else if (*b==')' && st) st--;
			else if (*b==')' && !st) break;
			*c++=*b++;
		}
		*c='\0';
		cs=searchDEC(constructor,term); // alters _len
		if (!cs || vn[cs].datatype!=DATA) return FALSE;

		/* check to which constructor the method belongs */
		if (!strcasestr_oq(datafunc[vn[cs].dim].proto,name))
			return FALSE; // it's not a method
		strncat_(name,"(",COMPSTR);
		snprintf(tnum,COMPSTR,"%d",vn[cs].ref);
		strncat_(name,tnum,COMPSTR);
		strncat_(name,")",COMPSTR);
		_len=tlen+2+strlen(constructor);
	}

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (vn[i].name[0] && !strcasecmp(vn[i].name,name)) {
			return i;
		}
		i--;
	}
	/* DEC irremediably not found */
	_len=0;
	return FALSE;
}


/* findARRAY()
 * detects the name that follows and search if it's an array on its own */
int findARRAY(char *lp) {
	int i=decCount;
	char name[COMPSTR], *n=name;
	char num[COMPSTR], *pb=p;

	/* set anyway a valid value as a safety measure */
	_len=0;

	if (!*lp) return FALSE;
	if (!(isbeginnamechar(lp))) return FALSE;

	/* get the whole name */
	while (isnamechar(lp)) *n++=*lp++;
	if (*lp=='[') *n++=*lp++;
	else if (*lp=='(') return FALSE;
	*n='\0';
	p=lp;
	snprintf(num,COMPSTR,"%d",(int)S());
	strncat_(name,num,COMPSTR);
	while (*p==',') {
		p++;
		strncat_(name,",",COMPSTR);
		snprintf(num,COMPSTR,"%d",(int)S());
		strncat_(name,num,COMPSTR);
	}
	lp=p;
	p=pb;
	if (*lp==']') {
		lp++;
		strncat_(name,"]",COMPSTR);
	};
	while (isblank(*lp)) lp++;
	if (*lp && *lp!='=' && *lp!=':') return FALSE;
	/* search for name */
	while (i>0) {
		if (!strcasecmp(vn[i].name,name) && vn[i].datatype==ARRAY) {
			_len=(int)strlen(name);
			return i;
		}
		i--;
	}
	return FALSE;
}


/* findHidden()
 * detects the non canonical name that follows and search if
 * it's an array on its own */
int findHidden(char *lp) {
	int i=decCount;
	char name[COMPSTR];

	/* set anyway a valid value as a safety measure */
	_len=0;

	if (!*lp) return FALSE;

	/* get the whole name */
	if (*lp=='$' || *lp=='\"' || *lp=='\'') {
		char *pb=p;
		p=lp;
		strncpy_(name,SS(),COMPSTR);
		lp=p;
		p=pb;
	}
	else return FALSE;
	while (isblank(*lp)) lp++;
	if (!(!*lp || *lp==':' || *lp=='=')) return FALSE;
	//if (*lp!='=' && *lp!=':') return FALSE;
	/* search for name */
	while (i>0) {
		if (!strcasecmp(vn[i].name,name) && vn[i].datatype==ARRAY) {
			_len=(int)strlen(name);
			return i;
		}
		i--;
	}
	return FALSE;
}


/* findDATa()
 * detects the name of a DATA item */
int findDATA(char *lp) {
	int i=dataTOS;
	char name[COMPSTR], *n=name;

	/* set anyway a valid value as a safety measure */
	_len=0;

	if (!*lp) return FALSE;
	if (!(isbeginnamechar(lp))) return FALSE;
	/* get DEC name */
	while (isalnum(*lp) || *lp=='.') *n++=*lp++;
	*n='\0';
	_len=(int)strlen(name);
	if (!_len || !name[0]) return FALSE;
	if (*lp=='(') lp++; // skip (

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (datafunc[i].name[0] && !strcasecmp(datafunc[i].name,name)) {
			return i;
		}
		i--;
	}

	/* DATA irremediably not found */
	_len=0;
	return FALSE;
}


/* findDEC()
 * find a DECLAREd variable/array in the vn[] structure;
 * lp points to the DEC name in getFunc(), SS() and get its value;
 * store in _len the length of the variable name
 * store in _datatype relative values for an immediate check
 * Instantiate the variable if not found
 * System function for the DECLARE management */
int findDEC(char *lp) {
	int i=decCount, isMethod=FALSE, cs;
	char name[COMPSTR], *n=name;

	/* set anyway a valid value as a safety measure */
	_len=0;

	if (!*lp) return FALSE;
	if (!(isbeginnamechar(lp))) return FALSE;
	/* get DEC name */
	while (isnamechar(lp)) *n++=*lp++;
	*n='\0';
	_len=(int)strlen(name);
	if (!_len || !name[0]) return FALSE;

	/* check if it is a method */
	if (*lp=='(') {
		char *b=lp, constructor[COMPSTR], *c=constructor;
		char tnum[COMPSTR];
		int st=0, tlen=_len;
		b++; // skip (
		while (*b) {
			if (*b=='(') st++;
			else if (*b==')' && st) st--;
			else if (*b==')' && !st) break;
			*c++=*b++;
		}
		*c='\0';
		cs=searchDEC(constructor,decCount); // alters _len
		if (!cs || vn[cs].datatype!=DATA) return FALSE;
		else isMethod=TRUE;

		/* check to which constructor the method belongs */
		if (!strcasestr_oq(datafunc[vn[cs].dim].proto,name))
			return FALSE; // it's not a method
		strncat_(name,"(",COMPSTR);
		snprintf(tnum,COMPSTR,"%d",vn[cs].ref);
		strncat_(name,tnum,COMPSTR);
		strncat_(name,")",COMPSTR);
		_len=tlen+2+strlen(constructor);
	}

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (!strcasecmp(vn[i].name,name)) {
			return i;
		}
		i--;
	}
	/* DEC not found: try to instantiate the variable */
	if (!isMethod) {
		declare(name, STRING, FALSE, 0, 0);
		_len=(int)strlen(name);
		return decCount;
	}

	/* DEC irremediably not found */
	_len=0;
	return FALSE;
}


/* declare()
 * declare a variable/array in the vn[] structure;
 * name contains the name to be declared in position decCount
 * type and arr the type and arr
 * System function for findDEC and the indirect referencing management */
void declare(char *name, int type, int arr, int chan, int io) {
	decCount++;
	if (decCount>=VLIMIT) perror_(__LINE__,74,l);
	strncpy_(vn[decCount].name,name,COMPSTR);
	if (type==INTEGER) strncpy_(vn[decCount].str,"0",COMPSTR);
	else if (type==REAL) strncpy_(vn[decCount].str,"0.0",COMPSTR);
	else vn[decCount].str[0]='\0';
	vn[decCount].datatype=type;
	vn[decCount].num=0.0;
	vn[decCount].datachan=chan;
	vn[decCount].iotype=io;
	vn[decCount].ref=decCount;
	vn[decCount].isData=FALSE;
	vn[decCount].isCode=FALSE;
}


/*****************************************
 *	     TIME & STACK	      *
 *****************************************/

/* getTime()
 * return current time structure */
struct tm *getTime(void) {
	time_t st_lt;
	st_lt=time(NULL);
	return localtime(&st_lt);
}


/* getMin()
 * return current min (0-59) */
int getMin(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_min;
}


/* getMilliSec()
 * return current milliseconds */
int getMilliSec(void) {
	struct timespec vt;
	clock_gettime(CLOCK_MONOTONIC, &vt);
	return vt.tv_nsec;
}


/* getSec()
 * return current second (0-59) */
int getSec(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_sec;
}


/* getHour()
 * return current hour (0-23) */
int getHour(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_hour;
}


/* getWDay()
 * return current week day (0-6) */
int getWDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_wday;
}


/* getDay()
 * return current day (1-31) */
int getDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_mday;
}


/* getMonth()
 * return current month (1-12) */
int getMonth(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_mon+1);
}


/* getYear()
 * return current year */
int getYear(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_year+1900);
}


/* getMonthString()
 * return current month string */
char *getMonthString(void) {
	return month[getMonth()];
}


/*****************************************
 *	     MATH & STRINGS	    *
 *****************************************/


/* makechar()
 * returns first character of string str as a string */
char *makechar(char* str) {
	static char onechar[2];

	onechar[0]=*str;
	onechar[1]='\0';
	return onechar;
}


/* spaces()
 * return a pointer to a string of v spaces up to LIMIT+1 characters */
char *spaces(int v) {
	static char spacePad[LIMIT+1];
	char *sp;
	int n;

	/* set limits */
	sp=spacePad;
	if (v<0) n=0;
	else if (v>LIMIT) n=LIMIT;
	else n=v;

	/* build spaces string */
	while (n-->0) *sp++=32;
	*sp='\0';
	return spacePad;
}


/* turnToUpper()
 * turn a line to all upper characters */
void turnToUpper(char *str) {
	while (*str) *str=toupper(*str), str++;
}


/* turnToUpper_oq()
 * turn a line to all upper characters outside double quotes*/
void turnToUpper_oq(char *str) {
	int st=0;
	char q=0;
	while (*str) {
		if (isquote(str) && !st) q=*str, st++;
		else if (isquote(str) && st && (*str)==q) st--;
		if (!st) *str=toupper(*str);
		str++;
	}
}


/* getRandom() */
double getRandom(void) {
	static double fix=0.3; // variable randSeed part
	static double div=0.1; // variable randDivi part
	double o=100.0*randSeed/randDivi;

	/* take fractional part of the division of randSeed by randDivi
	 * (take digits from 3rd to 8th position) */
	o-=(int)o;

	/* update randSeed */
	randSeed=(unsigned int)((o*1E5)+fix);
	if (!randSeed%2) randSeed++;

	/* update randDivi */
	randDivi=(unsigned int)((randDivi*randSeed)%0xFFFFF+div);
	if (randDivi%2) randDivi++;

	/* update variable parts */
	div+=3.0; if (div>499) div=-997;
	fix+=167.0; if (fix>4999) fix=0;

	/* ensure limits are respected (see previous note) */
	if (o<RZERO||o>=1.0) return getRandom(); // discard also neg. numbers
	return o;
}


/* randomize() */
void randomize(void) {
       	randDivi = clock()%MAXRAN+1;
	if (randDivi%2) randDivi++;
}


/* Note
 * The following strncpy_() and strncat_() are my own personal versions for
 * strcpy/strncpy and strcat/strncat respectively.
 * I must use mine because strncpy/strncat standard functions in C (gcc) have
 * erratic behaviors within different operating systems like Linux-Suse,
 * OpenBSD and Mac OS X 10.4 (the one I use).
 * Since many reported strange things happening because of strncpy/strncat
 * (from error in compilation to completely wrong string functions output), I
 * made up my mind and built these substitutes for both. */

/* strncpy_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator;
 * thus a width equal to 10 means 9 characters at most for the string;
 * dw must be put equal to the width, in this example 10;
 * of course, any lower value is also good.)
 * The process will take care of never going past the limit of dst,
 * and to fill  the rest of the space (if any) with nulls;
 * System function replacing strcpy/strncpy */
char *strncpy_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* check length of copy and source */
	if (dw<1) *dst='\0';
	else if (!src) {
		/* fill the whole string with nulls */
		if (!*src) while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	else {
		/* copy src onto dst but not past the end of dst */
		while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
		*dp++='\0';
		/* fill the rest with nulls */
		while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	/* Note: return the same value returned by strcpy/strncpy */
	return dst;
}


/* strncat_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst, and to fill
 * the rest of the space (if any) with nulls; if dst is found not initialized
 * (that is nowhere the terminator is found) it is initialized as void.
 * System function replacing strcat/strncat */
char *strncat_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* return directly dst in case src is empty or null */
	if (!src || !*src) return dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* copy src onto dst but not past the end of dst */
	while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<(dw)) *dp++='\0';
	/* Note: return the same value returned by strcat/strncat */
	return dst;
}


/* chrcat_()
 * add character c to list dst, taking care of checking the limit
 * dst: the destination string (which must have its proper dimension)
 * c: the character to be appended to dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst, and to fill
 * the rest of the space (if any) with nulls; if dst is found not initialized
 * (that is no terminator is found) dst is initialized as void.
 * Note: this function is a complement of the strncat_ function
 * System function */
char *chrcat_(char *dst, int c, int dw) {
	char *dp=dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* add c to dst but not past the end of dst */
	if (c && (int)(dp-dst)<(dw-1)) *dp++=c;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<(dw)) *dp++='\0';
	/* Note: return the same value returned by strncat_ */
	return dst;
}


/* Note
 * The following strncasecmp_() is my own personal version of strncasecmp.
 * I must use mine because strncasecmp seems to cause some problems if soft is
 * compiled under openSuse with gcc and or Linux/openBSD with gcc.
 * Since many reported errors in compiling when the standard strncasecmp is
 * used, I made up my mind and built this substitute. */

/* strncasecmp_()
 * the string compare function
 * dst and src are the strings to be compared;
 * N is the number of characters to be checked against;
 * return the flag for positive comparison result, 0 for match, -1 for failure.
 * Note: return values mimic the original return values, with the difference
 * that I don't check here for dst being greater or less than src, and in case
 * they differ, -1 is returned anyway; this is done for speed issues. */
int strncasecmp_(char *dst, char *src, int N) {
	if (N<=0) return TRUE;
	while (N && *dst && *src && toupper(*dst)==toupper(*src))
		src++, dst++, N--;
	if (!N) return FALSE;
	return TRUE;
}


/* strcomp()
 * the string comparison function for DIFFER and IDENT, which takes in account
 * the null comparison as true.
 * return TRUE if strings compare, FALSE if they differ.
 * system function for SS() */
int strcomp(char *str1, char *str2) {
	if (!*str1 && !*str2) return TRUE;
	else if (*str1 && !*str2) return FALSE;
	else if (!*str1 && *str2) return FALSE;
	else {
		while (*str1 && *str2 && *str1==*str2) str1++,str2++;
		if (*str1!=*str2) return FALSE;
	}
	return TRUE;
}


/* Note
 * The following memcpy_() is my own personal version of memcpy and memmove.
 * I must use mine because memcpy seems to be sometimes rejected by openBSD.
 * Since many reported errors in compiling if the standard memcpy/memmove is
 * used, I made up my mind and built this substitute. */

/* memcpy_()
 * copy a portion of memory from src to dst, using memmove (that takes care
 * of overlapping), for a number of characters as in size, checks before
 * if any of arrays are null, or size is zero */
void memcpy_(void *dst, void *src, int size) {
	if (src==NIL || dst==NIL || !size) return;
	memmove(dst,src,size);
}

/* Note
 * The following strstr_() is a version of strstr() adapted for SNOBOL4.
 * System function for patterns() and ARBNO
 * AM 2020 */
char *strstr_(char *base, char *pat) {
	int blen=(int)strlen(base);
	int plen=(int)strlen(pat);
	//evalAt();
	if (!rightPos) return NULL;
	if (!report) return NULL;
	if (!blen && !plen) return base;
	//if (!plen && blen) return base;
	if (!blen) return NULL;
	if (!strncmp(base,pat,plen)) return base;
	return NULL;
}


/* Note
 * The following strcasestr_() is my own personal version of strcasestr().
 * I must use mine because strcasestr() in C has someway an erratic behavior
 * with Linux.
 * Since many reported errors in compiling if the standard strcasestr() is
 * used, I made up my mind and built this substitute. */

/* strcasestr_()
 * find the first occurrence of the substring 'little' in string 'big',
 * ignoring the case of both arguments.
 * The terminating null bytes (i.e. '\0') are not compared.
 * If 'little' is null, return NIL; if the substring is found, return the
 * updated address in 'big', otherwise return NIL. */
char *strcasestr_(char *big, char *little) {
	int l=(int)strlen(little);

	if (!l) return NIL;
	while (*big) {
		if (!strncasecmp_(big,little,l)) return big;
		big++;
	}
	return NIL;
}


/* strstr_proper()
 * find the needed occurrence of the substring 'little' in string 'big',
 * considering the state of scan and the position in CFIRST 
 * (cfr. case of pattern=4 for 484, where the last 4 is the pattern).
 * The terminating null bytes (i.e. '\0') are not compared.
 * If 'little' is null, return NIL; if the substring is found, return the
 * updated address in 'big', otherwise return NIL. */
char *strstr_proper(char *big, char *little) {
	int l=(int)strlen(little);
	int b=(int)strlen(big);

	if (!l) return NIL;
	while (*(big+b)) {
		if (!strncmp(big+b,little,l)) return big+b;
		b--;
	}
	return NIL;
}


/* strchr_up()
 * find the first occurrence of character 'little' in string 'big',
 * ignoring the case of both arguments. Unused for the moment.
 * The terminating null bytes (i.e. '\0') are not compared.
 * If 'little' is null, return NIL; if the character is found, return the
 * updated address in 'big', otherwise return NIL. */
char *strchr_up(char *big, char little) {
	if (!little) return NIL;
	while (*big) {
		if (toupper(*big)==toupper(little)) return big;
		big++;
	}
	return NIL;
}


/* strcasechr_oq()
 * find the first occurrence of char 'pr' into string 'pl'
 * this function has the same usage of strchr(), but it works only if
 * outside of a string
 * (strcasechr_oq = strchr_ Out of Quotes No Case) */
char *strcasechr_oq(char *pl, char pr) {
	int isDou=FALSE, isSin=FALSE;

	if (!pr) return pl;
	while (*pl) {
		if (*pl=='\"' && !isDou && !isSin) isDou=TRUE;
		else if (*pl=='\"' && isDou) isDou=FALSE;
		else if (*pl=='\'' && !isDou && !isSin) isSin=TRUE;
		else if (*pl=='\'' && isSin) isSin=FALSE;
		if (*pl==pr && !isDou && !isSin) return pl;
		pl++;
	}
	return NIL;
}


/* strcasestr_oq()
 * find the first occurrence of the substring string 'pr' into string 'pl'
 * this function has the same usage of strcasestr_(), but it works only if
 * outside of a string, in Snobol4 normally surrounded by single or 
 * double quotes (strcasestr_oq = strcasestr_ Out of Quotes) */
char *strcasestr_oq(char *pl, char *pr) {
	int isDou=FALSE, isSin=FALSE;
	int l=(int)strlen(pr);

	if (!l) return pl;
	while (*pl) {
		if (*pl=='\"' && !isDou && !isSin) isDou=TRUE;
		else if (*pl=='\"' && isDou) isDou=FALSE;
		else if (*pl=='\'' && !isDou && !isSin) isSin=TRUE;
		else if (*pl=='\'' && isSin) isSin=FALSE;
		else if (!strncasecmp_(pl,pr,l) && !isDou && !isSin) return pl;
		pl++;
	}
	return NIL;
}


/* fgets_()
 * a replacement for fgets() to return strings from source f,
 * stopping only on feof(), and returning a void string in case
 * of empty line.
 * Note: the New Line character is removed and not part of the
 * returned string
 * Returns TRUE in case of correct reading, FALSE in case of EOF
 * The result string is in s */
int fgets_(char *s, int size, FILE *f) {
	char c;
	int i=0;
	c=fgetc(f);
	/* if EOF stop */
	if (c==EOF) {
		*s='\0';
		return FALSE;
	}
	/* if DOS/MAC-EOL set null string */
	else if (c=='\r') {
	       	c=fgetc(f);
		/* DOS-EOL*/
		if (c=='\n') {
			*s='\0';
		}
		/* MAC-EOL*/
		else {
			ungetc(c,f);
			*s='\0';
		}
		return TRUE;
	}
	/* if UNIX-EOL set null string */
	else if (c=='\n') {
		*s='\0';
		return TRUE;
	}
	/* proceed reading file line */
	else {
		while (c && i<size-1 && c!=EOF) {
			if (c=='\n' || c=='\r') {
				if (c=='\r') {
					c=fgetc(f);
					if (c!='\n') ungetc(c,f);
				}
				break; // end
			}
			*s++=c;
			i++;
			c=fgetc(f);
		}
		*s='\0';
	}
	return TRUE;
}


/******************************************
 *		 PARSING		*
 ******************************************/

/* setAddr()
 * calculate the numerical correspondence of any string label
 * Algorithm Adler32
 * Consulted October 2021 at http://www.ostack.cn/?qa=260790/
 * Used in LOAD() and in proceed() */
int setAddr(char *lp) {
	const uint8_t *buffer = (const uint8_t*)lp;
	uint32_t s1 = 1;
	uint32_t s2 = 0;
	size_t buflen=strlen(lp);

	for (size_t n = 0; n < buflen; n++) {
	   s1 = (s1 + buffer[n]) % 65521;
	   s2 = (s2 + s1) % 65521;
	}
	return (s2 << 16) | s1;
}


/* getLabelAddr()
 * search in the stored addresses the one corresponding to val */
int getLabelAddr(int val) {
	int co=1;
	/* if there's one, return it */
	while (co<=endCore) {
	       if (ln[co]==val) return co;
	       co++;
	}
	/* implicit END */
	if (val==endCode) return endCore+1;
	return -1;
}


/* intHandler()
 * the interrupt function */
void intHandler(int sig) {
	fflush(stdout);
	fflush(stderr);
	fflush(stdin);
	/* terminate program */
	fprintf(stderr,"%s","\n\nsoft: CTRL-C pressed. Execution terminated");
	if (isPie+goPie) {
		fprintf(stderr,"%s\n\n","; PIE is restored.");
		isPie=FALSE;
		goPie=TRUE;
	}
	else fprintf(stderr,"%s\n\n",".");
	/* process option trace-on-stop*/
	if (isTraceOnStop) {
		int i=1, ns=0;
		fprintf(stderr,"Break happened at line %d. Required trace-on-stop variables are:\n\n",l);
		while (i<=stopTOS) {
			ns=searchDEC(onStop[i],decCount);
			if (ns) {
				if (vn[ns].datatype==STRING) {
					char temp[SCREEN];
					int len=(int)strlen(vn[ns].str);
					if (len<SCREEN-4)
						strncpy_(temp,vn[ns].str,SCREEN);
					else {
						strncpy_(temp,vn[ns].str,SCREEN-4);
						strncat_(temp,"...",SCREEN);
					}
					if (!strchr(temp,'\''))
						fprintf(stdout,"%s = '%s' [%s] [%d]\n",vn[ns].name,temp,"STRING",len);
					else if (!strchr(temp,'\"'))
						fprintf(stdout,"%s = \"%s\" [%s] [%d]\n",vn[ns].name,temp,"STRING",len);
					else fprintf(stdout,"%s = {%s} [%s] [%d]\n",vn[ns].name,temp,"STRING",len);
				}
				else if (vn[ns].datatype<ARRAY)
					fprintf(stderr,"%s = %s [%s]\n",vn[ns].name,vn[ns].str,types[vn[ns].datatype/100]);
			}
			i++;
		}
	}

	/* Closing or reprise operations */
	if (!isPie) END(EXIT_FAILURE);
	else {
		l=0;
		isPie=FALSE;
		goPie=TRUE;
		isInterrupt=TRUE;
		scan=bscan=0;
		pattern[0]=upattern[0]='\0';
		resTOS=dotTOS=0;
		signal(SIGINT, intHandler);
	}
}


/* doDebugHelp()
 * print help for debugging */
void doDebugHelp(char *a, int hlen) {
	int j=1;
	int screen=DEBUGSCREEN;
	char temp[COMPSTR];

	/* get screen size*/
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;

	if (!*a) {
		strncpy_(temp,debugCommand[j++],COMPSTR);
		strncat_(temp," ",COMPSTR);
		while (j<LASTDEBUG) {
			strncat_(temp,debugCommand[j],COMPSTR);
			strncat_(temp," ",COMPSTR);
			if (strlen(temp)>screen) {
				strncat_(temp,"\n",COMPSTR);
				screen+=DEBUGSCREEN;
			}
			j++;
		}
		strncat_(temp,"\n",COMPSTR);
		printf("Available debug commands:\n");
		printf("%s",temp);
	}
	/* extended complete help */
	else if (*a=='*') {
		int i=1;
		printf("\n");
		while (i<LASTDEBUG) {
			doDebugHelp(debugCommand[i],strlen(debugCommand[i]));
			printf("\n");
			i++;
		}
		printWide(stdout,"Any integer number is searched in the variables list codes, and the corresponding variable compact status is reported.\n\nA number interval in the form n-m, with no spaces around the dash, shows a compact report on all variables having codes in the interval n-m; intervals are treated as follows:\n\n - if the indices n and m are respectively lower than 1 or greater than the current number of declared variables, they are resized accordingly;\n - if n>m, they are reversed implicitly;\n - if the form n- is used, the variable list goes from n until the last declared variable;\n - if the form -n is used, the variable list goes from from 1 to n included;\n - finally, if the dash only - is used, all variables are listed (as ALLVARS).\n\n\0",80);
		printWide(stdout,"The Enter key executes current line and steps to the next program line.\n\n\0",80);
		printWide(stdout,"Happy snobolling!\n\0",80);
	}
	else {
		int i=1, counter=0, com=0;
		while (i<LASTDEBUG) {
			if (!strncasecmp_(a,debugCommand[i],hlen)) {
				com=i;
				counter++;
			}
			i++;
		}
		if (counter>1) {
			int i=1;
			fprintf(stdout,"Ambiguous help request for '%s'. Available commands:\n",a);
			while (i<LASTDEBUG) {
				if (!strncasecmp_(a,debugCommand[i],strlen(a)))
					printf("%s ",debugCommand[i]);
				i++;
			}
			printWide(stdout,"\n\nPlease specify more characters for the desired command.\n\0",80);
		}
		else if (com==ALLVARSDEBUG) {
			printWide(stdout,"ALLVARS:\nlist all variables, their types and contents, including also null and system variables.\n\0",80);
		}
		else if (com==BASEDEBUG) {
			printWide(stdout,"BASE:\nprint the base string (that is, the string against which patterns are matched), if any.\n\0",80);
		}
		else if (com==BREAKDEBUG) {
			printWide(stdout,"BREAKPOINT (you will be asked for a line number <n>):\nset a breakpoint of the pattern evaluation debugging for the line <n>, where supposedly a pattern evaluation (and not an assignment or a direct command) is contained; up to 256 breakpoints can be used for each execution in the current implementation. When the pattern evaluation is completed, the normal debugging continues, and the pattern evaluation debug will happen again when another breakpoint is met.\n\nThe following rules govern the BREAKPOINT command:\n - If <n> is null, all the current breakpoints are listed.\n - If <n> is the symbol +, the breakpoint is set to the next line.\n - If <n> is the symbol -, the breakpoint is set to the previous line.\n - If <n> is the symbol |, the breakpoint is set to the current line.\n\0",80);
		}
		else if (com==CHANNELSDEBUG) {
			printWide(stdout,"CHANNELS:\nlist the current available I/O channels. The scheme is the following:\n\n The number of opened channels is <m>\n List of opened channels:\n Channel No. 0: output, destination 'screen'\n Channel No. 1: input, source 'keyboard', echoed\n Channel No. 2: input/output, source/destination <chan>\n ...\n Channel No. <m>: input/output, source/destination <chan>\n\n Current input channel is <n>, source is <source> (input exhausted)\n Current output channel is <n> to <dest>\n\nThe string (input exhausted) appears if the last input file is at the End-Of-File (i.e. no more input is possible).\nThe strings echoed/no echo appear according the input feature.\n\0",80);
		}
		else if (com==CLISTDEBUG) {
			printWide(stdout,"CLIST:\nlist the entire program in a beautified format. The current line appears in green.\n\0",80);
		}
		else if (com==CONTDEBUG) {
			printWide(stdout,"CONTINUE:\ncontinue the program and disables the debug mode. The output proceeds emitting the regular output in regular characters. If the program was started with option -i, it will remain in the PIE mode, otherwise it will terminate and get back to the Operating System.\n\0",80);
		}
		else if (com==COUNTDEBUG) {
			printWide(stdout,"COUNT:\nprint the number of system and user variables declared so far.\n\0",80);
		}
		else if (com==CURSORDEBUG) {
			printWide(stdout,"CURSOR:\nprint the cursor value and the string pointed by it so far.\n\0",80);
		}
		else if (com==DATASTRUCT) {
			printWide(stdout,"DATASTRUCT:\nprint information about all the user data. For each function, the scheme is the following:\n\n Name = <s>\n Arguments Proto = <proto> [<n>]\n\nSince the information is all contained into the String argument, DATA() structures can be declared from within PIE.\n\0",80);
		}
		else if (com==DEFINFODEBUG) {
			printWide(stdout,"DEFINED:\nprint information about all the user procedures. For each function, the scheme is the following:\n\n Name = <s>\n   Arguments Proto = <proto> [<n>]\n   Locals Proto = <proto> [<n>]\n   Starting label = <label>\n   Starting line number = <n>\n   NRETURN was used last time? <y/n>\n\nIt must be noted that at present PIE cannot execute user functions from console, because soft is interpreted, not compiled.\n\0",80);
		}
		else if (com==DIRDEBUG) {
			printWide(stdout,"DIR (you will be asked for a directory path <s>):\nlist the files in the specified directory. If the input string is the null string, the files in the current directory are listed.\n\0",80);
		}
		else if (com==DISABLEDEBUG) {
			printWide(stdout,"DISABLE (you will be asked for a line number <n>):\nremove the breakpoint set upon line <n>, according to the following rules:\n\n - If <n> is null, nothing changes.\n - If <n> is the symbol #, all breakpoints are disabled.\n - If <n> is the symbol %, the last breakpoint set is disabled.\n - If <n> is the symbol +, the breakpoint of the next line is removed.\n - If <n> is the symbol -, the breakpoint of the previous line is removed.\n - If <n> is the symbol |, the breakpoint of the current line is removed.\n\0",80);
		}
		else if (com==DEBUGMODE) {
			printWide(stdout,"DEBUGMODE:\ndisable the PIE mode and returns to the line-by-line debug.\n\0",80);
		}
		else if (com==ERASEDEBUG) {
			printWide(stdout,"ERASE:\nremove all instances of the variables, deleting their contents and setting their initial state, apart from the system variables, that remain available.\n\0",80);
		}
		else if (com==FILEDEBUG) {
			printWide(stdout,"FILE:\nprint some data about the current file. In case of a loaded file, the scheme is the following:\n\n File name: <name>\n Directory: <dir>\n Dimension: <n> bytes (<m> kB)\n Lines    : <n>\n\nIn case of a pure PIE session (without file), only the session name is printed.\n\0",80);
		}
		else if (com==HELPDEBUG) {
			printWide(stdout,"HELP (you will be asked for a string <s>):\nprint the help page about the debug command <s>; if <s> is null, a list of the available commands is printed; if <s> is specified, it must be a name of one debug command: a small help about the command is printed. If <s> is an asterisk, the help of all available commands is printed.\n\0",80);
		}
		else if (com==INFODEBUG) {
			printWide(stdout,"INFO:\nprint some info about the debugger.\n\0",80);
		}
		else if (com==LABELSDEBUG) {
			printWide(stdout,"LABELS:\nprint a list of all the labels in the source and where they are located. The scheme is the following:\n\n The number of labels is <m>:\n    1. Label <name> in line <n> has code <n>\n    2. Label <name> in line <n> has code <n>\n    ...\n    <m>. Label END in line <n> has code <n>\n\nNotice that every program must terminate with the label END.\n\0",80);
		}
		else if (com==LISTDEBUG) {
			printWide(stdout,"LIST:\nlist some lines around the current line in a beautified format. Five previous lines and five further lines, with respect to current, are shown (total 11, or less if the previous or further lines are less than required). The current line appears in green. To list the entire program use CLIST or NLIST.\n\0",80);
		}
		else if (com==LOADDEBUG) {
			printWide(stdout,"LOAD (you will be asked for a file name <fname>):\nload the file <fname>, that becomes the current program under evaluation. All registers are reset, for a fresh new execution. The complete path may be specified into <fname>.\n\0",80);
		}
		else if (com==MEMORYDEBUG) {
			printWide(stdout,"MEMORY:\nprint the memory amount of the program.\n\0",80);
		}
		else if (com==MONITORDEBUG || com==SHELLDEBUG) {
			printWide(stdout,"MONITOR or SHELL:\nexit to shell. Type 'exit' to return to soft\n\0",80);
		}
		else if (com==NEXTDEBUG) {
			printWide(stdout,"NEXT:\nexecute current line and step to the next program line (it is a mere clone of the Enter key).\n\0",80);
		}
		else if (com==NLISTDEBUG) {
			printWide(stdout,"NLIST:\nlist the entire program in numbered format. The current line appears in green.\n\0",80);
		}
		else if (com==ORIGINALDEBUG) {
			printWide(stdout,"ORIGINAL:\nlist the original source text of the program (empty lines and comments included).\n\0",80);
		}
		else if (com==PARAMDEBUG) {
			printWide(stdout,"PARAMETERS:\nlist the current execution parameters, all in one. The scheme is the following:\n\n The number of program lines in memory is <n>\n The number of Snobol4 commands executed so far is <n>\n\n Base comparing string is '<str>'\n Evaluation Request string is <str>\n Cursor pointer is <n>\n Previous Cursor pointer is <n>\n Cursor points to <str>\n Remaining base string is '<str>'\n Last pattern is '<str>'\n Rematch flag:  true/false\n Final state:  success/failure\n\nA string <str> is written as <null> in case of empty string.\n\0",80);
		}
		else if (com==PATTERNDEBUG) {
			printWide(stdout,"PATTERN:\nprint the pattern evaluation request and the current pattern situation (that is, the pattern gathered so far). If the base string does not contain the single quote, it is printed enclosed in single quotes; otherwise, if the base string does not contain the double quotes, it is printed enclosed in double quotes; otherwise it is printed enclosed in curly brackets.\n\0",80);
		}
		else if (com==PIEMODE) {
			printWide(stdout,"PIEMODE:\ndisable the line-by-line mode and enter the PIE mode. If PIEMODE is typed during a program execution, the current execution is terminated before stepping in Pie mode.\n\0",80);
		}
		else if (com==QUITDEBUG) {
			printWide(stdout,"QUIT:\nstop the program execution and terminates, both in the line-by-line and the Pie modes. The string \n\n soft debug: End of session. Ok.\n\nappears, to distinguish between a wrong stop (caused by some error) and an intentional stop,\n\0",80);
		}
		else if (com==REMARKDEBUG) {
			printWide(stdout,"REMARK: (you will be asked for a text string <s>):\nwrite string <s> onto the job log file, or the chosen channel, depending on options -j or --joblog. The text in the string <s> is in free format.\n\0",80);
		}
		else if (com==RESETDEBUG) {
			printWide(stdout,"RESET:\nreset the evaluation registers, in order to perform the next evaluation from a fresh start.\n\0",80);
		}
		else if (com==ALLRESETDEBUG) {
			printWide(stdout,"ALLRESET:\nreset the evaluation registers, in order to perform the next evaluation from a fresh start, reset also all program registers, and rewind all input files.\n\0",80);
		}
		else if (com==RUNDEBUG) {
			printWide(stdout,"RUN:\nexecute the program in memory, according to the current mode. All registers are reset before execution, and all input files are set to their start, but all variables are retained.\n\0",80);
		}
		else if (com==SETDEBUG) {
			printWide(stdout,"SET (you will be asked for a <flag> name and for a <state>):\nchange some system flags state, not coordinated by language procedures, where <flag> may be:\n\n - ALTER to enable/disable the alteration of the system variables.\n - PATDEBUG to enable/disable the pattern debug.\n - PRINTC to enable/disable the printing of pattern and created variables.\n - STATS to enable/disable the statistics at the end of the program.\n - TIMING to enable/disable the timing at the end of the program.\n\nIf <flag> is null, the current flags states are printed.\n\nThe ON and OFF states respectively enable and disable the feature; the TOGGLE state inverts the current settings.\n\0",80);
		}
		else if (com==STATEDEBUG) {
			printWide(stdout,"STATE:\ntoggle the printing of a detailed evaluation state after every program line (the state is off by default). The output is in reverse colors, and the scheme is the following:\n\n -- line <n> --\n base string is '<string>' \n pattern request was '<pattern>'\n last retrieved string pattern was '<string>'\n cursor is <n> and points to '<string>'\n last report was a <status>\n\nThe meaning of fields is quite clear; I will only add that the last retrieved string pattern is the pattern result gathered so far, and the string pointed by the cursor is a visualization of the next possible pattern; the status may be a failure or a success, depending on the last execution state. This information is useful to see the Snobol4 process from inside and step by step. Option --final-state prints the same mask (apart from the line number) in normal colors as the last information, after execution.\n\0",80);
		}
		else if (com==TYPEDEBUG) {
			printWide(stdout,"TYPE (you will be asked for a file name <fname>):\nprint the content of the textual file <fname>.\n\0",80);
		}
		else if (com==TRACEDEBUG) {
			printWide(stdout,"TRACE (you will be asked for a variable name <var>):\nmark variable <var> for tracing. If <var> is null, all the variables under tracing are listed.\n\0",80);
		}
		else if (com==UNTRACEDEBUG) {
			printWide(stdout,"UNTRACE (you will be asked for a variable name <var>):\nremove the trace mark from variable <var>. If <var> is equal to the symbol #, the tracing is removed from all variables. If <var> is null, nothing changes.\n\0",80);
		}
		else if (com==VERSIONDEBUG) {
			printWide(stdout,"VERSION:\nprint current soft version\n\0",80);
		}
		else if (com==WATCHDEBUG) {
			printWide(stdout,"WATCH (you will be asked for a variable name <var>):\nprint detailed information about the argument variable identified by <var>, which may be a natural or a created variable. if it is an array element, it must be given along with the coordinates (e.g. LIST[1,3]). WATCH treats also referenced variables in the form $VAR.\n\0",80);
		}
		else {
			printWide(stdout,"The help for this command is not ready yet...\n\0",80);
		}
	}
}


/* getDebugCommand()
 * select the debug command */
int getDebugCommand(char *a, int *len, char *other) {
	int j=1, res=0;
	*other='\0';
	*len=strlen(a);
	if (*a=='\0') return NODEBUG;
	else if (*a=='-') return NODEBUG;
	while (j<LASTDEBUG) {
		if (!strncasecmp_(debugCommand[j],a,*len)) {
			res=j;
			break;
		}
		j++;
	}
	/* one only match, return the number */
	if (j<LASTDEBUG) return res;
	return NODEBUG;
}


/* inspect()
 * perform the WATCH debug command */
void inspect(char *el) {
	char name[COMPSTR], *n=name;
	char temp[COMPSTR];
	int type=0, ns, ms, ttype;
	while (isblank(*el)) el++;

	if (*el=='$') {
		char *pb=p;
		el++;
		p=el;
		strncpy_(temp,GP(&ttype),COMPSTR);
		el=temp;
		p=pb;
	}

	/* copy name */
	ns=searchDEC(el,decCount);
	if (ns) {
		strncpy_(name,el,(int)(_len+1));
		el+=_len;
		n+=_len;
	}

	/* it was a natural variable */
	if (!*el) {
		type=1; // natural
		*n='\0';
	}
	/* an array element */
	else if (*el=='[') {
		int st=0;
		type=2; // array element
		while (*el) {
			if (*el=='[') st++;
			else if (*el==']' && st) st--;
			else if (*el==']' && st) break;
			*n++=*el++;
		}
		if (*el==']') *n++=*el++;
		*n='\0';
	}
	/* a DATA element */
	else if (*el=='(') {
		int st=0;
		type=3; // DATA
		while (*el) {
			if (*el=='(') st++;
			else if (*el==')' && st) st--;
			else if (*el==')' && st) break;
			*n++=*el++;
		}
		if (*el==')') *n++=*el++;
		*n='\0';
	}
	/* get element code and type */
	ms=decCount;
	while (ms>0) {
		if (!strcasecmp(vn[ms].name,name)) {
			break;
		}
		ms--;
	}
	if (ms && ms!=ns) ns=ms;
	ttype=vn[ns].datatype;
	if (ttype>PREDEF) ttype-=PREDEF;

	/* ns remains null */
	if (!ns) {
		printf("\nVariable not found\n");
		return;
	}

	/* print single natural name */
	if (type==1) {
		printf("Name :  %s\n",realName(vn[ns].name));
		printf("Code :  %d\n",ns);
	       	if (vn[ns].ref!=ns) printf("Ref  :   %s\n",vn[vn[ns].ref].name);
		printf("Type :  %s\n",types[ttype/100]);
		if (ttype<PATTERN) {
			printf("Text :  %s",vn[ns].str);
			if (vn[ns].str[0]) printf("%s"," ");
			if (ttype==STRING) printf("[%d]",(int)strlen(vn[ns].str));
			printf("\n");
			if (ttype<STRING) {
		       		printf("Num  :  %.15G\n",strtod(vn[ns].str,NULL));
			}
		}
		else if (ttype==PATTERN) {
			printf("Patt :  %s\n",vn[ns].str);
		}
		else if (ttype==ARRAY) {
			printf("Proto:  ['%s']\n",vn[ns].proto);
		}
		else if (ttype==DATA) {
			printf("Proto:  '%s'\n",vn[ns].proto);
		}
		else if (ttype==NAME) {
			printf(".Name:  %s\n",vn[ns].str);
		}
		if (vn[ns].iotype>0) {
			printf("I/O  :  %s\n",vn[ns].iotype==VWRITE?"Output":"Input");
			printf("Chan :  %d\n",vn[ns].datachan);
		}
	}
	/* array element */
	else if (type==2) {
		char *pb=p;
		char temp[COMPSTR];
		p=name;
		isIF=TRUE; // avoid printing error
		strncpy_(temp,GP(&ttype),COMPSTR);
		if (!report) {
			report=TRUE;
			printf("\nIllegal array item requested\n");
		}
		else {
			printf("Name :  %s\n",name);
			printf("Code :  %d\n",ns);
		       	if (vn[ns].ref!=ns) printf("Ref  :  %s\n",vn[vn[ns].ref].name);
			printf("Type :  %s\n",types[ttype/100]);
			if (ttype<PATTERN) {
				printf("Text :  %s\n",temp);
				if (ttype<STRING) {
			       		printf("Num  :  %.15G\n",strtod(temp,NULL));
				}
			}
		}
		p=pb;
	}
	/* DATA element */
	else if (type==3) {
		printf("Name :  %s\n",name);
		printf("Code :  %d\n",ns);
	       	if (vn[ns].ref!=ns) printf("Ref  :   %s\n",vn[vn[ns].ref].name);
		printf("Type :  %s\n",types[ttype/100]);
		if (ttype<PATTERN) {
			printf("Text :  %s\n",vn[ns].str);
			if (ttype<STRING) {
		       		printf("Num  :  %.15G\n",strtod(vn[ns].str,NULL));
			}
		}
	}
}


/* printCurState()
 * print current state for pattern evaluation in Debug */
void printCurState(void) {
	printf("base string is '%s'\n",FIRST);
	printf("pattern request was '%s'\n",second);
	printf("last retrieved string patterns was '%s'\n",pattern);
	printf("cursor is %d and points to '%s'\n",scan, CFIRST);
	printf("last report was a %s\n",report?"success":"failure");
}


/* parse()
 * The parser
 * It's a general purpose routine that executes lines contained into the h
 * line-memory buffer, from the 'start' line to the 'end' line
 * System basic function */
void parse(int start) {
	char BASESTR[COMPSTR]; // don't make it global, it must be local
	char curr[COMPSTR],prev[COMPSTR];
	int isHistory=FALSE, hasFailed=FALSE, noOnFalse=TRUE;
	/* check/set starting parameters */
	l=start;
	strncpy_(prev,"Snobol4",COMPSTR);
	strncpy_(curr,"snobol",COMPSTR);
	/* read history */
	if (isDebug || goPie) read_history(DEBUGHISTORY);

	/* execute line by line */
	while(!isQuit) {
		/* interrupt */
		if (isInterrupt) {
			isInterrupt=FALSE;
			continue;
		}
		/* break on END */
		if (ln[l]==endCode || l>endCore) {
			if (isPie) {
				l=0;
				goPie=TRUE;
				isPie=FALSE;
			}
			else break;
		}
		/* skip empty lines in memory */
		if (m[l] && *m[l]) {
			int i;
			noOnFalse=TRUE;
			strncpy_(BASESTR,m[l],COMPSTR);
			p=BASESTR;
			if (isStLimit>=0) {
				/* STLIMIT was reached (not for final END) */
				if (sStatms>isStLimit && ln[l]!=endCode) {
					l=0;
					if (goPie+isPie) {
						goPie=TRUE;
						isPie=FALSE;
					}
					perror_(__LINE__,51,l);
				}
			}
			if (isFlow && !isDebug && !goPie) {
				int k=funcTOS*3;
				printf("[%03d]\t",l);
				while (k>0) {
					putc(' ',stdout);
					k--;
				}
				printf("%s\n",m[l]);
			}
			if (isDebug) {
				printf("%s",INVCOLOR);
				printf("[%d]\t%s\n",l,m[l]);
				printf("%s",RESETCOLOR);
			}
			for (i=0;i<COMPSTR;i++) use[i]=0;
			for (i=0;i<COMPSTR;i++) pattern[i]='\0';

			/* perform debugging and parse user command */
			while (isDebug || goPie) {
				int com=-1, tlen;
				char dcomm[COMPSTR], arg[COMPSTR];
				char *an=(char *)NULL, *t;
				char other[COMPSTR];
				/* store for not replicating history cmds */
				char ans[COMPSTR];
				strncpy_(ans,"Snobol4!",COMPSTR);

				while (com<0) {
					/* get first command */
					if (an && *an) {
						free(an);
						an=(char *)NULL;
					}
					an=readline(prompt);
					if (!an) continue;
					/* ... */
					if (!strncasecmp_(an,"say",3)) {
						printf("goPie=%d, isPie=%d, l=%d\n",goPie,isPie,l);
						continue;
					}
					/* force digit/dash */
					if (*an && (isdigit(*an) || *an=='-')) {
						com=WRONGDEBUG;
						break;
					}
					while (isblank(*(an+strlen(an)-1)))
						*(an+strlen(an)-1)='\0';
					strncpy_(prev,curr,COMPSTR);
					strncpy_(curr,rl_line_buffer,COMPSTR);
					/* separate argument from command */
					t=dcomm; // command
					while (isblank(*an)) an++;
					while (*an && isalpha(*an)) *t++=*an++;
					*t='\0';
					t=arg;	// argument
					while (isblank(*an)) an++;
					while (*an) *t++=*an++;
					*t='\0';
					/* search */
					com=getDebugCommand(dcomm,&tlen,other);
					if (arg[0]) com=NODEBUG;
					if (com==WRONGDEBUG) break;
				}
				an=rl_line_buffer;
				if (an && *an) {
					if (strcmp(curr,prev)) {
						add_history(curr);
						isHistory=TRUE;
					}
					strncpy_(ans,an,COMPSTR);
				}
				if (isInterrupt) {
					isInterrupt=FALSE;
					continue;
				}
				/* The ENTER key to step to
				 * the next program line */
				if (!*an) {
					if (!goPie) break;
					else com=0;
				}
				/* NEXT to step to next program line */
				if (com==NEXTDEBUG) {
					if (!goPie) break;
				}
				/* QUIT let the program /and/ the debug end*/
				else if (com==QUITDEBUG) {
					isQuit=TRUE;
					isDebug=FALSE;
					if (!goPie) printf("\nsoft debug: End of session. Ok.\n\n");
					else printf("\nsoft: End of PIE session. Ok.\n\n");
					goPie=FALSE;
					continue;
				}
				/* BASE inform on base string */
				else if (com==BASEDEBUG) {
					if (FIRST[0]) {
						printf("Base string is\n%s\n",FIRST);
						printf("Base string from cursor is\n%s\n",CFIRST);
					}
					else {
						printf("Base string is\n<null>.\n");
						printf("Base string from cursor is\n<null>.\n");
					}
				}
				/* BREAK set breakpoint */
				else if (com==BREAKDEBUG) {
					int val;
					char *an;
					if (noFile) continue;
					printf("Set breakpoint on line: ");
					an=getString(TRUE);
					while (isblank(*an)) an++;
					/* list all breakpoints */
					if (!*an) {
						int i=1;
						printf("Current breakpoints:\n");
						if (!breakTOS) printf("none.\n");
						else {
							while (i<breakTOS) {
								printf("%d, ",breaks[i]);
								i++;
							}
							printf("%d.",breaks[breakTOS]);
						}
					}
					else {
						breakTOS++;
						if (breakTOS>=VLIMIT) {
							printf("Too much breakpoints. Breakpoint not set.\n");
						}
						else {
							if (*an=='+' && !*(an+1)) {
								breaks[breakTOS]=l+1;
								printf("Breakpoint set on line %d. Ok.\n",l+1);
							}
							else if (*an=='-' && !*(an+1)) {
								breaks[breakTOS]=l-1;
								printf("Breakpoint set on line %d. Ok.\n",l-1);
							}
							else if (*an=='|' && !*(an+1)) {
								breaks[breakTOS]=l;
								printf("Breakpoint set on line %d. Ok.\n",l);
							}
							else {
								val=strtol(an,&an,10);
								if (!*an) {
									breaks[breakTOS]=val;
									printf("Breakpoint set on line %d. Ok.\n",val);
								}
								else printf("Irregular line number. Breakpoint not set.\n");
							}
						}
					}
				}
				/* CHANNELS list channel parameters */
				else if (com==CHANNELSDEBUG) {
					int i;
					fprintf(stdout,"\n%s %d\n"," The number of opened channels is",fileTOS+1);
					fprintf(stdout,"%s\n"," List of opened channels:");
					for (i=0;i<=fileTOS;i++) {
						fprintf(stdout," Channel No. %d: %s, %s '%s'",i,channel[i].wayout==VREAD?"input":"output",channel[i].wayout==VREAD?"source":"destination",channel[i].ioname);
						if (channel[i].wayout==VREAD) {
							fprintf(stdout,", %s",channel[i].isCanon?"echoed":"no echo");
						}
						fprintf(stdout,"%s","\n");
					}
					fprintf(stdout,"\n%s %d"," Current input channel is",inF);
					if (inF==1 || channel[inF].isKYB)
						fprintf(stdout,"%s\n",", source is the keyboard");
					else {
						fprintf(stdout,"%s '%s'",", source is file",channel[inF].ioname);
						if (inF>=fileTOS) {
							int k=fileTOS;
							while (channel[k].wayout!=VREAD && k>0)
								k--;
							if (k>1 && feof(channel[k].stream)) {
								fprintf(stdout,"%s\n"," (input exhausted)");
							}
						}
						fprintf(stdout,"\n");
					}
					fprintf(stdout,"%s %d"," Current output channel is",outF);
					if (channel[outF].stream==stdout || channel[outF].stream==stderr)
						fprintf(stdout,"%s\n"," to the screen");
					else {
						fprintf(stdout,"%s '%s'\n"," to file",channel[outF].ioname);
					}
					fprintf(stdout,"%s","\n");
					report=TRUE;
				}
				/* NLIST (Numbererd complete LIST) to print
				 * the whole listing */
				else if (com==NLISTDEBUG) {
					int i=0, w=3, len=0;
					int offs=1, offe=endCore;
					if (noFile) continue;
					for (i=offs;i<offe;i++) {
						if (ln[i]>0) {
							len=(int)strlen(label[i]);
							if (len>w) w=len;
						}
					}
					for (i=offs;i<=offe;i++) {
						if (i==l) printf(GREENCOLOR);
						printf("[%03d] ",i);
						if (finalCore && i==finalCore)
							listLine(finalCore,w);
						else listLine(i,w);
						if (i==l) printf("%s",RESETCOLOR);
							isError=FALSE;
					}
					fprintf(stdout,"%s","\n");
					isError=FALSE;
				}
				/* CLIST (Complete LIST) to print the
				 * whole listing */
				else if (com==CLISTDEBUG) {
					int i=0, w=3, len=0;
					int offs=1, offe=endCore;
					if (noFile) continue;
					for (i=offs;i<=offe;i++) {
						if (ln[i]>0) {
							len=(int)strlen(label[i]);
							if (len>w) w=len;
						}
					}
					fprintf(stdout,"%s","\n");
					for (i=offs;i<=offe;i++) {
						if (i==l) printf(GREENCOLOR);
						if (finalCore && i==finalCore)
							listLine(finalCore,w);
						else listLine(i,w);
						if (i==l) printf(RESETCOLOR);
					}
					fprintf(stdout,"%s","\n");
					isError=FALSE;
				}
				/* CONT let the debug end and the program
				 * continue to continue its execution */
				else if (com==CONTDEBUG) {
					if (noFile) continue;
					isDebug=FALSE;
					printf("Continuing out of debug.\n");
					break;
				}
				/* COUNT inform on variable number */
				else if (com==COUNTDEBUG) {
					printf("System variables are in the range 1-%d,\n",sDefVar);
					if (decCount>sDefVar) {
						printf("User variables are in the range %d-%d.\n",sDefVar+1,decCount);
					}
					else {
						printf("No user variables yet\n");
					}
				}
				/* CURSOR inform on scan */
				else if (com==CURSORDEBUG) {
					if (*(CFIRST))
						printf("Cursor is at position %d and points to\n%s\n",scan,CFIRST);
					else
						printf("Cursor is at position %d and points to\n<null>\n",scan);
				}
				/* DEBUGMODE */
				else if (com==DEBUGMODE) {
					isDebug=TRUE;
					goPie=FALSE;
					strncpy_(prompt,"\n> ",COMPSTR);
					printf("Debug Mode activated.\n");
				}
				/* DATASTRUCT */
				else if (com==DATASTRUCT) {
					int i;
					if (!dataTOS) {
						printf("No user data yet.\n\n");
						continue;
					}
					printf("User procedures list:\n\n");
					for (i=1;i<=dataTOS;i++) {
						printf("Name = %s\n",datafunc[i].name);
						printf("Arguments Proto = '%s' [%d]\n",datafunc[i].proto,datafunc[i].num);
					}
				}
				/* DEFINED print user defined procedures data */
				else if (com==DEFINFODEBUG) {
					int i;
					if (!defineTOS) {
						printf("No user procedures yet.\n\n");
						continue;
					}
					printf("User procedures list:\n\n");
					for (i=1;i<=defineTOS;i++) {
						printf("Name = %s\n",definefunc[i].name);
						printf("  Arguments Proto = '%s' [%d]\n",definefunc[i].argproto,definefunc[i].anum);
						printf("  Locals Proto = '%s' [%d]\n",definefunc[i].otherproto,definefunc[i].lnum);
						printf("  Starting label = %s\n",definefunc[i].startlabel);
						printf("  Starting line number = %d\n",definefunc[i].label);
						printf("  NRETURN was used last time? %s\n\n",definefunc[i].nreturn?"yes":"no");
					}
				}
				/* DIR list directory */
				else if (com==DIRDEBUG) {
					char dir[COMPSTR], *an;
					DIR *dp;
  					struct dirent *ep;
					int c=0;
					printf("Directory name: ");
					an=getString(TRUE);
					while (isblank(*an)) an++;
					if (*an) strncpy_(dir,process(an),COMPSTR);
					else strncpy_(dir,"./",COMPSTR);
					dp = opendir(dir);
					if (dp != NULL) {
    						while ((ep = readdir(dp))) {
							if (!strcasecmp(get_ext(ep->d_name),"sno") || !strcasecmp(get_ext(ep->d_name),"sbl")) {
								c=c+strlen(ep->d_name)+2;
								if (c>=sysWidth-10) {
									c=strlen(ep->d_name)+3;
									printf("%s","\n");
								}
								printf("%s",ep->d_name);
								printf("%s","  ");
							}
							else if (is_dir(ep->d_name) && ep->d_name[0]!='.') {
								c=c+strlen(ep->d_name)+3;
								if (c>=sysWidth-10) {
									c=strlen(ep->d_name)+3;
									printf("%s","\n");
								}
								printf(BLUECOLOR);
								printf("%s",ep->d_name);
								printf("%s","/  ");
								printf("%s",RESETCOLOR);
							}
						}
						(void) closedir(dp);
  					}
  					else {
    						printf("Couldn't open directory %s",dir);
					}
				}
				/* DISABLE remove breakpoint */
				else if (com==DISABLEDEBUG) {
					int val;
					char *an;
					if (noFile) continue;
					printf("Disable breakpoint on line: ");
					an=getString(TRUE);
					while (isblank(*an)) an++;
					/* remove all breakpoints */
					if (!strcasecmp(an,"#")) {
						int i=1;
						while (i<=breakTOS) {
							breaks[i]=0;
							i++;
						}
						breakTOS=0;
						printf("All breakpoints were removed.\n");
					}
					else if (!*an);
					else {
						if (!strcasecmp(an,"+")) val=l+1, an++;
						else if (!strcasecmp(an,"-")) val=l-1, an++;
						else if (!strcasecmp(an,"|")) val=l, an++;
						else if (!strcasecmp(an,"%")) val=breaks[breakTOS], an++;
						else val=strtol(an,&an,10);
						if (val<1) val=1;
						if (val>endCore) val=endCore;
						if (val && !*an) {
							int i=breakTOS;
							if (i>0) while (i>0) {
								if (breaks[i]==val) {
									printf("Breakpoint removed from line %d.\n",val);
									breaks[i]=0;
									break;
								}
								i--;
							}
							else printf("No previous breakpoint found, none removed.\n");
						}
						else printf("Irregular line number. Breakpoint not removed.\n");
					}
				}
				/* ERASE removes all variables */
				else if (com==ERASEDEBUG) {
					int ns=decCount;
					while (ns>sDefVar) {
						strncpy_(vn[ns].name,VOIDS,COMPSTR);
						strncpy_(vn[ns].str,VOIDS,COMPSTR);
						strncpy_(vn[ns].proto,VOIDS,COMPSTR);
						strncpy_(vn[ns].argparam,VOIDS,COMPSTR);
						vn[ns].datatype=vn[ns].isData=0;
						vn[ns].dim=vn[ns].ref=vn[ns].num=0;
						vn[ns].iotype=vn[ns].datachan=0;
						vn[ns].isData=vn[ns].isCode=0;
						vn[ns].strmem=vn[ns].size=0;
						ns--;
					}
					decCount=sDefVar;
				}
				/* FILE print file info */
				else if (com==FILEDEBUG) {
					char ptr[COMPSTR];
					char name[COMPSTR];
					struct stat st;
					int size=0;
					if (!noFile) {
						strncpy_(name,filename,COMPSTR);
						stat(name, &st);
						size = st.st_size;
						realpath(dirname(name),ptr);
						printf("\nFile name: %s\n",basename(filename));
						printf("Directory: %s\n",ptr);
						printf("Dimension: %d bytes (%.3f kB)\n",size,size/1024.0);
						printf("Lines    : %d\n\n",endCore);
					}
					else {
						printf("%s\n",filename);
					}
				}
				/* HELP show the debug commands list */
				else if (com==HELPDEBUG) {
					char *an;
					printf("Help on command: ");
					an=getString(TRUE);
					while (isblank(*an)) an++;
					doDebugHelp(an,(int)strlen(an));
				}
				/* LABELS list evaluated labels
				 * of the LOADed program */
				else if (com==LABELSDEBUG) {
					int k, h=0;
					fprintf(stdout,"\n%s %d:\n"," The number of labels is",lnTOS);
					for (k=1;k<=endCore;k++) {
						if (ln[k]) fprintf(stdout," %3d. Label %s in line %d has code %d\n",++h,label[k],k,ln[k]);
					}
					fprintf(stdout,"%s","\n");
				}
				/* LIST print listing */
				else if (com==LISTDEBUG) {
					int i=0, w=3, len=0;
					int off=5, offs=l-off, offe=l+off;
					int breport=report;
					if (noFile) continue;
					i=5;
					while (i>0) {
						if (m[i] && !*m[i]) offs--;
						if (offs<=1) break;
						i--;
					}
					i=5;
					while (i>0) {
						if (m[i] && !*m[i]) offe++;
						if (offe>=endCore) break;
						i--;
					}
					report=TRUE;
					if (offs<1) offs=1;
					if (offe>endCore) offe=endCore;
					/* Note: keeps program track */
					for (i=offs;i<offe;i++) {
						if (ln[i]>0) {
							len=(int)strlen(label[i]);
							if (len>w) w=len;
						}
					}
					fprintf(stdout,"%s","\n");
					for (i=offs;i<offe;i++) {
						if (i==l) printf(GREENCOLOR);
						if (finalCore && i==finalCore)
							listLine(finalCore,w);
						else if (m[i] && *m[i]) listLine(i,w);
						else printf("\n");
						if (i==l) printf("%s",RESETCOLOR);
					}
					listLine(offe,w);
					fprintf(stdout,"%s","\n");
					isError=FALSE;
					report=breport;
				}
				/* TYPE print a file */
				else if (com==TYPEDEBUG) {
					char *an, text[COMPSTR], fname[COMPSTR];
					FILE *fd;
					printf("Type file: ");
					an=readline("");
					while (isblank(*(an+strlen(an)-1))) *(an+strlen(an)-1)='\0';
					strncpy_(fname,an,COMPSTR);
					fd=fopen(fname,"r"); // confirmed "r"
					if (!fd) printf("File %s not found.\n",fname);
					else {
						while (fgets_(text,COMPSTR,fd))
							printf("%s\n",text);
						fclose(fd);
					}
				}
				/* LOAD load a file */
				else if (com==LOADDEBUG) {
					char *an;
					printf("Load file: ");
					an=readline("");
					while (isblank(*(an+strlen(an)-1))) *(an+strlen(an)-1)='\0';
					if (*an<'a' && *an!='.' && *an!='/') {
						printf("\nIrregular file name given.\n");
					}
					if (*an) {
						strncpy_(filename,an,COMPSTR);
						noFile=FALSE;
						setup();
						reset_();
					}
					else {
						printf("\nNo file name given.\n");
					}
				}
				/* INFO */
				else if (com==INFODEBUG) {
					printf("I created this debugger in 2021.\n");
					printf("I hope you like it as I do.\n");
				}
				/* MEM print memory status */
				else if (com==MEMORYDEBUG) {
					printf("Occupied memory = %d bytes\n",memStatus());
				}
				/* MONITOR / SHELL go to shell */
				else if (com==MONITORDEBUG || com==SHELLDEBUG) {
					system(SHELLEX);
					fprintf(stdout,"\n");
				}
				/* ORIGINAL print the original list */
				else if (com==ORIGINALDEBUG) {
					int i;
					if (noFile) continue;
					for (i=1;i<=endCore;i++) {
						if (mb[i] && *mb[i]) fprintf(stdout,"%s\n",mb[i]);
						else fprintf(stdout,"%s\n","");
					}
				}
				/* PARAMETERS list system parameters */
				else if (com==PARAMDEBUG) {
					int ck=*CFIRST;
					if (!noFile) fprintf(stdout,"\n%s %d\n"," The number of program lines in memory is",endCore);
					fprintf(stdout,"%s %d\n"," The number of Snobol4 commands executed so far is",sStatms);
					if (!noFile) fprintf(stdout,"%s %d\n"," The next line to be executed is",l);
					fprintf(stdout,"\n%s '%s'\n"," Base comparing string is",FIRST[0]?FIRST:"<null>");
					fprintf(stdout,"%s %s\n"," Evaluation Request string is",second[0]?second:"<null>");
					fprintf(stdout,"%s %d\n"," Cursor pointer is",scan);
					fprintf(stdout,"%s %d\n"," Previous Cursor pointer is",bscan);
					if (ck) fprintf(stdout,"%s %c\n"," Cursor points to",*CFIRST?*CFIRST:'\0');
					else fprintf(stdout,"%s %s\n"," Cursor points to","<null>");
					fprintf(stdout,"%s '%s'\n"," Remaining base string is",*CFIRST?CFIRST:"<null>");
					fprintf(stdout,"%s '%s'\n"," Last pattern string is",pattern[0]?pattern:"<null>");
					fprintf(stdout,"%s %s\n",  " Rematch flag: ",rightPos?"true":"false");
					fprintf(stdout,"%s %s\n"," Final state: ",report?"success":"failure");
					fprintf(stdout,"%s","\n");
				}
				/* PATTERN inform on pattern */
				else if (com==PATTERNDEBUG) {
					/* pattern evaluation */
					if (FIRST[0]) {
						if (second[0]) {
							printf("Pattern evaluation is\n%s  %s\n",printQuoted(FIRST),second);
						}
						else {
							printf("Pattern evaluation is %s\n",printQuoted(FIRST));
						}
					}
					else {
						printf("Pattern evaluation is <null>\n");
					}
					/* pattern so far */
					if (pattern[0]) {
						printf("Last pattern string is\n%s\n",pattern);
					}
					else {
						printf("Last pattern string is <null>\n");
					}
				}
				/* PIEMODE */
				else if (com==PIEMODE) {
					isDebug=FALSE;
					goPie=TRUE;
					strncpy_(prompt,"\n$ ",COMPSTR);
					printf("PIE Mode activated.\n");
				}
				/* REMARK print on the job file */
				else if (com==REMARKDEBUG) {
					char ttime[COMPSTR];
					char tdate[COMPSTR];
					char *an;
					printf("Remark text (in free format):\n");
					an=getString(TRUE);

					/* set time */
					snprintf(ttime,COMPSTR,"%02d:%02d:%02d",getHour(),getMin(),getSec());
					snprintf(tdate,COMPSTR,"%02d %s %02d",getDay(),getMonthString(),getYear()-2000);
					/* print to job log */
					if (isDefJobLog) {
						FILE *fd;
						fd=fopen(joblog,"a"); // OK "a"
						/* TODO check for !fd*/
						if (fd) {
							fprintf(fd,"[%s - %s - %s] %s\n",username,tdate,ttime,an);
							fclose(fd);
						}
					}
					else {
						fprintf(channel[outF].stream,"[%s - %s - %s] %s\n",username,tdate,ttime,an);
					}
				}
				/* RESET erase evaluation data */
				else if (com==RESETDEBUG) {
					scan=bscan=0;
				}
				/* ALLRESET erase evaluation data and all */
				else if (com==ALLRESETDEBUG) {
					reset_();
				}
				/* RUN execute the program in memory
				 * Note: isPie is a hook for re-enabling
				 * goPie after execution*/
				else if (com==RUNDEBUG) {
					if (noFile) continue;
					reset_();
					if (goPie) isPie=TRUE;
					else isPie=FALSE;
					goPie=FALSE;
					l=0;
					printf("\n");
					break;
				}
				/* SET to set some features from PIE */
				else if (com==SETDEBUG) {
					char *an, dest[COMPSTR];
					int state=-999;
					printf("Set flag : ");
					an=getString(TRUE);
					strncpy_(dest,an,COMPSTR);
					if (*an) {
						printf("Set state: ");
						an=getString(TRUE);
						if (!strncasecmp_(an,"ON",2)) state=1;
						else if (!strncasecmp_(an,"OFF",3)) state=0;
						else if (!strncasecmp_(an,"TOGGLE",6)) state=-1;
						else if (*an) printf("%s: Wrong specifier.",an);
					}
					if (!*an) {
						printf("Current states:\n");
						printf("ALTER    = %d\n",isToAlter);
						printf("PATDEBUG = %d\n",isCommandDebug);
						printf("PRINTC   = %d\n",isPrintComplete);
						printf("STATS    = %d\n",isStats);
						printf("TIMING   = %d\n",isTiming);
					}
					else if (!strcasecmp(dest,"ALTER")) {
						if (state==1) isToAlter=TRUE;
						else if (!state) isToAlter=FALSE;
						else if (state==-1)
							isToAlter=isToAlter?FALSE:TRUE;
					}
					else if (!strcasecmp(dest,"PATDEBUG")) {
						if (state==1) isCommandDebug=TRUE;
						else if (!state) isCommandDebug=FALSE;
						else if (state==-1)
							isCommandDebug=isCommandDebug?FALSE:TRUE;
					}
					else if (!strcasecmp(dest,"PRINTC")) {
						if (state==1) isPrintComplete=TRUE;
						else if (!state) isPrintComplete=FALSE;
						else if (state==-1)
							isPrintComplete=isPrintComplete?FALSE:TRUE;
					}
					else if (!strcasecmp(dest,"STATS")) {
						if (state==1) isStats=TRUE;
						else if (!state) isStats=FALSE;
						else if (state==-1)
							isStats=isStats?FALSE:TRUE;
					}
					else if (!strcasecmp(dest,"TIMING")) {
						if (state==1) isTiming=TRUE;
						else if (!state) isTiming=FALSE;
						else if (state==-1)
							isTiming=isTiming?FALSE:TRUE;
					}
					else printf("%s: Inexistent feature.",dest);
				}
				/* STATE toggle printing state */
				else if (com==STATEDEBUG) {
					printState=printState?FALSE:TRUE;
					if (printState)
						printf("State printing enabled.\n");
					else printf("State printing disabled.\n");
				}
				/* TRACE set tracing on var */
				else if (com==TRACEDEBUG) {
					int ns;
					char name[COMPSTR], *t=name, *an;
					printf("Trace variable: ");
					an=getString(TRUE);
					while (isnamechar(an) || *an=='(' || *an==')') *t++=*an++;
					*t='\0';
					if (traceTOS>PSTACK) {
						printf("Too much traced variables. Trace not set.\n");
					}
					else if (!name[0]) {
						int i=0, hasPrinted=FALSE;
						printf("Tracing set for :\n");
						while (i<traceTOS) {
							if (trace[i]) {
								printf("variable #%d %s\n",trace[i],realName(vn[trace[i]].name));
								hasPrinted=TRUE;
							}
							i++;
						}
						if (!hasPrinted) printf("none.\n");
					}
					else {
						ns=searchDEC(name, decCount);
						if (ns) {
							int j=0, ttype=vn[ns].datatype;
							if (ttype>PREDEF) ttype-=PREDEF;
							if (ttype>=ARRAY) {
								printf("Cannot trace created variables. Trace not set.\n");
							}
							else {
								while (j<traceTOS) {
									if (!trace[j]) {
										trace[j]=ns;
										break;
									}
									j++;
								}
						       		if (j>=traceTOS) {
									trace[traceTOS]=ns;
									traceTOS++;
								}
								printf("Set tracing for %s.\n",realName(vn[ns].name));
							}
						}
						else {
							printf("Variable not found. Trace not set.\n");
						}
					}
				}
				/* UNTRACE remove tracing on var */
				else if (com==UNTRACEDEBUG) {
					int ns;
					char name[COMPSTR];
					printf("Stop tracing variable: ");
					strncpy_(name,getString(TRUE),COMPSTR);
					if (!name[0]);
					else if (!strcasecmp(name,"#")) {
						int i=0;
						while (i<traceTOS) {
							trace[i]=0;
							i++;
						}
						traceTOS=0;
						printf("Removed tracing from all variables.\n");
					}
					else {
						ns=searchDEC(name,decCount);
						if (ns) {
							int j=0;
							while (j<traceTOS) {
							       	if (trace[j]==ns) {
							       		trace[j]=0;
							       		break;
							       	}
							       	j++;
						       	}
						       	if (j>=traceTOS) {
								printf("Variable not found, no tracing removed.\n");
							}
							printf("Removed tracing from %s\n",realName(vn[ns].name));
						}
						else {
							printf("Variable not found, no tracing removed.\n");
						}
					}
				}
				/* VERSION print version */
				else if (com==VERSIONDEBUG) {
					printVersion(FALSE);
					printHelpBanner();
				}
				/* WATCH explore in detail a variable */
				else if (com==WATCHDEBUG) {
					char arg[COMPSTR];
					printf("Watch variable: ");
					strncpy_(arg,getString(TRUE),COMPSTR);
					inspect(arg);
				}
				/* a number N or an interval N-M prints the
				 * correspondent variables range */
				else if (com==ALLVARSDEBUG || (*an && isdigit(*an)) || *an=='-') {
					char *q=an;
					int i, fs=decCount, ns=-1;
					if (com==ALLVARSDEBUG) {
						ns=1;
						fs=decCount;
					}
					else if (*q=='-' && (!*(q+1) || *(q+1)==' ')) {
						ns=1;
						fs=decCount;
					}
					else if (*q=='-' && *(q+1)) {
						q++;
						ns=1;
						fs=strtol(q,&q,10);
					}
					else if (isdigit(*q)) {
						ns=strtol(q,&q,10);
						if (*q=='-') {
							q++;
							if (!*q && *q==' ') 
								fs=decCount;
							else if (isdigit(*q)) 
								fs=strtol(q,&q,10);
							//else printf("Cannot understand the interval.\n");
						}
						else if (!*q || (*q==' ')) 
							fs=ns;
						else printf("Cannot understand the interval.\n");
					}
					if (ns>decCount) ns=decCount;
					if (ns<1) ns=1;
				       	if (fs>decCount) fs=decCount;
				       	if (fs<1) fs=1;
					for (i=ns;i<=fs;i++) {
						int tt=vn[i].datatype;
						char out[COMPSTR];
						if (strlen(vn[i].str)>SCREEN) {
							strncpy_(out,vn[i].str,SCREEN);
							strncat_(out,"...",COMPSTR);
						}
						else strncpy_(out,vn[i].str,COMPSTR);
						if (tt>PREDEF) tt-=PREDEF;
							printf("[%d][%04d] ==> %s = '%s' [%s]\n",i,(int)strlen(vn[i].str),vn[i].name,out, types[tt/100]);
					}
				}
				/* PIE: parse one single Snobol4 command */
				else if (goPie && !com) {
					static char thisprev[COMPSTR];
					char *pb=p;
					p=curr;
					if (*p=='#') p++;
					if (strcmp(curr,thisprev)) scan=bscan=0;
					report=rightPos=TRUE;
					report=assign();
					if (report) printf("\nYes.\n");
					else printf("\nNo.\n");
					p=pb;
					strncpy_(thisprev,curr,COMPSTR);
					continue;
				}
				/* DEBUG LINE: */
				else {
					printf("Unrecognized debug command. Type help for the command list.\n");
					continue;
				}

			} // end if(isDebug)

			/* if QUIT was used, it's harmful go on... */
			if (isQuit) break;

			/* evaluate the line
			 * if it is as assignment, assign() will perform
			 * the assignment otherwise
			 * a pattern evaluation is performed */
			if (!goPie) {
				sStatms++;
				report=TRUE;
				report=assign();
			}

			/* set state and print it if required */
			if (isDebug && printState) {
				printf("%s",INVCOLOR);
				printf("-- line %d --\n",l);
				printCurState();
				printf("%s",RESETCOLOR);
			}
			if (!report) sFail++; // for Stats
			dotTOS=0;
			resTOS=0;
		} // end if(m[l] && *m[l]

		/* reset jump position in case */
		if (p && *p && strcasestr_oq(p,":")) p=strcasestr_oq(p,":");

		/* store current line number (which will became the old)*/
		sLastNo=l;

		/* if report is false and -NOFAIL was invoked */
		if (!report && !mf[l] && l>0 && !goPie) hasFailed=TRUE;
		else hasFailed=FALSE;

		/* set jumps data */
		if (p && *p==':') {
			char L[COMPSTR];
			int onFalse=0, onTrue=0, onJump=0, isCode=0, bl=l;
			onFalse=0, onTrue=0, onJump=0, isCode=0, bl=l;
			p++; // skip :
			while (isblank(*p)) p++;
			if (toupper(*p)!='F' && toupper(*p)!='S' &&\
				       *p!='(' && *p!='[')
				perror_(__LINE__,5,l);
			while (*p) {
				char *k, j;
				while (isblank(*p)) p++;
				/* regular jumps */
				if (!strncasecmp_(p,"S(",2) ||\
						!strncasecmp_(p,"F(",2) ||\
						!strncasecmp_(p,"(",1)) {
					k=p;
					j=toupper(*k);
					if (j=='S' || j=='F') p+=2;
					else p++;
					/* normal case: LABEL name */
					if (!strncasecmp_(p,"END",3) && !isnamechar(p+3)) {
						p+=3;
						strncpy_(L,"END",COMPSTR);
					}
					/* normal case: LABEL name */
					else if (isbeginnamechar(p)) {
						char *t=L;
						while (isnamechar(p))
							*t++=toupper(*p++);
						*t='\0';
					}
					/* first special case: $VAR referenced
					 * name */
					else if (*p=='$' && *(p+1)!='(') {
						char *t=L;
						int ns;
						p++;
						while (isnamechar(p))
							*t++=*p++;
						*t='\0';
						ns=findDEC(L);
						if (ns)
							strncpy_(L,vn[ns].str,COMPSTR);
						else perror_(__LINE__,11,l);
					}
					/* second special case: composed string
					 * and the $(...) case */
					else strncpy_(L,AS(),COMPSTR);
					if (j=='S') onTrue=setAddr(L);
					else if (j=='F') onFalse=setAddr(L);
					else onJump=setAddr(L);
					if (*p!=')') perror_(__LINE__,53,l);
				}
				/* CODE jumps */
				else if (!strncasecmp_(p,"S[",2) ||\
					        !strncasecmp_(p,"F[",2) ||\
						!strncasecmp_(p,"[",1)) {
					int ns;
					k=p;
					j=toupper(*k);
					if (j=='S' || j=='F') p+=2;
					else p++;
					ns=searchDEC(p,decCount);
					if (!ns || vn[ns].datatype!=CODE)
						perror_(__LINE__,6,l);
					p+=_len;
					if (j=='S') onTrue=1;
					if (j=='F') onFalse=1;
					else onJump=1;
					isCode=ns;
				}
				if (*p==')' || *p==']') p++;
			}

			/* check return from user-procedures */
			if (report) {
				if (onTrue==returnCode) {
					return;
				}
				else if (onTrue==freturnCode) {
					report=FALSE;
					return;
				}
				else if (onTrue==nreturnCode) {
					nreturnActed=TRUE;
					return;
				}
				else if (onJump==returnCode) {
					return;
				}
				else if (onJump==nreturnCode) {
					nreturnActed=TRUE;
					return;
				}
			}
			else {
				if (onFalse==returnCode) {
					report=TRUE;
					return;
				}
				else if (onFalse==freturnCode) {
					return;
				}
				else if (onFalse==nreturnCode) {
					report=TRUE;
					nreturnActed=TRUE;
					return;
				}
				else if (onJump==returnCode) {
					report=TRUE;
					return;
				}
				else if (onJump==nreturnCode) {
					report=TRUE;
					nreturnActed=TRUE;
					return;
				}
			}

			/* check errors in defining a destination */
			while (isblank(*p)) p++;
			if (onTrue>0 && onTrue==CORELIM)
				perror_(__LINE__,4,l);
			if (onFalse>0 && onFalse==CORELIM)
				perror_(__LINE__,4,l);
			if (onJump>0 && onJump==CORELIM)
				perror_(__LINE__,4,l);
			if (onJump && (onTrue || onFalse))
				perror_(__LINE__,86,l);

			/* perform jumps */
			if (onJump) {
				if (isCode) l=vn[isCode].ref-1;
				else l=getLabelAddr(onJump)-1;
			}
			else if (report && onTrue) {
				if (isCode) l=vn[isCode].ref-1;
				else l=getLabelAddr(onTrue)-1;
			}
			else if (!report && onFalse) {
				if (isCode) l=vn[isCode].ref-1;
				else l=getLabelAddr(onFalse)-1;
			}

			if (onFalse>0) noOnFalse=FALSE;
			else noOnFalse=TRUE;

			/* check for irregular line */
			if (l<0) perror_(__LINE__,4,bl);
		} // end set jumps data
		/* */
		if (hasFailed && noOnFalse) {
			perror_(__LINE__,88,l);
		}

		l++;
	} // end while(!isQuit)

	/* write history */
	if (isHistory) write_history(DEBUGHISTORY);
	p=NULL;

} // end of parse


/* code()
 * execute the CODE() procedure
 * Fixes finalCore to the position of current endCore, and extends endCore
 * to include the CODE lines */
char *code(void) {
	char temp[COMPSTR], *w, *sm;
	int lines=1, linenum=0;
	int ilevel=ILEVEL, fflag=FFLAG, spflag=SPFLAG,liflag=LIFLAG;

	/* ascertain that a final END is present, or add it */
	if (!label[endCore] || (label[endCore] && strcasecmp(label[endCore],"END"))) {
		endCore++;
		label[endCore]=malloc(4);
		if (!label[endCore]) perror_(__LINE__,73,l);
		strncpy_(label[endCore],"END",4);
		ln[endCore]=setAddr("END");
	}

	/* copy program string */
	linenum=endCore+1;
	strncpy_(temp,AS(),COMPSTR);
	w=temp;
	while((w=strcasestr_oq(w,";"))) w++,lines++;
	finalCore=endCore;
	w=temp;

	/* evaluate grouped lines */
	do {
		char L[COMPSTR], *lab;
		sm=strcasestr_oq(w,";");
		if (sm) {
			*sm='\0';
			sm++;
		}
		/* remove label and store in ln[]
		 * Note: the label must start at the first character */
		ln[linenum]=0;
		if (*w && isbeginnamechar(w)) {
			lab=L;
			while (isnamechar(w)) *lab++=*w++;
			*lab='\0';
			ln[linenum]=setAddr(L);
			lnTOS++;
			if (lnTOS>=VLIMIT) perror_(__LINE__,82,l);
			label[linenum]=malloc(strlen(L)+1);
			if (!label[linenum]) perror_(__LINE__,73,l);
			strncpy_(label[linenum],L,strlen(L)+1);
		}
		else {
			ln[linenum]=0;
			label[linenum]=malloc(2);
			if (!label[linenum]) perror_(__LINE__,73,l);
			strncpy_(label[linenum],VOIDS,2);

		}
		while (isblank(*w)) w++;
		/* check if it's a line with a label and no statements */
		if (!*w) continue;
		/* remove final blanks */
		while (isblank(*(w+strlen(w)-1))) *(w+strlen(w)-1)='\0';
		/* store pure execution line */
		strncpy_(pad,w,COMPSTR);
		m[linenum]=malloc(strlen(pad)+1);
		if (!m[linenum]) perror_(__LINE__,73,l);
		turnToUpper_oq(pad);
		strncpy_(m[linenum],pad,strlen(pad)+1);
		endCore=linenum;
		sActive++; // for Stats
		ml[linenum]=ilevel;
		mf[linenum]=fflag;
		md[linenum]=spflag;
		ms[linenum]=liflag;
		if (sm) {
			w=sm;
			linenum++;
		}
	} while (sm);
	endCore=linenum+1;
	ln[endCore]=ln[finalCore];
	label[endCore]=malloc(strlen(label[finalCore])+1);
	if (!label[endCore]) perror_(__LINE__,73,l);
	strncpy_(label[endCore],label[finalCore],strlen(label[finalCore])+1);
	/* build common attributes */
	while (isblank(*p)) p++;
	strncpy_(GALTPAD,temp,COMPSTR);
       	return GALTPAD;
} // end of code()


/* data()
 * execute the DATA() procedure */
void data(int ns, int elem) {
	char temp[COMPSTR], vname[COMPSTR], method[COMPSTR], *w=method, *q;
	int status;
	if (*p!='(') {
		perror_(__LINE__,39,l); // left for security
		return;
	}
	else p++; // skip (
	q=datafunc[elem].proto;
	/* for all methods in proto */
	while (*q) {
		int vs;
		w=method;
		/* get method name */
		while (isnamechar(q)) *w++=*q++;
		*w='\0';
		if (*q==',') q++;
		/* get value and type */
		strncpy_(temp,AS(),COMPSTR);
		if (!temp[0]) status=STRING;
		else {
			char *t=temp;
			strtod(t,&t);
			if (!*t) {
				if (parseInt(temp)) status=INTEGER;
				else status=REAL;
			}
			else status=STRING;
		}
		if (*p==',') p++;
		/* compose and declare DATA variable */
		strncpy_(vname,method,COMPSTR);
		strncat_(vname,"(",COMPSTR);
		snprintf(method,COMPSTR,"%d",vn[ns].ref);
		strncat_(vname,method,COMPSTR);
		strncat_(vname,")",COMPSTR);
		vs=decCount;
		/* search for duplicated names */
		while (vs>0) {
			if (!strcasecmp(vname,vn[vs].name))
				break;
			vs--;
		}
		if (vs>0) perror_(__LINE__,49,l);
		/* declare the variable and populate it */
		declare(vname,status,0,0,0); // increments decCount
		vn[decCount].dim=0;
		vn[decCount].isData=ns;
		strncpy_(vn[decCount].str,temp,COMPSTR);
		if (status<=REAL) vn[decCount].num=strtod(temp,NULL);
	}
	while (isblank(*p)) p++;
	if (*p==')') p++;
} // end of data()


/* retdata()
 * copy a DATA() procedure */
void retdata(int ns, int oldns, int elem) {
	char temp[COMPSTR], vname[COMPSTR], method[COMPSTR], *w=method, *q;
	int status, i=0;
	double val;

	q=datafunc[elem].proto;
	/* for all methods in proto */
	while (*q) {
		int vs;
		i++;
		w=method;
		/* get method name */
		while (isnamechar(q)) *w++=*q++;
		*w='\0';
		if (*q==',') q++;
		/* copy values from old related instance */
		strncpy_(temp, vn[oldns+i].str, COMPSTR);
		status=vn[oldns+i].datatype;
		val=vn[oldns+i].num;
		/* compose and declare copied DATA variable */
		strncpy_(vname,method,COMPSTR);
		strncat_(vname,"(",COMPSTR);
		snprintf(method,COMPSTR,"%d",ns);
		strncat_(vname,method,COMPSTR);
		strncat_(vname,")",COMPSTR);
		vs=decCount;
		/* search for duplicated names */
		while (vs>0) {
			if (!strcasecmp(vname,vn[vs].name))
				break;
			vs--;
		}
		if (vs>0) perror_(__LINE__,49,l);
		/* declare the variable and populate it */
		declare(vname,status,0,0,0); // increments decCount
		vn[decCount].dim=0;
		vn[decCount].isData=ns;
		strncpy_(vn[decCount].str,temp,COMPSTR);
		vn[decCount].num=val;
	}
} // end of retdata()


/* copyItem()
 * copy item in oldns to ns
 * if errflag is TRUE, ARRAY and DATA cause failure */
void copyItem(int ns, int oldns) {
	int i;
	int size=vn[oldns].size;
	int usize=size/COMPSTR;
	int isize=usize*sizeof(int);

	if (vn[oldns].datatype==ARRAY) {
		copyArray(ns,oldns);
		if (dimS[ns].elem) free(dimS[ns].elem);
		if (dim[ns].elem) free(dim[ns].elem);
		dimS[ns].elem=malloc((size_t)size);
		dim[ns].elem=calloc(sizeof(int),isize);
		for (i=0;i<usize;i++) {
			strncpy_(dimS[ns].elem+i*COMPSTR,dimS[oldns].elem+i*COMPSTR,COMPSTR);
			*(dim[ns].elem+i)=*(dim[oldns].elem+i);
		}
		snprintf(vn[ns].str,COMPSTR,"%d",ns);
		_datatype=vn[oldns].datatype;
	}
	else if (vn[oldns].datatype==DATA) {
		retdata(ns,oldns,vn[oldns].dim);
		strncpy_(vn[ns].proto,vn[oldns].proto,COMPSTR);
		strncpy_(vn[ns].str,vn[oldns].str,COMPSTR);
		vn[ns].datatype=vn[oldns].datatype;
		vn[ns].dim=vn[oldns].dim;
	}
	else if (vn[oldns].datatype==CODE) {
		strncpy_(vn[ns].proto,vn[oldns].proto,COMPSTR);
		vn[ns].ref=ns;
		snprintf(vn[ns].str,COMPSTR,"%d",ns);
		vn[ns].dim=vn[oldns].dim;
		vn[ns].datatype=vn[oldns].datatype;
	}
	else {
		copyArray(ns,oldns);
		strncpy_(vn[ns].str,vn[oldns].str,COMPSTR);
		vn[ns].datatype=vn[oldns].datatype;
	}
} // end of copyItem()


/* findPROC()
 * search if there is a user procedure with the name pointed
 * by pl given as argument*/
int findPROC(char *pl) {
	char name[COMPSTR], *t=name;
	int i=defineTOS;
	/* copy name until ( */
	while (isnamechar(pl)) *t++=*pl++;
	*t='\0';
	if (*pl!='(') return FALSE;
	/* check among definefunc[].name */
	while (i>0) {
		if (!strcasecmp(name,definefunc[i].name)) {
			return i;
		}
		i--;
	}
	return FALSE;
}


/* define()
 * execute the user-defined function identified by np
 * return in strres the string value and in type the data type
 * return the updated position of the program counter */
char *define(int np, char *strres, int* type) {
	char *q, name[COMPSTR], *w=name;
	char arg[COMPSTR], *pb;
	int argCount, isThisFtrace=FALSE;
	int lback=l, dback=decCount, arrref=0;
	/* increment function level */
	p+=strlen(definefunc[np].name)+1;
	funcTOS++;
	if (funcTOS>=PSTACK) {
		perror_(__LINE__,85,l);
	}
	currentDECstartBack=currentDECstart;
	currentDECstart=decCount;
	/* declare return variable with name = proc name */
	decCount++;
	if (decCount>=VLIMIT) {
		perror_(__LINE__,74,l);
	}
	argCount=decCount;
	strncpy_(vn[decCount].name,definefunc[np].name,COMPSTR);
	strncpy_(vn[decCount].str,VOIDS,COMPSTR);
	vn[decCount].datatype=STRING;
	vn[decCount].num=0;
	vn[decCount].ref=decCount;
	/* instantiate all argument variables */
	q=definefunc[np].argproto;
	while (*q) {
		int state;
		while (isblank(*q)) q++;
		if (*q==',') {
			q++;
			while (isblank(*q)) q++;
		}
		/* name: get variable name */
		w=name;
		while (isnamechar(q)) *w++=*q++;
		*w='\0';
		/* value: case of a Name entity */
		if (*p=='.') {
			char temp[COMPSTR], *v=temp;
			int st=0;
			p++;
			while (*p) {
				if (*p=='(') st++;
				else if (*p=='[') st++;
				else if (*p==')' && st) st--;
				else if (*p==']' && st) st--;
				else if (*p==',' && !st) break;
				else if (*p==')' && !st) break;
				else if (*p==']' && !st) break;
				*v++=*p++;
			}
			*v='\0';
			strncpy_(arg,temp,COMPSTR);
			state=NAME;
		}
		/* value: case of variables or values */
		else {
			double num;
			int dec=decCount;
			int ns=searchDEC(p,currentDECstart);
			if (ns && !vn[ns].str[0]) {
				p+=_len;
				strncpy_(arg,VOIDS,COMPSTR);
				state=STRING;
			}
			else if (vn[ns].datatype==ARRAY) {
				p+=_len;
				strncpy_(arg,VOIDS,COMPSTR);
				state=ARRAY;
				arrref=ns;
			}
			else {
				num=S();
				if (!notAMathExpression) {
					snprintf(arg,COMPSTR,"%.15G",num);
					if (parseInt(arg)) state=INTEGER;
					else state=REAL;
				}
				else {
					decCount=currentDECstart;
					strncpy_(arg,AS(),COMPSTR);
					state=_datatype;
				}
				if (!arg[0]) state=STRING;
				decCount=dec;
			}
		}
		/* assign variable */
		declare(name,state,FALSE,0,0);
		strncpy_(vn[decCount].str,arg,COMPSTR);
		if (state==INTEGER) vn[decCount].num=(int)strtod(arg,NULL);
		else if (state==REAL) vn[decCount].num=strtod(arg,NULL);
		else if (state==ARRAY) {
			vn[decCount].ref=arrref;
		}
		else vn[decCount].num=0;
		checkTrace(decCount);
		while (isblank(*p)) p++;
		if (*p==',') p++;
		while (isblank(*p)) p++;
	}
	/* instantiate all other variables */
	q=definefunc[np].otherproto;
	while (*q) {
		while (isblank(*q)) q++;
		if (*q==',') {
			q++;
			while (isblank(*q)) q++;
		}
		/* name: get var name */
		w=name;
		while (isnamechar(q)) *w++=*q++;
		*w='\0';
		/* assign the empty string value */
		declare(name,STRING,FALSE,0,0);
		strncpy_(vn[decCount].str,VOIDS,COMPSTR);
	}

	if (*p==')') p++;
	pb=p;

	/* perform tracing */
	if (isFtrace>0) {
		int i=0;
		char proto[COMPSTR];
		double endS;
		isThisFtrace=TRUE;
		gettimeofday(&tv, NULL);
		endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS-=beginS;
		strncpy_(proto,definefunc[np].name,COMPSTR);
		strncat_(proto,"(",COMPSTR);
		for (i=argCount+1;i<argCount+definefunc[np].anum;i++) {
			if (vn[i].str[0]) strncat_(proto,vn[i].str,COMPSTR);
			else strncat_(proto,"''",COMPSTR);
			strncat_(proto,",",COMPSTR);
		}
		strncat_(proto,vn[argCount+definefunc[np].anum].str,COMPSTR);
		strncat_(proto,")",COMPSTR);
		fprintf(stdout,"STATEMENT %d: LEVEL %d CALL OF %s, TIME = %d\n",l,funcTOS-1,proto,(int)(endS*1000));
		if (isFtrace>0) isFtrace--;
	}

	/* execute */
	parse(definefunc[np].label);
	p=pb;

	/* convert the math expression in case */
	if (vn[argCount].datatype==PATTERN) {
		double num;
		char *pb=p;
		p=vn[argCount].str;
		num=S();
		if (!*p) {
			snprintf(vn[argCount].str,COMPSTR,"%.15G",num);
			if (parseInt(vn[argCount].str)) vn[argCount].datatype=INTEGER;
			else vn[argCount].datatype=REAL;
		}
		p=pb;
	}

	/* END is met before a RETURN... */
	if (isQuit) {
		END(procCode);
	}

	/* set return value */
	if (!nreturnActed) {
		strncpy_(strres,vn[argCount].str,COMPSTR);
		*type=vn[argCount].datatype;
		if (*type==PATTERN) isAPattern=TRUE;
		else if (*type==CODE) {
			perror_(__LINE__,111,l);
		}
		else if (*type==ARRAY) {
			int i;
			int size=vn[argCount].size;
			int usize=size/COMPSTR;
			int isize=usize*sizeof(int);
			copyArray(BACKARR,argCount);	
			if (dimS[BACKARR].elem) free(dimS[BACKARR].elem);
			if (dim[BACKARR].elem) free(dim[BACKARR].elem);
			dimS[BACKARR].elem=malloc((size_t)size);
			dim[BACKARR].elem=calloc(sizeof(int),isize);
			for (i=0;i<usize;i++) {
				strncpy_(dimS[BACKARR].elem+i*COMPSTR,dimS[argCount].elem+i*COMPSTR,COMPSTR);
				*(dim[BACKARR].elem+i)=*(dim[argCount].elem+i);
			}
			isAnArray=TRUE;
		}
	}
	/* a void name cannot exist */
	else if (!vn[argCount].str[0]) {
		perror_(__LINE__,28,l);
	}
	else {
		/* set NAME return values */
		strncpy_(strres,vn[argCount].str,COMPSTR);
		*type=NAME;
	}

	if (isThisFtrace) {
		double endS;
		gettimeofday(&tv, NULL);
		endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS-=beginS;
		fprintf(stdout,"STATEMENT %d: LEVEL %d RETURN OF %s = %s, TIME = %d\n",l,funcTOS-1,definefunc[np].name,strres,(int)(endS*1000));
	}

	/* restore state */
	funcTOS--;
	l=lback;
	decCount=dback;
	p=pb;
	currentDECstart=currentDECstartBack;
	while (isblank(*p)) p++;
	return p;
}


/* proceed()
 * the procedures execution subroutine (the core of the engine, which calls
 * all the statements references in order to execute the commands)
 * lpc is the address of the execution line (the first character after the
 * line number)
 * return TRUE if execution goes well, FALSE otherwise
 * System basic function */
int proceed(void) {
	if (*p=='\0'); // nop for void lines
	/* DATA() function
	 * set new data item */
	else if (!strncasecmp_(p,"DATA(",5)) {
		char temp[COMPSTR],*v=temp, *t;
		int i;
		p+=5;
		dataTOS++;
		if (dataTOS>=PSTACK) perror_(__LINE__,84,l);
		strncpy_(temp,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (*p==')') p++;
		if (!strchr(temp,'(')) perror_(__LINE__,39,l);
		t=datafunc[dataTOS].name;
		v=temp;
		while (isblank(*v)) v++;
		while (*v && *v!='(') *t++=*v++;
		*t='\0';
		if (*v=='(') v++;
		while (isblank(*v)) v++;
		t=datafunc[dataTOS].proto;
		while (*v && *v!=')') *t++=*v++;
		*t='\0';
		/* count methods */
		i=0;
		t=datafunc[dataTOS].proto;
		while ((t=strchr(t,','))) i++,t++;
		datafunc[dataTOS].num=i+1;
	}
	/* DEFINE() function
	 * define a user procedure*/
	else if (!strncasecmp_(p,"DEFINE(",7)) {
		char temp[COMPSTR],*v=temp, *t;
		p+=7;
		defineTOS++;
		definefunc[defineTOS].anum=definefunc[defineTOS].lnum=0;
		if (defineTOS>=PSTACK) perror_(__LINE__,85,l);
		strncpy_(temp,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (*p==')') p++;
		else definefunc[defineTOS].anum++;
		if (!strchr(temp,'(')) perror_(__LINE__,25,l);
		/* store name */
		t=definefunc[defineTOS].name;
		v=temp;
		while (isblank(*v)) v++;
		while (*v && *v!='(') *t++=*v++;
		*t='\0';
		turnToUpper_oq(definefunc[defineTOS].name);
		if (*v=='(') v++;
		/* store argument proto */
		while (isblank(*v)) v++;
		t=definefunc[defineTOS].argproto;
		while (*v && *v!=')') *t++=*v++;
		*t='\0';
		if (*v==')') v++;
		/* count arguments */
		t=definefunc[defineTOS].argproto;
		while ((t=strchr(t,',')))
			definefunc[defineTOS].anum++,t++;
		if (strlen(definefunc[defineTOS].argproto))
			definefunc[defineTOS].anum++;
		/* store proto of other variables */
		while (isblank(*v)) v++;
		if (isbeginnamechar(v))  {
			t=definefunc[defineTOS].otherproto;
			while (*v) *t++=*v++;
			*t='\0';
			/* count arguments */
			t=definefunc[defineTOS].otherproto;
			while ((t=strchr(t,',')))
				definefunc[defineTOS].lnum++,t++;
			if (strlen(definefunc[defineTOS].otherproto))
				definefunc[defineTOS].lnum++;
		}
		/* store label, if any */
		if (*p==',') {
			p++;
			strncpy_(definefunc[defineTOS].startlabel,AS(),COMPSTR);
		}
		/* use the same name as label */
		else {
			strncpy_(definefunc[defineTOS].startlabel,definefunc[defineTOS].name,COMPSTR);
		}
		if (*p==')') p++;
		while (isblank(*v)) v++;
		definefunc[defineTOS].nreturn=FALSE;
		/* calculate starting label */
		if (definefunc[defineTOS].startlabel[0]) {
			definefunc[defineTOS].label=getLabelAddr(setAddr(definefunc[defineTOS].startlabel));
		}
		/* error in case of not found label */
		if (!definefunc[defineTOS].label) perror_(__LINE__,58,l);
	}
	/* CODE() function
	 * only if used without assignment
	 * in this case CODE() only adds the new source lines
	 * that are accessible only through labels */
	else if (!strncasecmp_(p,"CODE(",5)) {
		p+=5;
		code();
		if (*p==')') p++;
	}
	/* DETACH() function
	 * break correspondence between a variable and the channel */
	else if (!strncasecmp_(p,"DETACH(",7)) {
		char varname[COMPSTR];
		int ns=decCount, state;
		p+=7;
		/* read var name */
		strncpy_(varname,GP(&state),COMPSTR);
		while (isblank(*p)) p++;
		if (state!=NAME && state!=STRING) perror_(__LINE__,64,l);
		if (!varname[0]) perror_(__LINE__,64,l);
		/* search */
		while (ns>0) {
			if (!strcasecmp(vn[ns].name,varname))
				break;
			ns--;
		}
		if (ns>0) {
			vn[ns].iotype=0;
			vn[ns].datachan=0;
		}
		/* TODO make error */
		//else error
	}
	/* REMARK() function
	 * send to the job log the string argument */
	else if (!strncasecmp_(p,"REMARK(",7)) {
		char str[COMPSTR];
		char ttime[COMPSTR];
		char tdate[COMPSTR];
		p+=7;
		strncpy_(str,AS(),COMPSTR);
		/* set time */
		snprintf(ttime,COMPSTR,"%02d:%02d:%02d",getHour(),getMin(),getSec());
		snprintf(tdate,COMPSTR,"%02d %s %02d",getDay(),getMonthString(),getYear()-2000);
		/* print to job log */
		if (isDefJobLog) {
			FILE *fd;
			fd=fopen(joblog,"a"); // confirmed "a"
			if (!fd) return report=FALSE;
			fprintf(fd,"[%s - %s - %s] %s\n",username,tdate,ttime,str);
			fclose(fd);
		}
		else {
			fprintf(channel[outF].stream,"[%s - %s - %s] %s\n",username,tdate,ttime,str);
		}
		if (*p==')') p++;
	}
	/* CLEAR() function
	 * set all natural variables to null
	 * Note: in case of functions acting, the erasure 
	 * refers to the function domain only */
	else if (!strncasecmp_(p,"CLEAR(",6)) {
		char temp[COMPSTR];
		int i;
		p+=6;
		if (*p!=')') {
			while (isblank(*p)) p++;
			strncpy_(temp,AS(),COMPSTR);
			while (isblank(*p)) p++;
		}
		i=decCount;
		while (i>currentDECstart) {
			int type=vn[i].datatype;
			if (type>PREDEF) type-=PREDEF;
			if (type<ARRAY && !vn[i].isData && !vn[i].iotype) {
				strncpy_(vn[i].str,VOIDS,COMPSTR);
				vn[i].num=0;
				vn[i].ref=i;
				vn[i].datatype=STRING;
			}
			i--;
		}
		if (*p==')') p++;
	}
	/* ENDFILE() function
	 * close the argument file */
	else if (!strncasecmp_(p,"ENDFILE(",8)) {
		char fname[COMPSTR];
		int ch=2;
		FILE *fd;
		p+=8;
		strncpy_(fname,AS(),COMPSTR);
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				fd=channel[ch].stream;
				/* don't operate on standard I/O */
				if (fd==stdin || fd==stdout || fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				else {
					int i;
					fclose(channel[ch].stream);
					/* detach the connected variables */
					for (i=0;i<=decCount;i++) {
						if (vn[i].datachan==ch) {
							vn[i].datachan=0;
							vn[i].iotype=0;
						}
					}
					/* delete the channel data */
					channel[ch].stream=NULL;
					strncpy_(channel[ch].ioname,VOIDS,COMPSTR);
					channel[ch].wayout=0;
					channel[ch].datalen=0;
					strncpy_(channel[ch].attach,VOIDS,COMPSTR);
					channel[ch].isKYB=FALSE;
					channel[ch].isCanon=TRUE;
					channel[ch].isPrinter=FALSE;
					channel[ch].isLastWrite=FALSE;

					strncpy_(openFiles[ch],VOIDS,COMPSTR);
					openStreams[ch]=NULL;
				}
				break;
			}
			ch++;
		}
		if (ch>fileTOS) {
			report=FALSE;
			sErr=44;
			lErr=l;
			return TRUE;
		}
		if (*p==')') p++;
	}
	/* ENDGROUP() function
	 * write a mark on the output argument file */
	else if (!strncasecmp_(p,"ENDGROUP(",9)) {
		char fname[COMPSTR];
		FILE *fd;
		int level=0, ch=2;
		p+=9;
		strncpy_(fname,AS(),COMPSTR);
		if (*p==',') {
			p++; // skip comma
			level=(int)S();
		}
		if (level<0) level=0;
		if (level>15) level=15;
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				fd=channel[ch].stream;
				if (fd==stdin || fd==stdout ||fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				else {
					fprintf(fd,"%s%02d\n",FREEZECODE,level);
				}
				break;
			}
			ch++;
		}
		if (ch>fileTOS)  perror_(__LINE__,44,l);
		if (*p==')') p++;
	}
	/* RENAME() function
	 * rename or delete the argument file */
	else if (!strncasecmp_(p,"RENAME(",7)) {
		char oldname[COMPSTR], newname[COMPSTR];
		int ret=0, ch=2;
		p+=7;
		strncpy_(oldname,AS(),COMPSTR);
		if (*p==',') {
			p++; // skip comma
			strncpy_(newname,AS(),COMPSTR);
		}
		else newname[0]='\0';
		/* check that the file is not previously opened */
		while (ch<=fileTOS) {
			if (!strcmp(oldname,channel[ch].ioname)) {
				sErr=102;
				lErr=l;
				report=FALSE;
				return TRUE;
			}
			ch++;
		}
		if (newname[0]) ret=rename(oldname,newname);
		else ret=remove(oldname); // TODO error?
		if (ret<0) report=FALSE;
		if (*p==')') p++;
	}
	/* REWIND() function
	 * set argument file position to start */
	else if (!strncasecmp_(p,"REWIND(",7)) {
		char fname[COMPSTR];
		int ch=2, ret=0;
		FILE *fd;
		p+=7;
		strncpy_(fname,AS(),COMPSTR);
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				fd=channel[ch].stream;
				if (fd==stdin || fd==stdout || fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				/* print end-of-group of level 0 if last
				 * operation was a write */
				else if (channel[ch].isLastWrite) {
					fprintf(channel[ch].stream,"%s00\n",FREEZECODE);
				}
				ret=fseek(channel[ch].stream,0,SEEK_SET);
				break;
			}
			ch++;
		}
		if (ch>fileTOS)  perror_(__LINE__,44,l);
		if (*p==')') p++;
		if (ret<0) report=FALSE;
	}
	/* FORWARD() function
	 * set argument file position to end */
	else if (!strncasecmp_(p,"FORWARD(",8)) {
		char fname[COMPSTR];
		int ch=2, ret=0;
		FILE *fd;
		p+=8;
		strncpy_(fname,AS(),COMPSTR);
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				int c, pos;
				fd=channel[ch].stream;
				if (fd==stdin || fd==stdout || fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				/* set seek to end */
				ret=fseek(fd,0,SEEK_END);
				fflush(fd);
				/* backspace */
				pos=ftell(fd);
				ret=fseek(fd,--pos,SEEK_SET);
				if ((c=fgetc(fd)!='\n')) ungetc(c,fd);
				while (pos>0) {
					ret=fseek(fd,--pos,SEEK_SET);
					c=fgetc(fd);
					if (c=='\n') break;
				}
				/* reposition */
				fgets_(fname,COMPSTR,fd);
				if (!strcmp(fname,"#@||@#00")) {
					ret=fseek(fd,++pos,SEEK_SET);
				}
				else {
					ret=fseek(fd,0,SEEK_END);
				}
				break;
			}
			ch++;
		}
		if (ch>fileTOS)  perror_(__LINE__,44,l);
		if (*p==')') p++;
		if (ret<0) report=FALSE;
	}
	/* BACKSPACE() function
	 * set argument file position one line backwards */
	else if (!strncasecmp_(p,"BACKSPACE(",10)) {
		char fname[COMPSTR];
		int ch=2, ret=0;
		FILE *fd;
		p+=10;
		strncpy_(fname,AS(),COMPSTR);
		while (ch<=fileTOS) {
			if (!strcmp(fname,channel[ch].ioname)) {
				fd=channel[ch].stream;
				if (fd==stdin || fd==stdout || fd==stderr) {
					sErr=99;
					lErr=l;
					report=FALSE;
					return TRUE;
				}
				else {
					int c, pos, oldpos;
					fflush(fd);
					oldpos=ftell(fd);
					fclose(fd);
					// confirmed "r+"
					fd=fopen(channel[ch].ioname,"r+");
					/* TODO check fd==NULL */
					fseek(fd,oldpos,SEEK_SET);
					pos=oldpos;
					ret=fseek(fd,--pos,SEEK_SET);
					if ((c=fgetc(fd)!='\n')) ungetc(c,fd);
					while (pos>0) {
						ret=fseek(fd,--pos,SEEK_SET);
						c=fgetc(fd);
						if (c=='\n') break;
					}
					if (channel[ch].wayout==VWRITE) {
						fclose(fd);
						// confirmed r+
						fd=fopen(channel[ch].ioname,"r+");
						/* TODO check fd==NULL */
						ret=fseek(fd,pos,SEEK_SET);
						fprintf(channel[ch].stream,"%s","\n");
					}
				}
				break;
			}
			ch++;
		}
		if (ch>fileTOS)  perror_(__LINE__,44,l);
		if (*p==')') p++;
		if (ret<0) report=FALSE;
	}
	/* INPUT() function
	 * set current input source */
	else if (!strncasecmp_(p,"INPUT(",6)) {
		char varname[COMPSTR];
		char filname[COMPSTR], *fn=filname;
		int len=COMPSTR, echo=TRUE;
		p+=6;
		/* case of a Name entity */
		if (*p=='.') {
			char *v=varname;
			p++;
			while (*p && *p!=',') *v++=*p++;
			*v='\0';
		}
		/* case of variables or strings */
		else {
			int ns=findDEC(p);
			/* case of literal string */
			if (!ns) {
				strncpy_(varname,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME) perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(varname,vn[ns].str,COMPSTR);
			}
		}
		if (!varname[0]) perror_(__LINE__,64,l);
		while (isblank(*p)) p++;
		if (*p==',') p++; // skip comma
		else perror_(__LINE__,19,l);
		/* read scope name */
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"KYB",3)) {
			strncpy_(filname,"KYB",COMPSTR);
			p+=3;
		}
		else if (isbeginnamechar(p)) {
			int ns=0;
			while (isnamechar(p)) *fn++=*p++;
			*fn='\0';
			ns=searchDEC(filname,decCount);
			if (ns) {
				if (vn[ns].datatype<=STRING) {
					strncpy_(filname,vn[ns].str,COMPSTR);
				}
				else perror_(__LINE__,45,l);
			}
			else perror_(__LINE__,45,l);
		}
		else strncpy_(filname,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (!filname[0]) perror_(__LINE__,45,l);
		/* optional Length */
		if (*p==',') {
			p++; // skip comma;
			len=(int)S();
			while (isblank(*p)) p++;
			if (len<1) len=COMPSTR;
			if (len>COMPSTR-1) len=COMPSTR-1;
			/* optional echo */
			if (*p==',') {
				p++; // skip comma
				echo=(int)S();
				while (isblank(*p)) p++;
			}
		}
		/* setup for INPUT */
		fileTOS++;
		if (fileTOS>STREAMS) perror_(__LINE__,81,l);
		if (setInputFile(filname,varname,len,echo));
		else perror_(__LINE__,8,l);
		if (*p==')') p++;
	}
	/* OUTPUT() function
	 * set current output source */
	else if (!strncasecmp_(p,"OUTPUT(",7)) {
		char varname[COMPSTR], filname[COMPSTR], *fn=filname;
		char attach[COMPSTR];
		int app=0;
		p+=7;
		/* case of a Name entity */
		if (*p=='.') {
			char *v=varname;
			p++;
			while (*p && *p!=',') *v++=*p++;
			*v='\0';
		}
		/* case of variables or strings */
		else {
			int ns=findDEC(p);
			/* case of literal string */
			if (!ns) {
				strncpy_(varname,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME) perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(varname,vn[ns].str,COMPSTR);
			}
		}
		if (!varname[0]) perror_(__LINE__,64,l);
		while (isblank(*p)) p++;
		if (*p==',') p++;
		else perror_(__LINE__,19,l);
		/* read scope name */
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"TTY",3)) {
			strncpy_(filname,"TTY",COMPSTR);
			p+=3;
		}
		else if (!strncasecmp_(p,"ERR",3)) {
			strncpy_(filname,"ERR",COMPSTR);
			p+=3;
		}
		else if (isbeginnamechar(p)) {
			int ns=0;
			while (isnamechar(p)) *fn++=*p++;
			*fn='\0';
			ns=searchDEC(filname,decCount);
			if (ns) {
				if (vn[ns].datatype<=STRING) {
					strncpy_(filname,vn[ns].str,COMPSTR);
				}
				else perror_(__LINE__,45,l);
			}
			else perror_(__LINE__,45,l);
		}
		else strncpy_(filname,AS(),COMPSTR);
		while (isblank(*p)) p++;
		if (!filname[0]) perror_(__LINE__,45,l);
		/* optional attachment */
		if (*p==',') {
			p++; // skip comma;
			strncpy_(attach,AS(),COMPSTR);
			/* optional append mode */
			if (*p==',') {
				p++;
				app=(int)S();
			}
		}
		/* the default attach is the new line character to
		 * separate the output lines, append mode is 0 */
		else {
			attach[0]='\n';
			attach[1]='\0';
		}
		/* setup for OUTPUT */
		fileTOS++;
		if (fileTOS>STREAMS) perror_(__LINE__,81,l);
		if (setOutputFile(filname,varname,attach,app));
		else perror_(__LINE__,8,l);
		if (*p==')') p++;
	}
	/* RANDOMIZE()
	 * change random seed() - delegate randomize() */
	else if (!strncasecmp_(p,"RANDOMIZE(",10)) {
		char val[COMPSTR];
		p+=10;
		/* dummy value */
		strncpy_(val,AS(),COMPSTR);
		randomize();
		if (*p==')') p++;
	}
	/* FREEZE()
	 * save data to disk and stop */
	else if (!strncasecmp_(p,"FREEZE(",7)) {
		char usercode[COMPSTR];
		p+=7;
		strncpy_(usercode,AS(),COMPSTR);
		if (!goPie && !isDebug) {
			saveFreeze(usercode);
			isQuit=TRUE;
		}
		else fprintf(stderr,"%s\n",error[97]);
		if (*p==')') p++;
	}
	/* ECHO() function
	 * set echo/no echo on channel identified by var */
	else if (!strncasecmp_(p,"ECHO(",5)) {
		char varname[COMPSTR];
		int echo=FALSE, ns=0;
		p+=5;
		/* case of a Name entity */
		if (*p=='.') {
			char *v=varname;
			p++;
			while (*p && *p!=',') *v++=*p++;
			*v='\0';
		}
		/* case of variables or strings */
		else {
			int ns=findDEC(p);
			/* case of literal string */
			if (!ns) {
				strncpy_(varname,AS(),COMPSTR);
			}
			/* case of a variable */
			else {
				if (vn[ns].datatype!=NAME) perror_(__LINE__,64,l);
				p+=_len;
				strncpy_(varname,vn[ns].str,COMPSTR);
			}
		}
		if (!varname[0]) perror_(__LINE__,64,l);
		while (isblank(*p)) p++;
		if (*p==',') p++; // skip comma
		else perror_(__LINE__,65,l);
		/* read echo state */
		echo=S();
		ns=searchDEC(varname,decCount);
		if (!ns) perror_(__LINE__,64,l);
		if (!vn[ns].iotype) perror_(__LINE__,45,l);
		channel[vn[ns].datachan].isCanon=echo;
		if (*p==')') p++;
	}
	/* ANCHOR() function
	 * set the anchoring mode
	 * The form ANCHOR() is accepted */
	else if (!strncasecmp_(p,"ANCHOR(",7)) {
		char temp[COMPSTR];
		p+=7;
		if (*p==')') isAnchored=FALSE;
		else {
			while (isblank(*p)) p++;
			strncpy_(temp,AS(),COMPSTR);
			while (isblank(*p)) p++;
			/* select option on not null value */
			if (temp[0]) isAnchored=TRUE;
			else isAnchored=FALSE;
		}
		if (*p==')') p++;
	}
	/* &CODE */
	else if (!strncasecmp_(p,"&CODE",5)) {
		p+=5;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		procCode=S();
	}
	/* &ABEND */
	else if (!strncasecmp_(p,"&ABEND",6)) {
		int val;
		p+=6;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isAbend=TRUE;
		else isAbend=FALSE;
	}
	/* &REAL */
	else if (!strncasecmp_(p,"&REAL",5)) {
		int val;
		p+=5;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isNotExponential=TRUE;
		else isNotExponential=FALSE;
	}
	/* &ANCHOR */
	else if (!strncasecmp_(p,"&ANCHOR",7)) {
		int val;
		p+=7;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isAnchored=TRUE;
		else isAnchored=FALSE;
	}
	/* &TRACE */
	else if (!strncasecmp_(p,"&TRACE",6)) {
		int val;
		p+=6;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isTrace=val;
		else isTrace=0;
	}
	/* &FTRACE */
	else if (!strncasecmp_(p,"&FTRACE",7)) {
		int val;
		p+=7;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isFtrace=val;
		else isFtrace=0;
	}
	/* &TRIM */
	else if (!strncasecmp_(p,"&TRIM",5)) {
		int val;
		p+=5;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isGTrim=TRUE;
		else isGTrim=FALSE;
	}
	/* &FULLSCAN */
	else if (!strncasecmp_(p,"&FULLSCAN",9)) {
		int val;
		p+=9;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isFullscan=TRUE;
		else isFullscan=FALSE;
	}
	/* &INPUT */
	else if (!strncasecmp_(p,"&INPUT",6)) {
		int val;
		p+=6;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isInput=TRUE;
		else isInput=FALSE;
	}
	/* &OUTPUT */
	else if (!strncasecmp_(p,"&OUTPUT",7)) {
		int val;
		p+=7;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=S();
		if (val) isOutput=TRUE;
		else isOutput=FALSE;
	}
	/* DUMP() function
	 * set the dump mode
	 * The form DUMP() is accepted */
	else if (!strncasecmp_(p,"DUMP(",5)) {
		char temp[COMPSTR];
		int val=0;
		p+=5;
		if (*p==')') isDumping=FALSE;
		else {
			while (isblank(*p)) p++;
			strncpy_(temp,AS(),COMPSTR);
			while (isblank(*p)) p++;
			/* select option on not null value */
			if (temp[0]) {
				val=strtol(temp,NULL,10);
				if (val>=1 && val<=4) isDumping=val;
				else if (!val) isDumping=FALSE;
				else isDumping=TRUE;
			}
			else isDumping=FALSE;
		}
		if (*p==')') p++;
	}
	/* &DUMP */
	else if (!strncasecmp_(p,"&DUMP",5)) {
		int val;
		p+=5;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=(int)S();
		if (val) {
			if (val>=1 && val<=4) isDumping=val;
			else isDumping=TRUE;
		}
		else isDumping=FALSE;
	}
	/* &MAXLNGTH */
	else if (!strncasecmp_(p,"&MAXLNGTH",9)) {
		int val;
		p+=9;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		val=(int)S();
		if (val) isMaxlngth=TRUE;
		else isMaxlngth=FALSE;
	}
	/* &STLIMIT */
	else if (!strncasecmp_(p,"&STLIMIT",8)) {
		p+=8;
		while (isblank(*p)) p++;
		if (*p=='=') p++;
		else return FALSE;
		while (isblank(*p)) p++;
		isStLimit=(int)S();
	}
	else return FALSE;
	return TRUE; // must conserve the state
} // end of proceed()


/*****************************************
 *      SIGNALS & ERROR TREATMENT	*
 *****************************************/

/* perror_()
 * print a string message based upon the following information data:
 * - errNum is the error code number defined in errors.h and must always be
 *   given as first argument
 * - ll is the line number in which the error is occurred; if null, the
 *   line reference is not printed (general errors); this must always be given
 *   as the second argument
 * - all the other parameters should be the ones needed in the error strings,
 *   to fill the data in the % specifiers, according to their type.
 * In case of PIE, an error does not block the session;
 * If an error-catching technique is in use, set codes and exit.
 * The file name is added only in a CHAINed process, and only from the second
 * file on; the first file run has no file name reference*/
int perror_(int line,int errNum, int ll, ...) {
	va_list ap;
	int d=0, off=0;
	char *t=p;

	/* store errNum for isIF*/
	sErr=errNum;
	lErr=ll;

	/* IF() makes error being ignored */
	if (isIF || isRunAnyway) {
		report=FALSE;
		isIF=FALSE;
		return TRUE;
	}

	/* print error message */
	fprintf(stderr,"\n");
	va_start(ap, ll);
	/* real error: print regular error message with arguments */
	if (ll>0 && errNum>0) {
		fprintf(stderr,"ON PROGRAM %s:\n",filename);
		fprintf(stderr,"? ERROR %d IN STATEMENT %d AT LEVEL %d:\n%s",errNum,ll,funcTOS,error[errNum]);
		if (isPrintSourceCode) fprintf(stderr," #%d#",line);
		fprintf(stderr,"%s","\n");
		if (BASETOT) fprintf(stderr,"\n%s\n",BASETOT);
		if (t) while (*t++) d++;
		else d=0;
		if (BASETOT) off=strlen(BASETOT)-d;
		else off=0;
		while (off-->0) fputc(' ',stderr);
		fputc('^',stderr);
		fputc('\n',stderr);
	}
	/* print only message for system errors */
	else if (errNum>0) {
		fprintf(stderr,"? %s",error[errNum]);
		if (isPrintSourceCode) fprintf(stderr," #%d#",line);
		fprintf(stderr,"\n\n");
	}

	/* disable statistics */
	isStats=FALSE;

	/* stop execution */
	isError=TRUE;
	if (!isPie) END(EXIT_FAILURE);
	return TRUE;
}


/***************************************
 *      DOCUMENTATION AND LICENSE      *
 ***************************************/

/* printHelp()
 * help message */
void printHelp(int doIt) {
	printExistence(doIt,TRUE);
	fprintf(stdout,"Usage: soft [options] [filename]\n\n");
	fprintf(stdout,"Options:\n");
	fprintf(stdout,"      --alter             Enable alteration of the system variables\n");
	fprintf(stdout,"      --anchor            Set &ANCHOR = 1 (anchor mode)\n");
	fprintf(stdout,"  -b, --banner            Force banner + program info at start\n");
	fprintf(stdout,"      --conditions        Print GPL3 redistribution conditions and exit\n");
	fprintf(stdout,"  -d, --debug             Set &DEBUG = 1 (debug mode)\n");
	fprintf(stdout,"      --dump              Set &DUMP = 1 (dumping mode level 1)\n");
	fprintf(stdout,"      --dump=<n>          Set &DUMP = <n> (dumping mode levels 1..4)\n");
	fprintf(stdout,"  -e, --enable-printer    Enable printer for OUTPUT()\n");
	fprintf(stdout,"      --errors-list       Print the complete errors list and exit\n");
 	fprintf(stdout,"  -f  --final-state       Print the final state of computation\n");
	fprintf(stdout,"  -h, --help              Display this information and exit\n");
	fprintf(stdout,"  -i, --interactive       Start a PIE session\n");
	fprintf(stdout,"      --input=<s>         Set <s> as the next input file\n");
	fprintf(stdout,"  -j  --job-to-output     Send the job log text to the default output\n");
	fprintf(stdout,"      --joblog=<s>        Set <s> as the job log file\n");
	fprintf(stdout,"      --no-fail           Set the -NOFAIL directive for all lines\n");
	fprintf(stdout,"      --output=<s>        Set <s> as the output file\n");
	fprintf(stdout,"  -p, --pattern-debug     Expand each pattern evaluation\n");
 	fprintf(stdout,"      --print-complete    Print patterns and created-variables in full\n");
	fprintf(stdout,"      --quell-pragma      Avoid execution of any -PRAGMA directive\n");
	fprintf(stdout,"  -r, --resource          se what follows the final END as the last input\n");
	fprintf(stdout,"  -s, --stats             Print statistics about the program execution\n");
	fprintf(stdout,"      --stlimit=<n>       Set &STLIMIT = <n>\n");
	fprintf(stdout,"  -t, --timing            Print the running time of the execution\n");
	fprintf(stdout,"      --trace=<l>         Add variable in the list <l> to the TRACE list\n");
	fprintf(stdout,"      --trace-on-stop=<l> On CTRL-C, print the state of variables in <l>\n");
	fprintf(stdout,"      --trim              Set &TRIM = 1 (trim mode)\n");
	fprintf(stdout,"      --user-list=<file>  Enable -LIST on the indicated file\n");
	fprintf(stdout,"  -v, --version           Display version and exit\n");
	fprintf(stdout,"      --warranty          Print warranty conditions from GPL3 and exit\n");
	fprintf(stdout,"  -x                      Preprocess only. No execution\n");
 	fprintf(stdout,"      --                  Stops parsing options. The filename follows.\n");
	fprintf(stdout,"%s","\n");
	printWide(stdout,"The --input option may be iterated, and the input files will be queued in the given order. The --output option must be supplied only once; if more than one instance of it is provided, only the latter will be taken as the default output file. If no input or output files are set, the keyboard is assumed as the default input, and the screen as the default output.\n\0",80);
	printWide(stdout,"The --resource option appends what follows the last END label to the input files list (in an independent temporary file that will be removed after execution).\n\0",80);
	fprintf(stdout,"\nListing options:\n");
	fprintf(stdout,"  -L, --listing           List the source after the program execution\n");
	fprintf(stdout,"  -l, --list              List the source before the program execution\n");
	fprintf(stdout,"  -n, --numbered-list     List the source with numbered lines and exit\n");
	fprintf(stdout,"  -o, --original-list     List the original source text and exit\n");
	fprintf(stdout,"%s","\n");
	printWide(stdout,"The --list option emulates the behavior of some older compilers that listed the original source before execution. The --listing option, that lists the program source after execution, in case of continuation lines (with +), grouped lines (with the semicolon) or CODE istructions, procedures that alter the regular line numbering, helps in finding the correct error position given by the error routine.\n\n\0",80);
	printWide(stdout,"You should have received a copy of the GNU General Public License along with this program. If not, see <http:/www.gnu.org/licenses/>. Consult the man or the info page to know more about this program. Email bugs reports to <ing dot antonio dot maschio at gmail dot com>.\n\n\0",80);
	fprintf(stdout,"%s\n\n","It's GPL, enjoy!");
}


/* printHiddenHelp()
 * help message */
void printHiddenHelp(void) {
	fprintf(stdout,"Usage: soft [options] [filename]\n\n");
	fprintf(stdout,"Options:\n");
	fprintf(stdout,"      --alter             Enable alteration of the system variables\n");
	fprintf(stdout,"      --anchor            Set &ANCHOR = 1 (anchor mode)\n");
	fprintf(stdout,"  -b, --banner            Force banner + program info at start\n");
	fprintf(stdout,"      --conditions        Print GPL3 redistribution conditions and exit\n");
	fprintf(stdout,"  -d, --debug             Set &DEBUG = 1 (debug mode)\n");
	fprintf(stdout,"      --dump              Set &DUMP = 1 (dumping mode level 1)\n");
	fprintf(stdout,"      --dump=<n>          Set &DUMP = <n>\n");
	fprintf(stdout,"  -e, --enable-printer    Enable printer for OUTPUT()\n");
	fprintf(stdout,"      --errors-list       Print the complete errors list and exit\n");
 	fprintf(stdout,"  -f  --final-state       Print the final state of computation\n");
 	fprintf(stdout,"      --flow              Print current line in execution\n");
	fprintf(stdout,"  -h, --help              Display the normal help information and exit\n");
	fprintf(stdout,"      --hidden            Display this extendend hidden information and exit\n");
	fprintf(stdout,"  -i, --interactive       Start a PIE session on the file\n");
	fprintf(stdout,"      --input=<s>         Set <s> as the next input file\n");
	fprintf(stdout,"  -j  --job-to-output     Send the job log text to the default output\n");
	fprintf(stdout,"      --joblog=<s>        Set <s> as the job log file\n");
	fprintf(stdout,"  -k                      Run anyway even in case of errors\n");
	fprintf(stdout,"  -L, --listing           List the source after the program execution\n");
	fprintf(stdout,"  -l, --list              List the source before the program execution\n");
	fprintf(stdout,"      --no-fail           Set the -NOFAIL directive for all lines\n");
	fprintf(stdout,"      --no-list           Prevent activating the directive -LIST\n");
	fprintf(stdout,"  -n, --numbered-list     List the source with numbered lines and exit\n");
	fprintf(stdout,"  -o, --original-list     List the original source text and exit\n");
	fprintf(stdout,"      --output=<s>        Set <s> as the output file\n");
	fprintf(stdout,"  -P=<n>                  Set line <n> as BREAKPOINT while debugging\n");
	fprintf(stdout,"  -p, --pattern-debug     Expand each pattern evaluation\n");
 	fprintf(stdout,"      --print-complete    Print patterns and created-variables in full\n");
	fprintf(stdout,"      --quell-pragma      Avoid execution of any -PRAGMA directive\n");
	fprintf(stdout,"  -r, --resource          Use what follows final END as last input source\n");
	fprintf(stdout,"      --state             Enable state while debugging\n");
	fprintf(stdout,"  -S                      In case of error, print also the error line number\n");
	fprintf(stdout,"  -s, --stats             Print statistics about the program execution\n");
	fprintf(stdout,"      --stlimit=<n>       Set STLIMIT to <n>\n");
	fprintf(stdout,"  -t, --timing            Print the running time of the execution\n");
	fprintf(stdout,"      --trace=<l>         Add variable in the list <l> to TRACE list\n");
	fprintf(stdout,"      --trace-on-stop=<l> On CTRL-C, print state of variables in list <l>\n");
	fprintf(stdout,"      --trim              Set &TRIM = 1 (trim mode)\n");
	fprintf(stdout,"      --user-list=<file>  OUtput -LIST on the indicated file\n");
	fprintf(stdout,"  -V                      Print the version number and exit\n");
	fprintf(stdout,"  -v, --version           Display version and exit\n");
	fprintf(stdout,"  -W                      Discharge and print all variables data at the end\n");
	fprintf(stdout,"      --warranty          Print warranty conditions from GPL3 and exit\n");
	fprintf(stdout,"  -X                      Prevent directives to be executed\n");
	fprintf(stdout,"  -x                      Preprocess only. No execution\n");
 	fprintf(stdout,"      --                  Stops parsing options. The filename follows.\n");
}


/* printUsage()
 * usage message */
void printUsage(void) {
	fprintf(stdout,"Usage: soft [options] [filename]\n");
	fprintf(stdout,"Type soft -h for help\n");
	s_exit(EXIT_FAILURE);
}

/* printExistence()
 * existence message */
void printExistence(int doIt, int col) {
	if (!doIt) return;
	if (col) fprintf(stdout,LOGO,REDCOLOR,RESETCOLOR,REDCOLOR,RESETCOLOR);
	else fprintf(stdout,LOGO,"","","","");
	fprintf(stdout,"soft, a snobol4 interpreter for the humanities\n");
}

/* printVersion()
 * help banner */
void printVersion(int doIt) {
	printExistence(doIt,TRUE);
	fprintf(stdout,"version %s", VERSION);
	fprintf(stdout," - Copyleft (C) %s\n%s <%s>. \n", CY, AU, EM);
}

/* printHelpBanner()
 * version message */
void printHelpBanner(void) {
	fprintf(stdout,"%s\n","---------------------------------------------------------------");
	printWide(stdout,"This free software comes with ABSOLUTELY NO WARRANTY; for details about this, type 'soft --warranty'. You are welcome to redistribute it under certain conditions; type 'soft --conditions' for details. This software is released under the terms of the GNU General Public License 3.\n\0",80);
}

/* printWarranty()
 * warranty message (required by GPL3) */
void printWarranty(void) {
	printWide(stdout,"THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAWS. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHTERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\0",80);
}

/* printConditions()
 * conditions message (required by GPL3) */
void printConditions(void) {
	printWide(stdout,"You may make, run and propagate covered works that you do not convey, without conditions so long as your license otherwise remains in force. You may convey covered works to others for the sole purpose of having them make modifications exclusively for you, or provide you with facilities for running those works, provided that you comply with the terms of this License in conveying all material for which you do not control copyright. Those thus making or running the covered works for you must do so exclusively on your behalf, under your direction and control, on terms that prohibit them from making any copies of your copyrighted material outside their relationship with you.\n\0",80);
}


/******************************************************************************
 * MAIN SECTION
 ******************************************************************************/


/* doPragma()
 * set default option for correct running of a program */
void doPragma(char *arg) {
	char *args[MAXARGS+1];
	char *q, *a, op[COMPSTR], sin[COMPSTR];
	int argc=0;
	a=arg;
	while (isblank(*a)) a++;
	q=op;
	while (*a) *q++=*a++;
	*q='\0';
	q=op;
	args[argc]=malloc(7);
	if (!args[argc]) perror_(__LINE__,73,l);
	strncpy_(args[argc],"./soft",7);
	argc++;
	if (argc>MAXARGS) perror_(__LINE__,7,l);
	while (isblank(*q)) q++;
	while (*q=='-') {
		a=sin;
		while (*q && !isblank(*q)) *a++=*q++;
		*a='\0';
		args[argc]=malloc((int)strlen(sin)+1);
		if (!args[argc]) perror_(__LINE__,73,l);
		strncpy_(args[argc],sin,(int)strlen(sin)+1);
		while (isblank(*q)) q++;
		argc++;
		if (argc>MAXARGS) perror_(__LINE__,7,l);
	}
	args[argc]=malloc((int)strlen(filename)+1);
	if (!args[argc]) perror_(__LINE__,73,l);
	strncpy_(args[argc],filename,(int)strlen(filename)+1);
	eval_options(argc,args);
}


/* eval_options()
 * parse options; double and single dash options may be alternated,
 * options requiring an argument may or not be attached (but must
 * be the last options of that group);
 * return the updated argc count in ac
 * ~Antonio Maschio - March 2014 for the decb project, adapted and extracted
 * as a single function in April 2021 for the soft project */
int eval_options(int argc, char **argv) {
	int c,ac=0;
	while (++ac < argc) {
		/* do not parse the rest of the command-line */
		if (!strcasecmp(argv[ac], "--")) {
			ac++;
			break;
		}
		if (*argv[ac]=='-') {
			/* option --help */
			if (!strcasecmp(argv[ac], "--help")) {
				fputc('\n',stdout);
				printHelp(TRUE);
				exit(EXIT_SUCCESS);
			}
			/* option --hidden */
			if (!strcasecmp(argv[ac], "--hidden")) {
				fputc('\n',stdout);
				printHiddenHelp();
				exit(EXIT_SUCCESS);
			}
			/* option --errors-list */
			else if (!strcasecmp(argv[ac], "--errors-list") ||\
				!strcasecmp(argv[ac], "--errorslist") ||\
				!strcasecmp(argv[ac], "--errors")) {
				int i;
				char *y;
				fprintf(stdout,"\nErrors list for soft ");
				fprintf(stdout,"version %s\n\n",VERSION);
				for (i=0;i<ERRLIM;i++) {
				    y=error[i];
				    if (*y) fprintf(stdout,"%3d %s\n",i,y);
				}
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS);
			}
			/* option --version */
			else if (!strcasecmp(argv[ac], "--version")) {
				fputc('\n',stdout);
				printVersion(TRUE);
				printHelpBanner();
				exit(EXIT_SUCCESS);
			}
			/* option --anchor */
			else if (!strncasecmp(argv[ac], "--anchor",8)) {
				isAnchored=TRUE;
				continue;
			}
			/* option --original-list */
			else if (!strncasecmp(argv[ac], "--original-list",15)) {
				isListOriginal=TRUE;
				continue;
			}
			/* option --numbered-list */
			else if (!strncasecmp(argv[ac], "--numbered-list",15)) {
				isListNumbered=TRUE;
				continue;
			}
			/* option --listing */
			else if (!strncasecmp(argv[ac], "--listing",9)) {
				isListAfter=TRUE;
				continue;
			}
			/* option --list*/
			else if (!strncasecmp(argv[ac], "--list",6)) {
				isListBefore=TRUE;
				continue;
			}
			/* option --enable-printer */
			else if (!strncasecmp(argv[ac], "--enable-printer",16)) {
				isPrinter=TRUE;
				continue;
			}
			/* option --quell-pragma */
			else if (!strncasecmp(argv[ac], "--quell-pragma",14)) {
				doThePragma=FALSE;
				continue;
			}
			/* option --debug */
			else if (!strncasecmp(argv[ac], "--debug",7)) {
				isDebug=TRUE;
				continue;
			}
			/* option --dump */
			else if (!strncasecmp(argv[ac], "--dump",6)) {
				char *p=argv[ac]+6;
				char LINE[COMPSTR], *li=LINE;
				isDumping=TRUE;
				if (*p=='=') {
					p++; // skip =
					while(*p && isdigit(*p)) *li++=*p++;
					*li='\0';
					isDumping=strtoll(LINE,NULL,10);
					if (isDumping<1) isDumping=1;
					if (isDumping>4) isDumping=4;
				}
				continue;
			}
			/* option --user-list=<file> */
			else if (!strncasecmp(argv[ac], "--user-list=",12)) {
				char *p=argv[ac]+12, *li=userlist;
				while(*p && !isblank(*p)) *li++=*p++;
				*li='\0';
				isUserList=TRUE;
				isToListD=TRUE;
				continue;
			}
			/* option --timing */
			else if (!strncasecmp(argv[ac], "--timing",8)) {
				if (!isStats) isTiming=TRUE;
				else isTiming=FALSE;
				continue;
			}
			/* option --alter */
			else if (!strncasecmp(argv[ac], "--alter",7)) {
				isToAlter=TRUE;
				continue;
			}
			/* option --banner */
			else if (!strncasecmp(argv[ac], "--banner",8)) {
				isBanner=TRUE;
				continue;
			}
			/* option --stats */
			else if (!strncasecmp(argv[ac], "--stats",7)) {
				isStats=TRUE;
				isTiming=FALSE;
				continue;
			}
			/* option --trace= */
			else if (!strncasecmp(argv[ac], "--trace=",8)) {
				char *p=argv[ac]+8;
				char LINE[COMPSTR], *li;
				while(*p && !isblank(*p)) {
					li=LINE;
					while(*p && *p!=',') *li++=*p++;
					*li='\0';
					toBeTracedTOS++;
					if (toBeTracedTOS>=MAXARGS)
						perror_(__LINE__,61,l);
					strncpy(toBeTraced[toBeTracedTOS],LINE,COMPSTR);
					if (*p==',') p++;
				}
				isTrace=TRUE;
				continue;
			}
			/* option --trace-on-stop= */
			else if (!strncasecmp(argv[ac],"--trace-on-stop=",16)){
				char *p=argv[ac]+16;
				char LINE[COMPSTR], *li;
				while (*p && !isblank(*p)) {
					li=LINE;
					while(*p && *p!=',') *li++=*p++;
					*li='\0';
					stopTOS++;
					if (stopTOS>=MAXDIM)
						perror_(__LINE__,61,l);
					strncpy_(onStop[stopTOS],LINE,COMPSTR);
					if (*p==',') p++;
				}
				isTraceOnStop=TRUE;
				continue;
			}
			/* option --stlimit= */
			else if (!strncasecmp(argv[ac], "--stlimit=",10)) {
				char *p=argv[ac]+10;
				char LINE[COMPSTR], *li=LINE;
				if (*p=='-') *li++=*p++;
				while(*p && isdigit(*p)) *li++=*p++;
				*li='\0';
				isStLimit=strtoll(LINE,NULL,10);
				if (isStLimit>MEMLIMIT) isStLimit=MEMLIMIT;
				continue;
			}
			/* option --input= */
			else if (!strncasecmp(argv[ac], "--input=",8)) {
				char *p=argv[ac]+8;
				char LINE[COMPSTR], *li=LINE;
				fileTOS++;
				if (fileTOS>=STREAMS) perror_(__LINE__,81,l);
				/* copy file name */
				while(*p && !isblank(*p)) *li++=*p++;
				*li='\0';
				/* open file */
				channel[fileTOS].stream=fopen(LINE,"r+"); // r+
				if (!channel[fileTOS].stream) perror_(__LINE__,8,l);
				channel[fileTOS].wayout=VREAD;
				channel[fileTOS].datalen=COMPSTR;
				channel[fileTOS].isCanon=TRUE;
				channel[fileTOS].isKYB=FALSE;
				strncpy_(channel[fileTOS].ioname,LINE,COMPSTR);
				continue;
			}
			/* option --pattern-debug */
			else if (!strncasecmp(argv[ac], "--pattern-debug",15)) {
				isCommandDebug=TRUE;
				continue;
			}
			/* option --state (UNDOCUMENTED) */
			else if (!strncasecmp(argv[ac], "--state",7)) {
				printState=TRUE;
				continue;
			}
			/* option --final-state */
			else if (!strncasecmp(argv[ac], "--final-state",13)) {
				isFinDebug=TRUE;
				continue;
			}
			/* option --resource */
			else if (!strncasecmp(argv[ac], "--resource",10)) {
				isResFile=TRUE;
				continue;
			}
			/* option --interactive */
			else if (!strncasecmp(argv[ac], "--interactive",13)) {
				goPie=TRUE;
				strncpy_(prompt,"\n$ ",COMPSTR);
				continue;
			}
			/* option --output= */
			else if (!strncasecmp(argv[ac], "--output=",9)) {
				char *p=argv[ac]+9;
				char LINE[COMPSTR], *li=LINE;
				char pfilename[COMPSTR];
				fileTOS++;
				if (fileTOS>=STREAMS) perror_(__LINE__,81,l);
				/* copy file name */
				while(*p && !isblank(*p)) *li++=*p++;
				*li='\0';
				/* open file */
				channel[fileTOS].stream=fopen(LINE,"r+"); // r+
				if (!channel[fileTOS].stream) perror_(__LINE__,8,l);
				fseek(channel[fileTOS].stream,0,SEEK_END);
				channel[fileTOS].wayout=VWRITE;
				channel[fileTOS].isCanon=TRUE;
				channel[fileTOS].isKYB=FALSE;
				strncpy_(channel[fileTOS].attach,"\n",COMPSTR);
				strncpy_(channel[fileTOS].ioname,LINE,COMPSTR);
				strncpy_(pfilename,LINE,COMPSTR);
				outF=fileTOS; // set default printing for OUTPUT
				continue;
			}
			/* option --flow (UNDOCUMENTED) */
			else if (!strncasecmp(argv[ac], "--flow",6)) {
				isFlow=TRUE;
				continue;
			}
			/* option --no-list (UNDOCUMENTED) */
			else if (!strncasecmp(argv[ac], "--no-list",9)) {
				isToListD=FALSE;
				continue;
			}
			/* option --print-complete */
			else if (!strncasecmp(argv[ac], "--print-complete",16)) {
				isPrintComplete=TRUE;
				continue;
			}
			/* option --trim */
			else if (!strncasecmp(argv[ac], "--trim",6)) {
				isGTrim=TRUE;
				continue;
			}
			/* option --no-fail */
			else if (!strncasecmp(argv[ac], "--no-fail",9)) {
				FFLAG=FALSE;
				continue;
			}
			/* option --job-to-output */
			else if (!strncasecmp(argv[ac], "--job-to-output",15)) {
				isDefJobLog=FALSE;
				continue;
			}
			/* option --joblog= */
			else if (!strncasecmp(argv[ac], "--joblog=",9)) {
				char *p=argv[ac]+9;
				char *li=joblog;
				while(*p && !isblank(*p)) *li++=*p++;
				*li='\0';
				isDefJobLog=TRUE;
				continue;
			}
			/* option --warranty */
			else if (!strcasecmp(argv[ac], "--warranty")) {
				fputc('\n',stdout);
				printWarranty();
				exit(EXIT_SUCCESS);
			}
			/* option --conditions */
			else if (!strcasecmp(argv[ac], "--conditions")) {
				fputc('\n',stdout);
				printConditions();
				exit(EXIT_SUCCESS);
			}
			/* this feature is intentionally undocumented
			 * I use it to generate the README file */
			else if (!strcasecmp(argv[ac], "--greetings")) {
				fprintf(stdout,"%s","soft README page\n");
				fprintf(stdout,"%s",WELCOME);
				printExistence(TRUE,FALSE);
				printVersion(FALSE);
				printHelpBanner();
				printHelp(FALSE);
				fprintf(stdout,GREET);
				printWarranty();
				fprintf(stdout,"%s","\n");
				printConditions();
				fprintf(stdout,"%s","It's GPL. Enjoy!\n\n");
				exit(EXIT_SUCCESS);
			}
			/* stop options parsing */
			else if (!strcasecmp(argv[ac], "--")) {
				break;
			}
			/* ignore unrecognized double-dash options */
			else if (!strcmp(argv[ac],"--")) {
				char output[COMPSTR];
				snprintf(output,COMPSTR,error[79],argv[ac]);
				fprintf(stderr,"%s\n\n",output);
				continue;
			}
			/* ignore unrecognized dash-only options */
			else if (!strcmp(argv[ac],"-")) {
				char output[COMPSTR];
				snprintf(output,COMPSTR,error[78],NULL);
				fprintf(stderr,"%s\n\n",output);
				continue;
			}
			/* parse single-dash options */
			while (*++argv[ac]) {
				c=*argv[ac];
				/* option -b
				 * force banner */
				if (c=='b') {
					isBanner=TRUE;
				}
				/* option -d
				 * debug activation */
				else if (c=='d') {
					isDebug=TRUE;
					goPie=FALSE;
					strncpy_(prompt,"\n> ",COMPSTR);
				}
				/* option -e
				 * enable sending PRN file to printer */
				else if (c=='e') {
					isPrinter=TRUE;
				}
				/* option -f
				 * print final state */
				else if (c=='f') {
					isFinDebug=TRUE;
				}
				/* option -h
				 * print help */
				else if (c=='h') {
					fputc('\n',stdout);
					printHelp(TRUE);
					exit(EXIT_SUCCESS);
				}
				/* option -i
				 * activates PIE */
				else if (c=='i') {
					goPie=TRUE;
					isDebug=FALSE;
					strncpy_(prompt,"\n$ ",COMPSTR);
				}
				/* option -j
				 * list program */
				else if (c=='j') {
					isDefJobLog=FALSE;
				}
				/* option -k
				 * run anyway */
				else if (c=='k') {
					isRunAnyway=TRUE;
				}
				/* option -l
				 * list program */
				else if (c=='l') {
					isListBefore=TRUE;
				}
				/* option -L
				 * list program */
				else if (c=='L') {
					isListAfter=TRUE;
				}
				/* option -n
				 * list numbered source */
				else if (c=='n') {
					isListNumbered=TRUE;
				}
				/* option -o
				 * list source */
				else if (c=='o') {
					isListOriginal=TRUE;
				}
				/* option -p
				 * pattern debug */
				else if (c=='p') {
					isCommandDebug=TRUE;
				}
				/* option -P=<n> (UNDOCUMENTED)
				 * set line <n> as break point,
				 * enabling debug */
				else if (c=='P') {
					char num[COMPSTR];
					isDebug=TRUE;
					breakTOS++; // no check here
					strncpy_(num,(argv[ac]+2),COMPSTR);
					breaks[breakTOS]=strtol(num,NULL,10);
					argv[ac]+=strlen(num)+1;
					continue;
				}
				/* option -r
				 * set what follows the END statement
				 * as the input file */
				else if (c=='r') {
					isResFile=TRUE;
				}
				/* option -s
				 * enable statistics */
				else if (c=='s') {
					isStats=TRUE;
					isTiming=FALSE;
				}
				/* option -S  (UNDOCUMENTED)
				 * print source code line number inside the
				 * error message */
				else if (c=='S') {
					isPrintSourceCode=TRUE;
				}
				/* option -t
				 * list program */
				else if (c=='t') {
					if (!isStats) isTiming=TRUE;
					else isTiming=FALSE;
				}
				/* option -v
				 * print version */
				else if (c=='v') {
					fputc('\n',stdout);
					printVersion(TRUE);
					printHelpBanner();
					exit(EXIT_SUCCESS);
				}
				/* option -V  (UNDOCUMENTED)
				 * print version and exit */
				else if (c=='V') {
					printf("%s",VERSION);
					exit(EXIT_SUCCESS);
				}
				/* option -W (UNDOCUMENTED)
				 * print complete var state at the end */
				else if (c=='W') {
					isCompleteUnload=TRUE;
				}
				/* option -X (UNDOCUMENTED)
				 * avoid directives */
				else if (c=='X') {
					isAvoidDirectives=TRUE;
				}
				/* option -x
				 * preprocess only */
				else if (c=='x') {
					isPreprocessOnly=TRUE;
				}
				/* Ignore unrecognized options */
				else {
					char output[COMPSTR];
					snprintf(output,COMPSTR,error[78],argv[ac]);
					fprintf(stderr,"%s\n\n",output);
				}
			}
		}
		else break;
	}
	return ac;
}


/* main()
 * parse options, get file name, setup environment and perform, at request,
 * the following actions:
 * - setup to create the file in memory
 * - RUN to execute the file
 * Where it all begins... and where it all ends */
int main(int argc, char **argv) {
	int ac;
	char freezefile[COMPSTR];
	FILE *fz;
	strncpy_(prompt,"\n> ",COMPSTR);
	/* set default label codes */
	endCode=setAddr("END");
	returnCode=setAddr("RETURN");
	freturnCode=setAddr("FRETURN");
	nreturnCode=setAddr("NRETURN");
	/* get start time */
	gettimeofday(&tv, NULL);
	beginS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);

	/* get screen window size*/
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;

	/* erase start label */
	strncpy_(startLabel,VOIDS,COMPSTR);

	/* setup job log */
	strncpy_(joblog,JOBLOG,COMPSTR);

	/* evaluate direct options */
	ac=eval_options(argc,argv);

	/* set default output channel */
	channel[0].stream=stdout;
	strncpy_(channel[0].ioname,"screen",COMPSTR);
	channel[0].wayout=VWRITE;
	channel[0].isPrinter=FALSE;
	channel[0].isLastWrite=FALSE;
	channel[0].isCanon=TRUE;
	channel[0].isKYB=FALSE;
	strncpy_(channel[0].attach,ATTACH,COMPSTR);

	/* set default input channel */
	channel[1].stream=stdin;
	strncpy_(channel[1].ioname,"keyboard",COMPSTR);
	channel[1].wayout=VREAD;
	channel[1].isPrinter=FALSE;
	channel[0].isLastWrite=FALSE;
	channel[1].isCanon=TRUE;
	channel[1].isKYB=TRUE;
	channel[1].datalen=COMPSTR;

	/* declare predefined variables */
	declare("ABORT",PATTERN+PREDEF,FALSE,0,0);
	strncpy_(vn[1].str,"&ABORT",COMPSTR);
	declare("ARB",PATTERN+PREDEF,FALSE,0,0);
	strncpy_(vn[2].str,"&ARB",COMPSTR);
	declare("BAL",PATTERN+PREDEF,FALSE,0,0);
	strncpy_(vn[3].str,"&BAL",COMPSTR);
	declare("FAIL",PATTERN+PREDEF,FALSE,0,0);
	strncpy_(vn[4].str,"&FAIL",COMPSTR);
	declare("FENCE",PATTERN+PREDEF,FALSE,0,0);
	strncpy_(vn[5].str,"&FENCE",COMPSTR);
	declare("REM",PATTERN+PREDEF,FALSE,0,0);
	strncpy_(vn[6].str,"&REM",COMPSTR);
	sDefVar=6;
	strncpy_(sReturn,VOIDS,COMPSTR);
#ifndef NOUNIX
	strncpy_(LOGNAME,"LOGNAME",COMPSTR);
#else
	strncpy_(LOGNAME,"USERNAME",COMPSTR);
#endif
	strncpy_(username,getenv(LOGNAME),COMPSTR);

	/* install variables to be traced by option */
	while (toBeTracedTOS>0) {
		declare(toBeTraced[toBeTracedTOS],STRING,FALSE,0,0);
		trace[traceTOS++]=decCount;
		toBeTracedTOS--;
	}

	/* set time for features that depend on starting time */
	now=time(NULL);

	/* intercept the CTRL-C interrupt */
	signal(SIGINT, intHandler);

	/* OK; now, if after any option no file name was given
	 * and no interactive session was required, issue an error */
	if (((ac==argc)||(1==argc)) && !goPie) {
		/* disable statistics */
		isStats=FALSE;
		perror_(__LINE__,71,-1); // OK it appears /after/ goInt()
	}
	/* otherwise, if no file name was given but an interactive
	 * session was required, build a fake program */
	else if (((ac==argc)||(1==argc)) && goPie) {
		erasemem();
		buildFake();
	}
	else {
   		/* get input file name (discard following arguments)
		 * and setup name, attaching extension if not present */
		strncpy_(filename, argv[ac++], COMPSTR);

		/* check for the existence of the freeze file */
		strncpy_(freezefile,createFreezeFile(),COMPSTR);
		fz=fopen(freezefile,"r"); // confirmed "r"

		/* load old frozen state */
		if (fz) {
			isFreeze=TRUE;
			loadFreeze(freezefile);
			fclose(fz);
		}

		/* store program in memory
		 * Note: setSourceFile() is executed in LOAD
		 * when the final END is met */
		if (!isFreeze) {
			setup();
			/* set starting channels */
			resetFileIndex();
		}

		/* attach parameters in &PARM */
		if (ac<argc) {
			/* then collects the parameters */
			strncpy_(parm,argv[ac++],COMPSTR);
			while (ac<=argc) {
				strncat_(parm," ",COMPSTR);
				strncat_(parm,argv[ac],COMPSTR);
				ac++;
			}
		}
	}

	/* stop here in case option -x was used */
	if (isPreprocessOnly) {
		preproc(); // all info
	}
	/* list the program in organized form and/or RUN */
	else {
		/* force listing for all lines */
		if (isUserList) {
			int i=0;
			while (i<=endCore) ms[i++]=1;
		}
		/* list original source beautified */
		if (isListBefore && !noFile) list_beauty();
		/* list with control statements */
		if (isToListD && !isAvoidDirectives && !isUserList)
			list_control(stdout);
		else if (isToListD && !isAvoidDirectives && isUserList) {
			FILE *fd;
			fd=fopen(userlist,"w");
			// TODO if (!fd) make error
			list_control(fd);
		}
		/* -NOEXECUTE was invoked */
		if (isNoExecute && !isAvoidDirectives);
		/* execute the program in memory */
		else if (!isListNumbered && !isListOriginal) {
			if (isBanner) {
				printf(BANNER,VERSION);
				preproc();
				printf("Program output:\n\n\n");
			}
			if (!isFreeze) {
				l=0;
				RUN();
			}
			else {
				parse(l+1);
			}
			if (isBanner) {
				printf("\n\nProgram terminated.\n\n\n");
			}
			/* the listing operation is performed in END() */
		}
		/* list the program in numbered meta-form and exit */
		if (isListNumbered && !noFile) {
			int i, w=0;
			char format[COMPSTR];
			for (i=1;i<=endCore;i++) {
				int len=0;
				if (ln[i]>0) {
					len=strlen(label[i]);
					if (len>w) w=len;
				}
			}
			fprintf(stdout,"%s","\n");
			snprintf(format,COMPSTR,"%%-%ds",w+1);
			for (i=1;i<endCore;i++) {
				if (!m[i]) continue;
				printf("[%03d] ",i);
				if (ln[i]) printf(format,label[i]);
				else if (m[i][0]=='-');
				else {
					int j=w+1;
					while (j>0) putchar(' '),j--;
				}
				if (m[i] && *m[i]) {
					printf("%s\n",m[i]);
				}
				else printf("\n");
			}
			printf("[%03d] %-s",endCore, label[endCore]);
			fprintf(stdout,"%s","\n");
		}
		/* list the program in the original form */
		else if (isListOriginal && !noFile) {
			int i;
			for (i=1;i<=endCore;i++) {
				if (mb[i] && *mb[i]) fprintf(stdout,"%s\n",mb[i]);
				else fprintf(stdout,"%s\n","");
			}
		}
	}

	/* END (implicit!) */
	END(procCode);

	/* this is here only for C (!) */
	return EXIT_SUCCESS;


} /* end main */

/* end of soft.c */


