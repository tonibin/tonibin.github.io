A<-1 2 3
B<-3 4 5
A+B
AxB
A%B
A@.*B
)off
