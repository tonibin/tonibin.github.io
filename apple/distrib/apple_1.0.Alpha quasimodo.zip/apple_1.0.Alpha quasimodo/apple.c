/* apple.c
 * Copyleft (C) 2019-2021 Antonio Maschio
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 08 agosto 2021
 *
 * This is apple, an APL engine written in c99 for
 * the UNIX world. You must have gcc 4.X to compile (though maybe 3.X may go).
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */
#include "apple.h"	// catch-all header file

/******************************************
 *         FILE OPERATORS                 *
 ******************************************/
/* d_file()
 * open file with name in op to channel chan;
 * if otype=VREAD open for read
 * if otype=WRITE and wopen=APPEND open for append
 * if otype=WRITE and wopen=ERASE open for new */
void d_file(TDeclare *res, TDeclare chan, TDeclare op, int otype, int wopen) {
	checkStop;

	/* checks on chan */
	if (chan.rank!=SCALAR || chan.row!=1 || chan.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}
	if (op.rank==MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK
		return;
	}
	/* close channel */
	if ((op.rank==SCALAR && op.type==NUMERIC && (int)getArrayVal(op,1,1)==0) ||\
	  		(op.rank==VECTOR && op.type==NUMERIC && op.row==1 && op.col==0)) {
		int i,ret,ch=getArrayVal(chan,1,1);
		if (channel[ch].wayout==VWRITE) {
			fflush(channel[ch].stream);
		}
		if (channel[ch].isOpen) ret=fclose(channel[ch].stream);
		else ret=0;
		if (ret) {
			perror_(__LINE__,30,(int)(strlen(p)-strlen(basetot))); // CANNOT CLOSE FILE
		}
		else instScalar(res,0);
		channel[ch].isOpen=FALSE;
		channel[ch].ch=0;
		channel[ch].wayout=0;
		for (i=0;i<=strlen(channel[ch].name);i++)
			channel[ch].name[i]='\0';
		fileTOS--;
		return;
	}
	/* any other non null integer or a numeric vector is a mistake */
	else if ((op.rank==SCALAR && (int)getArrayVal(op,1,1)!=0) || op.type==NUMERIC) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK
		return;
	}

	/* open for read */
	if (otype==VREAD) {
		char name[COMPSTR];
		int i, ch=getArrayVal(chan,1,1);
		fileTOS++;
		if (fileTOS>STREAMS) {
			perror_(__LINE__,31,(int)(strlen(p)-strlen(basetot))); // TOO MUCH FILES OPENED
			return;
		}

		if (channel[ch].isOpen) {
			perror_(__LINE__,32,(int)(strlen(p)-strlen(basetot))); // FILE ALREADY OPENED
			return;
		}
		for (i=1;i<=op.col;i++) name[i-1]=getArrayVal(op,1,i);
		name[op.col]='\0';
		channel[ch].stream=fopen(name,"r");
		if (!channel[ch].stream) {
			perror_(__LINE__,33,(int)(strlen(p)-strlen(basetot))); // CANNOT OPEN FOR READ
			return;
		}
		channel[ch].isOpen=TRUE;
		channel[ch].ch=ch;
		channel[ch].wayout=VREAD;
		strncpy(channel[ch].name,name,COMPSTR);
		instScalar(res,0);
	}
	/* open for write */
	else if (otype==VWRITE) {
		char name[COMPSTR];
		int i, ch=getArrayVal(chan,1,1);
		fileTOS++;
		if (fileTOS>STREAMS) {
			perror_(__LINE__,31,(int)(strlen(p)-strlen(basetot))); // TOO MUCH FILES OPENED
			return;
		}
		if (channel[ch].isOpen) {
			perror_(__LINE__,32,(int)(strlen(p)-strlen(basetot))); // FILE ALREADY OPENED
			return;
		}
		for (i=1;i<=op.col;i++)
			name[i-1]=getArrayVal(op,1,i);
		name[op.col]='\0';
		if (wopen==WAPPEND) channel[ch].stream=fopen(name,"a");
		else if (wopen==WERASE) channel[ch].stream=fopen(name,"w");
		else {
			perror_(__LINE__,29,(int)(strlen(p)-strlen(basetot))); // WRONG WRITE SPECIFIER
			return;
		}
		if (!channel[ch].stream) {
			perror_(__LINE__,33,(int)(strlen(p)-strlen(basetot))); // CANNOT OPEN FOR WRITE
			return;
		}
		channel[ch].isOpen=TRUE;
		channel[ch].ch=ch;
		channel[ch].wayout=VWRITE;
		strncpy(channel[ch].name,name,COMPSTR);
		instScalar(res,0);
	}
}


/* backchangeEOL()
 * backchange the end-of-line in str 
 * used in d_writeseq() */
void backchangeEOL(char *str) {
	while (*str) {
		if (*str==24) *str='\n';
		str++;
	}
}


/* d_read()
 * read a line from chan, and reconstruct for res 
 * if mask is zero, store zero, else store the object */
void d_read(TDeclare *res, TDeclare chan, TDeclare mask) {
	char def[MAX_READ+1], *d=def;
	int ch,ms;
	int row=1,col=1,type,size;
	checkStop;

	/* checks on chan and mask */
	if (chan.rank!=SCALAR || chan.row!=1 || chan.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}
	if (mask.rank!=SCALAR || mask.row!=1 || chan.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}

	/* get values */
	ch=getArrayVal(chan,1,1);
	ms=getArrayVal(mask,1,1);

	/* more checks */
	if (!channel[ch].isOpen) {
		perror_(__LINE__,35,(int)(strlen(p)-strlen(basetot))); // FILE NOT OPEN
		return;
	}
	if (channel[ch].wayout!=VREAD) {
		perror_(__LINE__,36,(int)(strlen(p)-strlen(basetot))); // TRYING TO READ FROM A WRITE FILE
		return;
	}

	/* read and interpret control string */
	fgets_(def,MAX_READ,channel[ch].stream);
	/* object-mode */
	if (*d=='$') {
		d++;
		type=strtol(d,&d,10); // 1-6
		if (*d=='@') {
			d++;
			row=1;
			col=strtol(d,&d,10);
			if (*d=='@') {
				d++;
				row=col;
				col=strtol(d,&d,10);
			}
		}
		if (*d=='#') {
			d++;
			size=strtol(d,NULL,10);
		}
		else {
			perror_(__LINE__,37,(int)(strlen(p)-strlen(basetot))); // CORRUPTED DATA
			return;
		}
		/* process data of next line */
		if (ms) {
			char str[size+10], *s=str;
			double vec[row*col+1];
			int w=0;
			/* read object string */
			fgets_(str,size+9,channel[ch].stream);
			/* ravel all values */
			while (isblank(*s)) s++;
			while (*s) {
				vec[++w]=strtod(s,&s);
				while (isblank(*s)) s++;
			}
			if (w!=row*col) {
				perror_(__LINE__,37,(int)(strlen(p)-strlen(basetot))); // CORRUPTED DATA
				return;
			}
			/* numeric scalar */
			if (type==1) instScalar(res,vec[1]);
			/* string scalar */
			else if (type==2) {
				instScalar(res,vec[1]);
				res->type=STRING;
			}
			/* numeric vector */
			else if (type==3) instVec(res,NUMERIC,col,vec);
			/* string vector */
			else if (type==4) instVec(res,STRING,col,vec);
			/* matrix */
			else if (type>4) {
				int i,j;
				double mat[row+1][col+1];
				/* build matrix */
				w=0;
				for (i=1;i<=row;i++)
					for (j=1;j<=col;j++) 
						mat[i][j]=vec[++w];
				/* numeric matrix */
				if (type==5) instMat(res,NUMERIC,row,col,mat);
				/* string matrix */
				else if (type==6) instMat(res,STRING,row,col,mat);
			}
		}
		/* skip mode */
		else {
			char str[size+10];
			/* consume */
			fgets_(str,size+9,channel[ch].stream);
			/* skip reading */
			instScalar(res,0);
		}
	}
	/* line-mode */
	else {
		int i;
		if (ms) {
			double vec[strlen(def)+1];
			int len=strlen(def);
			backchangeEOL(def);
			for (i=1;i<=len;i++)
				vec[i]=def[i-1];
			instVec(res,STRING,len,vec);
		}
		else {
			instScalar(res,0);
		}
	}

}


/* changeEOL()
 * change the end-of-line in str 
 * used in d_writeseq() */
void convertEOL(char *str) {
	while (*str) {
		if (*str=='\n') *str=' ';
		else if (*str=='\r') *str=' ';
		str++;
	}
}


/* d_writeobj()
 * write object obj to chan as sequential string */
void d_writeobj(TDeclare *res, TDeclare chan, TDeclare obj) {
	int size, ch, type, bDigit=Wdigit;
	char *s=NULL;
	checkStop;

	/* checks on chan */
	if (chan.rank!=SCALAR || chan.row!=1 || chan.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}

	/* get values */
	ch=getArrayVal(chan,1,1);

	/* more checks */
	if (!channel[ch].isOpen) {
		perror_(__LINE__,35,(int)(strlen(p)-strlen(basetot))); // FILE NOT OPEN
		return;
	}
	if (channel[ch].wayout!=VWRITE) {
		perror_(__LINE__,38,(int)(strlen(p)-strlen(basetot))); // TRYING TO WRITE ON A READ FILE
		return;
	}
	
	/* maximize digits format */
	Wdigit=MAXPREC;
	snprintf(numformat,COMPSTR,"%%.%0dG  ",Wdigit);
	
	/* proceed */
	type=obj.type;
	obj.type=NUMERIC;
	printArray(&s,obj);
	convertEOL(s);
	size=strlen(s);

	if (obj.rank==SCALAR && type==NUMERIC) {
		fprintf(channel[ch].stream,"$1#%d\n",size);
		fprintf(channel[ch].stream,"%s\n",s);
	}
	else if (obj.rank==SCALAR && type==STRING) {
		fprintf(channel[ch].stream,"$2#%d\n",size);
		fprintf(channel[ch].stream,"%s\n",s);
	}
	else if (obj.rank==VECTOR && type==NUMERIC) {
		fprintf(channel[ch].stream,"$3@%d#%d\n",obj.col,size);
		fprintf(channel[ch].stream,"%s\n",s);
	}
	else if (obj.rank==VECTOR && type==STRING) {
		fprintf(channel[ch].stream,"$4@%d#%d\n",obj.col,size);
		fprintf(channel[ch].stream,"%s\n",s);
	}
	else if (obj.rank==MATRIX && type==NUMERIC) {
		fprintf(channel[ch].stream,"$5@%d@%d#%d\n",obj.row,obj.col,size);
		fprintf(channel[ch].stream,"%s\n",s);
	}
	else if (obj.rank==MATRIX && type==STRING) {
		fprintf(channel[ch].stream,"$6@%d@%d#%d\n",obj.row,obj.col,size);
		fprintf(channel[ch].stream,"%s\n",s);
	}
	
	/* restore digits format */
	Wdigit=bDigit;
	snprintf(numformat,COMPSTR,"%%.%0dG  ",Wdigit);
	free(s);
}


/* changeEOL()
 * change the end-of-line in str 
 * used in d_writeseq() */
void changeEOL(char *str) {
	while (*str) {
		if (*str=='\n') *str=24;
		else if (*str=='\r') *str=24;
		str++;
	}
}


/* d_writeseq()
 * write object obj in sequential form to chan  */
void d_writeseq(TDeclare *res, TDeclare chan, TDeclare obj) {
	int ch, bDigit=Wdigit;
	char *s=NULL;
	checkStop;

	/* checks on chan */
	if (chan.rank!=SCALAR || chan.row!=1 || chan.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}

	/* get values */
	ch=getArrayVal(chan,1,1);

	/* more checks */
	if (!channel[ch].isOpen) {
		perror_(__LINE__,35,(int)(strlen(p)-strlen(basetot))); // FILE NOT OPEN
		return;
	}
	if (channel[ch].wayout!=VWRITE) {
		perror_(__LINE__,38,(int)(strlen(p)-strlen(basetot))); // TRYING TO WRITE ON A READ FILE
		return;
	}
	
	/* maximize digits format */
	Wdigit=MAXPREC;
	snprintf(numformat,COMPSTR,"%%.%0dG  ",Wdigit);
	
	/* proceed */
	printArray(&s,obj);
	changeEOL(s);
	fprintf(channel[ch].stream,"%s\n",s);
	
	/* restore digits format */
	Wdigit=bDigit;
	snprintf(numformat,COMPSTR,"%%.%0dG  ",Wdigit);
	free(s);
}



/* d_pos()
 * to channel chan:
 * if pos>0 set fseek to pos, and skip until first forward @
 * if pos==-1, return current fseek
 * if pos==-2, return fseek(END)
 * if pos==-3, test for eof, on EOF return TRUE else FALSE */
void d_pos(TDeclare *res, TDeclare chan, TDeclare pos) {
	int val, ch;
	checkStop;

	/* checks on chan and pos */
	if (chan.rank!=SCALAR || chan.row!=1 || chan.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}
	if (pos.rank!=SCALAR || pos.row!=1 || pos.col!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot))); // RANK 
		return;
	}

	/* get values */
	ch=getArrayVal(chan,1,1);
	val=getArrayVal(pos,1,1);
	
	/* more checks */
	if (!channel[ch].isOpen) {
		perror_(__LINE__,35,(int)(strlen(p)-strlen(basetot))); // FILE NOT OPEN
		return;
	}
	if (channel[ch].wayout!=VREAD) {
		perror_(__LINE__,39,(int)(strlen(p)-strlen(basetot))); // CONTROLS ONLY IN READ MODE
		return;
	}

	/* set cursor position */
	if (val>0) {
		int len;
		fseek(channel[ch].stream,0,SEEK_END);
		len=ftell(channel[ch].stream);
		if (val>len) {
			perror_(__LINE__,40,(int)(strlen(p)-strlen(basetot))); // ILLEGAL FILE POINTER
			return;
		}
		fseek(channel[ch].stream,val,SEEK_SET);
		instScalar(res,0);
	}
	/* return current position */
	else if (val==-1) {
		instScalar(res,ftell(channel[ch].stream));
	}
	/* return file dimension */
	else if (val==-2) {
		int curr=ftell(channel[ch].stream);
		fseek(channel[ch].stream,0,SEEK_END);
		instScalar(res,ftell(channel[ch].stream));
		fseek(channel[ch].stream,curr,SEEK_SET);
	}
	/* return EOF state */
	else if (val==-3) {
		char c;
		int f;
		c=fgetc(channel[ch].stream);
		f=feof(channel[ch].stream);
	       	if (f) {
			instScalar(res,1);
			clearerr(channel[ch].stream);
		}
		else {
			ungetc(c,channel[ch].stream);
			instScalar(res,0);
		}
	}
	/* align in object-mode */
	else if (val==-4) {
		int c=fgetc(channel[ch].stream);
		if (c=='$') ungetc(c,channel[ch].stream);
		else {
			c=fgetc(channel[ch].stream);
			while (c!=EOF && c!='$') {
				c=fgetc(channel[ch].stream);
			}
			if (c=='$') ungetc(c,channel[ch].stream);
		}
		if (c!=EOF) instScalar(res,0);
		else instScalar(res,1);
	}
}


/******************************************
 *            APL INSPECTION              *
 ******************************************/
/* get_uptime()
 * calculates the memory amount of the program and return
 * it as an integer value in bytes*/
int get_uptime(void) {
	struct sysinfo s_info;
	int error = sysinfo(&s_info);
	if (error != 0) return 0;
	return s_info.uptime;
}


/* free_()
 * service function to free memory of the TDeclare variables */
void free_(TDeclare *var) {
	if (var->allocated && var->elem) {
		free(var->elem);
	}
	var->elem=NULL;
	var->allocated=FALSE;
}


/* outArray()
 * service function for gdb. Not used in apple */
void outArray(TDeclare var) {
	char *output=NULL;
	printArray(&output,var);
	emit(1,"%s\n",output);
	free(output);
}


/* isNotBanned()
 * return TRUE if the system )COMMAND can be used in programming
 * FALSE otherwise */
int isNotBanned(char *com) {
	if (!strncasecmp_(com,"CLEA",4)) return FALSE;
	if (!strncasecmp_(com,"COPY",4)) return FALSE;
	if (!strncasecmp_(com,"ERAS",4)) return FALSE;
	if (!strncasecmp_(com,"SAVE",4)) return FALSE;
	if (!strncasecmp_(com,"LOAD",4)) return FALSE;
	if (!strncasecmp_(com,"PCOP",4)) return FALSE;
	if (!strncasecmp_(com,"RENA",4)) return FALSE;
	return TRUE;
}


/* doScript()
 * perform the scripting of 'text' to fs
 * val is currently unused */
void doScript(FILE *fs, int val, char *format, ...) {
	if (isScript && fs) {
		va_list ap;
		va_start(ap, format);
		vfprintf(fs,format,ap);
		va_end(ap);
	}
}


/* emit()
 * print on the screen and if required on the script also
 * val is currently unused */
void emit(int val, char *format, ...) {
	va_list ap;
	if (isInterrupt) return;
	va_start(ap, format);
	vfprintf(stdout,format,ap);
	if (isScript && FS) {
		va_start(ap, format);
		vfprintf(FS,format,ap);
	}
	va_end(ap);
}


/* applizeName()
 * transform the name name.apl or name.wks in NAME */
void applizeName(char *name) {
	char *k=name;
	while (*k && *k!='.') k++;
	if (*k=='.') *k='\0';
	k=name;
	while (*k) {
		*k=toupper(*k);
		k++;
	}
}


/* isIBeam()
 * return TRUE if s points to an I-Beam figure 
 * FALSE otherwise */
int isIBeam(char *s) {
	if (*s=='I' && *(s+1)=='_') s+=2;
	else return FALSE;
	while (isblank(*s)) s++;
	if (isdigit(*s)) return TRUE;
	return FALSE;
}


/* setIBeam()
 * set value for the addressable I-Beam variables */
void setIBeam(int code, int var) {
    switch(code) {
        case 1: if (var>=WHigh && var<=WLow) {
			Wfuzz=var;
			fuzzValue=pow(10.0,Wfuzz*(-1.0));
		}
		else if (var==0.0) {
			Wfuzz=fuzzValue=0;
		}
		else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		break;
        case 2: if (var>=WHigh && var<=WMant) {
			Wdigit=var;
			snprintf(numformat,COMPSTR,"%%.%0dG  ",Wdigit);
		}
		else if (var==0) {
			Wdigit=var;
			snprintf(numformat,COMPSTR,"%%.06G  ");
		}
		else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		break;
        case 3: ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
		sysWidth=(int)wsz.ws_col;
		if (var>=30 && var<=sysWidth) Wwidth=var;
		else if (var==0.0) Wwidth=0.0;
		else perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
		break;
        case 4: if (var>=2 && var<=32768) {
			if ((int)var%2) var=(int)var+1;
			Wseed=var;
			Wchange=TRUE;
		}
		else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		break;
        case 5: if (var>=WHigh && var<=WLow) Wcomp=pow(10.0,-var);
		else if (var==0.0) Wcomp=0.0;
		else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		break;
        case 6: Wdiv=var; break;
        case 7: if (var==0 || var==1) indexOrigin=var; 
		else perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
		break;
        case 19: if (var==0 || var==1) isExp=var; 
		else perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
		break;
        case 38: Winv=var; break;
	case 46: maxDec=var; break;
        case 40: I_access=var; 
		break;
        default:perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot))); // SYNTAX
    }
}


/* getIBeam()
 * get value from an i-Beam variable */
void getIBeam(TDeclare *res, int code) {
	double ret[COMPSTR];
	int i, TOS=0, type=NUMERIC;
	switch(code) {
		case 1:	 ret[++TOS]=Wfuzz; break;
		case 2:	 ret[++TOS]=Wdigit; break;
		case 3:	 ret[++TOS]=Wwidth; break;
		case 4:	 ret[++TOS]=Wseed; break;
		case 5:	 ret[++TOS]=Wcomp; break;
		case 6:	 ret[++TOS]=Wdiv; break;
		case 7:	 ret[++TOS]=indexOrigin; break;
		case 8:	 gettimeofday(&tv, NULL);
			 endMS=(long long int)(tv.tv_sec*1000 + tv.tv_usec/1000.0);
			 ret[++TOS]=(endMS-beginMS);
			 break;
		case 9:  ret[++TOS]=getHour(); break;
		case 10: ret[++TOS]=getMin(); break;
		case 11: ret[++TOS]=getSec(); break;
		case 12: ret[++TOS]=getYear(); break;
		case 13: ret[++TOS]=getMonth(); break;
		case 14: ret[++TOS]=getDay(); break;
		case 15:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"%02d-%s-%d",getDay(),getMonthString(),getYear());
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 16:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"%02d:%02d:%02d",getHour(),getMin(),getSec());
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 17:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"%02d:%02d",getHour(),getMin());
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 18: callFlags();
			 callTime();
			 break;
		case 19: ret[++TOS]=isExp; break;
		case 20: ret[++TOS]=(getHour()*24.0+getMin()*60.0+getSec())*60.0; break;
		case 21: ret[++TOS]=get_uptime()*60; break;
		case 22: ret[++TOS]=COMPVAR-decCount-1;
			 ret[++TOS]=COMPSTR-progCount-1;
			 break;
		case 23: ret[++TOS]=1; break;
		case 24: gettimeofday(&tv, NULL);
		   	 endS=(tv.tv_sec + tv.tv_usec/1000000.0);
			 ret[++TOS]=(endS-beginS)*60;
			 break;
		case 25: ret[++TOS]=getYear()*10000+getMonth()*100+getDay(); break;
		case 26: ret[++TOS]=progLine; break;
		case 27: if (backTOS) {
				 int i=backTOS;
				 while (i>0) {
					 ret[++TOS]=backNumber[i--];
				 }
			 }
			 else ret[++TOS]=0;
			 break;
		case 28: if (filename[0]) {
				TOS=strlen(filename);
				for (i=1;i<=TOS;i++)
					ret[i]=filename[i-1];
			 }
			 else ret[++TOS]=0;
			 type=STRING;
			 break;
		case 29: if (lastProgram) {
				TOS=strlen(pn[lastProgram].name);
				for (i=1;i<=TOS;i++)
					ret[i]=pn[lastProgram].name[i-1];
			 }
			 else if (!lastProgram && filename[0]) {
				TOS=strlen(pn[0].name);
				for (i=1;i<=TOS;i++)
					ret[i]=pn[0].name[i-1];
			 }
			 else ret[++TOS]=0;
			 type=STRING;
			 break;
		case 30: if (username[0]) {
				TOS=strlen(username);
				for (i=1;i<=TOS;i++)
					ret[i]=username[i-1];
			 }
			 else ret[++TOS]=0;
			 type=STRING;
			 break;
		case 31:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"ABCDEFGHIJKLMNOPQRSTUVWXYZ");
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 32:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"abcdefghijklmnopqrstuvwxyz");
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 33:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"0123456789");
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 34:
		{
			i=1;
			char str[COMPSTR];
			snprintf(str,COMPSTR,"!\"#%%&\'()*,./:;?@[\\]^_`{|}~");
			TOS=strlen(str);
			for (i=1;i<=TOS;i++)
				ret[i]=str[i-1];
			type=STRING;
			break;
		}
		case 35: ret[++TOS]=properInv; break;
		case 36:
			i=1; 
			TOS=strlen(properInvStr); 
			for (i=1;i<=TOS;i++)
				ret[i]=properInvStr[i-1];
			type=STRING;
			break;
		case 37: ret[++TOS]=iterations; break;
		case 38: ret[++TOS]=Winv; break;
		case 39: ret[++TOS]=memStatus(); break;
		case 40: ret[++TOS]=selfReached; break;
		case 46: ret[++TOS]=maxDec; break;
		case 48: ret[++TOS]=decCount; break;
		case 49: ret[++TOS]=progCount; break;
		case 50: actOnSuppressMessage=FALSE; 
			 avoidPrintResult=TRUE;
			 break;
		case 51: actOnSuppressMessage=TRUE; 
			 avoidPrintResult=TRUE;
			 break;
		/* Note: this command is disabled out of programs */
		case 60: reset(backTOS);
			 avoidPrintResult=TRUE;
			 break;
		case 99: isExtProgram=TRUE;
			 END(0);
			 break;
		default:
			perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
			return;
	}

	if (TOS==1) instScalar(res,ret[1]);
	else instVec(res,type,TOS,ret);	
}


/* typeconv()
 * convert a string to number and viceversa */
int typeconv(TDeclare *res, TDeclare val) {
	if (val.type==STRING && val.rank<=VECTOR) {
		int i;
		char num[COMPSTR], *n=num;
		if (val.rank==SCALAR) instScalar(res,getArrayVal(val,1,1)-'0');
		else if (val.rank==VECTOR) {
			for (i=1;i<=val.col;i++) 
				*n++=getArrayVal(val,1,i);
			*n='\0';
			instScalar(res,getNum(num,NULL));
		}
	}
	else if (val.type==NUMERIC && val.rank<VECTOR) {
	  	int i;
	  	char *num=NULL;
		double vec[COMPSTR];
		printArray(&num,val);
		for (i=0;i<strlen(num);i++) 
			vec[i+1]=num[i];
		instVec(res,STRING,strlen(num),vec);
		free(num);
	}
	else return FALSE;
	return TRUE;
}


/* inspect()
 * print status of variable val
 * System function for the )? directive */
void inspect(FILE *fs, TDeclare val, int pos) {
	char em[COMPSTR];
	if (val.name[0]) fprintf(fs,"Name: %s\n",val.name);
	else fprintf(fs,"No name\n");
	if (val.row==1 && !val.col) strncpy_(em,"EMPTY ",COMPSTR);
	else strncpy_(em,VOIDS,COMPSTR);
	fprintf(fs,"Pos    : %d\n",pos);
	fprintf(fs,"Rank: %s%s\n",em,ranks[val.rank+1]);
	fprintf(fs,"Type: %s\n",types[val.type/100]);
	fprintf(fs,"Rows   : %d\n",val.row);
	fprintf(fs,"Columns: %d\n",val.col);
	fprintf(fs,"Size   : %d\n",val.size);
}


/* listWKS()
 * open the current directory and list all files that have the given
 * extension 'ext' */
void listWKS(char *ext) {
	DIR* dirFile=opendir("./");
	int count=0,myWidth=0;
	checkStop;

	/* determine output width */
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;
	if (Wwidth) myWidth=Wwidth;
	else myWidth=sysWidth;
	if (dirFile) {
		struct dirent* hFile;
		char name[NAMESTR];
		char test[COMPSTR];
		errno=0;
		while ((hFile=readdir(dirFile)) != NULL) {
			if (!strcmp(hFile->d_name, ".")) continue;
			if (!strcmp(hFile->d_name, "..")) continue;
			if (hFile->d_name[0] == '.') continue;
			if (!strncasecmp_(hFile->d_name+strlen(hFile->d_name)-4,ext,(int)strlen(ext))) {
				strncpy(test,hFile->d_name,COMPSTR);
				*(test+strlen(test)-(int)strlen(ext))='\0';
				strncpy_(name,test,NAMESTR);
				if (count+18>=myWidth) {
					emit(1,"\n");
					count=0;
				}
				emit(1,"%-16s  ",name);
				count+=18;
			}
		} 
		emit(1,"\n");
		closedir(dirFile);
	}
}


/* proginspect()
 * print status of program val
 * System function for the )? directive */
void proginspect(FILE *fs, TProg val, int pos) {
	if (val.name[0]) fprintf(fs,"Name          : %s\n",val.name);
	else fprintf(fs,"No name\n");
	fprintf(fs,"Pos           : %d\n",pos);
	fprintf(fs,"State         : %s\n",val.isMonadic?(val.isMonadic<0?"dyadic":"monadic"):"standalone");
	fprintf(fs,"Last start    : %d\n",val.startCount);
	fprintf(fs,"Final line    : %d\n",val.endCore);
	fprintf(fs,"Return var.   : %s\n",val.arg[0]?val.arg:"none.");
	fprintf(fs,"Left argument : %s\n",val.left[0]?val.left:"none.");
	fprintf(fs,"Right argument: %s\n",val.rights[0]?val.rights:"none.");
	fprintf(fs,"Local vars    : %s\n",val.locals[0]?val.locals:"none.");
	if (val.labelTOS) {
		fprintf(fs,"Labels [%d]:\n",val.labelTOS);
		int i;
		for (i=1;i<=val.labelTOS;i++)
			fprintf(fs,"   %s [%d]\n",val.label[i],val.ln[i]);
	}
	else fprintf(fs,"Labels [%d]    : none.\n",val.labelTOS);
}


/* buildHeader()
 * given a specific existing program, build the main header for 
 * )EXPORT or )LIST */
void buildHeader(int ns, char *header) {
	strncpy_(header,VOIDS,COMPSTR);
	if (pn[ns].arg[0]) {
		strncat_(header,pn[ns].arg,COMPSTR);
		strncat_(header,"<-",COMPSTR);
	}
	if (pn[ns].left[0]) {
		strncat_(header,pn[ns].left,COMPSTR);
		strncat_(header," ",COMPSTR);
	}
	strncat_(header,pn[ns].name,COMPSTR);
	if (pn[ns].rights[0]) {
		strncat_(header," ",COMPSTR);
		strncat_(header,pn[ns].rights,COMPSTR);
	}
	if (pn[ns].locals[0]) {
		strncat_(header,";",COMPSTR);
		strncat_(header,pn[ns].locals,COMPSTR);
	}
}


/* do_list()
 * perform the )LIST and \/[|_|] statements
 * list program in ns, from 'from' to 'to'
 * if printHT is TRUE, print also the header and footer 
 * otherwise print only the program lines */
void do_list(FILE *fs, int ns, int from, int to, int printHT, int printNUM) {
	int i, offset=4;
	char header[COMPSTR], spaces[COMPSTR];
	checkStop;

	/* build complex header Z<-X NAME Y */
	buildHeader(ns,header);
	if (printHT) {
		makeSpaces(spaces,offset);
		fprintf(fs, "%s\\/ %s\n",spaces,header);
		doScript(FS,1,"%s\\/ %s\n",spaces,header);
	}
	/* list lines */
	for (i=from;i<=to;i++) {
		int j;
		char nums[COMPSTR];
		if (!pn[ns].m[i][0] && !pn[ns].hasLabel) continue;
		for (j=1;j<=pn[ns].labelTOS;j++) { 
			if (pn[ns].ln[j]==i) break;
		}
		snprintf(nums,COMPSTR,"%G",pn[ns].data[i]);
		if (printNUM) {
			if (strlen(nums)<=3) makeSpaces(spaces,3-strlen(nums)+1);
			else makeSpaces(spaces,1);
			fprintf(fs,"[%s]%s",nums,spaces);
			doScript(FS,1,"[%s]%s",nums,spaces);
		}
		fprintf(fs,"%s\n",pn[ns].m[i]);
		doScript(FS,1,"%s\n",pn[ns].m[i]);
	}
	if (printHT) {
		makeSpaces(spaces,offset);
		fprintf(fs,"%s\\/\n",spaces);
		doScript(FS,1,"%s\\/\n",spaces);
	}
} // end of do_list()


/******************************************
 *           SYSTEM INTEFACE              *
 ******************************************/
/* discharge() 
 * frees execution-program stacks */
void discharge(void) {
	int i=backTOS;
	while (i>0) {
		decCount=backStore[i];
		backStore[i]=0;
		backNumber[i]=0;
		backCode[i]=0;
		isResAssign[i]=FALSE;
		resVar[i]=0;
		free_(&backLeft[i]);
		free_(&backRights[i]);
		resVar[i]=0;
		i--;
	}
	backTOS=0;
}


/* reset()
 * reset program execution 
 * l is the level of the functions that must be removed
 * (backTOS mainly) 
 * if called with l=0 it simply resets the flags*/
void reset(int l) {
	discharge();
	noCall=FALSE;
	reStart=0;
	backTOS=0;
	isError=FALSE;
	isProgram=FALSE;
	isInterrupt=FALSE;
	lastProgram=0;
	avoidPrintResult=FALSE;
}


/* dimCurrentWorspace()
 * calculates the dimension of the workspace (used variables and
 * programs) to estimate the file dimension for the workspace */
int dimCurrentWorkspace(void) {
	int i,j;
	int res=0;
	/* calculate dimension of variables */
	for (i=1;i<=decCount;i++) {
		res+=sizeof(TDeclare);
		res+=vn[i].size;
	}
	/* calculate dimension of programs */
	for (i=1;i<=progCount;i++) {
		res+=(sizeof(TProg)-256*256-16*256);
		for (j=1;j<=pn[i].endCore;j++) {
			res+=strlen(pn[i].m[j]);
		}
		for (j=1;j<=pn[i].labelTOS;j++) {
			res+=strlen(pn[i].label[j]);
		}
	}
	/* return dimension as integer */
	return res;
}


/* eraseCurrentWorkspace()
 * perform the )CLEAR system command */
void eraseCurrentWorkspace(void) {
	int i,j;
	gettimeofday(&tv, NULL);
	/* erase all variables */
	for (i=decCount;i>=1;i--) {
		strncpy_(vn[i].name,VOIDS,NAMESTR);
		vn[i].rank=vn[i].type=0;
		vn[i].row=vn[i].col=0;
		vn[i].size=1;
		free_(&vn[i]);
	}
	decCount=0;
	/* erase all programs */
	for (i=progCount;i>=1;i--) {
		strncpy_(pn[i].name,VOIDS,NAMESTR);
		for (j=1;j<=pn[i].endCore;j++)
			strncpy_(pn[i].m[j],VOIDS,COMPSTR);
		for (j=1;j<=pn[i].labelTOS;j++) {
			strncpy_(pn[i].label[j],VOIDS,COMPSTR);
	       		pn[i].ln[j]=0;
			pn[i].data[j]=0.0;
		}
		pn[i].isMonadic=pn[i].startCount=0;
		pn[i].endCore=pn[i].argCount=pn[i].leftNum=0;
		pn[i].rightNum=pn[i].labelTOS=0;
		strncpy_(pn[i].arg,VOIDS,NAMESTR);
		strncpy_(pn[i].left,VOIDS,NAMESTR);
		strncpy_(pn[i].rights,VOIDS,NAMESTR);
		strncpy_(pn[i].locals,VOIDS,NAMESTR);
	}
	/* reset flags state */
	strncpy_(currentWorkspaceName,VOIDS,NAMESTR);
	strncpy_(resName,VOIDS,NAMESTR);
	Wchange=FALSE;
	Wcomp=0;
	Wdigit=0;
	Wfuzz=0;
	Wseed=0;
	Wwidth=0;
	avoidPrintResult=FALSE;
	backTOS=0;
	beginMS=0;
	beginS=0.0;
	endMS=0;
	endS=0.0;
	fuzzValue=0.0;
	indexOrigin=1;
	isClean=FALSE;
	isDebug=FALSE;
	isDeleteScriptFile=FALSE;
	isError=FALSE;
	isExp=0;
	isExtProgram=FALSE;
	isExtTracing=FALSE;
	isExtraSpace=FALSE;
	isInterrupt=FALSE;
	isProgram=FALSE;
	isScript=FALSE;
	isSuspStop=FALSE;
	isTiming=FALSE;
	lastProgram=0;
	noCall=FALSE;
	progCount=0;
	progbeginS=0.0;
	reStart=0;
	recursionLimit=0;
	totalTime=0.0;
	wasLoadWorkspaceOK=TRUE;
	/* restart timing */
	beginS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
}


/* setupFileName()
 * create a file name from the filename of
 * the current program; the name is:
 * - a dot
 * - the program name (without extension)
 * - the extension '.dat' */
char *setupFileName(char *name) {
	char temp[COMPSTR], *t;
	strncpy_(temp,name,COMPSTR);
	t=temp+strlen(temp)-1;
	while (t>temp && *t!='.') t--;
	if (t>temp) *t='\0';
	strncpy_(freezefile,temp,COMPSTR);
	strncat_(freezefile,".wks",COMPSTR);
	return MYPAD=freezefile;
}


/* loadVar()
 * specialized function used by loadWorkspace to load data of a variable */
void loadVar(FILE *fd, int k) {
	char temp[COMPSTR];
	int i,j,rank,type,row,col,size;
	double val;
	/* for each variables structure */
	fgets_(temp,COMPSTR,fd);
	rank=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	type=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	row=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	col=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	size=strtol(temp,NULL,10);
	vn[k].rank=rank;
	vn[k].type=type;
	vn[k].row=row;
	vn[k].col=col;
	vn[k].size=size;
	dimArray(&vn[k],size);
	for (i=1;i<=row;i++) {
		for (j=1;j<=col;j++) {
			fgets_(temp,COMPSTR,fd);
			val=strtod(temp,NULL);
			setArrayVal(vn[k],i,j,val);	
		}
	}
}	


/* loadProg()
 * specialized function used by loadWorkspace to load data of a program */
void loadProg(FILE *fd, int k) {
	int j;
	char temp[COMPSTR];
	fgets_(temp,COMPSTR,fd);
	pn[k].endCore=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	pn[k].labelTOS=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	pn[k].isMonadic=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	pn[k].startCount=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	pn[k].argCount=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	pn[k].leftNum=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	pn[k].rightNum=strtol(temp,NULL,10);
	fgets_(pn[k].arg,NAMESTR,fd);
	fgets_(pn[k].left,NAMESTR,fd);
	fgets_(pn[k].rights,NAMESTR,fd);
	fgets_(pn[k].locals,COMPSTR,fd);
	for (j=1;j<=pn[k].endCore;j++) {
		fgets_(pn[k].m[j],COMPSTR,fd);
		fgets_(temp,COMPSTR,fd);
		pn[k].data[j]=strtod(temp,NULL);
	}
	for (j=1;j<=pn[k].labelTOS;j++) {
		fgets_(pn[k].label[j],NAMESTR,fd);
		fgets_(temp,COMPSTR,fd);
		pn[k].ln[j]=strtol(temp,NULL,10);
	}
}


/* loadWorkspace()
 * execute )LOAD 
 * 'name' contains the name (no extension) of the workspace
 * 'response', if not used implicitly, will contain the exit answer */
void loadWorkspace(char *name, char *response, int isDesc) {
	int i,j,k, decCo, progCo, doResp=TRUE;
	FILE *fd;
	char freezefile[COMPSTR], temp[COMPSTR+1];

	/* open file */
	if (!strcmp(response,defaultContinueName)) {
		strncpy_(freezefile,defaultContinueName,COMPSTR);
		doResp=FALSE;
	}
	else strncpy_(freezefile,setupFileName(name),COMPSTR);
	fd=fopen(freezefile,"r");
	if (!fd) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," NOT FOUND",COMPSTR);
		wasLoadWorkspaceOK=FALSE;
		return;
	}

	/* erase current workspace */
	eraseCurrentWorkspace(); // decCount is set to zero

	/* load and ignore dimension */
	fgets_(temp,COMPSTR,fd);

	/* check if a number or whatever */
	if (!isdigit(temp[0])) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," NOT A WORKSPACE",COMPSTR);
		fclose(fd);
		wasLoadWorkspaceOK=FALSE;
		return;
	}

	/* load variables counter */
	fgets_(temp,COMPSTR,fd);
	decCo=strtol(temp,NULL,10);
	/* load programs counter */
	fgets_(temp,COMPSTR,fd);
	progCo=strtol(temp,NULL,10);
	/* load workspace name */
	fgets_(currentWorkspaceName,NAMESTR,fd);
	/* load starting moment */
	fgets_(temp,COMPSTR,fd);
	totalTime=strtod(temp,NULL);

	/* load checkpoint #1 */
	fgets_(temp,COMPSTR,fd);
	if (strcmp(temp,"##1")) {
		if (doResp) {
			strncpy_(response,name,COMPSTR);
			strncat_(response," NOT LOADED",COMPSTR);
		}
		fclose(fd);
		wasLoadWorkspaceOK=FALSE;
		return;
	}

	/* load variables data */
	for (k=1;k<=decCo;k++) {
		fgets_(temp,COMPSTR,fd);
		strncpy_(vn[k].name,temp+2,NAMESTR);
		loadVar(fd,k);
	}
	decCount=decCo;

	/* load checkpoint #2 */
	fgets_(temp,COMPSTR,fd);
	if (strcmp(temp,"##2")) {
		if (doResp) {
			strncpy_(response,name,COMPSTR);
			strncat_(response," NOT LOADED",COMPSTR);
		}
		fclose(fd);
		wasLoadWorkspaceOK=FALSE;
		return;
	}

	/* load programs data */
	for (k=1;k<=progCo;k++) {
		fgets_(temp,COMPSTR,fd);
		strncpy_(pn[k].name,temp+2,NAMESTR);
		loadProg(fd,k);
	}
	progCount=progCo;
	
	/* load checkpoint #3 */
	fgets_(temp,COMPSTR,fd);
	if (strcmp(temp,"##3")) {
		if (doResp) {
			strncpy_(response,name,COMPSTR);
			strncat_(response," NOT LOADED",COMPSTR);
		}
		fclose(fd);
		wasLoadWorkspaceOK=FALSE;
		return;
	}

	/* load workspace data */
	fgets_(temp,COMPSTR,fd);
	Wdigit=strtol(temp,NULL,10);
	fgets_(numformat,COMPSTR,fd);
	fgets_(mnumformat,COMPSTR,fd);
	fgets_(temp,COMPSTR,fd);
	Wwidth=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	Wseed=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	Wchange=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	Wfuzz=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	fuzzValue=strtod(temp,NULL);
	fgets_(temp,COMPSTR,fd);
	Wcomp=strtod(temp,NULL);
	fgets_(temp,COMPSTR,fd);
	Wdiv=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	Winv=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	indexOrigin=strtol(temp,NULL,10);
	fgets_(temp,COMPSTR,fd);
	isExp=strtol(temp,NULL,10);
	fgets_(filename,COMPSTR,fd);
	/* load trace data */
	fgets_(traceName,NAMESTR,fd);
	if (isTracing) {
		fgets_(temp,COMPSTR,fd);
		traceV.rank=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		traceV.type=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		traceV.row=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		traceV.col=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		traceV.size=strtol(temp,NULL,10);
		dimArray(&traceV,traceV.size);
		for (i=1;i<=traceV.row;i++) {
			for (j=1;j<=traceV.col;j++) {
				fgets_(temp,COMPSTR,fd);
				setArrayVal(traceV,i,j,strtod(temp,NULL));
			}
		}
	}
	/* load stop data */
	fgets_(temp,COMPSTR,fd);
	isStopping=strtol(temp,NULL,10);
	fgets_(stopName,NAMESTR,fd);
	if (isTracing) {
		fgets_(temp,COMPSTR,fd);
		stopV.rank=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		stopV.type=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		stopV.row=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		stopV.col=strtol(temp,NULL,10);
		fgets_(temp,COMPSTR,fd);
		stopV.size=strtol(temp,NULL,10);
		dimArray(&stopV,stopV.size);
		for (i=1;i<=stopV.row;i++) {
			for (j=1;j<=stopV.col;j++) {
				fgets_(temp,COMPSTR,fd);
				setArrayVal(stopV,i,j,strtod(temp,NULL));
			}
		}
	}

	/* load checkpoint #4 */
	fgets_(temp,COMPSTR,fd);
	if (strcmp(temp,"##4")) {
		if (doResp) {
			strncpy_(response,name,COMPSTR);
			strncat_(response," NOT LOADED",COMPSTR);
		}
		fclose(fd);
		wasLoadWorkspaceOK=FALSE;
		return;
	}

	/* if other text is found after the checkpoint 4,
	 * it is the )DESCRIBE text */
	if (isDesc) {
		int space=COMPSTR;
		if (describe) free(describe);
		describe=malloc(space);
		*describe='\0';
		if (!describe) {
			strncat_(response," DESCRIPTION ERROR.",COMPSTR);
			return;
		}
		while (fgets_(temp,COMPSTR,fd)) {
			emit(1,"%s\n",temp);
			if (strlen(describe)+strlen(temp)+1>space) {
				space*=2;
				describe=realloc(describe,space);
			}
			strncat_(describe,temp,space);
			strncat_(describe,"\n",space);
		}
	}

	/* regular end */
	fclose(fd);
	if (doResp) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," LOADED",COMPSTR);
	}
}


/* saveWorkspace()
 * execute )SAVE 
 * 'name' contains the name (no extension) of the workspace
 * 'response', if not used implicitly, will contain the exit answer */
void saveWorkspace(char *name, char *response, int isDesc, int isApp) {
	int k,i,j, doResp=TRUE, pC=0, dC=0;
	FILE *fd;
	char freezefile[COMPSTR];
	double offS=0;
	/* open file */
	if (!strcmp(response,defaultContinueName)) {
		strncpy_(freezefile,defaultContinueName,COMPSTR);
		doResp=FALSE;
	}
	else strncpy_(freezefile,setupFileName(name),COMPSTR);
	fd=fopen(freezefile,"w");
	if (!fd) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," NOT FOUND",COMPSTR);
		return;
	}
	dC=decCount;
	for (i=1;i<=decCount;i++)
		if (!vn[i].name[0]) dC--;
	pC=progCount;
	for (i=1;i<=progCount;i++)
		if (!pn[i].name[0]) pC--;
	/* save dimensions (for )LIB) */
	fprintf(fd,"%d\n",dimCurrentWorkspace());
	/* save variables counter */
	fprintf(fd,"%d\n",dC);
	/* save programs counter */
	fprintf(fd,"%d\n",pC);
	/* save workspace name */
	fprintf(fd,"%s\n",currentWorkspaceName);
	/* save execution time */
	gettimeofday(&tv, NULL);
	offS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
	totalTime+=offS-beginS;
	fprintf(fd,"%.17f\n",totalTime);

	/* save checkpoint #1 */
	fprintf(fd,"%s\n","##1");

	/* save variables data */
	for (k=1;k<=decCount;k++) {
		char name[COMPSTR];
		if (!vn[k].name[0]) continue;
		strncpy_(name,"@#",COMPSTR);
		strncat_(name,vn[k].name,COMPSTR);
		fprintf(fd,"%s\n",name);
		fprintf(fd,"%d\n",vn[k].rank);
		fprintf(fd,"%d\n",vn[k].type);
		fprintf(fd,"%d\n",vn[k].row);
		fprintf(fd,"%d\n",vn[k].col);
		fprintf(fd,"%d\n",vn[k].size);
		for (i=1;i<=vn[k].row;i++) {
			for (j=1;j<=vn[k].col;j++) {
				fprintf(fd,"%0.17f\n",getArrayVal(vn[k],i,j));
			}
		}
	}

	/* save checkpoint #2 */
	fprintf(fd,"%s\n","##2");

	/* save programs data */
	for (k=1;k<=progCount;k++) {
		char name[COMPSTR];
		if (!pn[k].name[0]) continue;
		strncpy_(name,"$#",COMPSTR);
		strncat_(name,pn[k].name,COMPSTR);
		fprintf(fd,"%s\n",name);
		fprintf(fd,"%d\n",pn[k].endCore);
		fprintf(fd,"%d\n",pn[k].labelTOS);
		fprintf(fd,"%d\n",pn[k].isMonadic);
		fprintf(fd,"%d\n",pn[k].startCount);
		fprintf(fd,"%d\n",pn[k].argCount);
		fprintf(fd,"%d\n",pn[k].leftNum);
		fprintf(fd,"%d\n",pn[k].rightNum);
		fprintf(fd,"%s\n",pn[k].arg);
		fprintf(fd,"%s\n",pn[k].left);
		fprintf(fd,"%s\n",pn[k].rights);
		fprintf(fd,"%s\n",pn[k].locals);
		for (j=1;j<=pn[k].endCore;j++) {
			fprintf(fd,"%s\n",pn[k].m[j]);
			fprintf(fd,"%.17f\n",pn[k].data[j]);
		}
		for (j=1;j<=pn[k].labelTOS;j++) {
			fprintf(fd,"%s\n",pn[k].label[j]);
			fprintf(fd,"%d\n",pn[k].ln[j]);
		}
	}

	/* save checkpoint #3 */
	fprintf(fd,"%s\n","##3");

	/* save workspace data */
	fprintf(fd,"%d\n",Wdigit);
	fprintf(fd,"%s\n",numformat);
	fprintf(fd,"%s\n",mnumformat);
	fprintf(fd,"%d\n",Wwidth);
	fprintf(fd,"%d\n",Wseed);
	fprintf(fd,"%d\n",Wchange);
	fprintf(fd,"%d\n",Wfuzz);
	fprintf(fd,"%.17f\n",fuzzValue);
	fprintf(fd,"%.17f\n",Wcomp);
	fprintf(fd,"%d\n",Wdiv);
	fprintf(fd,"%d\n",Winv);
	fprintf(fd,"%d\n",indexOrigin);
	fprintf(fd,"%d\n",isExp);
	fprintf(fd,"%s\n",filename);
	/* save trace data */
	fprintf(fd,"%s\n",traceName);
	if (isTracing) {
		fprintf(fd,"%d\n",traceV.rank);
		fprintf(fd,"%d\n",traceV.type);
		fprintf(fd,"%d\n",traceV.row);
		fprintf(fd,"%d\n",traceV.col);
		fprintf(fd,"%d\n",traceV.size);
		for (i=1;i<=traceV.row;i++) {
			for (j=1;j<=traceV.col;j++) {
				fprintf(fd,"%0.17f\n",getArrayVal(traceV,i,j));
			}
		}
	}
	/* save stop data */
	fprintf(fd,"%d\n",isStopping);
	fprintf(fd,"%s\n",stopName);
	if (isTracing) {
		fprintf(fd,"%d\n",stopV.rank);
		fprintf(fd,"%d\n",stopV.type);
		fprintf(fd,"%d\n",stopV.row);
		fprintf(fd,"%d\n",stopV.col);
		fprintf(fd,"%d\n",stopV.size);
		for (i=1;i<=stopV.row;i++) {
			for (j=1;j<=stopV.col;j++) {
				fprintf(fd,"%0.17f\n",getArrayVal(stopV,i,j));
			}
		}
	}

	/* save checkpoint #4 */
	fprintf(fd,"%s\n","##4");

	/* ask for describing info */
	if (isDesc) {
		char *line=NULL;
		int space=COMPSTR;
		describe=malloc(space);
		if (!isApp) *describe='\0';
		do {
			line=readline(">");
			while (strlen(describe)+strlen(line)+1>space) {
				char prev[space];
				strncpy_(prev,describe,space);
				space*=2;
				describe=realloc(describe,space+1);
				if (!describe) {
					emit(1,"DESCRIPTION ERROR.\n");
					return;	
				}
				strncpy_(describe,prev,space);
			}
			strncat_(describe,line,space);
			fprintf(fd,"%s\n",line);
			strncat_(describe,"\n",space);
		} while (*line);
		free(line);
		if (describe) free(describe);
	}

	/* regular end */
	fclose(fd);
	if (doResp) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," SAVED",COMPSTR);
	}
}


/* dropWorkspace()
 * execute )DROP 
 * 'name' contains the name (no extension) of the workspace
 * 'response', if not used implicitly, will contain the exit answer */
void dropWorkspace(char *name, char *response) {
	char freezefile[COMPSTR];
	strncpy_(freezefile,setupFileName(name),COMPSTR);
	if (remove(freezefile)) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," NOT DROPPED",COMPSTR);
	}
	else {
		strncpy_(response,name,COMPSTR);
		strncat_(response," DROPPED",COMPSTR);
	}
}


/* nextVar()
 * checks if name is the name of an existing variable
 * protected serves to return decCount+1 to protect any
 * accidental variable with the same name
 * used by copyWorkspace() */
int nextVar(char *name, int protected) {
    int i=decCount;
    if (protected) return decCount+1;
    while (i>0) {
        if (!strcmp(name,vn[i].name))
            return i;
        i--;
    }
    return decCount+1;
}


/* nextProg()
 * checks if name is the name of an existing program
 * protected serves to return progCount+1 to protect any
 * accidental program with the same name
 * used by copyWorkspace() */
int nextProg(char *name, int protected) {
    int i=progCount;
    if (protected) return progCount+1;
    while (i>=0) {
        if (!strcmp(name,pn[i].name))
            return i;
        i--;
    }
    return progCount+1;
}


/* copyWorkspace()
 * copy the entire workspace or some objects only
 * if doProtected is FALSE, execute )COPY
 * or else if doProtected is TRUE, execute )PCOPY 
 * )COPY WSID
 * )COPY WSID NAME[S] */
void copyWorkspace(char *name, char *names, char *response, int protected) {
	FILE *fd;
	int done=FALSE, ns=0, np=0;
	char B[COMPSTR];
	char freezefile[COMPSTR];
	strncpy_(response,VOIDS,COMPSTR);
	/* open file */
	if (!strcmp(response,defaultContinueName)) {
		strncpy_(freezefile,defaultContinueName,COMPSTR);
	}
	else strncpy_(freezefile,setupFileName(name),COMPSTR);
	fd=fopen(freezefile,"r");
	if (!fd) {
		strncpy_(response,name,COMPSTR);
		strncat_(response," NOT FOUND",COMPSTR);
		return;
	}
	/* copy single objects */
	if (*names) {
		char output[COMPSTR];
		strncpy_(output,VOIDS,COMPSTR);
		while (*names) {
			char kname[NAMESTR], *k;
			int c;
			/* get next item name in kname */
			while (isblank(*names)) names++;
			k=kname;
			c=0;
			if (isupper(*names)) {
				while (*names && (isupper(*names) || (isdigit(*names))) && c<NAMESTR) 
					*k++=*names++, c++;
				*k='\0';
			}
			else {
				strncpy_(response,"INCORRECT COMMAND",COMPSTR);
				if (fd) fclose(fd);
				return;
			}
			
			/* seek set to start */
			rewind(fd);
			
			/* load lines until @#kname or $#kname is met */
			while (fgets_(B,COMPSTR,fd)) {
				if (!strncmp(B,"@#",2)) {
					if (!strcmp(kname,B+2)) {
						ns=nextVar(kname,protected);
						if (ns>=COMPVAR) {
							perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
							reset(backTOS); // ok 
							return;
						}
						free_(&vn[ns]);
						if (ns>decCount) decCount=ns;
						/* proceed to copy variable in ns */
						strncpy_(vn[ns].name,B+2,NAMESTR);
						loadVar(fd,ns);
						done=TRUE;
					}
				}
				else if (!strncmp(B,"$#",2)) {
					if (!strcmp(kname,B+2)) {
						np=nextProg(kname,protected);
						if (ns>=COMPVAR) {
							perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
							reset(backTOS); // ok
							return;
						}
						emptySlot(np);
						if (np>progCount) progCount=np;
						/* proceed to copy program in np */
						strncpy_(pn[np].name,B+2,NAMESTR);
						loadProg(fd,np);
						done=TRUE;
					}
				}
			}
			if (!done) {
				strncat_(output,kname,COMPSTR);
				strncat_(output," ",COMPSTR);
			}
			done=FALSE;
		}
		if (output[0]) {
			strncpy_(response," NOT FOUND ",COMPSTR);
			strncat_(response,output,COMPSTR);
		}
	}
	/* copy entire workspace into current */
	else {
		/* seek set to start */
		rewind(fd);
		/* load every variable */
		while (fgets_(B,COMPSTR,fd)) {
			if (!strncmp(B,"@#",2)) {
				ns=nextVar(B+2,protected);
				if (ns>decCount) decCount=ns;
				/* proceed to copy variable in ns */
				strncpy_(vn[ns].name,B+2,NAMESTR);
				loadVar(fd,ns);
			}
		}
		/* seek set to start */
		rewind(fd);
		/* load lines until $#kname is met */
		while (fgets_(B,COMPSTR,fd)) {
			if (!strncmp(B,"$#",2)) {
				np=nextProg(B+2,protected);
				if (np>progCount) progCount=np;
				/* proceed to copy program in np */
				strncpy_(pn[np].name,B+2,NAMESTR);
				loadProg(fd,np);
			}
		}
	}
	if (fd) fclose(fd);
}


/******************************************
 *                MATCH                   *
 ******************************************/
/* d_match()
 * confront val1 and val2 and return 1 in case they
 * match and 0 if not  */
void d_match(TDeclare *res, TDeclare val1, TDeclare val2) {
	checkStop;

	if (val1.type==NUMERIC && val2.type==STRING) 
		instScalar(res,0);
	else if (val2.type==NUMERIC && val1.type==STRING) 
		instScalar(res,0);
	else if (val1.rank==SCALAR && val2.rank==SCALAR) {
		if (relation(getArrayVal(val1,1,1),getArrayVal(val2,1,1))!=1)
			instScalar(res,0);
		else instScalar(res,1);
	}
	else if (val1.rank==VECTOR && val2.rank==VECTOR && val1.col==val2.col) {
		int i,isEqual=TRUE;
		for (i=1;i<=val1.col && isEqual;i++) {
			if (relation(getArrayVal(val1,1,i),getArrayVal(val2,1,i))!=1)
				isEqual=FALSE;
		}
		if (isEqual) instScalar(res,1);
		else instScalar(res,0);
	}
	else if (val1.rank==MATRIX && val2.rank==MATRIX && val1.row==val2.row && val1.col==val2.col) {
		int i,j,isEqual=TRUE;
		for (i=1;i<=val1.row && isEqual;i++) {
			for (j=1;j<=val1.col && isEqual;j++)
				if (relation(getArrayVal(val1,i,j),getArrayVal(val2,i,j))!=1)
					isEqual=FALSE;
		}
		if (isEqual) instScalar(res,1);
		else instScalar(res,0);
	}
	else instScalar(res,0);
}

/******************************************
 *              DISPLAY                   *
 ******************************************/
void d_display(TDeclare *res, TDeclare val1, TDeclare val2) {
	char *out, *s;
	int j,ret;
	checkStop;
	
	/* strings cannot be formatted */
	if (val2.type==STRING) {
		perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	/* format */
	ret=f_display(&out,val1,val2);
	if (ret) return;
	s=out;
	if (*s) {
		/* dimension res */
		res->type=STRING;
		res->rank=VECTOR;
		res->row=1;
			res->col=strlen(out);
		res->size=strlen(out)+1;
		dimArray(res,res->size);
		for (j=1;j<=res->col && *s;j++)
		setArrayVal(*res,1,j,*s++);
	}
	if (out) free(out);
}


/* f_display()
 * uses val1 as the formatter to print val2 
 * return 0 if all went well and 1 on error */
int f_display(char **foutput, TDeclare val1, TDeclare val2) {
	int limit=OUTSTR,w,isMat=FALSE,isInt=FALSE;
	int myWidth=0, ftype=0, wi=0, fwi[val2.col+1];
	char format[COMPSTR], cformat[val2.col+1][COMPSTR];
	char *output;
	*foutput=NULL;
	
	/* determine user output formats */
	if (val1.rank==VECTOR && val1.col==2 && val2.rank<=MATRIX) {
		int dec,wid;
		ftype=1;
		if (val2.rank==MATRIX) isMat=TRUE;
		wid=getArrayVal(val1,1,1);
		dec=getArrayVal(val1,1,2);
		if (wid<dec+2) {
			perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
			return 1;
		}
		if (dec<0) snprintf(format,COMPSTR,"%%%d.%dE",wid,abs(dec));
		else snprintf(format,COMPSTR,"%%%d.%dF",wid,dec);
		wi=wid;
	}
	else if (val1.rank==SCALAR && val2.rank<=MATRIX) {
		int dec;
		ftype=1;
		if (val2.rank==MATRIX) isMat=TRUE;
		isInt=TRUE;
		dec=getArrayVal(val1,1,1);
		if (dec<0) {
			perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
			return 1;
		}
		snprintf(format,COMPSTR,"%%%dd",dec);
		wi=dec;
	}
	else if (val1.rank==VECTOR && (val2.rank==MATRIX || val2.rank==VECTOR) && val1.col==2*val2.col) {
		int j,dec,wid;
		ftype=2;
		if (val2.rank==MATRIX) isMat=TRUE;
		/* for each column, use proper set */
		for (j=1;j<=val2.col;j++) {
			wid=getArrayVal(val1,1,2*j-1);
			dec=getArrayVal(val1,1,2*j);
			if (wid<dec+2) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				return 1;
			}
			if (dec<0) snprintf(cformat[j],COMPSTR,"%%%d.%dE",wid,abs(dec));
			else snprintf(cformat[j],COMPSTR,"%%%d.%dF",wid,dec);
			fwi[j]=wid;
		}
	}

	/* determine output width */
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;
	if (Wwidth) myWidth=Wwidth;
	else myWidth=sysWidth;
	globCount=0;

	/* dimension default output */
	output=calloc(limit+1,sizeof(char));
	if (!output) {
		perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
		return 1;
	}
	else strncpy_(output,VOIDS,limit+1);
	/* format output */
	if (val2.row==1 && !val2.col) {
		output[0]='\0';
	}
	else if (!val2.row && val2.col==1) {
		output[0]='\0';
	}
	else if (ftype==1) {
		int i,j;
		double var;
		char tipo[COMPSTR];
		if (isMat) output[0]='\n';
		for (i=1;i<=val2.row;i++) {
			for (j=1;j<=val2.col;j++) {
				var=getArrayVal(val2,i,j);
				if (!isInt) 
					snprintf(tipo,COMPSTR,format,var);
				else 
					snprintf(tipo,COMPSTR,format,(int)var);
				if (strlen(output)+strlen(tipo)>limit) {
					char *back=output;
					limit*=2;
					output=realloc(output,limit+1);
					if (!output) {
						perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
						free(back);
						if (output) free(output);
						return 1;
					}
				}
				if (strlen(tipo)>wi) {
					int k;
					for (k=0;k<wi;k++) tipo[k]='*';
					tipo[wi]='\0';
				}
				else changeMinus(tipo);
				if (globCount+strlen(tipo)>myWidth) {
					strncat(output,"\n      ",limit+1);
					globCount=OFFSET;
				}
				strncat_(output,tipo,limit+1);
				globCount+=strlen(tipo);
			}
			if (val2.rank==MATRIX && i!=val2.row) {
				strncat_(output,"\n",limit+1);
				globCount=0;
			}
		}
	}
	else {
		int i,j;
		double var;
		char tipo[COMPSTR];
		if (isMat) output[0]='\n';
		for (i=1;i<=val2.row;i++) {
			for (j=1;j<=val2.col;j++) {
				var=getArrayVal(val2,i,j);
				snprintf(tipo,COMPSTR,cformat[j],var);
				if (strlen(output)+strlen(tipo)>limit) {
					char *back=output;
					limit*=2;
					output=realloc(output,limit+1);
					if (!output) {
						perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
						free(back);
						if (output) free(output);
						return 1;
					}
				}
				if (strlen(tipo)>fwi[j]) {
					int k;
					for (k=0;k<wi;k++) tipo[k]='*';
					tipo[fwi[j]]='\0';
				}
				else changeMinus(tipo);
				if (globCount+strlen(tipo)>myWidth) {
					strncat(output,"\n      ",limit+1);
					globCount=OFFSET;
				}
				strncat_(output,tipo,limit+1);
				globCount+=strlen(tipo);
			}
			if (val2.rank==MATRIX && i!=val2.row) {
				strncat_(output,"\n",limit+1);
				globCount=0;
			}
		}
	}
	w=strlen(output)+1;
	*(output+w-1)='\0';
	*foutput=calloc(w,sizeof(char));
	strncpy_(*foutput,output,w);
	if (output) free(output);
	return 0;
}


/******************************************
 *                UNIQUE                  *
 ******************************************/
/* m_unique()
 * return in res  vector with only unique values of the item in val */
void m_unique(TDeclare *res, TDeclare val1) {
	int i=0,k=1;
	double curr;
	TDeclare temp, val;
	checkStop;

	setArray(&temp);
	setArray(&val);
	if (val1.rank>VECTOR) {
		int j,w=1;
		double vec[val1.row*val1.col+1];
		for (i=1;i<=val1.row;i++)
			for (j=1;j<=val1.col;j++)
				vec[w++]=getArrayVal(val1,i,j);
		instVec(&val,val1.type,val1.row*val1.col,vec);
	}
	else if (val1.rank==SCALAR) {
		copyArray(&val,val1);
		makeVector(&val);
	}
	else copyArray(&val,val1);
	copyArray(&temp,val);
	for (i=1;i<=temp.col;i++) {
		setArrayVal(temp,1,k++,-DBL_MAX);
	}
	k=1;
	for (i=1;i<=val.col;i++) {
		curr=getArrayVal(val,1,i);
		if (!isin(curr,temp)) {
			setArrayVal(temp,1,k++,curr);
		}
	}
	res->type=val.type;
	res->rank=VECTOR;
	res->row=1;
	res->col=k-1;
	res->size=res->col+1;
	dimArray(res,res->size);
	for (i=1;i<=res->col;i++)
		setArrayVal(*res,1,i,getArrayVal(temp,1,i));
	free_(&temp);
	free_(&val);
}


/* m_unique_mask()
 * The monadic function # is a set function that returns
 * a 1/0 vector containins the ones on the elements that appear 
 * for the first time, and zero for the repeated elements  */
void m_unique_mask(TDeclare *res, TDeclare val) {
	int k,i,j;
	int c=0, d=0, dim=val.row*val.col+1; // uses Wcomp
	double a[dim],b[dim],curr;
	for (i=0;i<dim;i++) a[i]=b[i]=0.0;
	/* extract elements */
	for (k=1;k<=val.row;k++) {
		for (i=1;i<=val.col;i++) {
			curr=getArrayVal(val,k,i);
			for (j=1;j<=d;j++) {
				if (relation(curr,b[j])==1) {
					break;
				}
			}
			if (j>d) {
				b[++d]=curr;
				a[++c]=1.0;
			}
			else {
				a[++c]=0.0;
			}
		}
	}
	if (val.rank==VECTOR) 
		instVec(res,NUMERIC,c,a);
	else {
		int tos=1;
		double mat[val.row+1][val.col+1];
		for (i=1;i<=val.row;i++)
			for (j=1;j<=val.col;j++)
				mat[i][j]=a[tos++];
		instMat(res,NUMERIC,val.row,val.col,mat);
	}
}


/******************************************
 *         GRADE UP AND DOWN              *
 ******************************************/
/* upreorder()
 * simple reorder mechanism, using sorta bubble sorting, 
 * used in m_grade() for grade up */
void upreorder(double res[], double val[], int dim) {
	int i=1;
	while (i<=dim) {
		double curr;
		int j, prev;
		prev=0;
		curr=DBL_MAX;
		j=1;
		while (j<=dim) {
			if (val[j]<curr) {
				curr=val[j];
				prev=j;
			}
			j++;
		}
		if (!prev) break;
		res[i]=prev;
		val[prev]=DBL_MAX;
		i++;
	}
}


/* downreorder()
 * simple reorder mechanism, using sorta bubble sorting, 
 * used in m_grade() for grade down */
void downreorder(double res[], double val[], int dim) {
	int i=1;
	while (i<=dim) {
		double curr;
		int j, prev;
		prev=0;
		curr=-DBL_MAX;
		j=1;
		while (j<=dim) {
			if (val[j]>curr) {
				curr=val[j];
				prev=j;
			}
			j++;
		}
		if (!prev) break;
		res[i]=prev;
		val[prev]=-DBL_MAX;
		i++;
	}
}


/* m_grade()
 * do grade up if type=1, do grade down if type is 2
 * do columns in matrices if dir=2 (default) 
 * do rows in matrices if dir=1 
 * On scalars: do nothing
 * On vectors: grade vectors
 * On matrices: /^\ grades up columns
 * On matrices: /^\[1] grades up rows
 * On matrices: \v/ grades down columns
 * On matrices: \v/[1] grades down rows */
void m_grade(TDeclare *res, TDeclare val, int type, int dir) {
	int i,j,k=1-indexOrigin;
	checkStop;

	if (val.rank==SCALAR) {
		copyArray(res,val);
		return;
	}
	copyArray(res,val); // copy structure
	res->type=NUMERIC;
	/* grade up vector */
	if (val.rank==VECTOR && type==1) {
		double tres[val.col+1], dat[val.col+1];
		for (i=1;i<=val.col;i++) dat[i]=getArrayVal(val,1,i);
		upreorder(tres,dat,val.col);
		for (j=1;j<=val.col;j++) setArrayVal(*res,1,j,tres[j]-k);
	}
	/* grade down vector */
	else if (val.rank==VECTOR && type==2) {
		double tres[val.col+1], dat[val.col+1];
		for (i=1;i<=val.col;i++) dat[i]=getArrayVal(val,1,i);
		downreorder(tres,dat,val.col);
		for (i=1;i<=val.col;i++) setArrayVal(*res,1,i,tres[i]-k);		
	}
	/* grade up matrix columns */
	else if (val.rank==MATRIX && type==1 && dir==2) {
		double tres[val.row+1], dat[val.row+1];
		for (i=1;i<=val.col;i++) {
			for (j=1;j<=val.row;j++) {
				dat[j]=getArrayVal(val,j,i);
			}
			upreorder(tres,dat,val.row);
			for (j=1;j<=val.row;j++) 
				setArrayVal(*res,j,i,tres[j]-k);
		}
	}
	/* grade down matrix columns */
	else if (val.rank==MATRIX && type==2 && dir==2) {
		double tres[val.row+1], dat[val.row+1];
		for (i=1;i<=val.col;i++) {
			for (j=1;j<=val.row;j++) {
				dat[j]=getArrayVal(val,j,i);
			}
			downreorder(tres,dat,val.row);
			for (j=1;j<=val.row;j++) 
				setArrayVal(*res,j,i,tres[j]-k);
		}
	}
	/* grade up matrix rows */
	else if (val.rank==MATRIX && type==1 && dir==1) {
		double tres[val.col+1], dat[val.col+1];
		for (i=1;i<=val.row;i++) {
			for (j=1;j<=val.col;j++) {
				dat[j]=getArrayVal(val,i,j);
			}
			upreorder(tres,dat,val.col);
			for (j=1;j<=val.col;j++) 
				setArrayVal(*res,i,j,tres[j]-k);
		}
	}
	/* grade down matrix rows */
	else if (val.rank==MATRIX && type==2 && dir==1) {
		double tres[val.col+1], dat[val.col+1];
		for (i=1;i<=val.row;i++) {
			for (j=1;j<=val.col;j++) {
				dat[j]=getArrayVal(val,i,j);
			}
			downreorder(tres,dat,val.col);
			for (j=1;j<=val.col;j++) 
				setArrayVal(*res,i,j,tres[j]-k);
		}
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
}


/* d_grade()
 * provide collating sequence for string vectors
 * do dyadic grade up if type=1, do dyadic grade down if type is 2
 * elements of val2 that appear also in val1 (which may be any item) 
 * are graded, the rest is maintained in the same order
 * On scalars: if val2 is in val1, return 1, else empty vector
 * On matrices: RANK error */
void d_grade(TDeclare *res, TDeclare val1, TDeclare val2, int type, int dir) {
	int i,j,k=1-indexOrigin;
	int w1=0, w2=0, d=0, c=0;
	double left[val1.col+1], right[val2.col+1];
	double collect[val2.col+1];
	int ref1[val2.col+1], ref2[val2.col+1];
	checkStop;

	for (i=0;i<=val1.col;i++) {
		left[i]=0.0;
	}
	for (i=0;i<=val2.col;i++) {
		right[i]=collect[i]=0.0;
	}
	/* numeric values are an error */
	if (val1.type!=STRING || val2.type!=STRING) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot))); // DOMAIN
		return;
	}
	/* create left vector without duplicates from val1 (a ravel of val1)*/
	d=0;
	left[++d]=getArrayVal(val1,1,1);
	for (i=2;i<=val1.col;i++) {
		for (j=1;j<=d;j++)
			if (left[j]==getArrayVal(val1,1,i))
				break;
		if (j>d) left[++d]=getArrayVal(val1,1,i);
	}

	/* create right vector from val2 (==vector or == first line of matrix) */
	for (i=1;i<=val2.col;i++) {
		// for matrices, it is the first line...
		right[i]=getArrayVal(val2,1,i);
	}
	
	/* collect each right remaining letter positions in the order in which they appear */
	for (i=1;i<=val2.col;i++) {
		c=TRUE;
		for (j=1;j<=d;j++) {
			if (right[i]==left[j]) {
				c=FALSE;
				break;
			}
		}
		if (c) ref2[++w2]=i;
	}

	/* if type == 1 (grade up) add ordered left + remaining */
	if (type==1) {
		/* check each letter in left that is also in right, in that order and
		 * collect its position from left*/
		for (i=1;i<=d;i++) {
			for (j=1;j<=val2.col;j++) {
				if (left[i]==right[j]) {
					ref1[++w1]=j;
				}
			}
		}

		instVec(res,NUMERIC,val2.col,collect);
		for (i=1;i<=w1;i++) setArrayVal(*res,1,i,ref1[i]-k);
		for (i=1;i<=w2;i++) setArrayVal(*res,1,w1+i,ref2[i]-k);
	}
	/* if type == 2 (grade down) add remaining + left in reverse order */
	if (type==2) {
		/* check each letter in left that is also in right, in that order and
		 * collect its position from right*/
		for (i=1;i<=d;i++) {
			for (j=val2.col;j>=1;j--) {
				if (left[i]==right[j]) {
					ref1[++w1]=j;
				}
			}
		}

		instVec(res,NUMERIC,val2.col,collect);
		for (i=1;i<=w2;i++) setArrayVal(*res,1,i,ref2[i]-k);
		for (i=1;i<=w1;i++) setArrayVal(*res,1,w2+i,ref1[w1-i+1]-k);
	}
}


/******************************************
 *        SUBSET AND EXCLUSION            *
 ******************************************/
/* d_subset()
 * flag function that return 0 or 1 
 * 1 if val1 is a proper subset of val2 
 * 0 if elements of val1 don't belong to val2 
 *   or if the two sets val1 and val2 are identical */
void d_subset(TDeclare *res, TDeclare val1, TDeclare val2) {
	int i,j,ret=TRUE, eq=TRUE;
	double curr;
	TDeclare myval1, myval2;
	checkStop;

	setArray(&myval1);
	setArray(&myval2);
	/* set result data */
	instScalar(res,0);
	
	/* copy */
	copyArray(&myval1,val1);
	copyArray(&myval2,val2);
	makeVector(&myval1);
	makeVector(&myval2);
	for (i=1;i<=myval1.col;i++) {
		curr=getArrayVal(myval1,1,i);
		for (j=1;j<=myval2.col;j++) {
			if (getArrayVal(myval2,1,j)==curr) {
				eq=TRUE;
				break;
			}
			else eq=FALSE;
		}
		if (j>myval2.col) {
			ret=FALSE;
			break;
		}
	}
	/* a proper subset is not the entire set */
	if (eq && myval1.size==myval2.size) ret=FALSE;
	setArrayVal(*res,1,1,ret);
	free_(&myval1);
	free_(&myval2);
}


/* d_exclusion()
 * The dyadic exclusion (~) function is a set function that returns
the elements that are in the first argument of the function, but not
in the second */
void d_exclusion(TDeclare *res, TDeclare val1, TDeclare val2) {
	int i,j,c=1,dim=max(val1.size,val2.size); // uses Wcomp
	double a[dim],curr;
	checkStop;

	if (val1.rank==MATRIX || val2.rank==MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (val1.type!=val2.type) {
		perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* extract elements */
	for (i=1;i<=val1.col;i++) {
		curr=getArrayVal(val1,1,i);
		for (j=1;j<=val2.col;j++) {
			if (curr==getArrayVal(val2,1,j)) {
				break;
			}
		}
		if (j>val2.col) a[c++]=curr;
	}
	/* set result data */
	instVec(res,val1.type,c-1,a);
}


/******************************************
 *           TAKE DROP OPERATORS          *
 ******************************************/
/* d_takeDrop()
 * if dir==1 perform take, otherwise perform drop */
void d_takeDrop(TDeclare *res, TDeclare val1, TDeclare v2, int dir) {
	int i,j, start1, start2;
	TDeclare val2;
	setArray(&val2);
	checkStop;
	copyArray(&val2,v2);

	if (val1.row==1 && val1.col==1 && val2.rank==VECTOR) {
		int pos=getArrayVal(val1,1,1);
		if (abs(pos)<0 || abs(pos)>val2.col) {
			perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
			goto go_take;
		}
		start1=0;
		if (dir==1) {
			if (pos>0) start2=0;
			else start2=val2.col-abs(pos);
			res->row=1;
			res->col=abs(pos);
		}
		else if (dir==2) {
			if (pos>0) start2=val2.col+pos;
			else start2=0;
			res->row=1;
			res->col=val2.col-abs(pos);
		}
	}
	else if (val1.rank==VECTOR && val1.col==2 && val2.rank==MATRIX) {
		int pos1=getArrayVal(val1,1,1);
		int pos2=getArrayVal(val1,1,2);
		if (abs(pos1)<1 || abs(pos1)>val2.col || abs(pos2)<1 || abs(pos2)>val2.col) {	
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto go_take;
		}
		if (dir==1) {
			if (pos1>0) start1=0;
			else start1=val2.row-abs(pos1);
			if (pos2>0) start2=0;
			else start2=val2.col-abs(pos2);
			res->row=abs(pos1);
			res->col=abs(pos2);
		}
		else {
			if (pos1>0) start1=abs(pos1);
			else start1=0;
			if (pos2>0) start2=abs(pos2);
			else start2=0;
			res->row=val2.row-abs(pos1);
			res->col=val2.col-abs(pos2);
		}
	}
	else {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto go_take;
	}
	res->rank=val2.rank;
	res->type=val2.type;
	res->size=res->row*res->col+1;
	dimArray(res,res->size);
	/* copy elements */
	if (res->col>0) for (i=1;i<=res->row;i++) {
		for (j=1;j<=res->col;j++) {
			setArrayVal(*res,i,j,getArrayVal(val2,start1+i,start2+j));
		}
	}
go_take:
	free_(&val2);
}


/******************************************
 *       RANDOM NUMBER OPERATOR           *
 ******************************************/
/* getRandom() 
 * return a random decimal number between 0 and 1 */
double getRandom(void) {
	static double fix=0.3; // variable randSeed part
	static double div=0.1; // variable randDivi part
	double o=0.0;
	
	/* reset parameters in case of )SEED 
	 * Note: Wchange was set in )SEED */
	if (Wchange) {
		randSeed=7139;
		randDivi=Wseed;
		fix=0.3;
		div=0.1;
		Wchange=FALSE;
	}
	/* mechanical randomizing */
	if (Wseed) {
		randDivi%=MAXRAN*4;
	}
	/* automatic randomizing */
	else {
		randDivi=clock()%MAXRAN+1;
	}
	if (randDivi%2) randDivi++;

	/* take fractional part of the division of randSeed by randDivi
	 * (take digits from 3rd to 8th position) */
	o=100.0*randSeed/randDivi;
	o-=(int)o;

	/* update randSeed */
	randSeed=(unsigned int)((o*1E5)+fix);
	if (!randSeed%2) randSeed++;

	/* update variable parts */
	div+=3.0; if (div>499) div=-997;
	fix+=167.0; if (fix>4999) fix=0;

	/* ensure limits are respected */
	if (o<CZERO) return CZERO;
	else if (o>=1.0) return fabs(o-(int)o);
	return o;
}


/* m_random()
 * perform the ? monadic operator 
 * Used also in d_deal */
double m_random(double val) {
	double rand=getRandom();
	int irand=rand*val+1;
	if (val==0.0) return rand;
	return (double)irand;
}


/* d_deal()
 * perform the ? dyadic operator */
void d_deal(TDeclare *res, TDeclare val1, TDeclare val2) {
	int col=getArrayVal(val1,1,1), range=(int)getArrayVal(val2,1,1)%32768;
	int i, r=1, classified[range+1], count=0, k=1-indexOrigin;
	double val;
	checkStop;

	if (val1.rank>SCALAR || val2.rank>SCALAR) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (col>range) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	for (i=0;i<=range;i++) classified[i]=0;
	res->rank=VECTOR;
	res->type=NUMERIC;
	if (col<=0) col=1;
	res->row=1;
	res->col=col;
	res->size=res->col+1;
	dimArray(res,res->size);
	if (isError) return;
	for (i=1; i<=col; i++) {
		val=m_random(range);
		if (!classified[(int)val]) {
			classified[(int)val]=1;
			setArrayVal(*res,1,r++,val-k);
			count++;
		}
		else {
			i--;
			if (isInterrupt) break;
			if (count>=range) break;
		}
	}
}


/******************************************
 *            MEMBERSHIP                  *
 ******************************************/
/* d_membership()
 * execute the membership dyadic operator */
void d_membership(TDeclare *res, TDeclare val1, TDeclare v2) {
	int i,j,k;
	double curr, vc;
	TDeclare val2;
	checkStop;

	setArray(&val2);
	copyArray(&val2,v2);
	if (val2.rank!=VECTOR) makeVector(&val2);
	copyArray(res,val1);
	res->type=NUMERIC;
	for (i=1;i<=val1.row;i++) {
		for (j=1;j<=val1.col;j++) {
			curr=getArrayVal(val1,i,j);
			setArrayVal(*res,i,j,0);
			for (k=1;k<=val2.col;k++) {
				vc=getArrayVal(val2,1,k);
				if (vc==curr) {
					setArrayVal(*res,i,j,1);
					break;
				}
			}
		}
	}
	free_(&val2);
}


/******************************************
 *        MATRIX REVERSAL/TRANSPOSE       *
 ******************************************/
/* d_rotate()
 * perform the rotation operator 
 * if dir=2 rotate colums, if dir=1 rotate rows */
void d_rotate(TDeclare *res, TDeclare val1, TDeclare val2, int dir) {
	checkStop;

	if (val2.rank==VECTOR && val1.col!=1 && val1.row!=1) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (val1.rank==VECTOR && dir==2 && val1.col!=val2.row) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (val1.rank==VECTOR && dir==1 && val1.col!=val2.col) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (val2.rank==VECTOR) {
		int i,pos=0;
		int rota=(int)getArrayVal(val1,1,1);
		copyArray(res,val2);
		for (i=1;i<=val2.col;i++) {
			pos=abs(i-rota+val2.col)%(val2.col);
			if (!pos) pos=val2.col;
			setArrayVal(*res,1,pos,getArrayVal(val2,1,i));
		}
	}
	else if (dir==2 && val2.rank==MATRIX) {
		int i,j, pos=0, rota=0;
		copyArray(res,val2);
		for (i=1;i<=val2.row;i++) {
			rota=(int)getArrayVal(val1,1,i);
			for (j=1;j<=val2.col;j++) {
				pos=abs(j-rota+val2.col)%(val2.col);
				if (!pos) pos=val2.col;
				setArrayVal(*res,i,pos,getArrayVal(val2,i,j));
			}
		}
	}
	else if (dir==1 && val2.rank==MATRIX) {
		int i,j, pos=0, rota=0;
		copyArray(res,val2);
		for (i=1;i<=val2.col;i++) {
			rota=(int)getArrayVal(val1,1,i);
			for (j=1;j<=val2.row;j++) {
				pos=abs(j-rota+val2.row)%(val2.row);
				if (!pos) pos=val2.row;
				setArrayVal(*res,pos,i,getArrayVal(val2,j,i));
			}
		}
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
}


/* m_reversal()
 * perform the o| and o- monadic operators */
void m_reversal(TDeclare *res, TDeclare val, int dir) {
	int i,j;
	checkStop;

	if (val.rank==SCALAR || (val.rank==VECTOR && val.col==1 && val.row==1) ||\
			(val.rank==VECTOR && dir==1)) {
		copyArray(res,val);
	}
	else if (val.rank==VECTOR) {
		copyArray(res,val);
		for (i=1;i<=val.col;i++) {
			setArrayVal(*res,1,val.col-i+1,getArrayVal(val,1,i));
		}
	}
	else if (val.rank==MATRIX && dir==2) {
		copyArray(res,val);
		for (i=1;i<=val.row;i++) {
			for (j=1;j<=val.col;j++) {
				setArrayVal(*res,i,val.col-j+1,getArrayVal(val,i,j));
			}
		}
	}
	else if (val.rank==MATRIX && dir==1) {
		copyArray(res,val);
		for (i=1;i<=val.row;i++) {
			for (j=1;j<=val.col;j++) {
				setArrayVal(*res,val.row-i+1,j,getArrayVal(val,i,j));
			}
		}
	}
}


/* m_transpose()
 * perform the o\ monadic operator */
void m_transpose(TDeclare *res, TDeclare val) {
	int i,j;
	checkStop;

	if (val.rank<VECTOR) {
		copyArray(res,val);
	}
	else {
		int temp;
		copyArray(res,val);
		temp=res->col;
		res->col=res->row;
		res->row=temp;
		if (res->col==1 && res->row==1) res->rank=VECTOR;
		else if (res->row==1) res->rank=VECTOR;
		else if (res->col==1) res->rank=MATRIX;
		else res->rank=MATRIX;
		for (i=1;i<=res->row;i++)
			for (j=1;j<=res->col;j++)
				setArrayVal(*res,i,j,getArrayVal(val,j,i));
	}
}


/* d_gtranspose()
 * perform the generalized dyadic transpose of element of a matrix */
void d_gtranspose(TDeclare *res, TDeclare v1, TDeclare val2) {
	double dir1,dir2;
	TDeclare val1;
	checkStop;

	setArray(&val1);
	copyArray(&val1,v1);
	/* val1 1 must be a vector and have 2 elements */
	if (val1.rank>VECTOR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto g_trans;
	}
	if (val1.col!=2) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto g_trans;
	}
	
	/* generalized transpose */
	dir1=getArrayVal(val1,1,1);
	dir2=getArrayVal(val1,1,2);
	if (dir1==1 && dir2==2) {
		copyArray(res,val2);
	}
	else if (dir1==2 && dir2==1) {
		m_transpose(res,val2);
	}
	else if (dir1==1 && dir2==1) {
		int i, s=(int)min(val2.row,val2.col);
		double mat[s+1];
		for (i=1;i<=s;i++)
			mat[i]=getArrayVal(val2,i,i);
		instVec(res,val2.type,s,mat);
	}
	else if (dir1==2 && dir2==2) {
		int i, s=(int)min(val2.row,val2.col);
		double mat[s+1];
		for (i=1;i<=s;i++)
			mat[i]=getArrayVal(val2,i,val2.col-i+1);
		instVec(res,val2.type,s,mat);
	}
	else {
		perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
	}
g_trans:
	free_(&val1);
}


/******************************************
 *             MATRIX TOOLS               *
 ******************************************/
/* r_square_invert()
 * invert real matrix a into x, returning detValue 
 * service function for set_inv_type() */
void r_square_invert(int n, double x[n+1][n+1], double a[n+1][n+1], double *detValue) {
	int i=0, j=0, k=0, d=2*n+1;
	double ma[n+1][d+1];
	double mul=0.0,piv=0.0;

	/* set determinant base multiplier */
	*detValue=1.0;

	/* create composed matrix AI, with the same rows number of A,
	 * and twice the columns number of A; in the second half lies I */
	for (i=1;i<=n;i++) {
		for(j=1;j<=n;j++) {
			ma[i][j]=a[i][j];
			/* setting I to all zeroes */
			ma[i][j+n+1]=0.0;
		}
	}
	/* set diagonal of I to all ones */
	for (i=1;i<=n;i++) ma[i][i+n+1]=1.0;
	
	/* erase destination matrix */
	for (i=1; i<=n; i++) for (j=1; j<=n; j++) x[i][j]=0.0;
	
	/* Gauss factorization over AI with partial pivoting */
	for (k=1;k<n;k++) {
		piv=ma[k][k];
		if (!piv) {
			double maxx=0;
			int r=k;
			/* k is the row where pivot is zero
			 * now find the row where pivot is max */
			for (i=k+1;i<=n;i++) 
				if (maxx<fabs(ma[i][k])){ 
					maxx=ma[i][k]; 
					r=i; 
				}
			/* matrix is singular if r hasn't changed */
			if (r==k) { 
				/* warning */
				*detValue=0.0; 
				return; 
			}
			/* change place to rows r and k */
			for (i=1;i<=d;i++) {
				maxx=ma[r][i];
				ma[r][i]=ma[k][i];
				ma[k][i]=maxx;
			}
			piv=ma[k][k];
			/* matrix is singular if pivot is still null */
			if (!piv) { 
				/* warning */
				*detValue=0.0; 
				return; 
			}
			/* update determinant sign */
			*detValue*=-1; 
		}
		/* update the rest of the rows */
		for (i=k+1;i<=n;i++) {
			mul=ma[i][k]/piv;
			for (j=k;j<=d;j++) ma[i][j]=ma[i][j]-mul*ma[k][j];
		} 
		
	}

	/* calculate determinant */
	for (i=1;i<=n;i++) *detValue*=ma[i][i];
	
	/* calculate the inverse of A through back-substitution */
	for (i=1;i<=n;i++) {
		x[n][i]=ma[n][i+n+1]/ma[n][n];
		for (j=n-1;j>=0;j--) {
			piv=0;
			for(k=j+1;k<=n;k++) piv+=ma[j][k]*x[k][i];
			x[j][i]=(ma[j][i+n+1]-piv)/ma[j][j];
		}
	}
}


/* isNullRow()
 * check if row this in matrix A of dimensions row x col is
 * null (i.e. is smaller than CZERO */
int isNullRow(int row, int col, double A[row+1][col+1], int this) {
	int res=TRUE;
	int i;
	for (i=1;i<=col;i++)
		if (fabs(A[this][i])>CZERO) res=FALSE;
	return res;
}


/* m_qrd()
 * perform the QR decomposition */
void m_qrd(TDeclare *QM, TDeclare *RM, TDeclare M) {
	int row=M.row, col=M.col;
	int i,j;
       	double A[row+1][col+1], Q[row+1][col+1], R[col+1][col+1];

	/* controls for matrices only */
	if (M.rank!=MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	/* recompose work-matrix A */
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++)
			A[i][j]=getArrayVal(M,i,j);

	/* delegate do_qrd() */
	do_qrd(row,col,A,Q,R);

	/* attribute return values */
	instMat(QM,NUMERIC,row,col,Q);
	instMat(RM,NUMERIC,col,col,R);
}


/* do_qrd()
 * perform the QR decomposition, also known as a QR factorization or QU factorization;
 * this operation decomposes a matrix A into a product A = QR of an orthogonal matrix Q 
 * and an upper triangular matrix R, using the Gram-Schmidt process.
 * See also:
 * https://en.wikipedia.org/wiki/QR_decomposition
 * Q has the same dimensions of A, R is square with the dimensions equal to the
 * columns number of A. Q is orthogonal; this means that Q^-1 = QT 
 * (inverse equals transpose) even in case Q (or A) is not square; 
 * in case of a square matrix A, this also means that Q is invertible.
 * Note: the QR decomposition is always possible, for any matrix.
 * Service function for m_qrd(). */
int do_qrd(int row, int col, double A[row+1][col+1], double Q[row+1][col+1], double R[col+1][col+1]) {
	int i,j,k;
	double num, V[row+1][col+1];

	/* recompose work-matrix V */
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++)
			V[i][j]=A[i][j];
	
	/* erase orthogonal Q */
	for (k=1;k<=row;k++) {
		for (i=1;i<=col;i++)
			Q[k][i]=0.0;
	}

	/* erase upper triangular R */
	for (k=1;k<=col;k++) {
		for (i=1;i<=col;i++)
			R[k][i]=0.0;
	}
	/* Gram-Schimdt iteration */
	i=0;
	while (i<col) {
		i++;
		num=0;
		for (j=1;j<=row;j++)
			num+=V[j][i]*V[j][i];
		num=sqrt(num);
		R[i][i]=num;

		for (j=1;j<=row;j++) {
			Q[j][i]=V[j][i]/R[i][i];
		}
		j=i;
		while (j<col) {
			j++;
			num=0;
			for (k=1;k<=row;k++)
				num+=Q[k][i]*V[k][j];
			R[i][j]=num;
			for (k=1;k<=row;k++)
				V[k][j]=V[k][j]-R[i][j]*Q[k][i];

		}
	}
	
	/* check if line k of R is null then column k of Q is null 
	 * Note: this happens in case of non triangular R, and thus
	 * non orthogonal Q */
	for (i=1;i<=col;i++) {
		for (j=i;j<=col;j++) {
			if (fabs(R[i][j])<IZERO) R[i][j]=0;
			if (isnan(R[i][j])) R[i][j]=0;
		}
	}
	/* check if some rows of R is null, then 
	 * erase the correspondent column of Q */
	for (i=1;i<=col;i++) {
		if (isNullRow(col,col,R,i)) {
			for (j=1;j<=row;j++) Q[j][i]=0;
		}
	}
	return 0;
} // end of do_qrd()


/* checkMatNull()
 * check if mat is null (i.e. all terms are lesser than IZERO
 * in absolute value) */
int checkMatNull(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (relation(fabs(M[i][j]),IZERO)==2)
				return FALSE;
		}
	}
	return TRUE;
}


/* isSubDiagNotNull()
 * check if the items under the sub diagonal are null 
 * Note: che check with 1E-7 was done to include the cumnulating errors */
int isSubDiagNotNull(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=2;i<=n;i++) {
		for(j=1;j<i;j++) {
			if (relation(fabs(M[i][j]),1E-7)==2)
				return TRUE;
		}
	}
	return FALSE;
}


/* isSuperDiagNotNull()
 * check if the items over the super diagonal are null 
 * Note: che check with 1E-7 was done to include the cumnulating errors */
int isSuperDiagNotNull(int n, double M[n+1][n+1]) {
	int i,j;
	for (j=2;j<=n;j++) {
		for(i=1;i<j;i++) {
			if (relation(fabs(M[i][j]),1E-7)==2)
				return TRUE;
		}
	}
	return FALSE;
}


/* diff()
 * calculates the numeric difference between S and T
 * and if negligible in all cases, they are considered equal
 * Note: VZERO is the limit 
 * System function for do_ben() */
int diff(int n, double S[n+1][n+1], double T[n+1][n+1]) {
	double dif=0;
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			dif+=fabs(S[i][j]-T[i][j]);
		}
	}
	if (dif>VZERO) return TRUE;
	return FALSE;	
}


/* isMatDiagonal()
 * check if square matrix M of dimensions nxn is diagonal 
 * Note: here the check is more strict, and uses XZERO */
int isMatDiagonal(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (i!=j && relation(fabs(M[i][j]),XZERO)==2)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatSymmetric()
 * check if matrix M with dimensions nxn is symmetric
 * Note: here the string equality is used. */
int isMatSymmetric(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (i!=j && relation(M[i][j],M[j][i])!=1)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatAntSymmetric()
 * check if matrix M with dimensions nxn is antisymmetric
 * Note: here the string equality is used. */
int isMatAntiSymmetric(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (i!=j && relation(M[i][j],-M[j][i])!=1)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatHypoSymmetric()
 * check if matrix M with dimensions nxn is hyposymmetric
 * Note: here the string equality is used. */
int isMatHypoSymmetric(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (i!=j && M[i][j]==0.0 && M[j][i]!=0.0)
				return FALSE;
			else if (i!=j && M[i][j]==0.0 && M[j][i]==0.0)
				continue;
			else if (i!=j && relation(M[i][j],1.0/M[j][i])!=1)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatLowTri()
 * check if matrix M with dimensions nxn is lower triangular
 * Note: here the string equality is used. */
int isMatLowTri(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=1;i<n;i++) {
		for (j=i+1;j<=n;j++) {
			if (relation(M[i][j],0.0)!=1)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatUpperTri()
 * check if matrix M with dimensions nxn is lower triangular
 * Note: here the string equality is used. */
int isMatUpperTri(int n, double M[n+1][n+1]) {
	int i,j;
	for (i=2;i<=n;i++) {
		for (j=1;j<i;j++) {
			if (relation(M[i][j],0.0)!=1)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatNull()
 * check if matrix M with dimensions mxn is null
 * Note: here the string equality is used. */
int isMatNull(int m, int n, double M[m+1][n+1]) {
	int i,j;
	for (i=1;i<=m;i++) {
		for (j=1;j<=n;j++) {
			if (relation(M[i][j],0-0)!=1)
				return FALSE;
		}
	}
	return TRUE;
}


/* isMatPosDef()
 * check if square matrix M of dimensions nxn is
 * positive definite (that is all items of the Echelon version
 * diagonal are positive) */
int isMatPosDef(int n, double M[n+1][n+1]) {
	double J[n+1][n+1];
	int i;

	do_rref(n,n,M,J,1);
	for (i=1;i<=n;i++) {
		if (relation(J[i][i],0.0)!=2) return FALSE;
	}
	return TRUE;
}


void do_2x2eigen(int n, double M[n+1][n+1], double P[n+1][n+1], double J[n+1][n+1], double S[n+1][n+1]) {
	int i,j;
	double Il[n+1][n+1], Al[n+1][n+1];

	if (fabs(M[1][2]>EZERO) && fabs(M[2][2]>EZERO)) {
		P[1][2]=sqrt(fabs(M[1][2]));
		P[2][2]=sqrt(fabs(M[2][2]));
	}
	else if (fabs(M[1][2]<EZERO)) {
		P[1][2]=0.0;
		P[2][2]=1.0/(M[1][2]+M[2][1]);
	}
	else {
		P[1][2]=1.0/(M[1][2]+M[2][1]);
		P[2][2]=0.0;
	}

	/* build lambda I*/
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (i==j) Il[i][j]=J[i][j];
			else Il[i][j]=0.0;
		}
	}

	/* build A-lambda I */
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			Al[i][j]=M[i][j]-Il[i][j];
		}
	}
	/* treat multiplicity */
	if (J[1][1]==J[2][2]) J[1][2]=1.0;
	
	P[1][1]=Al[1][1]*P[1][2]+Al[1][2]*P[2][2];
	P[2][1]=Al[2][1]*P[1][2]+Al[2][2]*P[2][2];

	isComplexWarning=TRUE;
}


/* m_eigen()
 * perform the eigen decomposition of a square matrix A
 * returning in res the result dependint on dir 
 * if dir==1 return the diagonal matrix J
 * if dir==2 return the eigenvectors matrix P
 * if dir==3 return the upper triangular Schur matrix U
 * if dir==4 return the orthogonal matrix Q
 * if dir==5 return the number of iterations of the QR algorithm */
void m_eigen(TDeclare *res, TDeclare A, int dir) {
	int i,j,n=A.row, iter=0;
	double M[n+1][n+1], P[n+1][n+1], J[n+1][n+1];
	double S[n+1][n+1], T[n+1][n+1];

	/* only for square matrices */
	if (A.row!=A.col) {
		perror_(__LINE__,43,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* copy A in M */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			M[i][j]=getArrayVal(A,i,j);

	do_eigen(n,M,P,J,S,T,&iter);

	/* rationalize P,S,T */
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (fabs(P[i][j])<CZERO) P[i][j]=0.0;
			if (fabs(S[i][j])<CZERO) S[i][j]=0.0;
			if (fabs(T[i][j])<CZERO) T[i][j]=0.0;
		}
	}

	if ((checkMatNull(n,J) || checkMatNull(n,P)) && dir<3) {
		printf("%s\n",error[41]);
		isError=TRUE;
		return;
	}
	
	if (isSubDiagNotNull(n,S) && !isComplexWarning && dir<3) {
		printf("%s\n",error[42]);
		isComplexWarning=TRUE;
	}
	
	if (dir==1) instMat(res,NUMERIC,n,n,J);
	else if (dir==2) instMat(res,NUMERIC,n,n,P);
	else if (dir==3) instMat(res,NUMERIC,n,n,S);
	else if (dir==4) instMat(res,NUMERIC,n,n,T);
	else if (dir==5) instScalar(res,iter);
}


/* do_eigen()
 * workhorse for the solution of eigenvectors and eigenvalues */
void do_eigen(int n, double M[n+1][n+1], double P[n+1][n+1], double J[n+1][n+1], double S[n+1][n+1], double T[n+1][n+1], int *iterations) {
	int i,j,k,count, mult[n+1], isUni=TRUE;
	double B[n+1][n+1], QB[n+1][n+1], RB[n+1][n+1];
	double V[n+1], ZER[n+1], MID[n+1][n+1], ID[n+1][n+1];
	double BI[n+1][n+1], CI[n+1][n+1], MI[n+1][n+1], detVal;
	TDeclare mid, zer, eigen;
	setArray(&mid);
	setArray(&zer);
	setArray(&eigen);
	checkStop;
	
	/* the diagonal case is easily solvable */
	if (isMatDiagonal(n,M)) {
		for (i=1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				if (i==j) J[i][j]=M[i][j];
				else J[i][j]=0.0;
				if (i==j) P[i][j]=1.0;
				else P[i][j]=0.0;
				S[i][j]=J[i][j];
				T[i][j]=P[i][j];
			}
		}
		goto matsort;
	}

	/* QR algorithm setup */
	count=0;
	for (i=1;i<=n;i++) {
		mult[i]=1;
		for (j=1;j<=n;j++) {
			if (i==j) ID[i][j]=T[i][j]=1.0;
			else ID[i][j]=T[i][j]=0.0;
			S[i][j]=M[i][j];
			P[i][j]=0.0;
		}
	}

	/* QR algorithm (finds T and S) */
	do {
		for (i=1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				B[i][j]=S[i][j];
			}
		}
		do_qrd(n,n,B,QB,RB);
		k_mat_mul(n,n,n,S,RB,QB);
		k_mat_mul(n,n,n,T,T,QB);
		count++;
		if (count>10000) break;
	} while (diff(n,S,B) && !isInterrupt);
	*iterations=count;
	checkStop;
	
	/* in case of upper or lower triangular cases,
	 * the eigenvalues are on the diagonal */
	if (!isSubDiagNotNull(n,M) || !isSuperDiagNotNull(n,M)) {
		for (i=1;i<=n;i++)
			V[i]=M[i][i];
	}

	/* extraction of the eigenvalues */
	else for (i=1;i<=n;i++) {
		V[i]=S[i][i];
	}

	/* building J from V */
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (i==j) J[i][j]=V[i];
			else J[i][j]=0.0;
		}
	}

	/* copy T in P */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			P[i][j]=T[i][j];

	/* check if reconstruction is good (only for invertible M) */
	r_square_invert(n,MI,P,&detVal);
	if (detVal!=0.0) {
		k_mat_mul(n,n,n,BI,P,J);
		k_mat_mul(n,n,n,CI,BI,MI);
		if (!diff(n,M,CI)) goto matsort;
	}
	
	/* calculate multiplicity */
	for (i=1;i<n;i++) {
		k=1;
		j=i+1;
		while (relation(V[j],V[i])==1 && j<=n) k++, j++;
		for (j=0;j<k;j++)
			mult[i+j]=k;
		i+=k-1;
	}

	/* set multiplicity flag*/
	for (i=1;i<=n;i++) {
		if (mult[i]>1) isUni=FALSE;
	}

	/* in case of single and distinct eigenvalues, proceed 
	 * with the equation calculus for the eigenvectors */
	if (isUni) { 

		/* set up the zero column */
		for (i=1;i<=n;i++) 
			ZER[i]=VZERO;
		instVec(&zer,NUMERIC,n,ZER);
	
		/* cycle over each distinct eigenvalue */
		for (k=n;k>=1;k--) {
			
			/* setup the equations knowns */
		 	for (i=1;i<=n;i++) {
		 		for (j=1;j<=n;j++) {
		 			MID[i][j]=M[i][j]-V[k]*ID[i][j];
		 		}
		 	}
		 	instMat(&mid,NUMERIC,n,n,MID);
	
			/* proceed solving the equation */
		 	d_matdivision(&eigen,zer,mid);
			
			/* build the k-th vector */
		 	for (j=1;j<=n;j++) 
		 		P[j][k]=getArrayVal(eigen,1,j);
		}
	}
	/* calculation of eigenvectors with multiplicity */
	else {
		/* TODO temporaty fake solution TODO */
		for (i=1;i<=n;i++)
			for (j=1;j<=n;j++)
				P[i][j]=S[i][j];
	}

matsort:
	/* sorting of J and P in descending order using 
	 * the Bubble Sort algorithm */
	for(i=1;i<=n;i++) {
		double curr;
		for(j=1;j<n;j++) {
			if (relation(J[j][j],J[j+1][j+1])==3) {
				curr=J[j][j];
				J[j][j]=J[j+1][j+1];
				J[j+1][j+1]=curr;
				for (k=1;k<=n;k++) {
					curr=P[k][j];
					P[k][j]=P[k][j+1];
					P[k][j+1]=curr;
				}
			}
		}
	}

	/* normalize P*/
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			if (fabs(P[n][i])>IZERO) 
			P[j][i]/=P[n][i];
		}
	}

	/* free memory */
	free_(&eigen);
	free_(&zer);
	free_(&mid);
}


/* do_plu()
 * Perform the PLU decomposition, to factorize a square matrix A 
 * into a lower left triangular matrix L and an upper right 
 * triangular matrix U so that A = PLU; P is the permutation matrix;
 * if A has no null values on the diagonal, P remains equal to I
 * otherwise it records the permutations to rebuild a correct A
 * See also:
 * https://en.wikipedia.org/wiki/LU_decomposition
 * Thanks to John Foster at the Hildebrand Department of 
 * Petroleum and Geosystems Engineering for his illuminating article at
 * https://johnfoster.pge.utexas.edu/numerical-methods-book/LinearAlgebra_LU.html  */
void do_plu(int n, double A[n+1][n+1], double L[n+1][n+1], double U[n+1][n+1], double P[n+1][n+1]) {
	int i,j,k;
	/* initialize L, U and P*/
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			L[i][j]=P[i][j]=0.0;
			U[i][j]=A[i][j];
		}
		L[i][i]=P[i][i]=1.0;
	}
	/* perform the PLU factorization */
	for (i=1;i<=n;i++) {
		/* a null value in the diagonal was found:
		 * swap rows Ui and Uk+1 and the correspondent
		 * Pi and Pk+1 permutation value.
		 * The control upon k is done for avoiding
		 * exchanging illegal rows */
		k=i+1;
		while (U[i][i]==0.0 && k<=n) {
			double temp;
			for (j=1;j<=n;j++) {
				temp=U[i][j];
				U[i][j]=U[k][j];
				U[k][j]=temp;
				temp=P[i][j];
				P[i][j]=P[k][j];
				P[k][j]=temp;
			}
			k++;
		}
	}
	/* perform the LU decomposition 
	 * on the result (swapped) matrix*/
	for (i=1;i<=n;i++) {
		for (j=i+1;j<=n;j++) {
			if (U[j][i]==0 && U[i][i]==0) L[j][i]=1.0;
			else if (U[i][i]==0.0) L[j][i]=0.0;
			else L[j][i]=U[j][i]/U[i][i];
			for (k=1;k<=n;k++) {
				U[j][k]-=L[j][i]*U[i][k];
			}
		}
	}
}


/* m_plu()
 * perform the PLU decomposition of a square matrix A
 * if dir==4 return the lower triangular matrix L
 * if dir==5 return the upper triangual matrix U
 * if dir==6 return the permitation matrix P */
void m_plu(TDeclare *res, TDeclare val, int dir) {
	int i,j,n=val.row;
	double M[n+1][n+1], L[n+1][n+1], U[n+1][n+1], P[n+1][n+1];

	/* Only for square matrices */
	if (val.row!=val.col) {
		perror_(__LINE__,43,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	/* compile M */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			M[i][j]=getArrayVal(val,i,j);

	/* delegate do_plu() */
	do_plu(n,M,L,U,P);
	if (dir==4) instMat(res,NUMERIC,n,n,L);
	else if (dir==5) instMat(res,NUMERIC,n,n,U);
	else instMat(res,NUMERIC,n,n,P);
}


/* do_ldu()
 * Perform the LDU decomposition to factorize a square matrix A
 * into a lower unitary triangular matrix L, an upper unitary triangualr matrix U
 * and a diagonal matrix D so that A = LDU */ 
void do_ldu(int n, double A[n+1][n+1], double L[n+1][n+1], double D[n+1][n+1], double U[n+1][n+1]) {
	int i,j,k;
	double temp;
	/* initialize L, U and D*/
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			L[i][j]=D[i][j]=0.0;
			U[i][j]=A[i][j];
		}
		L[i][i]=1.0;
	}

	/* perform first the LU decomposition 
	 * on the result matrix */
	for (i=1;i<=n;i++) {
		for (j=i+1;j<=n;j++) {
			if (U[j][i]==0 && U[i][i]==0) L[j][i]=1.0;
			else if (U[i][i]==0.0) L[j][i]=0.0;
			else L[j][i]=U[j][i]/U[i][i];
			for (k=1;k<=n;k++) {
				U[j][k]-=L[j][i]*U[i][k];
			}
		}
	}
	/* transform the LU decomposition into LDU
	 * (L remains the same) */
	for (i=1;i<=n;i++) {
		if (U[i][i]!=0.0) D[i][i]=U[i][i];
	}

	for (i=1;i<=n;i++) {
		temp=U[i][i];
		for (j=i;j<=n;j++) {
			if (temp!=0) U[i][j]/=temp;
		}
	}
}


/* m_ldu()
 * perform the LDU decomposition of a square matrix A
 * if dir==7 return the lower triangular matrix L
 * if dir==8 return the upper triangual matrix D
 * if dir==9 return the permitation matrix U */
void m_ldu(TDeclare *res, TDeclare val, int dir) {
	int i,j,n=val.row;
	double M[n+1][n+1], L[n+1][n+1], U[n+1][n+1], D[n+1][n+1];

	/* Only for square matrices */
	if (val.row!=val.col) {
		perror_(__LINE__,43,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	/* compile M */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			M[i][j]=getArrayVal(val,i,j);

	/* delegate do_ldu() */
	do_ldu(n,M,L,D,U);
	if (dir==7) instMat(res,NUMERIC,n,n,L);
	else if (dir==8) instMat(res,NUMERIC,n,n,D);
	else instMat(res,NUMERIC,n,n,U);
}


/* d_matTest()
 * analyse matrix on val2 and return the TRUE/FALSE value according to val1 
 * val1 = 0 matrix is null
 * val1 = 1 matrix is diagonal
 * val1 = 2 matrix is square
 * val1 = 3 matrix is positive definite
 * val1 = 4 matrix is lower triangular
 * val1 = 5 matrix is upper triangular
 * val1 = 6 matrix is symmetric
 * val1 = 7 matrix is antisymmetric
 * val1 = 8 matrix is hyposymmetric
 * val1 = 9 matrix is invertible
 * val1 = 10 matrix is monovalue
 * val1 = 11 matrix is the identity matrix */
void d_matTest(TDeclare *res, TDeclare val1, TDeclare val2) {
	int i,j,dir=getArrayVal(val1,1,1), m=val2.row, n=val2.col;
	double S[m+1][n+1], det;
	checkStop;

	/* check data */
	if (val1.rank==MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	else if (val2.rank!=MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	else if (val1.type!=NUMERIC || val2.type!=NUMERIC) {
		perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	else if (val1.rank==VECTOR) {
		int k, t=val1.col;
		double vec[t+1];
		TDeclare vval1;
		setArray(&vval1);
		for (k=1;k<=t && ! isError && !isInterrupt;k++) {
			instScalar(&vval1,getArrayVal(val1,1,k));
			d_matTest(res, vval1, val2);
			vec[k]=getArrayVal(*res,1,1);
		}
		if (!isError && !isInterrupt) 
			instVec(res,NUMERIC,t,vec);
		return;
	}

	/* build object matrix */
	for (i=1;i<=m;i++)
		for (j=1;j<=n;j++)
			S[i][j]=getArrayVal(val2,i,j);

	/* proceed with tests */
	switch (dir) {
		case 0: instScalar(res,isMatNull(m,n,S));
			break;
		case 1: instScalar(res,fabs(m==n && isMatDiagonal(n,S)));
			break;
		case 2: instScalar(res,fabs(m==n));
			break;
		case 3: instScalar(res,fabs(m==n && isMatPosDef(n,S)));
			break;
		case 4: instScalar(res,fabs(m==n && isMatLowTri(n,S)));
			break;
		case 5: instScalar(res,fabs(m==n && isMatUpperTri(n,S)));
			break;
		case 6: instScalar(res,fabs(m==n && isMatSymmetric(n,S)));
			break;
		case 7: instScalar(res,fabs(m==n && isMatAntiSymmetric(n,S)));
			break;
		case 8: instScalar(res,fabs(m==n && isMatHypoSymmetric(n,S)));
			break;
		case 9: m_processMatrix(res,val2,DETERMI);
			det=getArrayVal(*res,1,1);
			instScalar(res,fabs(det!=0.0));
			break;
		case 10: if (m==n && isMatDiagonal(n,S)) {
				instScalar(res,TRUE);
				for (i=1;i<=n;i++) {
					if (relation(S[i][i],S[1][1])!=1) {
						instScalar(res,FALSE);
						return;
					}
				}
			}
			else {
				instScalar(res,TRUE);
				for (i=1;i<=m;i++) {
					for (j=1;j<=n;j++) {
						if (relation(S[i][j],S[1][1])!=1) {
							instScalar(res,FALSE);
							return;
						}
					}
				}
			}
			break;
		case 11: if (m==n && isMatDiagonal(n,S)) {
				instScalar(res,TRUE);
				for (i=1;i<=n;i++) {
					if (relation(S[i][i],1.0)!=1) {
						instScalar(res,FALSE);
						return;
					}
				}
			 }
			 else instScalar(res,FALSE);
			 break;
		default:
			 perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
			 break;

	}
}


/* do_hess()
 * Reduce A to H by the elimination method. At the end of the algorithm,
 * H is in Hessenberg form and has the same eigenvalues of A.
 * Matrix A is preserved. 
 * Based on the algorithm found here:
 * https://mathsfromnothing.au/hessenberg-decomposition/?i=1
 * and converted to C (and APL for HESS.apl) by Antonio Maschio 2023-2024 */
void do_hess(int n, double A[n+1][n+1], double H[n+1][n+1], double Q[n+1][n+1]) {
	int i,j,k;
	double S[n+1][n+1], W[n+1][n+1], WT[n+1][n+1];
	
	/* start Q as identity matrix */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			Q[i][j]=(i==j)?1.0:0.0;
	/* start Q as matrix A */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			H[i][j]=A[i][j];

	/* a diagonal matrix is already in Hessenberg form */
	if (isMatDiagonal(n,A)) {
		return;
	}


	/* start elimination */
	for (k=1;k<=n-2;k++) {
  		double r[n-k+1],u[n-k+1];
		double s, v[n-k+1];
		double w1[k+1][n+1], w2[n-k+1][n+1];
		for (i=1;i<=n-k;i++)
			r[i]=H[k+i][k];
  		for (i=1;i<=n-k;i++)
			u[i]=0.0;
		s=0;
		for (i=1;i<=n-k;i++)
			s+=r[i]*r[i];
		s=sqrt(s);
    		u[1]=-(sign(r[1])*(r[1]!=0.0)+(r[1]==0))*s;
		for (i=1;i<=n-k;i++)
			v[i]=r[i]-u[i];
		s=0;
		for (i=1;i<=n-k;i++)
			s+=v[i]*v[i];
		s=sqrt(s);
		for (i=1;i<=n-k;i++) {
			if (v[i]==0.0 && s==0.0) v[i]=1.0;
			else if (s==0.0) v[i]=0.0;
			else v[i]/=s;
		}
		for (i=1;i<=k;i++)
			for (j=1;j<=n;j++)
				w1[i][j]=(i==j)?1.0:0.0;
		for (i=1;i<=n-k;i++) {
			for (j=1;j<=n;j++) {
				if (i==1 && j==1) w2[i][j]=1.0;
				else if (j==1) w2[i][j]=0.0;
			}
		}
		for (i=1;i<=n-k;i++) {
			for (j=1;j<=n-k;j++) {
				w2[i][j]=2.0*v[i]*v[j];
			}
		}
		for (i=1;i<=k;i++) {
			for (j=1;j<=n;j++) {
				W[i][j]=w1[i][j];
			}
		}
		for (i=k+1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				if (j<=k) W[i][j]=0.0;
				else if (i==j) W[i][j]=1.0-w2[i-k][j-k];
				else W[i][j]=-w2[i-k][j-k];
			}
		}
		/* build transpose of W */
		for (i=1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				WT[i][j]=W[j][i];
			}
		}
		k_mat_mul(n,n,n,S,H,WT);
		k_mat_mul(n,n,n,H,W,S);
		k_mat_mul(n,n,n,Q,Q,WT);
	}
	
	/* zero out elements under the sub-diagonal */
	for (i=1;i<n-1;i++)
		for (j=i+2;j<=n;j++)
			H[j][i]=9.9;
	
} // end of do_hess() 


/* m_hess()
 * process the h operator for the Hessenberg decomposition 
 * delegates do_hess() */
void m_hess(TDeclare *res, TDeclare A, int dir) {
	int i,j,n=A.row;
	double M[n+1][n+1], H[n+1][n+1], Q[n+1][n+1];

	/* only for square matrices */
	if (A.row!=A.col) {
		perror_(__LINE__,43,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* copy A in M */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			M[i][j]=getArrayVal(A,i,j);

	do_hess(n,M,H,Q);
	if (dir==1) instMat(res,NUMERIC,n,n,H);
	else instMat(res,NUMERIC,n,n,Q);
}


/* do_chol() 
 * if dir==1 perform the Cholesky decomposition returning the
 * triangular matrix in L 
 * if dir==2 perform the LDL decomposition returning L in L */
void do_chol(int n, double A[n+1][n+1], double L[n+1][n+1], double D[n+1][n+1], int dir) {
	int i,j,k;
	double temp;
	
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			L[i][j]=A[i][j];
		}
	}

	for (i=1;i<=n;i++) {
		double s;
		for (j=1;j<=n;j++) {
			if (i==j) {
				s=0;
				for (k=1;k<=j-1;k++) 
					s+=L[i][k]*L[i][k];
				L[i][j]=sqrt(fabs(A[i][j]-s));
			}
			else if (j<i) {
				s=0;
				for (k=1;k<=j-1;k++) 
					s+=L[i][k]*L[j][k];
				if (L[j][j]!=0.0) 
					L[i][j]=(A[i][j]-s)/L[j][j];
				else L[i][j]=0.0;
			}
			else L[i][j]=0.0;
		}
	}
	/* Cholesy decomposition ended */
	if (dir==1) return; 

	/* calculate the LDL decomposition */
	for (j=1;j<=n;j++) {
		temp=L[j][j];
		for (i=j;i<=n;i++) {
			D[i][j]=L[i][j];
			if (temp!=0.0) L[i][j]/=temp;
		}
	}
	for (j=1;j<=n;j++) {
		for (i=1;i<=n;i++) {
			if (i!=j) D[i][j]=0.0;
			else D[i][j]*=D[i][j];
		}
	}
} // end of do_chol() 


/* m_chol()
 * process the l operator for the Cholesky and LDL decompositions
 * delegates do_hess() */
void m_chol(TDeclare *res, TDeclare A, int dir) {
	int i,j,n=A.row;
	double M[n+1][n+1], L[n+1][n+1], D[n+1][n+1];

	/* only for square  matrices and positive definite matrices */
	if (A.row!=A.col) {
		perror_(__LINE__,43,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	
	/* copy A in M */
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			M[i][j]=getArrayVal(A,i,j);

	if (!isMatSymmetric(n,M)) {
		perror_(__LINE__,44,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (!isMatPosDef(n,M)) {
		perror_(__LINE__,45,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	do_chol(n,M,L,D,dir);
	if (dir==1 || dir==2) instMat(res,NUMERIC,n,n,L);
	else instMat(res,NUMERIC,n,n,D);
}


/* do_balance()
 * Balancing a matrix is a preprocessing step while solving 
 * the nonsymmetric eigenvalue problem. Balancing a matrix 
 * reduces the norm of the matrix and hopefully this will 
 * improve the accuracy of the computation.
 * For a given vector norm ||.|| , an n-by-n (square) matrix A 
 * is said to be balanced iff for all i from 1 to n, 
 * the norm of its i-th column and the norm of its i-th row 
 * are equal. A and A' are diagonally similar means 
 * that there exists a diagonal nonsingular matrix D such that 
 * A' = D^−1 A D (and of course the rebuild is A = D A D^-1).
 * Computing D (and/or A') such that A' is balanced is called 
 * "balancing A", and A' is called the "balanced matrix" .*/
void do_balance(int n, double M[n+1][n+1], double A[n+1][n+1], double D[n+1][n+1]) {
	int i,j,bal=FALSE;
	double c,r,f,s,radix=10.0;
	/* set up target matrices */
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			D[i][j]=(i==j)?1.0:0.0;
			A[i][j]=M[i][j];
		}
	}

	/* balancing using the Parlett and Reinsch modified algorithm 
	 * See also https://arxiv.org/pdf/1401.5766 */
	while (!bal && !isInterrupt) {
		bal=TRUE;
		for (i=1;i<=n;i++) {
			c=r=0;
			for (j=1;j<=n;j++) {
				c+=A[j][i]*A[j][i];
				r+=A[i][j]*A[i][j];
			}
			c=sqrt(c);
			r=sqrt(r);
			s=c+r;
			f=1.0;
			while (c<r/radix) c=c*radix, r=r/radix, f=f*radix;
			while (c>=r*radix) c=c/radix, r=r*radix, f=f/radix;
			if ((c+r)<(0.95*s)) {
				bal=FALSE;
				D[i][i]=f*D[i][i];
				for (j=1;j<=n;j++) {
					A[j][i]=f*A[j][i];
					A[i][j]=A[i][j]/f;
				}
			}
		}
	}
}


void m_balance(TDeclare *res, TDeclare val, int dir) {
	int i,j, n=val.row;
	double M[n+1][n+1], A[n+1][n+1], D[n+1][n+1];

	if (val.row!=val.col) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			M[i][j]=getArrayVal(val,i,j);
		}
	}
	do_balance(n,M,A,D);
	if (dir==1) instMat(res,NUMERIC,n,n,A);
	else instMat(res,NUMERIC,n,n,D);
}


/* m_svd()
 * perform the SVD decomposition 
 * it assumes it is always vertical or square
 * so that row>=col */
void m_svd(TDeclare *QU, TDeclare *QV, TDeclare *QS, TDeclare *QW, TDeclare M, int reduce) {
	int row=M.row, col=M.col;
	int i,j, first=0, rank;
	double A[row+1][col+1], vec[3];
	double S[row+1][col+1], V[col+1][col+1], U[row+1][row+1];
	TDeclare modi;
	setArray(&modi);

	/* controls for matrices only */
	if (M.rank!=MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	/* recompose work-matrix A */
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++)
			A[i][j]=getArrayVal(M,i,j);

	/* delegate do_svd() */
	do_svd(row,col,A,U,S,V,&first);

	/* attribute return values */
	instMat(QU,NUMERIC,row,row,U);
	instMat(QV,NUMERIC,col,col,V);
	instMat(QS,NUMERIC,row,col,S);
	instScalar(QW,first);
	
	/* reduce to rank-size */
	if (reduce) {
		rank=do_rref(row,col,A,S,2);
		vec[1]=row; vec[2]=rank;
		instVec(&modi,NUMERIC,2,vec);
		d_takeDrop(QU,modi,*QU,1);
		vec[1]=col;
		instVec(&modi,NUMERIC,2,vec);
		d_takeDrop(QV,modi,*QV,1);
		vec[1]=vec[2];
		instVec(&modi,NUMERIC,2,vec);
		d_takeDrop(QS,modi,*QS,1);
	}
	free_(&modi);
}


/* do_svd()
 * workhorse for decomposing matrix A into U,SIGMA and V matrices
 * so that A = U SIGMA V^T; U and V are orthogonal matrices.
 * See also:
 * https://towardsdatascience.com/simple-svd-algorithms-13291ad2eef2
 * A is row x col
 * U is row x row
 * SIGMA is row x col
 * V is col x col
 * This algorithm works only if row>=col, so that in do_monadic()
 * the case with row<col is treated transposing the orginal matrix A
 * and then reversing U and V and transposing SIGMA 
 * Uses the naive algorithm, but in case of non null singular values,
 * uses the recently calculated V, A and the inverse of the diagonal
 * SIGMA to calculate U, instead of using another QR algorithm 
 * that would probably lead to sign errors */
void do_svd(int row, int col, double A[row+1][col+1], double U[row+1][row+1], double SIGMA[row+1][col+1], double V[col+1][col+1], int *first) {
	int i,j, count;
	double B1[col+1][col+1], B[col+1][col+1], QB[col+1][col+1], RB[col+1][col+1];
	double AT[col+1][row+1], invSIGMA[col+1][row+1], D[row+1][row+1];
	double SV[col+1];

	/* zero out SIGMA */
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++)
			SIGMA[i][j]=0.0;

	/* zero out U */
	for (i=1;i<=row;i++)
		for (j=1;j<=row;j++)
			U[i][j]=0.0;
	
	/* zero out V */
	for (i=1;i<=col;i++)
		for (j=1;j<=col;j++)
			V[i][j]=0.0;

	/* build transpose of A in AT */
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++)
			AT[j][i]=A[i][j];

	/* QR algorithm setup */
	k_mat_mul(col,row,col,B1,AT,A);
	count=0;
	for (i=1;i<=col;i++) {
		for (j=1;j<=col;j++) {
			if (i==j) V[i][j]=1.0;
			else V[i][j]=0.0;
		}
	}

	/* QR algorithm for V */
	do {
		for (i=1;i<=col;i++) {
			for (j=1;j<=col;j++) {
				B[i][j]=B1[i][j];
			}
		}
		do_qrd(col,col,B,QB,RB);
		k_mat_mul(col,col,col,B1,RB,QB);
		k_mat_mul(col,col,col,V,V,QB);
		count++;
		if (count>10000) break;
	} while (ben_diff(col,col,B1,B) && !isInterrupt);
	*first=count;
	checkStop;

	/* collection of singular values */
	for (i=1;i<=col;i++) 
		SV[i]=B1[i][i];

	/* sort singular values in descending order 
	 * the Bubble Sort algorithm */
	for(i=1;i<=col;i++) {
		double curr;
		for(j=1;j<col;j++) {
			if (relation(SV[j],SV[j+1])==3) {
				int k;
				curr=SV[j];
				SV[j]=SV[j+1];
				SV[j+1]=curr;
				for (k=1;k<=col;k++) {
					curr=V[k][j];
					V[k][j]=V[k][j+1];
					V[k][j+1]=curr;
				}
			}
		}
	}

	/* calculation of SIGMA */
	for (i=1;i<=col;i++) {
		if ((fabs(SV[i]))<IZERO) {
			SIGMA[i][i]=0;
		}
		else SIGMA[i][i]=sqrt(SV[i]);
	}
	
	/* calculation of the inverse of SIGMA 
	 * Note: if SIGMA has some null values,
	 * set value to zero */
	for (i=1;i<=col;i++) {
		for (j=1;j<=row;j++) {
			if (i==j && SIGMA[i][i]!=0.0) 
				invSIGMA[i][i]=1.0/SIGMA[i][i];
			else if (i==j && SIGMA[i][i]==0.0)
				invSIGMA[i][i]=0;
			else invSIGMA[i][j]=0.0;
		}
	}
	/* build U */
	k_mat_mul(col,col,row,D,V,invSIGMA);
	k_mat_mul(row,col,row,U,A,D);
} // end of do_svd


/* m_polar()
 * perform the Polar Decomposition */
void m_polar(TDeclare *res, TDeclare val, int dir) {
	TDeclare QU,QV,QS,QW,QVT;
	setArray(&QU);
	setArray(&QV);
	setArray(&QW);
	setArray(&QS);
	setArray(&QVT);
	checkStop;

	if (val.rank!=MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* calculate the polar decomposition 
	 * through an SVD decomposition */
	m_svd(&QU,&QV,&QS,&QW,val,TRUE);
	if (dir==3) {
		copyArray(res,QW);
	}
	else if (dir==1) {
		m_transpose(&QVT,QV);
		d_inner(res,QU,QVT,'+','x');
	}
	else {
		m_transpose(&QVT,QV);
		d_inner(&QW,QV,QS,'+','x');
		d_inner(res,QW,QVT,'+','x');
	}
	free_(&QU);
	free_(&QV);
	free_(&QW);
	free_(&QS);
	free_(&QVT);
}


/* m_kond()
 * calculates the condition number */
void m_kond(TDeclare *res, TDeclare A) {
	int i,j,n=A.row;

	/* if matrix is not square, return INF */
	if (A.row!=A.col) {
		instScalar(res,1.0/0.0);
	}
	/* if matrix is square, check if invertible */
	else {
		double M[n+1][n+1], MI[n+1][n+1], coeff[n+2];
		/* copy matrix A to M */
		for (i=1;i<=n;i++)
			for (j=1;j<=n;j++)
				M[i][j]=getArrayVal(A,i,j);
		/* try inversion of M; determinant is last coefficient */
		do_faddeev(n,M,MI,coeff);
		/* if matrix is not invertible, return INF */
		if (coeff[n+1]==0.0) {
			instScalar(res,HUGE_VAL);
		}
		/* return condition number */
		else {
			int iter;
			double U[n+1][n+1], V[n+1][n+1];
			double S[n+1][n+1];
			do_svd(n,n,M,U,S,V,&iter);
			instScalar(res,S[1][1]/S[n][n]);
		}
	}
}


/* d_matdivision()
 * execute the dyadic |%| operator */
void d_matdivision(TDeclare *res, TDeclare val1, TDeclare val2) {
	int ns=0;
	TDeclare inv;
	checkStop;

	setArray(&inv);

	if (val1.rank!=VECTOR && val2.rank!=MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}

	/* look for the not-singular inverted matrix */
	m_processMatrix(&inv,val2,INVERSE);
	if (detValue) {
		/* search for an existing variable with name DETERMINANT;
		 * if existing and of type scalar, use it as the destination
		 * memory where to save the determinant value */
		ns=searchDEC("DETERMINANT",decCount);
		if (ns && vn[ns].rank==SCALAR) {
			setArrayVal(vn[ns],1,1,detValue);
			vn[ns].type=NUMERIC;
		}
		d_inner(res,inv,val1,'+','x');
	}
	/* if the coefficient matrix cannot be inverted
	 * no solution can be found: set for the least square evaluation */
	else {
		TDeclare Q,R,R1,QT,B;
		setArray(&Q);
		setArray(&R);
		setArray(&R1);
		setArray(&QT);
		setArray(&B);
		/* @x = R sup -1 Q sup T y# */
		m_qrd(&Q,&R,val2);
		m_invert(&R1,R);
		m_transpose(&QT,Q);
		d_inner(&B,R1,QT,'+','x');
		d_inner(res,B,val1,'+','x');
		free_(&B);
		free_(&QT);
		free_(&R1);
		free_(&R);
		free_(&Q);
	}
	free_(&inv);
	
	/* turn res to vector if equal to vertical vector */
	if (res->col==1 && res->rank==MATRIX) {
		res->rank=VECTOR;
		res->col=res->row;
		res->row=1;
	}
}


/* isEqual()
 * check if matrices A and B are equal
 * Note: CZERO is the limit */
int isEqual(int row, int col, double A[row+1][col+1], double B[row+1][col+1]) {
	int i,j,res=TRUE;
	for (i=1;i<=row && res;i++) {
		for (j=1;j<=col && res;j++) {
			if (fabs(A[i][j]-B[i][j])>CZERO)
				res=FALSE;
		}
	}
	return res;
}


int calcUnity(int n, double X[n+1][n+1]) {
	int i,j;
	double diag=1.0, rest=0.0;
	for (i=1;i<=n;i++)
		diag*=X[i][i];
	for (i=1;i<=n;i++)
		for (j=1;j<=n;j++)
			if (i!=j) rest+=X[i][j];
	if (fabs(diag-1.0)<CZERO && fabs(rest)<CZERO)
		return TRUE;
	return FALSE;
}


/* set_inv_type()
 * used by m_invert after inversion
 * writes and sets properInv (as integer) and properInvStr (as string) 
 * properInv is returned by I_36 and properInvStr by I_35 */
void set_inv_type(int row, int col, double M[row+1][col+1], double MI[col+1][row+1]) {
	int gen=0, refl=0, leH=0, riH=0, left=0, right=0;
	double A[row+1][row+1], B[col+1][col+1], R[row+1][col+1] ,X[col+1][col+1];
	double AT[row+1][row+1], BT[col+1][col+1], MT[col+1][row+1], Y[row+1][row+1];
	double detVal=0;

	/* MOORE-PENROSE RULES */
	/* verify first rule */
	k_mat_mul(row,col,row,A,M,MI);
	k_mat_mul(row,row,col,R,A,M);
	if (isEqual(row,col,R,M)) gen=1;

	/* verify second rule */
	k_mat_mul(col,row,col,B,MI,M);
	k_mat_mul(col,col,row,R,B,MI);
	if (isEqual(col,row,R,MI)) refl=2;

	/* verify third rule */
	k_mat_mul(row,col,row,A,M,MI);
	k_mat_tra(row,row,AT,A);
	if (isEqual(row,row,AT,A)) leH=4;

	/* verify fourth rule */
	k_mat_mul(col,row,col,B,MI,M);
	k_mat_tra(col,col,BT,B);
	if (isEqual(col,col,BT,B)) riH=8;

	/* set-up output code */
	properInv=gen+refl+leH+riH;
	
	/* assemble description string */
	properInvStr[0]='\0';

	if (gen) strncpy_(properInvStr,"GENERALIZED ",COMPSTR);
	else strncpy_(properInvStr,"UNSPECIAL ",COMPSTR);
	
	if (refl) strncpy_(properInvStr,"REFLEXIVE ",COMPSTR);

	if (leH && riH) strncat_(properInvStr,"HERMITIAN ",COMPSTR);
	else if (leH && !riH) strncat_(properInvStr,"LEFT HERMITIAN ",COMPSTR);
	else if (!leH && riH) strncat_(properInvStr,"RIGHT HERMITIAN ",COMPSTR);

	/* verify left and right pseudo-inverse */
	if (properInv==15) {
		double XB[col+1][col+1], YA[row+1][row+1];
		/* find transpose */
		k_mat_tra(row,col,MT,M);
		/* try if left inverse */
		k_mat_mul(col,row,col,B,MT,M);
		r_square_invert(col, X, B, &detVal);
		k_mat_mul(col,col,col,XB,X,B);
		if (calcUnity(col,XB)) left=TRUE;
		k_mat_mul(row,col,row,A,M,MT);
		r_square_invert(row, Y, A, &detVal);
		k_mat_mul(row,row,row,YA,Y,A);
		if (calcUnity(row,YA)) right=TRUE;
		/* search in data */
		if (left && !right) {
			strncpy_(properInvStr,"LEFT PSEUDO-",COMPSTR);
			properInv+=16;
		}
		else if (!left && right) {
			strncpy_(properInvStr,"RIGHT PSEUDO-",COMPSTR);
			properInv+=32;
		}
		else if (left && right) {
			strncpy_(properInvStr,"QUASI-",COMPSTR);
			properInv+=64;
		}
		else strncpy_(properInvStr,"PSEUDO-",COMPSTR);
	}

	strncat_(properInvStr,"INVERSE",COMPSTR);

}


/* countNotAllEmpty()
 * return the rank of an echelon matrix 
 * if dir==1 return rows count
 * else return column count */
int countNotAllEmpty(int row, int col, double val[row+1][col+1], int dir) {
	int i,j, ret, c1,c2;
	/* check by rows */
	c1=row;
	for (i=1;i<=row;i++) {
		ret=TRUE;
		for (j=1;j<=col;j++) {
			if (fabs(val[i][j])>CZERO) ret=FALSE;
		}
		if (ret) c1--;
	}

	/* check by columns */
	c2=col;	
	for (i=1;i<=col;i++) {
		ret=TRUE;
		for (j=1;j<=row;j++) {
			if (fabs(val[j][i])>CZERO) ret=FALSE;
		}
		if (ret) c2--;
	}
	if (dir==1) return c1;
	return c2;
}


/* do_echelon()
 * calculate the echelon form of any matrix */
void do_echelon(int row, int col, double val[row+1][col+1], double matrix[row+1][col+1]) {
	int lead, r, i, j;
	double n,temp;
	checkStop;

	for (i=1;i<=row;i++) 
		for (j=1;j<=col;j++)
			matrix[i][j]=val[i][j];


	lead=1;
	for (r=1;r<=row;r++) {
		if (lead>=col)  break;
		i=r;
		while (fabs(matrix[i][lead])<CZERO) {
			i = i + 1;
			if (i==row) {
				i = r;
				lead = lead + 1;
				if (lead==col) break;
			}
		}
		for (j=1;j<=col;j++) {
			temp=matrix[i][j];
			matrix[i][j]=matrix[r][j];
			matrix[r][j]=temp;
		}
		n=matrix[r][lead];
		if (fabs(n)>CZERO) {
			for (j=1;j<=col;j++) {
				matrix[r][j]=matrix[r][j]/n;
			}
		}
		for (i=r+1;i<=row;i++) {
			if (i!=r) {
				n=matrix[i][lead];
				for (j=1;j<=col;j++) {
					matrix[i][j]=matrix[i][j]-matrix[r][j]*n;
				}
			}
		}
		lead++;
	}
	/* turn first non-null items to 1 by dividing all lines by it */
	for (i=1;i<=row;i++) {
		int w=1,k=1;
		while (fabs(matrix[i][w])<CZERO && w<col) w++;
		n=matrix[i][w];
		if (fabs(n)>CZERO) {
			double rapp;
			for (k=1;k<=col;k++) {
				rapp=matrix[i][k]/n;
				if (fabs(rapp)<IZERO) rapp=0.0;
				matrix[i][k]=rapp;
			}
		}
	}

	/* discover if some null row is in the middle (but the first) */
	for (i=2;i<row;i++) {
		int zero;
		zero=TRUE;
		for (j=1;j<=col;j++) {
			if (fabs(matrix[i][j])<EZERO) {
				matrix[i][j]=0.0;
			}
			if (matrix[i][j]!=0.0) zero=FALSE;
		}
		/* exchange rows j and j+1 */
		if (zero) {
			double temp;
			for (j=1;j<=col;j++) {
				temp=matrix[i][j];
				matrix[i][j]=matrix[i+1][j];
				matrix[i+1][j]=temp;
			}
		}
	}
	/* discover if some null columns is in the middle */
	for (i=1;i<col;i++) {
		int zero;
		zero=TRUE;
		for (j=1;j<=row;j++) {
			if (fabs(matrix[j][i])<EZERO) {
				matrix[j][i]=0.0;
			}
			if (matrix[j][i]!=0.0) zero=FALSE;
		}
		/* exchange columns j and j+1 */
		if (zero) {
			double temp;
			for (j=1;j<=row;j++) {
				temp=matrix[j][i];
				matrix[j][i]=matrix[j+1][i];
				matrix[j+1][i]=temp;
			}
		}
	}
} // end of do_echelon()


/* do_rref()
 * calculate the rref form (and thus the rank) of any matrix */
int do_rref(int row, int col, double val[row+1][col+1], double matrix[row+1][col+1], int dir) {
	int lead, r, i, j;
	double n,temp;
	checkStop 0;

	/* copy val to matrix to preserve original */
	for (i=1;i<=row;i++) 
		for (j=1;j<=col;j++)
			matrix[i][j]=val[i][j];


	/* start Row reduction (thanks to catGPT) */
	lead=1;
	for (r=1;r<=row;r++) {
		if (lead>col)  break;
		i=r;
		while (fabs(matrix[i][lead])<CZERO) {
			i++;
			if (i>row) {
				i=r;
				lead++;
				if (lead>col) break;
			}
		}
		/* swap rows i and r */
		for (j=1;j<=col;j++) {
			temp=matrix[i][j];
			matrix[i][j]=matrix[r][j];
			matrix[r][j]=temp;
		}

		/* Build the leading coefficient i */
		n=matrix[r][lead];
		if (fabs(n)>CZERO) {
			for (j=1;j<=col;j++) {
				matrix[r][j]=matrix[r][j]/n;
			}
		}

		/* Zero out the column entries above
		 * and below the leading i */
		for (i=1;i<=row;i++) {
			if (i!=r) {
				n=matrix[i][lead];
				for (j=1;j<=col;j++) {
					matrix[i][j]=matrix[i][j]-matrix[r][j]*n;
				}
			}
		}
		lead++;
	}

	/* turn first non-null items to 1 by dividing all remaining items by it */
	for (i=1;i<=min(row,col);i++) {
		int w=1,k=1;
		while (fabs(matrix[i][w])<CZERO && w<col) w++;
		n=matrix[i][w];
		if (fabs(n)>CZERO) {
			double rapp;
			for (k=1;k<=col;k++) {
				rapp=matrix[i][k]/n;
				if (fabs(rapp)<IZERO) rapp=0.0;
				matrix[i][k]=rapp;
			}
		}
	}

	
	/* discover if some null row is in the middle (but the first) */
	for (i=1;i<row;i++) {
		int zero;
		zero=TRUE;
		for (j=1;j<=col;j++) {
			if (fabs(matrix[i][j])<EZERO) {
				matrix[i][j]=0.0;
			}
			if (matrix[i][j]!=0.0) zero=FALSE;
		}
		/* exchange rows j and j+1 */
		if (zero) {
			double temp;
			for (j=1;j<=col;j++) {
				temp=matrix[i][j];
				matrix[i][j]=matrix[i+1][j];
				matrix[i+1][j]=temp;
			}
		}
	}
	/* discover if some null columns is in the middle */
	for (i=1;i<col;i++) {
		int zero;
		zero=TRUE;
		for (j=1;j<=row;j++) {
			if (fabs(matrix[j][i])<EZERO) {
				matrix[j][i]=0.0;
			}
			if (matrix[j][i]!=0.0) zero=FALSE;
		}
		/* exchange columns j and j+1 */
		if (zero) {
			double temp;
			for (j=1;j<=row;j++) {
				temp=matrix[j][i];
				matrix[j][i]=matrix[j+1][i];
				matrix[j+1][i]=temp;
			}
		}
	}
	
	/* set for output for operator r[2], r[3] and r[4] 
	 * Note: operator r[5] follows matrix[] and r[1]
	 * is executed by do_echelon() */
	if (dir==3) {
		return countNotAllEmpty(row,col,matrix,1);
	}
	else if (dir==4) {
		return countNotAllEmpty(row,col,matrix,2);
	}
	else if (dir==2) {
		int r1,r2;
		r1=countNotAllEmpty(row,col,matrix,1);
		r2=countNotAllEmpty(row,col,matrix,2);
		return min(r1,r2);
	}
	return 0;
} // end of do_rref()


/* m_linear()
 * linear independent rows or columns
 * dir = 1 perform r or r[1] echelon
 * dir = 2 perform r[2] rank
 * dir = 3 perform r[3] row rank
 * dir = 4 perform r[4] col rank 
 * dir = 5 perform r[6] rref */
void m_linear(TDeclare *res, TDeclare val, int dir) {
	int i,j;
	double A[val.row+1][val.col+1];
	double ech[val.row+1][val.col+1];
	int rank;
	checkStop;

	for (i=1;i<=val.row;i++) {
		for (j=1;j<=val.col;j++) {
			A[i][j]=getArrayVal(val,i,j);
		}
	}
	if (dir==1) do_echelon(val.row,val.col,A,ech);
	else rank=do_rref(val.row, val.col, A, ech, dir);
	if (dir>1 && dir<5) instScalar(res,rank);
	else instMat(res,NUMERIC,val.row,val.col,ech);
}


/******************************************
 *           ENCODE/DECODE                *
 ******************************************/
/* d_decode() 
 * reduce a number representation in any number system to a value */
void d_decode(TDeclare *res, TDeclare v1, TDeclare v2) {
	int j,k,i;
	int item, ret;
	TDeclare val1,val2;
	checkStop;

	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	/* val1 scalar to array */
	if (val2.rank==SCALAR) {
		vectorize(&val2,1); 
		checkStop;
	}
	if (val1.rank==SCALAR || (val1.rank==VECTOR && val1.row==1 && val1.col==1)) {
		vectorize(&val1,val2.col);
		checkStop;
	}
	if (val1.col!=val2.col) {
		perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
		goto decode_go;
	}
	/* dimension result */
	if (val2.rank==VECTOR) {
		res->rank=VECTOR;
		res->type=NUMERIC;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		if (isError) goto decode_go;
	}
	else if (val2.rank==MATRIX) {
		res->rank=MATRIX;
		res->type=NUMERIC;
		res->row=val2.row;
		res->col=1;
		res->size=res->row+1;
		dimArray(res,res->size);
		if (isError) goto decode_go;
	}
	for (j=1;j<=val2.row;j++) {
		ret=getArrayVal(val2,j,val2.col);
		for (i=val2.col-1;i>=1;i--) {
			item=getArrayVal(val2,j,i);
			for (k=val1.col;k>i;k--) {
				item*=getArrayVal(val1,1,k);
			}
			ret+=item;
		}
		setArrayVal(*res,j,1,ret);
	}
decode_go:
	free_(&val1);
	free_(&val2);
}


/* d_decode() 
 * convert the value of a number to its representation in any number system */
void d_encode(TDeclare *res, TDeclare v1, TDeclare v2) {
	int j,k;
	TDeclare val1,val2;
	checkStop;

	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	/* val1 scalar to array */
	if (val2.rank==MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto encode_go;
	}
	if (val1.rank==SCALAR) {
		vectorize(&val1,1);
		checkStop;
	}
	if (val2.rank==SCALAR) {
		vectorize(&val2,1);
		checkStop;
	}
	if (val2.col==1 && val1.col>1) {
		res->rank=VECTOR;
		res->type=NUMERIC;
		res->row=1;
		res->col=val1.col;
		res->size=val1.col+1;
		dimArray(res,res->size);
		if (isError) goto encode_go;
	}
	else if (val2.col>1) {
		res->rank=MATRIX;
		res->type=NUMERIC;
		res->row=val2.col;
		res->col=val1.col;
		res->size=res->col*res->row+1;
		dimArray(res,res->size);
		if (isError) goto encode_go;
	}
	else if (val2.col==1 && val2.col==1) {
		res->rank=SCALAR;
		res->type=NUMERIC;
		res->col=1;
		res->row=1;
		res->size=2;
		dimArray(res,res->size);
		if (isError) goto encode_go;
	}
	for (j=1;j<=val2.col;j++) {
		int tot,div,mod,quo;
		tot=getArrayVal(val2,1,j);
		k=val1.col;
		while (TRUE) {
			div=getArrayVal(val1,1,k);
			if (!div) {
				setArrayVal(*res,j,k,tot);
				break;
			}
			quo=(int)(tot/div);
			mod=tot-quo*div;
			setArrayVal(*res,j,k,mod);
			tot=quo;
			k--;
			if (k<1) {
				break;
			}
		}
	}
encode_go:
	free_(&val1);
	free_(&val2);
}


/******************************************
 *        APL DEBUG INTERFACE             *
 ******************************************/
/* print()
 * print cxd matrix */
void print(int c, int d, double n[c+1][d+1]) {
	int i,j;
	for (i=1;i<=c;i++) {
		for (j=1;j<=d;j++) {
			printf("   %G\t",n[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}


/* printv()
 * print vector of dimension c */
void printv(int c, double n[c+1]) {
	int i;
	for (i=1;i<=c;i++) {
		printf("         %G",n[i]);
	}
	printf("\n");
}


/* vrint() 
 * print integer vector of dimension c*/
void vrint(int c, int n[c+1]) {
	int i;
	for (i=1;i<=c;i++) {
		printf("         %d",n[i]);
	}
	printf("\n");
}


/******************************************
 *    MATRIX CALCULATION FOR INVERSION    *
 ******************************************/

/* tr()
 * return the trace of the square matrix n x n in C-shape.
 * Service function for do_faddeev()  */
double tr(int n, double m[n+1][n+1]) {
	double res=0;
	int i;
	for (i=1;i<=n;i++)
		res+=m[i][i];
	return res;
}


/* k_mat_tra()
 * perform the multiplication of AT and A*/
void k_mat_tra(int row, int col, double AT[col+1][row+1], double A[row+1][col+1]) {
	int i,j;
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++)
			AT[j][i]=A[i][j];
}


/* k_mat_mul()
 * calculates the dot-product between the val1 and val2 matrices (in this order)
 * and put the result in res; 
 * matrix val1 has dimension row1/col1, 
 * matrix val2 has dimension col1/col2 (row2=col1). */
void k_mat_mul(int row1, int col1, int col2, double res[row1+1][col2+1], double val1[row1+1][col1+1], double val2[col1+1][col2+1]) {
	int i,j,k;
	double ret, temp[row1+1][col2+1];
	for (k=col2;k>=1;k--) {
		for (i=row1;i>=1;i--) {
			ret=0;
			for (j=col1;j>=1;j--) {
				ret+=val1[i][j]*val2[j][k];
			}
			temp[i][k]=ret;
		}
	}
	/* copy temp to res */
	for (i=1;i<=row1;i++) {
		for (j=1;j<=col2;j++) {
			res[i][j]=temp[i][j];
		}
	}
}


/* ben_diff()
 * calculates the numeric difference between S and T
 * and if negligible in all cases, they are considered equal
 * Note: CZERO is the limit 
 * System function for do_ben() */
int ben_diff(int n, int m, double S[n+1][m+1], double T[n+1][m+1]) {
	double dif=0;
	int i,j;
	for (i=1;i<=n;i++) {
		for (j=1;j<=m;j++) {
			dif+=fabs(S[i][j]-T[i][j]);
		}
	}
	if (dif>CZERO) return TRUE;
	return FALSE;	
}


/* do_ben()
 * treat the BEN-ISRAEL/COHEN iteration 
 * Note: according to Wikipedia:
 * "[This algorithm] uses the recursion 
 *     Ai = 2xA0 - A0+.xA+.xA0
 * which is sometimes referred to as 'hyper-power sequence'. 
 * This recursion produces a sequence converging quadratically 
 * to the pseudoinverse of A if it is started with an appropriate A0
 * satisfying A0+.xA = o\(A0+.xA)"
 * I set A0 to be equal to the transpose of A multiplied by a very
 * small term which is 1E-12; I found that fixing the difference 
 * between two consecutive results to 1E-13 satisfies 
 * the convergence and the result is reached in no more than 100 
 * iterations at most. 
 * Copyleft Antonio Maschio - May 2022 for apple */
void do_ben(int row, int col, double A[row+1][col+1], double AI[col+1][row+1]) {
	int i,j,count=0;
	double A1[col+1][row+1], A0[col+1][row+1];
	double B[col+1][col+1], C[col+1][row+1];
	checkStop;

	/* setup starting data */
	iterations=0;
	for (i=1;i<=row;i++) {
		for (j=1;j<=col;j++) {
			A1[j][i]=A[i][j]*CZERO;
		}
	}

	do {
		for (i=1;i<=col;i++) {
			for (j=1;j<=row;j++) {
				A0[i][j]=A1[i][j];
			}
		}
		k_mat_mul(col,row,col,B,A0,A);
		k_mat_mul(col,col,row,C,B,A0);
		for (i=1;i<=col;i++) {
			for (j=1;j<=row;j++) {
				A1[i][j]=2.0*A0[i][j]-C[i][j];
			}
		}
		count++;

	} while (ben_diff(col,row,A1,A0) && !isInterrupt);
	iterations=count;
	checkStop;
	
	for (i=1;i<=col;i++) {
		for (j=1;j<=row;j++) {
			AI[i][j]=A1[i][j];
		}
	}
}


/* do_faddeev()
 * Algorithm of Faddeev–LeVerrier for the inverse, the determinant 
 * and the determination of the coefficients of the characteristic
 * polynomial; 
 * See also 
 * https://en.wikipedia.org/wiki/Faddeev%E2%80%93LeVerrier_algorithm*/
void do_faddeev(int n, double A[n+1][n+1], double AI[n+1][n+1], double coeff[n+2]) {
	int i,j,t;
	double M[n+1][n+1],temp[n+1][n+1], ck;
	checkStop;

	/* first step (omitted); empty matrix */
	/* second step: build identity matrix */
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			M[i][j]=0;
		}
	}
	for (i=1;i<=n;i++) {
		M[i][i]=1;
	}
	coeff[1]=1;
		/* next steps iteration */
	for (t=1;t<=n;t++) {
		/* multiply temp = A M */
		k_mat_mul(n,n,n,temp,A,M);

		/* calculate trace */
		ck=-tr(n,temp)/t;
		coeff[t+1]=ck;

		/* in case the column count is reached, stop the cycle */
		if (t==n) break;
		/* add (with sign) trace from temp and assign to M */
		for (i=1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				if (i==j) M[i][j]=temp[i][j]+ck;
				else M[i][j]=temp[i][j];
			}
		}
	} // end of Feddeev-Le Verrier algorithm
	for (i=1;i<=n;i++) {
		for (j=1;j<=n;j++) {
			AI[i][j]=M[i][j]/(-ck);
		}
	}
}


/* instEmpty()
 * install vector in res from vector vec,
 * type is seto to 'type' and dimension us col */
void instEmpty(TDeclare *res) {
	res->type=NUMERIC;
	res->rank=VECTOR;
	res->row=1;
	res->col=0;
	res->size=1;
	dimArray(res,res->size);
}


/* instMat()
 * install matrix in res from matrix mat,
 * type is seto to 'type' and dimensions are row x col */
void instMat(TDeclare *res, int type, int row, int col, double mat[row+1][col+1]) {
	int i,j;
	res->type=type;
	res->rank=MATRIX;
	res->row=row;
	res->col=col;
	res->size=row*col+1;
	dimArray(res,res->size);
	for (i=1;i<=row;i++)
		for (j=1;j<=col;j++) 
			setArrayVal(*res,i,j,mat[i][j]);
}


/* instVec()
 * install vector in res from vector vec,
 * type is seto to 'type' and dimension us col */
void instVec(TDeclare *res, int type, int col, double vec[col+1]) {
	int i;
	res->type=type;
	res->rank=VECTOR;
	res->row=1;
	res->col=col;
	res->size=col+1;
	dimArray(res,res->size);
	for (i=1;i<=col;i++)
		setArrayVal(*res,1,i,vec[i]);
}


/* instScalar()
 * install numeric vector in res from value val */
void instScalar(TDeclare *res, double val) {
	res->type=NUMERIC;
	res->rank=SCALAR;
	res->row=1;
	res->col=1;
	res->size=2;
	dimArray(res,res->size);
	setArrayVal(*res,1,1,val);
}


/* m_processMatrix()
 * elaborate the following output:
 * operator |%|  square inverse (dir=INVERSE) 
 * operator d determinant */
void m_processMatrix(TDeclare *res, TDeclare A1, int dir) {
	int i,j,n=A1.row,m=A1.col;
	double A[n+1][m+1], AI[n+1][m+1], coeff[n+2];
	checkStop;

	/* perform checks */
	if (A1.type!=NUMERIC || A1.rank!=MATRIX) {
		perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (dir==INVERSE && n!=m) {
		detValue=0;
		instScalar(res,0.0);
		return;
	}
	else if ((dir==INVERSE || dir==DETERMI) && n==m) {
		for (i=1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				A[i][j]=getArrayVal(A1,i,j);
			}
		}
		/* square matrix */
		do_faddeev(n,A,AI,coeff);
		detValue=coeff[n+1];
		if (dir==INVERSE) instMat(res,NUMERIC,m,n,AI);
		else instScalar(res,detValue);
	}
	else if (dir==COEFFIC && n==m) {
		for (i=1;i<=n;i++) {
			for (j=1;j<=n;j++) {
				A[i][j]=getArrayVal(A1,i,j);
			}
		}
		/* square matrix */
		do_faddeev(n,A,AI,coeff);
		instVec(res,NUMERIC,n+1,coeff);
	}
	else if (dir==COEFFIC && n!=m) {
		instScalar(res,0.0);
	}
	else if (dir==DETERMI) {
		detValue=0;
		instScalar(res,0.0);
	}
	else {
		/* This should never appear */
		perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
		instScalar(res,0);
	}
}


/* isDiagonal()
 * return TRUE if the matrix is diagonal in the proper sense (i.e. it has
 * some non-null values in the diagonal and all zeroes elsewhere) 
 * */
int isDiagonal(TDeclare val) {
	int i=0,j=0, diag=0, res=FALSE;
	double el;
	if (val.rank!=MATRIX) return res;
	for (i=1;i<=val.col;i++) {
		for (j=1;j<=val.row;j++) {
			el=getArrayVal(val,i,j);
			if (i!=j && el!=0.0) diag++;
		}
	}
	res=!diag;
	return res;
}


int isNull(TDeclare val) {
	int i=0,j=0, res=TRUE;
	for (i=1;i<=val.col;i++) {
		for (j=1;j<=val.row;j++) {
			if (fabs(getArrayVal(val,i,j))>CZERO) 
				res=FALSE;
		}
	}
	return res;
}


/* m_invert()
 * execute the invert operator */
void m_invert(TDeclare *res, TDeclare val) {
	int i,j;
	double A[val.row+1][val.col+1], AI[val.col+1][val.row+1];
	checkStop;

	/* treat the scalar case */
	if (val.rank==SCALAR && !Winv) {
		double ret=getArrayVal(val,1,1);
		copyArray(res,val);
		if (fabs(ret)<CZERO) setArrayVal(*res,1,1,0.0);
		else setArrayVal(*res,1,1,1.0/ret);
		properInv=-1;
		strncpy_(properInvStr,"SCALAR INVERSE",COMPSTR);
		return;
	}
	/* treat the vector case (it returns a vectical vector) */
	else if (val.rank==VECTOR && !Winv) {
		double curr, square=0.0;
		copyArray(res,val);
		res->row=res->col;
		res->col=1;
		res->rank=MATRIX;
		for (i=1;i<=val.col;i++) {
			curr=getArrayVal(val,1,i);
			square+=curr*curr;
		}
		for (i=1;i<=val.col;i++) {
			setArrayVal(*res,i,1,getArrayVal(val,1,i)/square);
		}
		properInv=-1;
		strncpy_(properInvStr,"VECTOR INVERSE",COMPSTR);
		return;
	}
	/* treat the vertical vector case (it returns a vector) */
	else if (val.rank==MATRIX && val.col==1 && !Winv) {
		double curr, square=0.0;
		copyArray(res,val);
		res->col=res->row;
		res->row=1;
		res->rank=VECTOR;
		for (i=1;i<=val.row;i++) {
			curr=getArrayVal(val,i,1);
			square+=curr*curr;
		}
		for (i=1;i<=val.row;i++) {
			setArrayVal(*res,1,i,getArrayVal(val,i,1)/square);
		}
		properInv=-1;
		strncpy_(properInvStr,"VERTICAL VECTOR INVERSE",COMPSTR);
		return;
	}

	/* at this point, only matrices are admitted if Winv is enabled */
	if (val.rank!=MATRIX && Winv) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}


	/* treat the diagonal square matrix case */
	if (isDiagonal(val) && val.row==val.col) {
		double curr=0.0;
		copyArray(res,val);
		for (i=1;i<=val.row;i++) {
			curr=getArrayVal(val,i,i);
			if (curr!=0.0) setArrayVal(*res,i,i,1.0/curr);
		}
		properInv=-1;
		if (isNull(val)) 
			strncpy_(properInvStr,"NULL SQUARE MATRIX INVERSE",COMPSTR);
		else strncpy_(properInvStr,"SQUARE DIAGONAL MATRIX INVERSE",COMPSTR);
		return;
	}

	/* in case of a square matrix, try the Faddeev/LeVerrier algorithm 
	 * that succeeds only in case the determinant is not null */
	if (val.col==val.row) {
		m_processMatrix(res,val,INVERSE);
		if (detValue) {
			int ns=searchDEC("DETERMINANT",decCount);
			if (ns && vn[ns].rank==SCALAR) {
				setArrayVal(vn[ns],1,1,detValue);
			}
			properInv=0;
			strncpy_(properInvStr,"PROPER INVERSE",COMPSTR);
			return;
		}
	}
	
	/* at this point no inversion is possible if Winv is enabled */
	if (Winv) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	
	/* treat the generalized/pseudo-inverse case 
	 * as the final catch-all case */
	for (i=1;i<=val.row;i++) {
		for (j=1;j<=val.col;j++) {
			A[i][j]=getArrayVal(val,i,j);
		}
	}
	do_ben(val.row,val.col,A,AI);
	set_inv_type(val.row,val.col,A,AI);
	if (isNull(val)) 
		strncpy_(properInvStr,"NULL MATRIX INVERSE",COMPSTR);
	instMat(res,NUMERIC,val.col,val.row,AI);
}


/******************************************
 *   APL COMMA / LAMINATE INTERFACE	  *
 ******************************************/
/* vectorize() 
 * turn a scalar or a vector/uni into a vector with col elements
 * the type is not changed  */
void vectorize(TDeclare *res, int col) {
	int i;
	double val=getArrayVal(*res,1,1);
	res->rank=VECTOR;
	res->row=1;
	res->col=col;
	res->size=res->col+1;
	dimArray(res,res->size);
	if (isError) return;
	for (i=1;i<=col;i++)
		setArrayVal(*res,1,i,val);
}


/* makeVector()
 * turn a scalar or a matrix into a vector
 * Note: type is not changed
 * System function from d_comma() */
void makeVector(TDeclare *res) {
	checkStop;
	if (res->rank==SCALAR) {
		double val=getArrayVal(*res,1,1);
		res->rank=VECTOR;
		res->row=1;
		res->col=1;
		res->size=2;
		setArrayVal(*res,1,1,0);
		setArrayVal(*res,1,1,val);
	}
	else if (res->rank==VECTOR) {
		return;
	}
	/* Note: the rearranging of the type maintains
	 * the order of elements */
	else if (res->rank==MATRIX) {
		int tot=0;
		tot=res->row*res->col;
		res->rank=VECTOR;
		res->row=1;
		res->col=tot;
		res->size=tot+1;
	}
}


/* verticalize ()
 * turn a vector (which is horizontal and arranged on row=1 and col)
 * into a matrix with the same number of rows and col=1)
 * System function from d_comma() */
void verticalize(TDeclare *res) {
	res->row=res->col;
	res->col=1;
	res->rank=MATRIX;
}



/* d_laminate()
 * perform the laminate dyadic operator */
void d_laminate(TDeclare *res, TDeclare v1, TDeclare v2, int dir) {
	int i;
	TDeclare val1,val2;
	checkStop;

	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	if (v1.rank==MATRIX || v2.rank==MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto lami_go;
	}
	if (val1.rank==SCALAR && val2.rank==VECTOR) vectorize(&val1,val2.col);
	else if (val2.rank==SCALAR && val1.rank==VECTOR) vectorize(&val2,val1.col);
	checkStop;
	if (val1.col!=val2.col) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto lami_go;
	}
	/* set type */
	res->type=val2.type;
	if (val1.rank==SCALAR && val2.rank==SCALAR && dir==3) {
		res->rank=MATRIX;
		res->row=2;
		res->col=1;
		res->size=3;
		dimArray(res,res->size);
		setArrayVal(*res,1,1,getArrayVal(val1,1,1));
		setArrayVal(*res,2,1,getArrayVal(val2,1,1));
	}
	else if (val1.rank==SCALAR && val2.rank==SCALAR && dir==4) {
		res->rank=VECTOR;
		res->row=1;
		res->col=2;
		res->size=3;
		dimArray(res,res->size);
		setArrayVal(*res,1,1,getArrayVal(val1,1,1));
		setArrayVal(*res,1,2,getArrayVal(val2,1,1));
	}
	else if (val1.rank==VECTOR && val2.rank==VECTOR && dir==3) {
		res->rank=MATRIX;
		res->row=2;
		res->col=val1.col;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		for (i=1;i<=val1.col;i++) {
			setArrayVal(*res,1,i,getArrayVal(val1,1,i));
			setArrayVal(*res,2,i,getArrayVal(val2,1,i));
		}
	}
	else if (val1.rank==VECTOR && val2.rank==VECTOR && dir==4) {
		res->rank=MATRIX;
		res->row=val1.col;
		res->col=2;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		for (i=1;i<=val1.col;i++) {
			setArrayVal(*res,i,1,getArrayVal(val1,1,i));
			setArrayVal(*res,i,2,getArrayVal(val2,1,i));
		}
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
lami_go:
	free_(&val1);
	free_(&val2);
}



/* d_comma()
 * perform the comma dyadic operator */
void d_comma(TDeclare *res, TDeclare v1, TDeclare v2, int dir) {
	TDeclare val1,val2;
	checkStop;

	if (dir==3 || dir==4) {
		d_laminate(res,v1,v2,dir);
		return;
	}
	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	if (val1.rank==SCALAR) makeVector(&val1);
	if (val2.rank==SCALAR) makeVector(&val2);
	/* set type */
	res->type=val2.type;
	if (val1.rank==VECTOR && val2.rank==VECTOR) {
		int i;
		/*if (val1.col+val2.col>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=VECTOR;
		res->row=1;
		res->col=val1.col+val2.col;
		res->size=res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (i=1;i<=val1.col;i++) {
			setArrayVal(*res,1,i,getArrayVal(val1,1,i));
		}
		for (i=1;i<=val2.col;i++) {
			setArrayVal(*res,1,val1.col+i,getArrayVal(val2,1,i));
		}
		if (dir==1) verticalize(res);
	}
	else if (val1.rank==VECTOR && val2.rank==MATRIX && dir==1) {
		int i,j;
		if (val1.col==1) {
			vectorize(&val1,val2.col);
			if (isError || isInterrupt) goto comma_go; // checkStop
		}
		else if (val1.col!=val2.col) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}
		/*if (val2.row+1>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=MATRIX;
		res->row=val2.row+1;
		res->col=val2.col;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (j=1;j<=val1.col;j++)
			setArrayVal(*res,1,j,getArrayVal(val1,1,j));
		for (i=1;i<=val2.row;i++) {
			for (j=1;j<=val2.col;j++) {
				setArrayVal(*res,1+i,j,getArrayVal(val2,i,j));
			}
		}
	}
	else if (val1.rank==VECTOR && val2.rank==MATRIX && dir==2) {
		int i,j;
		if (val1.col==1) {
			vectorize(&val1,val2.row);
			if (isError || isInterrupt) goto comma_go; //checkStop
		}
		else if (val1.col!=val2.row) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}
		/*if (val2.col+1>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=MATRIX;
		res->row=val2.row;
		res->col=val2.col+1;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (j=1;j<=val1.col;j++)
			setArrayVal(*res,j,1,getArrayVal(val1,1,j));
		for (i=1;i<=val2.row;i++) {
			for (j=1;j<=val2.col;j++) {
				setArrayVal(*res,i,1+j,getArrayVal(val2,i,j));
			}
		}
	}
	else if (val1.rank==MATRIX && val2.rank==VECTOR && dir==1) {
		int i,j;
		if (val2.col==1) {
			vectorize(&val2,val1.col);
			if (isError || isInterrupt) goto comma_go; // checkStop
		}
		else if (val2.col!=val1.col) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}
		/*if (val1.row+1>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=MATRIX;
		res->row=val1.row+1;
		res->col=val1.col;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (i=1;i<=val1.row;i++) {
			for (j=1;j<=val1.col;j++) {
				setArrayVal(*res,i,j,getArrayVal(val1,i,j));
			}
		}
		for (j=1;j<=val1.col;j++)
			setArrayVal(*res,val1.row+1,j,getArrayVal(val2,1,j));
	}
	else if (val1.rank==MATRIX && val2.rank==VECTOR && dir==2) {
		int i,j;
		if (val2.col==1) {
			vectorize(&val2,val1.row);
			if (isError || isInterrupt) goto comma_go; // checkStop
		}
		else if (val2.col!=val1.row) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}
		/*if (val1.col+1>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=MATRIX;
		res->row=val1.row;
		res->col=val1.col+1;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (i=1;i<=val1.row;i++) {
			for (j=1;j<=val1.col;j++) {
				setArrayVal(*res,i,j,getArrayVal(val1,i,j));
			}
		}
		for (j=1;j<=val2.col;j++)
			setArrayVal(*res,j,val1.col+1,getArrayVal(val2,1,j));
	}
	else if (val1.rank==MATRIX && val2.rank==MATRIX && dir==1) {
		int i,j;
		if (val2.col!=val1.col) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}
		/*if (val1.row+val2.row>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=MATRIX;
		res->row=val1.row+val2.row;
		res->col=val1.col;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (i=1;i<=val1.row;i++) {
			for (j=1;j<=val1.col;j++) {
				setArrayVal(*res,i,j,getArrayVal(val1,i,j));
			}
		}
		for (i=1;i<=val2.row;i++) {
			for (j=1;j<=val2.col;j++) {
				setArrayVal(*res,val1.row+i,j,getArrayVal(val2,i,j));
			}
		}
	}
	else if (val1.rank==MATRIX && val2.rank==MATRIX && dir==2) {
		int i,j;
		if (val2.row!=val1.row) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}
		/*if (val1.col+val2.col>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto comma_go;
		}*/
		res->rank=MATRIX;
		res->row=val1.row;
		res->col=val1.col+val2.col;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto comma_go;
		for (i=1;i<=val1.row;i++) {
			for (j=1;j<=val1.col;j++) {
				setArrayVal(*res,i,j,getArrayVal(val1,i,j));
			}
		}
		for (i=1;i<=val2.row;i++) {
			for (j=1;j<=val2.col;j++) {
				setArrayVal(*res,i,val1.col+j,getArrayVal(val2,i,j));
			}
		}
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
comma_go:
	free_(&val1);
	free_(&val2);

}


/* m_comma()
 * perform the comma monadic operator */
void m_comma(TDeclare *res, TDeclare val) {
	checkStop;

	if (val.rank==SCALAR) {
		res->rank=VECTOR;
		res->type=val.type;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		if (isError) return;
		setArrayVal(*res,1,1,getArrayVal(val,1,1));
	}
	else {
		int i=1,j=1,r=1;
		/*if (val.row*val.col>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			return;
		}*/
		res->rank=VECTOR;
		res->type=val.type;
		res->row=1;
		res->col=val.row*val.col;	
		res->size=res->col+1;
		dimArray(res,res->size);
		if (isError) return;
		for (r=1;r<=res->col;r++) {
			setArrayVal(*res,1,r,getArrayVal(val,i,j));
			j++;
			if (j>val.col) {
				j=1;
				i++;
				if (i>val.row) i=1;
			}
		}
	}
}


/***********************************************
 * REDUCTION/COMPRESSION/ESPAND/SCAN INTERFACE *
 ***********************************************/
/* m_reduction()
 * operate the reduction according to these rules:
 * -> op is the scalar operator to be used 
 * -> val is the object to be reduced 
 * -> dir is the direction: 1 or 2 
 * The result is stored in res */
void m_reduction(TDeclare *res, char op, TDeclare val, char dir) {
	int i,j,k;
	double mres;
	checkStop;

	if (val.rank==SCALAR) {
		copyArray(res,val);
	}
	else if (val.rank==VECTOR && val.row==1 && !val.col) {
		res->rank=SCALAR;
		res->type=val.type;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		setArrayVal(*res,1,1,identity(op));
	}
	else if (val.rank==MATRIX && (!val.row || !val.col)) {
		res->rank=SCALAR;
		res->type=val.type;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		setArrayVal(*res,1,1,identity(op));
	}
	else if (val.rank==VECTOR) {
		res->rank=SCALAR;
		res->type=val.type;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		if (isError) return;
		mres=getArrayVal(val,1,val.col);
		for (i=val.col-1;i>=1;i--) {
			mres=do_dscalar(op,getArrayVal(val,1,i),mres);
		}
		setArrayVal(*res,1,1,mres);
	}
	/* matrix reduced in rows (maintains the number of rows)*/
	else if (dir==2) {
		res->rank=VECTOR;
		res->type=val.type;
		res->row=1;
		res->col=val.row;
		res->size=res->col+1;
		dimArray(res,res->size);
		if (isError) return;
		k=1;
		for (i=1;i<=val.row;i++) {
			/* calculations proceed from right */
			mres=identity(op);
			if (op=='}' || op=='{') mres=0;
			for (j=val.col;j>=1;j--) {
				mres=do_dscalar(op,getArrayVal(val,i,j),mres);
			}
			setArrayVal(*res,1,k++,mres);
		}
	}
	/* matrix reduced in columns (maintains the number of columns)*/
	else if (dir==1) {
		res->rank=VECTOR;
		res->type=val.type;
		res->row=1;
		res->col=val.col;
		res->size=val.col+1;
		dimArray(res,res->size);
		if (isError) return;
		k=1;
		for (i=1;i<=val.col;i++) {
			/* calculations proceed from right */
			mres=identity(op);
			if (op=='}' || op=='{') mres=0;
			for (j=val.row;j>=1;j--) {
				mres=do_dscalar(op,getArrayVal(val,j,i),mres);
			}
			setArrayVal(*res,1,k++,mres);
		}
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
}


/* m_scan()
 * perform the monadic scan operator */
void m_scan(TDeclare *res, TDeclare val, char op, int dir) {
	int i,j;
	double temp;
	checkStop;

	copyArray(res,val);
	if (val.type!=NUMERIC) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* scalar is already done - no operation */
	if (val.rank==SCALAR) return;
	/* vector scan */
	else if (val.rank==VECTOR) {
		for (j=1;j<=val.col;j++) {
			if (j==1) {
				setArrayVal(*res,1,j,getArrayVal(val,1,j));
				continue;
			}
			else if (j==2) {
				setArrayVal(*res,1,j,do_dscalar(op,getArrayVal(val,1,1),getArrayVal(val,1,2)));
				continue;
			}
			else {
				int k;
				temp=getArrayVal(val,1,j); // last
				for (k=j-1;k>=1;k--)
					temp=do_dscalar(op,getArrayVal(val,1,k),temp);
				setArrayVal(*res,1,j,temp);
			}
		}	
	}
	/* matrix scan along rows (default) */
	else if (val.rank==MATRIX && dir==2) {
		for (i=1;i<=val.row;i++) {
			for (j=1;j<=val.col;j++) {
				if (j==1) {
					setArrayVal(*res,i,j,getArrayVal(val,i,j));
					continue;
				}
				else if (j==2) {
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(val,i,1),getArrayVal(val,i,2)));
					continue;
				}
				else {
					int k;
					temp=getArrayVal(val,i,j); // last
					for (k=j-1;k>=1;k--)
						temp=do_dscalar(op,getArrayVal(val,i,k),temp);
					setArrayVal(*res,i,j,temp);
				}
			}
		}
	}
	/* matrix scan along columns */
	else if (val.rank==MATRIX && dir==1) {
		for (i=1;i<=val.col;i++) {
			for (j=2;j<=val.row;j++)
				setArrayVal(*res,j,i,do_dscalar(op,getArrayVal(val,j,i),getArrayVal(val,j-1,i)));
			for (j=1;j<=val.row;j++) {
				if (j==1) {
					setArrayVal(*res,j,i,getArrayVal(val,j,i));
					continue;
				}
				else if (j==2) {
					setArrayVal(*res,j,i,do_dscalar(op,getArrayVal(val,1,i),getArrayVal(val,2,i)));
					continue;
				}
				else {
					int k;
					temp=getArrayVal(val,j,i); // last
					for (k=j-1;k>=1;k--)
						temp=do_dscalar(op,getArrayVal(val,k,i),temp);
					setArrayVal(*res,j,i,temp);
				}
			}
		}
	}
}


/* d_compress()
 * perform the compression operators / and /- */
void d_compress(TDeclare *res, TDeclare v1, TDeclare v2, int dir) {
	int i,j,k,num=0, neg=0;
	TDeclare val1, val2;
	checkStop;
	
	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	/* a scalar right argument is not extended 
	 * (see page 88 of the APL69) */	
	if (val2.rank==SCALAR) makeVector(&val2);
	/* a scalar left argument is expanded to vector 
	 * extended to apply to all elements of the right argument 
	 * (see page 88 of the APL69) */
	if (val1.row==1 && val1.col==1) {
		if (dir==2 || (dir==1 && val2.rank==VECTOR)) vectorize(&val1,val2.col);
		else if (dir==1) vectorize(&val1,val2.row);
		checkStop;
	}

	/* val1 must be a vector */
	if (val1.rank>VECTOR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto compress_go;
	}
	
	/* check conformability */
	if (dir==2 && val2.col!=val1.col) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto compress_go;
	}
	else if (dir==1 && val2.row!=val1.col && val2.rank==MATRIX) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto compress_go;
	}

	/* count positive values */
	for (i=1;i<=val1.col;i++) {
		if ((k=(int)getArrayVal(val1,1,i)) && k>0) num+=k;
		else if ((k=(int)getArrayVal(val1,1,i)) && k<0) neg+=k;
	}

	/* return empty vector in case no numeric values in val1 is true */
	if (!num && !neg) {
		copyArray(res,val1);
		res->rank=VECTOR;
		res->col=0;
		res->size=1;
		dimArray(res,res->size);
	}

	else {
		/* dimension result */
		res->type=val2.type;
		res->rank=val2.rank;
		if (dir==2 || (dir==1 && val2.rank==VECTOR)) {
			res->row=val2.row;
			res->col=num-neg;
		}
		else {
			res->row=num-neg;
			res->col=val2.col;
		}
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
	
		/* compress along columns */
		if (dir==2 || (dir==1 && val2.rank==VECTOR)) {
			int w,val;
			for (i=1;i<=val2.row;i++) {
				k=1;
				for (j=1;j<=val2.col;j++) {
					double put;
					val=getArrayVal(val1,i,j);
					if (val>0) for (w=1;w<=val;w++) {
						setArrayVal(*res,i,k++,getArrayVal(val2,i,j));
					}
					else if (val<0) for (w=1;w<=-val;w++) {
						if (val2.type==NUMERIC)
							put=0.0;
						else put=(double)' ';
						setArrayVal(*res,i,k++,put);
					}
				}
			}
		}
		/* compress along rows */
		else if (dir==1) {
			int w,val;
			k=0;
			for (i=1;i<=val2.row;i++) {
				val=getArrayVal(val1,1,i);
				for (w=1;w<=abs(val);w++) {
					double put;
					k++;
					if (val>0) for (j=1;j<=val2.col;j++) {
						setArrayVal(*res,k,j,getArrayVal(val2,i,j));
					}
					else if (val<0) for (j=1;j<=val2.col;j++) {
						if (val2.type==NUMERIC)
							put=0.0;
						else put=(double)' ';
						setArrayVal(*res,k,j,put);
					}
				}
			}
		}
	}
compress_go:
	free_(&val1);
	free_(&val2);
}


/* d_expand()
 * perform the expansion operators \ and \- 
 * works also in replication, and if used only with ones and zeroes
 * it works as in the APL\1130 */
void d_expand(TDeclare *res, TDeclare v1, TDeclare v2, int dir) {
	int i,j,k,w;
	int num=0, neg=0, pos=0, filler=0;
	TDeclare val1,val2;
	checkStop;

	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	
	/* val1 cannot be a matrix */
	if (val1.rank>VECTOR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto expand_go;
	}
	/* and if val1 is a scalar, it is vectorized */
	else if (val1.rank==SCALAR) {
		vectorize(&val1,1);
		if (isError || isInterrupt) goto expand_go;
	}
	
	/* the scalar right argument is vectorized */
	if (val2.rank==SCALAR) {
		vectorize(&val2,num);	
		if (isError || isInterrupt) goto expand_go;
	}

	/* in case of expansion of a vector, force \ and not \- */
	if (val2.rank==VECTOR) dir=2;

	/* count positive values and evaluate
	 * positive, null and negative quantities */
	for (i=1;i<=val1.col;i++) {
		k=getArrayVal(val1,1,i);
		if (!k) neg+=1;
		else if (k<0) neg+=-k;
		else if (k>0) num++, pos+=k;
	}

	/* conformance */
	if (dir==2 && num!=val2.col) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto expand_go;
	}
	else if (dir==1 && num!=val2.row) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto expand_go;
	}

	/* set filler */
	if (val2.type==STRING) filler=' ';

	/* dimension result */
	res->type=val2.type;
	res->rank=val2.rank;
	if (dir==2) {
		res->row=val2.row;
		res->col=neg+pos;
	}
	else {
		res->row=neg+pos;
		res->col=val2.col;
	}
	res->size=res->row*res->col+1;
	dimArray(res,res->size);

	/* expand columns */
	if (dir==2) {
		for (i=1;i<=res->row;i++) {
			int h=0,f=1;
			for (j=1;j<=res->col;j++) {
				h++;
				k=getArrayVal(val1,1,h);
				if (!k) {
					setArrayVal(*res,i,j,filler);
				}
				else if (k<0) {
					for (w=0;w<-k;w++)
						setArrayVal(*res,i,j+w,filler);
					j=j-k-1;
				}
				else { 
					for (w=0;w<k;w++)
						setArrayVal(*res,i,j+w,getArrayVal(val2,i,f));
					j=j+k-1;
					f++;
				}
			}
		}
	}
	/* expand rows */
	else if (dir==1) {
		for (i=1;i<=res->col;i++) {
			int h=0,f=1;
			for (j=1;j<=res->row;j++) {
				h++;
				k=getArrayVal(val1,1,h);
				if (!k) {
					setArrayVal(*res,j,i,filler);
				}
				else if (k<0) {
					for (w=0;w<-k;w++)
						setArrayVal(*res,j+w,i,filler);
					j=j-k-1;
				}
				else { 
					for (w=0;w<k;w++)
						setArrayVal(*res,j+w,i,getArrayVal(val2,f,i));
					j=j+k-1;
					f++;
				}
			}
		}
	}
expand_go:
	free_(&val1);
	free_(&val2);
}


/******************************************
 *	    APL RHO INTERFACE	          *
 ******************************************/
/* fillRavel()
 * using the vector in ravel, fill object *res
 * if ravel is longer than needed, the excessive items are ignored
 * if ravel is shorer than needed, the items are repeated from first 
 * System function for d_rho() */
void fillRavel(TDeclare *res, TDeclare ravel) {
	int i,j,r=1;
	checkStop;

	if (ravel.rank!=VECTOR || res->rank==SCALAR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	for (i=1;i<=res->row;i++) {
		for (j=1;j<=res->col;j++) {
			setArrayVal(*res,i,j,getArrayVal(ravel,1,r++));
			if (r>ravel.col) r=1;
		}
	}
}


/* d_rho()
 * perform the rho dyadic operator 
 * dims is the list at the left, which may be a vector or a scalar 
 * rav is the list on the right, which may be anything */
void d_rho(TDeclare *res, TDeclare dims, TDeclare rav) {
	TDeclare ravel;
	checkStop;
	setArray(&ravel);
	copyArray(&ravel,rav);

	if (dims.rank>VECTOR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto rho_go;
	}
	if (dims.col>2) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		goto rho_go;
	}
	/* "Cannot make something out of nothing 
	 * so if left or right argument is an empty vector,
	 * return an empty vector" 
	 * This is my original assessment, but then
	 * I checked against TryAPL, and noticed that:
	 * (i0)p(i0)    generate scalar zero 
	 * (i0)pX	generates scalar = X[1;1]
	 * Npi0		generates zero-vector dim N
	 * Vpi0		generates zero matrix dim V
	 * So I had to change my mind... */
	/* both arguments are empty vectors */
	if (dims.row==1 && !dims.col && ravel.row==1 && !ravel.col) {
		res->type=NUMERIC;
		res->rank=SCALAR;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		setArrayVal(*res,1,1,0);
		goto rho_go;
	}
	/* left arguments is an empty vectors 
	 * return a scalar */
	else if (dims.row==1 && !dims.col) {
		res->type=NUMERIC;
		res->rank=SCALAR;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		setArrayVal(*res,1,1,getArrayVal(ravel,1,1));
		goto rho_go;
	}
	/* right arguments is an empty vectors 
	 * return a zero-object */
	else if (ravel.row==1 && !ravel.col) {
		int i,j;
		res->type=NUMERIC;
		if (dims.rank==SCALAR) {
			res->rank=VECTOR;
			res->row=1;
			res->col=dims.col;
		}
		else {
			res->rank=MATRIX;
			res->row=getArrayVal(dims,1,1);
			res->col=getArrayVal(dims,1,2);
		}
		res->size=res->row*res->size+1;
		dimArray(res,res->size);
		for (i=1;i<=res->row;i++)
			for (j=1;j<=res->col;j++)
				setArrayVal(*res,i,j,0);
		goto rho_go;
	}

	/* Normal behaviour, also contemplated
	 * in the APL68, APL69 and APL70;
	 * ravel right argument in case it is not a vector */
	if (ravel.rank==MATRIX || ravel.rank==SCALAR) {
		makeVector(&ravel);
	}
	/* return a vector from a scalar*/
	if ((dims.rank==SCALAR || (dims.rank==VECTOR && dims.col==1)) && ravel.type==NUMERIC) {
		int col=getArrayVal(dims,1,1);
		if (col<0) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}
		/*else if (col>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}*/
		res->rank=VECTOR;
		res->type=NUMERIC;
		res->row=1;
		res->col=col;
		res->size=col+1;
		/* in case column is zero, it is an empty vector */
		if (!res->col) res->row=res->size=1;
		dimArray(res,res->size);
		if (isError) goto rho_go;
		fillRavel(res,ravel);
	}
	/* return a string from a char */
	else if ((dims.rank==SCALAR || (dims.rank==VECTOR && dims.col==1)) && ravel.type==STRING) {
		int col=getArrayVal(dims,1,1);
		if (col<0) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}
		/*else if (col>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}*/
		res->rank=VECTOR;
		res->type=STRING;
		res->row=1;
		res->col=col;
		res->size=col+1;
		dimArray(res,res->size);
		if (isError) goto rho_go;
		fillRavel(res,ravel);
	}
	/* return a numeric matrix */
	else if (dims.rank==VECTOR && ravel.type==NUMERIC) {
		int row=getArrayVal(dims,1,1);
		int col=getArrayVal(dims,1,2);
		if (col<0 || row<0) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}
		else if (!col && !row) col=0, row=1;
		else if (col && !row) col=0, row=1;
		/*if (col>=COMPSTR || row>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_g;
		}*/
		res->rank=MATRIX;
		res->type=NUMERIC;
		res->row=row;
		res->col=col;
		res->size=row*col+1;
		dimArray(res,res->size);
		if (isError) goto rho_go;
		fillRavel(res,ravel);
	}
	/* return a string matrix */
	else if (dims.rank==VECTOR && ravel.type==STRING) {
		int row=getArrayVal(dims,1,1);
		int col=getArrayVal(dims,1,2);
		if (col<0 || row<0) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}
		/*if (col>=COMPSTR || row>=COMPSTR) {
			perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
			goto rho_go;
		}*/
		res->rank=MATRIX;
		res->type=STRING;
		res->row=row;
		res->col=col;
		res->size=row*col+1;
		dimArray(res,res->size);
		if (isError) goto rho_go;
		fillRavel(res,ravel);
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
rho_go:
	free_(&ravel);
} 


/* m_rho()
 * perform the rho monadic operator */
void m_rho(TDeclare *res, TDeclare val) {
	checkStop;

	if (val.rank==SCALAR) {
		res->rank=VECTOR;
		res->type=NUMERIC;
		res->row=1;
		res->col=0;
		res->size=1;
		dimArray(res,res->size);
		if (isError) return;
	}
	else if (val.rank==VECTOR) {
		res->rank=VECTOR;
		res->type=NUMERIC;
		res->row=1;
		res->col=1;
		res->size=2;
		dimArray(res,res->size);
		if (isError) return;
		setArrayVal(*res,1,1,val.col);
	}
	else if (val.rank==MATRIX) {
		res->rank=VECTOR;
		res->type=NUMERIC;
		res->row=1;
		res->col=2;
		res->size=3;
		dimArray(res,res->size);
		if (isError) return;
		setArrayVal(*res,1,1,val.row);
		setArrayVal(*res,1,2,val.col);
	}
}


/******************************************
 *	    APL IOTA INTERFACE	          *
 ******************************************/
/* m_iota()
 * perform the iota monadic operator, generating 
 * a series of indices from 1 to the argument value,
 * which must be an integer */
void m_iota(TDeclare *res, TDeclare val) {
	int lim, i, k;
	checkStop;

	k=1-indexOrigin;
	/* cannot make something out of nothing */
	if (val.col!=1 || val.row!=1) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	lim=(int)getArrayVal(val,1,1);
	if (lim<0) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/*if (lim>=COMPSTR) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}*/
	res->rank=VECTOR;
	res->type=NUMERIC;
	res->row=1;
	res->col=lim;
	res->size=lim+1;
	dimArray(res,res->size);
	if (isError) return;
	for (i=1;i<=res->col;i++)
		setArrayVal(*res,1,i,i-k);
}


/* checkVectorInMat()
 * check if vector vec is a row in matrix mat 
 * used in d_iota() */
int checkVectorInMat(TDeclare vec, TDeclare mat) {
	int res=TRUE;
	int i,j;
	double d1,d2;
	for (i=1;i<=mat.row;i++) {
		res=TRUE;
		for (j=1;j<=mat.col;j++) {
			d1=getArrayVal(vec,1,j);
			d2=getArrayVal(mat,i,j);
			if (d1!=d2) {
				res=FALSE;
				break;
			}
		}
		if (res) return i;
	}
	return FALSE;
}


/* d_iota()
 * search in vector val1 all the items specified in the object val2, which may
 * be a scalar, a vector or a matrix. 
 * res is of the same rank of val2, but classified as NUMERIC */
void d_iota(TDeclare *res, TDeclare val1, TDeclare val2) {
	int i,j,k,ko;
	double curr, vc;
	checkStop;

	ko=1-indexOrigin;
	if (val1.rank==MATRIX && val2.rank==VECTOR && val2.col==val1.col) {
		int val;
		res->type=NUMERIC;
		res->rank=SCALAR;
		res->row=res->col=1;
		res->size=2;
		dimArray(res,res->size);
		val=checkVectorInMat(val2,val1);
		if (val) setArrayVal(*res,1,1,val-ko);
		else setArrayVal(*res,1,1,val1.row+1-ko);
		return;
	}
	/* Only vectors here */
	/*else if (val1.rank!=VECTOR) {
		perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
		return;
	}*/
	/* case of vectors*/
	copyArray(res,val2);
	res->type=NUMERIC;
	for (i=1;i<=val2.row;i++) {
		for (j=1;j<=val2.col;j++) {
			curr=getArrayVal(val2,i,j);
			for (k=1;k<=val1.col;k++) {
				vc=getArrayVal(val1,1,k);
				if (vc==curr) {
					setArrayVal(*res,i,j,k-ko);
					break;
				}
			}
			if (k>val1.col) setArrayVal(*res,i,j,k-ko);
		}
	}
}


/******************************************
 *	 MATH & TOOLS INTERFACE	          *
 ******************************************/
/* min()
 * return the minimum between val1 and val2
 * System function for { and } */
double min(double val1, double val2) {
	double diff=val1-val2;
	if (diff==0.0) return val1;
	else if (fabs(diff)<fabs(Wcomp)) return val1;
	else if (diff>0) return val2;
	return val1;
}


/* max()
 * return the maximum between val1 and val2
 * System function for { and } */
double max(double val1, double val2) {
	double diff=val1-val2;
	if (diff==0.0) return val1;
	else if (fabs(diff)<fabs(Wcomp)) return val1;
	else if (diff>0) return val1;
	return val2;
}


/* sign()
 * return 1 if the argument is positive,
 * -1 if the argument is negative
 * and 0 if it is zereo */
double sign(double val) {
	if (val>0) return 1.0;
	else if (val<0) return -1.0;
	return 0.0;
}


/* ceiling()
 * return the highest integer with respect to val */
double ceiling(double val) {
	double res=0.0, nval;
	if (fabs(val)<fabs(Wcomp)) nval=0;
	else nval=val;
	if (fabs((double)(nval-(int)nval))>fabs(Wcomp)) {
		if (nval>0) res=(int)(nval+1);
		else res=(int)(nval);
	}
	else res=(int)nval;
	return res;
}


/* floor()
 * return the lowest integer with respect to val */
double floor(double val) {
	double res=0.0, nval;
	if (fabs(val)<fabs(Wcomp)) nval=0;
	else nval=val;
	if (fabs((double)(nval-(int)nval))>fabs(Wcomp)) {
		if (nval>0) res=(int)nval;
		else res=(int)(nval-1);
	}
	else res=(int)nval;
	return res;
}


/* radix()
 * calculate the r root of x within the usage
 * of the operator ensemble *% (RADI) */
double radix(double x, double r) {
	if (r==0.0) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	else if (x<=0.0 && r<0.0) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	else if (x<0.0) {
	       	if (r==(int)r && ((int)r)%2==1) {
			return -pow(-x,1.0/r);
		}
		else {
			perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
			return 0.0;
		}
	}
	else if (x==0.0 && r>0.0) {
		return 0.0;
	}
	return pow(x,1.0/r);
}


/* power()
 * calculate the power of x^e */
double power(double x, double e) {
	if (e==0.0) 
		return 1.0;
	else if (x<0.0) {
		if (e==(int)e && ((int)e)%2==1) {
			return -pow(-x,e);
		}
		else if (e==(int)e && ((int)e)%2==0) {
			return pow(-x,e);
		}
		else if (!Wdiv) {
			return 0.0;
		}
		else {
			perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
			return 0.0;
		}
	}
	else if (x==0.0 && e>0.0)
		return 0.0;
	else if (x==0.0 && e<0.0 && !Wdiv) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	else if (x==0.0 && e<0.0)
		return 0.0;
	return pow(x,e);
}


/* isRadix()
 * test if the operator is *% possibly with blanks inside */
int isRadix(char *s) {
	int t=0;
	if (*s!='*') return FALSE;
	s++;
	t++;
	while (isblank(*s)) s++, t++;
	if (*s=='%') return t+1;
	return FALSE;
}


/* resi()
 * perform the residual calculus for the division of val1 by val2
 * System function for do_dscalar() */
double resi(double val1,double val2) {
	double add=0,ret=0.0;
	if (val1<0) add=val1;
	ret=val2-fabs(val1)*floor(val2/fabs(val1))+add;
	return ret;
}


/* combi()
 * calculate the binomial value beween val1 in val2
 * using the tgamma function */
double combi(double val1, double val2) {
	double res=0.0;
	if (val2==0.0) res=0.0;
	else {
		if (val2<0.0) val2=-val2+1.0;
		res=tgamma(val2+1.0)/(tgamma(val1+1.0)*tgamma(val2-val1+1.0));
	}
	return res;
}


/* gcd()
 * return the Greatest Common Divisor between n1 and n2
 * Note: uses the residual APL function resi() */
double gcd(double n1, double n2) {
	double N1=fabs(n1), N2=fabs(n2);
	long long int tim=1L;
	long long int M1=0, M2=0, count=0;
	/* do checks */
	if (N1>1E8) N1=1E8;
	if (N1<1E-8) N1=0;
	if (N2>1E8) N2=1E8;
	if (N2<1E-8) N2=0;
	if (relation(N1,0.0)==1) return N2;
	if (relation(N2,0.0)==1) return N1;
	/* transform numbers in quasi-integers */
	while ((N1!=(int)N1 || N2!=(int)N2) && count<8) {
		count++;
		N1*=10.0;
		N2*=10.0;
		tim*=10L;
	}
	M1=labs((int)N1);
	M2=labs((int)N2);
	/* calcolo GCD using the pure Euclidean method */
	while (M1!=M2) {
		if (M1>M2) M1=M1-M2;
		else M2=M2-M1;
	}
	/* return value */
        return (((double)M1)/(tim*1.0));
}


/* lcm()
 * return the Least Common Multiple between n1 and n2 
 * See also 
 * https://stackoverflow.com/questions/3154454/what-is-the-most-efficient-way-to-calculate-the-least-common-multiple-of-two-int */
double lcm(double n1, double n2) {
	double sig=sign(n1)*sign(n2);
	double N1=fabs(n1), N2=fabs(n2);
	/* do checks */
	if (N1>1E8) N1=1E8;
	if (N1<1E-8) N1=0;
	if (N2>1E8) N2=1E8;
	if (N2<1E-8) N2=0;
	if (relation(N1,0.0)==1) return 0.0;
	if (relation(N2,0.0)==1) return 0.0;
	/* get LCM using GCM */
	N1=(fabs(n1)/gcd(n1,n2))*fabs(n2);
	/* return value */
        return sig*N1;
}


/* logicand()
 * return 1 if val1 && val2 occurs according to Wcomp
 * otherwise return 0 */
int logicand(double val1, double val2) {
	int v1=val1!=0.0,v2=val2!=0.0;
	if (fabs(val1)<fabs(Wcomp)) v1=0;
	if (fabs(val2)<fabs(Wcomp)) v2=0;
	if (v1==1 && v2==1) return 1;
	return 0;
}


/* logicor()
 * return 1 if val1 || val2 occurs according to Wcomp
 * otherwise return 0 */
int logicor(double val1, double val2) {
	int v1=val1!=0.0,v2=val2!=0.0;
	if (fabs(val1)<fabs(Wcomp)) v1=0;
	if (fabs(val2)<fabs(Wcomp)) v2=0;
	if (v1==1 || v2==1) return 1;
	return 0;
}


/* relation()
 * return 1 if val1 == val2 according to Wcomp 
 * return 2 if val1 >  val2 according to Wcomp
 * return 3 if val1 <  val2 according to Wcomp */
int relation(double val1, double val2) {
	double diff=val1-val2;
	/* note: the following is necessary, because in case Wcomp is zero,
	 * it would fail and return 3 in case diff is zero (and thus
	 * val1 and val2 are perfectly equal) */
	if (diff==0.0) return 1;
	if (fabs(diff)<=fabs(Wcomp)) return 1;
	if (diff>0) return 2;
	return 3;
}


/* nand()
 * Not And function
 * Note: works only on 0 and 1 */
double nand(double n1, double n2) {
	if (relation(n1,0.0)!=1 && relation(n1,1.0)!=1) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	if (relation(n2,0.0)!=1 && relation(n2,1.0)!=1) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	return !logicand(n1,n2);
}


/* nor()
 * Not Or function
 * Note: works only on 0 and 1 */
double nor(double n1, double n2) {
	if (relation(n1,0.0)!=1 && relation(n1,1.0)!=1) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	if (relation(n2,0.0)!=1 && relation(n2,1.0)!=1) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}
	return !logicor(n1,n2);
}


/*****************************************
 *      INNER ENGINE PROCESSORS          *
 *****************************************/
/* d_inner()
 * perform the inner product calculus */
void d_inner(TDeclare *res, TDeclare v1, TDeclare v2, char leftop, char rightop) {
	int i,j,k;
	double ret,interm;
	TDeclare val1, val2;
	checkStop;

	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	/* in case of both scalar or univectors, 
	 * perform direct math operation and return a scalar */
	if (val1.row==1 && val1.col==1 && val2.row==1 && val2.col==1) {
		copyArray(res,val1);
		res->rank=SCALAR;
		setArrayVal(*res,1,1,do_dscalar(rightop, getArrayVal(val1,1,1),getArrayVal(val2,1,1)));
		if (islogic(rightop)) res->type=NUMERIC;
		goto inner_go;
	}

	/* if val1 is a scalar or univector, promote it to vector */
	if (val1.col==1 && val1.row==1) vectorize(&val1,val2.row);
	/* if val2 is a scalar or univector, promote it to vector */
	if (val2.col==1 && val2.row==1) vectorize(&val2,val1.col);
	checkStop;

	/* if val1 is a vector, turn to MATRIX */
	if (val1.rank==VECTOR) val1.rank=MATRIX;

	/* if val2 is a vector, verticalize it */
	if (val2.rank==VECTOR && val1.col!=1) verticalize(&val2);
	else val2.rank=MATRIX;

	/* perform matrix to matrix if conformant */
	if (val1.col==val2.row) {
		res->type=max(val1.type,val2.type);
		res->row=val1.row;
		res->col=val2.col;
		if (res->row==1 && res->col==1) res->rank=SCALAR;
		else if (res->row==1) res->rank=VECTOR;
		else if (res->col==1) res->rank=MATRIX;
		else res->rank=MATRIX;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) goto inner_go;
		for (k=val2.col;k>=1;k--) {
			for (i=val1.row;i>=1;i--) {
				ret=identity(leftop);
				for (j=val1.col;j>=1;j--) {
					interm=do_dscalar(rightop,getArrayVal(val1,i,j),getArrayVal(val2,j,k));
					ret=do_dscalar(leftop,ret,interm);
				}
				setArrayVal(*res,i,k,ret);
			}
		}
	}
	else {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		goto inner_go;
	}
	if (islogic(rightop)) res->type=NUMERIC;
inner_go:
	free_(&val1);
	free_(&val2);
}


/* d_outer() 
 * perform the outer product calculus
 * Note: as stated in table 3.7 of the 1969 manual,
 * the outer product has a meaning only for vector to vector;
 * vector to matrix or matrix to matrix are not contempled 
 * and in all other cases (namely scalar to scalar, scalar to vector 
 * and scalar to matrix) this is simply a scalar function */
void d_outer(TDeclare *res, TDeclare val1, TDeclare val2, char op) {
	checkStop;

	if (val1.rank==MATRIX && val2.rank==MATRIX) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if ((val1.rank==VECTOR && val2.rank==MATRIX) || (val1.rank==MATRIX && val2.rank==VECTOR)) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (val1.rank==VECTOR && val2.rank==VECTOR) {
		int i,j;
		res->rank=MATRIX;
		res->type=max(val1.type,val2.type);
		res->row=val1.col;
		res->col=val2.col;
		res->size=res->row*res->col+1;
		dimArray(res,res->size);
		if (isError) return;
		for (i=1;i<=res->row;i++)
			for (j=1;j<=res->col;j++)
				setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(val1,1,i),getArrayVal(val2,1,j)));
	}
	else do_scalar_dyadic(res,op,val1,val2);
	if (islogic(op)) res->type=NUMERIC;
}


/* do_scalar_dyadic()
 * dyadic scalar operator functions */
void do_scalar_dyadic(TDeclare *res, char op, TDeclare add1, TDeclare add2) {
	int i,j;
	double val;
	checkStop;

	/* check for type */
	if (add1.type!=add2.type) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* strings can only use = and # */
	if (add1.type==STRING && op!='=' && op!='#') {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* check compatibility */
	if (add1.rank==VECTOR && add2.rank==VECTOR) {
		if (add1.col!=add2.col) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			return;
		}
	}
	else if (add1.rank==MATRIX && add2.rank==MATRIX) {
		if (add1.col!=add2.col || add1.row!=add2.row) {
			perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
			return;
		}
	}
	/* both numeric */
	if (add1.type==NUMERIC && add2.type==NUMERIC) {
		if (add1.rank==SCALAR && add2.rank==SCALAR) {
			copyArray(res,add2);
			setArrayVal(*res,1,1,do_dscalar(op,*add1.elem,*add2.elem));
		}
		else if (add1.rank==SCALAR && add2.rank>SCALAR) {
			copyArray(res,add2);
			for (i=1;i<=add2.row;i++) 
				for (j=1;j<=add2.col;j++)
					setArrayVal(*res,i,j,do_dscalar(op,*add1.elem,getArrayVal(add2,i,j)));
		}
		else if (add1.rank==VECTOR && add1.row==1 && add1.col==1 && add2.rank>SCALAR) {
			copyArray(res,add2);
			val=getArrayVal(add1,1,1);
			for (i=1;i<=add2.row;i++) {
				for (j=1;j<=add2.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,val,getArrayVal(add2,i,j)));
				}
			}
		}
		else if (add1.rank>SCALAR && add2.rank==SCALAR) {
			copyArray(res,add1);
			for (i=1;i<=add1.row;i++) 
				for (j=1;j<=add1.col;j++)
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(add1,i,j),*add2.elem));
		}
		else if (add1.rank>SCALAR && add2.rank==VECTOR && add2.row==1 && add2.col==1) {
			copyArray(res,add1);
			val=getArrayVal(add2,1,1);
			for (i=1;i<=add1.row;i++) {
				for (j=1;j<=add1.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(add1,i,j),val));
				}
			}
		}
		else if (add1.rank==add2.rank && add1.row==add2.row && add1.col==add2.col) {
			copyArray(res,add1);
			for (i=1;i<=add1.row;i++) 
				for (j=1;j<=add1.col;j++)
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(add1,i,j),getArrayVal(add2,i,j)));
		}
		else {
			perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		}
	}
	/* both strings */
	else if (add1.type==STRING && add2.type==STRING) {
		if (add1.rank==SCALAR && add2.rank==SCALAR) {
			copyArray(res,add1);
			setArrayVal(*res,1,1,do_dscalar(op,*add1.elem,*add2.elem));
			if (_logic) res->type=NUMERIC;
		}
		else if (add1.rank==SCALAR && add2.rank>SCALAR) {
			copyArray(res,add2);
			for (i=1;i<=add2.row;i++) {
				for (j=1;j<=add2.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,*add1.elem,getArrayVal(add2,i,j)));
					if (_logic) res->type=NUMERIC;
				}
			}
		}
		else if (add1.rank==VECTOR && add1.row==1 && add1.col==1 && add2.rank>SCALAR) {
			copyArray(res,add2);
			val=getArrayVal(add1,1,1);
			for (i=1;i<=add2.row;i++) {
				for (j=1;j<=add2.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,val,getArrayVal(add2,i,j)));
					if (_logic) res->type=NUMERIC;
				}
			}
		}
		else if (add1.rank>SCALAR && add2.rank==SCALAR) {
			copyArray(res,add1);
			for (i=1;i<=add1.row;i++) {
				for (j=1;j<=add1.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(add1,i,j),*add2.elem));
					if (_logic) res->type=NUMERIC;
				}
			}
		}
		else if (add1.rank>SCALAR && add2.rank==VECTOR && add2.row==1 && add2.col==1) {
			copyArray(res,add1);
			val=getArrayVal(add2,1,1);
			for (i=1;i<=add1.row;i++) {
				for (j=1;j<=add1.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(add1,i,j),val));
					if (_logic) res->type=NUMERIC;
				}
			}
		}
		else if (add1.rank==add2.rank && add1.row==add2.row && add1.col==add2.col) {
			copyArray(res,add1);
			for (i=1;i<=add1.row;i++) { 
				for (j=1;j<=add1.col;j++) {
					setArrayVal(*res,i,j,do_dscalar(op,getArrayVal(add1,i,j),getArrayVal(add2,i,j)));
					if (_logic) res->type=NUMERIC;
				}
			}
		}
		else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		if (islogic(op)) res->type=NUMERIC;
	}
	/* mixed */
	else if (op=='=' || op=='#') {
		int ret=1;
		if (op=='=') {
			if (add1.rank==SCALAR && add2.rank==SCALAR) {
				eraseDEC(res);
				ret*=getArrayVal(add1,1,1)==getArrayVal(add2,1,1);
				setArrayVal(*res,1,1,ret);
			}
			else if (add1.col==add2.col && add1.row==add2.row) {
				copyArray(res,add1);
				res->type=NUMERIC;
				for (i=1;i<=add1.row;i++) { 
					for (j=1;j<=add1.col;j++) {
						setArrayVal(*res,i,j,getArrayVal(add1,i,j)==getArrayVal(add2,i,j));
					}
				}
			}
			else ret=0;
		}
		else if (op=='#') {
			if (add1.rank==SCALAR && add2.rank==SCALAR) {
				eraseDEC(res);
				ret*=getArrayVal(add1,1,1)!=getArrayVal(add2,1,1);
				setArrayVal(*res,1,1,ret);
			}
			else if (add1.col==add2.col && add1.row==add2.row) {
				copyArray(res,add1);
				res->type=NUMERIC;
				for (i=1;i<=add1.row;i++) { 
					for (j=1;j<=add1.col;j++) {
						setArrayVal(*res,i,j,getArrayVal(add1,i,j)!=getArrayVal(add2,i,j));
					}
				}
			}
			else ret=1;
		}
	}
	else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
}


/* do_scalar_monadic()
 * monadic scalar operator functions */
void do_scalar_monadic(TDeclare *res, char op, TDeclare add1) {
	int i,j;
	checkStop;

	/* strings cannot be used here */
	if (add1.type==STRING) {
		perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* numeric */
	if (add1.type==NUMERIC) {
		if (add1.rank==SCALAR) {
			copyArray(res,add1);
			setArrayVal(*res,1,1,do_mscalar(op,*add1.elem));
		}
		else {
			copyArray(res,add1);
			for (i=1;i<=add1.row;i++) 
				for (j=1;j<=add1.col;j++)
					setArrayVal(*res,i,j,do_mscalar(op,getArrayVal(add1,i,j)));
		}
	}
	/* string  */
	else if (add1.type==STRING) {
		if (add1.rank==SCALAR) {
			copyArray(res,add1);
			setArrayVal(*res,1,1,do_mscalar(op,*add1.elem));
		}
		else {
			copyArray(res,add1);
			for (i=1;i<=add1.row;i++) {
				for (j=1;j<=add1.col;j++) {
					setArrayVal(*res,i,j,do_mscalar(op,getArrayVal(add1,i,j)));
				}
			}
		}
	}
	else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
}


/******************************************
 *	    TRIG INTERFACE	          *
 ******************************************/
/* do_trig()
 * perform the basic scalar functions for the circular operator
 * (mainly trigonometry) */
double do_trig(int val, double arg) {
	double ret=0, interm=0;
	switch (val) {
		/* arctanh */
		case -7: 
			if (arg==-1.0) ret=-1.0/0.0;
			else if (arg==1.0) ret=1.0/0.0;
			else ret=0.5*log((1.0+arg)/(1.0-arg));	
			break;
		/* arccosh */
		case -6: 
			if (arg<1.0) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				return 0.0;
			}
			ret=log(arg+sqrt(arg*arg-1.0));
			break;
		/* arcsinh */
		case -5:
		       	ret=log(arg+sqrt(1+arg*arg));
			break;	
		/* cathetus 2 */
		case -4:
			interm=(-1+arg*arg);
			if (interm<0) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				return 0.0;
			}
			ret=sqrt(interm);
			break;
		/* arctan */
		case -3: 
			ret=atan(arg);
			break;
		/* arccos */
		case -2: 
			if (arg<-1.0 || arg>1.0) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				return 0.0;
			}
			ret=acos(arg);
			break;
		/* arcsin */
		case -1:
			if (arg<-1.0 || arg>1.0) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				return 0.0;
			}
			ret=asin(arg);
			break;
		/* cathetus 1 */
		case 0: 
			interm=1-arg*arg;
			if (interm<0) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				return 0.0;
			}
			ret=sqrt(interm);
			break;
		/* sine */
		case 1: 
			ret=sin(arg);
			break;
		/* cosine */
		case 2: 
			ret=cos(arg);
			break;
		/* tangent */
		case 3: 
			ret=tan(arg);
			break;
		/* hypotenuse */
		case 4: 
			ret=sqrt(1+arg*arg);
			break;
		/* sinh */
		case 5: 
			ret=(-exp(-arg)+exp(arg))/2.0;
			break;
		/* cosh */
		case 6: 
			ret=(exp(-arg)+exp(arg))/2.0;
			break;
		/* tanh */
		case 7: 
			ret=(exp(arg)-exp(-arg))/(exp(arg)+exp(-arg));
			break;
		/* ADDED FUNCTIONS */
		/* natural log of absolute gamma value */
		case -9:
			ret=lgamma(arg);
			break;
		/* erfc */
		case -8:
			ret=erf(arg);
			break;
		/* erf */
		case 8:
			ret=erf(arg);
			break;
		/* gamma value */
		case 9:
			ret=tgamma(arg);
			break;
		/* round to the nearest integer */
		case 10:
			ret=(int)(arg+sign(arg)*0.5);
			break;	
		default: 
			perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
			break;
	}
	return ret;
}



/******************************************
 *	  MATRIX CALCULUS INTERFACE	  *
 ******************************************/
/* eraseDEC()
 * removes res structures and set for a null scalar 
 * (i.e. an element with rank SCALAR, type NUMERIC and content 0)*/
void eraseDEC(TDeclare *res) {
	checkStop;

	strncpy_(res->name,VOIDS,NAMESTR);
	res->rank=SCALAR;
	res->type=NUMERIC;
	res->row=1;
	res->col=1;
	res->size=2;
	free_(res);
}


/* takeRowCol()
 * returns in row and col the necessary 
 * F[4] for vectors 
 * F[1 4] for vectors 
 * F[1 4;2 4] for matrices 
 * F[;2 4] for matrices 
 * F[1 4;[ for matrices
 * F[;] for matrices 
 * Uses p; p must point to [ */
void takeRowCol(TDeclare base, TDeclare *row, TDeclare *col) {
	checkStop;

	free_(row);
	free_(col);
	row->row=row->col=0;
	col->row=col->col=0;
	if (*p=='[') p++; // skip [
	/* take regular vector col */
	if (base.rank==VECTOR) {
		int i;
		instScalar(row,0);
		row->col=0;
		if (*p==']') {
			col->size=base.col+1;
			col->type=NUMERIC;
			col->rank=VECTOR;
			col->col=base.col;
			col->row=1;
			dimArray(col,col->size);
			for (i=1; i<=base.col; i++) 
				setArrayVal(*col,1,i,i);
		}
		else {
			/* attribute vector to col */
			expression(col);
		}
	}
	/* error for scalars */
	else if (base.rank==SCALAR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* shortcut for 'all matrix row elements' */
	else if (*p==';') {
		int i;
		p++; // skip ;
		row->size=base.row+1;
		row->type=NUMERIC;
		row->rank=VECTOR;
		row->col=base.row;
		row->row=1;
		dimArray(row,row->size);
		for (i=1; i<=base.row; i++) 
			setArrayVal(*row,1,i,i);
		/* all matrix columns elements */
		if (*p==']') {
			col->size=base.col+1;
			col->type=NUMERIC;
			col->rank=VECTOR;
			col->col=base.col;
			col->row=1;
			dimArray(col,col->size);
			for (i=1; i<=base.col; i++) 
				setArrayVal(*col,1,i,i);
		}
		else {
			expression(col);
		}
	}
	/* take regular matrix row and col */
	else if (*p && *p!=']') {
		/* attribute first vector to col */
		expression(col);
		/* this is a matrix */
		if (*p==';') {
			p++; // skip ;
			/* copy col to row */
			copyArray(row,*col);
			/* short cut for 'take all columns items' */
			if (*p==']') {
				int i;
				p++; // skip ;
				col->size=base.col+1;
				col->type=NUMERIC;
				col->rank=VECTOR;
				col->col=base.col;
				col->row=1;
				dimArray(col,col->size);
				for (i=1; i<=base.col; i++) 
					setArrayVal(*col,1,i,i);
			}
			else {
				expression(col);
			}
		}
		else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
	}
	/* shortcut for 'all elements' [] */
	else {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	if (*p==']') p++;
} // end of takeRowCol()


/* assignSubArray()
 * assign in res objects extracting from base the elements
 * defined by row and col:
 * if base is a vector (I is ignored):
 *   if J is a scalar, res is a scalar
 *   if J is a vector, res is vector
 *   if J is a matrix, res is matrix
 * if base is a matrix:
 *   if I and J are scalars, res is a scalar 
 *   if I and J are vectors, res is a matrix
 *   if I is a vector and J is a scalar res is a vector
 *   if I is a scalar and J is a vector res is a vector
 *   if I is a matrix and J is a scalar res is a matrix
 *   if I is a scalar and J is a matrix res is a matrix
 *   else rank error */
void assignSubArray(TDeclare *res, TDeclare value, TDeclare I, TDeclare J) {
	int i, j, trow, tcol;
	int k=1-indexOrigin;
	if (res->rank==VECTOR) {
		if (J.rank==SCALAR && !I.col && value.rank==SCALAR) {
			tcol=getArrayVal(J,1,1)+k;
			if (tcol>res->col) {
				perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
				return;
			}
			setArrayVal(*res,1,tcol,getArrayVal(value,1,1));
		}
		else if (J.rank==VECTOR && !I.col && value.rank==VECTOR && J.col==value.col) {
			for (j=1;j<=J.col;j++) {
				tcol=getArrayVal(J,1,j)+k;
				if (tcol>res->col) {
					perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
					return;
				}
				setArrayVal(*res,1,tcol,getArrayVal(value,1,j));
			}
		}
		else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
	}
	else if (res->rank==MATRIX) {
		if (I.rank==SCALAR && J.rank==SCALAR && value.rank==SCALAR) {
			trow=getArrayVal(I,1,1)+k;
			tcol=getArrayVal(J,1,1)+k;
			if (trow>res->row || tcol>res->col) {
				perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
				return;
			}
			setArrayVal(*res,trow,tcol,getArrayVal(value,1,1));
		}
		else if (I.rank==SCALAR && J.rank==VECTOR && value.rank==VECTOR && J.col==value.col) {
			trow=getArrayVal(I,1,1)+k;
			for (j=1;j<=J.col;j++) {
				tcol=getArrayVal(J,1,j)+k;
				if (trow>res->row || tcol>res->col) {
					perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
					return;
				}
				setArrayVal(*res,trow,tcol,getArrayVal(value,1,j));
			}
		}
		else if (I.rank==VECTOR && J.rank==SCALAR && value.rank==VECTOR && I.col==value.col) {
			tcol=getArrayVal(J,1,1)+k;
			for (i=1;i<=I.col;i++) {
				trow=getArrayVal(I,1,i)+k;
				if (trow>res->row || tcol>res->col) {
					perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
					return;
				}
				setArrayVal(*res,trow,tcol,getArrayVal(value,1,i));
			}
		}
		else if (I.rank==VECTOR && J.rank==VECTOR && value.rank==MATRIX) {
			for (i=1;i<=I.col;i++) {
				trow=getArrayVal(I,1,i)+k;
				for (j=1;j<=J.col;j++) {
					tcol=getArrayVal(J,1,j)+k;
					if (trow>res->row || tcol>res->col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,trow,tcol,getArrayVal(value,i,j));
				}
			}
		}
		else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
} // end of assignSubArray()


/* subArray()
 * return a TDeclare object extracting from base the elements
 * defined by row and col, which are vectors
 * if base is a vector (I is ignored):
 *   if J is a scalar, res is a scalar
 *   if J is a vector, res is vector
 *   if J is a matrix, res is matrix
 * if base is a matrix:
 *   if I and J are scalars, res is a scalar 
 *   if I and J are vectors, res is a matrix
 *   if I is a vector and J is a scalar res is a vector
 *   if I is a scalar and J is a vector res is a vector
 *   if I is a matrix and J is a scalar res is a matrix
 *   if I is a scalar and J is a matrix res is a matrix
 *   else rank error */
void subArray(TDeclare *res, TDeclare base, TDeclare I, TDeclare J) {
	int i,j, trow, tcol;
	int k=1-indexOrigin;
	if (base.rank==SCALAR) {
		perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	else if (base.rank==VECTOR) {
		if (J.rank==SCALAR && !I.col) {
			tcol=(int)getArrayVal(J,1,1)+k;
			if (tcol<1 || tcol>base.col) {
				perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
				return;
			}
			res->type=base.type;
			res->rank=SCALAR;
			res->row=1;
			res->col=1;
			res->size=2;
			dimArray(res,res->size);
			setArrayVal(*res,1,1,getArrayVal(base,1,tcol));
		}
		else if (J.rank==VECTOR && !I.col) {
			res->type=base.type;
			res->rank=VECTOR;
			res->row=1;
			res->col=J.col;
			res->size=res->col+1;
			dimArray(res,res->size);
			for (j=1;j<=res->col;j++) {
				tcol=getArrayVal(J,1,j)+k;
				if (tcol<1 || tcol>base.col) {
					perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
					return;
				}
				setArrayVal(*res,1,j,getArrayVal(base,1,tcol));
			}
		}
		else if (J.rank==MATRIX && !I.col) {
			res->type=base.type;
			res->rank=MATRIX;
			res->row=J.row;
			res->col=J.col;
			res->size=res->row*res->col+1;
			dimArray(res,res->size);
			for (i=1;i<=res->row;i++) {
				for (j=1;j<=res->col;j++) {
					tcol=getArrayVal(J,i,j)+k;
					if (tcol<1 || tcol>base.col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,i,j,getArrayVal(base,1,tcol));
				}
			}
		}
		else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
	}
	else if (base.rank==MATRIX) {
		if (!I.col && J.col) {
			perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
			return;
		}
		else if (I.rank==SCALAR && J.rank==SCALAR) {
			trow=(int)getArrayVal(I,1,1)+k;
			tcol=(int)getArrayVal(J,1,1)+k;
			if (trow<1 || trow>base.row || tcol<1 || tcol>base.col) {
				perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
				return;
			}
			res->type=base.type;
			res->rank=SCALAR;
			res->row=1;
			res->col=1;
			res->size=2;
			dimArray(res,res->size);
			setArrayVal(*res,1,1,getArrayVal(base,trow,tcol));
		}
		else if (I.rank==VECTOR && J.rank==VECTOR) {
			res->type=base.type;
			res->rank=MATRIX;
			res->row=I.col;
			res->col=J.col;
			res->size=res->row*res->col+1;
			dimArray(res,res->size);
			for (i=1;i<=I.col;i++) {
				for (j=1;j<=J.col;j++) {
					trow=getArrayVal(I,1,i)+k;
					tcol=getArrayVal(J,1,j)+k;
					if (trow<1 || trow>base.row || tcol<1 || tcol>base.col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,i,j,getArrayVal(base,trow,tcol));
				}
			}
		}
		else if (I.rank==VECTOR && J.rank==SCALAR) {
			res->type=base.type;
			res->rank=VECTOR;
			res->row=1;
			res->col=I.col;
			res->size=res->col+1;
			dimArray(res,res->size);
			for (i=1;i<=I.col;i++) {
				for (j=1;j<=J.col;j++) {
					trow=getArrayVal(I,1,i)+k;
					tcol=getArrayVal(J,1,j)+k;
					if (trow<1 || trow>base.row || tcol<1 || tcol>base.col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,1,i,getArrayVal(base,trow,tcol));
				}
			}
		}
		else if (I.rank==SCALAR && J.rank==VECTOR) {
			res->type=base.type;
			res->rank=VECTOR;
			res->row=1;
			res->col=J.col;
			res->size=res->col+1;
			dimArray(res,res->size);
			for (i=1;i<=I.col;i++) {
				for (j=1;j<=J.col;j++) {
					trow=getArrayVal(I,1,i)+k;
					tcol=getArrayVal(J,1,j)+k;
					if (trow<1 || trow>base.row || tcol<1 || tcol>base.col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,1,j,getArrayVal(base,trow,tcol));
				}
			}
		}
		else if (I.rank==MATRIX && J.rank==SCALAR) {
			res->type=base.type;
			res->rank=MATRIX;
			res->row=I.row;
			res->col=I.col;
			res->size=res->row*res->col+1;
			dimArray(res,res->size);
			for (i=1;i<=I.row;i++) {
				for (j=1;j<=I.col;j++) {
					trow=getArrayVal(I,i,j)+k;
					tcol=getArrayVal(J,1,1)+k;
					if (trow<1 || trow>base.row || tcol<1 || tcol>base.col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,i,j,getArrayVal(base,trow,tcol));
				}
			}
		}
		else if (I.rank==SCALAR && J.rank==MATRIX) {
			res->type=base.type;
			res->rank=MATRIX;
			res->row=J.row;
			res->col=J.col;
			res->size=res->row*res->col+1;
			dimArray(res,res->size);
			for (i=1;i<=J.row;i++) {
				for (j=1;j<=J.col;j++) {
					trow=getArrayVal(I,1,1)+k;
					tcol=getArrayVal(J,i,j)+k;
					if (trow<1|| trow>base.row || tcol<1 || tcol>base.col) {
						perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
						return;
					}
					setArrayVal(*res,i,j,getArrayVal(base,trow,tcol));
				}
			}
		}
		else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
	}
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
} // end of subArray()


/* arraySegue()
 * check if the item that follows shapes an explicit array
 * System function for expression() */
int arraySegue(char *s) {
	if (*s && !isblank(*s)) return FALSE;
	if (*s==')' || *s==']') return FALSE;
	while (isblank(*s)) s++;
	if (*s=='$') return TRUE;
	if (*s==';') return FALSE;
	if (*s=='_' && isnum(s+1)) s++;
	if (isblank(*s)) return FALSE;
	if (isflot(s)) return TRUE;
	return FALSE;
}


/* checkTextFile()
 * check if file is probabilistically a text file or a binary file
 * The algorithm is heuristic */
int checkTextFile(FILE *fd) {
	int bTot=0, aTot=0, c=0;
	int percentAscii=0;

	fseek(fd, 0, SEEK_SET);
	if (ftell(fd) != 0) return -2;

	while ((c=fgetc(fd))!=EOF && bTot < 10000) {
		bTot++;
		aTot+=(c>7 && c<255);
	}
	if (bTot>0) {
		percentAscii=((aTot*100)/bTot);
		if (percentAscii<90) return FALSE;
	}
	else return FALSE;
	return TRUE;
}


/* getNum()
 * get a numeric scalar from keyboard
 * System function for assign()  */
double getNum(char *p, char **newp) {
	char num[COMPSTR], *k=num;
	double dval;
	int isEx=FALSE;
	strncpy_(num,VOIDS,COMPSTR);
	/* get sign */
	if (*p=='$') {
		p++; // skip $
		isEx=TRUE;
	}
	if (*p=='_') *k++='-', p++;
	else if (*p=='+') p++;
	else if (*p=='-') *k++='-', p++;
	if (*p=='$') {
		p++; // skip $
		isEx=TRUE;
	}
	if (!isEx) {
		/* get integer part */
		while (isdigit(*p)) *k++=*p++;
		/* get dot */
		if (*p=='.') *k++=*p++;
		/* get fractional part */
		while (isdigit(*p)) *k++=*p++;
		/* get exponent symbol*/
		if (*p=='E') {
			*k++=*p++;
			/* get sign of exponent */
			if (*p=='_') *k++='-', p++;
			else if (*p=='+') p++;
			while (isdigit(*p)) *k++=*p++;
		}
		*k='\0';
		dval=strtod(num,NULL);
	}
	else {
		/* get hex */
		while (isxdigit(*p)) *k++=*p++;
		*k='\0';
		dval=(double)strtol(num,NULL,16);
	}
	if (newp) *newp=p;
	return dval;
}


/* calcTime()
 * adjust the time in endS filling in case min and hour */
void calcTime(double *endS, int *min, int *hour) {
	if (*endS>60) {
		*min=*endS/60;
		*endS=*endS-*min*60;
	}
	if (*min>60) {
		*hour=*min/60;
		*min=*min-*hour*60;
	}
}


/* do_timing(g()
 * execute the timing feature */
void do_timing(double endS) {
	int hour=0,min=0;
	double secs=endS-beginS, elapse=endS-beginS;
	calcTime(&secs,&min,&hour);

	fputc('\n',stdout);
	/* print timing */
	if (!hour && !min) {
		if (secs<1)
		     fprintf(stdout,"Time:  %.2f ms\n\n",secs*1000.0);
		else
		     fprintf(stdout,"Time:  %.2f s\n\n",secs);
	}
	else if (!hour)
		fprintf(stdout,"Time:  %.2d:%.2d minute%c (%.2f s).\n\n",min,(int)(secs+0.5),min!=1?'s':' ',elapse);
	else
		fprintf(stdout,"Time:  %.2d:%.2d:%.2d hour%c (%.2f s).\n\n",hour,min,(int)(secs+0.5),hour!=1?'s':' ',elapse);
}


/* memStatus()
 * get memory size of the whole program
 * For statistic scopes
 * Thanks to Amos for his algorithm at
 * https://stackoverflow.com/questions/1558402/memory-usage-of-current-process-in-c
 * */
int memStatus(void) {
	struct rusage r_usage;
	getrusage(RUSAGE_SELF,&r_usage);
  	return r_usage.ru_maxrss;
}


/* checkBal()
 * check balancing of parenthesis and square brackets 
 * return FALSE if str is NOT correct */
int checkBal(char *str) {
	int st=0, qst=0;
	while (*str) {
		if (*str=='\"' || *str=='\'') {
			char q=*str;
			str++;
			while (*str && *str!=q) str++;
		}
		else if (*str=='(') st++;
		else if (*str==')') st--;
		else if (*str=='[') qst++;
		else if (*str==']') qst--;
		str++;
	}
	if (st || qst) return FALSE;
	return TRUE;
}


/*****************************************
 *     INFORMATIVE FUNCTIONS             *
 *****************************************/
/* callIBeam()
 * print help about I-Beam variables */
void callIBeam(FILE *fs) {
	emit(1,"\n I-Beam variables:\n");
	emit(1,"%s I_1%s\tGet/Set the %sfuzz%s depth[)FUZZ]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_2%s\tGet/Set the %sdigits%s number [)DIGIT]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_3%s\tGet/Set the screen %swidth%s [)WIDTH]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_4%s\tGet/Set the %sseed%s value [)SEED]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_5%s\tGet/Set the %scomparison tolerance%s [)COMP]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_6%s\tGet/Set the %sdivision flag%s [)DIV]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_7%s\tGet/Set the %sindex origin%s [)ORIGIN]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_8%s\tGet the %stime of day%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_9%s\tGet the %scurrent hour%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_10%s\tGet the %scurrent minutes%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_11%s\tGet the %scurrent seconds%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_12%s\tGet the %scurrent year%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_13%s\tGet the %scurrent month%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_14%s\tGet the %scurrent day%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_15%s\tGet the %scurrent date%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_16%s\tGet the %scurrent time%s with seconds\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_17%s\tGet the %scurrent time%s without seconds\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_18%s\tGet the %sworkspace status%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_19%s\tGet/set the %sexponential%s flag [)DIV]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_20%s\tGet the %stime of day%s in 60th of seconds\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_21%s\tGet the %scomputer clock%s in 60th of seconds\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_22%s\tGet the %savailable variables and programs%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_23%s\tGet the %snumber of users%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_24%s\tGet the %ssession duration%s in 60th of seconds\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_25%s\tGet %stoday's date%s in composed integer\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_26%s\tGet the %sline number%s of currently executing function\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_27%s\tGet %sline numbers%s of all started and not completed functions\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_28%s\tGet the %scurrent filename%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_29%s\tGet the %scurrent executing function name%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_30%s\tGet the %scurrent username%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_31%s\tGet %supper alphabetical%s characters' list\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_32%s\tGet %slower alphabetical%s characters' list\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_33%s\tGet %sdigits'%s list\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_34%s\tGet %spunctuation characters'%s list\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_35%s\tGet the %slast matrix inversion type code%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_36%s\tGet the %slast matrix inversion type description%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_37%s\tGet the %slast pseudo-inversion iterations count%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_38%s\tGet/Set the %sinversion%s flag [)INV]\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_39%s\tGet the %smemory status%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_40%s\tGet the %slast recursion iteration count%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_46%s\tGet/Set the %slast declared variables count%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_48%s\tGet the %snumber of declared variables%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_49%s\tGet the %snumber of programs in memory%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1," I-Beam-styled commands:\n");
	emit(1,"%s I_50%s\t%sEnable error messages for the execution operator%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_51%s\t%sDisable error messages for the execution operator%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_60%s\t%sClear the state indicator%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	emit(1,"%s I_99%s\t%sTerminate the APL session%s\n",BLUECOLOR,RESETCOLOR,GREENCOLOR,RESETCOLOR);
	fprintf(fs,"\n Happy APL programming with %sapple%s!\n",BOLD,RESETCOLOR);
}


/* callOps()
 * print the operators format used by )OPS (apocryphal) */
void callOps(FILE *fs) {
	fprintf(fs,"\n APL\\1130 operators\n");
	fprintf(fs," -------------------\n\n");
	fprintf(fs," %sMathematical monadic and dyadic operators%s\n\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," The scalar operators are:\n");
	fprintf(fs,"\n%s +  -  x  %%  {  }  *  |  !  ^  v  >  <  =  #  &  ~  o\n%s",BLUECOLOR,RESETCOLOR); 
	fprintf(fs,"\n\n MONADIC                   OPERATOR                     DYADIC\n");
	fprintf(fs," -------------------------------------------------------------\n");
	fprintf(fs," set positive (optional)       %s+%s                      addition\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," set negative                  %s-%s                   subtraction\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," signum                        %sx%s                multiplication\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," reciprocal                    %s%%%s                      division\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," ceiling                       %s}%s                 maximum value\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," floor                         %s{%s                 minimum value\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," e to the power of             %s*%s                exponentiation\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," absolute value                %s|%s                      residual\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," factorial                     %s!%s                  combinations\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," random number                 %s?%s            random combination\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," logical not                   %s~%s                 excluding set\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s^%s         lcm and logical 'and'\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %sv%s          gcd and logical 'or'\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s^~%s               logical 'nand'\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %sv~%s                logical 'nor'\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s=%s                         equal\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s>%s                  greater than\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s>=%s        greater than or equal\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s<%s                   lesser than\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s<=%s         lesser than or equal\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s#%s                     not equal\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," logarithm in base e           %s&%s         logarithm in base any\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Greek Pi times                %so%s  circular function (see down)\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," reduction of rows             %sf/%s  %s(f scalar operator)%s\n",REDCOLOR,RESETCOLOR,BLUECOLOR,RESETCOLOR);
	fprintf(fs," reduction of columns         %sf/-%s  %s(f scalar operator)%s\n",REDCOLOR,RESETCOLOR,BLUECOLOR,RESETCOLOR);
	fprintf(fs,"                               %s/%s     compression along columns\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s/-%s       compression along rows\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s\\%s       expansion along columns\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s\\-%s         expansion along rows\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," ravel                         %s,%s         catenate and laminate\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," dimension                     %sp%s                   restructure\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," indices generation            %si%s                        locate\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                              %s`|`%s      representation (encode)\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                              %s_|_%s               value (decode)\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                              %s/|\\%s                         take\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                              %s\\|/%s                         drop\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," grade up                     %s/^\\%s\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," grade down                   %s\\v/%s\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," reversal of rows              %so|%s             rotation of rows\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," reversal of columns           %so-%s          rotation of columns\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," transposition                 %s\\o%s\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %se%s                    membership\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s<-%s                   assignment\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," go to line                    %s->%s\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," inner product:               %sf.g%s   %s(f and g scalar operators)%s\n",REDCOLOR,RESETCOLOR,BLUECOLOR,RESETCOLOR);
	fprintf(fs," outer product:               %s@.g%s   %s(g scalar operator)%s\n",REDCOLOR,RESETCOLOR,BLUECOLOR,RESETCOLOR);
	fprintf(fs,"\n\n %sThe circular dyadic operators are:%s\n\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Inner parable               %s 0oY%s                   (1-Y*2)*.5\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Arcsine                     %s_1oY%s                     ARCSIN Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Arc cosine                  %s_2oY%s                     ARCCOS Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Arctangent                  %s_3oY%s                     ARCTAN Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Outer parable               %s_4oY%s                  (_1+Y*2)*.5\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Hyperbolic arcsine          %s_5oY%s                    ARCSINH Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Hyperbolic arc cosine       %s_6oY%s                    ARCCOSH Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Hyperbolic arctangent       %s_7oY%s                    ARCTANH Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Sine                        %s 1oY%s                        SIN Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Cosine                      %s 2oY%s                        COS Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Tangent                     %s 3oY%s                        TAN Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Parable                     %s 4oY%s                   (1+Y*2)*.5\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Hyperbolic sine             %s 5oY%s                       SINH Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Hyperbolic cosine           %s 6oY%s                       COSH Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," Hyperbolic tangent          %s 7oY%s                       TANH Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"\n\n %sThe added monadic and dyadic operators are:%s\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"\n MONADIC                   OPERATOR                     DYADIC\n");
	fprintf(fs," -------------------------------------------------------------\n");
	fprintf(fs," unique mask                   %s#%s                              \n",REDCOLOR,RESETCOLOR);
	fprintf(fs," scan along rows               %sf\\%s  %s(f scalar operator)%s\n",REDCOLOR,RESETCOLOR,BLUECOLOR,RESETCOLOR);
	fprintf(fs," scan along columns           %sf\\-%s  %s(f scalar operator)%s\n",REDCOLOR,RESETCOLOR,BLUECOLOR,RESETCOLOR);
	fprintf(fs," type conversion               %sc%s                              \n",REDCOLOR,RESETCOLOR);
	fprintf(fs," execute APL string            %se%s                              \n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %sf%s               print formatted\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," numeric entity checking       %sn%s                              \n",REDCOLOR,RESETCOLOR);
	fprintf(fs," timing operations             %st%s                              \n",REDCOLOR,RESETCOLOR);
	fprintf(fs," unique set                    %su%s                              \n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s~%s                 exclusion set\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                               %s=_%s                        match\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                              %s/^\\%s            relative grade up\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"                              %s\\v/%s          relative grade down\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," matrix inversion             %s|%%|%s              system solution\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"\n\n %sThe added circular dyadic operators are:%s\n\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," compl. error function       %s_8oY%s                       ERFC Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," error function               %s8oY%s                        ERF Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," natural log. of gamma func. %s_9oY%s                     LGAMMA Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," gamma function               %s9oY%s                      GAMMA Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," nearest integer             %s10oY%s                       RINT Y\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"\n Happy APL programming with %sapple%s!\n",BOLD,RESETCOLOR);
}



/* callExtOps()
 * print the operators format used by )OPS (apocryphal) */
void callExtOps(FILE *fs) {
	fprintf(fs,"\n APL\\1130 extended linear algebraic operators\n");
	fprintf(fs," --------------------------------------------\n\n");
	fprintf(fs," %sThe extended linear algebraic operators are:%s\n\n",REDCOLOR,RESETCOLOR);
	fprintf(fs," %s  Eigendecomposition a%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sa[1]M%s:  Jordan diagonal eigenvalues matrix J\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sa[2]M%s:  Normalized eigenvectors matrix P \n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = P x J x inverse(P)%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sa[3]M%s:  Schur triangular matrix S\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sa[4]M%s:  Orthogonal matrix T \n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = T x S x transpose(T)%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"             or      %sM = T x S x inverse(T)%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sa[5]M%s:  number of the QR algorithm iterations\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs," %s  Balancing decomposition b%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sb[1]M%s:  Balanced matrix B\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sb[2]M%s:  Diagonal output matrix D\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = D x B x inverse(D)%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  Determinant d%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sdM%s:     Determinant of M\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs," %s  Hessemberg decomposition h%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sh[1]M%s:  Hessenberg matrix H\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sh[2]M%s:  Orthogonal matrix Q\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = Q x H x transpose(Q)%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"             or      %sM = Q x H x inverse(Q)%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  Characteristic polynomial j%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sjM%s:     Characteristic polynomial of M\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs," %s  Condition number k%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %skM%s:     Condition number of M\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs," %s  CHolesky decompositions l%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[1]M%s:  Cholesky matrix L\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = L x transpose(L)%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  LDL decompositions l%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[2]M%s:  Lower triangular matrix L\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[3]M%s:  Diagonal matrix D\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = L x D x transpose(L)%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  PLU decompositions l%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[4]M%s:  Lower triangular matrix L\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[5]M%s:  Upper triangular matrix U\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[6]M%s:  Permutation matrix P\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = (P x) L x U%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"             (P only if different from the identity matrix)\n\n");
	fprintf(fs," %s  LDU decompositions l%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[7]M%s:  Lower triangular matrix L\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[8]M%s:  Diagonal matrix D\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sl[9]M%s:  Upper triangular matrix U\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = L x D x U%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  QR decomposition q%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sq[1]M%s:  Orthogonal matrix Q\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sq[2]M%s:  Lower triangular matrix R\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = Q x R%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  Echelon, RREF and rank r%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sr[1]M%s:  Echelon matrix\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sr[2]M%s:  Rank of the matrix\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sr[3]M%s:  Row rank of the matrix\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sr[4]M%s:  Column rank of the matrix\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %sr[5]M%s:  RREF matrix\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs," %s  SV compact decomposition s%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[1]M%s:  Diagonal matrix S\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[2]M%s:  Orthogonal matrix U\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[3]M%s:  Orthogonal matrix V\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = U x S x transpose(V)%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[4]M%s:  number of the QR algorithm iterations\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs," %s  SV full decomposition s%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[5]M%s:  Diagonal full matrix S\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[6]M%s:  Diagonal full matrix U\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[7]M%s:  Orthogonal full matrix V\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = U x S x transpose(V)%s\n\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s  Matrix dyadic tests operator t%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"%s",GREENCOLOR);
	printTests(fs);
	fprintf(fs,"%s\n",RESETCOLOR);
	fprintf(fs," %s  Polar decomposition w%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %sw[1]M%s:  Upper triangular matrix U\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[2]M%s:  Definite positive matrix P\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"             so that %sM = U x P%s\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"     %ss[3]M%s:  number of the QR algorithm iterations\n\n",GREENCOLOR,RESETCOLOR);
	fprintf(fs,"\n %sThe figure [1] can be omitted for all operators%s\n",REDCOLOR,RESETCOLOR);
	fprintf(fs,"\n Happy APL programming with %sapple%s!\n",BOLD,RESETCOLOR);
}


/* isScalar()
 * check if p points to a scalar operator
 * for )HELP */
int isScalar(char *p) {
	switch(*p) {
		case '+':  
		case '-':  
		case 'x':  
		case '%': 
		case '{':
		case '}':
		case '*':
		case '|':
		case '!':
		case '=':
		case '#':
		case '&':
		case 'o':  break;
		case '^':
		   if (!*(p+1)) break;
		   else if (*(p+1)=='~') break;
		   else if (*(p+1)=='\\') break;
		   else if (*(p+1)=='/') break;
		   else return FALSE;
		case 'v':
		   if (!*(p+1)) break;
		   else if (*(p+1)=='~') break;
		   else if (*(p+1)=='\\') break;
		   else if (*(p+1)=='/') break;
		   else return FALSE;
		case '>':
		   if (!*(p+1)) break;
		   else if (*(p+1)=='=') break;
		   else if (*(p+1)=='\\') break;
		   else if (*(p+1)=='/') break;
		   else return FALSE;
		case '<':
		   if (!*(p+1)) break;
		   else if (*(p+1)=='=') break;
		   else if (*(p+1)=='\\') break;
		   else if (*(p+1)=='/') break;
		   else return FALSE;
	}

	return TRUE;
}


/* getSpecificHelp()
 * print help on each operator, invoked by )HELP <op> 
 * Note: the string p must be cleaned by extra final blanks */
void getSpecificHelp(char *p, FILE* fs) {
	if (isScalar(p) && *(p+1)) {
		switch(*(p+1)) {
			case '.':
				if (isScalar((p+2)) && !(*(p+3))) {
					fprintf(fs," %c.%c dyadic: inner product\n", *p, *(p+2));
					return;
				}
				break;
			case '/':
				if (!*(p+2)) {
					fprintf(fs," %c/ monadic: row reduction\n",*p);
					return;
				}
				else if (*(p+2)=='-' && !(*(p+3))) {
					fprintf(fs," %c/- monadic: column reduction\n",*p);
					return;
				}
				break;
			case '\\':
				if (!*(p+2)) {
					fprintf(fs," %c\\monadic: row scan on %c\n",*p,*p);
					return;
				}
				else if (*(p+2)=='-' && !(*(p+3))) {
					fprintf(fs," %c\\- monadic: column scan %c\n",*p,*p);
					return;
				}
				break;
		}
	}
	if (*p) {
		if (*p=='\"' && !*(p+1)) {
			fprintf(fs," \"string delimiter\".\n");
			fprintf(fs," 1. One character is a vector, and not a scalar.\n");
			fprintf(fs," 2. Interprets escape characters.\n");
		}
		else if (*p=='\'' && !*(p+1)) {
			fprintf(fs," 'string delimiter'.\n");
			fprintf(fs," 1. One character is a scalar, and not a vector.\n");
			fprintf(fs," 2. Does not interpret escape characters.\n");
		}
		else if (*p=='_' && !*(p+1)) {
			fprintf(fs," minus symbol for negative numbers\n");
		}
		else if (*p=='$' && !*(p+1)) {
			fprintf(fs," symbol for integer hexadecimal numbers\n");
		}
		else if (*p=='!' && !*(p+1)) {
			fprintf(fs," ! monadic: combinations\n");
			fprintf(fs," ! dyadic : factorial (scalar operator)\n");
		}
		else if (*p=='#' && !*(p+1)) {
			fprintf(fs," # monadic: unique mask\n");
			fprintf(fs," # dyadic : not equal (scalar operator)\n");
		}
		else if (*p=='%' && !*(p+1)) {
			fprintf(fs," %% monadic: reciprocal\n");
			fprintf(fs," %% dyadic : division (scalar operator)\n");
		}
		else if (*p=='&' && !*(p+1)) {
			fprintf(fs," & monadic: logarithm in case e\n");
			fprintf(fs," & dyadic : logarithm in any base (scalar operator)\n");
		}
		else if (*p=='*' && !*(p+1)) {
			fprintf(fs," * monadic: e to the power of\n");
			fprintf(fs," * dyadic : exponentiation (scalar operator)\n");
		}
		else if (*p=='+' && !*(p+1)) {
			fprintf(fs," + monadic: set positive (optional)\n");
			fprintf(fs," + dyadic : addition (scalar operator)\n");
		}
		else if (*p==',' && !*(p+1)) {
			fprintf(fs," , monadic: ravel\n");
			fprintf(fs," , dyadic : catenate (axis 1 and 2)\n");
			fprintf(fs," , dyadic : laminate (axis 0.5 and 1.5)\n");
		}
		else if (*p=='-' && !*(p+1)) {
			fprintf(fs," - monadic: set negative\n");
			fprintf(fs," - dyadic : subtraction (scalar operator)\n");
		}
		else if (*p=='-' && *(p+1)=='>' && !(*(p+2))) {
			fprintf(fs," -> monadic: go to line\n");
		}
		else if (*p=='/' && !*(p+1)) {
			fprintf(fs," / dyadic: compression on last dimension\n");
		}
		else if (!strcmp(p,"/-")) {
			fprintf(fs," /- dyadic: compression on first dimension\n");
		}
		else if (!strcmp(p,"/^\\")) {
			fprintf(fs," /^\\ monadic: absolute grade up\n");
			fprintf(fs," /^\\ dyadic : relative grade up\n");
		}
		else if (!strcmp(p,"/|\\")) {
			fprintf(fs," /|\\ dyadic: take\n");
		}
		else if (*p=='<' && !*(p+1)) {
			fprintf(fs," < dyadic: lesser than (scalar operator)\n");
		}
		else if (!strcmp(p,"<-")) {
			fprintf(fs," <- dyadic: assignment\n");
		}
		else if (!strcmp(p,"<=")) {
			fprintf(fs," <= dyadic: less than or equal (scalar operator)\n");
		}
		else if (*p=='=' && !*(p+1)) {
			fprintf(fs," = dyadic: equal to (scalar operator)\n");
		}
		else if (!strcmp(p,"=_")) {
			fprintf(fs," =_ dyadic: match\n");
		}
		else if (*p=='>' && !*(p+1)) {
			fprintf(fs," > dyadic: greater than (scalar operator)\n");
		}
		else if (!strcmp(p,">=")) {
			fprintf(fs," >= dyadic: greater than or equal (scalar operator)\n");
		}
		else if (*p=='?' && !*(p+1)) {
			fprintf(fs," ? monadic: random number\n");
			fprintf(fs," ? dyadic : random combination\n");
		}
		else if (*p=='\\' && !*(p+1)) {
			fprintf(fs," \\ dyadic: expansion on last dimension\n");
		}
		else if (!strcmp(p,"\\-")) {
			fprintf(fs," \\- dyadic: expansion on first dimension\n");
		}
		else if (!strcmp(p,"\\o")) {
			fprintf(fs," \\o monadic: matrix transpose\n");
			fprintf(fs," \\o dyadic : matrix transpose\n");
		}
		else if (!strcmp(p,"\\v/")) {
			fprintf(fs," \\v/ monadic: aboslute grade down\n");
			fprintf(fs," \\v/ dyadic : relative grade down\n");
		}
		else if (!strcmp(p,"\\|/")) {
			fprintf(fs," \\|/ dyadic: drop\n");
		}
		else if (*p=='^' && !*(p+1)) {
			fprintf(fs," ^ dyadic : lcm - logical 'and' (scalar operator)\n");
		}
		else if (!strcmp(p,"^~")) {
			fprintf(fs," ^~ dyadic: logical 'not-and', or nand (scalar operator)\n");
		}
		else if (!strcmp(p,"_|_")) {
			fprintf(fs," _|_ dyadic: encode representation from value\n");
		}
		else if (!strcmp(p,"`|`")) {
			fprintf(fs," `|` dyadic: decode value representation\n");
		}
		else if (*p=='a' && !*(p+1)) {
			fprintf(fs," a monadic: matrix eigendecompositions");
		}
		else if (*p=='b' && !*(p+1)) {
			fprintf(fs," b monadic: balancing decomposition\n");
		}
		else if (*p=='c' && !*(p+1)) {
			fprintf(fs," c monadic: type conversion\n");
		}
		else if (*p=='d' && !*(p+1)) {
			fprintf(fs," d monadic: matrix determinant\n"); 
		}
		else if (*p=='e' && !*(p+1)) {
			fprintf(fs," e monadic: statement execution\n");
			fprintf(fs," e dyadic : membership\n");
		}
		else if (*p=='f' && !*(p+1)) {
			fprintf(fs," f dyadic: print formatted\n");
		}
		else if (*p=='h' && !*(p+1)) {
			fprintf(fs," h monadic: matrix Hessenberg decomposition\n");
		}
		else if (*p=='i' && !*(p+1)) {
			fprintf(fs," i monadic: indices generation\n");
			fprintf(fs," i dyadic : locate\n");
		}
		else if (*p=='j' && !*(p+1)) {
			fprintf(fs," j monadic: matrix characteristic polynomial\n");
		}
		else if (*p=='k' && !*(p+1)) {
			fprintf(fs," k monadic: matrix condition number\n");
		}
		else if (*p=='l' && !*(p+1)) {
			fprintf(fs," l monadic: matrix triangular decompositions\n");
		}
		else if (*p=='n' && !*(p+1)) {
			fprintf(fs," n monadic: number checking\n");
		}
		else if (*p=='o' && !*(p+1)) {
			fprintf(fs," o monadic: Greek-Pi times\n");
			fprintf(fs," o dyadic : Circular functions (scalar operator)\n");
		}
		else if (!strcmp(p,"o-")) {
			fprintf(fs," o- monadic: matrix reversal along first dimension\n");
			fprintf(fs," o- dyadic : matrix rotation on first dimension\n");
		}
		else if (!strcmp(p,"o|")) {
			fprintf(fs," o| monadic: matrix reversal along last dimension\n");
			fprintf(fs," o| dyadic : matrix rotation on last dimension\n");
		}
		else if (*p=='@' && *(p+1)=='.' && isScalar((p+2))) {
			fprintf(fs," @.%c dyadic: outer product\n",*(p+2));
		}
		else if (*p=='@' && *(p+1)=='.') {
			fprintf(fs," @.<op> dyadic: outer product associated to any scalar operator <op>\n");
		}
		else if (*p=='p' && !*(p+1)) {
			fprintf(fs," p monadic: return dimension\n");
			fprintf(fs," p dyadic : reshape\n");
		}
		else if (*p=='q' && !*(p+1)) {
			fprintf(fs," q monadic: matrix QR decomposition\n");
		}
		else if (*p=='r' && !*(p+1)) {
			fprintf(fs," r monadic: matrix echelon, RREF reduction, matrix rank\n");	
		}
		else if (*p=='s' && !*(p+1)) {
			fprintf(fs," s monadic: matrix SV decomposition\n");
		}
		else if (*p=='t' && !*(p+1)) {
			fprintf(fs," t monadic: timing operations\n");
			fprintf(fs," t dyadic:  matrix tests\n");
		}
		else if (*p=='u' && !*(p+1)) {
			fprintf(fs," u monadic: unique set\n");
		}
		else if (!strcmp(p,"v~")) {
			fprintf(fs," v~ dyadic: logical 'not-or', or nor (scalar operator)\n");
		}
		else if (*p=='v' && !*(p+1)) {
			fprintf(fs," v dyadic : gdc - logical 'or' (scalar operator)\n");
		}
		else if (*p=='w' && !*(p+1)) {
			fprintf(fs," w monadic: matrix Polar decomposition\n");
		}
		else if (*p=='x' && !*(p+1)) {
			fprintf(fs," x monadic: signum\n");
			fprintf(fs," x dyadic : multiplication (scalar operator)\n");
		}
		else if (*p=='{' && !*(p+1)) {
			fprintf(fs," { monadic: floor\n");
			fprintf(fs," { dyadic : minumum value (scalar operator)\n");
		}
		else if (*p=='}' && !*(p+1)) {
			fprintf(fs," } monadic: ceiling\n");
			fprintf(fs," } dyadic : maximum value (scalar operator)\n");
		}
		else if (*p=='~' && !*(p+1)) {
			fprintf(fs," ~ monadic: logical 'not'\n");
			fprintf(fs," ~ dyadic : exclusion set\n");
		}
		else if (*p=='|' && *(p+1)=='%' && *(p+2)=='|' && !*(p+3)) {
			fprintf(fs," |%%| monadic: inversion\n");
			fprintf(fs," |%%| dyadic : matrices division\n");
		}
		else if (*p=='|' && !*(p+1)) {
			fprintf(fs," | monadic: absolute value\n");
			fprintf(fs," | dyadic : residual (scalar operator)\n");
		}
		else if (*p==')' && isalpha(*(p+1))) {
			fprintf(fs,"- not implemented -\n");
		}
		else if ((*p=='(' || *p==')') && !isalpha(*(p+1))) {
			fprintf(fs," (..): expression segmentation\n");
			fprintf(fs," evaluated from left to right (during preprocessing)\n");
		}
		else if (*p=='[' || *p==']') {
			fprintf(fs," [..]: expression sub-selection\n");
			fprintf(fs," evaluated from right to left\n");
		}
		else fprintf(fs,"UNRECOGNIZED SYMBOL\n");
	}
	// Note: getSpecificHelp() is called upon a non empty string
	// thus there is no else case here
} // end of getSpecificHelp()


/* callHelp() 
 * print the help; called by )HELP /(apochryfal) */
void callHelp(FILE *fs) {
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;
	fprintf(fs,"\n%sapple%s SYSTEM COMMANDS:\n",BOLD,RESETCOLOR);
	fprintf(fs,"---------------------\n");
	fprintf(fs," The following conventions are used in this help:\n");
	fprintf(fs,"   [FILE] is a file name (obeying to this OS rules)\n");
	fprintf(fs,"   [NAMES] is a blank-separated list of APL objects names\n");
	fprintf(fs,"   [NAME] is one single APL object name\n");
	fprintf(fs,"   [STR] is any string or option\n");
	fprintf(fs,"   [VAL] is a numeric value\n");
	fprintf(fs,"   [WSID] is the WorkSpace IDentifier (a string)\n");
	fprintf(fs,"\n An APL object is a variable or a user-defined program.\n");
	fprintf(fs," Only the letters in capital blue are parsed, the rest is ignored.\n\n");
	fprintf(fs," %s)CLEA%sR               start a new empty workspace\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)COMP%s [VAL]          (%d-%d) show or set [VAL] as comparison tolerance\n",BLUECOLOR,RESETCOLOR,WHigh,WBond);
	fprintf(fs," %s)CONT%s INUE           exit from session saving workspace to default file\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)COPY%s [WSID]         copy the entire workspace [WSID] to current\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)COPY%s [WSID][NAMES]  copy [NAMES] from stored workspace [WSID]\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)DATE%s                print current date as MMM DD, YYYY\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)DEBU%sG OFF           start debug, OFF to disable\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)DESC%sRIBE            print the description of the workspace (if any)\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)DIGI%sT [VAL]         (%d-%d) show or set the output precision to [VAL]\n",BLUECOLOR,RESETCOLOR,WHigh,WAcc);
	fprintf(fs," %s)DISP%sOSE             clear the screen\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)DIV%s                 (0-1) show or set the division by zero flag\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)DROP%s [WSID]         erase workspace [WSID] from the current directory\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)EDIT%s [NAME]         edit function [NAME] with external editor\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)EDIT%s FILE [NAME]    edit file [NAME] with external editor\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)ERAS%sE [NAMES]       erase [NAMES] in the current workspace\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)EXPO%sRT [NAME]       export program [NAME] to file [NAME].apl\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)FILE%sS               list all channels' state of the current session\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)FNS %s                list all defined functions in the current workspace\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)FUZZ%s [VAL]          (%d-%d) show or set the zero value limit\n",BLUECOLOR,RESETCOLOR,WHigh,WBond);
	fprintf(fs," %s)HEX%s [VAL]           (0-1) show or set numeric hexadecimal output\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)IMPO%sRT [FILE]       import function FILE from [FILE]\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)INV%s                 (0-1) show or set the inversion flag\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)LIB%s  [STR]          list files in current directory, using [STR] as selector\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)LIST%s [NAME]         list program name of the current workspace\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)LOAD%s [WSID]         load a workspace from the current directory\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)MEMO%sRY              print the current memory amount\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)OFF%s                 exit from session\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)ORIG%sIN [VAL]        set indices origin to 1 (default) or 0\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)PCOP%sY [WSID]        copy-protect the entire workspace [WSID] to current\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)PCOP%sY [WSID][NAMES] copy-protect [NAMES] from stored workspace [WSID]\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)PROG%s                list .apl files in the current directory\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)PRWS%s                print current workspace in readable format\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)PWD%s                 print current working directory name\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)RENA%sME OLD NEW      change name to an existing user program\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)RESE%sT               reset the state indicators and suspended functions\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SAVE%s [WSID]         save the current workspace under current or [WSID] name\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SCRI%sPT [FILE]       activate session scripting to file [FILE]\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SEED%s [VAL]          (2-32768) show or set starting random seed\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SHEL%sL               start a Unix sub shell\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SI%s                  display stopped defined functions\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SIV%s                 display stopped defined functions with local variables\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)SPAC%sES              list workspaces in the current directory\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)STAT%sE               print workspace state and session timing\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)TIME%s                print current time as HH:MM:SS\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)TYPE%s [FILE]         list [FILE] in current directory\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)VARS%s                list variables in the current workspace\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)WIDT%sH [VAL]         (30-%d) show or set the printing width\n",BLUECOLOR,RESETCOLOR,sysWidth);
	fprintf(fs," %s)WSID%s [WSID]         show or set the current workspace name\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"\n COMP, DIGIT, DIV, EXP, FUZZ, INV, ORIGIN, SEED, WIDTH and WSID\n");
	fprintf(fs," if used without arguments, return the current value.\n");
	fprintf(fs,"\n Documentation is given by:\n");
	fprintf(fs," %s)HELP%s                help on system commands\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)HELP%s <op>           help on <op> operator\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)OPS%s                 help on operators\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)EXTE%sNDED            help on linear algebraic operators\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs," %s)IBEA%sM [FILE]        help on I-Beam variables\n",BLUECOLOR,RESETCOLOR);
	fprintf(fs,"\n Happy APL programming with %sapple%s!\n",BOLD,RESETCOLOR);
}


/********************************************
 *       MIXED TOOL-FUNCTIONS               *
 ********************************************/
/* callVars()
 * print vars report: called by )STATE */
void callVars(void) {
	int scal=0, vec=0, mat=0, irr1=0;;
	int num=0, str=0, irr2=0, i=0, irr3=0;
	for (i=1;i<=decCount;i++) {
		if (vn[i].rank==SCALAR) scal++;
		else if (vn[i].rank==VECTOR) vec++;
		else if (vn[i].rank==MATRIX) mat++;
		else irr1++;
		if (vn[i].type==NUMERIC) num++;
		else if (vn[i].type==STRING) str++;
		else irr2++;
		if (!vn[i].name[0]) irr3++;
	}
	emit(1,"Number of variables: %d, of which:\n",decCount);
	emit(1,"  %d %sscalar%s%s\n",scal,BOLD,scal==1?"":"s",RESETCOLOR);
	emit(1,"  %d %svector%s%s\n",vec,BOLD,vec==1?"":"s",RESETCOLOR);
	emit(1,"  %d %smatri%s%s\n",mat,BOLD,mat==1?"x":"ces",RESETCOLOR);
	emit(1,"  %d %sof type %snumeric%s, and %d of type %sstring%s\n",num,num==1?"is ":"are ",BOLD,RESETCOLOR,str,BOLD,RESETCOLOR);
	if (irr1>0) emit(1,"Found %d irregular-by-rank item%s\n",irr1,irr1==1?"":"s");
	if (irr2>0) emit(1,"Found %d irregular-by-type item%s\n",irr2,irr2==1?"":"s");
	if (irr3>0) emit(1,"Found %d irregular-by-name item%s\n",irr3,irr3==1?"":"s");
	emit(1,"Number of programs in memory: %d\n",progCount);
}


/* callFlags()
 * print flags report: called by )STATE */
void callFlags(void) {
	emit(1,"\n%sFlags:%s\nDEBUG IS %s\n",BOLD,RESETCOLOR,isDebug?"ON":"OFF");
	emit(1,"WIDTH IS %d\tDIGIT IS %d\tDIV IS %d\n",Wwidth,Wdigit,Wdiv);
	emit(1,"FUZZ  IS %d\tEXP   IS %d\tINV IS %d\n",Wfuzz,isExp,Winv);
	emit(1,"ORIGIN IS %d\tSEED  IS %d\tCOMPARISON TOL. IS %G\n",indexOrigin,Wseed,Wcomp);
	emit(1,"Current %s width is %d\n\n",!Wwidth?"dynamic":"fixed",!Wwidth?sysWidth:Wwidth);
}


/* callTime() 
 * print a timing string; called by )TIME and )STATE (apocryphal) */
void callTime(void) {
	int hour=0,min=0,day=0;
	double endS, bendS,tt;
	char session[COMPSTR];
	gettimeofday(&tv, NULL);
	endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
	bendS=endS-=beginS;
	/* pre-calculate intermediate time values */
	if (endS>60) min=endS/60, endS=endS-min*60;
	if (min>60) hour=min/60, min=min-hour*60;
	/* depict timing in condensed form */
	if (!hour && !min) {
		snprintf(session,COMPSTR,"%.2f secs",endS);
		emit(1,"%s %d, %d - %02d:%02d:%02d - session time: %s\n", getMonthString(),getDay(),getYear(),getHour(),getMin(),getSec(),session);
	}
	else {
		if (!hour) snprintf(session,COMPSTR,"%.2d:%.2d min%c",min,(int)(endS+0.5),min!=1?'s':' ');
		else if (hour<24) snprintf(session,COMPSTR,"%.2d:%.2d:%.2d hour%c",hour,min,(int)(endS+0.5),hour!=1?'s':' ');
		else {
			day=hour/24;
			hour=hour-24*day;
			snprintf(session,COMPSTR,"%d day%s, %.2d:%.2d:%.2d hour%s",day,day!=1?"s":"",hour,min,(int)(endS+0.5),hour!=1?"s":"");
		}
		/* print time string */
		emit(1,"%s %d, %d - %02d:%02d:%02d - session time: %s (%d total secs)\n", getMonthString(),getDay(),getYear(),getHour(),getMin(),getSec(),session,(int)bendS);
	}
	/* pre-calculate intermediate total time values */
	tt=totalTime+endS;
	if (tt>60) min=tt/60, tt=tt-min*60;
	if (min>60) hour=min/60, min=min-hour*60;
	/* depict timing in condensed form */
	if (!hour && !min) {
		snprintf(session,COMPSTR,"%.2f secs",tt);
		emit(1,"Total time: %s\n", session);
	}
	else {
		if (!hour) snprintf(session,COMPSTR,"%.2d:%.2d min%c",min,(int)(tt+0.5),min!=1?'s':' ');
		else if (hour<24) snprintf(session,COMPSTR,"%.2d:%.2d:%.2d hour%c",hour,min,(int)(tt+0.5),hour!=1?'s':' ');
		else {
			day=hour/24;
			hour=hour-24*day;
			snprintf(session,COMPSTR,"%d day%s, %.2d:%.2d:%.2d hour%s",day,day!=1?"s":"",hour,min,(int)(tt+0.5),hour!=1?"s":"");
		}
		/* print time string */
		emit(1,"Total time: %s\n", session);
	}
}


/* isAmongInterrupted()
 * return TRUE if name is one of the program in the )SI list */
int isAmongInterrupted(char *name) {
	int i;
	if (!backTOS) return FALSE;
	i=backTOS;
	while (i>0) {
		if (!strcmp(name,pn[backCode[i]].name)) return TRUE;
		i--;
	}
	return FALSE;
}


/* findProg()
 * search for a prog name in the pn[] structure */
int findProg(char *s) {
	int i=progCount;
	char name[NAMESTR], *k=name;
	if (!isupper(*s)) return FALSE;
	while ((isupper(*s) || isdigit(*s)) && (k-name)<NAMESTR) *k++=*s++;
	*k='\0';
	while (i>=0) {
		if (!strcmp(name,pn[i].name)) {
#if 0
			if (isAmongInterrupted(pn[i].name) && fromArrow) {
				int y=backTOS;
				while (y>0) {
					backCode[y]=0;
					backNumber[y]=0;
					backStore[y]=0;
					y--;
				}
				backTOS=0;
			}
#endif
			_len=(int)strlen(pn[i].name);
			return i;
		}
		i--;
	}
	return FALSE;
}


/* isop()
 * check the operator form in dyadic functions 
 * and return the operator single-char code */
char isop(char *s, int *adv) {
	char code=0;
	/* multi-character operators (3) */
	     if (*s=='`' && *(s+1)=='|' && *(s+2)=='`') code='b', *adv=3; // decode/encode
	else if (*s=='_' && *(s+1)=='|' && *(s+2)=='_') code='m', *adv=3; // decode/encode
	else if (*s=='|' && *(s+1)=='%' && *(s+2)=='|') code='h', *adv=3; // matrix inversion
	else if (*s=='|' && *(s+1)=='^' && *(s+2)=='|') code='t', *adv=3; // file pos
	else if (*s=='|' && *(s+1)=='<' && *(s+2)=='|') code='l', *adv=3; // file read
	/* multi-character operators (2) */
	else if (*s=='<' && *(s+1)=='=')  code='j', *adv=2;
	else if (*s=='>' && *(s+1)=='=')  code='k', *adv=2;
	else if (*s=='^' && *(s+1)=='~')  code='f', *adv=2; // not and
	else if (*s=='v' && *(s+1)=='~')  code='y', *adv=2; // not or
	else if (*s=='o' && *(s+1)=='-')  code='w', *adv=2; // o-
	else if (*s=='=' && *(s+1)=='_')  code='n', *adv=2; // =_
	/* classic scalar operators */
	else if (*s=='+') code=*s, *adv=1;
	else if (*s=='-') code=*s, *adv=1;
	else if (*s=='x') code=*s, *adv=1;
	else if (*s=='%') code=*s, *adv=1;
	else if (*s=='{') code=*s, *adv=1;
	else if (*s=='}') code=*s, *adv=1;
	else if (*s=='*') code=*s, *adv=1;
	else if (*s=='|') code=*s, *adv=1;
	else if (*s=='!') code=*s, *adv=1;
	else if (*s=='^') code=*s, *adv=1;
	else if (*s=='v') code=*s, *adv=1;
	else if (*s=='>') code=*s, *adv=1;
	else if	(*s=='<') code=*s, *adv=1;
	else if	(*s=='=') code=*s, *adv=1;
	else if	(*s=='#') code=*s, *adv=1;
	else if (*s=='&') code=*s, *adv=1; 
	else if (*s=='~') code=*s, *adv=1; 
	/* other dyadic operators */
	else if (*s=='o') code=*s, *adv=1;
	else if (*s=='?') code=*s, *adv=1;
	else *adv=0;
	if (*adv>0) return code;
	return FALSE;
}


/* isinnerop()
 * select only those operators that enter an inner product */
int isinnerop(char *s, int *adv) {
	char code=0;
	/* multi-character operators (2) */
	     if (*s=='<' && *(s+1)=='=')  code='j', *adv=2;
	else if (*s=='>' && *(s+1)=='=')  code='k', *adv=2;
	else if (*s=='^' && *(s+1)=='~')  code='f', *adv=2;
	else if (*s=='v' && *(s+1)=='~')  code='y', *adv=2;
	/* classic scalar operators */
	else if (*s=='+') code=*s, *adv=1; 
	else if (*s=='-') code=*s, *adv=1; 
	else if (*s=='x') code=*s, *adv=1; 
	else if (*s=='%') code=*s, *adv=1; 
	else if (*s=='{') code=*s, *adv=1; 
	else if (*s=='}') code=*s, *adv=1; 
	else if (*s=='*') code=*s, *adv=1; 
	else if (*s=='&') code=*s, *adv=1; 
	else if (*s=='|') code=*s, *adv=1; 
	else if (*s=='!') code=*s, *adv=1; 
	else if (*s=='?') code=*s, *adv=1; 
	else if (*s=='o') code=*s, *adv=1; 
	else if (*s=='^') code=*s, *adv=1; 
	else if (*s=='v') code=*s, *adv=1; 
	else if (*s=='<') code=*s, *adv=1; 
	else if (*s=='>') code=*s, *adv=1; 
	else if (*s=='=') code=*s, *adv=1; 
	else if (*s=='#') code=*s, *adv=1; 
	else *adv=0;
	if (*adv>0) return code;
	return FALSE;
}


/******************************************
 *		 PARSING		*
 ******************************************/
/* isin() 
 * check if element item is in vector vect */
int isin(int item, TDeclare vect) {
	int i;
	for (i=vect.col;i>=1;i--) {
		if (item==getArrayVal(vect,1,i))
			return TRUE;
	}
	return FALSE;
}


/* do_tracing()
 * perform the printing of the tracing string */
void do_tracing(int l, TDeclare *res, int pC) {
	char *str=NULL, *out=NULL;
	int lim;
	checkStop;
	/* get result object*/
	if (res->elem) {
		printArray(&out,*res);
		lim=strlen(out)+COMPSTR;
		str=malloc((size_t)(lim));
		if (!strncasecmp_(pn[pC].m[l],"->",2)) strncpy_(str,"-> ",lim);
		else strncpy_(str,VOIDS,lim);
		if (res->rank==VECTOR && !res->col) strncat_(str,"<empty vector>",lim);
		else if (res->rank==MATRIX && (!res->col || !res->row)) strncat_(str,"<empty matrix",lim);
		else strncat_(str,out,lim);
	}
	else {
		str=malloc((size_t)COMPSTR);
		strncpy_(str,"<void>",COMPSTR);
	}
	/* print tracing line */
	if (isin(l,traceV) && !isError && !isInterrupt && !strcmp(traceName,pn[pC].name)) {
		emit(1,"%s[%d] %s\n",pn[pC].name,l,str);
	}
	free(out);
	free(str);
}


char *findSep(char *s) {
	if (!s || !*s) return NULL;
	while (*s) {
		/* discard |'| which cannot be confused with a string */
		if (!strncmp(s,"|'|",3)) s+=3;
		/* consume 'strings' */
		else if (*s=='\'') {
			s++;
			while (*s) {
				if (*s=='\'' && *(s+1)=='\'') s++;
				else if (*s=='\'') break;
				s++;
			}
			if (*s=='\'') s++;
		}
		/* consume "strings" */
		else if (*s=='\"') {
			s++;
			while (*s) {
				if (*s=='\"' && *(s+1)=='\"') s++;
				else if (*s=='\"') break;
				s++;
			}
			if (*s=='\"') s++;
		}
		/* consume [..] */
		else if (*s=='[') {
			int st=0;
			s++;
			while (*s) {
				if (*s=='[') st++;
				else if (*s==']' && st) st--;
				else if (*s==']' && !st) break;
				s++;
			}
			if (*s==']') s++;
		}
		else if (*s==';') return s;
		else s++;
	}
	return NULL;
}


/* execProg()
 * execute user program, whose code is contained into progCode
 * res will hold the result
 * at present, val1 and val2, the values of the previous and following
 * elements in case of dyadic or monadic operations are unused */
void execProg(TDeclare *res, int from, TDeclare val1, TDeclare val2, int progCode) {
	int i=0, oi=0, vs=0;
	char *isMult=NULL, *q=NULL;
	int backnoCall=noCall, blast=lastProgram;
	char *k, name[NAMESTR], *lk, pline[COMPSTR];
	strncpy_(progName,pn[progCode].name,NAMESTR);
	recursionLimit=RECURS*1024*1024/memStatus();
	pn[progCode].progbeginS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
	backBackTOS=0;
	noCall=FALSE;

	/* debug line */
	if (isDebug) emit(1,"STARTING %s\n",pn[progCode].name);

	/* check self-calling 
	 * Note: this is done on basis that Linux grants at least 24 MB per thread so that 
	 * if memory passes this limit it's likely to reach a SIGSEGV interruption 
	 * I stop before this, by evaluating the memory amount at each invocation 
	 * To change set RECURS in custom.h to a higher value */
	if (!strcmp(prevName,progName)) {
		self++;
		selfReached=self;
		if (self>=recursionLimit) {
			perror_(__LINE__,15,(int)(strlen(p)-strlen(basetot)));
			reset(backTOS);
			self=0;
			isError=TRUE;
			return;
		}
	}
	else {
		self=0;
		strncpy_(prevName,progName,COMPSTR);
	}
	

	/* get starting CPU cycle */
	gettimeofday(&tv, NULL);

	/* reset variables measure */
	if (!backTOS) maxDec=0;
	
	/* set program data */
	if (!reStart) {
		strncpy_(resName,VOIDS,NAMESTR);
		backTOS++;
		if (backTOS>=COMPVAR) {
			perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
			reset(backTOS); // ok
			return;
		}
		
		backCode[backTOS]=lastProgram=progCode;
		backStore[backTOS]=decCount;
		isResAssign[backTOS]=FALSE;
		resVar[backTOS]=0;
		resAs[backTOS]=0;

		/* instantiate dummy variables */
		if (pn[progCode].arg[0]) {
			strncpy_(resName,pn[progCode].arg,NAMESTR);
			resAs[backTOS]=0; // flag not assigned
			decCount++;
			if (decCount>=COMPVAR) {
				perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
				reset(backTOS); // ok
				return;
			}
			declare(decCount,"",NUMERIC,SCALAR,1,1);
			if (isError) return;
			resVar[backTOS]=decCount;
		}
		else strncpy_(resName,VOIDS,NAMESTR);
		if (pn[progCode].left[0]) {
			decCount++;
			if (decCount>=COMPVAR) {
				perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
				reset(backTOS); // ok
				return;
			}
			declare(decCount,pn[progCode].left,NUMERIC,SCALAR,1,1);
			if (isError) return;
			copyArray(&vn[decCount],val1);
		}
		if (pn[progCode].rights[0]) {
			decCount++;
			if (decCount>=COMPVAR) {
				perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
				reset(backTOS); // ok
				return;
			}
			declare(decCount,pn[progCode].rights,NUMERIC,SCALAR,1,1);
			if (isError) return;
			copyArray(&vn[decCount],val2);
		}
		/* instantiate local variables */
		k=pn[progCode].locals;
		while (*k) {
			lk=name;
			while (*k && *k!=';') *lk++=*k++;
			*lk='\0';
			decCount++;
			if (decCount>=COMPVAR) {
				perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
				reset(backTOS); // ok
				return;
			}
			declare(decCount,name,NUMERIC,SCALAR,1,0);
			if (isError) return;
			if (*k!=';') break; // TODO check for something not ';'?
			else k++; // skip ;
		}

		/* set argument variables */
		copyArray(&backLeft[backTOS],val1);
		copyArray(&backRights[backTOS],val2);
	}
	reStart=0;

	/* (re)address label variables */
	for (i=1;i<=pn[progCode].labelTOS;i++) {
		decCount++;
		if (decCount>=COMPVAR) {
			perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
			reset(backTOS); // ok
			return;
		}
		declare(decCount,pn[progCode].label[i],NUMERIC,SCALAR,1,1);
		if (isError) return;
		setArrayVal(vn[decCount],1,1,pn[progCode].ln[i]);
	}
	
	/* store interrupt-reprise data */ 
	isProgram=TRUE;

	/* execution */
	pn[progCode].startCount=i=from;
	p=NULL;
	while (i<=pn[progCode].endCore && !isInterrupt && !isError) {
		oi=i;
		strcpy(pline,pn[progCode].m[i]);
		strncpy_(basetot,pline,COMPSTR);
		isComplexWarning=FALSE;

		/* remove any comment */
		if ((q=strstr_oq(pline,"co"))) *q='\0';
		if ((q=strstr_o2q(pline,"co"))) *q='\0';
		free(q);

		p=pline;
		while (isblank(*p)) p++;
		if (*p==';') {
			p++;
			while (isblank(*p)) p++;
		}

		
		/* skip label */
		skipLabel();
		while (isblank(*p)) p++;

		/* avoid empty lines */
		if (!p) {
			i++;
			free_(res);
			//if (isTracing) do_tracing(oi,res,progCode);
			continue;
		}
		
		/* avoid lines with blanks*/
		while (isblank(*p)) p++;
		if (!*p) {
			i++;
			free_(res);
			//if (isTracing) do_tracing(oi,res,progCode);
			continue;
		}

		/* debug line-print */
		if (isDebug) emit(1,"  #%d %s\n",i,pline);

		/* if stop, stop setting interrupt */
		if (isStopping && isin(oi,stopV) && !isError && !isInterrupt &&\
				!strcmp(stopName,pn[progCode].name) && !isSuspStop){
			emit(1,"\n%s[%d]\n",pn[progCode].name,oi);
			isInterrupt=TRUE;
			if (isExtStopping) {
				char *out=NULL;
				printArray(&out,*res);
				emit(1,"%s\n",out);
				free(out);
			}
			continue;
		}

		/* store line number */
		progLine=i;
		backNumber[backTOS]=i;

		/* calculate expression: delegate analyse() */
		if (p && *p) {
			while (p && *p && !isError && !isInterrupt) {
				dsp=NULL;
				/* set starting p in case of multiple statements */
				isMult=findSep(p);
				if (isMult && *isMult) {
					*isMult='\0';
				}

				BASETOT=p;
				strncpy_(res->name,VOIDS,NAMESTR);
				avoidPrintResult=FALSE; // in execProg()
				/* perform the jump in execProg() */
				if (!strncasecmp_(p,"->",2)) {
					TDeclare jump;
					setArray(&jump);
					p+=2; // skip ->
					expression(&jump);
					if (isError) break;
					/* empty vectors cause stepping to the next line */
					if (jump.rank==VECTOR && !jump.col) {
						if (isMult) p=isMult+1;
					}
					/* empty matrices also cause stepping to the next line */
					else if (jump.rank==MATRIX && (!jump.col || !jump.row)) {
						if (isMult) p=isMult+1;
					}
					/* real jumps are decremented by one */
					else {
				 		/* Note: APL 1130 states that if the result of 
						 * the analysis of a go-to address is not a 
						 * scalar, the element to be considered
						 * is the one at position [1,1] */
						int val=(int)getArrayVal(jump,1,1);
						/* case of zero or of a number 
						 * beyond program limit */
						if (val<=0 || val>pn[progCode].endCore) {
							val=pn[progCode].endCore+1;
						}
						p=isMult=NULL;
						i=val-1;
					}
					/* after deciding the jump address, reset parameters 
					 * (reset also the possible multiple lines) */
					free_(&jump);
					isError=FALSE;
					instScalar(res,i+1);
					avoidPrintResult=TRUE;
					break;
				}
				else {
					if (isAnAssignment(p)) 
						avoidPrintResult=TRUE;
					analyse(res); // it parses also system commands
				}

				/* manage errors */
				if (isError) {
					globCount=0;
					break;
				}
				else if (isInterrupt) break;

				/* manage print result */
				if (!avoidPrintResult && !isError && !isInterrupt) {
					char *out=NULL;
					printArray(&out,*res);
					emit(1,"%s",out);
					free(out);
				}

				/* manage multiple lines*/
				if (isMult) {
					p=isMult+1;
					while (isblank(*p)) p++;
					if (!strncasecmp_(p,"->",2)) {
						if (!avoidPrintResult) emit(1,"%s","\n");
					}
				}
				else  {
					globCount=0;
					break;
				}
			}
			/* manage print carriage return */
			if (!avoidPrintResult && !isError && !isInterrupt) {
				emit(1,"%s","\n");
			}
		}

		/* tracing */
		if (isTracing) do_tracing(oi,res,progCode);
		
		/* stop control */
		isSuspStop=FALSE;

		/* update counter */
		i++;
	}

	/* value error in case variable is not instantiated */
	if (!isError && !isInterrupt && resName[0] && !isResAssign[backTOS]) {
		perror_(__LINE__,2,0);
	}

	/* in case of stop or irregularities, break here */
	if (isError || isInterrupt) {
		return;
	}

	/* set up for result */
	if (resVar[backTOS]>0 && pn[progCode].arg[0]) {
		avoidPrintResult=FALSE;
		copyArray(res,vn[resVar[backTOS]]);
	}
	else avoidPrintResult=TRUE;
	
	/* reset program data */
	decCount=backStore[backTOS];
	backCode[backTOS]=0;
	isResAssign[backTOS]=0;
	backNumber[backTOS]=0;
	free_(&backLeft[backTOS]);
	free_(&backRights[backTOS]);
	resVar[backTOS]=0;
	vs=searchDEC(resName,decCount);
	if (vs) {
		eraseDEC(&vn[vs]);
		strncpy_(vn[vs].name,VOIDS,NAMESTR);
	}
	/* back function data*/
	backTOS--;
	/* debug line */
	if (isDebug) {
		if (backTOS>0)
			emit(1,"ENDING %s, REPRISING %s\n",pn[progCode].name,pn[backCode[backTOS]].name);
		else 
			emit(1,"ENDING %s\n",pn[progCode].name);
	}

	resAs[backTOS]=0;
	if (backTOS>0) {
		strncpy_(resName,pn[backCode[backTOS]].arg,NAMESTR);
	}
	else strncpy_(resName,VOIDS,NAMESTR);
	/* reset flags */
	strncpy_(prevName,VOIDS,COMPSTR);
	isProgram=FALSE;
	lastProgram=blast;
	noCall=backnoCall;
	
} // end of execProg()


/* isLabel()
 * check if the string pointed by s is in the 'form' of a label */
int isLabel(char *s) {
	if (!isupper(*s)) return FALSE;
	while (isupper(*s) || isdigit(*s)) s++;
	if (*s==':') return TRUE;
	return FALSE;
}


/* skipLabel()
 * ignore label during execution */
void skipLabel(void) {
	if (isLabel(p)) {
		while (isupper(*p) || isdigit(*p)) p++;
		if (*p==':') p++;
		while (isblank(*p)) p++;
	}
}


/* insert()
 * with reference to the program in progCount,
 * insert a line in m at position pos, shifting lines up 
 * Note: this procedure does not copy the line */
int insert(int progCount, int pos) {
	int i, l=pn[progCount].endCore+1;
	if (l>=COMPSTR) {
		perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
		reset(backTOS); // ok
		return 0;
	}
	while (l>pos) {
		strncpy_(pn[progCount].m[l],pn[progCount].m[l-1],COMPSTR);
		l--;
	}
	strncpy_(pn[progCount].m[pos],VOIDS,COMPSTR);
	for (i=1;i<=pn[progCount].labelTOS;i++) {
		if (pn[progCount].ln[i]>=pos) pn[progCount].ln[i]++;
	}
	pn[progCount].endCore++;
	return pos;
}


/* delete()
 * with reference to the program in progCount,
 * delete a line in m at position pos, shifting lines down */
int delete(int progCount, int pos) {
	int l=pos+1;
	/* remove current position by moving all items
	 * that come after one position backward */
	while (l<=pn[progCount].endCore) {
		strncpy_(pn[progCount].m[l-1],pn[progCount].m[l],COMPSTR);
		pn[progCount].data[l-1]=pn[progCount].data[l]-1;
		l++;
	}
	/* update label references */
	//for (i=1;i<=pn[progCount].labelTOS;i++) {
	//	if (pn[progCount].ln[i]>=pos) pn[progCount].ln[i]--;
	//}
	/* update total (one less) */
	pn[progCount].endCore--;
	return pos;
}


/* emptySlot()
 * empty the programming slot identified by np */
void emptySlot(int np) {
	int i;
	strncpy_(pn[np].name,VOIDS,NAMESTR);
	for (i=0;i<=pn[np].endCore;i++)
		strncpy_(pn[np].m[i],VOIDS,COMPSTR);
	pn[np].isMonadic=0;
	pn[np].startCount=0;
	pn[np].argCount=0;	
	strncpy_(pn[np].arg, VOIDS,NAMESTR);
	pn[np].leftNum=0;
	strncpy_(pn[np].left,VOIDS,NAMESTR);
	pn[np].rightNum=0;
	strncpy_(pn[np].rights,VOIDS,NAMESTR);
	for (i=0;i<=pn[np].endCore;i++) {
		pn[np].data[i]=0.0;
		pn[np].ln[i]=0;
		strncpy_(pn[np].label[i],VOIDS,NAMESTR);
	}
	pn[np].labelTOS=0;
	pn[np].endCore=0;
}


/* presortProg()
 * sort program in memory using the Bubble sort algorithm 
 * all empty lines are removed from the count 
 * and the label references are updated in the process
 * at the end.
 * used in progMode() in intermediate listings */
void presortProg(int c) {
	int i,j;
	char temp[COMPSTR];
	double curr;
	/* remove empty lines */
	for (i=1;i<=pn[c].endCore;i++) {
		if (!pn[c].m[i][0]) {
			delete(c,i);
		}
	}
	/* sort lines using the Bubble Sort algorithm */
	for(i=1; i<=pn[c].endCore; i++){
		for(j=1; j<=pn[c].endCore-1; j++) {
			if (pn[c].data[j]>pn[c].data[j+1]) {
			        strncpy_(temp, pn[c].m[j], COMPSTR);
				strncpy_(pn[c].m[j], pn[c].m[j+1], COMPSTR);
				strncpy_(pn[c].m[j+1], temp, COMPSTR);
				curr=pn[c].data[j];
				pn[c].data[j]=pn[c].data[j+1];
				pn[c].data[j+1]=curr;
			}
		}
	}
#if 0
	/* update label references */
	for (i=1;i<=pn[c].endCore;i++) {
		int t;
		char *k=pn[c].m[i];
		for (j=1;j<=pn[c].labelTOS;j++) {
			t=strlen(pn[c].label[j]);
			if (!strncmp(pn[c].label[j],k,t) && *(k+t)==':') {
				pn[c].ln[j]=i;
				break;
			}
		}
	}
#endif
}


/* sortProg()
 * sort program in memory using the Bubble sort algorithm 
 * all empty lines are removed from the count 
 * and the label references are updated in the process
 * at the end, renumber the data items to an ordered 
 * numeric integer sequence 
 * used in progMode() */
void sortProg(int c) {
	int i,j;
	char temp[COMPSTR];
	double curr;
	/* remove empty lines */
	for (i=1;i<=pn[c].endCore;i++) {
		if (!pn[c].m[i][0]) {
			delete(c,i);
		}
	}
	/* sort lines using the Bubble Sort algorithm */
	for(i=1; i<=pn[c].endCore; i++){
		for(j=1; j<=pn[c].endCore-1; j++) {
			if (pn[c].data[j]>pn[c].data[j+1]) {
			        strncpy_(temp, pn[c].m[j], COMPSTR);
				strncpy_(pn[c].m[j], pn[c].m[j+1], COMPSTR);
				strncpy_(pn[c].m[j+1], temp, COMPSTR);
				curr=pn[c].data[j];
				pn[c].data[j]=pn[c].data[j+1];
				pn[c].data[j+1]=curr;
			}
		}
	}
	/* reset label references */
	for (i=1;i<=pn[c].endCore;i++) {
		int t;
		char *k=pn[c].m[i];
		for (j=1;j<=pn[c].labelTOS;j++) {
			t=strlen(pn[c].label[j]);
			if (!strncmp(pn[c].label[j],k,t) && *(k+t)==':') {
				pn[c].ln[j]=i;
				break;
			}
		}
	}
}


/* exists()
 * checks if the reference ll is an already existing data element 
 * in the program, whose index is returned used in progMode() */
int exists(int c, double ll) {
	int i;
	for (i=1;i<=pn[c].endCore;i++) {
		if (fabs(ll-pn[c].data[i])<1E-7)
			return i;
	}
	return FALSE;
}


/* progMode()
 * perform the program mode in APL session, using the record c 
 * aa is the current line passed, which is re-read in case */
void progMode(int c, char *aa) {
	char prom[2*COMPSTR+2], spaces[COMPSTR];
	char exa[COMPSTR], *a=aa;
	int count=pn[c].endCore+1;
	int lcount=0;
	double ll=pn[c].endCore+1, inc=1, t=0;
	strncpy_(exa,"",COMPSTR);
	while (TRUE) {
		if (count>=COMPSTR) {
			perror_(__LINE__,10,0);
			reset(backTOS); // ok
			return;
		}
		
		if (isInterrupt || isError) return;
		/* thanks to Chet Ramey and his examples in
		 * https://tiswww.case.edu/php/chet/readline/readline.html#Readline-Variables
		 * I could solve a big memory problem using readline */
		if (!a || !*a) {
			char nums[COMPSTR], *b=NULL;
			/* build prompt */
			snprintf(nums,COMPSTR,"%G",ll);
			if (strlen(nums)<=3) makeSpaces(spaces,3-strlen(nums)+1);
			else makeSpaces(spaces,1);
			snprintf(prom,2*COMPSTR+2,"[%s]%s",nums,spaces);
			/* ask for line */
			b=readline(prom);
			if (b && *b) {
				while (isblank(*rl_line_buffer)) rl_line_buffer++;
				if (strcmp(rl_line_buffer,exa)) add_history(rl_line_buffer);
				strncpy_(exa,rl_line_buffer,COMPSTR);
				a=exa;
				if (isScript) fprintf(FS,"%s%s\n",prom,a);
			}
			free(b);
		}
		/* treat the case of re-indexing [] and internal listing */
		if (*a=='[') {
			a++;
			while (isblank(*a)) a++;
			/* remake header using the figure [0] */
			if (*a=='0' && *(a+1)==']') {
				a+=2;
				while (isblank(*a)) a++;
				if (*a) {
					getHeader(a,&a,c);
					if (pn[c].data[1]) ll=pn[c].data[1];
					else ll=1;
					count=1;
				}
				a=NULL;
				continue;
			}
			/* insertion using a real decimal number */
			else if (isflot(a)) {
				double N=0.0;
				int i=0;
				N=strtod(a,&a);
				/* size N */
				if (N>pn[c].endCore) N=pn[c].endCore+1;
				if ((i=exists(c,N))) {
					count=i;
					ll=pn[c].data[i];
				}
				else {
					count=pn[c].endCore+1;
					ll=N;
				}
				while (isblank(*a)) a++;
				/* perform the listing types N|_| or N|_|M */
				if (!strncasecmp_(a,"|_|",3)) {
					a+=3;
					if (isScript) do_list(FS,c,count,count,FALSE,TRUE);
					while (isblank(*a)) a++;
					/* apple treats the case [N|_|M] as a listing
					 * from N to M included */
					if (isflot(a)) {
						double M=strtod(a,&a);
						/* size input */
						if (M>pn[c].endCore) M=pn[c].endCore;
						if (M<N) M=N;
						while (isblank(*a)) a++;
						presortProg(c);
						do_list(stdout,c,N,M,FALSE,TRUE);
						if (M+1>pn[c].endCore) {
							count=pn[c].endCore+1;
							ll=count;
						}
						else {
							count=M+1;
							ll=pn[c].data[count];
						}
					}
					/* in case of [N|_|] (single left number)
					 * list that single line */
					else {
						do_list(stdout,c,count,count,FALSE,TRUE);
						/* Note: no need to change count
						 * and ll here...*/
					}
					checkClose;
					continue;
				}
			}
			/* list in case of |_| or |_|M */
			else if (!strncasecmp_(a,"|_|",3)) {
				a+=3;
				while (isblank(*a)) a++;
				/* apple treats the case [|_|M] (single right number)
				 * by listing from M to the end of program */
				if (isflot(a)) {
					double M=strtod(a,&a);
					while (isblank(*a)) a++;
					presortProg(c);
					do_list(stdout,c,M,pn[c].endCore,FALSE,TRUE);
					count=pn[c].endCore+1;
					ll=count;
				}
				/* else [|_|] list the entire program */
				else if (*a==']') {
					presortProg(c);
					do_list(stdout,c,1,pn[c].endCore,TRUE,TRUE);
					count=pn[c].endCore+1;
					pn[c].data[count]=count;
					ll=pn[c].data[pn[c].endCore]+1;
				}
				checkClose;
				continue;
			}
			checkClose;
			while (isblank(*a)) a++;
			/* erase in case the number is followed by nothing */
			if (!*a) {
				strncpy_(pn[c].m[count],VOIDS,COMPSTR);
				pn[c].data[count]=0;
			}
		}
		/* close in case of \/ */
		else if (!strcmp(a,"\\/")) {
			int i;
			sortProg(c);
			for (i=1;i<=pn[c].endCore;i++) {
				pn[c].data[i]=i;
			}
			break;
		}
		/* close in case of \/ followed by anything */
		else if (!strncasecmp_(a,"\\/",2)) {
			int i;
			sortProg(c);
			for (i=1;i<=pn[c].endCore;i++) {
				pn[c].data[i]=i;
			}
			break;
		}

		while (isblank(*a)) a++;
		/* evaluate the label in the added line */
		if (isLabel(a)) {
			int k=0, j=0;
			char *pb=a;
			lcount++;
			j=0;
			while (isupper(*a) || isdigit(*a)) {
				pn[c].label[lcount][k++]=*a++;
				j++;
				if (j>=NAMESTR) break;
			}
			pn[c].label[lcount][k]='\0';
			pn[c].ln[lcount]=count;
			pn[c].labelTOS=lcount;
			pn[c].hasLabel=TRUE;
			if (*a==':') a++;
			a=pb;
		}
		else pn[c].hasLabel=FALSE;

		/* calculate the new provisional line number */
		t=ll;
		inc=1;
		while (fabsl((t-(int)t))>1E-10) inc/=10.0, t*=10.0;

		while (isblank(*a)) a++;
		/* add system command only if admitted */
		if (*a==')') {
			char *b=a;
			b++; //skip )
			while (isblank(*b)) b++;
			if (!isNotBanned(b)) {
				perror_(__LINE__,14,0);
				break;
			}
		}
		/* case of regular line */
		if (a && *a) {
			char *k=pn[c].m[count];
			while (*a && strcmp(a,"\\/")) *k++=*a++;
			*k='\0';
			pn[c].data[count]=ll;
		}
		/* in case of label without content, add three spaces */
		else if (pn[c].hasLabel) {
			char *k=pn[c].m[count];
			int j=3;
			while (j>0) *k++=' ', j--;
			*k='\0';
			pn[c].data[count]=ll;
		}
		/* otherwise set line empty */
		else {
			strncpy_(pn[c].m[count],VOIDS,COMPSTR);
			pn[c].data[count]=0;
			count--;
			ll-=inc;
		}
		if (count>pn[c].endCore) pn[c].endCore=count;
		count++;
		ll+=inc;
		while (isblank(*a)) a++;
	}
} // end of progMode()


/* getHeader()
 * analyse the header of an user-program and establish the type of program */
int getHeader(char *p, char **newp, int uProgCount) {
	char name[MAXARGS][NAMESTR], *k;
	int nameTOS=1, myisAssign=FALSE, j,t;
	/* get first name */
	j=0;
	strncpy_(name[nameTOS],VOIDS,NAMESTR);
	k=name[nameTOS];
	while (isblank(*p)) p++;
	while (isupper(*p) || isdigit(*p)) {
		*k++=*p++;
		j++;
		if (j>=NAMESTR) break;
	}
	*k='\0';

	/* lower letters not admitted */
	if (islower(*p) && strncmp(p,"co",2)) {
		perror_(__LINE__,7,(int)(strlen(p)-strlen(basetot)));
		return FALSE;
	}
	
	while (isblank(*p)) p++;
	if (!strncasecmp_(p,"<-",2)) p+=2, myisAssign=TRUE;
	while (isblank(*p)) p++;
	/* get all items until the start of local variables */
	while (*p && *p!=';' && *p!='[' && *p!='\\') {
		j=0;
		nameTOS++;
		if (nameTOS>=MAXARGS) {
			perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
			return FALSE;
		}
		k=name[nameTOS];
		if (!isupper(*p)) {
			perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
			return FALSE;
		}
		while(isupper(*p) || isdigit(*p)) {
			*k++=*p++;
			j++;
			if (j>=NAMESTR) break;
		}
		*k='\0';
		while (isblank(*p)) p++;
	}
	/* check if some name is the same */
	j=1;
	if (*p) while (j<=3) {
		t=j+1;
		while (t<=4) {
			if (!strcmp(name[j],name[t]) && name[j][0] && name[t][0]) {
	 	 		perror_(__LINE__,7,(int)(strlen(p)-strlen(basetot)));
				return FALSE;
			}
			t++;
		}
		j++;
	}
	if (*p==';') p++; // skip divisor
	/* case \/ F */
	if (nameTOS==1 && !myisAssign) {
		/* function's name */
		strncpy_(pn[uProgCount].name,name[1],NAMESTR);
		pn[uProgCount].isMonadic=0; // standalone
	}
	/* case \/ Z<-F */
	else if (nameTOS==2 && myisAssign) {
		/* return value */
		strncpy_(pn[uProgCount].arg,name[1],NAMESTR);
		/* function's name */
		strncpy_(pn[uProgCount].name,name[2],NAMESTR);
		pn[uProgCount].isMonadic=0; // standalone 
	}
	/* case \/ F Y */
	else if (nameTOS==2 && !myisAssign) {
		/* function's name */
		strncpy_(pn[uProgCount].name,name[1],NAMESTR);
		/* right argument value */
		strncpy_(pn[uProgCount].rights,name[2],NAMESTR);
		pn[uProgCount].rightNum++;
		pn[uProgCount].isMonadic=1; // monadic
	}
	/* case \/ Z<-F Y*/
	else if (nameTOS==3 && myisAssign) {
		/* return value */
		strncpy_(pn[uProgCount].arg,name[1],NAMESTR);
		/* function's name */
		strncpy_(pn[uProgCount].name,name[2],NAMESTR);
		/* right argument value */
		strncpy_(pn[uProgCount].rights,name[3],NAMESTR);
		pn[uProgCount].rightNum++;
		pn[uProgCount].isMonadic=1; // monadic
	}
	/* case \/ X F Y */
	else if (nameTOS==3 && !myisAssign) {
		/* left argument value */
		strncpy_(pn[uProgCount].left,name[1],NAMESTR);
		pn[uProgCount].leftNum++;
		/* function's name */
		strncpy_(pn[uProgCount].name,name[2],NAMESTR);
		/* right argument value */
		strncpy_(pn[uProgCount].rights,name[3],NAMESTR);
		pn[uProgCount].rightNum++;
		pn[uProgCount].isMonadic=-1; // dyadic
	}
	/* case \/ Z<-F Y */
	else if (nameTOS==3 && myisAssign) {
		/* return value */
		strncpy_(pn[uProgCount].arg,name[1],NAMESTR);
		/* function's name */
		strncpy_(pn[uProgCount].name,name[2],NAMESTR);
		/* right argument values */
		strncpy_(pn[uProgCount].arg,name[3],NAMESTR);
		pn[uProgCount].rightNum++;
		pn[uProgCount].isMonadic=1; // monadic
	}
	/* case \/ Z<-X F Y */
	else if (nameTOS==4 && myisAssign) {
		/* return value */
		strncpy_(pn[uProgCount].arg,name[1],NAMESTR);
		/* left argument value */
		strncpy_(pn[uProgCount].left,name[2],NAMESTR);
		pn[uProgCount].leftNum++;
		/* function's name */
		strncpy_(pn[uProgCount].name,name[3],NAMESTR);
		/* right argument values */
		strncpy_(pn[uProgCount].rights,name[4],NAMESTR);
		pn[uProgCount].rightNum++;
		pn[uProgCount].isMonadic=-1; // dyadic
	}
	else return FALSE;
	/* get local variables */
	while (isblank(*p)) p++;
	k=pn[uProgCount].locals;
	while (isupper(*p)) {
		while (*p && (isupper(*p) || isdigit(*p))) *k++=*p++;
		while (isblank(*p)) p++;
		if (*p!=';') break;
		else *k++=*p++;
		while (isblank(*p)) p++;
	}
	*k='\0';
	if (newp) *newp=p;
	return TRUE;
} // end of getHeader()


/* printNamesList()
 * print the names in alphabetic order and in a fixed grid
 * of cells */
void printNamesList(int kind) {
	int i=1, j=0, n=0, count=0;
	int winsize=0, size=decCount+progCount;
	char temp[COMPSTR], name[size+1][COMPSTR];

	/* clean */
	for (i=1;i<=size;i++) 
		strncpy_(name[i],VOIDS,COMPSTR);

	/* get window size */
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	winsize=(int)wsz.ws_col;

	/* gather var names */
	if (kind==VARVS) {
		for (i=1;i<=decCount;i++)
			strncpy_(name[i],vn[i].name,COMPSTR);
		n=decCount;
	}
	else if (kind==FNCTS) {
		for (i=1;i<=progCount;i++)
			strncpy_(name[i],pn[i].name,COMPSTR);
		n=progCount;
	}
	else {
		return;
	}

	/* bubble sort ordering */
	for (i=1;i<=n;i++) {
        	for (j=0;j<=n-i;j++) {
			/* swap */ 
        		if (strcmp(name[j], name[j+1])>0) {
                		strncpy_(temp, name[j],COMPSTR);
                		strncpy_(name[j], name[j+1],COMPSTR);
                		strncpy_(name[j+1],temp,COMPSTR);
            		}
        	}
    	}
	/* print elements */
	for (i=1;i<=n;i++) {
		if (!name[i][0]) continue;
		/* case of lengths under the 8 characters */
		if (strlen(name[i])<=7) {
			if (count+8>winsize) {
				emit(1,"\n");
				count=0;
			}
			emit(1,"%-8s",name[i]);
			count+=8;
		}
		/* case of lengths between the 8-*15 characters */
		else if (strlen(name[i])<=15) {
			if (count+16>winsize) {
				emit(1,"\n");
				count=0;
			}
			emit(1,"%-16s",name[i]);
			count+=16;
		}
	}
	if (count) emit(1,"\n");
} // end of printNamesList


void printTests(FILE *fs) {
	fprintf(fs,"     %s\n"," 0tM  M is null");
	fprintf(fs,"     %s\n"," 1tM  M is diagonal");
	fprintf(fs,"     %s\n"," 2tM  M is square");
	fprintf(fs,"     %s\n"," 3tM  M is positive definite");
	fprintf(fs,"     %s\n"," 4tM  M is lower triangular");
	fprintf(fs,"     %s\n"," 5tM  M is upper triangular");
	fprintf(fs,"     %s\n"," 6tM  M is symmetric");
	fprintf(fs,"     %s\n"," 7tM  M is antisymmetric");
	fprintf(fs,"     %s\n"," 8tM  M is hypo-symmetric");
	fprintf(fs,"     %s\n"," 9tM  M is invertible");
	fprintf(fs,"     %s\n","10tM  M is mono-value");
	fprintf(fs,"     %s\n","11tM  M is the identity matrix");
}


/* executeSystemCommand()
 * execute the system command in s, and return
 * in exitState the return value */
int executeSystemCommand(char *comm) {
	if (*comm!=')') {
		return -1;
	}
	else comm++; // skip ')'
	while (isblank(*comm)) comm++;
	/* save to default file, print logoff string and sign off */
	if (!strcasecmp(comm,"OFF")) {
		emit(1,"\n%s SIGNED OFF\n",username);
		doScript(FS,1,"Script session end: %s %d, %d - %02d:%02d:%02d\n", getMonthString(),getDay(),getYear(),getHour(),getMin(),getSec());
		return 1;
	}
	/* save workspace to default file */
	if (!strncasecmp_(comm,"CONT",4)) {
		saveWorkspace(defaultContinueName,defaultContinueName,FALSE,FALSE);
		emit(1,"\n%s SIGNED OFF\n",username);
		doScript(FS,1,"Script session end: %s %d, %d - %02d:%02d:%02d\n", getMonthString(),getDay(),getYear(),getHour(),getMin(),getSec());
		return 1;
	}
	/* )$ VAL [NAME]
	 * inspection (UNDOCUMENTED)
	 * report on variable VAL which is a variable code */
	else if (!strncasecmp_(comm,"$",1)) {
		char name[NAMESTR];
		char *q=comm+1;
		while (isblank(*q)) q++;
		if (*q && isdigit(*q)) {
			int ns=strtoll(q,&q,10);
			if (ns>0 && ns<=decCount) {
				while (isblank(*q)) q++;
				if (*q && isupper(*q)) {
					strncpy_(name,q,NAMESTR);
					strncpy(vn[ns].name,name,NAMESTR);
					inspect(stdout,vn[ns],ns);
					if (isScript) inspect(FS,vn[ns],ns);
				}
				else {
					inspect(stdout,vn[ns],ns);
					if (isScript) inspect(FS,vn[ns],ns);
				}
			}
			else emit(1,"NO VAR WITH CODE %d\n",ns);
		}
		else {
			emit(1,"VALUE ERROR\n");
		}
	}
	/* )? NAME
	 * )^ NAME
	 * inspection (UNDOCUMENTED)
	 * report on NAME which is a function or a variable name */
	else if (!strncasecmp_(comm,"?",1) || !strncasecmp_(comm,"^",1)) {
		char name[COMPSTR], *k=name;
		char *q=comm+1;
		while (isblank(*q)) q++;
		if (*q && isupper(*q)) {
			int ns=0;
			while (isupper(*q) || isdigit(*q)) {
				*k++=*q++;
			}
			*k='\0';
			ns=searchDEC(name,decCount);
			if (ns) {
				inspect(stdout,vn[ns],ns);
				if (isScript) inspect(FS,vn[ns],ns);
			}
			else {
				ns=findProg(name);
				if (ns) {
					proginspect(stdout,pn[ns],ns);
					if (isScript) proginspect(FS,pn[ns],ns);
				}
				else {
					emit(1,"%s NOT FOUND\n",name);
				}
			}

		}
		else {
			emit(1,"VALUE ERROR\n");
		}
	}
	/* )CLEAR
	 * clear workspace */
	else if (!strncasecmp_(comm,"CLEA",4)) {
		eraseCurrentWorkspace();
		gettimeofday(&tv, NULL);
		beginS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		beginMS=(long long int)(tv.tv_sec*1000 + tv.tv_usec / 1000.0);
	}
	/* )COMP [NUM]
	 * comparison tolerance
	 * set NUM as the comparison tolerance 
	 * (0 | 1-77, that is 0 | 1E-1<=NUM<=1E-77) */
	else if (!strncasecmp_(comm,"COMP",4)) {
		int was=(Wcomp==0.0)?0:-log10(Wcomp);
		char *s=comm+4;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			int val=abs((int)getNum(s,&s));
			if (!val || (val>=WHigh && val<=WBond)) {
				if (!val) Wcomp=0.0;
				else Wcomp=pow(10.0,-val);
				emit(1,"WAS %d\n",was);
			}
			else {
				emit(1,"IS %d\n",was);
			}
		}
		else emit(1,"IS %d\n",was);
	}
	/* )COPY WSID [NAMES] 
	 * copy all or some objects from a stored workspace */
	else if (!strncasecmp_(comm,"COPY",4)) {
		char *q=comm+4;
		char name[COMPSTR], names[COMPSTR], resp[COMPSTR], *n;
		strncpy_(name,VOIDS,NAMESTR);
		n=name;
		while (isblank(*q)) q++;
		/* this is a file name... */
		while(*q && !isblank(*q)) *n++=*q++;
		*n='\0';
		strncpy_(names,VOIDS,COMPSTR);
		n=names;
		while (isblank(*q)) q++;
		if (isupper(*q)) {
			while (*q) *n++=*q++;
			*n='\0';
		}
		copyWorkspace(name,names,resp,FALSE);
		if (resp[0]) {
			emit(1,"%s\n",resp);
		}
	}
	/* )DATE (NOT STANDARD)
	 * print current date (not standard) */
	else if (!strcasecmp(comm,"DATE")) {
		emit(1,"Date: %s %02d, %d\n",getMonthString(),getDay(),getYear());
	}
	/* )DEBUG (NOT STANDARD)
	 * toggle debug mode */
	else if (!strncasecmp_(comm,"DEBU",4)) {
		char *q=comm+4;
		while (*q && !isblank(*q)) q++;
		while (isblank(*q)) q++;
		if (!strcasecmp(q,"OFF")) isDebug=FALSE;
		else if (!*q) isDebug=TRUE;
		emit(1,"DEBUG IS %s\n",isDebug?"ON":"OFF");
	}
	/* )DESCRIBE (NOT STANDARD)
	 * get or show the WSID description */
	else if (!strncasecmp_(comm,"DESC",4)) {
		if (describe && *describe) {
			char *t=describe;
			while (*t) putc(*t++,stdout);
			putc('\n',stdout);
		}
		else {
			emit(1,"NO DESCRIPTION.\n");
		}
	}
	/* )DIGIT [NUM]
	 * set NUM precision digits (1<=NUM<=16) */
	else if (!strncasecmp_(comm,"DIGI",4)) {
		int was=Wdigit;
		char *s=comm+4;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			Wdigit=strtol(s,&s,10);
			if (Wdigit>=WHigh && Wdigit<=WAcc) {
				snprintf(numformat,COMPSTR,"%%.%0dG  ",Wdigit);
				emit(1,"WAS %d\n",was);
			}
			else if (Wdigit==0) {
				snprintf(numformat,COMPSTR,"%%.06G  ");
				emit(1,"WAS %d\n",was);
			}
			else {
				Wdigit=was;
				emit(1,"IS %d\n",Wdigit);
			}
		}
		else emit(1,"IS %d\n",Wdigit);
	}
	/* )DISCHARGE (UNDOCUMENTED)
	 * set discharge of variable at the end */
	else if (!strncasecmp_(comm,"DISC",4)) {
		isCompleteUnload=TRUE;
	}
	/* )DISPOSE (NOT STANDARD)
	 * clear screen */
	else if (!strncasecmp_(comm,"DISP",4)) {
		system("clear");
	}
	/* )DIV [NUM] (NOT STANDARD)
	 * set division tolerance (zero or not zero) */
	else if (!strncasecmp_(comm,"DIV",3)) {
		int was=Wdiv;
		char *s=comm+3;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			Wdiv=strtol(s,&s,10);
			emit(1,"WAS %d\n",was);
		}
		else emit(1,"IS %d\n",Wdiv);
	}
	/* )DROP [WSID]
	 * erase workspace */
	else if (!strncasecmp_(comm,"DROP",4)) {
		char *q=comm+4;
		char name[COMPSTR], resp[COMPSTR], *n;
		strncpy_(name,VOIDS,NAMESTR);
		n=name;
		while (isblank(*q)) q++;
		if (*q && isupper(*q)) {
			while (*q && (isupper(*q) || isdigit(*q))) *n++=*q++;
			*n='\0';
		}
		dropWorkspace(name,resp);
		emit(1,"%s\n",resp);
	}
	/* )EDIT [FILE] NAME (NOT STANDARD) 
	 * edit file or function with the editor */
	else if (!strncasecmp_(comm,"EDIT",4)) {
		char *q=comm+4, func[COMPSTR], *f=func;
		FILE *fd;
		while (isblank(*q)) q++;
		/* case of file */
		if (!strncasecmp_(q,"FILE",4)) {
			char edit[COMPSTR];
			q+=4;
			while (isblank(*q)) q++;
			while (*q) *f++=*q++;
			*f='\0';
			fd=fopen(func,"r");
			if (!fd) fopen(func,"w");
			if (fd) fclose(fd);
			strncpy_(edit,VEDIT,COMPSTR);
			strncat_(edit," ",COMPSTR);
			strncat_(edit,func,COMPSTR);
			system(edit);
			/* Note: no removal here */
		}
		/* case of func */
		else {
			int ns, doExistFunc=TRUE;
			FILE *fs;
			char edit[COMPSTR];
			/* get function name */
			while (*q && isupper(*q)) *f++=*q++;
			*f='\0';
			/* check if existing */
			ns=findProg(func);
			if (!ns) {
				doExistFunc=FALSE;
				ns=++progCount;
			}
			
			/* create editing command */
			strncpy_(edit,VEDIT,COMPSTR);
			strncat_(edit," ",COMPSTR);
			strncat_(edit,func,COMPSTR);
			
			/* in case of a function which is present */
			if (doExistFunc) {
				/* open file and reset it if it exists */
				fs=fopen(func,"w");
				if (!fs) emit(1,"CANNOT OPEN FILE FOR EDITING FUNCTION %s\n",func);
				else {
					/* store current function */
					do_list(fs,ns,1,pn[ns].endCore,TRUE,FALSE);
					/* close file (the editor will load it) */
					fclose(fs);
					/* start editing */
					system(edit);
					/* reload file */
					emptySlot(ns);
					load(func,ns);
					strncpy_(pn[ns].name,func,NAMESTR);
					remove(func);
				}
			}
			/* else create an empty file */
			else {
				/* open file and reset it */
				fs=fopen(func,"w");
				if (!fs) emit(1,"CANNOT OPEN FILE FOR EDITING FUNCTION %s\n",func);
				else {
					/* close file (the editor will load it) */
					fclose(fs);
					/* start editing */
					system(edit);
					/* rebuild file name */
					strncpy_(edit,func,COMPSTR);
					/* reload file */
					load(func,ns);
					strncpy_(pn[ns].name,func,NAMESTR);
					remove(func);
				}
			}
		}
	}
	/* )ERASE NAME[S]
	 * erase object(s) */
	else if (!strncasecmp_(comm,"ERAS",4)) {
		int nsv=0, nsp=0;
		char *q=comm+4;
		char name[COMPSTR], *n, resp[COMPSTR];
		char output[COMPSTR];
		while (*q && !isblank(*q)) q++;
		strncpy_(output,VOIDS,COMPSTR);
		while (isblank(*q)) q++;
		if (!strncasecmp_(q,"@VARS",5)) {
			decCount=0;
			emit(1,"%s\n","ALL VARIABLES CLEARED.");
		}
		else if (!strncasecmp_(q,"@PROGS",6)) {
			int i;
			for (i=0;i<=progCount;i++) pn[i].labelTOS=0;
			progCount=0;
			emit(1,"%s\n","ALL PROGRAMS CLEARED.");
		}
		else while (*q && isupper(*q)) {
			n=name;
			while (isupper(*q) || isdigit(*q)) {
				*n++=*q++;
			}
			*n='\0';
			while (isblank(*q)) q++;
			/* variables and programs */
			nsv=searchDEC(name,decCount);
			nsp=findProg(name);
			/* erase variable */
			if (nsv) {
				strncpy_(vn[nsv].name,VOIDS,NAMESTR);
			}
			/* erase program */
			else if (nsp) {
				strncpy_(pn[nsp].name,VOIDS,NAMESTR);
			}
			/* if not found, add name to the not-found list */
			else {
				strncat_(output," ",COMPSTR);
				strncat_(output,name,COMPSTR);
			}
		}
		/* now save and reload the workspace */
		saveWorkspace(".aplErase.wpc",resp,FALSE,FALSE);
		loadWorkspace(".aplErase.wpc",resp,FALSE);
		remove(".aplErase.wpc");
		/* print not-found list*/
		if (output[0]) {
			emit(1,"%s NOT FOUND\n",output);
		}
	}
	/* )EXP [NUM] (NOT STANDARD)
	 * set or get exponential flag (0|1) */
	else if (!strncasecmp_(comm,"EXP",3) && *(comm+3)!='O') {
		int was=isExp;
		char *s=comm+3;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			isExp=strtol(s,&s,10);
			if (isExp==1 || isExp==0) {
				emit(1,"WAS %d\n",was);
			}
			else {
				isExp=was;
				emit(1,"IS %d\n",isExp);
			}
		}
		else emit(1,"IS %d\n",isExp);
	}
	/* )EXPORT NAME (NOT STANDARD)
	 * )WRITE NAME
	 * export program to textual file *.apl */
	else if (!strncasecmp_(comm,"EXPO",4) || !strncasecmp_(comm,"WRIT",4)) {
		char name[COMPSTR], file[COMPSTR], *n, *q;
		char header[COMPSTR];
		int ns=0;
		q=comm+4;
		while (*q && !isblank(*q)) q++;
		n=name;
		strncpy_(name,VOIDS,COMPSTR);
		while (isblank(*q)) q++;
		if (*q && isupper(*q)) {
			while(*q && (isupper(*q) || isdigit(*q))) *n++=*q++;
		}
		*n='\0';
		strncpy_(file,name,COMPSTR);
		strncat_(file,".apl",COMPSTR);
		ns=findProg(name);
		if (ns) {
			char doc[NAMESTR], *d=doc;
			buildHeader(ns,header);
			int ds=0;
			/* build documentation name */
			*d++='D';
			strncpy_(d,name,NAMESTR);
			ds=searchDEC(doc,decCount);
			if (!(do_export(file,ns,header,ds))) {
				emit(1,"%s EXPORTED\n",name);
			}
		}
		else {
			emit(1,"%s NOT EXPORTED\n", name);
		}
	}
	/* )FILES (NOT STANDARD)
	 * list of channels' states */
	else if (!strncasecmp_(comm,"FILE",4)) {
		int i=0;
		for (i=1;i<=STREAMS;i++) {
			if (channel[i].isOpen) {
				emit(1,"CHANNEL %d IS OPENED IN %s MODE TO FILE '%s'\n",i,channel[i].wayout==VREAD?"read":"write",channel[i].name);
			}
			else {
				emit(1,"CHANNEL %d IS CLOSED.\n",i);
			}
		}
	}
	/* )FLAG (UNDOCUMENTED)
	 * print flags */
	else if (!strncasecmp_(comm,"FLAG",4)) {
		emit(1,"System flags:\n");
		emit(1,"  self=%d\n",self);
		emit(1,"  noCall=%d\n",noCall);
		emit(1,"  reStart=%d\n",reStart);
		emit(1,"  backTOS=%d\n",backTOS);
		emit(1,"  isDebug=%d\n",isDebug);
		emit(1,"  isError=%d\n",isError);
		emit(1,"  isProgram=%d\n",isProgram);
		emit(1,"  globCount=%d\n",isProgram);
		emit(1,"  isInterrupt=%d\n",isInterrupt);
		emit(1,"  backBackTOS=%d\n",backBackTOS);
		emit(1,"  selfReached=%d\n",selfReached);
		emit(1,"  lastProgram=%d\n",lastProgram);
		emit(1,"  avoidPrintResult=%d\n",avoidPrintResult);
		emit(1,"\nNo. of pending functions=%d\n",backTOS);
		emit(1,"\nNo. of user programs=%d\n",progCount);
		emit(1,"No. of declared variables=%d\n",decCount);
	}
	/* )FNS
	 * list of defined functions */
	else if (!strcasecmp(comm,"FNS")) {
		printNamesList(FNCTS);
	}
	/* )FUZZ [VAL] (NOT STANDARD)
	 * set val as the zero limit  */
	else if (!strncasecmp_(comm,"FUZZ",4)) {
		int was=Wfuzz;
		char *s=comm+4;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			Wfuzz=strtol(s,&s,10);
			if (Wfuzz>=WHigh && Wfuzz<=WBond) {
				fuzzValue=pow(10.0,-Wfuzz);
				emit(1,"WAS %d\n",was);
			}
			else if (Wfuzz==0.0) {
				fuzzValue=0.0;
				emit(1,"WAS %d\n",was);
			}
			else {
				Wfuzz=was;
				emit(1,"IS %d\n",was);
			}
		}
		else emit(1,"IS %d\n",Wfuzz);
	}
	/* )HELP [op] (NOT STANDARD) 
	 * give a help about specific operator */
	else if (!strncasecmp_(comm,"HELP",4)) {
		char *q=comm+4;
		while (isblank(*q)) q++;
		if (!*q) {
			callHelp(stdout);
			if (isScript) callHelp(FS);
		}
		else if (!strncasecmp_(q,"TRAC",4)) {
			emit(1,"\ntemplate:\n       T/\\ <name> <- <list>\ne.g.:\n       T/\\FAC<-3 5 	==>  	set trace on lines 3,5 of FAC\n       T/\\BAL<-i8 	==>  	set trace on first 8 lines of BAL\n");
		}
		else if (!strncasecmp_(q,"STOP",4)) {
			emit(1,"\ntemplate:\n       S/\\ <name> <- <list>\ne.g.:\n       S/\\FAC<-3 5 	==>  	set stop on lines 3,5 of FAC\n       S/\\BAL<-i8 	==>  	set stop on first 8 lines of BAL\n");
		}
		else if (!strncasecmp_(q,"TEST",4)) {
			emit(1,"     %s\n\n","Tests range X t M");
			printTests(stdout);
			if (isScript) printTests(FS);
		}
		else {
			while (isblank(*(q+strlen(q)))) 
				*(q+strlen(q))='\0';
			emit(1,"Help for the symbol %s\n",q);
			getSpecificHelp(q,stdout);
			emit(1,"%s","\n");
			if (isScript) getSpecificHelp(q,FS);
		}
	}
	/* )IBEAM (NOT STANDARD)
	 * give a help about I_Beams  */
	else if (!strncasecmp_(comm,"IBEA",4)) {
		callIBeam(stdout);
		if (isScript) callIBeam(FS);
	}
	/* )IBM (UNDOCUMENTED)
	 * show my thanks to IBM for creating this wonderful program 
	 * (The easter egg) */
	else if (!strcasecmp(comm,"IBM")) {
		emit(1," Thanks to Kenneth E. Iverson for his theory.\n Thanks to IBM for creating this wonderful language,\n thanks to Adin Falkoff, William C. Carter and Edward H. Sussenguth Jr.\n for having been present during creation,\n thanks to John L. Lawrence for making it an educational tool,\n thanks to Lawrence M. Breed and Philip S. Abrams for completion\n of the language notation and the 1130 version setting.\n Thanks to all of you.\n");
	}
	/* )IMPORT NAME (NOT STANDARD)
	 * )READ NAME
	 * load fns from textual file *.apl */
	else if (!strncasecmp_(comm,"IMPO",4) || !strncasecmp_(comm,"READ",4)) {
		char file[COMPSTR], name[COMPSTR], *n, *q, resp[COMPSTR];
		int ns=0, progn;
		q=comm+4;
		while (*q && !isblank(*q)) q++;
		strncpy_(name,VOIDS,COMPSTR);
		strncpy_(file,VOIDS,COMPSTR);
		n=file;
		while (isblank(*q)) q++;
		/* it's a file name... */
		while(*q && !isblank(*q)) *n++=*q++;
		*n='\0';
		strncpy_(name,basename(file),NAMESTR);
		turnToUpper(name);
		n=name+strlen(name)-1;
		while (n>name && *n!='.') n--;
		if (*n=='.') *n='\0';
		/* search if already loaded */
		ns=findProg(name);
		if (ns>0 && name[0]) {
			emit(1,"%s ALREADY IMPORTED\n",name);
			return 0;
		}
		else if (name[0]) {
			progn=progCount+1;
			progCount++;
			if (progCount>=COMPSTR) {
				perror_(__LINE__,10,0);
				reset(backTOS); // ok
				return -1;
			}
			ns=progCount;
		}
		else {
			perror_(__LINE__,10,0);
			return -1;
		}
		progn=load(file,ns);
		if (progn) {
			emit(1,"%s IMPORTED\n",name);
			strncpy_(pn[ns].name,name,NAMESTR);
		}
		else {
			/* remove the program loaded so far */
			emptySlot(ns);
			strncpy_(pn[ns].name,VOIDS,NAMESTR);
			/* now save and reload the workspace */
			saveWorkspace(".aplErase.wpc",resp,FALSE,FALSE);
			loadWorkspace(".aplErase.wpc",resp,FALSE);
			remove(".aplErase.wpc");
			emit(1,"%s NOT IMPORTED\n",name);
		}
	}
	/* )INV [NUM] (NOT STANDARD)
	 * set inversion flag (zero or not zero) */
	else if (!strncasecmp_(comm,"INV",3)) {
		int was=Winv;
		char *s=comm+3;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			Winv=strtol(s,&s,10);
			emit(1,"WAS %d\n",was);
		}
		else emit(1,"IS %d\n",Winv);
	}
	/* )LIB [OPTION] 
	 * list files in the current directory */
	else if (!strncasecmp_(comm,"LIB",3)) {
		char *q=comm+3;
		char exec[COMPSTR];
		while (isblank(*q)) q++;
		snprintf(exec,COMPSTR,"%s","ls ");
		if (*q) strncat_(exec,q,COMPSTR);
		system(exec);
	}
	/* )LIST [NAME] (NOT STANDARD)
	 * list program [NAME] in current workspace */
	else if (!strncasecmp_(comm,"LIST",4)) {
		char *q=comm+4;
		char name[COMPSTR], *n;
		int ns;
		strncpy_(name,VOIDS,NAMESTR);
		n=name;
		while (isblank(*q)) q++;
		if (*q && isupper(*q)) {
			while (*q && (isupper(*q) || isdigit(*q))) *n++=*q++;
			*n='\0';
			ns=findProg(name);
			if (ns) {
				do_list(stdout, ns,1,pn[ns].endCore,TRUE,TRUE);
			}
			else {
				emit(1,"%s NOT FOUND\n",name);
			}
		}
		else {
			emit(1,"MISSING FUNCTION NAME\n");
		}
	}
	/* )LOAD WSID 
	 * load workspace */
	else if (!strncasecmp_(comm,"LOAD",4)) {
		char *q=comm+4;
		char name[COMPSTR], resp[COMPSTR], *n;
		int isDesc=TRUE;
		strncpy_(name,VOIDS,NAMESTR);
		n=name;
		while (isblank(*q)) q++;
		/* this is a file name... */
		while(*q && !isblank(*q)) *n++=*q++;
		*n='\0';
		while (isblank(*q)) q++;
		if (!strncasecmp_(q,"NODE",4)) isDesc=FALSE;
		loadWorkspace(name,resp,isDesc);
		emit(1,"%s\n",resp);
	}
	/* )MEMORY (NOT STANDARD)
	 * give info about used memory */
	else if (!strncasecmp_(comm,"MEMO",4)) {
		emit(1,"USED MEMORY = %d\n",memStatus());
	}
	/* )OPS (NOT STANDARD)
	 * give a help about apple operators  */
	else if (!strcasecmp(comm,"OPS")) {
		callOps(stdout);
		if (isScript) callOps(FS);
	}
	/* )EXTENDED (NOT STANDARD)
	 * give a help extended operators  */
	else if (!strncasecmp_(comm,"EXTE",4)) {
		callExtOps(stdout);
		if (isScript) callExtOps(FS);
	}
	/* )ORIGIN [NUM] (NOT STANDARD - APL70) 
	 * set NUM as origin (0<=NUM<=1) */
	else if (!strncasecmp_(comm,"ORIG",4)) {
		int was=indexOrigin;
		char *s=comm+4;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			indexOrigin=strtol(s,&s,10);
			if (indexOrigin==0 || indexOrigin==1) {
				emit(1,"WAS %d\n",was);
			}
			else {
				indexOrigin=was;
				emit(1,"IS %d\n",was);
			}
		}
		else emit(1,"IS %d\n",indexOrigin);
	}
	/* )PCOPY WSID [NAMES] 
	 * copy-protect all or some objects from a stored workspace */
	else if (!strncasecmp_(comm,"PCOP",4)) {
		char *q=comm+4;
		char name[COMPSTR], names[COMPSTR], resp[COMPSTR], *n;
		while (*q && !isblank(*q)) q++;
		strncpy_(name,VOIDS,NAMESTR);
		n=name;
		while (isblank(*q)) q++;
		/* this is a file name... */
		while(*q && !isblank(*q)) *n++=*q++;
		*n='\0';
		strncpy_(names,VOIDS,COMPSTR);
		n=names;
		while (isblank(*q)) q++;
		if (isupper(*q)) {
			while (*q && (isupper(*q) || isdigit(*q))) *n++=*q++;
			*n='\0';
		}
		copyWorkspace(name,names,resp,TRUE);
		if (resp[0]) {
			emit(1,"%s\n",resp);
		}
	}
	/* )PROG
	 * list workspaces in current directory */
	else if (!strcasecmp(comm,"PROG")) {
		listWKS(".apl");
	}
	/* )PRWS
	 * print workspace in readable format */
	else if (!strcmp(comm,"PRWS")) {
		int i;
		emit(1,"Workspace name: %s\n",currentWorkspaceName[0]?currentWorkspaceName:"None.");
		emit(1,"\nNumber of variables: %d\n",decCount);
		for (i=1;i<=decCount;i++) {
			if (vn[i].rank==MATRIX) {
				char *out=NULL;
				emit(1,"%s [%d,%d]\n",vn[i].name,vn[i].row,vn[i].col);	
				printArray(&out,vn[i]);
				emit(1,"%s\n\n",out);
				free(out);
			}
			else if (vn[i].rank==VECTOR) {
				char *out=NULL;
				emit(1,"%s [%d]\n",vn[i].name,vn[i].col);	
				printArray(&out,vn[i]);
				emit(1,"%s\n\n",out);
				free(out);
			}
			else {
				char *out=NULL;
				printArray(&out,vn[i]);
				emit(1,"%s: %s\n",vn[i].name,out);
				free(out);
			}

		}
		emit(1,"\nNumber of programs: %d\n",progCount);
		for (i=1;i<=progCount;i++) {
			emit(1,"\n");
			do_list(stdout,i,1,pn[i].endCore,TRUE,TRUE);
			emit(1,"\n");
		}
	}
	/* )PWD
	 * print current directory */
	else if (!strcasecmp(comm,"PWD")) {
		char dirname[COMPSTR];
		getcwd(dirname,COMPSTR);
		emit(1,"%s\n",dirname);
	}
	/* )RENAME OLD NEW 
	 * rename program */
	else if (!strncasecmp_(comm,"RENA",4)) {
		char newname[COMPSTR], oldname[COMPSTR];
		char *q=comm+4, *n;
		int ns=0;
		while (*q && !isblank(*q)) q++;
		strncpy_(newname,VOIDS,NAMESTR);
		strncpy_(oldname,VOIDS,NAMESTR);
		while (isblank(*q)) q++;
		n=oldname;
		if (*q && isupper(*q)) {
			while (isupper(*q) || isdigit(*q)) *n++=*q++;
		}
		*n='\0';
		while (isblank(*q)) q++;
		n=newname;
		if (*q && isupper(*q)) {
			while (isupper(*q) || isdigit(*q)) *n++=*q++;
		}
		*n='\0';
		ns=findProg(oldname);
		if (ns) {
			strncpy_(pn[ns].name,newname,NAMESTR);
		}
		else {
			emit(1,"%s NOT RENAMED\n",oldname);
		}
	}
	/* )RESET (NOT STANDARD)
	 * reset flags */
	else if (!strncasecmp_(comm,"RESE",4)) {
		reset(backTOS);
	}
	/* )SAVE [WSID] [DESCRIBE] [APPEND]
	 * save current workspace */
	else if (!strncasecmp_(comm,"SAVE",4)) {
		char *q=comm+4;
		char name[COMPSTR], resp[COMPSTR], *n;
		int isDesc=FALSE, isApp=FALSE;
		strncpy_(name,VOIDS,NAMESTR);
		n=name;
		while (isblank(*q)) q++;
		if (*q && isupper(*q)) {
			while(*q && (isupper(*q) || isdigit(*q))) *n++=*q++;
			*n='\0';
		}
		else if (currentWorkspaceName[0]) {
			strncpy_(name,currentWorkspaceName,NAMESTR);
		}
		/* check for describe */
		while (isblank(*q)) q++;
		if (!strncasecmp_(q,"DESC",4)) {
			q+=4;
			while (*q && (isupper(*q) || isdigit(*q))) q++;
			isDesc=TRUE;
			/* check for APPEND */
			while (isblank(*q)) q++;
			if (!strncasecmp_(q,"APPE",4)) {
				isApp=TRUE;
			}
		}
		if (name[0]) {
			strncpy_(currentWorkspaceName,name,NAMESTR);
			saveWorkspace(name,resp,isDesc,isApp);
			emit(1,"%s\n",resp); 
			strncpy_(currentWorkspaceName,name,NAMESTR);
		}
		else {
			emit(1,"%s","CANNOT SAVE A NAMELESS WORKSPACE.\n");
		}
	}
	/* )SCRIPT [APPEND] [NAME] | [OFF] (NOT STANDARD) */
	/* start script file or stop */
	else if (!strncasecmp_(comm,"SCRI",4)) {
		char name[COMPSTR], *n, *q;
		int isApp=FALSE;
		q=comm+4;
		while (*q && !isblank(*q)) q++;
		while (isblank(*q)) q++;
		if (!strncasecmp_(q,"APPE",4)) {
			isScript=TRUE;
			isApp=TRUE;
			while (*q && !isblank(*q)) q++;
			while (isblank(*q)) q++;
		}
		else if (!strncasecmp_(q,"OFF",3)) {
			isScript=FALSE;
			if (FS) fclose(FS);
		}
		if (isScript) {
			isDeleteScriptFile=!isApp;
			n=name;
			strncpy_(name,VOIDS,COMPSTR);
			while (isblank(*q)) q++;
			while(*q && !isblank(*q)) *n++=*q++;
			*n='\0';
			if (!name[0] && !isScript) {
				emit(1,"ACTIVATING SCRIPTING ON FILE %s\n",defaultScriptName);
				strncpy_(name,defaultScriptName,COMPSTR);
			}
			else {
				emit(1,"ACTIVATING SCRIPT ON FILE %s\n",name);
			}
			isScript=TRUE;
			if (isDeleteScriptFile) FS=fopen(name,"w");
			else FS=fopen(name,"a");
			/* open the script file */
			if (!FS) {
				isScript=FALSE;
				emit(1,"COULD'T OPEN FILE %s FOR SCRIPTING\n",name);
			}
			else doScript(FS,1,"%s)%s\n",PROMPTBASE,comm);
		}
	}
	/* )SEED [VAL]
	 * set val as the current seed for random numbers */
	else if (!strncasecmp_(comm,"SEED",4)) {
		int was=Wseed;
		char *s=comm+4;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			Wseed=strtol(s,&s,10);
			if (Wseed>=2 && Wseed<=32768) {
				if (Wseed%2) Wseed++;
				Wchange=TRUE;
				emit(1,"WAS %d\n",was);
			}
			else if (Wseed==0) {
				emit(1,"WAS %d\n",was);
				Wchange=TRUE;
			}
			else {
				Wseed=was;
				emit(1,"IS %d\n",Wseed);
			}
		}
		else emit(1,"IS %d\n",Wseed);
	}
	/* )SHELL (NOT STANDARD)
	 * start a shell session inside current session */
	else if (!strncasecmp_(comm,"SHEL",4)) {
		char shell[COMPSTR];
		char *q=comm+4, *n;
		while (*q && !isblank(*q)) q++;
		while (isblank(*q)) q++;
		n=shell;
		if (*q) {
			while (*q) *n++=*q++;
			*n='\0';
			system(shell);
		}
		else system(VSHELL);
		emit(1,"(restoring APL session)\n");
	}
	/* )SI
	 * print interrupted fns data */
	else if (!strcasecmp(comm,"SI")) {
		int thisCase=backTOS;
		if (!thisCase) thisCase=backBackTOS;
		if (thisCase>0) {
			int i=backTOS;
			char susp;
			while (i>0) {
				if (backCode[thisCase]==backCode[i]) susp='*';
				else susp='\0';
				emit(1,"%s [%d]  %c\n",pn[backCode[i]].name,backNumber[i],susp);
				i--;
			}

		}
	}
	/* )SIV
	 * print interrupted fns data with local vars */
	else if (!strcasecmp(comm,"SIV")) {
		int thisCase=backTOS;
		if (!thisCase) thisCase=backBackTOS;
		if (thisCase>0) {
			int i=backTOS, j=0;
			int start, end;
			char susp;
			while (i>0) {
				if (backCode[thisCase]==backCode[i]) susp='*';
				else susp=' ';
				start=backStore[i]+1;
				if (i==backTOS) end=decCount;
				else end=backStore[i+1];
				emit(1,"%s [%d]  %c ",pn[backCode[i]].name,backNumber[i],susp);
				j=start;
				while (j<=end) {
					emit(1,"%s ",vn[j].name);
					j++;
				}
				i--;
				emit(1,"\n");
			}
		}
	}
	/* )SPACES
	 * list workspaces in current directory */
	else if (!strncasecmp_(comm,"SPAC",4)) {
		listWKS(".wks");
	}
	/* )STATE (NOT STANDARD) 
	 * give info about workspace data */
	else if (!strncasecmp_(comm,"STAT",4)) {
		char compdate[COMPSTR];
		ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
		sysWidth=(int)wsz.ws_col;
		emit(1,"APL is running on a %s system\n",getenv("CPU"));
		emit(1,"Environment is %s %s\n",getenv("VENDOR"),getenv("MACHTYPE"));
		emit(1,"APL interpreter is %sapple%s (GPL version)\n",REDCOLOR,RESETCOLOR);
		snprintf(compdate,COMPSTR,"%s at %s",__DATE__,__TIME__);
		emit(1,"and current version is %s%s%s\ncompiled on %s\n",REDCOLOR,VERSION,RESETCOLOR,compdate);
		emit(1,"Runtime expressions are limited to %d characters\n",COMPSTR-1);
		emit(1,"No limits for array dimensions\n\n");

		emit(1,"%sWorkspace data:%s\n",BOLD,RESETCOLOR);
		if (currentWorkspaceName[0]) {
			emit(1,"Current workspace has name %s and occupies %d bytes (that is %G Kb)\n",currentWorkspaceName,memStatus(),memStatus()/1024.0);
		}
		else {
			if (!decCount && !progCount) 
				emit(1,"Current nameless new workspace occupies %d bytes (that is %G Kb)\n",memStatus(),memStatus()/1024.0);
			else 
				emit(1,"Current nameless workspace occupies %d bytes (that is %G Kb)\n",memStatus(),memStatus()/1024.0);
		}
		callVars();	
		callFlags();
		callTime();
	}
	/* )TIME (NOT STANDARD)
	 * print current time */
	else if (!strcasecmp(comm,"TIME")) {
		emit(1,"Time: %02d:%02d:%02d\n",getHour(),getMin(),getSec());
	}
	/* )TYPE NAME (NOT STANDARD)
	 * list program */
	else if (!strncasecmp_(comm,"TYPE",4)) {
		char name[COMPSTR], *n, *q;
		q=comm+4;
		while (*q && !isblank(*q)) q++;
		n=name;
		strncpy_(name,VOIDS,COMPSTR);
		while (isblank(*q)) q++;
		while(*q && !isblank(*q)) *n++=*q++;
		*n='\0';
		if (!type(name)) {
			emit(1,"%s NOT FOUND\n",name);
		}
	}
	/* )VARS
	 * list variables in current workspace */
	else if (!strcasecmp(comm,"VARS")) {
		printNamesList(VARVS);
	}
	/* )UNRECOG (UNDOCUMENTED)
	 * (The easter egg #2 ) */
	else if (!strncasecmp_(comm,"UNRE",4)) {
		emit(1,"REALLY? ;-)\n");
	}
	/* )VERSION (UNDOCUMENTED)
	 * print apple version */
	else if (!strncasecmp_(comm,"VERS",4)) {
		emit(1,"%s\n",VERSION);
	}
	/* )WIDTH [VAL]
	 * set val as the output width */
	else if (!strncasecmp_(comm,"WIDT",4)) {
		int was=Wwidth;
		char *s=comm+4;
		while (*s && !isblank(*s)) s++;
		while (isblank(*s)) s++;
		/* use parameter */
		if (*s) {
			Wwidth=strtol(s,&s,10);
			if (Wwidth>=30 && Wwidth<=sysWidth) {
				emit(1,"WAS %d\n",was);
			}
			else if (Wwidth==0) {
				emit(1,"WAS %d\n",was);
			}
			else {
				Wwidth=was;
				emit(1,"IS %d\n",Wwidth);
			}
		}
		else emit(1,"IS %d\n",Wwidth);
	}
	/* )WSID [NAME]
	 * show or set new workspace name */
	else if (!strncasecmp_(comm,"WSID",4)){
		char name[NAMESTR], *n;
		char was[NAMESTR];
		char *q=comm+4;
		strncpy_(was,currentWorkspaceName,NAMESTR);
		n=name;
		strncpy_(name,VOIDS,NAMESTR);
		while (isblank(*q)) q++;
		if (*q && isupper(*q)) {
			int c=0;
			while(*q && (isupper(*q) || isdigit(*q)) && c<NAMESTR) *n++=*q++, c++;
			*n='\0';
			if (strlen(name)) {
				strncpy_(currentWorkspaceName,name,NAMESTR);
				emit(1,"WAS %s.\n",was);
			}
			else {
				emit(1,"IS %s.\n",currentWorkspaceName);
			}
		}
		else if (currentWorkspaceName[0]) {
			emit(1,"IS %s.\n",currentWorkspaceName);
		}
		else {
			if (!decCount && !progCount) 
				emit(1,"NAMELESS WSID IS NEW.\n");
			else 
				emit(1,"NAMELESS WSID IS USED.\n");
		}	
	}
	/* UNRECOGNIZED COMMAND */
	else return -1;
	return 0;
} // end of executeSystemCommand()


/* parse()
 * general purpose routine that interprets the user input
 * at present, the argument is ignored
 * System function */
int parse(int start) {
	char *q=NULL;
	char prev[COMPSTR], spaces[COMPSTR];
	char sline[COMPSTR];
	int len=0;
	TDeclare tres;
	setArray(&tres);
	eraseDEC(&traceV);

	/* get start time*/
	gettimeofday(&tv, NULL);
	
	/* read readline history */
	read_history(HISTORY);

	/* print login string */
	if (!isSilent) {
		system("clear");
		/* screen-only */
		printf(LOGO,REDCOLOR,RESETCOLOR,REDCOLOR,RESETCOLOR);
		printf("%s SIGNED ON%n\n",username,&len);
		makeSpaces(spaces,len);
		printf("%s A (P) P L (E) \\ 1 1 3 0\n\n",spaces);
		/* script-only */
		doScript(FS,1,"Script session start: %s %d, %d - %02d:%02d:%02d\n", getMonthString(),getDay(),getYear(),getHour(),getMin(),getSec());
		doScript(FS,1,"%s SIGNED ON\n",username);
		doScript(FS,1,"%s A (P) P L (E) \\ 1 1 3 0\n\n",spaces);
	}
	if (!wasLoadWorkspaceOK) {
		emit(1,"COULDN'T LOAD %s: CONTINUING WITH AN EMPTY WORKSPACE\n\n",wname);
		eraseCurrentWorkspace();	
	}

	/* setup prompts */
	strncpy_(prompt,PROMPTBASE,COMPSTR);
	strncpy_(charprompt,VOIDS,COMPSTR);
	isProgram=FALSE;
	
	/* interpret the user input */
	while (TRUE) {
		char *l=NULL;
		int isOff=FALSE;
		TDeclare void1, void2;
		setArray(&void1);
		setArray(&void2);
		eraseDEC(&void1);
		eraseDEC(&void2);
		globCount=0;
		isError=isInterrupt=FALSE;       
		isComplexWarning=FALSE;
		l=readline(prompt);
		
		/* CTRL-D behaves like )OFF */
		if (!l) {
			emit(1,"%s\n",")OFF");
			strncpy_(sline,")OFF",COMPSTR);
		}
		/* regular command */
		else {
			/* in case of empty string, regain position up one line */
			if (!*l) {
				/* only for stdout!! */
				free(l);
				fprintf(stdout,"\x1b[A");
				continue;
			}
			else strncpy_(sline,l,COMPSTR);
		}
		free(l);
		
		strncpy_(basetot,sline,COMPSTR);
		BASETOT=NULL;
		self=0;

		/* history: store command */
		if (strcmp(sline,prev) && !(history_search_pos(sline,-1,0)>0)) {
			add_history(sline);
			strncpy_(prev,sline,COMPSTR);
		}
		
		/* check an assignment made in stopping mode */
		if (isAnAssignment(sline) && isStopping) {
			perror_(__LINE__,7,0);
			isError=FALSE;
			continue;
		}

		/* if scripting is on */
		doScript(FS,1,"%s%s\n",prompt,sline);

		/* remove any comment */
		if ((q=strstr_oq(sline,"co"))) *q='\0';
		if ((q=strstr_o2q(sline,"co"))) *q='\0';
		free(q);

		/* reset pointer */
		p=sline;
		while (isblank(*p)) p++;
		if (*p==';') {
			p++;
			while (isblank(*p)) p++;
		}
		/* check if a label is present */
		else if (isLabel(p)) skipLabel();
		/* check if p is null */
		else if (!*p) continue;

		/* check balancing of parenthesis */
		if (!checkBal(sline) && sline[0]!=')' && !strncmp(sline,"co",2))  {
			perror_(__LINE__,27,0);
			isError=FALSE;
			continue;
		}

		/* analyse request to start an editing session ù
		 * Note: this cannot be put in the isMult chain 
		 * because the mechanism of local variables (separated
		 * by semicolon) interferes with isMult */
		if (!strncasecmp_(p,"\\/",2)) {
			int j, uProgCount=0;
			char name[NAMESTR], *pb;
			p+=2;
			while (isblank(*p)) p++;
			/* improper use of \/ if followed by nothing*/
			if (!*p) {
				perror_(__LINE__,7,(int)(strlen(p)-1));
				continue;
			}

			pb=p;
			/* search existing program with the same name */
			getHeader(p,&p,0);
			while (isblank(*p)) p++;

			j=progCount;
			while (j>0) {
				if (!strcmp(pn[j].name,pn[0].name)) {
					uProgCount=j;
					break;
				}
				j--;
			}
			/* in case the name is not found, the function is new */
			if (!uProgCount) {
				p=pb;
				/* get temporary header for the real name */
				getHeader(p,&p,0);
				uProgCount=progCount+1;

				/* erase header data */
				pn[uProgCount].argCount=0;
				strncpy_(pn[uProgCount].arg,VOIDS,NAMESTR);
				pn[uProgCount].leftNum=0;
				strncpy_(pn[uProgCount].left,VOIDS,NAMESTR);
				pn[uProgCount].rightNum=0;
				strncpy_(pn[uProgCount].rights,VOIDS,NAMESTR);
				pn[uProgCount].isMonadic=0;

				/* setup header data on real pos */
				if (getHeader(pb, &p, uProgCount));
				else {
					BASETOT=sline;
					perror_(__LINE__,7,(int)(strlen(p)-1));
					continue;
				}
			}

			/* delete program or variable instance */
			if (!strncasecmp_(p,"\\/",2)) {
				int nsv=0, nsp=0;
				char resp[COMPSTR];
				nsv=searchDEC(name,decCount);
				nsp=uProgCount;
				if (nsv) {
					eraseDEC(&vn[nsv]);
					free_(&vn[nsv]);
				}
				else if (nsp) {
					emptySlot(nsp);	
				}
				/* now save and reload the workspace */
				saveWorkspace(".aplErase.wpc",resp,FALSE,FALSE);
				loadWorkspace(".aplErase.wpc",resp,FALSE);
				remove(".aplErase.wpc");
				continue;
			}
			/* enter programming mode */
			progMode(uProgCount, p);
			if (uProgCount>progCount) progCount++;
			if (progCount>=COMPSTR) {
				perror_(__LINE__,10,0);
				reset(backTOS); // ok
			}
			while (isblank(*p)) p++;
			p=NULL;
			continue;
		}

		/* select type of command except the internal editor */
		while (p && *p && !isError && !isInterrupt) {
			char *isMult=NULL;
			dsp=NULL;
			/* set starting p in case of multiple statements */
			isMult=findSep(p);
			if (isMult && *isMult) {
				*isMult='\0';
			}
			BASETOT=p;
			strncpy_(tres.name,VOIDS,NAMESTR);
			isProgram=FALSE;
			lastProgram=0;
			dimArray(&tres,1);
			reStart=backTOS>0;
			avoidPrintResult=FALSE; // in parse()
			/* console -> command in parse() 
			 * Note: the command may be used in three flavours:
			 * -> to re-execute last line (even unknown)
			 * -> N to execute from N; if N is null or negative
			 *    or greater than endCore, end program
			 * ->LAB to execute from label LAB 
			 * any non digit or non alphabetical upper char
			 * returns an error... */ 
			if (!strncmp(p,"->",2)) {
				int reCode, jump=-99999;
				p+=2;
				if (backTOS<1) {
					perror_(__LINE__,28,(int)(strlen(p)-strlen(basetot)));
					break;
				}
				reCode=backCode[backTOS];
				while (isblank(*p)) p++;
				if (!*p) jump=progLine;
				else if (isupper(*p)) {
					int k=decCount;
					char lab[COMPSTR], *l=lab;
					while (isupper(*p) || isdigit(*p))
						*l++=*p++;
					*l='\0';
					while (k>0) {
						if (!strcmp(vn[k].name,lab)) {
							jump=getArrayVal(vn[k],1,1);
							break;
						}
					}
				}
				else if (isdigit(*p)) {
					int num=strtoll(p,&p,10);
					if (num<1 || num>pn[reCode].endCore)
						jump=0;
					else jump=num;
				}
				else {
					perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
					break;
				}
				while (isblank(*p)) p++;
				if (jump<0) {
					perror_(__LINE__,8,(int)(strlen(p)-strlen(basetot)));
					break;
				}
				else if (!jump) {
					reset(backTOS);
					avoidPrintResult=TRUE;
				}
				else {
					if (reStart) {
						isSuspStop=TRUE;
						isInterrupt=isError=FALSE;
						avoidPrintResult=FALSE;
						execProg(&tres,jump,void1,void2,reCode);
						free_(&void1);
						free_(&void2);
					}
				}
			}
			/* tracing feature */
			else if (!strncasecmp_(p,"T/\\",3)) {
				char *k=traceName;
				p+=3;
				while (isblank(*p)) p++;
				if (isupper(*p)) {
					int pC;
					while (isupper(*p) || isdigit(*p)) *k++=*p++;
					*k='\0';
					if (!(pC=findProg(traceName))) {
						emit(1,"PROGRAM NOT FOUND\n");
						break;
					}
					while (isblank(*p)) p++;
					if (!strncasecmp_(p,"<-",2)) p+=2;
					else {
						emit(1,"MALFORMED TRACE\n");
						break;
					}
					while (isblank(*p)) p++;
				}	
				else {
					emit(1,"MALFORMED TRACE\n");
					break;
				}
				while (isblank(*p)) p++;
				expression(&traceV);
				if (traceV.rank==SCALAR) {
					if (getArrayVal(traceV,1,1)==0) {
						isTracing=FALSE;
						break;
					}
					else makeVector(&traceV);
				}
				else if (traceV.rank!=VECTOR) {
					emit(1,"VALUE ERROR\n");
					break;
				}
				isTracing=TRUE;
				avoidPrintResult=TRUE;
			}
			/* stopping feature */
			else if (!strncasecmp_(p,"S/\\",3)) {
				char *k=stopName;
				p+=3;
				while (isblank(*p)) p++;
				if (isupper(*p)) {
					int pC;
					while (isupper(*p) || isdigit(*p)) *k++=*p++;
					*k='\0';
					if (!(pC=findProg(stopName))) {
						emit(1,"PROGRAM NOT FOUND\n");
						break;
					}
					while (isblank(*p)) p++;
					if (!strncasecmp_(p,"<-",2)) p+=2;
					else {
						emit(1,"MALFORMED STOP\n");
						break;
					}
					while (isblank(*p)) p++;
				}	
				else {
					emit(1,"MALFORMED STOP\n");
					break;
				}
				while (isblank(*p)) p++;
				expression(&stopV);
				if (stopV.rank==SCALAR) {
					if (getArrayVal(stopV,1,1)==0) {
						isStopping=FALSE;
						break;
					}
					else makeVector(&stopV);
				}
				else if (stopV.rank!=VECTOR) {
					emit(1,"VALUE ERROR\n");
					break;
				}
				isStopping=TRUE;
				avoidPrintResult=TRUE;
			}
			/* delegate analyse */
			else {
				globRet=0;
				/* for assignments at the start */
				if (isAnAssignment(p)) 
					avoidPrintResult=TRUE;
				analyse(&tres); //ex assign()
				if (globRet==-1) {
					emit(1,"UNRECOGNIZED SYSTEM COMMAND\n");
					break;
				}
				else if (globRet==1) {
					isOff=TRUE;
					break;
				}
				if (globRet) 
					avoidPrintResult=TRUE;
			
			}
			/* manage errors */
			if (isError) {
				globCount=0;
				break;
			}
			/* manage interrupts */
			else if (isInterrupt) break;
			
			/* manage the printing of results */
			if (!avoidPrintResult && !isError && !isInterrupt) {
				char *out=NULL;
				printArray(&out,tres);
				emit(1,"%s",out);
				free(out);
			}
			
			/* manage the case of multiple lines */
			if (isMult) {
				p=isMult+1;
				while (isblank(*p)) p++;
			}
			/* or else cease the anaylsis */
			else {
				globCount=0;
				break;
			}
		}
		/* print carriage return in parse  */
		if (!avoidPrintResult && !isError && !isInterrupt) {
			emit(1,"%s","\n");
		}
		/* in case the system command declared logoff */
		if (isOff) break;
	}

	/* write readline history */
	write_history(HISTORY);
	history_truncate_file (HISTORY, HISTLEN);
	free_(&tres);
	return TRUE;
} // end of parse


/* shiftDEC()
 * free position ns in the variables list, by shifting all variables up */
void shiftDEC(int ns) {
	int k,i=decCount;
	decCount++;
	if (decCount>=COMPVAR) {
		perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
		reset(backTOS); // ok
		return;
	}
	while (i>=ns) {
		copyArray(&vn[i+1],vn[i]);
		strncpy_(vn[i+1].name,vn[i].name,NAMESTR);
		i--;
	}
	if (backTOS>0) {
		k=1;
		while (k<=backTOS) {
			backStore[k]++;
			resVar[k]++;
			k++;
		}
	}
	eraseDEC(&vn[ns]);
}


/* isAnAssignment()
 * check if the variable which p points to is followed by <-*/
int isAnAssignment(char *s) {
	if (!isupper(*s)) return FALSE;
	/* skip name */
	while (isupper(*s) || isdigit(*s)) s++;
	while (isblank(*s)) s++;
	/* skip [..] section */
	if (*s=='[') {
		int st=0;
		s++; // skip [
		while (*s) {
			if (*s=='[') st++;
			else if (*s==']' && st) st--;
			else if (*s==']' && !st) break;
			s++;
		}
		if (*s==']') s++;
	}
	while (isblank(*s)) s++;
	if (!strncasecmp_(s,"<-",2)) return TRUE;
	return FALSE;
} // end of isAnAssignment()


/* assign()
 * The assign subroutine called by expression(): 
 * assigns a number, a string or a pattern to a variable.
 * variable name is taken from input string.
 * returns in res the final value
 * p is the string to analyse */
void assign(TDeclare *res) {
	char name[NAMESTR], *n=NULL;
	int ns=0, isArray=FALSE, j=0;
	TDeclare vrow,vcol;
	setArray(&vrow);
	setArray(&vcol);
	strncpy_(res->name,VOIDS,NAMESTR);

	/* get var name */
	n=name;
	j=0;
	while (isupper(*p) || isdigit(*p)) {
		*n++=*p++;
		j++;
		if (j>=NAMESTR) break;
	}
	*n='\0';
	/* retrieve the array indices */
	if (*p=='[') {
		ns=searchDEC(name,decCount);
		if (!ns) {
			perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
			return;
		}
		takeRowCol(vn[ns],&vrow,&vcol);
		if (isError) return;
		isArray=TRUE;
	}
	/* calc assignment value */
	while (isblank(*p)) p++;
	if (!strncasecmp_(p,"<-",2)) p+=2;
	while (isblank(*p)) p++;
	if (!*p) {
		perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	/* if the object of assignment is an assignment, 
	* call another instance */
	if (isAnAssignment(p)) {
		assign(res);
	}
	else expression(res);

	/* is case of error, return */
	if (isError || isInterrupt) {
		return;
	}

	/* search for the variable code */
	ns=searchDEC(name,decCount);
	/* decide the variable code and if local or global;
	 * Note: this algorithm assumes that local variables and dummy variables (i.e. 
	 * left and right arguments), which were declared in execProg(), are found (ns>0)
	 * and thus the found ns will be used in these cases (but not for the return variable 
	 * of a function, which was not declared in execProg and awaits the declaration here) 
	 * The examples in APL69 at page 63 shows that S, which was declared in SUM3 or SUM2, 
	 * and which is not a dummy variable left, right or local[], is declared as global, 
	 * and remains available after SUM3 or SUM2 terminate.
	 * The example in APL69 at page 97 shows that Z, which was declared manually after 
	 * BIN 3 fails, is not available any more when BIN 4 starts; so, Z is local and the only 
	 * difference with the previous S is that Z is also the return variable name of BIN */

	/* set for global variables in absolute mode */
	if (!backTOS && !ns) {
		ns=1;
		shiftDEC(ns); // updates decCount
		declare(ns,name,NUMERIC,VECTOR,1,0);
		if (isError) return;
	}
	/* set for variables created in program mode */
	else if (backTOS>0) {
		/* resName is declared local in either way only the first time */
		if (!strcmp(name,resName) && !resAs[backTOS] && resVar[backTOS]) {
			ns=resVar[backTOS];
			resAs[backTOS]=TRUE;
			declare(ns,name,NUMERIC,VECTOR,1,0);
			resName[0]='\0';
		}
		/* variables not referring to resName, are global */
		else if (!ns) {
			shiftDEC(1); // updates decCount
			declare(1,name,NUMERIC,VECTOR,1,0);
			if (isError) return;
			ns=1;
		}
		else {
		}
	}
	/* or else, use the ns found */
	else {
	}

	/* proceed to assign */
	while (isblank(*p)) p++;

	strncpy_(res->name,vn[ns].name,NAMESTR);
	/* assign array item */
	if (isArray) {
		assignSubArray(&vn[ns],*res,vrow,vcol);	
		free_(&vrow);
		free_(&vcol);
	}
	/* normal assignment */
	else {
		copyArray(&vn[ns],*res);
		if (backTOS>0 && pn[backCode[backTOS]].arg[0]) isResAssign[backTOS]=TRUE;
	}
} // end of assign()


/* analyse()
 * check single command from parse
 * if it is an assignment, delegate expression()
 * returns in res the final value
 * p is the string to analyse */
void analyse(TDeclare *res) {
	TDeclare tres;
	setArray(&tres);
	strncpy_(tres.name,VOIDS,NAMESTR);
	while (isblank(*p)) p++;
	if (*p==')') {
		char line[COMPSTR];
		if (!strcasecmp(p,")V") && (!*(p+2) || isblank(*(p+2)))) 
			strcpy(line,")VARS");
		else if (!strcasecmp(p,")F") && (!*(p+2) || isblank(*(p+2)))) 
			strcpy(line,")FNS");
		else if (!strcasecmp(p,")S") && (!*(p+2) || isblank(*(p+2)))) 
			strcpy(line,")STATE");
		else strncpy_(line,p,COMPSTR);
		globRet=executeSystemCommand(line);
		if (globRet!=1 && globRet!=-1) globRet=-2;
		avoidPrintResult=TRUE;
		return;
	}
	//else if (*p && *p!=']' && !isError) {
	else if (*p && !isError) {
		expression(&tres);
		if (tres.elem) copyArray(res,tres);
	}
	free_(&tres);
} // end of analyse()


int isquote(char *s) {
	if (*s=='\"') return '\"';
	if (*s=='\'') return '\'';
	return 0;
}



/* strrstr()
 * find last occurrence of n in s 
 * but only if out of strings, 
 * which must be preserved*/
char *strrstr(char *s, char *n) {
	char *t=s, *tb=NULL;
	int pos[strlen(s)];
	/* mark positions in s */
	while (*t) {
		/* mark |'| as not checkable */
		if (!strncmp(t,"|'|",3)) {
			t+=3;
			continue;
		}
		/* mark ".." as not checkable */
		if (*t=='\"') {
			pos[(int)(t-s)]=1;
			t++;
			while (*t && *t!='\"') {
				pos[(int)(t-s)]=1;
				t++;
			}
			if (*t=='\"') {
				pos[(int)(t-s)]=1;
			}
		}
		/* mark '..' as not checkable */
		else if (*t=='\'') {
			pos[(int)(t-s)]=1;
			t++;
			while (*t && *t!='\'') {
				pos[(int)(t-s)]=1;
				t++;
			}
			if (*t=='\'') {
				pos[(int)(t-s)]=1;
			}
		}
		/* mark as checkable */
		else pos[(int)(t-s)]=0;
		t++;		
	}
	/* proceed with search of string n */
	t=s;
	while (*t && (t=strstr(t,n)) && !pos[(int)(t-s)]) {
		tb=t;
		t++;
	}
	return tb;
}


/* do_assign()
 * workhorse for assign() that operates from right to left,
 * before any expression evaluation in expression();
 * system function for expression() */
void do_assign(char *s) {
	int st=0, stB=0, stS=0, a=0, b=0;
	int bAvoid;
	char *t, *pb;
	char *dpos; // delete position
	char *npos; // name-start position
	char *fpos; // end of expression
	TDeclare temp;
	setArray(&temp);
	checkStop;

	/* set up for avoidPrintResult */
	if (isAnAssignment(s)) bAvoid=TRUE;
	else bAvoid=avoidPrintResult;

	/* for every instance of "<-" from the right: */
	while ((t=strrstr(s,"<-"))) {
		/* 1. set deletion start */
		dpos=t;
		/* 2. look for the variable name (skipping indices, in case) */
		t--; // jump to the character before <-
		st=0;
		while (isblank(*t) && t>s) t--;
		/* skip indices */
		if (*t==']') {
			t--; // skip ]
			while (t>s) {
				if (*t==']') st++;
				else if (*t=='[' && st) st--;
				else if (*t=='[' && !st) break;
				t--;
			}
			if (*t!='[') {
				perror_(__LINE__,2,(int)(t-s));
				goto doassign_go;
			}
			if (*t=='[') t--;	
		}
		/* change I_DD (where DD is two digits) */
		if (t-3>=s && !strncasecmp_(t-3,"I_",2)) {
			*(dpos)='#';
			*(dpos+1)='@';
			*(t-3)='@';
			*(t-2)='#';
			continue;
		}
		/* change |_|<- and |'|<- changing <- to @@ 
		 * and also I_D (where D is one digit) */
		else if (t-2>=s && !strncasecmp_(t-2,"|_|",3)) {
			*(t-2)='@';
			*(t-1)='@';
			a=(int)(parTOS/10);
			b=parTOS-10*a;
			*(dpos)=*(dpos+1)=' ';
			*(t)=a+'0';
			*(t+1)=b+'0';
			parTOS++;
			if (parTOS>=PARSTACK) {
				perror_(__LINE__,19,(int)(strlen(p)-strlen(basetot)));
				goto doassign_go;
			}
			continue;
		}
		else if (t-2>=s && !strncasecmp_(t-2,"|'|",3)) {
			*(t-2)='@';
			*(t-1)='@';
			*t='_';
			*(dpos)=*(dpos+1)=' ';
			continue;
		}
		else if (t-2>=s && !strncasecmp_(t-2,"I_",2)) {
			*(dpos)='#';
			*(dpos+1)='@';
			*(t-2)='@';
			*(t-1)='#';
			continue;
		}
		/* skip name */
		while (isblank(*t) && t>s) t--;
		if (t>s) {
			while (t>s && (isdigit(*t) || isupper(*t))) 
				t--;
		}
		if (t!=s) t++; // regain the first character of name
		/*if (!isupper(*t)) {
			perror_(__LINE__,4,(int)(t-s));
			return;
		}*/
		/* 3. set name-start position */
		npos=t;
		/* 4. find the end of expression */
		t=dpos+2;
		st=0; stB=0;
		checkStop;
		while (*t) {
			if (*t=='\'' || *t=='\"') stS++;
			else if (*t=='(') st++;
			else if (*t==')' && st) st--;
			else if (*t==')' && !st) break;
			else if (*t=='[') stB++;
			else if (*t==']' && stB) stB--;
			else if (*t==']' && !stB) break;
			else if (*t=='\'' && *(t+1)!='\'' && stS) stS--;
			else if (*t=='\'' && *(t+1)=='\'' && stS) t++;
			else if (*t=='\"' && *(t+1)!='\"' && stS) stS--;
			else if (*t=='\"' && *(t+1)=='\"' && stS) t++;
			else if (*t==';' && !st && !stB && !stS) break;
			t++;
		}
		fpos=t;
		/* 5. assign - delegates assign() */
		pb=p;
		p=npos;
		BASETOT=p;
		strncpy_(temp.name,VOIDS,NAMESTR);
		dimArray(&temp,1);
		noCall=TRUE;
		analyse(&temp);
		noCall=FALSE;
		p=pb;
		/* 6. deletion process - substitute spaces to the expression and
		 *    the <- symbol, and leave only the assigned element */
		t=dpos;
		while (t<fpos) *t=' ', t++;
		t=NULL;
	}
doassign_go:
	avoidPrintResult=bAvoid;
	free_(&temp);
} // end of do_assign()


/* do_cal()
 * perform the calculus from */
int do_calc(int low, struct t_declare valstack[], int opstack[], int opclass[], int _valTOS, int _opTOS) {
	int progCode=0, opTOS=_opTOS, valTOS=_valTOS;
	TDeclare sal1, sal2;
	setArray(&sal1);
	setArray(&sal2);
	while (opTOS>low) {
		if (opclass[opTOS]==3) {
			TDeclare void1, void2, tres;
			setArray(&void1);
			setArray(&void2);
			setArray(&tres);
			progCode=opstack[opTOS-1];
			execProg(&tres,1,void1,void2,progCode);
			opTOS--;
			free_(&void2);
			free_(&void1);
			free_(&tres);
			(opTOS)--;
		}
		/* perform dyadic operators */
		else if (opclass[opTOS]==2) {
			/* retrieve current variable value if in case */
			copyArray(&sal1,valstack[valTOS-1]);
			copyArray(&sal2,valstack[valTOS]);
			/* special operators charge */
			if (opstack[opTOS]=='z') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='q') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='@') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==',') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='/') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='\\') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='a') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='r') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='s') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='g') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='w') progCode=opstack[opTOS-1];
			/* normal behaviour */
			do_dyadic(&valstack[valTOS-1],opstack[opTOS],sal1,sal2,progCode);
			/* special operators discharge */
			if (opstack[opTOS]=='z') (opTOS)--;
			else if (opstack[opTOS]=='q') (opTOS)--;
			else if (opstack[opTOS]=='@') (opTOS)--;
			else if (opstack[opTOS]==',') (opTOS)--;
			else if (opstack[opTOS]=='/') (opTOS)--;
			else if (opstack[opTOS]=='\\') (opTOS)--;
			else if (opstack[opTOS]=='a') (opTOS)--;
			else if (opstack[opTOS]=='r') (opTOS)--;
			else if (opstack[opTOS]=='s') (opTOS)--;
			else if (opstack[opTOS]=='g') (opTOS)--;
			else if (opstack[opTOS]=='w') (opTOS)--;
			/* normal behaviour */
			(opTOS)--;
			(valTOS)--;
		}
		/* perform monadic operators */
		else if (opclass[opTOS]==1) {
			/* retrieve current variable value if in case */
			copyArray(&sal1,valstack[valTOS]);
			/* special operators charge */
			if (opstack[opTOS]=='z') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='b') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='w') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='g') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='r') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='y') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='s') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]=='n') progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==QRDC) progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==QSVD) progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==POLA) progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==EIGE) progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==HESS) progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==CHOL) progCode=opstack[opTOS-1];
			else if (opstack[opTOS]==BALA) progCode=opstack[opTOS-1];
			/* normal behaviour */
			do_monadic(&valstack[valTOS],opstack[opTOS],sal1,progCode);
			/* special operators discharge */
			if (opstack[opTOS]=='z') (opTOS)--;
			else if (opstack[opTOS]=='b') (opTOS)--;
			else if (opstack[opTOS]=='w') (opTOS)--;
			else if (opstack[opTOS]=='g') (opTOS)--;
			else if (opstack[opTOS]=='r') (opTOS)--;
			else if (opstack[opTOS]=='y') (opTOS)--;
			else if (opstack[opTOS]=='s') (opTOS)--;
			else if (opstack[opTOS]=='n') (opTOS)--;
			else if (opstack[opTOS]==QRDC) (opTOS)--;
			else if (opstack[opTOS]==QSVD) (opTOS)--;
			else if (opstack[opTOS]==POLA) (opTOS)--;
			else if (opstack[opTOS]==EIGE) (opTOS)--;
			else if (opstack[opTOS]==HESS) (opTOS)--;
			else if (opstack[opTOS]==CHOL) (opTOS)--;
			else if (opstack[opTOS]==BALA) (opTOS)--;
			/* normal behaviour */
			(opTOS)--;
			/* Note: valTOS is not decremented because do_monadic() applies
			 * to the value on the higher value of valTOS only */
		}
		free_(&sal1);
		free_(&sal2);
	}
	return opTOS;
}


/* expression()
 * The PARSER for numerical expression
 * returns in res the final value as a TDeclare object
 * p is the string to analyse */
void expression(TDeclare *res) {
	int i,opturn=FALSE, opstack[COMPSTR*2], opclass[COMPSTR*2];
	int opTOS=1, valTOS=0;
	char val[COMPSTR];
	TDeclare valstack[COMPSTR*2];
	checkStop;

	/* in case of empty string signal SYNTAX ERROR */
	if (!*p) {
		perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
		goto expr_go;
	}
	
	/* setup stack variables*/
	for (i=0;i<COMPSTR;i++) {
		setArray(&valstack[i]);
	}

	/* assure to assign all values from right */
	if (!noCall) {
		do_assign(p);
		noCall=FALSE;
		noParCall=TRUE;
	}
	
	/* skip label */
	skipLabel();
	while (isblank(*p)) p++;

	/* consume the comment */
	if (*p=='c' && *(p+1)=='o') {
		while (*p) p++;
		avoidPrintResult=TRUE;
		goto expr_go;
	}

	/* store single expression items */
	while (*p && *p!=')' && *p!=']' && *p!=';' && (!(*p=='c' && *(p+1)=='o')) && !isError) {
		int adv=0, adv1=0, q=0, progCode=0;
		char code, code1;
		while (isblank(*p)) p++;
		if (!*p) break;
		if (valTOS>=COMPSTR) {
			perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
			goto expr_go;
		}

		/* operator [] 
		 * Note: the [] pair is consumed by takeRowCol() */
		else if (*p=='[') {
			TDeclare temp, col, row;
			setArray(&temp);
			if (valTOS<1) {
				perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
				free_(&temp);
				goto expr_go;
			}
			copyArray(&temp,valstack[valTOS-1]);
			if (temp.rank<VECTOR) {
				perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
				free_(&temp);
				goto expr_go;
			}
			setArray(&row);
			setArray(&col);
			takeRowCol(temp,&row,&col);
			if (isError) {
				free_(&temp);
				free_(&row);
				free_(&col);
				goto expr_go;
			}
			subArray(&valstack[valTOS-1],temp,row,col);
			if (isError) {
				free_(&temp);
				free_(&row);
				free_(&col);
				goto expr_go;
			}
			free_(&temp);
			free_(&col);
			free_(&row);
			continue;
		}
		/* special case of the I_D assignment I_D<- */
		else if (*p=='@' && *(p+1)=='#' && isdigit(*(p+2)) && *(p+3)=='#' && *(p+4)=='@') {
			int code;
			p+=2; // skip @#
			code=strtol(p,&p,10);
			p+=2; // skip #@
			opstack[opTOS++]=code;
			opstack[opTOS]='b';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the I_DD assignment I_DD<- */
		else if (*p=='@' && *(p+1)=='#' && isdigit(*(p+2)) && isdigit(*(p+3)) && *(p+4)=='#' && *(p+5)=='@') {
			int code;
			p+=2; // skip @#
			code=strtol(p,&p,10);
			p+=2; // skip #@
			opstack[opTOS++]=code;
			opstack[opTOS]='b';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* quad (|_|) assignment in monadic fashion */
		else if (*p=='@' && *(p+1)=='@' && isdigit(*(p+2)) && isdigit(*(p+3)) && !opturn) {
			int code;
			p+=2; // skip @@
			code=strtol(p,&p,10);
			opstack[opTOS++]=code;
			opstack[opTOS]='n';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* quad (|'|) char assignment to define the char input prompt 
		 * in monadic fashion */
		else if (*p=='@' && *(p+1)=='@' && *(p+2)=='_' && !opturn) {
			p+=3; // skip @@_
			while (isblank(*p)) p++;
			opstack[opTOS]='m';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the input operator |_| */
		else if (!strncasecmp_(p,"|_|",3) && !opturn) {
			char input[COMPSTR], *pb;
			char *ans=NULL;
			dsp=p;
			p+=3; // skip |_|
			pb=p;
			ans=readline("|_|:\n      ");
			if (ans) strncpy_(input,ans,COMPSTR);
			else {
				strncpy_(input,VOIDS,COMPSTR);
				emit(1,"\n");
			}
			free(ans);
			doScript(FS,1,"|_|:\n      %s\n",input);
			if (!input[0]) strncpy_(input,"0",COMPSTR);
			p=input;
			expression(&valstack[valTOS]);
			valstack[valTOS].type=NUMERIC;
			p=pb;
			valTOS++;
			opturn=TRUE;
		}
		/* special case of the monadic characters input operator (|'|) */
		else if (!strncasecmp_(p,"|'|",3) && !opturn) {
			char input[COMPSTR];
			char *ans=NULL;
			dsp=p;
			p+=3; // skip |'|
			ans=readline(charprompt);
			doScript(FS,1,"%s",charprompt);
			if (ans) strncpy_(input,ans,COMPSTR);
			else strncpy_(input,VOIDS,COMPSTR);
			free(ans);
			doScript(FS,1,"%s\n",input);
			/* instVec() cannot be used here because input
			 * starts from zero; since this is a delicate part,
			 * I leave things go plain */
			if (input[1]=='\0') {
				valstack[valTOS].rank=VECTOR;
				valstack[valTOS].type=STRING;
				valstack[valTOS].row=1;
				valstack[valTOS].col=0;
				valstack[valTOS].size=1;
				dimArray(&valstack[valTOS],valstack[valTOS].size);
			}
			else {
				int i, len=strlen(input);
				valstack[valTOS].rank=VECTOR;
				valstack[valTOS].type=STRING;
				valstack[valTOS].row=1;
				valstack[valTOS].col=len;
				valstack[valTOS].size=len+1;
				dimArray(&valstack[valTOS],valstack[valTOS].size);
				for (i=1;i<=len;i++)
					setArrayVal(valstack[valTOS],1,i,input[i-1]);
			}
			valTOS++;
			opturn=TRUE;
		}
		/* special case of radix operator ensemble */
		else if ((q=isRadix(p)) && opturn) {
			p+=q;
			opstack[opTOS]=RADI;
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of monadic grade up /^\ */
		else if (*p=='/' && *(p+1)=='^' && *(p+2)=='\\' && !opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=3; // skip operator
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=10*dir+1;
			opstack[opTOS]='g';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of dyadic grade up /^\ */
		else if (*p=='/' && *(p+1)=='^' && *(p+2)=='\\' && opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=3; // skip operator
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=10*dir+1;
			opstack[opTOS]='g';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of monadic grade down \v/ */
		else if (*p=='\\' && *(p+1)=='v' && *(p+2)=='/' && !opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=3; // skip operator
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=10*dir+2;
			opstack[opTOS]='g';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of dyadic grade down \v/ */
		else if (*p=='\\' && *(p+1)=='v' && *(p+2)=='/' && opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=3; // skip operator
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=10*dir+2;
			opstack[opTOS]='g';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of file open |v| */
		else if (*p=='|' && *(p+1)=='v' && *(p+2)=='|' && opturn) {
			int dir=1;
			p+=3; // skip operator
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>3) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			if (dir==1) opstack[opTOS]=100*VREAD;
			else if (dir==2) opstack[opTOS]=100*VWRITE+WAPPEND;
			else if (dir==3) opstack[opTOS]=100*VWRITE+WERASE;
			opTOS++;
			opstack[opTOS]='s';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of file write |>| */
		else if (*p=='|' && *(p+1)=='>' && *(p+2)=='|' && opturn) {
			int dir=1;
			p+=3; // skip operator
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='r';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic o| */
		else if (*p=='o' && *(p+1)=='|' && !opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=2;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='w';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the dyadic o| */
		else if (*p=='o' && *(p+1)=='|' && opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=2; // skip o|
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='w';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic o- */
		else if (*p=='o' && *(p+1)=='-' && !opturn) {
			int dir=1;
			int k=1-indexOrigin;
			p+=2;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='w';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the dyadic o- */
		else if (*p=='o' && *(p+1)=='-' && opturn) {
			int dir=1;
			int k=1-indexOrigin;
			p+=2; // skip o|
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='w';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic matrix reversal o| */
		else if (*p=='o' && *(p+1)=='|' && !opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=2;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='w';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the dyadic o| */
		else if (*p=='o' && *(p+1)=='|' && opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p+=2; // skip o|
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1)+k;
				if (*p==']') p++;
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='w';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic j eigen coeff */
		else if (*p=='j' && !opturn) {
			p++;
			opstack[opTOS]='j';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic m memory access */
		else if (*p=='m' && !opturn) {
			p++;
			opstack[opTOS]=ASSI;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic # */
		else if (*p=='#' && !opturn) {
			p++;
			opstack[opTOS]='#';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic type conversion operator a */
		else if (*p=='c' && !opturn) {
			p++;
			opstack[opTOS]='c';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the dyadic print formatted f */
		else if (*p=='f' && opturn) {
			p++;
			opstack[opTOS]=AFRM;
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the dyadic membership operator e */
		else if (*p=='e' && opturn) {
			p++;
			opstack[opTOS]='e';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic matrix transpose \o */
		else if (*p=='\\' && *(p+1)=='o' && !opturn) {
			p+=2;
			opstack[opTOS]=TRAS;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the dyadic matrix expansion \o */
		else if (*p=='\\' && *(p+1)=='o' && opturn) {
			p+=2;
			opstack[opTOS]=TRAS;
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of take /|\ */
		else if (*p=='/' && *(p+1)=='|' && *(p+2)=='\\' && opturn) {
			p+=3; // skip /
			opstack[opTOS++]=1;
			opstack[opTOS]='a';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of drop \|/ */
		else if (*p=='\\' && *(p+1)=='|' && *(p+2)=='/' && opturn) {
			p+=3; // skip /
			opstack[opTOS++]=2;
			opstack[opTOS]='a';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the dyadic compression / and /- */
		else if (*p=='/' && opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p++; // skip /
			if (*p=='-') {
				p++; // skip -
				dir=1;
			}
			if (*p=='[') {
				p++; // skip [
				dir=strtol(p,&p,10)+k;
				if (*p==']') p++; // skip ]
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='/';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the dyadic expansion \ and \- */
		else if (*p=='\\' && opturn) {
			int dir=2;
			int k=1-indexOrigin;
			p++; // skip backslash
			if (*p=='-') {
				p++; // skip -
				dir=1;
			}
			if (*p=='[') {
				p++; // skip [
				dir=strtol(p,&p,10)+k;
				if (*p==']') p++; // skip ]
			}
			if (dir!=1 && dir!=2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='\\';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the outer product combination */
		else if (*p=='@' && *(p+1)=='.' &&\
			       (code=isinnerop(p+2,&adv)) && opturn) {
			p+=2; // skip @ and dot
			p+=adv;
			opstack[opTOS++]=code;
			opstack[opTOS]='@';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the inner product combination */
		else if ((code=isinnerop(p,&adv)) && *(p+adv)=='.' &&\
			       (code1=isinnerop(p+adv+1,&adv1)) && opturn) {
			char first,second;
			first=code;
			p+=adv;
			p++; // skip dot
			second=code1;
			p+=adv1;
			opstack[opTOS++]=second*1000+first;
			opstack[opTOS]='q';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic rank calculator operator (r) */
		else if (*p=='r' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>5) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]='r';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic qrd operator (q) */
		else if (*p=='q' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=QRDC;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic hessenberg operator (h) */
		else if (*p=='h' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=HESS;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic balance operator (b) */
		else if (*p=='b' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>2) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=BALA;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic cholesky operator (l) */
		else if (*p=='l' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>9) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=CHOL;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic eigen operator (a) */
		else if (*p=='a' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>5) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=EIGE;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic svd operator (s) */
		else if (*p=='s' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>7) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=QSVD;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic polar operator (w) */
		else if (*p=='w' && !opturn) {
			int dir=1;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				dir=getArrayVal(*res,1,1); // no k
				if (*p==']') p++;
			}
			if (dir<1 || dir>3) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=POLA;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic condition-number operator k */
		else if (*p=='k' && !opturn) {
			p++;
			opstack[opTOS]=KOND;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic unique operator u */
		else if (*p=='u' && !opturn) {
			p++;
			opstack[opTOS]='u';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic execute  e */
		else if (*p=='e' && !opturn) {
			p++;
			opstack[opTOS]='e';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic s (through STRI) */
		else if (*p=='n' && !opturn) {
			p++;
			opstack[opTOS]=STRI;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic t (through TIMI) */
		else if (*p=='t' && !opturn) {
			p++;
			opstack[opTOS]=TIMI;
			opclass[opTOS]=1;
			opTOS++;
			gettimeofday(&tv, NULL);
			timiStart=((double)tv.tv_sec*1000.0 + tv.tv_usec / 1000.0);
		}
		/* special case of the dyadic t (through TIMI) */
		else if (*p=='t' && opturn) {
			p++;
			opstack[opTOS]=TIMI;
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* special case of the monadic determinant (d) */
		else if (*p=='d' && !opturn) {
			p++;
			opstack[opTOS]='d';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic matrix inversion operator (|%|) */
		else if (!strncasecmp_(p,"|%|",3) && !opturn) {
			p+=3;
			opstack[opTOS]='h';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* store dyadic comma operator for catenate and laminate */
		else if (*p==',' && opturn) {
			double ldir=0;
			int dir=2, k=1-indexOrigin;
			p++;
			if (*p=='[') {
				p++;
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				ldir=getArrayVal(*res,1,1)+k;
				if (ldir>=0.001 && ldir<=0.999) dir=3;
				else if (ldir>=1.001 && ldir<=1.999) dir=4;
				else if (ldir*1000-(int)(ldir)*1000) {
					perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				else {
					dir =(int)ldir;
					if (dir<1 || dir>2) {
						perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
						goto expr_go;
					}
				}
				if (*p==']') p++;
				else {
					perror_(__LINE__,17,(int)(p-BASETOT+1));
					goto expr_go;
				}
			}
			if (dir!=1 && dir!=2 && dir!=3 && dir!=4) {
				perror_(__LINE__,17,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=dir;
			opstack[opTOS]=',';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* store monadic comma operator */
		else if (*p==',' && !opturn) {
			p++;
			opstack[opTOS]=',';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic reduction operator (scalar plus /)  
		 * through s */
		else if ((code=isinnerop(p,&adv)) && *(p+adv)=='/' && !opturn) {
			int k=1-indexOrigin;
			p+=adv+1; // skip operator and /
			if (*p=='-') {
				p++; // skip -
				code=-code;
			}
			if (*p=='[') {
				int val=0;
				p++; // skip [
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				val=getArrayVal(*res,1,1)+k;
				if (val==2) code=(char)abs(code);
				else if (val==1) code=-(char)abs(code);
				else {
					perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				if (*p==']') p++;
			}
			opstack[opTOS++]=code;
			opstack[opTOS]='s';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* special case of the monadic scan operator (scalar plus \)  
		 * through y */
		else if ((code=isinnerop(p,&adv)) && *(p+adv)=='\\' && !opturn) {
			int k=1-indexOrigin;
			p+=adv+1; // skip operator and /
			if (*p=='-') {
				p++; // skip -
				code=-code;
			}
			if (*p=='[') {
				int val=0;
				p++; // skip [
				expression(res);
				if (res->rank!=SCALAR || res->type!=NUMERIC) {
					perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				val=getArrayVal(*res,1,1)+k;
				if (val==2) code=(char)abs(code);
				else if (val==1) code=-(char)abs(code);
				else {
					perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
					goto expr_go;
				}
				if (*p==']') p++;
			}
			opstack[opTOS++]=code;
			opstack[opTOS]='y';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* R0
		 * store standalone program that returns no values and uses no values 
		 * note: since it cannnot enter any expression, the start must coincide
		 * with the start of the statements, and the request is processed immefiately
		 * afterwards, so that no other element must follow */
		else if ((progCode=findProg(p)) && (isblank(*(p+_len)) || !*(p+_len)) &&\
			       !pn[progCode].isMonadic && !pn[progCode].arg[0] && !opturn &&\
			       p==BASETOT && !searchDEC(p,decCount)) {
			p+=strlen(pn[progCode].name);
			while (isblank(*p)) p++;
			if (*p && *p!=';') {
				perror_(__LINE__,27,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			opstack[opTOS++]=progCode;
			opstack[opTOS]='z';
			opclass[opTOS]=3;
			opTOS++;
			opturn=TRUE; // Note: this is due, don't remove!
			break;
		}
		/* R3
		 * store dyadic program (as dyadic operator) */
		else if ((progCode=findProg(p)) && (isblank(*(p+_len)) || !*(p+_len)) &&\
				pn[progCode].isMonadic==-1 && opturn) {
			/* dyadic programs that return no value cannot be used 
			 * into expressions */
			if (!pn[progCode].arg[0] && dsp!=BASETOT) {
				perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			p+=_len;
			while (isblank(*p)) p++;
			opstack[opTOS++]=progCode;
			opstack[opTOS]='z';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* R2
		 * store monadic program (as monadic operator) */
		else if ((progCode=findProg(p)) && (isblank(*(p+_len)) || !*(p+_len)) &&\
				pn[progCode].isMonadic==1 && !opturn &&\
				!searchDEC(p,decCount)) {
			findProg(p); // resets _len, necessay here - don't remove
			/* monadic programs that return no value cannot be used 
			 * into expressions */
			if (!pn[progCode].arg[0] && p!=BASETOT) {
				perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			p+=_len;
			while (isblank(*p)) p++;
			opstack[opTOS++]=progCode;
			opstack[opTOS]='z';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* rho monadic operator  */
		else if (*p=='p' && !opturn) {
			p++;
			opstack[opTOS]='p';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* rho dyadic operator  */
		else if (*p=='p' && opturn) {
			p++;
			opstack[opTOS]='p';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* iota monadic operator */
		else if (*p=='i' && !opturn) {
			p++;
			opstack[opTOS]='i';
			opclass[opTOS]=1;
			opTOS++;
		}
		/* iota dyadic operator */
		else if (*p=='i' && opturn) {
			p++;
			opstack[opTOS]='i';
			opclass[opTOS]=2;
			opTOS++;
			opturn=FALSE;
		}
		/* GENERAL DYADIC CASE: store operator) */
		else if ((code=isop(p, &adv)) && opturn) {
			opstack[opTOS]=code;
			opclass[opTOS]=2;
			opTOS++;
			p=p+adv;
			opturn=FALSE;
		}
		/* GENERAL MONADIC CASE: store operator */
		else if (ismonadic(p) && !opturn) {
			opstack[opTOS]=*p++;
			opclass[opTOS]=1;
			opTOS++;
		}
		/* not an unknown monadic operator after a dyadic */
		else if (isop(p,&adv) && !ismonadic(p) && !opturn) {
			perror_(__LINE__,1,(int)(strlen(p)-strlen(basetot)));
			goto expr_go;
		}
		/* misuse of the dyadic expression / or \ used as monadic */
		else if ((*p=='/' || (*p=='\\' && *(p+1)!='o')) && !opturn) {
			perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
			goto expr_go;
		}
		/* not any non-ASCII char
		 * Note: those characters normally are stored as a couple of
		 * values, the first is -61 or -62 and the second is also negative
		 * and defines the character; since  this is an error that the
		 * IBM APL\1130 couldn't parse, I must use a specific error text */
		else if ((*p==-61 || *p==-62) && *(p+1)<0) {
			perror_(__LINE__,16,(int)(p-BASETOT+1));
			goto expr_go;
		}
		/* not an operator composed of another lower letters */
		else if (islower(*p)) {
			perror_(__LINE__,1,(int)(strlen(p)-strlen(basetot)));
			goto expr_go;
		}
		/* misuse of the delta operator */
		else if (!strncasecmp_(p,"\\/",2)) {
			perror_(__LINE__,7,(int)(strlen(p)-strlen(basetot)));
			goto expr_go;
		}
		/* get single-char sequence */
		else if (!opturn && (q=isquote(p)) && *(p+1)!=q && *(p+2)==q) {
			char *k=val;
			int i=1,isScal=FALSE;
			for (i=0;i<COMPSTR;i++) val[i]='\0';
			while (q && *(p+1)!=q && *(p+2)==q) {
				p++; // skip open quote
				/* manage escape for "" */
				if (q=='\"') {
					if (*p=='\"' && *(p+1)=='\"') *k++='\"', p+=2;
					else if (*p=='\\' && *(p+1)=='a') *k++='\a',p+=2;
					else if (*p=='\\' && *(p+1)=='b') *k++='\b',p+=2;
					else if (*p=='\\' && *(p+1)=='f') *k++='\f',p+=2;
					else if (*p=='\\' && *(p+1)=='n') *k++='\n',p+=2;
					else if (*p=='\\' && *(p+1)=='r') *k++='\r',p+=2;
					else if (*p=='\\' && *(p+1)=='v') *k++='\v',p+=2;
					else if (*p=='\\' && *(p+1)=='t') *k++='\t',p+=2;
					else if (*p=='\\' && *(p+1)=='0') *k++='\0',p+=2;
					else if (*p=='\\' && *(p+1)=='\\') *k++='\\',p+=2;
					else *k++=*p++;
				}
				else *k++=*p++;
				*k='\0';
				p++; // skip closing quote
				while (isblank(*p)) p++;
				if (q=='\'') isScal=TRUE;
				q=isquote(p);
			}
			*k='\0';
			while (isblank(*p)) p++;
			if (strlen(val)==1 && isScal) valstack[valTOS].rank=SCALAR;
			else valstack[valTOS].rank=VECTOR;
			valstack[valTOS].type=STRING;
			/* If strlen is null, an empty vector is created */
			valstack[valTOS].col=strlen(val);
			valstack[valTOS].row=1;
			valstack[valTOS].size=valstack[valTOS].col+1;
			dimArray(&valstack[valTOS],valstack[valTOS].size);
			if (isError) goto expr_go;
			k=val;
			i=1;
			while (*k) setArrayVal(valstack[valTOS],1,i++,*k++);
			valTOS++;
			opturn=TRUE;
		}
		/* get other single-quoted string */
		else if (!opturn && *p=='\'') {
			char *k=val;
			int i=1;
			dsp=p;
			p++; // skip '
			while (*p) {
				if (*p=='\'' && *(p+1)=='\'') *k++='\'', p+=2;
				else if (*p=='\'') break;
				else *k++=*p++;
			}
			*k='\0';
			if (*p=='\'') p++; // skip closing '
			else {
				perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			while (isblank(*p)) p++;
			if (strlen(val)==1) valstack[valTOS].rank=SCALAR;
			else valstack[valTOS].rank=VECTOR;
			valstack[valTOS].type=STRING;
			/* If strlen is null, an empty vector is created */
			valstack[valTOS].col=strlen(val);
			valstack[valTOS].row=1;
			valstack[valTOS].size=valstack[valTOS].col+1;
			dimArray(&valstack[valTOS],valstack[valTOS].size);
			if (isError) goto expr_go;
			k=val;
			while (*k) {
				setArrayVal(valstack[valTOS],1,i,*k);
				i++;
				k++;
			}
			valTOS++;
			opturn=TRUE;
		}
		/* get other double-quoted string */
		else if (!opturn && *p=='\"') {
			char *k=val;
			int i=1;
			dsp=p;
			p++; // skip "
			while (*p) {
				if (*p=='\"' && *(p+1)=='\"') *k++='\"', p+=2;
				else if (*p=='\\' && *(p+1)=='a') *k++='\a',p+=2;
				else if (*p=='\\' && *(p+1)=='b') *k++='\b',p+=2;
				else if (*p=='\\' && *(p+1)=='f') *k++='\f',p+=2;
				else if (*p=='\\' && *(p+1)=='n') *k++='\n',p+=2;
				else if (*p=='\\' && *(p+1)=='r') *k++='\r',p+=2;
				else if (*p=='\\' && *(p+1)=='v') *k++='\v',p+=2;
				else if (*p=='\\' && *(p+1)=='t') *k++='\t',p+=2;
				else if (*p=='\\' && *(p+1)=='0') *k++='\0',p+=2;
				else if (*p=='\\' && *(p+1)=='\\') *k++='\\',p+=2;
				else if (*p=='\"') break;
				else *k++=*p++;
			}
			*k='\0';
			if (*p=='\"') p++; // skip closing "
			else {
				perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			while (isblank(*p)) p++;
			valstack[valTOS].rank=VECTOR;
			valstack[valTOS].type=STRING;
			/* If strlen is null, an empty vector is created */
			valstack[valTOS].col=strlen(val);
			valstack[valTOS].row=1;
			valstack[valTOS].size=valstack[valTOS].col+1;
			dimArray(&valstack[valTOS],valstack[valTOS].size);
			if (isError) goto expr_go;
			k=val;
			while (*k) {
				setArrayVal(valstack[valTOS],1,i,*k);
				i++;
				k++;
			}
			valTOS++;
			opturn=TRUE;
		}
		/* get a number for the expression */
		else if (!opturn) {
			dsp=p;
			if (!*p) {
				perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
				goto expr_go;
			}
			/* parenthesized element */
			if (*p=='(') {
				p++; // skip (
				expression(&valstack[valTOS]);
				if (*p==')') p++;
			}
			/* R1
			 * standalone program that returns a value and uses no values */
			else if ((progCode=findProg(p)) && (isblank(*(p+_len)) || !*(p+_len)) &&\
			       		!pn[progCode].isMonadic && pn[progCode].arg[0]) {
				char *pb;
				TDeclare void1, void2, ret;
				setArray(&void1);
				setArray(&void2);
				setArray(&ret);
				p+=_len;
				while (isblank(*p)) p++;
				pb=p;
				execProg(&ret,1,void1,void2,progCode);
				copyArray(&valstack[valTOS],ret);
				p=pb;
				free_(&void1);
				free_(&void2);
				free_(&ret);
			}
			/* I-beam variable */
			else if (isIBeam(p)) {
				int code=0;
				TDeclare ret;
				p+=2; // skip I_
				while (isblank(*p)) p++;
				code=getNum(p,&p);
				setArray(&ret);
				getIBeam(&ret, code);
				copyArray(&valstack[valTOS],ret);
				free_(&ret);
			}
			/* numeric or char variable */
			else if (isupper(*p)) {
				char name[NAMESTR], *n=name;
				int ns=0;
				if (isAnAssignment(p)) {
					TDeclare temp;
					setArray(&temp);
					// advances p automatically
					assign(&temp);
					copyArray(&valstack[valTOS],temp);
					free_(&temp);
				}
				else {
					char *sb=p;
					int j=0;
					while (isupper(*p) || isdigit(*p)) {
						*n++=*p++;
						j++;
						if (j>=NAMESTR) break;
					}
					*n='\0';
					ns=searchDEC(name,decCount);
					if (!ns) {
						perror_(__LINE__,2,(int)(sb-BASETOT));
						goto expr_go;
					}
					else copyArray(&valstack[valTOS],vn[ns]);
					while (isblank(*p)) p++;
				}
			}
			/* literal number in the extended form -NNN.NNN+-ENNN 
			 * or hex number in the form -$HHH */
			else {
				double dval=0.0;
				dval=getNum(p, &p);
				if (arraySegue(p)) {
					int vTOS=1, i;
					double value[COMPSTR];
					while (isblank(*p)) p++;
					value[vTOS]=dval;
					vTOS++;
					while (isflot(p) || *p=='$') {
						value[vTOS++]=getNum(p, &p);
						if (arraySegue(p)) {
							while(isblank(*p))p++;
							if (*p==';') break;
						}
						else break;
					}
					valstack[valTOS].rank=VECTOR;
					valstack[valTOS].type=NUMERIC;
				       	valstack[valTOS].row=1;
					valstack[valTOS].col=vTOS-1;
					valstack[valTOS].size=vTOS;
					dimArray(&valstack[valTOS],valstack[valTOS].size);
					if (isError) goto expr_go;
					for (i=1;i<=valstack[valTOS].col;i++) {
						setArrayVal(valstack[valTOS],1,i,value[i]);
					}
				}
				else {
					valstack[valTOS].rank=SCALAR;
					valstack[valTOS].type=NUMERIC;
					valstack[valTOS].row=1;
					valstack[valTOS].col=1;
					valstack[valTOS].size=2;
					dimArray(&valstack[valTOS],valstack[valTOS].size); 
					if (isError) goto expr_go;
					setArrayVal(valstack[valTOS],1,1,dval);
				}
				while (isblank(*p)) p++;
			}
			valTOS++;
			opturn=TRUE;
		}
		else if (*p!=';') {
			perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
			break;
		}
		else break;
	}

	/* error if only operators and no values were found 
	 * or in case there is a missing last value in the queue */
	if ((!opturn && !(opTOS==1 && !valTOS))) {
		perror_(__LINE__,4,(int)(strlen(p)-strlen(basetot)));
		goto expr_go;
	}
	/* if expression is not empty at the end (see the last instruction end here */
	if (!opTOS && !valTOS) {
		goto expr_go;
	}

	/* interpret expression with monadic and/or dyadic operators: 
	 * perform calculus from right */
	--opTOS;
	--valTOS;
	/* calculate result value */
	do_calc(0,valstack,opstack,opclass,valTOS,opTOS);

	/* print quad outputs */
	if (noParCall) {
		for (int i=0;i<parTOS;i++) {
			if (parstack[i][0]) {
				emit(1,"%s\n",parstack[i]);
				avoidPrintResult=TRUE;
			}
		}
		noParCall=FALSE;
		parTOS=0;
	}
expr_go:
	copyArray(res,valstack[0]);
	for (i=0;i<COMPSTR;i++) free_(&valstack[i]);
	
} // end of expression()


/* do_dscalar()
 * perform the basic scalar dyadic operators between val1 and val2 */
double do_dscalar(char op, double val1, double val2) {
	double res=0.0;
	int ret=0;

	switch(op) {
		case '+': res=val1+val2; break; 
		case '-': res=val1-val2; break; 
		case 'x': res=val1*val2; break; 
		case '%': if (val1==0 && val2==0) res=1.0;
			  else if (val2==0) {
				if (!Wdiv) perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				else res=0;
			  }
			  else res=val1/val2; 
			  break; 
		case '{': res=min(val1,val2); break; 
		case '}': res=max(val1,val2); break; 
		case '*': res=power(val1,val2); break; 
		case RADI: res=radix(val1,val2); break; 
		case '|': res=resi(val1,val2); break; 
		case '!': res=combi(val1,val2); break; 
		case '^': res=lcm(val1,val2); break;
		case 'v': res=gcd(val1,val2); break; 
		case 'f': res=nand(val1,val2); break;
		case 'y': res=nor(val1,val2); break;
		case '>': ret=relation(val1,val2); 
			  if (ret==2) res=1;
			  else res=0; 
			  break; 
		case '<': ret=relation(val1,val2); 
			  if (ret==3) res=1;
			  else res=0;
			  break; 
		case '=': ret=relation(val1,val2); 
			  if (ret==1) res=1;
			  else res=0;
			  break; 
		case '#': ret=relation(val1,val2); 
			  if (ret==2 || ret==3) res=1;
			  else res=0;
			  break; 
		case 'j': ret=relation(val1,val2); 
			  if (ret==1 || ret==3) res=1;
			  else res=0;
			  break; 
		case 'k': ret=relation(val1,val2); 
			  if (ret==1 || ret==2) res=1;
			  else res=0;
			  break; 
		case '&': if (val2<=0 || val1<=0 || val1==1) 
			  	perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
			  res=log(val2)/log(val1); 
			  break;
		case 'o': res=do_trig((int)val1,val2);
			  break;
	}
	_logic=islogic(op);
	return res;
}


/* do_monadic()
 * apply monadic operator to val, and return the new value */
double do_mscalar(char op, double val) {
	double res=0;

	switch(op) {
		case '+': res=val; break;
		case '-': res=-1.0*val; break;
		case 'x': res=sign(val); break;
		case '%': if (val==0 && !Wdiv) {
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot))); 
			  }
			  else if (val==0) res=0;
			  else res=1.0/val; 
			  break;
		case '}': res=ceiling(val); break;
		case '{': res=floor(val); break;
		case '*': res=exp(val); break;
		case '&': if (val<=0) 
				perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot))); 
			  res=log(val); 
			  break;
		case '|': res=fabs(val); break;
		case '!': res=tgamma(val+1); break;
		case 'o': res=val*APLPI; break;
		case '~': if (fabs(val)<fabs(Wcomp)) res=1;
			  else res=(int)(val==0); 
			  _logic=TRUE;
			  break;
		case '?': {
				int k=1-indexOrigin;
				if (val==0.0) res=m_random(val);
				else res=m_random(val)-k;
			  }
			  break;
	}
	return res;
}


/* identity()
 * return the identity value of the scalar operator op,
 * that is the value that is neutral for op */
double identity(char op) {
	double res=0.0;
	switch(op) {
		case 'x': res=1.0; break; // iso
		case '+': res=0.0; break; // iso
		case '%': res=1.0; break; // iso
		case '-': res=0.0; break; // iso
		case '*': res=1.0; break; // iso
		case '{': res=DBL_MAX; break; // iso
		case '}': res=-DBL_MAX; break; // iso
		case '|': res=0.0; break; // iso
		case '!': res=1.0; break; // iso
		case 'v': res=0.0; break; // iso
		case '^': res=1.0; break; // iso
		case '=': res=1.0; break; // iso
		case '#': res=0.0; break; // iso
		case '>': res=0.0; break; // iso
		case 'k': res=1.0; break; // iso
		case '<': res=0.0; break; // iso
		case 'j': res=1.0; break; // iso
		default:
			  perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
			  res=0.0;
	}
	return res;
}



/* do_monadic()
 * apply monadic operator to val1 and return the result */
void do_monadic(TDeclare *res, char op, TDeclare v, int progCode) {
	int type=1, dir=2, ns=0;
	char *pb;
	double timiEnd=0;
	TDeclare val;
	checkStop;

	setArray(&val);
	copyArray(&val,v);
	switch(op) {
		/* execute scalar functions */
		case '+': 
		case '-': 
		case 'x': 
		case '%': 
		case '{': 
		case '}':
		case '*': 
		case '&': 
		case '|': 
		case '!': 
		case 'o': 
		case '~': 
		case '?': do_scalar_monadic(res,op,val); break;
		/* WS2
		 * execute monadic user program */
		case 'z': pb=p;
			  execProg(res,1,val,val,progCode); 
			  p=pb;
			  break;
		/* execute reduction operator */
		case 's': if (progCode<0) dir=1;
			  m_reduction(res,abs(progCode),val,dir); 
			  break;
		/* execute scan operator */
		case 'y': if (progCode<0) dir=1;
			  m_scan(res,val,abs(progCode),dir); 
			  break;
		/* execute matrix inversion */
		case 'h': ns=searchDEC("DETERMINANT",decCount);
			  if (ns && vn[ns].rank==SCALAR) 
				setArrayVal(vn[ns],1,1,0.0);
			  m_invert(res,val); 
			  break;
		/* execute monadic comma operator */
		case ',': m_comma(res,val); break;
		/* execute monadic rho operator */
		case 'p': m_rho(res,val); break;
		/* execute monadic iota operator */
		case 'i': m_iota(res,val); break;
		/* execute matrix reversal */
		case 'w': m_reversal(res,val,progCode); break;
		/* execute matrix reversal */
		case TRAS: m_transpose(res,val); break;
		/* determinant */
		case '#': m_unique_mask(res, val); break;
		/* execute unique */
		case 'u': m_unique(res,val); break;
		/* execute matrix rank */
		case 'd': m_processMatrix(res,val,DETERMI); break;
		/* execute coeff */
		case 'j': m_processMatrix(res,val,COEFFIC); break;
		/* execute string check */
		case STRI: if (val.type==STRING) instScalar(res,0);
			   else instScalar(res,1);
			   break;
		/* execute timing */
		case TIMI: gettimeofday(&tv, NULL);
			   timiEnd=((double)tv.tv_sec*1000.0 + tv.tv_usec / 1000.0)-timiStart;
			   if (timiEnd<1000.0) emit(1,"TIMING: %.3G ms\n",timiEnd);
			   else emit(1,"TIMING: %.3G s\n",timiEnd/1000.0);
			   copyArray(res,val);
			   break;
		/* execute qr decomposition */
		case QRDC: {
				  TDeclare Q,R;
				  setArray(&Q); setArray(&R);
				  m_qrd(&Q,&R,val);
				  if (progCode==1) copyArray(res,Q);
				  else if (progCode==2) copyArray(res,R);
				  free_(&Q); free_(&R);
			  }
			  break;
		/* execute eigen decomposition */
		case EIGE: m_eigen(res,val,progCode); break;
		/* execute Hessenberg decomposition */
		case HESS: m_hess(res,val,progCode); break;
		/* execute triangular decomposition */
		case CHOL: /* Cholesky and LDL decompositions */
			   if (progCode<=3) m_chol(res,val,progCode); 
			   /* LU/PLU decomposition */
			   else if (progCode<=6) m_plu(res,val,progCode);
			   /* LDU decomposition */
			   else m_ldu(res,val,progCode);
			   break;
		/* execute balancing */
		case BALA: m_balance(res,val,progCode); break;
		/* execute condition nummber calculation */
		case KOND: m_kond(res,val); break;
		/* execute the polar decomposition */
		case POLA: m_polar(res,val,progCode); break;
		/* execute svd decomposition */
		case QSVD: {
				  int isTrans=FALSE;
				  TDeclare U,V,S,W,valT;
				  setArray(&U); setArray(&V); setArray(&S); 
				  setArray(&W);setArray(&valT);
				  if (val.row<val.col) {
					  m_transpose(&valT,val);
					  isTrans=TRUE;
				  }
				  else copyArray(&valT,val);
				  if (progCode>3) 
					  m_svd(&U,&V,&S,&W,valT,FALSE);
				  else
					  m_svd(&U,&V,&S,&W,valT,TRUE);
				  if (progCode==1 || progCode==4) {
					  if (!isTrans) copyArray(res,S);
					  else m_transpose(res,S);
				  }
				  else if (progCode==2 || progCode==5) {
					  if (!isTrans) copyArray(res,U);
					  else copyArray(res,V);
				  }
				  else if (progCode==3 || progCode==6) {
					  if (!isTrans) copyArray(res,V);
					  else copyArray(res,U);
				  }
				  else if (progCode==7) copyArray(res,W);
				  free_(&W); free_(&S); free_(&V); 
				  free_(&U); free_(&valT);
			  }
			  break;
		/* execute matrix rank */
		case 'r': m_linear(res,val,progCode); break;
		/* execute grading */
		case 'g': dir=progCode/10;
			  type=progCode-dir*10;
			  m_grade(res,val,type,dir); 
			  break;
		/* execute type conversion */
		case 'c': if (!typeconv(res,val))
				  perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
			  break;
		/* execute |_|<- */
		case 'n': {
				  char *out=NULL;
				  printArray(&out,val);
				  strncpy_(parstack[progCode],out,COMPSTR);
				  copyArray(res,val);
				  free(out);
			  }
			  break;
		/* execute |'|<- */
		case 'm': {
				  char *k=charprompt;
				  int i;
				  if (val.type!=STRING || val.rank!=VECTOR) {
				  	perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				  	break;
				  }
				  for (i=1;i<=val.col;i++)
				  	*k++=getArrayVal(val,1,i);
				  *k='\0';
			  }
			  avoidPrintResult=TRUE;
			  copyArray(res,val);
			  break;
		/* execute I_D<- or I_DD<- */
		case 'b': if (val.rank==SCALAR && val.type==NUMERIC) {
				  setIBeam(progCode,(int)getArrayVal(val,1,1));
			  }
			  else if (val.rank!=SCALAR) {
				  perror_(__LINE__,6,(int)(strlen(p)-strlen(basetot)));
				  break;
			  }
			  else if (val.type!=NUMERIC) {
				  perror_(__LINE__,3,(int)(strlen(p)-strlen(basetot)));
				  break;
			  }
			  copyArray(res,val);
			  avoidPrintResult=TRUE;
			  break;
		/* execute 'execute' */
		case 'e': {
				   int i;
				   char text[COMPSTR];
				   char *k=text;
				   pb=p;
				   if (val.type!=STRING) {
					   perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
					   break;
				   }
				   while (isblank(*k)) k++;
				   for (i=1;i<=val.col;i++) *k++=getArrayVal(val,1,i);
				   *k='\0';
				   p=text;
				   /* suppress Messages? */
				   if (actOnSuppressMessage) suppressMessage=TRUE; 
				   analyse(res);
				   suppressMessage=FALSE;
				   p=pb;
			   }
			   break;
		/* execute memory access */
		case ASSI: if (val.type==STRING && val.rank<MATRIX) {
				   int i,ns=0;
				   char name[NAMESTR];
				   for (i=1;i<=val.col;i++)
					   name[i-1]=getArrayVal(val,1,i);
				   name[val.col]='\0';
				   ns=searchDEC(name,decCount);
				   instScalar(res,ns);
			   }
			   else if (val.type==NUMERIC && val.rank==SCALAR) {
				   int ns=0;
				   ns=getArrayVal(val,1,1);
				   if (ns>0 && ns<=decCount)
					   copyArray(res,vn[ns]);
				   else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
			   }
			   else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
			   break;
	}
	free_(&val);
}


/* do_dyadic()
 * apply dyadic operator to val1 and val2 and return the result */
void do_dyadic(TDeclare *res, char op, TDeclare v1, TDeclare v2, int progCode) {
	int type=1, dir=2, firstop, secondop;
	char *pb;
	TDeclare val1,val2;
	checkStop;

	setArray(&val1);
	setArray(&val2);
	copyArray(&val1,v1);
	copyArray(&val2,v2);
	switch(op) {
		/* execute scalar functions */
		case '+': 
		case '-': 
		case 'x': 
		case '%': 
		case '{': 
		case '}':
		case '*': 
		case '|': 
		case '!': 
		case '^': 
		case 'v': 
		case 'f': 
		case 'y': 
		case '>': 
		case '<': 
		case '=': 
		case '#': 
		case 'j': 
		case 'k':
		case 'o':
		case RADI:
		case '&': do_scalar_dyadic(res,op,val1,val2); break;
		/* WS3
		 * execute dyadic user program */
		case 'z': pb=p;
			  execProg(res,1,val1,val2,progCode); 
			  p=pb;
			  break;
		/* execute dyadic rho operator */
		case 'p': d_rho(res,val1,val2); 
			  break;
		/* execute dyadic iota operator */
		case 'i': d_iota(res,val1,val2); break;
		/* execute dyadic comma operator (g is the case ,[N])*/
		case ',': d_comma(res,val1,val2,progCode); break;
		/* execute inner product operator */
		case 'q': secondop=(int)(progCode/1000);
			  firstop=progCode-secondop*1000;
			  d_inner(res,val1,val2,firstop,secondop);
			  break;
		/* execute outer product operator */
		case '@': d_outer(res,val1,val2,progCode); break;
		/* execute encode/decode operators */
		case 'b': d_encode(res,val1,val2); break;
		case 'm': d_decode(res,val1,val2); break;
		/* execute execute compression */
		case '/': d_compress(res,val1,val2,progCode); break;
		/* execute execute expansion */
		case '\\': d_expand(res,val1,val2,progCode); break;
		/* execute deal function */
		case '?': d_deal(res,val1,val2); break;
		/* execute matrix division */
		case 'h': d_matdivision(res,val1,val2); break;
		/* execute membership */
		case 'e': d_membership(res,val1,val2); break;
		/* execute take/drop */
		case 'a': d_takeDrop(res,val1,val2,progCode); break;
		/* execute display */
		case AFRM: 
			  d_display(res,val1,val2);
			  //avoidPrintResult=TRUE; // prints automatically
			  break;
		/* execute rotate */
		case 'w': d_rotate(res,val1,val2,progCode); break;
		/* execute generalized transpose */
		case TRAS: d_gtranspose(res,val1,val2); break;
		/* exluding elements  */
		case '~': d_exclusion(res,val1,val2); break;
		/* execute grading */
		case 'g': dir=progCode/10;
			  type=progCode-dir*10;
			  d_grade(res,val1,val2,type,dir); 
			  break;
		/* execute file open */
		case 's': dir=progCode/100;
			  type=progCode-dir*100;
			  d_file(res,val1,val2,dir,type);
			  break;
		/* execute tests */
		case TIMI: d_matTest(res,val1,val2); break;
		/* execute file pos */
		case 't': d_pos(res,val1,val2); break;
		/* execute file read */
		case 'l': d_read(res,val1,val2); break;
		/* execute file write */
		case 'r': if (progCode==1) 
			  	d_writeobj(res,val1,val2); 
			  else
			  	d_writeseq(res,val1,val2); 
			  break;
		/* execute match */
		case 'n': d_match(res,val1,val2); break;
	}
	free_(&val1);
	free_(&val2);
}


/******************************************************************************
 * The following functions define general system environment subroutines:
 * they are internal routines not directly accessible as APL statements.
 ******************************************************************************/

/* copyArray()
 * copy array from into to, included the numeric memory 
 * System function */
void copyArray(TDeclare *to, TDeclare from) {
	int i,j;
	checkStop;

	/* copy array memory */
	to->type=from.type;
	to->rank=from.rank;
	to->col=from.col;
	to->row=from.row;
	to->size=from.size;
	dimArray(to,to->size);
	if (isError) return;
	if (to->rank==VECTOR && !to->col) return;
	if (to->rank==MATRIX && (!to->col || !to->row)) return;
	/* copy values */
	if (from.elem && from.rank==SCALAR) {
		setArrayVal(*to,1,1,getArrayVal(from,1,1));
	}
	else if (from.elem) {
		for (i=1;i<=from.row;i++) {
			for (j=1;j<=from.col;j++) {
				setArrayVal(*to,i,j,getArrayVal(from,i,j));
			}
		}
	}
}


/* makeSpaces()
 * build a string of n spaces */
void makeSpaces(char *k, int n) {
	while (n-->0) *k++=' ';
	*k='\0';
}

 
/* printFormatted()
 * return a string in len width aligned to the right 
 * and padded with blanks */
void printFormatted(char *out, int len, char *num) {
	char spaces[COMPSTR];
	int diff=len-strlen(num);
	makeSpaces(spaces,diff);
	snprintf(out,COMPSTR,"%s%s",spaces,num);
}


/* changeMinus()
 * change the leading minus of a number to underscore 
 * and the figure nnnnE-mm to nnnnE_mm*/
void changeMinus(char *str) {
	char *k;
	while (isblank(*str)) str++;
	if (*str=='-') *str='_';
	if ((k=strstr(str,"e")) && *(k+1)=='-') *(k+1)='_';
	if ((k=strstr(str,"E")) && *(k+1)=='-') *(k+1)='_';
}


/* printArray()
 * print the array pointed by var 
 * System function */
void printArray(char **foutput, TDeclare var) {
	int i,j,limit=OUTSTR,w;
	int myWidth=0;
	char num[COMPSTR],*output=NULL;
	char numf[COMPSTR], mnumf[COMPSTR];
	double curr;
	checkStop;
	
	/* determine temporary output formats */

	/* exponential */
	if (isExp>0) {
		snprintf(numf,COMPSTR,"%%.%dE  ",Wdigit);
		snprintf(mnumf,COMPSTR,"  %%.%dE",Wdigit);
	}
	/* decimal */
	else if (Wdigit>0) {
		snprintf(numf,COMPSTR,"%%.%dG  ",Wdigit);
		snprintf(mnumf,COMPSTR,"  %%.%dG",Wdigit);
	}
	/* or else default */
	else {
		snprintf(numf,COMPSTR,"%s",numformat);
		snprintf(mnumf,COMPSTR,"%s",mnumformat);
	}

	/* determine output width */
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;
	if (Wwidth) myWidth=Wwidth;
	else myWidth=sysWidth;
	globCount=0;

	/* dimension default output */
	output=calloc(limit+1,sizeof(char));
	strncpy_(output,VOIDS,limit+1);
	if (!output) {
		perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
		return;
	}
	else if (var.row==1 && !var.col) {
		if (var.rank==VECTOR) {
			output[0]='\0';
		}
		else {
			output[0]='\0';
		}

	}
	else if (var.type==NUMERIC) {
		if (var.rank==SCALAR) {
			int k;
			curr=getArrayVal(var,1,1);
			if (Wfuzz && fabs(curr)<fabs(fuzzValue)) curr=0.0; 
			if (fabs(curr)<ZERO) curr=0.0; 
			snprintf(num,COMPSTR,numf,curr);
			changeMinus(num);
			/* only for scalars: remove final spaces */
			k=strlen(num)-1;
			while (k>0 && isblank(num[k])) num[k--]='\0';
			strncat_(output,num,limit+1);
		}
		else if (var.rank==VECTOR) {
			ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
			for (i=1;i<=var.col && !isInterrupt;i++) {
				curr=getArrayVal(var,1,i);
				if (Wfuzz && fabs(curr)<fabs(fuzzValue)) curr=0.0; 
				if (fabs(curr)<ZERO) curr=0.0; 
				snprintf(num,COMPSTR,numf,curr);
				if (globCount+strlen(num)>myWidth) {
					strncat(output,"\n      ",limit+1);
					globCount=OFFSET;
				}
				if (strlen(output)+strlen(num)>limit) {
					char *back=output;
					limit*=2;
					output=realloc(output,limit+1);
					if (!output) {
						perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
						free(back);
						return;
					}
				}
				changeMinus(num);
				strncat_(output,num,limit+1);
				globCount+=strlen(num);
			}
		}
		else if (var.rank==MATRIX) {
			int len=1;
			char num[COMPSTR], nums[COMPSTR];
			if (!var.col || !var.row) {
				free(output);
				return;
			}
			/* matrices are preceded by a blank line */
			snprintf(output,COMPSTR,"%s","\n");
			/* determine max length of matrix's elements */
			for (i=1;i<=var.row && !isInterrupt;i++) {
				for (j=1;j<=var.col && !isInterrupt;j++) {
					curr=getArrayVal(var,i,j);
					if (fabs(fuzzValue)>0 && fabs(curr)<fabs(fuzzValue)) 
						curr=0.0; 
					snprintf(num,COMPSTR,mnumf,curr);
					if (strlen(num)>len) len=(int)strlen(num);
				}
			}
			/* print numeric matrix */
			for (i=1;i<=var.row && !isInterrupt;i++) {
				for (j=1;j<=var.col && !isInterrupt;j++) {
					char form[COMPSTR];
					curr=getArrayVal(var,i,j);
					if (Wfuzz && fabs(curr)<fabs(fuzzValue)) curr=0.0; 
					if (fabs(curr)<ZERO) curr=0.0; 
					snprintf(num,COMPSTR,mnumf,curr);
					changeMinus(num);
					printFormatted(form,len,num);
					snprintf(nums,COMPSTR,"%s",form);
					if (globCount+strlen(nums)>myWidth) {
						strncat(output,"\n      ",limit+1);
						globCount=OFFSET;
					}
					if (strlen(output)+strlen(nums)>limit) {
						char *back=output;
						limit*=2;
						output=realloc(output,limit+1);
						if (!output) {
							perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
							free(back);
							return;
						}
					}
					strncat_(output,nums,limit+1);
					globCount+=strlen(nums);
				}
				/* separate matrix's rows*/
				if (i!=var.row) strncat_(output,"\n",limit+1);
				globCount=0;
			}
		}
	}
	else if (var.type==STRING) {
		if (var.rank==SCALAR) {
			snprintf(num,COMPSTR,"%c",(char)getArrayVal(var,1,1));
			strncat_(output,num,limit+1);
		}
		else if (var.rank==VECTOR) {
			char *o=output;
			for (i=1;i<=var.col && !isInterrupt;i++) {
				if (globCount>=limit) {
					char *back=output;
					limit*=2;
					output=realloc(output,limit+1);
					if (!output) {
						perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
						free(back);
						return;
					}
				}
				*o++=getArrayVal(var,1,i);
				globCount++;
			}
			*o='\0';
		}
		else if (var.rank==MATRIX && var.type==STRING) {
			char *o;
			snprintf(output,COMPSTR,"%s","\n");
			o=output+1;
			for (i=1;i<=var.row && !isInterrupt;i++) {
				if (globCount>=limit) {
					char *back=output;
					limit*=2;
					output=realloc(output,limit+1);
					if (!output) {
						perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
						free(back);
						return;
					}
				}
				for (j=1;j<=var.col && !isInterrupt;j++) {
					if (globCount>=limit) {
						char *back=output;
						limit*=2;
						output=realloc(output,limit+1);
						if (!output) {
							perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
							free(back);
							return;
						}
					}
					*o++=getArrayVal(var,i,j);
					globCount++;
				}
				/* separate matrix's rows*/
				if (i!=var.row) *o++='\n', globCount++;
			}
			*o='\0';
		}
	}
	//else perror_(__LINE__,2,(int)(strlen(p)-strlen(basetot)));
	w=strlen(output)+1;
	*(output+w-1)='\0';
	*foutput=calloc(w,sizeof(char));
	strncpy_(*foutput,output,w);
	free(output);
} // end of printArray()


/* setArray()
 * set array for declaration */
void setArray(TDeclare *res) {
	res->elem=NULL;
	res->allocated=FALSE;
}


/* dimArray()
 * dimension the array memory of the object res using size */
void dimArray(TDeclare *res, int size) {
	if (res->allocated) {
		free(res->elem);
		setArray(res);
	}
	if (size<=2) size=2;
	res->elem=malloc((size_t)(size-1)*sizeof(double));
	if (!res->elem) perror_(__LINE__,9,(int)(strlen(p)-strlen(basetot)));
	else res->allocated=TRUE;
}


/* declare()
 * declare an empty array in the vn[] structure;
 * name contains the name to be declared in position decCount
 * type and rank are passed
 * System function  */
void declare(int pos, char *name, int type, int rank, int row, int col) {
	int size;
	if (pos<1 || pos>COMPVAR) {
		perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
		reset(backTOS);
		return;
	}
	strncpy_(vn[pos].name,name,NAMESTR);
	vn[pos].type=type;
	vn[pos].rank=rank;
	vn[pos].col=col;
	vn[pos].row=row;
	size=(row)*(col)+1;
	vn[pos].size=size;
	dimArray(&vn[pos],size);
	maxDec++;
}


/* getArrayVal(matrix-index,type,row-position,column-position)
 * get value of an element of a numerical array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * T: matrix type, 1 for unidimensional vectors, 2 for matrices
 * row: the row number (=0 for one rows matrices)
 * col: the column number (=0 for vectors and one columns matrices)
 * System function */
double getArrayVal(TDeclare var, int row, int col) {
	/*if (row<1 || row>var.row || col<1 || col>var.col) {
		perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
		return 0.0;
	}*/
	/* vector */
	if (var.rank==VECTOR) 
		return *(var.elem+col-1);
	/* regular matrix */
	else if (var.rank==MATRIX) 
		return *(var.elem+((var.col)*(row-1)+col-1)); 
	/* scalar value */
	return *var.elem;
}


/* setArrayVal(matrix-index,type,row-position,column-position,value)
 * set an element of a numerical array to a specific value, given the value 
 * itself and the element coordinates.
 * var: the index of the variable holding the matrix name
 * row: the row number (=0 for one rows matrices)
 * col: the column number (=0 for vectors and one columns matrices)
 * val: the double value to be stored.
 * System function */
void setArrayVal(TDeclare var, int row, int col, double val){
	/*if (row<1 || row>var.row || col<1 || col>var.col) {
		perror_(__LINE__,11,(int)(strlen(p)-strlen(basetot)));
		return;
	}*/
	/* vectors */
	if (var.rank==VECTOR) 
		*(var.elem+col-1)=val;
	/* regular matrix */
	else if (var.rank==MATRIX) 
		*(var.elem+((var.col)*(row-1)+col-1))=val;
	/* scalar */
	else if (var.rank==SCALAR) *var.elem=val;
	else perror_(__LINE__,5,(int)(strlen(p)-strlen(basetot)));
}


/* searchDEC()
 * find a DECLAREd variable/array in the vn[] structure
 * lp points to the DEC name and gets its code;
 * term is the last decCount to be counted;
 * store in _len the length of the variable name
 * System function */
int searchDEC(char *lp, int term) {
	int i=term, j;
	char name[NAMESTR], *n=name;

	/* check limit */
	if (i>=COMPVAR) {
		perror_(__LINE__,10,(int)(strlen(p)-strlen(basetot)));
		return 0;
	}

	/* set anyway a valid value as a safety measure */
	_len=0;
	if (!*lp || !lp) return FALSE;
	if (!(isupper(*lp))) return FALSE;
	/* get DEC name */
	j=0;
	while (isupper(*lp) || isdigit(*lp)) {
		*n++=*lp++;
		j++;
		if (j>=NAMESTR) break;
	}
	*n='\0';
	_len=(int)strlen(name);
	if (!_len || !name[0]) return FALSE;

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (vn[i].name[0] && !strcasecmp(vn[i].name,name)) {
			return i;
		}
		i--;
	}
	/* DEC irremediably not found */
	_len=0;
	return FALSE;
}


/*****************************************
 *	     TIME & STACK	      *
 *****************************************/

/* getTime()
 * return current time structure */
struct tm *getTime(void) {
	time_t st_lt;
	st_lt=time(NULL);
	return localtime(&st_lt);
}


/* getMin()
 * return current min (0-59) */
int getMin(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_min;
}


/* getMilliSec()
 * return current milliseconds */
int getMilliSec(void) {
	struct timespec vt;
	clock_gettime(CLOCK_MONOTONIC, &vt);
	return vt.tv_nsec;
}


/* getSec()
 * return current second (0-59) */
int getSec(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_sec;
}


/* getHour()
 * return current hour (0-23) */
int getHour(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_hour;
}


/* getWDay()
 * return current week day (0-6) */
int getWDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_wday;
}


/* getDay()
 * return current day (1-31) */
int getDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_mday;
}


/* getMonth()
 * return current month (1-12) */
int getMonth(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_mon+1);
}


/* getYear()
 * return current year */
int getYear(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_year+1900);
}


/* getMonthString()
 * return current month string */
char *getMonthString(void) {
	return month[getMonth()];
}


/*****************************************
 *	     MATH & STRINGS	    *
 *****************************************/

/* turnToUpper()
 * turn a line to all upper characters */
void turnToUpper(char *str) {
	while (*str) *str=toupper(*str), str++;
}


/* Note
 * The following strncpy_() and strncat_() are my own personal versions for
 * strcpy/strncpy and strcat/strncat respectively.
 * I must use mine because strncpy/strncat standard functions in C (gcc) have
 * erratic behaviors within different operating systems like Linux-Suse,
 * OpenBSD and Mac OS X 10.4 (the one I use).
 * Since many reported strange things happening because of strncpy/strncat
 * (from error in compilation to completely wrong string functions output), I
 * made up my mind and built these substitutes for both. */

/* strncpy_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator;
 * thus a width equal to 10 means 9 characters at most for the string;
 * dw must be put equal to the width, in this example 10;
 * of course, any lower value is also good.)
 * The process will take care of never going past the limit of dst,
 * and to fill  the rest of the space (if any) with nulls;
 * System function replacing strcpy/strncpy */
char *strncpy_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* check length of copy and source */
	if (dw<1) *dst='\0';
	else if (!src) {
		/* fill the whole string with nulls */
		if (!*src) while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	else {
		/* copy src onto dst but not past the end of dst */
		while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
		*dp++='\0';
		/* fill the rest with nulls */
		while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	/* Note: return the same value returned by strcpy/strncpy */
	return dst;
}


/* strncat_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst, and to fill
 * the rest of the space (if any) with nulls; if dst is found not initialized
 * (that is nowhere the terminator is found) it is initialized as void.
 * System function replacing strcat/strncat */
char *strncat_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* return directly dst in case src is empty or null */
	if (!src || !*src) return dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* copy src onto dst but not past the end of dst */
	while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<(dw)) *dp++='\0';
	/* Note: return the same value returned by strcat/strncat */
	return dst;
}


/* chrcat_()
 * add character c to list dst, taking care of checking the limit
 * dst: the destination string (which must have its proper dimension)
 * c: the character to be appended to dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst, and to fill
 * the rest of the space (if any) with nulls; if dst is found not initialized
 * (that is no terminator is found) dst is initialized as void.
 * Note: this function is a complement of the strncat_ function
 * System function */
char *chrcat_(char *dst, int c, int dw) {
	char *dp=dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* add c to dst but not past the end of dst */
	if (c && (int)(dp-dst)<(dw-1)) *dp++=c;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<(dw)) *dp++='\0';
	/* Note: return the same value returned by strncat_ */
	return dst;
}


/* Note
 * The following strncasecmp_() is my own personal version of strncasecmp.
 * I must use mine because strncasecmp seems to cause some problems if apple is
 * compiled under openSuse with gcc and or Linux/openBSD with gcc.
 * Since many reported errors in compiling when the standard strncasecmp is
 * used, I made up my mind and built this substitute. */

/* strncasecmp_()
 * the string compare function
 * dst and src are the strings to be compared;
 * N is the number of characters to be checked against;
 * return the flag for positive comparison result, 0 for match, -1 for failure.
 * Note: return values mimic the original return values, with the difference
 * that I don't check here for dst being greater or less than src, and in case
 * they differ, -1 is returned anyway; this is done for speed issues. */
int strncasecmp_(char *dst, char *src, int N) {
	if (N<=0) return TRUE;
	while (N && *dst && *src && toupper(*dst)==toupper(*src))
		src++, dst++, N--;
	if (!N) return FALSE;
	return TRUE;
}


/* strcomp()
 * the string comparison function for DIFFER and IDENT, which takes in account
 * the null comparison as true.
 * return TRUE if strings compare, FALSE if they differ.
 * system function for expression() */
int strcomp(char *str1, char *str2) {
	if (!*str1 && !*str2) return TRUE;
	else if (*str1 && !*str2) return FALSE;
	else if (!*str1 && *str2) return FALSE;
	else {
		while (*str1 && *str2 && *str1==*str2) str1++,str2++;
		if (*str1!=*str2) return FALSE;
	}
	return TRUE;
}


/* Note
 * The following memcpy_() is my own personal version of memcpy and memmove.
 * I must use mine because memcpy seems to be sometimes rejected by openBSD.
 * Since many reported errors in compiling if the standard memcpy/memmove is
 * used, I made up my mind and built this substitute. */

/* memcpy_()
 * copy a portion of memory from src to dst, using memmove (that takes care
 * of overlapping), for a number of characters as in size, checks before
 * if any of arrays are null, or size is zero */
void memcpy_(void *dst, void *src, int size) {
	if (src==NIL || dst==NIL || !size) return;
	memmove(dst,src,size);
}


/* Note
 * The following strcasestr_() and strchr_() are my own personal version 
 * of strcasestr() and strchr(). I must use mine because strcasestr() and strchr()
 * in C has someway an erratic behavior with Linux.
 * Since many reported errors in compiling if the standard strcasestr() is
 * used, I made up my mind and built this substitute. */

/* strcasestr_()
 * find the first occurrence of the substring 'little' in string 'big',
 * ignoring the case of both arguments.
 * The terminating null bytes (i.e. '\0') are not compared.
 * If 'little' is null, return NIL; if the substring is found, return the
 * updated address in 'big', otherwise return NIL. */
char *strcasestr_(char *big, char *little) {
	int l=(int)strlen(little);

	if (!l) return NIL;
	while (*big) {
		if (!strncasecmp_(big,little,l)) return big;
		big++;
	}
	return NIL;
}


/* strchr_()
 * find the first occurrence of char 'pr' into string 'pl' */
char *strchr_(char *pl, char pr) {
	if (!pr) return pl;
	while (*pl) {
		if (*pl==pr) return pl;
		pl++;
	}
	return NIL;
}


/* strcasechr_oq()
 * find the first occurrence of char 'pr' into string 'pl'
 * this function has the same usage of strchr(), but it works only if
 * outside of a string
 * (strcasechr_oq = strchr_ Out of Quotes No Case) */
char *strcasechr_oq(char *pl, char pr) {
	int isSin=FALSE;

	if (!pr) return pl;
	while (*pl) {
		if (*pl=='\'' && !isSin) isSin=TRUE;
		else if (*pl=='\'' && isSin) isSin=FALSE;
		if (*pl==pr && !isSin) return pl;
		pl++;
	}
	return NIL;
}


/* strstr_oq()
 * find the first occurrence of the substring string 'pr' into string 'pl'
 * this function has the same usage of strstr(), but it works only if
 * outside of a string, in APL normally surrounded by single quotes 
 * (strstr_oq = strstr_ Out of Quotes) */
char *strstr_oq(char *pl, char *pr) {
	int isSin=FALSE;
	int l=(int)strlen(pr);

	if (!l) return pl;
	while (*pl) {
		if (*pl=='\'' && !isSin) isSin=TRUE;
		else if (*pl=='\'' && isSin) isSin=FALSE;
		else if (!strncmp(pl,pr,l) && !isSin) return pl;
		pl++;
	}
	return NIL;
}


/* strstr_o2q()
 * find the first occurrence of the substring string "pr" into string "pl"
 * this function has the same usage of strstr(), but it works only if
 * outside of a string, this time surrounded by double quotes 
 * (strstr_o2q = strstr_ Out of Double Quotes) */
char *strstr_o2q(char *pl, char *pr) {
	int isSin=FALSE;
	int l=(int)strlen(pr);

	if (!l) return pl;
	while (*pl) {
		if (*pl=='\"' && !isSin) isSin=TRUE;
		else if (*pl=='\"' && isSin) isSin=FALSE;
		else if (!strncmp(pl,pr,l) && !isSin) return pl;
		pl++;
	}
	return NIL;
}


/* fgets_()
 * a replacement for fgets() to return strings from source f,
 * stopping only on feof(), and returning a void string in case
 * of empty line.
 * Note: the New Line character is removed and not part of the
 * returned string
 * Returns TRUE in case of correct reading, FALSE in case of EOF
 * The result string is in s */
int fgets_(char *s, int size, FILE *f) {
	char c;
	int i=0;
	c=fgetc(f);
	/* if EOF stop */
	if (c==EOF) {
		*s='\0';
		return FALSE;
	}
	/* if DOS/MAC-EOL set null string */
	else if (c=='\r') {
	       	c=fgetc(f);
		/* DOS-EOL*/
		if (c=='\n') {
			*s='\0';
		}
		/* MAC-EOL*/
		else {
			ungetc(c,f);
			*s='\0';
		}
		return TRUE;
	}
	/* if UNIX-EOL set null string */
	else if (c=='\n') {
		*s='\0';
		return TRUE;
	}
	/* proceed reading file line */
	else {
		while (c && i<size-1 && c!=EOF) {
			if (c=='\n' || c=='\r') {
				if (c=='\r') {
					c=fgetc(f);
					if (c!='\n') ungetc(c,f);
				}
				break; // end
			}
			*s++=c;
			i++;
			c=fgetc(f);
		}
		*s='\0';
	}
	return TRUE;
}


/*****************************************
 *      SIGNALS & ERROR TREATMENT	*
 *****************************************/

/* perror_()
 * print a string message based upon the following information data:
 * - errNum is the error code number defined in errors.h and must always be
 *   given as first argument
 * - ll is the line number in which the error is occurred; if null, the
 *   line reference is not printed (general errors); this must always be given
 *   as the second argument
 * - all the other parameters should be the ones needed in the error strings,
 *   to fill the data in the % specifiers, according to their type. */
int perror_(int line,int errNum, int ll, ...) {
	va_list ap;
	char output[COMPSTR*4], num[COMPSTR];
	int plen=0, offset=0;
	checkStop TRUE;;

	/* assure ll is positive */
	if (ll<0) ll=-ll;

	/* reset output string */
	strncpy_(output,VOIDS,COMPSTR*4);
	
	/* start building the error message */
	va_start(ap, ll);

	/* add regular error message with arguments */
	strncat_(output,error[errNum],COMPSTR*4);

	/* add apple source code (required by option -S) */
	if (isPrintSourceCode) {
		snprintf(num,COMPSTR," #%d#",line);
		strncat_(output,num,COMPSTR*4);
	}
	strncat_(output,"\n",COMPSTR*4);
	offset=(int)(strstr(basetot,p)-basetot);
	if (offset<0) offset=0;

	/* add programming line in case of error in program execution */
	if (((lastProgram && backTOS>0) || filename[0])) {
		char prog[COMPSTR*4];
		char name[COMPSTR];
		int line=0;
		if (!progLine) line=ll;
		else line=progLine;
		if (backTOS>0) {
			strncpy_(name,pn[backCode[backTOS]].name,COMPSTR);
			BASETOT=pn[backCode[backTOS]].m[line];
		}
		else {
			strncpy_(name,filename,COMPSTR);
			BASETOT=pn[0].m[line];
		}
		snprintf(prog,COMPSTR*4,"%s[%d] %n",name,line,&plen);
		strncat_(output,prog,COMPSTR*4);
	}
	else {
		strncat_(output,prompt,COMPSTR*4);
		plen=strlen(prompt)-1;
		BASETOT=basetot;
	}
	/* regulate length */
	if (ll>COMPSTR) ll=0;

	/* add line pointer to indicate where error appeared */
	if (BASETOT) {
		if ((lastProgram && backTOS>0) || filename[0])
			ll=plen+offset+1+(backTOS>0?strlen(pn[backCode[backTOS]].label[progLine])+1:0);
		else ll+=OFFSET;
		strncat_(output,BASETOT,COMPSTR);
		strncat_(output,"\n",COMPSTR);
		while (ll-->0) strncat_(output," ",COMPSTR);
		strncat_(output,"^",COMPSTR);
		strncat_(output,"\n",COMPSTR);
	}
	else strncat_(output,"\n",COMPSTR);

	/* print the error */
	if (!suppressMessage) emit(1,"%s",output);
	isError=TRUE;

	/* exit in case it is required by )OFF or in case of program given by console */
	if (isExtProgram) END(errNum);
	va_end(ap);
	return TRUE;
} // end of perror_()


/* intHandler()
 * the interrupt function */
void intHandler(int sig) {
	if (!transparent) {
		fflush(stdout);
		fflush(stderr);
		fflush(stdin);
		fprintf(stderr,"\n%s.\n\n","apple: CTRL-C pressed");
		fflush(stderr);
		/* force end in case of program given by console */
		isInterrupt=TRUE;
		if (isExtProgram) END(procCode);
		signal(SIGINT, intHandler);
	}
	else {
		if (!isExtProgram) {
			isInterrupt=TRUE;
		}
		signal(SIGINT, intHandler);
	}
}


/* END()
 * end program and return to session */
int END(int state) {
	int i;
	/* TIMING OPERATIONS */
	/* record end time
	 * Note: if file was not found, beginS remains negative */
	if (beginS<0) endS=0.0;
	else {
		gettimeofday(&tv, NULL);
	       	endS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		if (!isTiming) endS=endS-beginS;
		else endS=endS-progbeginS;
	}
	
	/* close all opened file */
	for (int i=1;i<=STREAMS;i++) {
		if (channel[i].isOpen) {
			fclose(channel[i].stream);
			channel[i].isOpen=FALSE;
			channel[i].ch=channel[i].wayout=0;
			for (int j=0;j<COMPSTR;j++)
				channel[i].name[j]='\0';
		}
	}

	/* perform unload of all var data if required */
	if (isCompleteUnload) {
		int tt, tk;
		i=1;
		if (decCount>0) {
			emit(1,"\nVariables data discharge for session %s:\n\n",currentWorkspaceName[0]?currentWorkspaceName:"without name");
			emit(1,"Name        Code        Type         Rank       row,col     Size\n");
			emit(1,"-------------------------------------------------------------------\n");
			while (i<=decCount) {
				if (vn[i].type) {
					tt=vn[i].type;
					tk=vn[i].rank;
					emit(1,"%-10.10s  %02d          %-10.10s   %-10.10s   %0d,%0d       %d\n",vn[i].name,i,types[tt/100],ranks[tk+1],vn[i].row,vn[i].col,vn[i].size);
				}
				i++;
			}
			emit(1,"\nEnd of variables data discharge\n");
		}
		else emit(1,"No variables to discharge for session %s.\n",currentWorkspaceName[0]?currentWorkspaceName:"without name");

		if (progCount>0) {
			i=1;
			emit(1,"\nPrograms data discharge for session %s:\n\n",currentWorkspaceName[0]?currentWorkspaceName:"without name");
			emit(1,"Name        Code   Lines   arg        left       right      locals\n");
			emit(1,"------------------------------------------------------------------------\n");
			while (i<=progCount) {
			emit(1,"%-10.10s  %02d     %02d      %-10.10s %-10.10s %-10.10s %-12.12s",pn[i].name,i,pn[i].endCore,pn[i].arg,pn[i].left,pn[i].rights,pn[i].locals);
			if (strlen(pn[i].locals)>12) emit(1,"*");
			emit(1,"\n");
				i++;
			}
			emit(1,"\nEnd of programs data discharge\n\n");
		}
		else emit(1,"\nNo programs to discharge for session %s.\n\n",currentWorkspaceName[0]?currentWorkspaceName:"without name");
	}

	/* timing or statistics */
	if (isTiming) do_timing(endS);

	/* flush all open streams, to ensure file data writing is completed */
	fflush(NULL);
	if (rl_line_buffer) free(rl_line_buffer);

	/* reset stack size */
	setrlimit(RLIMIT_STACK,&currStackSize);

	if (isExtProgram) exit(state);
	return TRUE;
} // end of END()


/***************************************
 *      DOCUMENTATION AND LICENSE      *
 ***************************************/

/* printHelp()
 * help message */
void printHelp(int doIt) {
	printExistence(doIt,TRUE);
	emit(1,"Usage: %sapple%s [options] [filename]\n\n",BOLD,RESETCOLOR);
	emit(1,"Options:\n");
	emit(1,"      --apl=<expr>        Evaluate APL expression <expr> before run\n");
 	emit(1,"      --args=<expr>       Set program arguments in <expr>, separated with ;\n");
	emit(1,"      --conditions        Print GPL3 redistribution conditions and exit\n");
	emit(1,"  -c, --clean/--clear     Start with a clean workspace, ignoring saved one\n");
	emit(1,"  -d, --delete-script     Erase scripting file before run\n");
	emit(1,"      --errors-list       Print the complete errors list and exit\n");
	emit(1,"  -h, --help              Display this information and exit\n");
        emit(1,"      --ibeams/--beams    Print the list of the I-Beam variables\n");
	emit(1,"  -l, --lib               List workspaces in current directory and exit\n");
	emit(1,"  -o, --ops               Print the monadic/dyadic operators list and exit\n");
 	emit(1,"      --post=<expr>       Evaluate APL expression <expr> after run\n");
	emit(1,"  -p, --prog              List apl programs in current directory and exit\n");
	emit(1,"      --script[=<f>]      Enable appending scripting the session (to file <f>)\n");
	emit(1,"  -s, --silent            Disable the banner printing\n");
	emit(1,"  -t, --timing            Enable timing execution\n");
 	emit(1,"      --trace=<expr>      Enable tracing on lines in <expr>\n");
	emit(1,"      --user=<u>          Set user name to <u>\n");
	emit(1,"  -v, --version           Display version and exit\n");
	emit(1,"      --warranty          Print warranty conditions from GPL3 and exit\n");
	emit(1,"      --workspace=<w>     Load workspace <w> before session or [filename]\n\n");
	emit(1,"If [filename] is not given, an APL session will start; if option --user\nis not used, the Linux/UNIX login name, turned to upper case,\nwill be used as the username.\n\n");
	emit(1,"You should have received a copy of the GNU General Public License along\nwith this program. If not, see <http:/www.gnu.org/licenses/>.\nConsult the man or the info page to know more about this program.\nEmail bugs reports to <ing dot antonio dot maschio at gmail dot com>.\n\n");
	emit(1,"It's GPL, enjoy!\n\n");
}


/* printHiddenHelp()
 * complete help message */
void printHiddenHelp(int doIt) {
	printExistence(doIt,TRUE);
	emit(1,"Usage: %sapple%s [options] [filename]\n\n",BOLD,RESETCOLOR);
	emit(1,"Options:\n");
	emit(1,"      --apl=<expr>        Evaluate APL expression <expr> before run\n");
 	emit(1,"      --args=<expr>       Set program arguments in <expr>, separated with ;\n");
	emit(1,"      --conditions        Print GPL3 redistribution conditions and exit\n");
	emit(1,"  -c, --clean/--clear     Start with a clean workspace, ignoring saved one\n");
	emit(1,"  -d, --delete-script     Erase scripting file before run\n");
	emit(1,"  -D (debug)              set debug mode\n");
	emit(1,"      --errors-list       Print the complete errors list and exit\n");
	emit(1,"  -h, --help              Display this information and exit\n");
	emit(1,"      --hidden            Display this complete help and exit\n");
	emit(1,"  -l, --lib               List workspaces in current directory and exit\n");
	emit(1,"  -o, --ops               Print the monadic/dyadic operators list and exit\n");
	emit(1,"  -p, --prog              List apl programs in current directory and exit\n");
	emit(1,"      --script[=<f>]      Enable appending scripting the session (to file <f>)\n");
	emit(1,"  -s, --silent            Don't print the %sapple%s banner\n",BOLD,RESETCOLOR);
	emit(1,"  -S (debug)              Print source code line in case of error\n");
	emit(1,"  -t, --timing            Enable timing execution\n");
 	emit(1,"      --trace=<expr>      Enable tracing on lines in <expr>\n");
	emit(1,"      --user=<u>          Set user name to <u>\n");
	emit(1,"  -v, --version           Display version and exit\n");
	emit(1,"  -V (debug)              Display version number only\n");
	emit(1,"      --warranty          Print warranty conditions from GPL3 and exit\n");
	emit(1,"      --workspace=<w>     Load workspace <w> before session or [filename]\n");
	emit(1,"  -W (debug)              apply discharge and show variables final state\n\n");
	emit(1,"If [filename] is not given, an APL session will start; if option --user\nis not used, the Linux/UNIX login name will be used as the username,\nwhich is all turned to upper case, for starting a new clean workspace.\n\n");
	emit(1,"The following undocumented APL console commands (never abbreviated)\nare available for current usage in any workspace (conceived while\ndevelopping %sapple%s and here maintained):\n\n",BOLD,RESETCOLOR);
	emit(1,"   )?[NAME]           See variable or program [NAME]\n");
	emit(1,"   )$[VAL] [NAME]     See variable with code [VAL]; set [NAME] if given\n");
	emit(1,"   )DISCHARGE         apply discharge (apple debug purposes)\n");
	emit(1,"   )FLAG              print flags status (apple debug purposes)\n");
	emit(1,"   )IBM               (easter-egg) My thanks to APL creators\n");
	emit(1,"   )UNRECOG           (easter-egg) Joke\n");
	emit(1,"   )VERSION           print current version\n\n");
	emit(1,"The debug mode, when active, prints the number and the content of the line\nunder execution, before it is executed. The programmer may so highlight\nthe execution process, and see where it does not work as expected.\n\n");
	emit(1,"The discharge mode, at the end of session, prints two tables, one for\nthe variables and and one for the programs, that sum up the memory state\nof the current workspace. This helps in understanding if some variable\nwas local or global, or if some programs was altered.\n\n");
	emit(1,"The status of the flags was useful to establish if some system flag was\nwrongly set or to understand, step by step, which flag was on or off.\nThis is meaningless for the APL programmer.\n\n");
	emit(1,"You should have received a copy of the GNU General Public License along\nwith this program. If not, see <http:/www.gnu.org/licenses/>.\nConsult the man or the info page to know more about this program.\nEmail bugs reports to <ing dot antonio dot maschio at gmail dot com>.\n\n");
	emit(1,"It's GPL, enjoy!\n\n");
}

/* printExistence()
 * existence message */
void printExistence(int doIt, int col) {
	if (!doIt) return;
	if (col) emit(1,LOGO,REDCOLOR,RESETCOLOR,REDCOLOR,RESETCOLOR);
	else emit(1,LOGO,"","","","");
	emit(1,"%sapple%s, an APL (ASCII) engine for Unix\n",BOLD,RESETCOLOR);
}

/* printVersion()
 * help banner */
void printVersion(int doIt) {
	printExistence(doIt,TRUE);
	emit(1,"version %s %s", VERSION,__DATE__);
	emit(1," - Copyleft (C) %s\n%s <%s>. \n", CY, AU, EM);
}

/* printHelpBanner()
 * version message */
void printHelpBanner(void) {
	emit(1,"%s\n","---------------------------------------------------------------");
	emit(1,"%s","This free software comes with ABSOLUTELY NO WARRANTY; for details\nabout this, type 'apple --warranty'. You are welcome to redistribute it\nunder certain conditions; type 'apple --conditions' for details.\nThis software is released under the terms of the GNU General Public License 3.\n\0");
}

/* printWarranty()
 * warranty message (required by GPL3) */
void printWarranty(void) {
	emit(1,"%s","THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\nAPPLICABLE LAWS. EXCEPT WHEN OTHERWISE STATED IN WRITING THE\nCOPYRIGHTERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\"\nWITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,\nBUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY\nAND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY\nAND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM\nPROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\0");
}

/* printConditions()
 * conditions message (required by GPL3) */
void printConditions(void) {
	emit(1,"%s","You may make, run and propagate covered works that you do not convey,\nwithout conditions so long as your license otherwise remains in force.\nYou may convey covered works to others for the sole purpose of\nhaving them make modifications exclusively for you, or provide you\nwith facilities for running those works, provided that you comply with\nthe terms of this License in conveying all material for which you\ndo not control copyright. Those thus making or running the covered works\nfor you must do so exclusively on your behalf, under your direction\nand control, on terms that prohibit them from making any copies of your\ncopyrighted material outside their relationship with you.\n\0");
}


/******************************************************************************
 * MAIN SECTION
 ******************************************************************************/
/* type()
 * perform the )TYPE command */
int type(char *filestr) {
	FILE *f=NULL;
	char B[COMPSTR];
	
	/* open file for reading */
	if (!(f=fopen(filestr,"r"))) { // confirmed "r"
		/* try appending ".apl" (using B) */
		strncpy_(B,VOIDS,COMPSTR);
		strncat_(B,filestr,COMPSTR);
		strncat_(B,".apl",COMPSTR);
		if (!(f=fopen(B,"r"))) { // confirmed "r"
			return FALSE;
		}
	}

	/* type file */
	while(fgets_(B,COMPSTR,f)) 
		if (B[0]) {
			emit(1,"%s\n",B);
		}

	if (f) fclose(f);
	return TRUE;
}


/* do_export()
 * perform the )EXPORT command */
int do_export(char *filestr, int ns, char *header, int ds) {
	FILE *f=NULL;
	char B[COMPSTR];
	int i;
	
	/* open file for writing */
	if (strncasecmp_(filestr+strlen(filestr)-4,".apl",4)) {
		/* append ".apl" (using B) */
		strncpy_(B,VOIDS,COMPSTR);
		strncat_(B,filestr,COMPSTR);
		strncat_(B,".apl",COMPSTR);
	}
	else strncpy_(B,filestr,COMPSTR);
	if (!(f=fopen(B,"w"))) {
		emit(1,error[20],filestr);
		return FALSE;
	}

	/* export file */
	fprintf(f,"\\/ %s\n",header);
	for (i=1;i<=pn[ns].endCore;i++) {
		fprintf(f,"%s\n",pn[ns].m[i]);
	}
	fprintf(f,"\\/\n");

	/* export documentation variable ds */
	if (ds) {
		char *out=NULL;
		char *o;
		fprintf(f,"\n");
		fprintf(f,"%s<-",vn[ds].name);
		printArray(&out,vn[ds]);
		o=out;
		fputc('\"',f);
		while (*o) {
			if (*o=='\n') {
				fputc('\\',f);
				fputc('n',f);
			}
			else fputc(*o,f);
			o++;
		}
		fputc('\"',f);
		fputc('\n',f);
		fputc('\n',f);
	}

	if (f) fclose(f);
	return TRUE;
}


/* load()
 * the general loader for programs, used in main()
 * and by the system command )IMPORT */
int load(char *filestr, int pos) {
	FILE *f;
	char B[COMPSTR], *pB=B;
	char BD[OUTSTR], *w;
	int linenum=1, aline=1, dvar=0;
	
	/* open file for reading */
	if (!(f=fopen(filestr,"r"))) { // confirmed "r"
		/* try appending ".apl" (using B) */
		strncpy_(B,VOIDS,COMPSTR);
		strncat_(B,filestr,COMPSTR);
		strncat_(B,".apl",COMPSTR);
		if (!(f=fopen(B,"r"))) { // confirmed "r"
			if (!pos) {
				emit(1,error[21],filestr);
			}
			return FALSE;
		}
	}

	/* load lines one by one */
	while((fgets_(B,COMPSTR,f)) && linenum<COMPSTR-1) {
		aline++;
		/* check if it is a workspace */
		if (isdigit(B[0]) && linenum==1) {
			emit(1,error[26],filestr);
			return FALSE;
		}
		/* strip away EOL */
		pB=w=B;
		if ((int)strlen(pB)>0) {
			if (*(w+strlen(w)-1)=='\r') *(w+strlen(w)-1)='\0';
			if (*(w+strlen(w)-1)=='\n') *(w+strlen(w)-1)='\0';
			if (*(w+strlen(w)-1)=='\r') *(w+strlen(w)-1)='\0';
		}
		/* double "" print its content */
		if (*pB=='\"' && *(pB+1)=='\"') {
			pB+=2;
			while (isblank(*pB)) pB++;
			emit(1,"%s\n",pB);
			continue;
		}

		/* bash-like comment or empty lines are discarded */
		else if (*pB=='#' && linenum==1 && *filestr) continue;
		else if (!*pB) continue;
		/* skip starting blanks */
		while (isblank(*pB)) pB++;
		/* the simple comment is discared */
		//if (*pB=='c' && *(pB+1)=='o') continue;
		pn[pos].hasLabel=FALSE;
		/* pragma command ]IMPORT */
		if (*pB==']') {
			char *k=pB;
			*k=')';
			k++;
			while (isblank(*k)) k++;
			if (strncasecmp_(k,"IMPO",4)) {
				perror_(__LINE__,14,(p-BASETOT));
				return FALSE;
			}
			executeSystemCommand(pB);
			continue;
		}
		else if (!strncmp(pB,"co",2)) {
			continue;
		}
		/* check for banned commands */
		else if (*pB==')') {
			char *s=pB;
			s++; // skip )
			if (!isNotBanned(s)) {
				perror_(__LINE__,14,(p-BASETOT));
				return FALSE;
			}
		}
		/* check balancing */
		if (!checkBal(pB) && *pB!=')')  {
			fprintf(stderr,"%s - LINE %d\n",error[27],aline);
			return FALSE;
		}
		if (!strncasecmp_(pB,"\\/",2) && linenum==1) {
			pB+=2;
			while (isblank(*pB)) pB++;
			getHeader(pB,&pB,pos);
			continue;
		}
		else if (!strcmp(pB,"\\/")) {
			break;
		}
		/* label detected */
		else if (isLabel(pB)) {
			char lab[NAMESTR], *k, *pb=pB;
			int j;
			pn[pos].labelTOS++;
			k=lab;
			j=0;
			while (isupper(*pB) || isdigit(*pB)) {
				*k++=*pB++;
				j++;
				if (j>=NAMESTR) break;
			}
			*k='\0';
			if (*pB==':') pB++;
			/* else error */
			while (isblank(*pB)) pB++;
			strncpy_(pn[pos].label[pn[pos].labelTOS],lab,NAMESTR);
			pn[pos].ln[pn[pos].labelTOS]=linenum;
			pn[pos].hasLabel=TRUE;
			pB=pb;
		}
		if (*pB) strncpy_(pn[pos].m[linenum],pB,COMPSTR);
		else strncpy_(pn[pos].m[linenum],"   ",COMPSTR);
		pn[pos].data[linenum]=linenum;
		linenum++;
	}

	/* in case of headless function, set it as an argument-less
	 * program with the name equal to the file name without
	 * extension, and turned to upper */
	if (!pn[pos].name[0]) {
		char *t;
		char name[COMPSTR];
		strncpy_(name,filestr,COMPSTR);
		turnToUpper(name);
		t=name;
		while (*t) {
			if (*t=='.') {*t='\0';
				break;
			}
			t++;
		}
		strncpy_(pn[pos].name,name,NAMESTR);
	}

	/* look for the documentation variable beginning with D
	 * (for Dictionary? Definition? Documentation?) */
	BD[0]='\0';
	pB=BD;
	/* skip empty lines */
	while (!*pB && (dvar=fgets_(BD,OUTSTR,f))) {
		pB=BD;
		while (isblank(*pB)) pB++;
	}
	/* assign */
	if (*pB && isAnAssignment(pB)) {
		char *pb=p;
		TDeclare res;
		setArray(&res);
		p=pB;
		expression(&res);
		p=pb;
		free_(&res);
	}
	/* close file channel */
	pn[pos].endCore=linenum-1;
	if (f) fclose(f);
	return pos;	
} // end of load()


/* execAplLine()
 * execute the line in --apl as an APL command
 * return control to main() */
int execAplLine(char *line) {
	TDeclare res;
	setArray(&res);
	p=line;
	while (*p && !isError) {
		BASETOT=p;
		analyse(&res); // ex assign()
		if (!avoidPrintResult) {
			char *out=NULL;
			printArray(&out,res);
			emit(1,"%s\n",out);
			free(out);
		}
		while (isblank(*p)) p++;
		if (*p==';') p++;
		else break;
		while (isblank(*p)) p++;
	}
	free_(&res);
	return TRUE;
}


/* eval_options()
 * parse options; double and single dash options may be alternated,
 * options requiring an argument may or not be attached (but must
 * be the last options of that group);
 * return the updated argc count in ac
 * ~Antonio Maschio - March 2014 for the decb project, adapted and extracted
 * as a single function in April 2021 for the apple project */
int eval_options(int argc, char **argv) {
	int c,ac=0;
	while (++ac < argc) {
		/* do not parse the rest of the command-line */
		if (!strcasecmp(argv[ac], "--")) {
			ac++;
			break;
		}
		if (*argv[ac]=='-') {
			/* option --help */
			if (!strcasecmp(argv[ac], "--help")) {
				fputc('\n',stdout);
				printHelp(TRUE);
				exit(EXIT_SUCCESS);
			}
			/* option --hidden */
			if (!strcasecmp(argv[ac], "--hidden")) {
				fputc('\n',stdout);
				printHiddenHelp(TRUE);
				exit(EXIT_SUCCESS);
			}
			/* option --errors-list */
			else if (!strcasecmp(argv[ac], "--errors-list") ||\
				!strcasecmp(argv[ac], "--errorslist") ||\
				!strcasecmp(argv[ac], "--errors")) {
				int i;
				char *y;
				fprintf(stdout,"\nErrors list for %sapple%s ",BOLD,RESETCOLOR);
				fprintf(stdout,"version %s\n\n",VERSION);
				for (i=0;i<ERRLIM;i++) {
					y=error[i];
				    	if (*y) {
						fprintf(stdout,"%3d %s",i,y);
					    	if (*(y+strlen(y)-1)!='\n') {
							fprintf(stdout,"\n");
					    	}
				    	}
				}
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS);
			}
			/* option --operators / --ops / --ops-list */
			else if (!strcasecmp(argv[ac], "--operators") ||\
					!strcasecmp(argv[ac], "--ops") ||\
					!strcasecmp(argv[ac], "--ops-list")) {
				fprintf(stdout,"\nOperators in %sapple%s ",BOLD,RESETCOLOR);
				fprintf(stdout,"version %s\n",VERSION);
				callOps(stdout);
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS);
			}
			/* option --ibeam / --ibeams / --i-beam */
			else if (!strcasecmp(argv[ac], "--ibeam") ||\
					!strcasecmp(argv[ac], "--ibeams") ||\
					!strcasecmp(argv[ac], "--i-beam")) {
				fprintf(stdout,"\nI-Beam variables in %sapple%s ",BOLD,RESETCOLOR);
				fprintf(stdout,"version %s\n",VERSION);
				callIBeam(stdout);
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS);
			}
			/* option --version */
			else if (!strcasecmp(argv[ac], "--version")) {
				fputc('\n',stdout);
				printVersion(TRUE);
				printHelpBanner();
				exit(EXIT_SUCCESS);
			}
			/* option --delete-script */
			else if (!strcasecmp(argv[ac], "--delete-script")) {
				isDeleteScriptFile=TRUE;
				continue;
			}
			/* option --warranty */
			else if (!strcasecmp(argv[ac], "--warranty")) {
				fputc('\n',stdout);
				printWarranty();
				exit(EXIT_SUCCESS);
			}
			/* option --conditions */
			else if (!strcasecmp(argv[ac], "--conditions")) {
				fputc('\n',stdout);
				printConditions();
				exit(EXIT_SUCCESS);
			}
			/* option --lib 
			 * list workspaces */
			else if (!strncasecmp(argv[ac], "--lib",5)) {
				listWKS(".wks");
				exit(EXIT_SUCCESS);
			}
			/* option --prog
			 * list workspaces */
			else if (!strncasecmp(argv[ac], "--prog",6)) {
				listWKS(".apl");
				exit(EXIT_SUCCESS);
			}
			/* option --apl= */
			else if (!strncasecmp(argv[ac], "--apl=",6)) {
				char *p=argv[ac]+6;
				strncpy_(aplline,p,COMPSTR);
				isAplLine=TRUE;
				continue;
			}
			/* option --post= */
			else if (!strncasecmp(argv[ac], "--post=",7)) {
				char *p=argv[ac]+7;
				strncpy_(postline,p,COMPSTR);
				isPostLine=TRUE;
				continue;
			}
			/* option --trace= */
			else if (!strncasecmp(argv[ac], "--trace=",8)) {
				char *pb=p;
				int trace=TRUE;
				p=argv[ac]+8;
				expression(&traceV);
				if (traceV.rank==SCALAR) {
					if (getArrayVal(traceV,1,1)==0) {
						trace=FALSE;
					}
					else makeVector(&traceV);
					isExtTracing=trace;
				}
				else if (traceV.rank!=VECTOR) {
					printf("Value error. Tracing not set.\n");
					isExtTracing=FALSE;
				}
				else isExtTracing=TRUE;
				p=pb;
				continue;
			}
			/* option --args= */
			else if (!strncasecmp(argv[ac], "--args=",7)) {
				char *p=argv[ac]+7;
				strncpy_(args,p,COMPSTR);
				isArg=TRUE;
				continue;
			}
			/* option --user= */
			else if (!strncasecmp(argv[ac], "--user=",7)) {
				char *p=argv[ac]+7;
				char *li=username;
				while(*p && !isblank(*p)) *li++=*p++;
				*li='\0';
				turnToUpper(username);
				isClean=TRUE;
				continue;
			}
			/* option --workspace= */
			else if (!strncasecmp(argv[ac], "--workspace=",12)) {
				char *q=argv[ac]+12;
				char resp[COMPSTR], *n;
				strncpy_(wname,VOIDS,NAMESTR);
				n=wname;
				while (isblank(*q)) q++;
				/* this is a file name... */
				while(*q && !isblank(*q)) *n++=*q++;
				*n='\0';
				wasLoadWorkspaceOK=TRUE;
				loadWorkspace(wname,resp,FALSE);
				isClean=TRUE;
				continue;
			}
			/* option --clean/--clear 
			 * start with a clean workspace */
			else if (!strncasecmp(argv[ac], "--clean",7) || !strncasecmp(argv[ac], "--clear",7)) {
				isClean=TRUE;
				continue;
			}
			/* option --timing 
			 * enable timing */
			else if (!strncasecmp(argv[ac], "--timing",8)) {
				isTiming=TRUE;
				continue;
			}
			/* option --silent 
			 * disable banner */
			else if (!strncasecmp(argv[ac], "--silent",8)) {
				isSilent=TRUE;
				continue;
			}
			/* option --script */
			else if (!strncasecmp(argv[ac], "--script",8)) {
				char *p=argv[ac]+8;
				if (*p=='=') {
					char *li=scriptname;
					int c=0;
					p++; // skip =
					while(*p && !isblank(*p) && c<COMPSTR) {
						*li++=*p++;
						c++;
					}
					*li='\0';
				}
				else {
					strncpy_(scriptname,defaultScriptName,COMPSTR);
				}
				isScript=TRUE;
				continue;
			}
			/* this feature is intentionally undocumented
			 * I use it to generate the README file */
			else if (!strcasecmp(argv[ac], "--greetings")) {
				fprintf(stdout,"%s","apple README page\n");
				fprintf(stdout,"%s",WELCOME);
				printExistence(TRUE,FALSE);
				printVersion(FALSE);
				printHelpBanner();
				printHelp(FALSE);
				fprintf(stdout,GREET);
				printWarranty();
				fprintf(stdout,"%s","\n");
				printConditions();
				fprintf(stdout,"%s","It's GPL. Enjoy!\n\n");
				exit(EXIT_SUCCESS);
			}
			/* stop options parsing */
			else if (!strcasecmp(argv[ac], "--")) {
				break;
			}
			/* ignore unrecognized double-dash options */
			else if (!strncasecmp_(argv[ac],"--",2)) {
				char output[COMPSTR];
				snprintf(output,COMPSTR,error[24],argv[ac]);
				fprintf(stderr,"%s\n\n",output);
				ac++;
				return ac=-999;
			}
			/* parse single-dash options */
			while (*++argv[ac]) {
				c=*argv[ac];
				/* option -h
				 * print help */
				if (c=='h') {
					fputc('\n',stdout);
					printHelp(TRUE);
					exit(EXIT_SUCCESS);
				}
				/* option -W (UNDOCUMENTED)
				 * print complete var state at the end */
				else if (c=='W') {
					isCompleteUnload=TRUE;
				}
				/* option -S  (UNDOCUMENTED)
				 * print source code line number inside the
				 * error message */
				else if (c=='S') {
					isPrintSourceCode=TRUE;
				}
				/* option -D  (UNDOCUMENTED)
				 * print executed line in case of programs */
				else if (c=='D') {
					isDebug=TRUE;
				}
				/* option --lib 
				 * list workspaces */
				else if (c=='l') {
					listWKS(".wks");
					exit(EXIT_SUCCESS);
				}
				/* option --prog
				 * list programs */
				else if (c=='p') {
					listWKS(".apl");
					exit(EXIT_SUCCESS);
				}
				/* option -s
				 * disable banner */
				else if (c=='s') {
					isSilent=TRUE;
				}
				/* option -c
				 * enable starting with a clean workspace */
				else if (c=='c') {
					isClean=TRUE;
				}
				/* option -d
				 * enable deleting script file */
				else if (c=='d') {
					isDeleteScriptFile=TRUE;
				}
				/* option -t
				 * enable timing */
				else if (c=='t') {
					isTiming=TRUE;
				}
				/* option -o
				 * print operators */
				else if (c=='o') {
					fprintf(stdout,"\nOperators in %sapple%s ",BOLD,RESETCOLOR);
					fprintf(stdout,"version %s\n\n",VERSION);
					callOps(stdout);
					fprintf(stdout,"\n");
					exit(EXIT_SUCCESS);
				}
				/* option -v
				 * print version */
				else if (c=='v') {
					fputc('\n',stdout);
					printVersion(TRUE);
					printHelpBanner();
					exit(EXIT_SUCCESS);
				}
				/* option -V  (UNDOCUMENTED)
				 * print version and exit */
				else if (c=='V') {
					printf("%s",VERSION);
					exit(EXIT_SUCCESS);
				}
				/* Ignore unrecognized options */
				else {
					char output[COMPSTR];
					snprintf(output,COMPSTR,error[25],c);
					fprintf(stderr,"%s\n\n",output);
					return ac=-999;
				}
			}
		}
		else break;
	}
	return ac;
}


/* main()
 * get file name, setup environment and perform, at request.
 * Where it all begins... and where it all ends */
int main(int argc, char **argv) {
	int i=0,ac=0;
	char efilename[COMPSTR];

	/* get start time *
	 * set features that depend on starting time */
	gettimeofday(&tv, NULL);
	beginS=((double)tv.tv_sec + tv.tv_usec / 1000000.0);
	progbeginS=beginS;
	beginMS=(long long int)(tv.tv_sec*1000 + tv.tv_usec / 1000.0);
	strncpy_(username,getenv("LOGNAME"),COMPSTR);
	turnToUpper(username);

	/* set standard 6-digits output */
	snprintf(numformat,COMPSTR,"%%.06G  ");
	snprintf(mnumformat,COMPSTR,"  %%.06G");

	/* get screen window size*/
	ioctl(STDOUT_FILENO, TIOCGWINSZ, &wsz);
	sysWidth=(int)wsz.ws_col;

	/* set up inversion string */
	strcpy(properInvStr,"NO INVERSION YET!");
	
	/* erase workspace data */
	eraseCurrentWorkspace();
	strncpy_(prevName,VOIDS,COMPSTR);
	for (i=0;i<COMPSTR;i++) {
		backStore[i]=0;
		backCode[i]=0;
		backNumber[i]=0;
		isResAssign[i]=0;
		resVar[i]=0;
		if (vn[i].allocated) eraseDEC(&vn[i]);
		else setArray(&vn[i]); // assure to put elem=NULL
	}

	/* set up file data */
	for (int i=1;i<=STREAMS;i++) {
		channel[i].stream=NULL;
		channel[i].isOpen=FALSE;
		channel[i].ch=channel[i].wayout=0;
		for (int j=0;j<COMPSTR;j++)
			channel[i].name[j]='\0';
	}
	
	/* initialize parstack structures */
	for (int i=0;i<PARSTACK;i++) {
		parstack[i][0]='\0';
	}
	
	/* evaluate direct options */
	ac=eval_options(argc,argv);
	
	/* augment stack size for recursion */
	getrlimit(RLIMIT_STACK,&currStackSize);
	newStackSize=currStackSize;
	newStackSize.rlim_cur=RLIM_INFINITY;
	newStackSize.rlim_max=RLIM_INFINITY;
	setrlimit(RLIMIT_STACK,&newStackSize);

	/* case of unrecognized options */
	if (ac==-999) goto main_end;

	/* get file name */
	if (ac<argc && argc!=1) {
		strncpy_(efilename,argv[ac++],COMPSTR);
	}
	else {
		strncpy_(efilename,VOIDS,COMPSTR);
	}
	
	/* intercept the CTRL-C interrupt */
	signal(SIGINT, intHandler);
	
	/* execute file */
	if (efilename[0]) {
		char fname[COMPSTR];
		TDeclare res, val1, val2;
		setArray(&res);
		setArray(&val1);
		setArray(&val2);
		/* set up external args */
		if (isArg) {
			p=args;
			if (!*p) {
				emit(1,"Missing argument. Cannot continue.\n");
				goto main_end;
			}
			expression(&val1);
			if (*p==';') {
				p++; // skip ;
				expression(&val2);
			}
			else copyArray(&val2,val1);
		}
		else {
			eraseDEC(&val1);
			eraseDEC(&val2);
		}
		isExtProgram=TRUE;
		/* set up names and trace options */
		strncpy_(fname,efilename,COMPSTR);
		applizeName(fname);
		/* execute the --apl option in case */
		if (isAplLine) execAplLine(aplline);
		/* load file in memory at pos 1 */
		strncpy_(filename,efilename,COMPSTR);
		load(efilename,1);
		/* run program */
		strncpy_(traceName,pn[1].name,NAMESTR);
		//strncpy_(pn[1].name,fname,NAMESTR);
		progCount=1;

		if (isExtTracing) {
			isTracing=TRUE;
		}
		if (isExtStopping) {
			isStopping=TRUE;
			strcpy(stopName,pn[1].name);
		}
		execProg(&res,1,val1,val2,1);
		/* print result in case of arguments from outside */
		if (isArg) {
			char *out=NULL;
			printArray(&out,res);
			emit(1,"%s\n",out);
			free(out);
		}
		/* execute the --post option in case */
		avoidPrintResult=FALSE;
		if (isPostLine) execAplLine(postline);
		free_(&res);
		free_(&val1);
		free_(&val2);
	}
	/* execute the --apl option */
	else if (isAplLine) execAplLine(aplline);
	/* otherwise start session */
	else {
		/* search for the system default workspace file set by )CONTINUE */
		FILE *fres=fopen(defaultContinueName,"r");
		/* if found, load it unless --clean was invoked */
		if (fres && !isClean) {
			fclose(fres);
			wasLoadWorkspaceOK=TRUE;
			loadWorkspace(defaultContinueName,defaultContinueName,FALSE);
			/* in case of error, set the workspace system name
			 * and let parse() print the message */
			if (!wasLoadWorkspaceOK) {
				strncpy_(wname,"SYSTEM WSID",NAMESTR);
			}
		}
		/* open the script file if required */
		if (isScript) {
			if (isDeleteScriptFile) FS=fopen(scriptname,"w");
			else FS=fopen(scriptname,"a");
			if (!FS) {
				isScript=FALSE;
			}
		}
		parse(1);
	}

main_end:
	
	/* end scripting task */
	if (isScript && FS) {
		fflush(FS);
		fclose(FS);
	}
	
	/* END program */
	END(procCode);
	return EXIT_SUCCESS;
} /* end main */

/* end of apple.c */


