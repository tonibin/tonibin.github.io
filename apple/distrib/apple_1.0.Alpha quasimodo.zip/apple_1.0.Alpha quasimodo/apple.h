/* apple.h
 * Copyleft (C) 2009-2018 Antonio Maschio
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 07 agosto 2021
 *
 * This is apple, an APL engine written in c99 for
 * the UNIX world. You must have gcc 4.X to compile (though maybe 3.X may go).
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stddef.h>
#include <dirent.h>
#include <sys/dir.h>
#include <sys/param.h>
#include <errno.h>
#include "errors.h"
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <fnmatch.h>
#include <stdarg.h>
#include <sys/resource.h>
#include <libgen.h>
#include <pwd.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <termios.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <stdint.h>
#include <float.h>
#include <sys/sysinfo.h>
#include <complex.h>
#include "custom.h"
#undef I

/* Hardwired versioning strings (dont' change!) */
#define VERSION "1.0.Alpha quasimodo"
#define AU "Antonio Maschio"		                  /* Author */
#define EM "ing dot antonio dot maschio at gmail dot com" /* Email */
#define CY "2022-2024"		  	                  /* Years */

/* Hardwired constants (don't change!) */
#define TRUE  1
#define FALSE 0
#define STRING  	 100		// STRING data type code
#define NUMERIC  	 200		// INTEGER data type code
#define SCALAR		   0
#define VECTOR             1
#define MATRIX		   2
#define VREAD		  10
#define VWRITE            20
#define WAPPEND            2
#define WERASE             3
#define PAREN		  20

char *types[]=
{"UNKNOWN", "STRING","NUMERIC"};
char *ranks[]=
{"UNKNOWN", "SCALAR","VECTOR","MATRIX"};

#define LOGO "       __\n      /_|\n  __ |/_\n /   V  \\\n|      _ |\n|    /_/ |\n \\______/   %sA%sP%sPL%sE APL!\n\n"
	
#define NIL 0
#define PROMPTBASE "      "
#define ZERO 8.6361685763E-78 		// smallest real not zero (2^-256)
#define XZERO 1.E-78 //
#define CZERO 1.E-12 // OK1.E-12
#define IZERO 1.E-16 //
#define EZERO 1.E-13 //
#define VZERO 1.E-18 //
#define PSTACK 256			// dimension of the inner RPN stack
#define CONTINUE -100
#define MAXARGS 16			// limit for alternations
#define APLPI  3.14159265358979323846	// pi
#define MAXRAN  32768
#define GREET "Notes:\n- to compile type \'make\' as user in apple\' source directory.\n- to install type \'make install\' as root after compiling.\n  (but I'm sure you know better than me what to do!)\n\n"
#define WELCOME "\nWelcome, user! I hope you\'ll like this program.\nHere\'s some information about it and its license...\n"
#define BOLD "[1m"
#define RESETCOLOR "[1;m"
#define REDCOLOR  "[1;31m"
#define GREENCOLOR  "[1;32m"
#define YELLOWCOLOR  "[1;33m"
#define BLUECOLOR  "[1;34m"
#define WHITECOLOR  "[1;37m"
#define HISTORY	"./.apple_history"	// readline facility
#define HISTLEN 1000			// readline facility
#define VOIDS   ""
#define MAX_READ 4096
#define BALA 14
#define CHOL 15
#define KOND 16
#define HESS 17
#define RADI 18
#define GOTO 19
#define ASSI 20
#define AFRM 21
#define STRI 22
#define TIMI 23
#define TRAS 24
#define QRDC 25
#define QSVD 26
#define EIGE 27
#define POLA 28
#define INVERSE 1
#define DETERMI 2
#define COEFFIC 3
#define VARVS   11
#define FNCTS   22
#define MAXPREC 18
#define OFFSET  6
#define PARSTACK 100

#define BANNER "\n-----------------------------------------------------------------------------\nWelcome to apple, an implementation of SNOBOL4 in C (version %s)\nbuilt according to the Berkeley Version implemented at the University of\nCalifornia (see the manual of Robert Gaskins and Laura Gould - Spring 1972)\nby Antonio Maschio <ing dot antonio dot maschio at gmail dot com> 2020-2021\nIt's GPL: Enjoy!\n-----------------------------------------------------------------------------\n\n"
#define defaultContinueName ".aplcont.wkc"
#define defaultScriptName "aplscript.txt"

/* variable structure */
struct t_declare {
	char name[NAMESTR];	// declaration name
	int type;		// = NUMERIC|STRING
	int rank;		// = SCALAR|VECTOR|MATRIX
	double *elem;		// pointer to the array space
	int col;		// columns number
	int row;		// row number
	int size;		// array global space
	int allocated;		// for free()
};
typedef struct t_declare TDeclare;

/* program structure */
struct t_program {
	char name[NAMESTR];		// program name /parse
	char m[COMPSTR][COMPSTR];	// the memory the program /progMode
	int isMonadic;			// -1|0|1 /parse
	int startCount;			// starting decCount /execProg
	int endCore;			// the program limit /progMode
	int argCount;			// code of return value /execProg 
	int leftNum;			// 0|1 /parse
	int rightNum;			// 0..10 /parse
	int labelTOS;
	int ln[COMPSTR];
	int hasLabel;
	char arg[NAMESTR];		// contains return variable name /parse
	char left[NAMESTR];		// contains left variable name /parse
	char rights[NAMESTR];		// contains right variable(s) name(s)
	char locals[COMPSTR];		// contains local variable(s) name(s)
	char label[COMPSTR][NAMESTR];
	double data[COMPSTR];		// label treatment
	double progbeginS;		// for timing 
};
typedef struct t_program TProg;

struct t_channel {
	FILE *stream;
	char name[COMPSTR];
	int ch;
	int isOpen;
	int wayout; // VREAD | VWRITE
};
typedef struct t_channel TFile;

/* Functions prototypes (decidedly don't change!)*/
int parse(int i);
int executeSystemCommand(char *y);
void assign(TDeclare *res);
void analyse(TDeclare *res);
void expression(TDeclare *res);
void copyArray(TDeclare *to, TDeclare from);
double getArrayVal(TDeclare var, int m, int n) ;
void setArrayVal(TDeclare var, int m, int n, double val);
void printArray(char **s, TDeclare var);
void outArray(TDeclare var);
void execProg(TDeclare *res, int from, TDeclare val1, TDeclare val2, int code);
void dimArray(TDeclare *var, int S);
void setArray(TDeclare *var);
/* aid to expression */
double do_mscalar(char op, double s);
double do_dscalar(char op, double s1, double s2);
void do_scalar_dyadic(TDeclare *res, char op, TDeclare add1, TDeclare add2);
void do_scalar_monadic(TDeclare *res, char op, TDeclare add1);
void do_dyadic(TDeclare *var, char p, TDeclare v1, TDeclare v2, int code);
void do_monadic(TDeclare *var, char p, TDeclare v1, int code);
void do_square_invert(TDeclare *varr, TDeclare var1);
double do_trig(int c, double a);
/* specifics */
void d_display(TDeclare *res, TDeclare val1, TDeclare val2);
int f_display(char **foutput, TDeclare val1, TDeclare val2);
void d_decode(TDeclare *res, TDeclare val1, TDeclare val2);
void d_inner(TDeclare *res, TDeclare val1, TDeclare val2, char leftop, char rightop);
void progMode(int i, char *u);
void eraseDEC(TDeclare *res);
void vectorize(TDeclare *res, int col);
char isop(char *p, int *adv);
void makeSpaces(char *s, int n);
void makeVector(TDeclare *s);
char numformat[COMPSTR];
char mnumformat[COMPSTR];
int isAnAssignment(char *s);
double min(double n1, double n2);
double max(double n1, double n2);
double resi(double n1, double n2);
double combi(double n1, double n2);
double identity(char op);
int load(char *filestr, int pos);
int save(char *filestr, int pos);
double sign(double val);
double ceiling(double val);
double floor(double val);
int do_export(char *filestr, int pos, char *header, int ds);
int type(char *filestr);
int getHeader(char *p, char **newp, int uProgCount) ;
void m_processMatrix(TDeclare *res, TDeclare A1, int dir) ;
int relation(double val1, double val2) ;
char efilename[COMPSTR];
int transparent=FALSE;
void emit(int val, char *format, ...);
void do_square_invert(TDeclare *varr, TDeclare var1);
int isEqual(int row, int col, double A[row+1][col+1], double B[row+1][col+1]);
void r_square_invert(int n, double x[n+1][n+1], double a[n+1][n+1], double *detValue);
void k_mat_tra(int row, int col, double AT[col+1][row+1], double A[row+1][col+1]);
void mat_mul(int n, double res[n+1][n+1], double left[n+1][n+1], double right[n+1][n+1]);
void print(int c, int d, double n[c+1][d+1]);
void k_mat_mul(int row1, int col1, int col2, double res[row1+1][col2+1], double val1[row1+1][col1+1], double val2[col1+1][col2+1]);
void instMat(TDeclare *res, int type, int row, int col, double mat[row+1][col+1]);
void instVec(TDeclare *res, int type, int col, double vec[col+1]);
void instScalar(TDeclare *res, double val);
void vrint(int c, int n[c+1]);
void printv(int c, double n[c+1]);
void takeRowCol(TDeclare base, TDeclare *row, TDeclare *col);
void subArray(TDeclare *res, TDeclare base, TDeclare I, TDeclare J);
void do_faddeev(int n, double A[n+1][n+1], double AI[n+1][n+1], double coeff[n+2]);
double sign(double val);
char *findSep(char *s);
int do_qrd(int row, int col, double A[row+1][col+1], double Q[row+1][col+1], double R[col+1][col+1]);
void do_svd(int row, int col, double A[row+1][col+1], double Q2[row+1][row+1], double SIGMA[row+1][col+1], double Q1[col+1][col+1], int *first);
int ben_diff(int n, int m, double S[n+1][m+1], double T[n+1][m+1]);
void do_echelon(int row, int col, double val[row+1][col+1], double matrix[row+1][col+1]);
int do_rref(int row, int col, double val[row+1][col+1], double matrix[row+1][col+1], int dir);
void do_eigen(int n, double M[n+1][n+1], double P[n+1][n+1], double J[n+1][n+1], double U[n+1][n+1], double Q[n+1][n+1], int *iter);
void d_matdivision(TDeclare *res, TDeclare val1, TDeclare val2);
void do_hess(int n, double A[n+1][n+1], double H[n+1][n+1], double Q[n+1][n+1]);
void do_polar(int row, int col, double A[row+1][col+1], double U[row+1][row+1], double P[col+1][col+1], int *first);
void printTests(FILE *fs);

/* OLD MATERIAL */
int END(int s);
int LOAD(char **m, int from, int labelfrom, char *f);
int eval_options(int a, char **b);
char *strcasestr_oq(char *pl, char *pr);
char *strcasechr_oq(char *pl, char pr);
char *strcasestr_(char *big, char *little);
int strncasecmp_(char *d, char *s, int N);
int strcomp(char *d, char *s);
char *strncpy_(char *dst, char *src, int dw);
char *strncat_(char *dst, char *src, int dw);
char *chrcat_(char *dst, int c, int dw);
int fgets_(char *s, int n, FILE *f);
int checkBal(char *str);
int string(char *mypad) ;
int searchDEC(char *p, int s);
void declare(int pos, char *name, int type, int form, int col, int row);
void set(TDeclare *v, int type, int form, int row, int col);
char *getMonthString(void) ;
//char *spaces(int v);
int exec(char *lpc) ;
void data(int ns, int i);
char *code(void);
int getDay(void) ;
int getWDay(void) ;
int getHour(void) ;
int getMin(void) ;
int getMonth(void) ;
int getSec(void) ;
int getYear(void) ;
double getNum(char *p, char **newp) ;
struct tm *getTime(void) ;
void turnToUpper(char *str) ;
void sigint(int sig);
void erase(char *d, int s);
void memcpy_(void *dst, void *src, int size);
char *define(int n, char *c, int *f);
/* Error messaging system */
int perror_(int line, int errNum, int l, ...) ;
/* Info messaging collection */
void printConditions(void) ;
void printExistence(int i,int c);
void printHelp(int i) ;
void printVersion(int i) ;
void printHelpBanner(void) ;
void printWarranty(void) ;
void changeMinus(char *str) ;
void m_transpose(TDeclare *res, TDeclare val) ;
void emptySlot(int np) ;
int isin(int item, TDeclare vect) ;
int memStatus(void);
void skipLabel(void) ;
void m_invert(TDeclare *res, TDeclare val) ;
void callFlags(void);
void callTime(void);
void reset(int l);
void setIBeam(int code, int var);
char *strstr_oq(char *pl, char *pr);
char *strstr_o2q(char *pl, char *pr);

/* Inspective macros (imperatively don't change!) */
#define isnum(p)        (isdigit(*(p)) || *(p)=='.')
#define ismonadic(p)	(*(p)=='+' || *(p)=='-' || *(p)=='x' || *(p)=='%' || *(p)=='{' || *(p)=='}' || *(p)=='*' || *(p)=='&' || *(p)=='|' || *(p)=='!' || *(p)=='?' || *(p)=='o' || *(p)=='~')
#define isflot(p)	(((*(p)=='+' || *(p)=='_') && isdigit(*((p)+1))) || ((*(p)=='+' || *(p)=='_') && *((p)+1)=='.' && isdigit(*((p)+2))) || (*(p)=='.' && isdigit(*((p)+1))) || isdigit(*(p)))
#define islogic(p) 	((p)=='^' || (p)=='v' || (p)=='u' || (p)=='y' || (p)=='<' || (p)=='j' || (p)=='=' || (p)=='k' || (p)=='>' || (p)=='#')
#define checkStop       if (isError || isInterrupt) return
#define checkClose 	if (*a==']') a++; else {emit(1,"%s\n",error[18]);a=NULL;continue;}

/* Lotsa global variables! */
/* System variables (Don't change at all!) */
char *BASETOT;
int isError=FALSE;
char username[COMPSTR];
char resName[NAMESTR];
char args[COMPSTR];
int isArg=FALSE;
int isExtTracing=FALSE;
int isExtStopping=FALSE;
char *describe;
int avoidPrintResult=FALSE;
int isProgram=FALSE;
int isExtProgram=FALSE;
char progName[COMPSTR];
char prompt[COMPSTR];
char charprompt[COMPSTR];
int lastProgram=0;
char prevName[COMPSTR];
int self=0;
int recursionLimit=0;
int selfReached=0;
double detValue;
int isDeleteScriptFile=FALSE;
int isDebug=FALSE;
int isScript=FALSE;
int isExtraSpace=FALSE;
int reStart=FALSE;
int indexOrigin=1;
//int isAssign=FALSE;
int isExp=0;
int isHex=0;
int isSuspStop=FALSE;
int noCall=FALSE;
int offset=0;
double timiStart=0;
int isComplexWarning=FALSE;

/* quad printing*/
int parTOS=1;
char parstack[PARSTACK][COMPSTR];
int noParCall=FALSE;

/* random generation */
int randSeed=7139;
int randDivi=24424;
double getRandom(void);

/* system */
int isInterrupt=FALSE;
char *MYPAD;
//TDeclare RESPAD;
char filename[COMPSTR];
char scriptname[COMPSTR];
FILE *FS=NULL;
int isPrintSourceCode=FALSE;
struct winsize wsz;
int sysWidth=80;
int properInv=0;
char properInvStr[COMPSTR];
int iterations=0;
/* System strings */
static char *month[]=
{"", "JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC" };
char freezefile[COMPSTR];
int I_access=0;
int globRet=0;

/* findDEC aid
 * _len holds complete name length
 * _logic is true if last operator was a logic operator  */
int _len,_logic;

/* Memory system */
char *p;
int opturn=0;	// don't change!
int isCompleteUnload=FALSE;
int procCode=EXIT_SUCCESS;
struct rlimit newStackSize;
struct rlimit currStackSize;

/* DECLARE management
 * vn holds the DECLARE definitions in a proper struct
 * decCount holds current number of declared variables */
TDeclare vn[COMPVAR];
int decCount=0;
int maxDec=0;

/* PROG management
 * pn holds the TProg definitions in a proper struct
 * progCount holds current number of user programs */
TProg pn[COMPSTR];
int progCount=0;
int maxProg=0;

/* Timing variables
 * tv is used for time calculations
 * beginS is calculated at start for the TIM() function and the timer
 * now contains seed for current number generator */
struct timeval tv;
double beginS=0.0, endS=0.0;
double progbeginS=0.0;
double totalTime=0.0;
long long int beginMS=0, endMS=0;
int isTiming=FALSE;

/* program flow variables */
int backStore[COMPSTR];
int backCode[COMPSTR];
int backNumber[COMPSTR];
int isResAssign[COMPSTR];
int resAs[COMPSTR];
int resVar[COMPSTR];
int backTOS=0;
int backBackTOS=0;
TDeclare backLeft[COMPSTR], backRights[COMPSTR];
int progLine=0;
int fromArrow=FALSE;
char *dsp;

/* tracing */
int isTracing=FALSE;
TDeclare traceV;
char traceName[NAMESTR];

/* stopping */
int isStopping=FALSE;
TDeclare stopV;
char stopName[NAMESTR];

/* option --apl */
char aplline[COMPSTR];
int isAplLine=FALSE;
char currentWorkspaceName[NAMESTR];
char postline[COMPSTR];
int isPostLine=FALSE;

/* service workspace vars */
int Wdigit=0;
int Wwidth=0;
int Wseed=0;
int Wchange=FALSE;
double fuzzValue=0.0;
int Wfuzz=0;
double Wcomp=0;
#define WLow  308
#define WBond  77
#define WMant  52
#define WAcc   16
#define WHigh   1
int Wdiv=0;
int Winv=0;
char wname[NAMESTR];
int wasLoadWorkspaceOK=TRUE;
int isClean=FALSE;
int isSilent=FALSE;
int globCount=0;
char basetot[COMPSTR];

/* I/O */
#define STREAMS 12
int fileTOS=0;
TFile channel[STREAMS+1];

/* excecution operator messages suppression */
int suppressMessage=FALSE;
int actOnSuppressMessage=FALSE;
char Toffset[200000];
/* end of apple.h */


