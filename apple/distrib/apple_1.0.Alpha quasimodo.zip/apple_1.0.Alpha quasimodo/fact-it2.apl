\/ Z<-FAC N;I
Z<-N
L1:N<-N-1
->0xiN<2
Z<-ZxN
->L1
\/

