/* custom.h
 * Copyleft (C) 2009-2018 Antonio Maschio
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 07 agosto 2021
 *
 * This is apple, an APL engine written in c99 for
 * the UNIX world. You must have gcc 4.X to compile (though maybe 3.X may go).
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation, either version 3 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

/* COMPVAR
 * This definition sets the base dimension of contemporarily
 * existence of variables in the same workspace */
#define COMPVAR 32769			// apple's limit for variables number

/* COMPSTR 
 * This definition sets the base dimension 
 * Note: the vectors and matrices have dynamic length
 * but this is used for the base dimension, and also for file name lengths 
 * and for lines read from files; also it sets the base dimensions for 
 * the admissible program lines */
#define COMPSTR 513			// apple's limit for string and array size

/* NAMSETR
 * This definition sets the name length 
 * It is set currently to 15 characters */
#define NAMESTR 16			// apple's limit for names

/* PARLIMIT
 * This definition sets the number of parenthesis limit for the 
 * quad printing */
#define PARLIMIT 16			// apple's limit for parenthesis

/* OUTSTR
 * This definition sets the output limit in composing an output
 * (vectors and matrices are printed as a whole string) */
#define OUTSTR 65537			// apple's limit for output 

/* RECURS 
 * This definition sets the recursion level in MB */
#define RECURS 24

/* EDIT 
 * This definition sets the preferred editor */
#define VEDIT "vim"

/* SHELL 
 * This definition sets the preferred shell */
#define VSHELL "bash"

