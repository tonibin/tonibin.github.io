/* errors.h 
 * Copyleft (C) 2009-2018 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 05 agosto 2021
 *
 * This is apple, an APL engine written in c99 for
 * the UNIX world. You must have gcc 4.X to compile (though maybe 3.X may go).
 * 
 * This program is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) 
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with 
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

char* error[]= {

/* SYSTEM ERRORS 
 * used by perror_ */
/* 0 */	"",
/* 1 */	"CHARACTER ERROR",
/* 2 */	"VALUE ERROR",
/* 3 */	"DOMAIN ERROR",
/* 4 */	"SYNTAX ERROR",
/* 5 */	"RANK ERROR",
/* 6 */	"LENGTH ERROR",
/* 7 */	"DEFN ERROR",
/* 8 */	"LABEL ERROR",
/* 9 */	"SYSTEM ERROR",
/* 10 */ "FN SPACE FULL ERROR",
/* 11 */ "INDEX ERROR",
/* 12 */ "WS FULL ERROR",
/* 13 */ "ID ERROR",
/* 14 */ "NOT WITH OPEN DEFINITION",
/* 15 */ "FN RECURSION LIMIT ERROR",
/* 16 */ "NON-STANDARD ASCII CHARACTER ERROR",
/* 17 */ "AXIS ERROR",
/* 18 */ "EDITING SYNTAX ERROR",
/* 19 */ "QUAD PRINT ERROR",
/* 20 */ "Cannot open file %s\n",
/* 21 */ "File %s not found\n",
/* 22 */ "File %s is probably not a textual file. Force opening [y/n]?\n",
/* 23 */ "Cannot interpret this APL file.Terminating.\n",
/* 24 */ "Unknown double dash option %s.Terminating.\n",
/* 25 */ "Unknown dash option -%c.Terminating.\n",
/* 26 */ "File %s is not an APL file.\n",
/* 27 */ "UNBALANCED BRACKETS",
/* 28 */ "NO PENDENT PROGRAM ERROR",
/* 29 */ "WRONG WRITE SPECIFIER ERROR",
/* 30 */ "CANNOT OPEN THIS FILE",
/* 31 */ "TOO MUCH OPENED FILES ERROR",
/* 32 */ "FILE ALREADY OPENED ERROR",
/* 33 */ "ERROR, CANNOT OPEN THIS FILE FOR READ",
/* 34 */ "ERROR, CANNOT OPEN THIS FILE FOR WRITE",
/* 35 */ "FILE NOT ALREADY OPEN ERROR",
/* 36 */ "ERROR, TRYING TO READ FROM A WRITE-FILE",
/* 37 */ "CORRUPTED DATA ERROR",
/* 38 */ "ERROR, TRYING TO WRITE TO A READ-FILE",
/* 39 */ "ERROR, FILE CONTROLS AVAILABLE ONLY IN READ MODE",
/* 40 */ "ILLEGAL FILE POINTER ERROR",
/* 41 */ "WARNING: CANNOT CALCULATE THIS EIGENSPACE",
/* 42 */ "WARNING: THIS EIGENSPACE HAS COMPLEX RESULTS",
/* 43 */ "NON-SQUARE MATRIX ERROR",
/* 44 */ "NON-SYMMETRIC MATRIX ERROR",
/* 45 */ "NON-POSITIVE-DEFINITE MATRIX ERROR",
/* L+1 */ ""					/* last + 1 */
};

#define ERRLIM 46				/* L + 1 */

