\/ Z<-FAC N;I
Z<-1
I<-0
L1:I<-I+1
->0xiI>N
Z<-ZxI
->L1
\/

