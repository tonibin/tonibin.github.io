" Vim syntax file
" Language:     APL (apple version)
" Creator:      Antonio Maschio <ing.antonio.maschio@gmail.com>
" Maintainer:   Antonio Maschio <ing.antonio.maschio@gmail.com>
" Update: 	April 13, 2022

" For version 5.x: Clear all syntax items
" For version 6.x: Quit when a syntax file was already loaded
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif
set ts=4
" Operators
syn keyword     appleScalarOp     + - x % { } \* \| ! ^ v > < = # & ~  o contained
" General entities: don't change this order
syn keyword     appleTodo contained	TODO FIXME XXX
syn match       appleNumber       "[_]*\d*\(\.\d*\)*\([eE]\([+-]\)*\d*\)*" 
syn match       appleConstant     "\u\(\u*\d*\)*"
syn match       appleLabel        "^\u\(\u*\d*\)*:"
syn match       appleSpecChar     display contained "\\a"
syn match       appleSpecChar     display contained "\\b"
syn match       appleSpecChar     display contained "\\f"
syn match       appleSpecChar     display contained "\\n"
syn match       appleSpecChar     display contained "\\r"
syn match       appleSpecChar     display contained "\\t"
syn match       appleSpecChar     display contained "\\v"
syn match       appleSpecChar     display contained "\\\\"
syn region      appleString       start=+"+ end=+"+ contains=appleSpecChar oneline
syn region      appleString       start=+'+ end=+'+  
syn region      appleComment      start=+co+ end=+$+ contains=appleTODO
syn match       appleGoto         "->\s*\(\u\(\u*\d*\)\)*"
syn match       appleCommand      "^)\s*\u*.*$"
syn match       appleCommand      "^]\s*\u*.*$"

" Define the default highlighting.
" For version 5.7 and earlier: only when not done already
" For version 5.8 and later: only when an item doesn't have highlighting yet
if version >= 508 || !exists("did_apple_syntax_inits")
command -nargs=+ HiLink hi link <args>

  HiLink appleTodo            Todo
  HiLink appleNumber          Type
  HiLink appleConstant        Conditional
  HiLink appleScalarOp        Conditional
  HiLink appleLabel           Label
  HiLink appleSpecChar        SpecialChar
  HiLink appleString          String
  HiLink appleComment         Comment
  HiLink appleGoto            Conditional
  HiLink appleCommand         Label

  delcommand HiLink
endif

let b:current_syntax = "apple"
