\/ W<-NULL A;M;N
M<-(pA)[1]
N<-(pA)[2]
W<-(M,N)p0
\/
