\/ Z<-KOND M;U;V;SIGMA;V1;V2
]IMPORT libs/SVD.apl
->INFIxi(dM)=0
Z<-SVD M
V1<-(}/1 1\oSIGMA)
V2<-({/1 1\oSIGMA)
Z<-V1%V2
->0
INFI:Z<-(+/1 1\oM)%1E_308
\/


