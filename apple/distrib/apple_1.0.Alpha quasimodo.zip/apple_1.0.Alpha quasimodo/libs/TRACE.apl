\/ Z<-TRACE M;I;N
co Calculate the trace of a matrix 
co TRACE <arg>
co arg: M
co return Z
Z<-+/1 1\oM
\/


