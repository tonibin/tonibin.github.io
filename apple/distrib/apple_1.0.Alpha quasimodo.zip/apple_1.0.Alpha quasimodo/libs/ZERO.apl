\/Z<-T1 ZERO T2
co T1 ZERO T2
co Arg: T1 T2
co Return a square zero matrix with dimensions:
co T1 rows and T2 columns
Z<-((T1),(T2))p0
\/
