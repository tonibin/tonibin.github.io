\/ Z<-NORM M;N;I
co NORM - Calculate one-dimensional item's Frobenius norm 
co usage: NORM M
co arg. M
co return N
->LMxi(ppM)=2
->LExi(ppM)=0
co Vector norm
Z<-0
I<-1
N<-pM
L1:Z<-Z+M[I]xM[I]
I<-I+1
->L1xiI<=N
Z<-Z*.5
->0
co One-column matrix norm
LM:
->LExi(pM)[2]#1
Z<-0
I<-1
N<-(pM)[1]
L2:Z<-Z+M[I;1]xM[I;1]
I<-I+1
->L2xiI<=N
Z<-Z*.5
->0
LE:Z<-0
'ERROR: NOT A VECTOR NOR A ONE-COLUMN MATRIX!'
\/

