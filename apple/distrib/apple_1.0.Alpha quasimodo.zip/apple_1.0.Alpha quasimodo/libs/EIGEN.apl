\/Z<- JO EIGEN A;N;I;COUNT;V1;V2;M2;Q;R;K;E;T;I;V;MI
controls
co ->LExi(dA)=0
co: inclusion
]IMPORT libs/EYE.apl
]IMPORT libs/DIFF.apl
]IMPORT libs/ZERO.apl
]IMPORT libs/NORM.apl
N<-(pA)[1]
I<-0
J<-N ZERO N
P<-N ZERO N
E<-EYE N
T<-i0
co cycle over all columns
LI:I<-I+1
	COUNT<-0
	MI<-1000xJO[I;I]
	K<-|%|(A-(ExJO[I;I]))
	V2<-\oK[;I]%(NORM K[;I])
	co Releigh iteration
	CYC:V1<-V2
		COUNT<-COUNT+1
		V2<-(K+.xV1)%(NORM (K+.xV1))
		MI<-((\oV2)+.xA+.xV2)%((\oV2)+.xV2)
		->L9xiCOUNT>1000
	->CYCxi(V1 DIFF V2)>0
	L9:P[;I]<-,V2
	J[I;I]<-MI
	T<-T,COUNT
->LIxiI<N
co order eigenvalues
I<-1
V<-i0
LR:V<-V,J[I;I]
	I<-I+1
->LRxiI<=N
V1<-\v/V
V<-V[V1]
co store in J
I<-1
LG:J[I;I]<-V[I]
	I<-I+1
->LGxiI<=N
comment normalize eigenvectors
I<-1
L2:P[;I]<-P[;I]%P[N;I]
	I<-I+1
->L2xiI<=N
Z<-T
co reorder eigenvectors
P<-P[;V1]
->0
LE:'ONLY INVERTIBLE SQUARE MATRICES HERE!'
Z<-0
\/



