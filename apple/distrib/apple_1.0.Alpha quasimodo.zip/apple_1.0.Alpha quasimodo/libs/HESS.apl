\/ HESS A;N;K;J;R;U;V;W1;W2;W
controls
->LExi(ppA)#2
->LExi(pA)[1]#(pA)[2]
co import aid-functions
]IMPORT libs/NORM
]IMPORT libs/ZERO
]IMPORT libs/EYE
construct setup
N<-(pA)[1]
Q<-EYE N
H<-A
commence cycle over H
K<-0
LK:K<-K+1
	R<-H[K+i(N-K);K]
	U<-\o(N-K) ZERO 1
	U[1]<- -((x(R[1])x(R[1]#0))+(R[1]=0))x((R+.xR)*.5)
	V<-R-U
	V<-V%NORM V
	W1<-((EYE K),(K ZERO (N-K)))
	W2<-(((N-K) ZERO K),(EYE (N-K))-2xV@.xV)
	W<-W1,[1]W2
	H<-W+.xH+.x\oW
	Q<-Q+.x\oW
->LKxiK<N-2
commence erasure over items that must be zero
comment: the algorithm makes actually them quasi-zero
J<-0
LJ:J<-J+1
	H[(J+1)+i(N-J+1);J]<-(i(N-J+1))-i(N-J+1)
->LJxiJ<N-2
->0
LE:'ONLY SQUARE MATRICES HERE.'
H<-i0
\/

DHESS<-"\nTHE FUNCTION  HESS  PRODUCES  THE  HESSEMBERG  DECOMPOSITION\nOF THE SQUARE MATRIX GIVEN AS ARGUMENT  -  USES: NORM, ZERO,\nEYE  -  SETS  H  AND  Q,  WHERE H IS THE  HESSENBERG MATRIX,\nAND Q IS AN  ORTHONORMAL MATRIX  THAT REBUILDS  THE MATRIX A\nTHROUGH THE EQUATION A<-Q+.xH+.x\oQ\n\nBASED ON THE ALGORITHM FOUND HERE:\nhttps://mathsfromnothing.au/hessenberg-decomposition/?i=1"

