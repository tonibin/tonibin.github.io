\/ Z<-SVD A;M;N;P;R;Q;QP;SIG2;B;B1;D;D1;COUNT;T;M1;N1;S;ISIGMA
->LExi(ppA)#2
]IMPORT libs/QRD
]IMPORT libs/DIFF
]IMPORT libs/IDEN
]IMPORT libs/EIGEN
Z<-0
co case of M>=N
M<-(pA)[1] ; N<-(pA)[2] ; T<-0
->SKIP0xiM>=N
co case of M<N
V<-M ; M<-N ; N<-V ; A<-\oA ; T<-1
SKIP0:SIGMA<-((M),(N))p0
co QR algorithm for V
COUNT<-0
B1<-(\oA)+.xA
QP<-IDEN B1
LC1:B<-B1
	QRD B
	B1<-R+.xQ
	QP<-QP+.xQ
	COUNT<-COUNT+1
	->LG1xiCOUNT>10000
->LC1xi(B1 DIFF B)>0
LG1:Z<-COUNT
co ATTRIBUTION FOR SIGMA
S<-1 1\oB1
S<-(|S)*0.5
->SKIP1xiM=N
M1<-((x(M-N))x(M-N))
N1<-(Nx(M>N))+(Mx(M<N))
SIG2<-(M1,N1)p0
SIGMA<-((N1,N1)pS,(N1,N1)p0),[1]SIG2
->SKIP2
SKIP1:SIGMA<-(M,N)pS,(M,N)p0
co ATTRIBUTION FOR V
SKIP2:V<-QP
co U is derived
S<-1 1\oSIGMA
ISIGMA<-\oSIGMA
D<-0
LC2:D<-D+1
ISIGMA[D;D]<-((S[D]=0)x0)+(S[D]#0)x%S[D]
->LC2xiD<M{N
U<-A+.xV+.xISIGMA
->ENDxiT=0
co calculate re-attributions for the case M<N
co Q is used as an aid variable
Q<-V
V<-U
U<-Q
SIGMA<-\oSIGMA
co reduce to rank-size
END:
M<-(pA)[1]
N<-(pA)[2]
R<-r[2]A
U<-(M,R)/|\U
V<-(N,R)/|\V
SIGMA<-(R,R)/|\SIGMA
->0
LE:'ARGUMENT IS NOT A MATRIX'
Z<-0
\/

