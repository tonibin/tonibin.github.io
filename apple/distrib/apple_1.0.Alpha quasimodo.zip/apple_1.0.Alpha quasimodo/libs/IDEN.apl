\/Z<-IDEN A;N;N1
co Return identity matrix based on A columns
co Works also on scalars and vectors
->LSxi(ppA)=0
->LVxi(ppA)=1
co Matrices
N<-(pA)[2]
N1<-iN
Z<-N1@.=N1
->0
co Scalars
LS:Z<-1.0
->0
co Vectors
LV:Z<-((pA)[1])p0
Z[1]<-1.0
\/

