\/ PRIMES
P<-1+T<-1
TEST:->(END<=p,P)/PRINT
ADD:->(v/0=P|T<-T+2)/ADD
P<-P,T
->TEST
PRINT: P
\/
