\/S<-N FPLOT F;GDX;GDY;M;XMAX;XMIN;YMAX;YMIN;XD;YD;C;X;PX;PY;LX;LY
comment general parameters setup; search for abscissa max and min
GDX<-N[2]
GDY<-N[1]-1
XMIN<-N[3]
XMAX<-N[4]
XD<-|XMAX-XMIN
comment build matrix M
M<-((GDX+1),2)p0.0
C<-0
X<-XMIN-XD%GDX
CALC:C<-C+1
X<-X+XD%GDX
M[C;1]<-X
M[C;2]<-eF
->CALCxiC<=GDX
co: initialize; search for ordinate max and min
C<-1+YMAX<-YMIN<-0
BAS:C<-C+1
LX<-}/M[;2]
LY<-{/M[;2]
YMAX<-YMAX}LX
YMIN<-YMIN{LY
->BASxiC<GDX
YD<-|YMAX-YMIN
co: create grid and put markers
S<-((GDY+3),(GDX+8))p' '
co: put ordinate markers
S[;7]<-(GDY+3)p'|'
S[;GDX+7]<-(GDY+3)p'|'
PY<-YMAX
LY<-0
LAB1:S[LY+1;i5]<-5 2fPY
S[LY+1;7]<-'+'
LY<-LY+GDY%4
PY<-PY-YD%4
->LAB1xiLY<=GDY
co: put abscissa markers
S[GDY+2;i(GDX+7)]<-(GDX+7)p'-'
PX<-XMIN
LX<-4
LAB2:S[GDY+3;LX+i5]<-5 2fPX
S[GDY+2;LX+3]<-'+'
LX<-LX+GDX%6
PX<-PX+XD%6
->LAB2xiLX<=GDX
S[GDY+3;(GDX+3)+i5]<-5 2fXMAX
S[GDY+2;GDX+7]<-'+'
co: cycle on all items of column 2
X<-0
DAT:X<-X+1
co: map single points to 
PX<-{7+(M[X;1]-XMIN)xGDX%XD
PY<-{1+GDY-(M[X;2]-YMIN)xGDY%YD
co: plot on the result string (in inverse coordinates,
co: because we want the abscissas on the horizontal
co: part of the scheme, and the ordinates on height)
S[PY;PX]<-'o'
->DATxiX<GDX
\/

DFPLOT<-"FPLOT IS A PROGRAM FOR PLOTTING A FUNCTION CONTAINED IN THE RIGHT ARGUMENT;\nTHE FUNCTION WILL BE REPRESENTED WITH A THE SYMBOL o.\nTHE LEFT ARGUMENT IS A VECTOR WITH FOUR ELEMENTS, THE FIRST BEING THE ORDINATE\nDIMENSION AND THE SECOND THE ABSCISSA DIMENSION OF THE GRAPHIC, THE THIRD THE X LOW EXTREME OF THE FUNCTION AND THE FOURTH THE X HIGH EXTREME OF THE FUNCTION."

