\/Z<-EYE N;N1
co Return an identity matrix with dimensions N
N1<-iN
Z<-N1@.=N1
\/
