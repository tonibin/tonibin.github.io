\/S<-N PLOT M;GDX;GDY;XMAX;XMIN;YMAX;YMIN;XD;YD;C;X;PX;PY;SYM;DIM;COLS;LX;LY
comment general parameters setup; search for abscissa max and min
SYM<-'_XYZWABEHPSTO'
DIM<-(pM)[1]
COLS<-((pM)[2])
->ERRxiCOLS>12
GDX<-N[2]
GDY<-N[1]-1
XMAX<-}/M[;1]
XMIN<-{/M[;1]
XD<-|XMAX-XMIN
co: initialize; search for ordinate max and min
C<-1+YMAX<-YMIN<-0
BAS:C<-C+1
LX<-}/M[;C]
LY<-{/M[;C]
YMAX<-YMAX}LX
YMIN<-YMIN{LY
->BASxiC<COLS
YD<-|YMAX-YMIN
co: create grid wider for the markers
S<-((GDY+3),(GDX+8))p' '
co: put ordinate markers
PY<-YMAX
LY<-0
LAB1:S[LY+1;i5]<-5 2fPY
LY<-LY+GDY%4
PY<-PY-YD%4
->LAB1xiLY<=GDY
S[;7]<-(GDY+3)p'|'
S[;GDX+7]<-(GDY+3)p'|'
co: put abscissa markers
S[GDY+2;i(GDX+7)]<-(GDX+7)p'-'
PX<-XMIN
LX<-4
LAB2:S[GDY+3;LX+i5]<-5 2fPX
S[GDY+2;LX+3]<-'+'
LX<-LX+GDX%6
PX<-PX+XD%6
->LAB2xiLX<=GDX
S[GDY+3;(GDX+3)+i5]<-5 2fXMAX
S[GDY+2;GDX+7]<-'+'
co: outer cycle on all columns from 2nd
C<-COLS+1
CYC:C<-C-1
co: inner cycle on all items of current column
X<-0
DAT:X<-X+1
co: map single points to grid 
PX<-{7+(M[X;1]-XMIN)xGDX%XD
PY<-{1+GDY-(M[X;C]-YMIN)xGDY%YD
co: plot on the result string (in inverse coordinates,
co: because we want the abscissas on the horizontal
co: part of the scheme, and the ordinates on height)
S[PY;PX]<-SYM[C]
->DATxiX<=DIM-1
->CYCxiC>2
->0
ERR:S<-"TOO MUCH COLUMNS FOR DATA"
\/


DPLOT<-"PLOT IS A PROGRAM FOR PLOTTING DATA CONTAINED IN THE RIGHT ARGUMENT,\nWITH ABSCISSA VALUES CONTAINED IN COLUMN ONE; THE FOLLOWING COLUMNS,\nUP TO 12 (THAT IS THE ARGUMENT MAY HAVE ANY NUMBER OF LINES AND UP\nTO 13 COLUMNS IN TOTAL) CONTAIN THE ORDINATE VALUES, ONE SERIES FOR EACH COLUMN.\nEACH COLUMN WILL BE REPRESENTED WITH A DIFFERENT LETTER SYMBOL.\nTHE LEFT ARGUMENT IS A VECTOR WITH TWO ELEMENTS, THE FIRST BEING THE ORDINATE\nDIMENSION AND THE SECOND THE ABSCISSA DIMENSION OF THE GRAPHIC."
