\/ Z<-JORD A;A1;Q;R;N;QP;I;W;COUNT;V;V1
controls
->LExi(pA)[1]#(pA)[2]
co import
]IMPORT libs/QRD.apl
]IMPORT libs/IDEN.apl
]IMPORT libs/DIFF.apl
]IMPORT libs/EIGEN.apl
N<-(pA)[1]
A1<-A
QP<-IDEN A
COUNT<-0
co QR algorithm cycle
LC:A<-A1
	QRD A
	A1<-R+.xQ
	QP<-QP+.xQ
	COUNT<-COUNT+1
	->LGxiCOUNT>10000
->LCxi(A1 DIFF A)>0
co set eigenvectors matrix P
LG:P<-QP
Z<-COUNT
co sort eigenvalues
V<-1 1\oA1
V1<-\v/V
V<-V[V1]
P<-P[;V1]
co set eigenvalues matrix J
J<-(N,N)p0
J<-(0,iN-1)o|J
J[;1]<-V
J<-(0,-iN-1)o|J
co normalize P
I<-0
L3:I<-I+1
	P[;I]<-P[;I]%P[N;I]
->L3xiI<N
->0
LE:'ONLY SQUARE MATRICES HERE!'
COU<-0
\/
DJORD<-"\nTHE FUNCTION  JORD PRODUCES THE  JORDAN DECOMPOSITION OF THE\nMATRIX  ARGUMENT  SUPPLIED,  EMPLOYING   THE  QR  ALGORITHM.\nRETURN VALUE:  THE NUMBER OF ITERATIONS OF THE QR ALGORITHM.\nDECLARE: J AND P  (EIGENVALUES AND NORMALIZED EIGENVECTORS).\nUSING  LIBRARY  PROGRAMS:  QRD, NORM (IN QRD),  IDEN,  DIFF.\nCONTROLS: ONLY SQUARE MATRICES HERE!\nBASED ON THE ALGORITHM IN\nhttps://people.inf.ethz.ch/arbenz/ewp/lnotes/chapter4.pdf\nTRANSLATED   FOR  apple  APL   BY   ANTONIO MASCHIO  -  2024"
