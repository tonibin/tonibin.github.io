\/S<-N FPLOTL F;GDX;GDY;M;XMAX;XMIN;YMAX;YMIN;XD;YD;C;X;Y;PX;PY;LX;LY
comment general parameters setup; search for abscissa max and min
GDX<-N[2]
GDY<-N[1]-1
XMIN<-N[3]
XMAX<-N[4]
YMIN<-N[5]
YMAX<-N[6]
XD<-|XMAX-XMIN
YD<-|YMAX-YMIN
co: create grid
S<-((GDY+3),(GDX+8))p' '
co: put ordinate markers
S[;7]<-(GDY+3)p'|'
S[;GDX+7]<-(GDY+3)p'|'
PY<-YMAX
LY<-0
LAB1:S[LY+1;i5]<-5 2fPY
S[LY+1;7]<-'+'
LY<-LY+GDY%4
PY<-PY-YD%4
->LAB1xiLY<=GDY
co: put abscissa markers
S[GDY+2;i(GDX+7)]<-(GDX+7)p'-'
PX<-XMIN
LX<-4
LAB2:S[GDY+3;LX+i5]<-5 2fPX
S[GDY+2;LX+3]<-'+'
LX<-LX+GDX%6
PX<-PX+XD%6
->LAB2xiLX<=GDX
S[GDY+3;(GDX+3)+i5]<-5 2fXMAX
S[GDY+2;GDX+7]<-'+'
co: cycle on all X values
X<-XMIN-XD%GDX
DAT:X<-X+XD%GDX
Y<-eF
co: map single points to 
->DAT2xi(Y<YMIN)v(Y>YMAX)
PX<-{7+((X-XMIN)xGDX%XD)
PY<-{1+GDY-(Y-YMIN)xGDY%YD
co: plot on the result string (in inverse coordinates,
co: because we want the abscissas on the horizontal
co: part of the scheme, and the ordinates on height)
S[PY;PX]<-'o'
DAT2:->DATxiX<(XMAX-XD%GDX)
\/


DFPLOTL<-"FPLOTL IS A PROGRAM FOR PLOTTING A FUNCTION CONTAINED IN THE RIGHT ARGUMENT;\nTHE FUNCTION WILL BE REPRESENTED WITH A THE SYMBOL o.\nTHE LEFT ARGUMENT IS A VECTOR WITH SIX ELEMENTS, THE FIRST BEING THE ORDINATE\nDIMENSION, THE SECOND THE ABSCISSA DIMENSION OF THE GRAPHIC, THE THIRD THE X LOW EXTREME OF THE FUNCTION, THE FOURTH THE X HIGH EXTREME OF THE FUNCTION, THE FIFTH THE Y LOW EXTREME OF THE FUNCTION, THE SIXTH THE Y HIGH EXTREME OF THE FUNCTION"

