\/Z<-POL A;SIGMA;V;T
->LExi(ppA)#2
]IMPORT libs/SVD
Z<-SVD A
T<-U
P<-V+.xSIGMA+.x\oV
U<-T+.x\oV
->0
LE:'ONLY MATRICES HERE!
\/
