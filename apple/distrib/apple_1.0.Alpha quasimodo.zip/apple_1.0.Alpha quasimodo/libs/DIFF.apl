\/ Z<-A DIFF B;S
->LExi^/(pA)#pB
S<-+/+/((|A)-(|B))
Z<-1E_16<|S
->0
LE:'ERROR: INCOMPATIBLE ITEMS!'
Z<-0
\/
