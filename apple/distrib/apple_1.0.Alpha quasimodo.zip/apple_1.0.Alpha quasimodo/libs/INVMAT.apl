\/ Z<-INVMAT M;I;J;DET;A1;A;COUNT
->LExi(ppM)#2
DET<-dM
->BENxiDET=0
co regular invertible matrix 
co algorithm by the creators of the APL\1130
M<-\o(1 0 +pM)p(,\oM),~J<-1<iI<-1/|\pM
M<-1o|(J,1)o|[1]M-(JxM[;1])@.xM[1;]<-M[1;]%M[1;1]
->5xi0#I<-I-1
Z<-M[;i1/|\pM]
->0
co non invertible matrix
co algorithm by Ben-Israel, implemented by Antonio Maschio
BEN:A1<-(\oM)x(10*_12)
COUNT<-0
LAB:A<-A1
	A1<-(2xA)-(A+.xM+.xA)
	COUNT<-COUNT+1
	->LGxiCOUNT>100000
->LABxi(|+/,A-A1)>1E_16
LG:Z<-A1
->0
LE:'ARGUMENT IS NOT A MATRIX'
\/

DINVMAT<-"\nTHE FUNCTIONS INVMAT PRODUCE THE INVERSE OF THE MATRIX ARGUMENT;\nIF M IS INVERTIBLE, USES THE GAUSS-JORDAN ELIMINATION ALGORITHM\nTO FIND THE INVERSE, WITHOUT PIVOTING; IF M IS NOT\nINVERTIBLE USES THE BEN-ISRAEL ALGORITHM TO FIND THE PSEUDO-INVERSE."

