/* decb.c 
 * Copyleft (C) 2009-2014 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 14 December 2014
 * 
 * This is decb, a simulator of the DEC-20 BASIC language, version 17F, as 
 * reported in the January 1976 book "BASIC User's Guide" (the book, a.k.a. 
 * DEC-20-LBMAA-A-D, is a reprint of the March 1974 paper "Basic Conversational 
 * Language Manual" for version 17D, a.k.a. DEC-10-LBLMA-A-D). 
 * I'm not certain if version 17F is the one described in the LBMAA-A-D since 
 * nowhere it's written what version it is (see down for explicative notes).
 * 
 * The cited 1976 book "BASIC User's Guide" is, from now on, identified with 
 * the label LBMAA-A-D, and all the listing references point to this book
 * (unless otherwise specified).
 * 
 * All these books are downloadable for free as pdf at the great bitsavers.org.
 *
 * decb is part of the 'vibes' project, a set of programs for simulating the 
 * MONITOR, the BASIC interface and the BASIC language, for which decb is the 
 * BASIC language interpreter for programs execution (vibes is still in the
 * design phase). I have planned also Algol for this project, but I'm not sure
 * this last will be really created, because I don't know this language.
 * 
 * Byron S. Gottfried's book "Programming with BASIC", 1st edition, 1975 (in 
 * which he uses the DEC System and a BASIC version close to 17F) served as 
 * well for the making of this program (what a wonderful teacher he was!)
 *
 * Some features, not completely reported in the DEC-20 documentation, were 
 * found and tested at the Living Computer Museum (livingcomputermuseum.org)
 * on a PDP-10 (from now on this site will be identified by LCM), where version 
 * 17F runs, and herein integrated (see also the BAS17F.DOC file in the DOC: 
 * directory). One notable fact, is that the LBMAA-A-D dates back to January 
 * 1976, while the document BAS17F.DOC dates back to September 1981: how long 
 * it lasted! And the fact that the PDP-10 LCM BASIC behaves just as described 
 * in the LBMAA-A-D makes me think the latter describes version 17F.
 *
 * Beta version claim:
 * Thanks to the many who downloaded and tested decb in Gamma phase, and in 
 * particular I want to thank I.J. (he wants to remain unknown) who spent much 
 * of his time in testing and trying many decb features, founding many bugs and 
 * bad behaviours, now corrected (I hope) in this Beta version. There is still
 * much work to do for version 1.0...
 *
 * This program is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) 
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with 
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 *
 *
 * Notes about the DECSYSTEM-20 (from the LCM):
 * -------------------------------------------
 * DEC PDP-10: KL-10 (DECSYSTEM-20)
 * Introduced in 1974, it had 36-bit word size, a magnetic core (later 
 * semiconductor) memory, capacity of 32K to 4096K (4M) words, 500 nanosecond 
 * instruction cycle, 1.8 MIPS.
 * The KL-10 was a new implementation of the PDP-10 architecture intended for 
 * high-end timesharing in data centers. It was built using a fast but 
 * power-hungry technology called emitter-coupled logic (ECL), which was soon 
 * replaced by other methods of making logic components that used far less 
 * power but offered even higher speed.
 * Although the KL-10 was intended for the new TOPS-20 operating system, which 
 * provided more powerful tools for system developers, customers demanded that 
 * DEC provide a version of TOPS-10 for the DECSYSTEM-20 because of its more 
 * efficient use of resources.
 *
 * Notes about the DEC-20 BASIC implemented here:
 * ---------------------------------------------
 * The DEC-20 had a long term service, and programs written for it underwent
 * a long chain of updated versions; the BASIC environment didn't escape this.
 * Nonetheless, if you run the BASIC in the DEC-20 at the LCM, you'll discover 
 * a very advanced BASIC, with subroutines, no line numbering, many statements 
 * per line, added statements, missing DEC-10 statements and so forth. It is
 * definitely another BASIC.
 *
 * So you may ask: why decb (which is related to the DEC-20) simulates an older
 * version? Why did you make this DEC-20 simulator, while the very same 
 * computer hosts another (very advanced) BASIC?
 *
 * An answer may be this: in 1974 the BASIC on the DEC-10 was at its last 
 * revision (v. 17F) since 1968 (when the first DEC BASIC was issued); the 
 * LBLMA-A-D is an evidence of this, being last update dating back to March 
 * 1974). This BASIC was then ported to the DEC-20, initially with the same 
 * architecture (the LBMAA-A-D, which dates back to January 1976, is a reprint 
 * of the LBLMA-A-D, after all...), starting presumably from version 17F circa 
 * (this is the version simulated by decb); but the years passed, and new 
 * updates came on the DEC-20, but not on the older DEC-10; the last of these 
 * DEC-20 updates is the version you find today on the "modern" DEC-20 system 
 * at the LCM. The old DEC-10 living at the LCM, where a KL10 CPU #3530 is 
 * running a Tops-10 7.04 operating system, hosts the DEC-BASIC version closer 
 * to decb (and was the testing engine for decb, actually).
 *
 * I wrote decb according to the LBMAA-A-D directives, that match completely 
 * the BASIC running on the DEC-10, but the fact that I call it a DEC-20
 * simulator comes from the first sentence in chapter 1 of the LBMAA-A-D, 
 * where you can read: 
 *       "This chapter introduces the user to BASIC on the DECsystem-20 
 *       and to its restrictions and characteristics...."
 * It was early 1976, and times would change. It was a long time ago...
 */

#include "decb.h"	// catch-all header file

/******************************************************************************
 * The following routine define the PRAGMA instruction (decb feature)
 ******************************************************************************/


/* PRAGMA()
 * read following string and evaluate parameters, to activate available 
 * options at runtime (generally, options are a subset of all the options that 
 * can also be activated on the command line).
 * Blanks are ignored. This function is encapsulated in a REM statement, so 
 * that it can be used in any BASIC without interfering with the source.
 * Options must be followed by a specifier E or D (E for enable, D for disable)
 * under the following rules:
 * - Unrecognized options will be ignored
 * - Unrecognized specifiers will be ignored and cause option to be ignored.
 * In case option is ignored, the default behavior is not changed.
 * p points to the character after PRAGMA
 * Available options:
 * 	C enable capitalization on input 
 * 	R disable resetting of memory upon CHAIN calls 
 * Note: more options may be available in future versions.
 * Note: there must be one PRAGMA statement for each program; in case of a 
 * CHAIN set, it should be set in the first program, if option has to be used 
 * in all the programs in the CHAIN set.
 * Secondary system function. */
void PRAGMA(void) {
	pragmaCalls++;
	if (pragmaCalls>1) perror_(199,l);
	else while (*p) {
		if (*p=='C') {
			p++;
			if (*p=='E') isCap=TRUE;
			else if (*p=='D') isCap=FALSE;
		}
		if (*p=='R') {
			p++;
			if (*p=='E') isToReset=NORESET;
			else if (*p=='D') isToReset=RESET;
		}
		p++;
	}
}


/******************************************************************************
 * The following routines define the behavior of all the statements involving 
 * the USING feature as defined in the LBMAA-A-D, which were included since 
 * 1971 version VI of Dartmouth BASIC
 * Ref. LBMAA-A-D Chapter 11, "Formatted Output"
 ******************************************************************************/


/* FWRITEUSINGSHARP()
 * perform the 'PRINT/WRITE USING #N' / 'PRINT/WRITE #N, USING' statement.
 * The algorithm is: get the image and call formatAnalyzer() upon it.
 * flag: if it's TRUE, perform the PRINT USING# statement, otherwise WRITE# 
 * ch: a channel id in case command comes from FWRITESHARP()
 * p either points to the character after USING# in the first form or to the 
 *    USING string in the second form
 * Ref. LBMAA-A-D 11.1, 11-1, "The USING Statements" */
void FWRITEUSINGSHARP(int flag, int ch) {
	char image[COMPSTR];
	int jj;

	/* clean buffer */
	for (jj=0;jj<MAXSTRLEN;jj++) image[jj]='\0';	
	
	/* statement in the form PRINT/WRITE #1[,]USING<spec>,list
	 * coming from FWRITESHARP() */
	if (!strncmp(p,"USING",5)) p+=5;
	/* statement in the form PRINT/WRITE USING #1,<spec>,list
	 * coming from parse() */
	else {
		ch=(int)S();
		if (!channel[ch].isopen) perror_(80,l);
		if (ch<1 || ch>9) perror_(179,l);
		/* checking comma/colon, which must be present
		 * Ref. LBMAA-A-D 11.1, 11-1 */
		if (','!=*p && ':'!=*p) perror_(65,l,makechar(p),": OR ,");
		else p++;
	}
	
	/* if file is new, set writer mode */
	if (channel[ch].writer==NOUSE && ch>0) {
		if (flag) channel[ch].writer=VPRINT;
		else channel[ch].writer=VWRITE;
	}

	/* checking if WRITE# and PRINT# are mixed for the same channel
	 * in sequential files, which is an error 
	 * Ref. LBMAA-A-D 11.1, 11-2 */
	if (flag && channel[ch].type==SEQ) {
		if (channel[ch].writer==VWRITE) perror_(103,l);
	}
	if (!flag && channel[ch].type==SEQ) {
		if (channel[ch].writer==VPRINT) perror_(103,l);
	}

	/* string image */
	if (isanystring(p)) strncpy_(image,SS(),COMPSTR);
	/* line image */
	else if (isdigit(*p)) {
		int line=strtol(p,&p,10);
		char *mp=m[line], *im=image;
		if (!m[line]) perror_(61,l,line);
		while (isblank(*mp)) mp++;
		if (*mp!=':') perror_(55,l);
		mp++; // skip ':'
		while (*mp && *mp!='\n') *im++=*mp++;
		*im='\0';
		/* if there are no variables, but there's an image line,
		 * print it bare */
		if (!*p) {
			fprintf(stdout,"%s\n",image);
			return;
		}
	}
	else perror_(48,l);

	/* checking comma */
	if (*p!=',') perror_(65,l,makechar(p),",");
	if (image[0]) formatAnalyzer(image, ++p, !flag, ch);
	else perror_(49,l);
}


/* PRINTUSING()
 * perform the PRINT USING statement
 * The algorithm is the same of the previous function: get the image and call 
 * formatAnalyzer() upon it.
 * Note: the PRINT USING command has nothing in common with PRINT.
 * p points to the character after USING 
 * Ref. LBMAA-A-D 11.1, 11-1, "The USING Statements" */
void PRINTUSING(void) {
	char image[COMPSTR];

	/* string image */
	if (isanystring(p)) strncpy_(image,SS(),COMPSTR);
	/* line image */
	else if (isdigit(*p)) {
		int line=strtol(p,&p,10);
		char *mp=m[line], *im=image;
		if (!m[line]) perror_(61,l,line); // tested
		while (isblank(*mp)) mp++;
		if (*mp!=':') perror_(55,l); // tested 
		mp++; // skip ':'
		while (*mp && *mp!='\n') *im++=*mp++;
		*im='\0';
		/* if there are no variables, but there's an image line,
		 * print it bare */
		if (!*p) {
			fprintf(stdout,"%s\n",image);
			return;
		}
	}
	else perror_(48,l);
	if (*p!=',') perror_(65,l,makechar(p),",");
	/* delegate PRINT USING subsidiary function 
	 * Note: CONSOLE directs printing to the screen */
	if (image[0]) formatAnalyzer(image, ++p, FALSE, CONSOLE);
	/* void image line */
	else perror_(49,l);
}


/******************************************************************************
 * The following routines define the behavior of all the FILES statements as 
 * defined in the LBMAA-A-D, and which were included since 1969 version V of
 * Dartmouth BASIC
 * Ref. LBMAA-A-D Chapter 10, "Data File Capability"
 ******************************************************************************/
 

/* For the file types, consult:
 * Ref. LBMAA-A-D 10.1, 10-1, "Types of Data Files"
 * Ref. LBMAA-A-D 10.1.1, 10-1, "Sequential Access Files" 
 * Ref. LBMAA-A-D 10.1.2, 10-2, "Random Access Files" */


/* FFILE()
 * implementation of the FILE/FILES statements. 
 * isFiles: flag: if TRUE, execute FILES (which does not accept variables and 
 * is executed before program start by preParse); if FALSE, execute FILE (which
 * accepts variables and is executed during runtime).
 * l: contains current line number for perror_();
 * p holds address of character after FILE/FILES 
 * Ref. LBMAA-A-D 10.2, 10-2, "The FILE and FILES Statements" */
void FFILE(int isFiles, int l) {
	int type, mode, filelen, reclen;
	/* the default mode for FILES/FILE opened file is read mode
	 * Ref. LBMAA-A-D 10.3, 10-4 */
	int wayout=VREAD;
	int fchar,flen;
	char op[COMPSCR], *o=op;
	char fop[COMPFIL];

	/* there must be at least one argument */
	if (!*p) {
		if (isFiles) perror_(88,l) ; // tested
		else perror_(65,l,FFLFVT,"# OR :"); // tested
	}

	/* perform the FILES statement 
	 * Ref. LBMAA-A-D 10.2, 10-2 */
	if (isFiles) do {
		op[0]='\0';o=op;
		reclen=STRRECLEN; mode=STRING; type=SEQ;
		while (channel[currChan].isopen) currChan++; 
		if (currChan>STREAMS) perror_(59,l);
		if (*p==',') {
			p++;
			continue;
		}

		/* variables are not admitted with FILES because FILES
		 * is executed into preParse(), when any variable is still
		 * uninstantiated, and thus not known */
		if (isstr(p)) perror_(101,l); // tested
		/* names enclosed in quotes are not admitted 
		 * (tested at the LCM) */
		else if (*p=='\"') perror_(88,l); // tested
		/* get file name 
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		/* name as constant */
		else while (*p && *p != ',' && *p !=';') *o++=*p++;
		*o='\0';

		/* discard separators , and ; on the input line
		 * (for next iteration) 
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		if (*p==',' || *p==';') p++;

		/* determine file characteristics */
		setupName(op,&fchar,&flen);
		if (flen<0) perror_(65,l,makechar(op),"; OR ,");
		if (fchar=='%') type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		else if (fchar=='$') {
			type = RANDOM, mode=STRING;
			if (flen>0) reclen=flen;
			else reclen=NOUSE;
			if ((reclen<1 || reclen>132) && reclen!=NOUSE)
				perror_(56,l);
		}
		
		/* set channel values */
		/* open file, checking before if file has already been
		 * opened into another channel stream */
		if (checkNames(currChan,op)) perror_(82,l,op);

		/* set channel values */
		channel[currChan].stream=fopen(op,"r+");
		channel[currChan].isopen=TRUE;
		/* in case file does not exist, create it empty 
		 * Note: I couldn't find references about this, but I take it 
		 * for granted */
		if (!channel[currChan].stream) {
			channel[currChan].stream=fopen(op,"w");
			fclose(channel[currChan].stream);
			channel[currChan].stream=fopen(op,"r+");
			if (reclen==NOUSE) reclen=STRRECLEN;
			wayout=CREATED_VOID;
		}
		/* if file exists and type is RANDOM and mode is STRING
		 * get first item to set filelen to file length 
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		else {
			if (mode==STRING && type==RANDOM) {
				char op1[COMPSTR];
				fread(op1,sizeof(char),MAXSTRLEN,
						channel[currChan].stream);
				filelen=(int)strtod(op1+1,NULL);
				if (filelen>STRING) filelen-=STRING;
				else perror_(101,l);
				if (filelen>MAXSTRLEN || filelen<1) 
					perror_(56,l);
				if (reclen==NOUSE) reclen=filelen;
				else if (reclen!=filelen) perror_(84,l);
				/* file existed not as random file: reset it 
				 * Ref. LBMAA-A-D 10.2, 10-2 */
				if (reclen<0) {
					fclose(channel[currChan].stream);
					channel[currChan].stream=fopen(op,"w");
					fclose(channel[currChan].stream);
					reclen=STRRECLEN;
				}
				else if (reclen!=filelen) perror_(84,l);
				/* reset file position 
				 * Ref. LBMAA-A-D 10.3, 10-4, "The SCRATCH and
				 * RESTORE Statements" */
				fseek(channel[currChan].stream,0,SEEK_SET);
			}
		}

		/* print identifier in case of random files */
		if (type==RANDOM) {
			if (mode==STRING)
				sprintw(fop,COMPFIL,"�%d",reclen+STRING);
			else if (mode==NUMBER)
				sprintw(fop,COMPFIL,"�%d",reclen+NUMBER);
			fseek(channel[currChan].stream,0,SEEK_SET);
			fwrite(fop,sizeof(char),
					FIRSTLEN,channel[currChan].stream);
		}
		
		/* setup file */
		strncpy_(channel[currChan].ioname,op,COMPSTR);
		channel[currChan].type=type;
		channel[currChan].mode=mode;
		channel[currChan].fcounter=0;
		channel[currChan].wayout=wayout; // (only for SEQ)
		channel[currChan].currseek=1;
		channel[currChan].reclen=reclen;
		channel[currChan].randomaccessed=FALSE;
		channel[currChan].quote=NOQUOTE;
		channel[currChan].margin=MARGINDEF;
		channel[currChan].page=0;
		channel[currChan].pagerow=0;
		channel[currChan].writer=NOUSE;
		channel[currChan].reader=NOUSE;
		channel[currChan].fprintn=TRUE;
	} while (*p); 

	/* perform the FILE command  
	 * Ref. LBMAA-A-D 10.2, 10-2 */
	else do {
		reclen=STRRECLEN;
		mode=STRING;
		type=SEQ;

		/* get type and channel */
		if (*p==':') type=RANDOM, p++;
		else if (*p=='#') p++;
		else if (!isdigit(*p)) perror_(179,l); // tested
		currChan=strtol(p,&p,10);
		if (currChan>STREAMS || currChan<1) perror_(179,l);
		if (*p==',' || *p==':') p++;
		else perror_(65,l,makechar(p),": OR ,");
		
		/* check if channel is already opened by another command */
		if (channel[currChan].isopen) perror_(88,l,currChan);
		
		/* get file name (copy input text into op);
		 * Note: unquoted constants are not permitted with FILE 
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		if (isanystring(p)) strncpy_(op,SS(),COMPSCR);
		else perror_(37,l); // tested

		/* discard separators , and ; on the input line 
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		if (*p==',' || *p==';') p++;

		/* determine file characteristics */
		setupName(op,&fchar,&flen);
		if (flen<0) perror_(65,l,makechar(op),"; OR ,");
		if (fchar=='%') type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		else if (fchar=='$') {
			type = RANDOM, mode=STRING;
			if (flen) reclen=flen;
			else reclen=NOUSE;
			if ((reclen<1 || reclen>132) && reclen!=NOUSE)
				perror_(56,l);
		}
		/* the FILE: statement must be followed by a specifier for 
		 * the random file type (this behavior has been tested on the
		 * LCM), and this specifier must reside into the double quotes 
		 * or in the string variable */
		else if (type==RANDOM) perror_(101,l);

		/* as stated in the LBMAA-A-D document, par. 10.2, if FILE 
		 * finds open the required channel, it disconnects it and the 
		 * relative file, and reopens the channel connecting it to the 
		 * new file; it's specified that old file type is immaterial 
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		if (channel[currChan].stream!=NULL ||\
			       	*channel[currChan].ioname) {
			fflush(channel[currChan].stream);
			fclose(channel[currChan].stream);
		}

		/* name cannot be opened more than once;
		 * Note: I couldn't find news about this but I take it for 
		 * granted */
		if (checkNames(currChan,op)) perror_(82,l,op);

		/* set channel values */ 
		channel[currChan].stream=fopen(op,"r+");
		channel[currChan].isopen=TRUE;
		/* in case file does not exist, create it empty 
		 * Note: I couldn't find references about this, but I take it 
		 * for granted */
		if (!channel[currChan].stream) {
			channel[currChan].stream=fopen(op,"w");
			fclose(channel[currChan].stream);
			channel[currChan].stream=fopen(op,"r+");
			if (reclen==NOUSE) reclen=STRRECLEN;
			wayout=CREATED_VOID;
		}
		/* if file exists and type is RANDOM and mode is STRING
		 * get first item to set file length  
		 * Ref. LBMAA-A-D 10.2, 10-2 */
		else {
			if (mode==STRING && type==RANDOM) {
				char op1[COMPSTR];
				fread(op1,sizeof(char),MAXSTRLEN,
						channel[currChan].stream);
				filelen=(int)strtod(op1+1,NULL);
				if (filelen>STRING) filelen-=STRING;
				else perror_(101,l);
				if (filelen>MAXSTRLEN || filelen<1) 
					perror_(56,l);
				if (reclen==NOUSE) reclen=filelen;
				/* file existed not as random file: reset it  
				 * Ref. LBMAA-A-D 10.2, 10-2 */
				if (reclen<0) {
					fclose(channel[currChan].stream);
					channel[currChan].stream=fopen(op,"w");
					fclose(channel[currChan].stream);
					reclen=STRRECLEN;
				}
				else if (reclen!=filelen) perror_(84,l);
				/* reset file position 
				 * Ref. LBMAA-A-D 10.3, 10-4, "The SCRATCH and
				 * RESTORE Statements" */
				fseek(channel[currChan].stream,0,SEEK_SET);
			}
		}

		/* print identifier in case of random files */
		if (type==RANDOM) {
			if (mode==STRING)
				sprintw(fop,COMPFIL,"�%d",reclen+STRING);
			else if (mode==NUMBER)
				sprintw(fop,COMPFIL,"�%d",reclen+NUMBER);
			fseek(channel[currChan].stream,0,SEEK_SET);
			fwrite(fop,sizeof(char),
					FIRSTLEN,channel[currChan].stream);
		}
		
		/* setup file */
		strncpy_(channel[currChan].ioname,op,COMPSTR);
		channel[currChan].type=type;
		channel[currChan].mode=mode;
		channel[currChan].fcounter=0;
		channel[currChan].wayout=wayout; // only for SEQ
		channel[currChan].currseek=1;
		channel[currChan].reclen=reclen;
		channel[currChan].randomaccessed=FALSE;
		channel[currChan].quote=NOQUOTE;
		channel[currChan].margin=MARGINDEF;
		channel[currChan].page=0;
		channel[currChan].pagerow=0;
		channel[currChan].writer=NOUSE;
		channel[currChan].reader=NOUSE;
		channel[currChan].fprintn=TRUE;
	} while (*p); 
}


/* IFEND() 
 * implementation of the IF END#/IF END: statement 
 * Note: decb IF END does not distinguish between sequential files with or 
 * without line numbers (that is in READ or INPUT mode); so decb version of 
 * IF END returns TRUE whenever whichever stream has reached EOF.
 * Ref. LBMAA-A-D 10.10, 10-14, "The IF END statement" */
void IFEND(void) {
	int ch=-1, flag=0;

	/* IF END is not followed by THEN/GOTO */
	if (!check(p,"GOTO")) perror_(35,l);
	
	/* setup for sequential files */
	if (*p=='#') {
		p++;
		ch=(int)S();
		/* checking if channel is valid */
		if (ch<1 || ch>STREAMS) perror_(179,l);
		/* checking if file is open, if RANDOM and if in READ mode*/
		if (!channel[ch].isopen) perror_(80,l);
		if (channel[ch].wayout!=VREAD) perror_(85,l);
		if (channel[ch].type!=SEQ) perror_(101,l);
	}
	/* setup for random access files */
	else if (*p==':') {
		p++;
		ch=(int)S();
		/* checking if file is open and if RANDOM */
		if (!channel[ch].isopen) perror_(80,l);
		if (channel[ch].type!=RANDOM) perror_(101,l);
	}
	else perror_(65,l,makechar(p),"A LETTER");
	
	/* check EOF */
	flag=testEOF(ch); 
	/* if there's a comma, skip it 
	 * Ref. LBMAA-A-D 10.10, 10-14 */
	if (*p==',') p++;
	/* now skip GOTO (THEN has been changed into GOTO in tokenize() */
	if(!strncmp(p," OTO",4)) p+=4;
	/* otherwise it's an incorrect IF END */
	else perror_(38,l);
	/* if IF END condition is true, go to the THEN/GOTO destination */
	if (flag) GOTO();
}


/* FMARGIN()
 * implementation of the MARGIN statement
 * Ref. LBMAA-A-D 10.8, 10-12, "The MARGIN and MARGIN ALL Statements" */
void FMARGIN(void) {
	int ch, msize;

	/* a void MARGIN is an error in any case for the DEC-20 */
	if (!*p) perror_(65,l,FFLFVT,TERMINAT); // tested

	/* MARGIN ALL statement (for files)
	 * Note: no checking is done here to see if a stream is seq or random
	 * because, anyway, in a random file, the margin field is not used 
	 * Note: the terminal is not affected by this command
	 * Ref. LBMAA-A-D 10.8, 10-12, "The MARGIN and MARGIN ALL Statements" */
	if (!strcmp(p,"ALL")) {
		/* get margin size */
		p+=3; // 'ALL' specifier must be followed by direct formula
		msize=(int)S();
		if (msize<1 || msize>MARGINMAX) perror_(98,l);
		for (ch=1;ch<=STREAMS;ch++)
			channel[ch].margin=msize;
	}
	/* files or terminal MARGIN statement 
	 * Note: in chapter 6.7, page 6-8 it's stated that the MARGIN command 
	 * for the terminal had to be used in parallel with the MONITOR command 
	 * TERMINAL WIDTH in case the MARGIN is set to a number greater than 72
	 * with arguments from 8 to 127. Of course, decb may be used  in the 
	 * same fashion, but since it is used as a UNIX program, it's up to the 
	 * user decide what kind of terminal to use, whether real or simulated,
	 * and if possible, to change or adapt its width. 
	 * I generally use the Terminal in MAC OS X or in Linux, so I can 
	 * control the width, but I rarely go past 72.
	 * Ref. LBMAA-A-D 6.7, 6-7, "MARGIN Statement" 
	 * Ref. LBMAA-A-D 10.8, 10-12, "The MARGIN and MARGIN ALL Statements" */
	else do {
		if (*p==':') perror_(101,l);
		if (*p=='#') { 
			p++; 
			ch=(int)S();
			if (ch<1 || ch>STREAMS) perror_(179,l);
		}
		else ch=CONSOLE; // terminal
		if (channel[ch].type!=SEQ) perror_(101,l);
		if (*p==':' || *p==',') p++;
		msize=(int)S();
		if (msize<1 || msize>MARGINMAX) perror_(98,l);
		channel[ch].margin=msize;
		if (*p==',' || *p==';') p++;
	} while (*p);
}


/* FPAGE()
 * implementation of the PAGE [ALL] statement 
 * Ref. LBMAA-A-D 10.9, 10-12, "The PAGE, PAGE ALL, NOPAGE, NOPAGE ALL 
 * Statements" 
 * Ref. LBMAA-A-D, 6.8, 6-8, "PAGE Statement"
 * Ref. LBMAA-A-D, 6.9, 6-8, "NOPAGE Statement" 
 * Ref. LBMAA-A-D, 10.9, 10-13, "The PAGE, PAGE ALL, NOPAGE, and NOPAGE ALL
 * Statements" */
void FPAGE(void) {
	int ch, psize;

	/* a void PAGE is an error in any case */
	if (!*p) perror_(65,l,FFLFVT,TERMINAT); // tested

	/* files: PAGE ALL statement 
	 * Ref. LBMAA-A-D 10.9, 10-13 */
	if (!strcmp(p,"ALL")) {
		/* get page size */
		p+=3; // 'ALL' specifier must be followed by direct formula
		psize=(int)S();
		/* a zero (or lesser) value is an error
		 * Ref. LBMAA-A-D 10.9, 10-14 */
		if (psize<1) perror_(116,l);
		else if (psize>PAGEHEIGHT) psize=PAGEHEIGHT;
		/* The PAGE ALL statement does not affect the terminal
		 * Ref. LBMAA-A-D 10.9, 10-13/14 */
		for (ch=1;ch<=STREAMS;ch++)
			channel[ch].page=psize;
	}
	/* files or terminal statement */
	else do {
		if (*p==':') perror_(101,l);
		if (*p=='#') { 
			p++; 
			ch=(int)S(); 
			if (ch<1 || ch>STREAMS) perror_(179,l); 
		}
		else ch=CONSOLE; // terminal
		if (channel[ch].type!=SEQ) perror_(101,l);
		if (*p==':' || *p==',') p++;
		psize=(int)S();
		/* a zero (or lesser) value is an error
		 * Ref. LBMAA-A-D 10.9, 10-14 */
		if (psize<1) perror_(116,l);
		else if (psize>PAGEHEIGHT) psize=PAGEHEIGHT;
		channel[ch].page=psize;
		if (*p==',' || *p==';') p++;
	} while (*p);

	/* when invoked, print PA_VOID lines */
	fillPage(ch);
	/* ensure page values are reset */
	channel[ch].fprintn=0;
	channel[ch].fcounter=0;
	channel[ch].pagerow=1;
}


/* FNOPAGE()
 * implementation of the NOPAGE [ALL] statement 
 * Ref. LBMAA-A-D 10.9, 10-13, "The PAGE, PAGE ALL, NOPAGE, NOPAGE ALL 
 * Statements" */
void FNOPAGE(void) {
	int ch;

	/* NOPAGE ALL statement (for files)
	 * Ref. LBMAA-A-D 10.9, 10-14 */
	if (!strcmp(p,"ALL")) {
		p+=3;
		if (*p) perror_(65,l,makechar(p),TERMINAT);
		/* The NOPAGE ALL statement does not affect the terminal
		 * Ref. LBMAA-A-D 10.9, 10-14 */
		for (ch=1;ch<=STREAMS;ch++)
			channel[ch].page=0;
	}
	/* terminal statement NOPAGE alone (allowed by the DEC-20) */
	else if (!*p) channel[CONSOLE].page=0;
	/* File statement NOPAGE #N */
	else while (*p) {
		if (*p==':') perror_(101,l);
		if (*p==',' || *p==';') ch=CONSOLE;
		else {
			if (*p=='#') p++;
			ch=(int)S();
		}
		channel[ch].page=0;
		if (*p==',' || *p==';') p++;
	}
}


/* FQUOTE()
 * implementation of the QUOTE/NOQUOTE [ALL] statement
 * quotemode: a flag to set/reset quote mode; if TRUE, set QUOTE mode, if 
 * FALSE, set NOQUOTE mode.
 * Ref. LBMAA-A-D 10.7, 10-10 "The QUOTE, QUOTE ALL, NOQUOTE, and
 * NOQUOTE ALL Statements" */
void FQUOTE(int quotemode) {
	int ch;

	/* QUOTE ALL/NOQUOTE ALL statement for files only 
	 * Ref. LBMAA-A-D 10.7, 10-11 */
	if (!strcmp(p,"ALL")) {
		p+=3;
		if (*p) perror_(65,l,makechar(p),TERMINAT);
		for (ch=1;ch<=STREAMS;ch++)
			channel[ch].quote=quotemode;
	}
	/* QUOTE/NOQUOTE alone for terminal
	 * Ref. LBMAA-A-D 10.7, 10-10 */
	else if (!*p) channel[CONSOLE].quote=quotemode;
	/* QUOTE #N/NOQUOTE #N for single channels */
	else while (*p) {
		if (*p==':') perror_(101,l);
		if (*p==',' || *p==';') ch=CONSOLE;
		else if (*p=='#') { 
			p++; 
			ch=(int)S(); 
		}
		else ch=(int)S();
		channel[ch].quote=quotemode;
		if (*p==',' || *p==';') p++;
	}
}


/* PRINT()
 * Wrapper to the PRINT family statements to select the correct path 
 * (designed for PRINT/PRINT#/WRITE#) 
 * flag: if TRUE, perform PRINT/PRINT#, otherwise perform WRITE#  
 * p points to the character after PRINT or WRITE */
void PRINT(int flag) {
	/* WRITE cannot be used as PRINT for console-mode */
	if (!flag && *p!='#' && *p!=':') perror_(44,l);
	/* PRINT#/WRITE#
	 * Ref. LBMAA-A-D 10.5.1, 10-7 */
	if (*p=='#') FWRITESHARP(flag);
	/* PRINT:/WRITE:
	 * Ref. LBMAA-A-D 10.5.2, 10-9 */
	else if (*p==':') FWRITECOLON();
	/* PRINT
	 * Ref. LBMAA-A-D 1.4.3, 1-8 */
	else FWRITESHARP(TRUE);
}


/* FWRITESHARP()
 * implementation of the PRINT/PRINT#/WRITE# statement (sequential files only) 
 * flag: if TRUE, perform PRINT/PRINT#, otherwise perform WRITE# 
 * Note: I noticed that on the LCM, if the last printed item was a number, 
 * there was one void line between the line of the number and the "TIME:" line, 
 * while if last item was a string void lines were three; I judge this too
 * weird, and too onerous to implement a control for what last printed item 
 * type is, so I decided to keep three void lines for better readability 
 * Ref. LBMAA-A-D 1.4.3, 1-8, "PRINT Statement" 
 * Ref. LBMAA-A-D 6.1, 6-1, "More about the PRINT Statement" 
 * Ref. LBMAA-A-D 10.5.1, 10-7, "WRITE and PRINT Statements for Sequential 
 * Access Files" */
void FWRITESHARP(int flag) {
	int ch, marg;

	/* choose destination */
	/* print on screen/terminal */
	if (*p!='#') ch=CONSOLE;
	/* print on file: get file channel */
	else {
		p++;
		ch=(int)S();
		if (ch<1 || ch>STREAMS) perror_(179,l);
		if (*p==','||*p==':') p++; // optional comma/colon - TESTED
		if (!channel[ch].isopen) perror_(80,l);
	
		/* if p points to USING, it's a PRINT/WRITE #1[,]USING<spec>
		 * form of the command - delegate FWRITEUSINGSHARP() */
		if (!strncmp(p,"USING",5)) {
			FWRITEUSINGSHARP(flag,ch);
			return;
		}
	}
	
	/* set default print CR state */
	channel[ch].fprintn=TRUE;

	/* if file is new, set writer mode */
	if (channel[ch].writer==NOUSE && ch>0) {
		if (flag) channel[ch].writer=VPRINT;
		else channel[ch].writer=VWRITE;
	}
	
	/* checking if this seq file was not SCRATCHed, which is an error 
	 * Ref. LBMAA-A-D 10.5, 10-7 */
	if (channel[ch].wayout==CREATED_VOID) perror_(72,l);

	/* checking if this seq file is in READ mode, which is an error 
	 * Ref. LBMAA-A-D 10.3, 10-5 (about RESTORE) */
	if (channel[ch].wayout==VREAD) perror_(73,l);

	/* checking if WRITE# and PRINT# are mixed for the same channel
	 * in sequential files, which is an error 
	 * Ref. LBMAA-A-D 10.5, 10-7 */
	if (flag && channel[ch].type==SEQ) {
		if (channel[ch].writer==VWRITE) perror_(103,l);
	}
	if (!flag && channel[ch].type==SEQ) {
		if (channel[ch].writer==VPRINT) perror_(103,l);
	}

	/* get current margin for subsequent evaluations */
	marg=channel[ch].margin;

	/* WRITE#/PRINT# without argument */
	if(!*p) channel[ch].pagerow++, channel[ch].fprintn=TRUE;
	/* WRITE#/PRINT# with argument */
	else while (*p) {
		
		/* WRITE# begins a line with a 5-digit number, 
		 * starting from 1000, followed by a tab 
		 * Ref. LBMAA-A-D 10.5,1, 10-7*/
		if (!flag) {
			if (!channel[ch].fcounter) {
				/* for WRITE, the MARGIN must be at least 7 or 
				 * line number and the tab can't be printed.
				 * Ref. LBMAA-A-D 10.8, 10-13 */
				if (marg<=MARGINMIN) perror_(99,l);
				/* line numbers must be <= 99999 */
			       	if (writeSeqStart>DATLIM) perror_(71,l);
				fprintf(channel[ch].stream,"%05d\t",\
						writeSeqStart);
				writeSeqStart+=writeSeqStep;
				channel[ch].fcounter=6;
			}
		}

		/* print a string (explicit or into a variable or into a string 
		 * expression); in QUOTE mode, string is enclosed into double 
		 * quotes and preceded by a blank - tested */
		if (isanystring(p)) {
			int i;
			char res[MAXSTRLEN]; res[0]='\0';
			strncpy_(res,SS(),COMPSTR);
			for (i=0;i<MAXSTRLEN;i++) pad[i]='\0';
			/* quote mode */
			if (channel[ch].quote==QUOTE) {
				/* string in quote mode cannot contain quote
				 * character (ASCII 34) */
				if (strchr(res,34)) perror_(86,l);
				strncpy_(pad," ",COMPSTR);
				/* quotes only if a blank/comma/tab is found */
				if (isblankcommatab(res)) {
					strncat_(pad,"\"",COMPSTR);
					strncat_(pad,res,COMPSTR); //sp+dq
					strncat_(pad,"\"",COMPSTR);
				}
				else strncat_(pad,res,COMPSTR); // space
				/* check length in QUOTE MODE 
				 * (LBMAA-A-D par. 10.7)*/
				if ((int)strlen(pad)>marg) perror_(111,l);
				else fprintf(channel[ch].stream,"%s",pad);
				channel[ch].fcounter+=strlen(pad);
				if (channel[ch].fcounter>marg) FCR(ch);
				channel[ch].fprintn=1;
			}
			/* normal no-quote */
			else {
				strncpy_(pad,res,COMPSTR);
				printContained(ch,pad,marg);
				channel[ch].fprintn=1;
			}
			
			/* if after a comma/semicolon there's a TAB, the
			 * comma/semicolon function must not be performed */
			if (!strncmp(p,";TAB(",5)||!strncmp(p,",TAB(",5)) p++;
			
			/* only the + operator is admitted */
			if(*p && *p!='+') {
				if (isro(p)) perror_(35,l); // tested
			}
			/* p is updated into SS() */
		}
		/* adjust comma position (go to next ZONE) 
		 * Note: WRITE starts counting ZONEs after the five numbers
		 * plus the TAB character, so we must subtract this value */
		else if (*p==',') {
			int k=flag?0:6; // WRITE line-number space
			if (!channel[ch].fcounter) channel[ch].fcounter+=k;
			if (!channel[ch].fcounter) FAC(ch);
			while ((channel[ch].fcounter)%ZONE) FAC(ch);
			
			/* in case of multiple commas, force advancing */
			if (*(p+1)==',') FAC(ch);
			p++, channel[ch].fprintn=0;
			
			/* the following Carriage Return, for file printing
			 * only, was tested on the LCM, but?? */
			if (marg<72 && ch>0) FCR(ch); 
		}
		/* adjust semicolon position (actually doing nothing) */
		else if (*p==';') {
			/* in case of sequent comma, force advancing */
			if (*(p+1)==',') FAC(ch);
			p++, channel[ch].fprintn=0;
		}
		/* <PA> delimiter for PRINT/PRINT#/WRITE# 
		 * Ref. LBMAA-A-D 6.8, 6-8 "PAGE Statement", where it's
		 * stated that "whenever a PRINT statement containing <PA> is
		 * executed, the line count for the terminal page is set
		 * back to zero." */
		else if (!strncmp(p,"??;",3)) {
		 	/* <PA> on files
			 * the effect is to separate outputs not on a basis of
		 	 * a printed page but on a plain empty lines series */
			channel[ch].fprintn=0;
			fillPage(ch);
			p+=3;
			channel[ch].fcounter=0;
		}
		/* TAB() function 
		 * Ref. LBMAA-A-D 6.1, 6-3 */
		else if (!strncmp(p,"TAB(",4)) {
			int tab;
			p+=4;
			channel[ch].fprintn=0;
			tab=(int)S();
			tab=(abs(tab)%marg);
			if (')'==*p) p++; // skip ')'
			else perror_(37,l);
			while (channel[ch].fcounter<tab) {
				fputc(' ',channel[ch].stream);
				channel[ch].fcounter++;
			}
		}
		/* print a numerical expression;
		 * regardless of QUOTE mode, a space is printed after the 
		 * number to prevent contiguous characters 
		 * Ref. LBMAA-A-D 6.1, 6-1, see the picture */ 
		else {
			double res=S();
			char out[COMPSTR], *o=out, pad[COMPSTR],*PAD=pad;
			printNUM(ch,res,1,out);
			if (res<0 && channel[ch].quote==QUOTE) 
				sprintw(pad,COMPSTR," %s",out);
			else strncpy_(pad,out,COMPSTR);	
			
			/* 'quote' mode 
			 * Ref. LBMAA-A-D 10.7,10-10 */
			if (channel[ch].quote==QUOTE) {
				/* check length in QUOTE MODE */
				if ((int)strlen(pad)>marg) perror_(111,l);
				else fprintf(channel[ch].stream, "%s", pad);
				channel[ch].fcounter+=strlen(pad);
				if (channel[ch].fcounter>marg) {
					FCR(ch);
					channel[ch].fprintn=0;		
				}
				else channel[ch].fprintn=1;
			}
			
			/* 'no quote' mode  
			 * Ref. LBMAA-A-D 10.7, 10-10 */
			else {
				while (*PAD) {
					o=out;
					while(*PAD&&channel[ch].fcounter<marg){
						*o++=*PAD++;
						channel[ch].fcounter++;
					}
					*o='\0';
					if (channel[ch].fcounter>marg-1) 
						FCR(ch);
					fprintf(channel[ch].stream, "%s", out);
					channel[ch].fprintn=1;
				}
			}
			
			/* if after a comma/semicolon there's a TAB, the
			 * comma/semicolon function must not be performed */
			if (!strncmp(p,";TAB(",5)||!strncmp(p,",TAB(",5)) p++;
			/* p is updated into S() */
		}
	}
	if (channel[ch].fprintn) FCR(ch);
}


/* FWRITECOLON()
 * implementation of the WRITE:/PRINT: statement (random files only) 
 * Note: according to the LBMAA-A-D the WRITE: and PRINT: statements
 * are completely equivalent, and may be used on the same channel 
 * consecutively and/or alternatively without raising errors 
 * Ref. LBMAA-A-D 10.5.2, 10-9, "WRITE and PRINT Statements for Random Access 
 * Files" */
void FWRITECOLON(void) {
	int ch,i;
	char op[COMPFIL];

	/* get channel and make checks */
	p++;
	ch=(int)S();
	if (ch<1 || ch>STREAMS) perror_(179,l);
	if (!channel[ch].isopen) perror_(80,l);
	if (channel[ch].type!=RANDOM) perror_(101,l);
	if (*p==':' || *p==',') p++;
	else perror_(38,l);

	/* get elements to be written */
	do {
		/* clear buffer */
		for (i=0;i<COMPFIL;i++) op[i]='\0';

		/* write a string variable or literal */
		if (isstr(p) || *p=='\"') {
			/* checking type */
			if (channel[ch].mode!=STRING) perror_(45,l);

			/* get element */
			strncpy_(op,SS(),COMPFIL);
		}
		/* write a numeric formula result */
		else {
			/* checking type */
			if (channel[ch].mode!=NUMBER) perror_(45,l);

			/* get element */
			printNUM(ch,S(),TRUE,op);
		}
		if (*p==',' || *p==';') p++;
		else if (*p) perror_(38,l);
		
		/* write phisically data on file */
		if ((int)strlen(op)>channel[ch].reclen) perror_(113,l);
		fwrite(op,sizeof(char),channel[ch].reclen,
			channel[ch].stream);
		channel[ch].currseek++;

	} while (*p);
}


/* FREADSHARP()
 * implementation of the READ#/INPUT# statements
 * Note: READ# and INPUT#, according to the LBMAA-A-D differ: READ expects a 
 * line number for each data file line, and this number is discarded; if no 
 * number is found, an error is issued; INPUT#, does not expect a line number, 
 * and if found, treats it as a datum;
 * These commands may not be mixed in the same channel; 
 * flag: if TRUE, perform INPUT#, otherwise perform READ# 
 * Ref. LBMAA-A-D 10.4, 10-5, "The READ and INPUT Statements" */
void FREADSHARP(int flag) {
	char line[COMPFIL], *u, c=0;
	int ch=0, var=0, done=1, j=0;
	double val=0.0;
	static int startofline=TRUE; 

	/* get channel and make checks */
	ch=(int)S();
	if (ch<1 || ch>STREAMS) perror_(179,l);
	if (*p==',' || *p==':') p++;
	else perror_(38,l);
	if (!channel[ch].isopen) perror_(69,l);
	if (channel[ch].type!=SEQ) perror_(101,l);

	/* checking if sequential file is in WRITE mode, which is an error */
	if (channel[ch].wayout==VWRITE) perror_(70,l);
	
	/* checking if end of file */
	if (testEOF(ch)) perror_(25,l);
		
	/* checking if READ# and INPUT # are mixed for the same
	 * channel, which results in an error 
	 * Ref. LBMAA-A-D 10.4, 10-5 */
	if (channel[ch].reader==NOUSE) {
		if (flag) channel[ch].reader=VINPUT;
		else channel[ch].reader=VREAD;
		fseek(channel[ch].stream,0,SEEK_SET);
	}
	else {
		if (flag && channel[ch].reader==VREAD) perror_(102,l);
		if (!flag && channel[ch].reader==VINPUT) perror_(102,l);
	}

	for (j=0; j<COMPFIL;j++) line[j]='\0';

	/* repeat for all variables */
	while (*p && done) {
		/* checking variable syntax */
		if (varCode(p) >= FUNCTION) perror_(38,l);
		
		/* get next available character */
		u=line;
		c=fgetc(channel[ch].stream);
		while (isblank(c) || c=='\n') c=fgetc(channel[ch].stream);

		/* READ# reads and discards starting line number 
		 * Note: the LBMAA-A-D par. 10.1.1, 10-1, states that "In line
		 * numbered files, each line number must be followed 
		 * immediately by at least a space, a tab, or the letter D." 
		 * [sic]; 
		 * Ref. LBMAA-A-D 10.4, 10-5 */
		if (!flag && startofline) {
			int rc=0;
			if (isdigit(c)) {
				while (rc++<5 && isdigit(c)) {
					c=fgetc(channel[ch].stream);
				}
				if (c!='d' && c!='D' && c!='\t' && c!=' ')
					perror_(22,l);
			}
			else perror_(22,l);
			startofline=FALSE;
			while (isblank(c)) c=fgetc(channel[ch].stream);
		}

		/* read a string enclosed into double quotes */
		if (c=='\"') {
			c=fgetc(channel[ch].stream);
			while (c!=EOF && c!='\n' && c!='\"' &&\
					(int)(u-line)<FILELINE) {
				*u++=c;
				c=fgetc(channel[ch].stream);
			}
			if (c=='\"') c=fgetc(channel[ch].stream);
			else if (c=='\n') perror_(22,l); // tested
		}
		/* read a normal string or number-string
		 * (the comma separates strings as well as spaces)
		 * Note: if a double quote is found, the BAD DATA error
		 * is shown - tested */
		else {
			do {
				*u++=c; // store even one starting space
				c=fgetc(channel[ch].stream);
				if (c==34) perror_(22,l);
			} while (c!=EOF && c!=' ' && c!=',' && c!=10 && c!=13&&\
				       c!='\t' && (int)(u-line)<FILELINE);
			while (isblank(c)) c=fgetc(channel[ch].stream);
			/* return last character read (which is not a blank)*/
			ungetc(c,channel[ch].stream);
		}
		*u='\0'; // close line!
		
		/* treat lines beginning with spaces */
		u=line;
		if (isblank(*u) || *u==',') u++;
		
		/* Reset counter if end of line is reached */
		if (c==13 || c==10 || !c) {
			startofline=TRUE;
		}

		/* treat exhausted lines 
		 * (last character read was an end-of-file) */
		if (c==EOF) break;

		/* INPUT#/READ# numerical vars A..Z/A0..Z9 */
		if (varcheck(p,SIMPVAR) || varcheck(p,DOUBVAR)) {
			while (isblank(*u)) u++;
			if (isdigit(*u) || *u=='.' || *u=='-' || *u=='+') {
				val=strtod(u,&u);
				if (val<MINFF || val>INFF) done=0;
				else p=setINPUTnum(p,val);
			}
			else done=0;
		}
		/* INPUT#/READ# numerical arrays */
		else if (varcheck(p,DOUBARR) || varcheck(p,SIMPARR)) {
			while (isblank(*u)) u++;
			if (isdigit(*u) || *u=='.' || *u=='-' || *u=='+') {
				val=strtod(u,&u);
				if (val<MINFF || val>INFF) done=0;
				else p=setINPUTarray(p,val);
			}
			else done=0;
		}
		/* INPUT#/READ# string variables and string arrays */
		else if (varcheck(p,SIMPSTR) || varcheck(p,DOUBSTR)
			|| varcheck(p,SIMPSTRARR) || varcheck(p,DOUBSTRARR)) {
			u=line;
			while (isblank(*u)) u++;
			/* store assignment into variables */
			if (varcheck(p,SIMPSTR)) {
				int lk;
				var=(int)*p;
				lk=strlen(u)+1;
				if (PS[var]!=NIL) free(PS[var]);
				PS[var]=malloc(lk);
				if (!PS[var]) perror_(191,l);
				*PS[var]='\0';
				strncpy_(PS[var],u,lk);
				p+=2;
			}
			else if (varcheck(p,DOUBSTR)) {
				int lk;
				var=in(*p,*(p+1));
				lk=strlen(u)+1;
				if (PS[var]!=NIL) free(PS[var]);
				PS[var]=malloc(lk);
				if (!PS[var]) perror_(191,l);
				*PS[var]='\0';
				strncpy_(PS[var],u,lk);
				p+=3;
			}
			/* or into string arrays */
			else if (varcheck(p,SIMPSTRARR)) {
				int M=0;
				var=*p; p+=3;
				M=S();
				setArrayStr(var,1,M,0,u);
				p++;
			}
			else if (varcheck(p,DOUBSTRARR)) {
				int M=0;
				var=in(*p,*(p+1)); p+=4;
				M=S();
				setArrayStr(var,1,M,0,u);
				p++;
			}
			while (*p && *p!=',' && *p!=';') p++;
		}
		while(isblank(*p)) p++;
		if (*p==','||*p==';') p++;
		if (!*p) break;
	}

	/* discard all remaining spaces in the line */
	while (c==' ' || c=='\t' || c=='\n') 
		c=fgetc(channel[ch].stream);

	/* reset file position */
	u=line;
	while (*u) u++;
	fseek(channel[ch].stream,-strlen(line)+(int)(u-line)-1,SEEK_CUR);
}


/* FREADCOLON()
 * implementation of the READ:/INPUT: statements
 * Note: according to the LBMAA-A-D the READ: and INPUT: statements are 
 * completely equivalent, and may be used in the same channel consecutively 
 * without raising errors (page 10-6).
 * Ref. LBMAA-A-D 10.4, 10-5, "The READ and INPUT Statements" */
void FREADCOLON(void) {
 	char op[COMPFIL];
	int ch,var,i;

	/* get channel and make checks */
	ch=(int)S();
	if (ch<1 || ch>STREAMS) perror_(179,l);
	if (*p==',' || *p==':') p++;
	else perror_(38,l);
	if (!channel[ch].isopen) perror_(80,l);
	if (channel[ch].type!=RANDOM) perror_(101,l);

	/* checking if end of file */
	if (testEOF(ch)) perror_(25,l);
		
	/* in case this command is executed on a not accessed file,
	 * read first data file line to access file type and dimensions */
	if (!channel[ch].randomaccessed) {
		int rl;
		long ft=ftell(channel[ch].stream);
		channel[ch].randomaccessed=TRUE;
		fseek(channel[ch].stream,0,SEEK_SET);
		fread(op,sizeof(char),FIRSTLEN,channel[ch].stream);
		op[0]='0'; // get rid of � identifier
		rl=(int)strtod(op,NULL);
		if (channel[ch].mode==STRING) {
			rl-=STRING;
			if (rl>MAXSTRLEN||rl<1) perror_(56,l);
		}
		else if (channel[ch].mode==NUMBER) rl-=NUMBER;
		if (rl!=channel[ch].reclen) perror_(84,l);
		fseek(channel[ch].stream,ft,SEEK_SET); // restore position
		channel[ch].currseek=1;
	}

	/* repeat for all variables */
	while (*p) {

		/* clear buffer */
		for (i=0;i<COMPFIL;i++) op[i]='\0';

		/* checking variable syntax */
		if (varCode(p) >= FUNCTION) perror_(38,l);

		/* INPUT:/READ: numerical vars A..Z/A0..Z9 */
		if (varcheck(p,SIMPVAR) || varcheck(p,DOUBVAR)) {
			double val=0.0;
			if (channel[ch].mode!=NUMBER) perror_(45,l);
			fread(op,sizeof(char),channel[ch].reclen,
					channel[ch].stream);
			val=strtod(op,NULL);
			if (val<MINFF) val=MINFF;
			else if (val>INFF) val=INFF;
			p=setINPUTnum(p,val);
		}
		/* INPUT:/READ: numerical arrays */
		else if (varcheck(p,DOUBARR) || varcheck(p,SIMPARR)) {
			double val=0.0;
			if (channel[ch].mode!=NUMBER) perror_(45,l);
			fread(op,sizeof(char),channel[ch].reclen,
					channel[ch].stream);
			val=strtod(op,NULL);
			if (val<MINFF) val=MINFF;
			else if (val>INFF) val=INFF;
			p=setINPUTarray(p,val);
		}
		/* INPUT:/READ: string variables and string arrays */
		else if (varcheck(p,SIMPSTR) || varcheck(p,DOUBSTR)
			|| varcheck(p,SIMPSTRARR) || varcheck(p,DOUBSTRARR)) {
			if (channel[ch].mode!=STRING) perror_(45,l);
			/* get string from file */
			fread(op,sizeof(char),channel[ch].reclen,
					channel[ch].stream);
			/* store assignment into variables */
			if (varcheck(p,SIMPSTR)) {
				int lk;
				var=(int)*p;
				lk=strlen(op)+1;
				if (PS[var]!=NIL) free(PS[var]);
				PS[var]=malloc(lk);
				if (!PS[var]) perror_(191,l);
				*PS[var]='\0';
				strncpy_(PS[var],op,lk);
				p+=2;
			}
			else if (varcheck(p,DOUBSTR)) {
				int lk;
				var=in(*p,*(p+1));
				lk=strlen(op)+1;
				if (PS[var]!=NIL) free(PS[var]);
				PS[var]=malloc(lk);
				if (!PS[var]) perror_(191,l);
				*PS[var]='\0';
				strncpy_(PS[var],op,lk);
				p+=3;
			}
			/* or into string arrays */
			else if (varcheck(p,SIMPSTRARR)) {
				int M=0;
				var=*p; p+=3;
				M=S();
				setArrayStr(var,1,M,0,op);
				p++;
			}
			else if (varcheck(p,DOUBSTRARR)) {
				int M=0;
				var=in(*p,*(p+1)); p+=4;
				M=S();
				setArrayStr(var,1,M,0,op);
				p++;
			}
		}
		channel[ch].currseek++;
		if (*p==','||*p==';') p++;
	}
}


/* FRESTORE()
 * implementation of the RESTORE statement for files;
 * omitting the # (sign number) or the : (colon) is interpreted as a RESTORE on 
 * a sequential file 
 * Ref. LBMAA-A-D 10.3, 10-4, "The SCRATCH and RESTORE Statements" */
void FRESTORE(void) {
	int ch;
	do {
		/* sequential file */
		if(*p=='#' || isdigit(*p)) {
			if (*p=='#') p++;
			ch=(int)S();
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) perror_(179,l);
			/* check if file exists */
			if (!channel[ch].stream) perror_(88,l);
			if (!channel[ch].isopen) perror_(80,l);
			/* check if file is random, which results in an error*/
			if (channel[ch].type!=SEQ) perror_(101,l);
			/* set file in read mode and move seek to start 
			 * Ref. LBMAA-A-D 10.3, 10-4, "Restoring a sequential
			 * access file sets the file in read mode. Reading will
			 * start at the beginning of the file." */
			channel[ch].wayout=VREAD;
			fseek(channel[ch].stream,0,SEEK_SET);
		}
		/* random file */
		else if (*p==':') {
			p++;
			ch=(int)S();
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) perror_(179,l);
			/* check if file exists */
			if (!channel[ch].stream) perror_(88,l);
			if (!channel[ch].isopen) perror_(80,l);
			/* check if file is seq, which results in an error*/
			if (channel[ch].type!=RANDOM) perror_(101,l);
			/* set to first item 
			 * Ref. LBMAA-A-D 10.3, 10-5 "Restoring a random 
			 * access file simply sets the pointer for the file to
			 * the first record in the file." */
			channel[ch].currseek=1;
			fseek(channel[ch].stream,FIRSTLEN,SEEK_SET);
		}
		else perror_(38,l);
		if (*p==',' || *p==';') p++;
	} while (*p);
}


/* FSCRATCH() 
 * implementation of the SCRATCH statement;
 * omitting the # (sign number) or the : (colon) is interpreted as a SCRATCH on 
 * a sequential file  
 * Ref. LBMAA-A-D 10.3, 10-4, "The SCRATCH and RESTORE Statements" */
void FSCRATCH(void) {
	int ch;
	/* there must be an argument */
	if (!*p) perror_(38,l);
	
	do {
		/* sequential file 
		 * Ref. LBMAA-A-D 10.3, 10-4 (about the absence of both the 
		 * number sign and the colon) */
		if(*p=='#' || isdigit(*p)) {
			if (*p=='#') p++;
			ch=(int)S();
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) perror_(179,l);
			/* check if file exists */
			if (!channel[ch].isopen) perror_(80,l);
			/* check if file is random, which results in an error*/
			if (channel[ch].type!=SEQ) perror_(101,l);
			/* erase and reset to write mode
			 * Ref. LBMAA-A-D 10.3, 10-4, "Scratching a sequential
			 * access file erases it and sets it in write mode." */
			if (channel[ch].stream) {
				fclose(channel[ch].stream);
				channel[ch].stream=
					fopen(channel[ch].ioname,"w+");
				channel[ch].wayout=VWRITE;
				channel[ch].writer=NOUSE;
			}
		}
		/* random file */
		else if (*p==':') {
			int type=0, reclen=0, mode=0;
			char fop[COMPFIL];
			p++;
			ch=(int)S();
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) perror_(179,l);
			/* check if file exists */
			if (!channel[ch].isopen) perror_(80,l);
			/* check if file is seq, which results in an error*/
			if (channel[ch].type!=RANDOM) perror_(101,l);
			/* erase and reset to first item 
			 * Ref. LBMAA-A-D 10.3, 10-4, "Scratching a random 
			 * access file simply erases is and sets the pointer
			 * for the file to the first record in the file." */
			type=channel[ch].type;
			reclen=channel[ch].reclen;
			mode=channel[ch].mode;
			if (channel[ch].stream) {
				fclose(channel[ch].stream);
				channel[ch].stream=
					fopen(channel[ch].ioname,"w+");
			}
			/* re-print identifier in case of random files */
			if (type==RANDOM) {
				if (mode==STRING)
				    sprintw(fop,COMPFIL,"�%d",reclen+STRING);
				else if (mode==NUMBER)
				    sprintw(fop,COMPFIL,"�%d",reclen+NUMBER);
				fseek(channel[currChan].stream,0,SEEK_SET);
				fwrite(fop,sizeof(char),
					FIRSTLEN,channel[currChan].stream);
			}
			/* update file references*/
			channel[ch].currseek=1;
			channel[ch].randomaccessed=FALSE;
		}
		else perror_(38,l);
		if (*p==',' || *p==';') p++;
	} while (*p);
}


/* FSET() 
 * implementation of the SET statement;
 * Ref. LBMAA-A-D 10.6, 10-9, "The SET Statement and the LOC and LOF 
 * Functions" */
void FSET(void) {
	int ch=0, setpos=0, eof=0, reclen=0;

	/* Ref. LBMAA-A-D 10.6, 10-9, "Each SET statement must have at least 
	 * one argument." */
	if (!*p) perror_(37,l); // tested
	/* there are arguments */
	else do {
		/* colon can be omitted
		 * Ref. LBMAA-A-D 10.6, 10-11 */
		if (*p==':') p++;
		
		/* get and check channel */
		ch=(int)S();
		if (ch<1 || ch>STREAMS) perror_(179,l);
		if (!channel[ch].isopen) perror_(80,l);
		if (channel[ch].type!=RANDOM) perror_(101,l);

		 /* get and check position */
		if (*p!=':' && *p!=',') perror_(38,l);
		p++;
		setpos=(int)S();
		reclen=channel[ch].reclen;
		if (setpos<=0) perror_(120,l);
		/* fill positions in case SET value is past EOF */
		eof=getEOF(ch);
		if (setpos>eof) {
			fseek(channel[ch].stream,0,SEEK_END);
			fwrite("\0",sizeof(char),(setpos-eof-1)*reclen,
					channel[ch].stream);
		}
		/* set position */
		fseek(channel[ch].stream,FIRSTLEN+(setpos-1)*reclen,SEEK_SET);
		channel[ch].currseek=setpos;
		if (*p==',' || *p==';') p++;
	} while (*p);		
}


/* CHAIN()
 * implementation of the CHAIN command;
 * enable a program to load and parse an external program.
 * Note: the CHAIN statement is the last to be executed, so anything following
 * it is discarded, both in listing and in the program flow. In practice, the 
 * caller program transfers the control to the CHAINed file.
 * The CHAINed file doesn't inherit the caller's variables (tested on the LCM,
 * but not specified anywhere in the LBMAA-A-D).
 * The starting line of the CHAINed program may be specified after a comma 
 * Ref. LBMAA-A-D 6.6, 6-6, "CHAIN Statement"
 * Ref. LBMAA-A-D 9.5, 9-8, "Executing a BASIC Program in Memory", CHAIN */
void CHAIN(void) {
	char fname[COMPSCR], *tf=fname;
	FILE* fd;
	int z=0, sL=0;
	
	/* Note: as tested on the LCM, the CHAIN command
	 * may be issued into a FOR, or with a pending GOSUB subroutine,
	 * or within a multiline DEF function; so there's no need to
	 * prevent the call to CHAIN in those cases */

	/* get file name 
	 * name may be given as CHAIN FILE1 or CHAIN "FILE1" or CHAIN A$; 
	 * FILE1 without quotes must of course not contain quotes, spaces,
	 * commas; if it contains any of such peculiar characters, it must be 
	 * written enclosed by double quotes.
	 * Ref. LBMAA-A-D 6.6, 6-6 */
	while (isblank(*p)) p++;
	/* get name from string (case a)*/
	if (!isstr(p)) 
		{	
			/* string enclosed by "" */
			if (*p=='\"') {
				p++;
				while (*p!='\"') *tf++=*p++;
				*tf='\0';
				p++;
			}
			/* plain name until comma or end of string */
			else {
				while (*p!=',' && *p!='\0') *tf++=*p++;
				*tf='\0';
			}
		}
	/* get name from variable (case b) */
	else strncpy_(fname,SS(),COMPSCR);
	while (isblank(*p)) p++;

	/* get starting line, if given as argument; check if into bounds 
	 * Ref. LBMAA-A-D 6.6, 6-6 */
	if (*p){
		if (*p!=',') perror_(38,l);
		p++; // skip comma
		sL=(int)S();
		if (sL<0 || sL>DATLIM) perror_(94,l);
	}
	/* if no argument was found, set default starting line = -1 to 
	 * force check for line 0 in case it is chosen */
	else sL=-1;

	/* flush and close previous opened */
	for (z=1; z<=9; z++) {
		if (channel[z].isopen) {
			fflush(channel[z].stream);
			fclose(channel[z].stream);
			channel[z].isopen=FALSE;
		}
	}

	/* checking file existence */
	setupName(fname,&z,&z);
	if (!(fd=fopen(fname,"r"))) perror_(10,l,fname);
	else fclose(fd);
	
	/* set CHAIN flag, load file name */
	isChain=TRUE;
	strncpy_(filename,fname,COMPSCR);
	OLD(); // OLD() erases memory

	
	/* irregular line (line inside a multiline DEF FN, for instance) */
	if (fm[sL]) perror_(89,l);
	
	/* find first useful line in case user didn't specify one 
	 * This works even if line 0 does exist. */
	if (sL==-1) {
		z=0; while (!m[z++]);
		startingLine=z-1;
	}
	/* otherwise set user choice */
	else startingLine=sL;

	/* starting line does not exist in the CHAINed file */
	if (!m[startingLine]) perror_(107,-1);
	
	/* all's good: execute the CHAINed program 
	 * Note: RUN erases all memory and calls both preParse() and parse() */
	RUN();
}


/******************************************************************************
 * The following routines define the behavior of the MAT statements, which were
 * included as a CardBasic option (external program on cards) since 1964 
 * version II of Dartmouth BASIC, and as standard since 1966 version III.
 * I base the following routines on chapter 7 of the LBMAA-A-D, and of course
 * on the September 1966 manual for version III, which also presents an 
 * exhaustive explanation on the usage of matrices.
 * Many references and suggestions have been grabbed by the beautiful book
 * "Programming with BASIC" by Byron S. Gottfried (1975, Italian edition)
 * and on the 1978 historical essay "BASIC Session" by Thomas E. Kurtz.
 * Ref. LBMAA-A-D Chapter 7, "Vectors and Matrices"> 
 ******************************************************************************/


/* MATbyK(result-matrix)
 * multiply a matrix by an expression, both taken from stream; read multiplier
 * and argument matrix from stream, multiply to the result matrix
 * varr: the result matrix code, checked into MATtype() and passed here. 
 * Ref. LBMAA-A-D 7.9, 7-4, "MAT C=(K)*A" */
void MATbyK(int varr){
	double exp=S();
	int var1=0,i=0,j=0,m=0,n=0,t=0;

	/* result matrix existence was checked into MATtype() */

	/* check syntax */
	if (*p++!= ')') perror_(35,l);
	if (*p++!= '*') perror_(35,l);
	
	/* get argument matrix code */
	if (varcheck(p,SIMPVAR)) var1=*p++;
	else if (varcheck(p,DOUBVAR)) var1=in(*(p),*(p+1)),p+=2;
	else perror_(42,l);

	/* check argument matrix existence, and if not, declare 
	 * Ref. LBMAA-A-D 7.1, 7-1 */
	if (!dim[var1].type) dimArray(var1,2,10,10);

	/* check dimensions validity */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)<\
			(dim[var1].row+1)*(dim[var1].col+1)) 
		perror_(76,l);

	/* redimension result matrix */
	m=dim[varr].row=dim[var1].row;
	n=dim[varr].col=dim[var1].col;
	t=dim[varr].type;

	/* perform multiplication by expression */
	/* Legal procedures for special cases:
	 * MAT A=(K)*A */
	i=1; j=(t==1)?0:1;
	while (i<=m) {
		setArrayVal(varr,t,i,j,exp*getArrayVal(var1,t,i,j));
		j++;
		if (j>n) {i++; j=(t==1)?0:1;}
	}
}


/* MATTRN(result-matrix)
 * The MAT TRN statement for transposing a matrix; read argument matrix from 
 * stream, transpose it to the result matrix 
 * varr: the result matrix, checked into MATtype() and passed here.
 * Ref. LBMAA-A-D 7.8, 7-4, "MAT C=TRN(A)" */
void MATTRN(int varr){
	int var1=0,i=0,j=0,t=0,t1=0,y=0;

	/* result matrix existence was checked into MATtype */

	/* get argument matrix code */
	if (*p++=='(') {
		if (varcheck(p,SIMPVAR)) var1=*p++;
		else if (varcheck(p,DOUBVAR)) var1=in(*(p),*(p+1)),p+=2;
		else perror_(42,l);
	}
	else perror_(35,l);

	t=dim[varr].type;
	t1=dim[var1].type;

	/* if origin is a vector and destination is a perpendicular vector
	 * or vice-versa, treat this as a special case */
	if (t+t1==3) {
		/* result is a vector, origin a horizontal vector */
		if (dim[varr].row && !dim[var1].row && dim[var1].col) {
			for (i=0;i<=dim[var1].col;i++)
				setArrayVal(varr,1,i,0,getArrayVal(var1,2,0,i));
		}
		/* result is a horizontal vector, origin a vector */
		else if (!dim[varr].row && dim[var1].row && dim[varr].col) {
			for (i=0;i<=dim[var1].row;i++)
				setArrayVal(varr,2,0,i,getArrayVal(var1,1,i,0));
		}
		return;
	}
	
	/* check argument matrix existence, and if not, declare 
	 * Ref. LBMAA-A-D 7.1, 7-1  */
	if (!dim[var1].type) dimArray(var1,2,10,10);

	/* check dimensions coherence */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)<\
			(dim[var1].row+1)*(dim[var1].col+1))
		perror_(76,l);

	/* Legal procedures for special cases:
	 * MAT C=TRN(C) 
	 * calculate values for result matrix and copy argument matrix to
	 * temporary matrix for enabling the legal case MAT C=TRN(C)
	 * Ref. LBMAA-A-D par. 7.8, page 7-4 */
	dimArray(TEMPVAR,t1,dim[var1].row,dim[var1].col);
	for(i=0;i<=dim[var1].row;i++) for(j=0;j<=dim[var1].col;j++)
		setArrayVal(TEMPVAR,t1,i,j,getArrayVal(var1,t1,i,j));

	/* redimension result matrix 
	 * Ref. LBMAA-A-D par. 7.8, page 7-4 */
	y=dim[var1].row;
	dim[varr].row=dim[var1].col;
	dim[varr].col=y;
	
	/* transpose argument matrix (previously copied over temporary) 
	 * to result matrix */
	i=(t==1)?0:1;
	while (i<=dim[varr].col) {
		j=1;
		while (j<=dim[varr].row) {
			setArrayVal(varr,t,j,i,getArrayVal(TEMPVAR,t1,i,j));
			j++;
		}
		i++;
	}

}


/* MATINV(result-matrix)
 * The MAT INV statement for inverting a matrix
 * Read parameters from the stream, setup parameters and pass them to 
 * matinvert(), the **real** matrix inverter. 
 * varr: the result matrix, checked into MATtype() and passed here.
 * Ref. LBMAA-A-D 7.10, 7-4, "MAT C=INV(A) and the DET Function" */
void MATINV(int varr){
	int var1=0;

	/* existence was checked into MATtype() */

	/* get argument matrix code */
	if (*p++=='(') {
		if (varcheck(p,SIMPVAR)) var1=*p++;
		else if (varcheck(p,DOUBVAR)) var1=in(*(p),*(p+1)),p+=2;
		else perror_(42,l);
	}
	else perror_(42,l);

	/* check argument matrix existence, and if not, declare 
	 * Ref. LBMAA-A-D 7.1, 7-1 */
	if (!dim[var1].type) dimArray(var1,2,10,10);

	/* check matrix coherence 
	 * Ref. LBMAA-A-D 7.10, 7-4 "...(A must be a square matrix)..." */
	if (dim[var1].type!=2) perror_(76,l);

	/* redimension result matrix if its dimensions are greater than
	 * matrix to invert; Ref. Gottfried, Example 7.21, where it's stated
	 * (adapted from Italian): "In line 90 [MAT R = INV(Q)] matrix R
	 * will be implicitly redimensioned and will become NxN, because
	 * the inverse of a matrix must have the same proportions of the
	 * starting matrix"; 
	 * Note: in the expression MAT C=INV(A) C may be a vector; as tested
	 * on the LCM, C is turned to square, provided it has sufficient
	 * space for the NxN elements;
	 * Note: MAT A=INV(A) is not reported in the LBMAA-A-D but it works
	 * on the LCM BASIC, so it is considered legal (no control) */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)>=\
			(dim[var1].row+1)*(dim[var1].col+1)) {
		dim[varr].type=2; // in case of a transformed vector
		dim[varr].row = dim[var1].row;
		dim[varr].col = dim[var1].col;
	}
	else perror_(76,l);
	
	/* delegate inversion */
	matinvert(varr,var1);
}


/* matinvert(result-matrix, argument-matrix)
 * Invert matrix 'argument' into matrix 'result' and calculate the determinant 
 * using the Gauss factorization scheme. Variables:
 * - varr: the unknown result global inverted matrix (NxN) in the BASIC code
 * - var1: the global knowns matrix to be inverted (NxN) in the BASIC code, it
 *    is used to form ma
 * ma is the local composed matrix (2NxN) (to the left the knowns matrix, to 
 *    the right the identity matrix); this matrix is invisible to BASIC
 * x is the local calculated inverted matrix (NxN), invisible to BASIC and 
 *    later copied back to varr. 
 * detValue is the global determinant value, visible to BASIC through DET.
 * Copyleft Antonio Maschio - March 2008 */
void matinvert(int varr, int var1) {
	int n = dim[var1].row, d=2*n+1; 	
	int i, j, k;
	double x[n+1][n+1],ma[n+1][d+1];
	double mul,piv;

	/* set determinant base multiplier */
	detValue=1.0;
	
	/* create composed matrix AI, with the same rows number of A,
	 * and twice the columns number of A; in the second half lies I */
	for (i=1;i<=n;i++) for(j=1;j<=n;j++) {
		ma[i][j]=getArrayVal(var1,2,i,j);
		/* setting I to all zeroes */
		ma[i][j+n+1]=0.0;
	}
	/* set diagonal of I to all ones */
	for (i=1;i<=n;i++) ma[i][i+n+1]=1.0;
	
	/* erase destination matrix */
	for (i=1; i<=n; i++) for (j=1; j<=n; j++) x[i][j]=0.0;
	
	/* Gauss factorization over AI with partial pivoting */
	for (k=1;k<n;k++) {
		piv=ma[k][k];
		if (!piv) {
			double maxx=0;
			int r=k;
			/* k is the row where pivot is zero
			 * now find the row where pivot is max */
			for (i=k+1;i<=n;i++) 
				if (maxx<fabs(ma[i][k])){ 
					maxx=ma[i][k]; 
					r=i; 
				}
			/* matrix is singular if r hasn't changed */
			if (r==k) { perror_(121,l); detValue=0; return; }
			/* exchange rows r and k */
			for (i=1;i<=d;i++) {
				maxx=ma[r][i];
				ma[r][i]=ma[k][i];
				ma[k][i]=maxx;
			}
			piv=ma[k][k];
			/* matrix is singular if pivot is still null */
			if (!piv) { perror_(121,l); detValue=0; return; }
			/* update determinant sign */
			detValue*=-1; 
		}
		/* update the rest of the rows */
		for (i=k+1;i<=n;i++) {
			mul=ma[i][k]/piv;
			for (j=k;j<=d;j++) ma[i][j]=ma[i][j]-mul*ma[k][j];
		} 
		
	}

	/* calculate determinant */
	for (i=1;i<=n;i++) detValue*=ma[i][i];
	
	/* check singularity; this should not be the case, since singularity
	 * should emerge from the calculation, but if, after all, determinant
	 * is null, print a message, to warn the user without stopping
	 * the program in any case 
	 * Note: in some cases (notably, for the inverse of test matrix 
	 * {1 2 3}{4,5,6}{7,8,9}) this algorithm returns determinant zero
	 * and therefore the matrix is singular (not invertible);
	 * the LCM algorithm instead returned determinant = -4.47035E-8
	 * and thus the matrix is absurdly composed of big big numbers.
	 * I take comfort from online matrix inversion algorithms (mainly
	 * matrix.reshish.com, www.quickmath.com, matrixcalc.org/en/), which
	 * don't return any inverted matrix because the determinant is null.
	 * The returned matrix so will be the zero matrix, because no value
	 * is set and all values are erased before calculating inverse */
	if (detValue==0.0) {
		perror_(121,l);
		return;
	}

	/* calculate the inverse of A through back-substitution */
	for (i=1;i<=n;i++) {
		x[n][i]=ma[n][i+n+1]/ma[n][n];
		for (j=n-1;j>=0;j--) {
			piv=0;
			for(k=j+1;k<=n;k++) piv+=ma[j][k]*x[k][i];
			x[j][i]=(ma[j][i+n+1]-piv)/ma[j][j];
		}
	}

	/* set varr to the resulting inverted matrix */
	for (i=0; i<=n; i++) for (j=0; j<=n; j++) 
		setArrayVal(varr,2,i,j,x[i][j]);
}


/* MATIDN(result-matrix)
 * The MAT IDN statement for setting a square array to identity matrix;
 * var: the code of the matrix to be IDNed (there is no argument matrix)
 * Note: as tested on the LCM, the IDN statement accepts forms of 
 * re-dimensioning like IDN(3), IDN(3,1), IDN(3,2) and IDN(2,3);
 * - in the first case, the zero vector is returned (it refers to col. 0); 
 * - in the second case, the vector is {1 0 0} (in vertical) because the first 
 * 	actual column is preserved;
 * - in case of IDN(3,2) the first two columns are taken {1 0 0 ; 0 1 0} 
 * 	(in vertical); 
 * - in the last case the 2x2 left matrix is IDNed, while the last column is 
 * 	preserved (with nulls) 
 * Ref. LBMAA-A-D 7.2, 7-2, "MAT C=ZER, MAT C=CON, MAT C=IDN" */
void MATIDN(int var){
	int m=0,n=0,t=0,q=0;
	int i=0,j=0;

	/* set array values */
	t=dim[var].type;
	m=dim[var].row;
	n=dim[var].col;

	/* result matrix existence was checked into MATtype() */

	/* use re-dimensioning data 
	 * Ref. LBMAA-A-D 7.2, 7-2 */
	if (*p=='(') {
		p++;
		m=(int)S();
		n=-1; // special flag value
		if (m<0) perror_(76,l);
		
		/* there's a second index: bidimensional array */
		if (*p==',') {
			if (dim[var].type==1) perror_(76,l);
			p++;
			n=(int)S();
			if (n<0) perror_(76,l);
		}
		else if (*p==')') p++;
		else perror_(76,l);
		
		/* check limits */
		if ((m+1)*(n+1)>((dim[var].brow+1)*(dim[var].bcol+1)))
			perror_(76,l);
		
		/* setup values for special definitions */
		if (t==2 && m && n==-1) n=m, m=0;
		if (t==2 && m && !n) t=1, n=0;
		if (n==-1) n=0;
		
		/* redimension */
		dim[var].row=m;
		dim[var].col=n;
		dim[var].type=t;
		q=m<n?m:n;	// sub-square value for non-square matrices
	}

	/* set values for IDN */
	for (i=0;i<=m;i++) for (j=0;j<=n;j++) setArrayVal(var,2,i,j,0.0);
	for (i=0;i<q;i++) setArrayVal(var,2,i+1,i+1,1.0);
}


/* MATZER(result-matrix, option-value)
 * The MAT ZER and MAT CON statements for setting (or resetting) an array to 
 * all zeroes (MAT ZER) or ones (MAT CON), depending on option value 'op' 
 * (0 for ZER, 1 for CON);
 * Note: as tested on the LCM, the ZER/CON statements accept forms of 
 * re-dimensioning like CON(0), CON(4), CON(0,4) and CON(4,0);
 * - in the first case, the vector is a one-element vector = 1;
 * - in the second case, the vector is {1 1 1 1} (in vertical) because the 
 * 	first actual column is preserved and set to ones; 
 * the case CON(0,4) it's a horizontal vector, which has the form {0 1 1 1 1}; 
 * the last case is equivalent to the second;
 * any other configurations like CON(m,n) are trivial
 * var: the code of matrix to be ZEROed
 * op: if TRUE perform CON, if FALSE perform ZER
 * Ref. LBMAA-A-D 7.2, 7-2, "MAT C=ZER, MAT C=CON, MAT C=IDN"  */
void MATZER(int var, double op){
	int t,m,n;
	int i,j;

	/* set array values */
	t=dim[var].type;
	m=dim[var].row;
	n=dim[var].col;

	/* result matrix existence was checked into MATtype() */
	
	/* use re-dimensioning data 
	 * Ref. LBMAA-A-D 7.2, 7-2  */
	if (*p=='(') {
		p++;
		m=(int)S();
		n=-1;
		if (m<0) perror_(76,l);
		
		/* second index? bidimensional array */
		if (*p==',') {
			if (dim[var].type==1) perror_(76,l);
			p++;
			n=(int)S();
			if (n<0) perror_(76,l);
		}
		else if (*p==')') p++;
		else perror_(76,l);
		
		/* check limits */
		if ((m+1)*(n+1)>((dim[var].brow+1)*(dim[var].bcol+1)))
			perror_(76,l);
		
		/* setup values for special definitions */
		if (t==2 && m && n==-1) n=m, m=0;
		if (t==2 && m && !n) t=1,n=0;
		if (n==-1) n=0;
		
		/* redimension */
		dim[var].row=m;
		dim[var].col=n;
		dim[var].type=t;
	}

	/* set values for ZER or CON */
	if (t==1) for (i=0;i<m;i++) setArrayVal(var,t,i+1,0,op);
	else for (i=0;i<m;i++) for (j=0;j<n;j++) 
		setArrayVal(var,t,i+1,j+1,op);
}


/* MATsum(result-matrix,matrix1,matrix2,option-value)
 * Add two matrices or subtract the second from the first.
 * varr: the result matrix code
 * var1: first matrix addendum
 * var2: second matrix addendum
 * op: if -1, do subtraction, if 1 do addition
 * Ref. LBMAA-A-D 7.6, 7-4, "MAT C=A+B and MAT C=A-B" */
void MATsum(int varr, int var1, int var2, int op){
	int i=0,j=0;
	int M=0, N=0, K=1;
	int T=dim[varr].type;
	int T1=dim[var1].type;
	int T2=dim[var2].type;
	
	/* existences of result matrix and of argument matrices var1 and var2 
	 * have already been checked into MATtype() */

	/* check matching of dimensions 
	 * Note: one can only sum vectors with vectors, matrices with
	 * matrices, and not use unidimensional vectors or
	 * degenerated matrices of one row or of one column */
	if (dim[var1].row!=dim[var2].row ||\
			dim[var1].col!=dim[var2].col)
		perror_(76,l);
	if (T1!=T2 || T!=T1 || T!=T2) perror_(76,l);

	/* Legal procedures for special cases:
	 * MAT A=A+B, A=A-B 
	 * MAT A=B+A, A=B-A (which should succeed for the same reasons)
	 * Ref. LBMAA-A-D 7.6, 7-4
	 * Unreported cases, but tested and working on the LCM:
	 * MAT A=A+A, A=A-A 
	 * (no control) */

	/* redimension result matrix
	 * Ref. LBMAA-A-D 7.6, 7-4 */
	if ((dim[var1].brow+1)*(dim[var1].bcol+1)>\
			(dim[varr].brow+1)*(dim[varr].bcol+1))
		perror_(76,l);
	else {
		M=dim[varr].row=dim[var1].row;
		N=dim[varr].col=dim[var1].col;
		T=dim[varr].type=dim[var1].type;
	}

	/* create dummy matrix dimensionally equal to varr */
	dimArray(TEMPVAR,T,M,N);
	
	/* if summing up vectors (vertical or horizontal), consider
	 * row/col at zero index */
	if (M && !N && T==1) K=0;
	else if (!M && N && T==2) K=0;

	/* perform sum and copy data back to varr;
	 * TEMPVAR serves as a buffer for not overwriting any values */
	i=K; j=K;
	while (i<=M) {
		setArrayVal(TEMPVAR,T,i,j,\
				getArrayVal(var1,T1,i,j)+\
				op*getArrayVal(var2,T2,i,j));
		setArrayVal(varr,T,i,j,getArrayVal(TEMPVAR,T,i,j));
		j++;
		if (j>N) {i++; j=(T==1)?0:1;}
	}

}


/* MATmul(result-matrix,matrix1,matrix2)
 * The cross-product between two matrices or vectors 
 * varr: the result matrix code
 * var1: first matrix 
 * var2: second matrix
 * Ref. LBMAA-A-D 7.7, 7-4, "MAT C=A*B" */
void MATmul(int varr, int var1, int var2){
	int i,j,k;
	int M=dim[varr].row;
	int Nr=dim[varr].col;
	int N=dim[var1].col;
	int P=dim[var2].col;
	int T=dim[varr].type;
	int T1=dim[var1].type;
	int T2=dim[var2].type;

	/* existences of result matrix and of argument matrices var1 and var2 
	 * have already been checked into MATtype() */

	/* instantiate temporary matrix with result matrix dimensions */
	dimArray(TEMPVAR,T,M,Nr);

	/* check dimensions validity */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)<\
			(dim[var1].row+1)*(dim[var2].col+1))
		perror_(76,l);

	/* redimension result matrix */
	dim[varr].row=dim[var1].row;
	dim[varr].col=dim[var2].col;
	
	 /* Legal procedures for special cases:
	 * MAT B=A*A 
	 * Ref. LBMAA-A-D 7.7, 7-4
	  *Unreported cases, but tested and working (though failing) on LCM:
	 * MAT A=A*B, A=B*A and A=A*A 
	 * Note: the fact these cases work on the LCM is not a testimonial 
	 * that results are correct (they are not, in effect); 
	 * but this is left to the user, I suppose.
	 * In any case, the use of TEMPVAR makes decb return correct
	 * results even in such cases! (no control) */

	/* perform cross multiplication and copy data back to varr 
	 * TEMPVAR serves as a buffer for not overwriting any values */
	if (T==2) {
		for(i=1;i<=M;i++) {
			for(j=1;j<=P;j++) {
				double res=0.0;
				for(k=1;k<=N;k++)
					res+=getArrayVal(var1,T1,i,k)*\
						getArrayVal(var2,T2,k,j);
				setArrayVal(TEMPVAR,T,i,j,res);
			}
		}
		for (i=1;i<=M;i++)  for (j=1;j<=P;j++)
			setArrayVal(varr,T,i,j,getArrayVal(TEMPVAR,T,i,j));
	}
	else if (T==1) {
		for(i=1;i<=M;i++) {
			double res=0.0;
			for(k=1;k<=N;k++)
				res+=getArrayVal(var1,T1,i,k)*\
					getArrayVal(var2,T2,k,0);
			setArrayVal(TEMPVAR,T,i,0,res);
		}
		for (i=1;i<=M;i++)
			setArrayVal(varr,T,i,0,getArrayVal(TEMPVAR,T,i,0));
	}
}



/* MATtype()
 * this function is invoked by parse when a MAT statement is met (other than 
 * MAT READ, MAT PRINT or MAT INPUT, which follow their way), to choose the 
 * correct command. 
 * Controls are done on result matrix (instantiating it if not existing), and
 * in case of addition, subtraction and multiplication between matrices, 
 * control is done on argument matrices; peculiar functions like IDN, CON,
 * ZER, INV and TRN check argument matrix on their own. 
 * Ref. LBMAA-A-D, Chapter 7, "Vectors and Matrices" 
 * System function for matrix management */
void MATtype(void) {
	int varr=0; 
	int var1=0;
	int var2=0;
	int op=0;

	/* get result matrix code */
	if (varcheck(p,SIMPVAR)) varr=*p++;
	else if (varcheck(p,DOUBVAR)) varr=in(*(p),*(p+1)), p+=2;
	else perror_(42,l);

	if (*p++!='=') perror_(35,l);
	
	/* mat operations */
	if (varcheck(p,SIMPVAR) || varcheck(p,DOUBVAR)) {
		/* get first matrix operand code */
		if (varcheck(p,SIMPVAR)) var1=*p++;
		else if (varcheck(p,DOUBVAR)) var1=in(*(p),*(p+1)), p+=2;
		else perror_(42,l);
		
		/* check existence, otherwise set a 10x10 matrix
		 * Ref. LBMAA-A-D 7.1, 7-1 */
		if (dim[var1].type==0) dimArray(var1,2,10,10);
		
		/* perform the simple copy (no operators)
		 * Ref. LBMAA-A-D 7.5, 7-4 */
		if (!*p) matCopy(varr, var1);
		/* perform the matrix operations */
		else {
			/* get op */
			if (*p!='+' && *p!='-' && *p!='*' && *p!='\0') 
				perror_(35,l);
			else op=*p++;
			
			/* get second matrix operand code */
			if (op!='\0') {
				if (varcheck(p,SIMPVAR)) var2=*p++;
				else if (varcheck(p,DOUBVAR)) 
					var2=in(*(p),*(p+1)), p+=2;
				else perror_(42,l);
			}
			
			/* check existence, otherwise set a 10x10 matrix
			 * Ref. LBMAA-A-D 7.1, 7-1 */
			if (dim[var2].type==0) dimArray(var2,2,10,10);
			
			/* check existence of result numeric matrix, 
			 * otherwise set a 10x10 matrix 
			 * Ref. LBMAA-A-D 7.1, 7-1) */
			if (dim[varr].type==0) {
				dimArray(varr,2,10,10);
				/* redimension undeclared result matrix 
				 * in case of multiplication */
				if (op=='*') {
					dim[varr].row=dim[var1].row;
					if (dim[var2].type==1) {
						dim[varr].type=1;
						dim[varr].col=0;
					}
					else dim[varr].col=dim[var2].col;
				}
			}
			
			/* perform numerical operations */
			     if (op=='-') MATsum(varr, var1, var2, -1);
			else if (op=='+') MATsum(varr, var1, var2, 1);
			else if (op=='*') MATmul(varr, var1, var2);
			else perror_(35,l);
		}
	}
		
	/* mat functions */
	else {
		/* check existence of result numeric matrix, 
		 * otherwise set a 10x10 matrix 
		 * Ref. LBMAA-A-D 7.1, 7-1) */
		if (dim[varr].type==0) dimArray(varr,2,10,10);
		     if (!strncmp(p,"ZER",3)) p+=3, MATZER(varr,0.0);
		else if (!strncmp(p,"CON",3)) p+=3, MATZER(varr,1.0);
		else if (!strncmp(p,"TRN",3)) p+=3, MATTRN(varr);
		else if (!strncmp(p,"IDN",3)) p+=3, MATIDN(varr);
		else if (!strncmp(p,"INV",3)) p+=3, MATINV(varr);
		else if (*p=='(') p++, MATbyK(varr);
		else perror_(35,l);
	}
}


/* matCopy(result-matrix, argument-matrix)
 * copy source argument matrix into destination result matrix;
 * dst: destination matrix
 * src: source matrix
 * Automatic redimension is performed in case target matrix can hold argument 
 * matrix dimensions.
 * Ref. LBMAA-A-D 7.5, 7-4, "MAT B=A" */
void matCopy(int dst, int src){
	int i,j;
	/* source data */
	int ms=dim[src].row;
	int ns=dim[src].col;
	int ts=dim[src].type;
	/* destination data */
	int MD=dim[dst].row;
	int ND=dim[dst].col;
	int TD=dim[dst].type;

	/* existence of argument matrix var1 has already 
	 * been checked into MATtype() */

	/* check immediate compatibility */
	if (dst==src) return;
	if (ts!=TD || ts==0 || TD==0) perror_(76,l);
	
	/* redimension 
	 * Ref. LBMAA-A-D 7.5, 7-4 */
	if (ms!=MD || ns!= ND) {
		if ((MD+1)*(ND+1)<=(dim[src].brow+1)*(dim[src].bcol+2)) {
			dim[dst].row=dim[src].row;
			dim[dst].col=dim[src].col;
			MD=dim[dst].row;
			ND=dim[dst].col;
		}
		else perror_(76,l);
	}
	
	/* check compatibility */
	if (ms!=MD || ns!=ND) perror_(76,l);

	/* copy (copy column 0 and row 0 too!) */
	if (ts==2) for (i=0;i<=ms;i++) for (j=0;j<=ns;j++)
		setArrayVal(dst,TD,i,j,getArrayVal(src,ts,i,j));
	else if (ts==1) for (i=0;i<=ms;i++)
		setArrayVal(dst,TD,i,0,getArrayVal(src,ts,i,0));
}


/* MATINPUT()
 * The MAT INPUT statement
 * mode 1 is for numerical matrices, mode 2 for string matrices.
 * Multiple-matrices input enabled 
 * Note: MAT INPUT does not treat more than one array per statement
 * Ref. LBMAA-A-D 7.4, 7-3, "MAT INPUT V and the NUM function"
 * Ref. LBMAA-A-D 8.1, 8-1, "Reading and printing strings" */ 
void MATINPUT(void) {
	char line[COMPSCR], *u=line;
	int done=1,mode=0,M=0,N=0,T=0,var=0; // mode=1=numbers, mode=2=strings
	int Mb=0, Nb=0, nVb=0.0; // in case of re-request, store index values
	double val=0.0, extraS=0.0;

	/* get timer (exclude user delay from timing) - tested */
        gettimeofday(&tv, NULL);
       	extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);

	/* get array type */
	while (isblank(*u)) u++;
	if (varcheck(p,SIMPVAR)) var=*p++, mode=1;
	else if (varcheck(p,DOUBVAR)) var=in(*p,*(p+1)), p+=2, mode=1;
	else if (varcheck(p,SIMPSTR)) var=*p, p+=2, mode=2;
	else if (varcheck(p,DOUBSTR)) var=in(*p,*(p+1)), p+=3, mode=2;
	else perror_(42,l);

	/* check existence of argument matrices */
	/* numeric variables */
	if (mode==1) {
		/* check existence, otherwise set a 10x10 matrix
		 * Ref. LBMAA-A-D 7.1, 7-1 */
		if (dim[var].type==0) dimArray(var,2,10,10);
	}
	/* string variables */
	else if (mode==2) {
		/* check existence, otherwise set a 10 string vector
		 * Ref. LBMAA-A-D 8.1, 8-1 */
		if (dimS[var].type==0) dimStrArray(var,1,10,0);
	}

	/* set up starting values */
	if (mode==1) T=dim[var].type;
	else T=dimS[var].type;
	numValue=nVb=0; M=Mb=1; N=Nb=1;
	if (mode==1 && T==2 && !dim[var].row && dim[var].col) M=0;

redo:
	/* get user input */
	*u='\0';
	fprintf(stdout," ?");
	strncpy_(line,getString(),COMPSCR);
	if (strlen(line)>MAXSTRLEN) perror_(180,l);
	
	do {
		/* INPUT from keyboard a numerical vector
		 * REf. LBMAA-A-D 7.4, 7-4 */
		if (mode==1 && T==1 && *u) do {
			/* asking for more in case of ampersand
			 * Ref. LBMAA-A-D 7.4, 7-3 */
			while (isblank(*u)) u++;
			if (*u=='&') {
				fprintf(stdout," ?");
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				Mb=M;
				Nb=N;
				nVb=numValue;
			}
			while (isblank(*u)) u++;
			if (!*u) break;
			else if (M>dim[var].row) break;
			val=strtod(u,&u);
			if (val>INFF || val<MINFF) done=0; // tested
			else {
				setArrayVal(var,T,M,0,val);
				M++;
				numValue++;
				if (*u==',') u++;
			}
		} while (TRUE && done);
		/* INPUT from keyboard a numerical array 
		 * Note: as tested on the LCM, the MAT INPUT for a
		 * matrix works in this way: first item is attributed
		 * to element at pos (1,1), the remaining are lined in memory
		 * consecutively, including item at pos (X,0)
		 * Note: M and N are variables that go through the whole
		 * matrix/vector.
		 * REf. LBMAA-A-D 7.4, 7-4 */
		else if (mode==1 && T==2 && *u) do {
			while (isblank(*u)) u++;
			/* asking for more in case of ampersand
			 * Ref. LBMAA-A-D 7.4, 7-3 */
			if (*u=='&') {
				fprintf(stdout," ?");
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				Mb=M;
				Nb=N;
				nVb=numValue;
			}
			while (isblank(*u)) u++;
			if (!*u) break;
			else if (N>dim[var].col) {
				N=0; // tested
				M++;
				if (M>dim[var].row) break;
			}
			val=strtod(u,&u);
			if (val<MINFF || val > INFF) done=0;
			else {
				setArrayVal(var,T,M,N,val);
				N++;
				numValue++;
				if (*u==',') u++;
			}
		} while (TRUE && done);
		/* INPUT from keyboard a string array 
		 * Ref. LBMAA-A-D 8.1, 8-1 */
		else if (*u) do {
			char op[MAXSTRLEN+1], *P1;
			N=0, P1=op, *P1='\0';
			while (isblank(*u)) u++;
			/* asking for more in case of ampersand
			 * Ref. LBMAA-A-D 8.1, 8-1 
			 * Ref. LBMAA-A-D 8.1, 8-1 "A comma must precede the
			 * ampersand if the string immediately before the
			 * ampersand is unquoted." */			
			if (*u=='&') {
				fprintf(stdout," ?");
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				Mb=M;
				Nb=N;
				nVb=numValue;
			}
			while (isblank(*u)) u++;
			if (!*u) break;
			else if (M>dimS[var].row) break;
			/* grab next input string until comma */
			if (*u!='\"') {
				while (*u && *u!=',')  // no ampersand
					if (isCap) *P1++=toupper(*u++);
					else *P1++=*u++;
				*P1='\0';
			}
			/* grab next input string until closing quotes */
			else {
				u++;
				while (*u && *u!='\"') {
					if (isCap) *P1++=toupper(*u++);
					else *P1++=*u++;
				}
				*P1='\0';
				if (*u!='\"') done=0;
				else {
					if (*u=='&') *--u=',';
					while (isblank(*u)) u++;
				}
			}
			if (done) {
				setArrayStr(var,T,M,0,op);
				M++;
				numValue++;
				if (*u==',') u++;
			}
			
		} while (TRUE && done);

		/* as tested on the LCM, MAT INPUT accepts only the exact 
		 * number of items or less, and issues an error message if they 
		 * are more than needed */
		if (done && *u) done=999;
	} while (*p++==',' && done);

	/* redo in case of any mistaken input, resetting parameters */
	if (!done || done==999) {
		if (!done) fprintf(stdout, "\n%s\n", error[91]);
		else if (done==999) fprintf(stdout, "\n%s\n", error[128]);
		/* reset values for repeating */
		u=line;
		done=1;
		M=Mb;
		N=Nb; 
		numValue=nVb;
		goto redo;
	}

	/* reset printing position */
	channel[0].fprintn=channel[0].fcounter=0;

	/* get timer (exclude user delay from timing) */
        gettimeofday(&tv, NULL);
       	extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0)-extraS;
	beginS=beginS+extraS;
}


/* MATREAD()
 * The MAT READ statement-
 * Multiple-matrices reading enabled 
 * Ref. LBMAA-A-D 7.1, 7-1, "MAT Instruction Conventions"
 * Ref. LBMAA-A-D 8.1, 8-1 "Reading and printing strings" */
void MATREAD(void){
	int var=0, m=0, n=0, mode=0;
	
	/* there must be something to read! */
	if (!isalpha(*p)) perror_(35,l); // tested

	/* start loop on all MAT READ arrays */	
	do {
		/* get variable code */
		if (varcheck(p,SIMPVAR) || varcheck(p,SIMPARR)) var=*p++;
		else if (varcheck(p,DOUBVAR) || varcheck(p,DOUBARR)) 
			var=in(*(p),*(p+1)),p+=2;
		else if (varcheck(p,SIMPSTR) || varcheck(p,SIMPSTRARR)) 
			var=*p, p+=2, mode=1; 
		else if (varcheck(p,DOUBSTR) || varcheck(p,DOUBSTRARR)) 
			var=in(*p,*(p+1)),p+=3, mode=1; 
		else perror_(65,l,makechar(p+1),TERMINAT); // tested

		/* READ numerical array 
		 * Ref. LBMAA-A-D 7.1, 7-1 */
		if (!mode) {
			if (dataLimit==0) perror_(50,l);
			/* check existence, otherwise set a 10x10 matrix
			 * Ref. LBMAA-A-D 7.1, 7-1 */
			if (dim[var].type==0) dimArray(var,2,10,10);
		
			/* use explicit re-dimensioning data 
			 * Ref. LBMAA-A-D 7.1, 7-1 */
			if (*p=='(') {
				p++;
				m=(int)S();
				if (m<=0) perror_(76,l);
	
				/* there's a second index: 
				 * bidimensional array */
				if (*p==',') {
					if (dim[var].type==1) perror_(76,l);
					p++;
					n=(int)S();
					if (n<=1) perror_(76,l);
				}
				else if (dim[var].type==2) perror_(76,l);
	
				/* redimension a MxN matrix */ 
				if (m>1 && n>0) {
					if ((m+1)*(n+1)>(dim[var].bcol+1)*\
							(dim[var].brow+1))
						perror_(76,l);
					else {
						dim[var].row=m;
						dim[var].col=n;
					}
				}
				/* redimension a matrix specified by 1 
				 * argument from MxN matrix to vector */
				else if (m>1 && !n && dim[var].type==2) {
					if (m+1>(dim[var].brow+1)*\
							(dim[var].bcol+1)) 
						perror_(76,l);
					else dim[var].row=m, dim[var].type=1;
				}
				/* redimension a vector */
				else if (m>1 && !n && dim[var].type==1) {
					if (m+1>(dim[var].brow+1))
						perror_(76,l);
					else dim[var].row=m;
				}
				else perror_(35,l);

				if (*p++!=')') perror_(35,l);
			}
	
			/* use implicit data */
			else if (*p=='\0' || *p==',') {
				m=dim[var].row;
				n=dim[var].col;
			}
			else perror_(35,l);
	
			/* assign DATA values */
			matReadAssign(var,dim[var].type,m,n);	
	
		} 
		/* READ string array 
		 * Ref. LBMAA-A-D 8.1, 8-1 */
		else {
			int w;
			if (dataLimitS==0) perror_(50,l);
			
			/* check existence otherwise set a 10 string vector 
			 * Ref. LBMAA-A-D 8.1, 8-1 */
			if (dimS[var].type==0) dimStrArray(var,1,10,0);
		
			/* use explicit re-dimensioning data */
			if (*p=='(') {
				p++;
				m=(int)S();
				if (m<=0) perror_(76,l);
	
				/* redimension */ 
				if ((m+1)>(dimS[var].brow+1)) perror_(76,l);
				else dimS[var].row=m;
				if (*p++!=')') perror_(35,l);
			}
	
			/* use implicit data */
			else if (!*p || *p==',') m=dimS[var].row;
			else perror_(35,l);

			/* assign string values */
			for(w=1;w<=m;w++) {
				if (dcs>dataLimitS) perror_(110,l);
				setArrayStr(var,1,w,0,DS[dcs++]);
			}
		}	
	} while (*p++==',');
}


/* MATPRINT()
 * The MAT PRINT statement - rewritten April 2014 
 * Multiple-matrices printing enabled 
 * Ref. LBMAA-A-D 7.3, 7-3, "MAT PRINT A"
 * Ref. LBMAA-A-D 8.1, 8-1, "Reading and printing strings" */
void MATPRINT(int ch) {
	int var=0, m=0, n=0, t=0;	// matrix data
	int mode=0, ma;			// mode=1=string array, ma=margin
	int i,j;			// counters
	int isReduced=FALSE;		// flag for explicit re-dimensioning

	/* resolve irregular format (tested) */
	if (!isalpha(*p)) perror_(35,l);

	/* get variable codes */
	if (varcheck(p,SIMPSTRARR)) var=*p, p+=2, mode=1;
	else if (varcheck(p,DOUBARR)) var=in(*(p),*(p+1)),p+=2;
	else if (varcheck(p,SIMPARR)) var=*p++;
	else if (isalpha(*p) && isdigit(*(p+1))) {
		var=in(*(p),*(p+1)),p+=2;
		if (*p=='$') p++, mode=1;
	}
	else if (isalpha(*p) && *p=='$') var=*p, p+=2, mode=1;
	else if (isalpha(*p) && isalpha(*(p+1))) var=*p++;
	else if (varcheck(p,SIMPSTR)) var=*p, p+=2, mode=1;
	else if (varcheck(p,DOUBSTR)) var=in(*p,*(p+1)), p+=3, mode=1;
	else if (varcheck(p,DOUBVAR)) var=in(*(p),*(p+1)),p+=2;
	else if (varcheck(p,SIMPVAR)) var=*p++;
	else perror_(42,l);

	/* dimension if undeclared
	 * REF. LBMAA-A-D 7.1, 7-2 and 8.1, 8-2 */
	if (!dimS[var].type && mode) dimStrArray(var,1,10,0);
	if (!dim[var].type && !mode) dimArray(var,2,10,10);

	/* a void line BEFORE the matrix - tested */
	FCR(ch); 

	/* PRINT a string array
	 * REF. LBMAA-A-D 8.1, 8-2 */
	if (mode) {
		int w;
	
		/* store basic data */
		t=dimS[var].type;
		m=dimS[var].row;
		n=0; 
		ma=channel[ch].margin;
		if (t!=1) perror_(76,l);

		/* explicit re-dimensioning 
		 * Note: explicit re-dimensioning is not quoted in par. 8.1 nor
		 * elsewhere in the LBMAA-A-D but was tested on the LCM */
		if (*p=='(') {
			p++;
			m=(int)S();
			if (m<0) perror_(76,l);
			if (!*p) perror_(65,l,FFLFVT,")");
			if (*p!=')') perror_(65,l,makechar(p),")");
			else p++;
			if (m+1<=dim[var].brow+1) {
				dimS[var].row=m;
				dimS[var].col=0;
			}
			else perror_(76,l);
		}

		FCR(ch);
		
		/* cycle all elements */
		for (w=1; w<=m; w++) {
			/* print in column */
			if (!*p) {
				printContained(ch,getArrayStr(var,1,w,0),ma);
				FCR(ch);
			}
			/* print in zones */
			else if (*p==',') {
				printContained(ch,getArrayStr(var,1,w,0),ma);
				while (channel[ch].fcounter%ZONE) FAC(ch);
				if (channel[ch].fcounter>channel[ch].margin-ZONE) FCR(ch);
			}
			/* print contiguously */
			else printContained(ch,getArrayStr(var,1,w,0),ma);
		}
		/* separate tables */
		FCR(ch);
		if (*p==',') FCR(ch);
		if (*p==',' || *p==';') p++;
		
		/* if there's something else to print, recall MATPRINT again */
		if (*p) MATPRINT(ch);
		/* or else end up here */
		return;
	}

	/* PRINT a numerical array/matrix
	 * REF. LBMAA-A-D 7.1, 7-2 */

	/* get matrix/vector elements */
	t=dim[var].type;
	m=dim[var].row;
	n=dim[var].col;
	
	/* Use explicit re-dimensioning data if required;
	 * Note: explicit re-dimensioning is not quoted in par. 7.1 nor
	 * elsewhere in the LBMAA-A-D but was tested on the LCM; as tested, 
	 * the redefinition may convert a matrix into a vector */
	if (*p=='(') {
		p++; // skip '('
		m=(int)S();
		if (m<0) perror_(76,l);
		n=-1;
		if (*p==',') {
			p++; // skip comma
			n=(int)S();
			if (n<0) perror_(76,l);
		}
		if (*p!=')') perror_(65,l,FFLFVT,")"); // tested 
		p++; // skip ')'
		/* index inversion for matrices identified by 1-index */
		if (t==2 && m && n==-1) n=m, m=0;
		/* index setting for pseudo-vectors */
		if (t==2 && !n && m) n=0, t=1;
		/* redimension */
		if ((m+1)*(n+1)>(dim[var].brow+1)*(dim[var].bcol+1)) 
			perror_(76,l);
		dim[var].col=n;
		dim[var].row=m;
		dim[var].type=t;
		isReduced=TRUE;
	}

	/* extra starting void line in case of normal matrix/vector */
	if (!isReduced) FCR(ch);
	
	/* print vector (integral or reduced) */
	if (t==1) {
		int aCapo=FALSE;
		/* Note: the LCM BASIC prints a reduced vector in one line, but 
		 * the vector remains a vector and is printed in vertical on 
		 * subsequent processes, thus the use of aCapo */
		if (!*p && !isReduced) aCapo=TRUE;
		if (isReduced && *p) perror_(35,l); // tested 
		i=0;
		do {
			channel[ch].fcounter=\
				printNUM(ch,getArrayVal(var,t,i+1,0),0,NULL);
			if (*p==',') while (channel[ch].fcounter%ZONE) FAC(ch);
			if (channel[ch].fcounter>channel[ch].margin-ZONE) 
				FCR(ch);
			if (aCapo) FCR(ch);
			i++;
		} while (i<m);
		if (!aCapo) FCR(ch);
		FCR(ch);
		FCR(ch);
	}
	/* print matrix/horizontal vector (integral or reduced) */
	else {
		/* k here acts an index adder: if matrix is a full matrix,
		 * it makes start count=1 (the index for MAT statements);
		 * otherwise, in case of horizontal matrices (or matrices
		 * specified by means of 1 index only), it makes start
		 * count=0 (0th row is the only row which is printed) */
		int k=1;
		if (isReduced && *p) perror_(35,l); // tested
		if (!m && n) k=0;
		i=0;
		do {
			j=0;
			do {
				channel[ch].fcounter=printNUM(ch,getArrayVal(var,t,i+k,j+1),0,NULL);
				if(channel[ch].fcounter>channel[ch].margin-ZONE)
					FCR(ch);
				if((*p==',' || !*p) && !isReduced) 
					while (channel[ch].fcounter%ZONE) 
						FAC(ch);
				if(channel[ch].fcounter>channel[ch].margin-ZONE)
					FCR(ch);
				j++;
			} while (j<n);
			FCR(ch);
			FCR(ch); // both required 
			i++;
		} while (i<m);
		if (*p==',' || isReduced) FCR(ch);
	}
	
	/* if there's something else to print, recall MATPRINT again */
	if (*p==',' || *p==';') p++;
	if (*p) MATPRINT(ch);
}


/****************************************************************************** 
 * The following routines define the behavior of the statements involved with 
 * arrays, the DIM statement and the CHANGE statement;
 * the DIM statement for numerical arrays was included since 1964 version II
 * of the Dartmouth BASIC, and for strings since 1967 version IV; the CHANGE
 * statement was included since 1967 version IV (not including the add-on
 * variation CHANGE..TO..BIT, which appeared in 1969 version V). 
 ******************************************************************************/


/* CHANGE() 
 * The CHANGE statement
 * convert the explicit string (a variable or a constant enclosed into 
 * parentheses) to the series of ASCII character it's composed of, and store it 
 * into the vector specified after TO;
 * convert also the vector which holds the string data to the string variable
 * specified after TO. 
 * The vector need not to be dimensioned if the string is shorter than 10 
 * characters (pos. 0 holds the length, pos. 1 through 10 hold the string), but
 * if it's longer it must be declared, otherwise an error will be raised.
 * Ref. LBMAA-A-D 8.4, 8-3, "The CHANGE Statement" */
void CHANGE(void) {
	char op[MAXSTRLEN+1], *P1=op;
	int var=0, varS=0, len;

	/* check general syntax */
	if(check(p,"TO")); else perror_(37,l);

	/* in case first argument is a numerical variable (which stands for 
	 * the array name) perform CHANGE vector TO string */
	if (varcheck(p,SIMPVAR) || varcheck(p,DOUBVAR)) {
		int c,val;

		/* get var name */
		if (varcheck(p,SIMPVAR)) var=*p, p++;
		else var=in(*p,*(p+1)), p+=2;

		/* check vector existence and dimension 
		 * (only unidimensional vectors are valid) */
		if (dim[var].type==2) perror_(62,l);
		else if (dim[var].type!=1) dimArray(var,1,10,0);

		/* check syntax */
		if (strncmp(p," O",2)) perror_(38,l);
		p+=2;

		/* get string name */
		if (varcheck(p,SIMPSTR)) varS=*p;
		else varS=in(*p,*(p+1));

		/* instantiate string name if it's void */
		if (PS[varS]!=NIL) free(PS[varS]);
		PS[varS]=malloc(MAXSTRLEN+1);
		if (!PS[varS]) perror_(191,l);
		
		/* fill string if len was correct
		 * (in general, error 90 depends on a file corruption) */
		len=(int)getArrayVal(var,1,0,0);
		if (len>=MAXSTRLEN) len=MAXSTRLEN;
		else if (len<=0) perror_(90,l);
		for (c=0; c<len; c++) {
			val=getArrayVal(var,1,c+1,0);
			/* Note; illegal character is a negative val, here.
			 * I do this to let build strings like A$+CHR(13) */
			if (val<0) perror_(87,l);
			*(PS[varS]+c)=val;
		}
		*(PS[varS]+len)='\0';
	}
	
	/* otherwise perform CHANGE string TO vector */
	else {
		int i=0;
		/* store string */
		*P1='\0';
		strncpy_(op,SS(),COMPSTR);
		len=strlen(op);
	
		/* check syntax */
		if (strncmp(p," O",2)) perror_(38,l);
		p+=2;
		
		/* get vector code */
		if (varcheck(p,SIMPVAR)) var=*p;
		else if (varcheck(p,DOUBVAR)) var=in(*(p),*(p+1));
		else perror_(62,l);

		/* check vector existence and dimension 
		 * (only unidimensional vectors are valid) */
		if (dim[var].type==2) perror_(76,l);
		else if (dim[var].type!=1) dimArray(var,1,10,0);
		if (len>dim[var].row) perror_(106,l);
	
		/* do the string conversion, storing in 0 string length */
		setArrayVal(var,1,i++,0,len);
		while (*P1) setArrayVal(var,1,i++,0,*P1++);
	}
}


/* DIM()
 * The DIM statement 
 * Note: since DIM is preprocessed by preParse(), and thus cannot use any
 * variable indexing (because variable are not initialized yet!), only numbers 
 * and not variables (or algebraic entities) must be used in the DIM statement; 
 * this is the very same behaviour of the DEC-20 basic. Besides, since it is 
 * never executed in runtime, the line number is not known, and it must be 
 * passed as argument (l)
 * l: the current line that preParse() is analyzing.
 * Ref. LBMAA-A-D 3.1, 3-1, "The Dimension Statement (DIM)"
 * see also Ref. LBMAA-A-D 7.2, 7-2 (MAT instructions) 
 * see also Ref. LBMAA-A-D 8.2, 8-2 (string instructions) */
void DIM(int l){
	char *pp=p;
	int mode;

	while (*pp) {
		int var=0, M=0, N=0, T=1;
		mode=0; // 0=numbers, 1=strings

		/* take var index */
		if (varcheck(pp,SIMPARR)) var=*pp++;
		else if (varcheck(pp,DOUBARR)) var=in(*pp,*(pp+1)), pp+=2;
		else if (varcheck(pp,SIMPSTRARR)) var=*pp, pp+=2, mode=1;
		else if (varcheck(pp,DOUBSTRARR)) 
			var=in(*pp,*(pp+1)), pp+=3, mode=1;
		else if (*pp=='\'') break;
		else perror_(42,l);

		/* DIM numerical arrays */
		if (!mode) {
			/* get M (and N) */
			if (*pp!='(') perror_(35,l);
			pp++; // skip '('
			M=strtol(pp,&pp,10);
			if (M<0) perror_(76,l);
			if(*pp==',') {
				pp++; // skip ','
				N=strtol(pp,&pp,10);
				if (N<0) perror_(76,l);
				T=2;
			}

			if (!M && N) T=2;
			else if (M && !N) T=1;

			/* check syntax */
			if (*pp!=')') perror_(35,l); // tested
			else pp++;
			if (dim[var].type) perror_(63,l);
			if (dim[var].type==1 && T==2) perror_(64,l);
			dimArray(var,T,M,N);
		}
		/* DIM string arrays */
		else if (mode==1) {
			/* get M */
			if (*pp!='(') perror_(35,l);
			pp++; // skip '('
			M=strtol(pp,&pp,10);
			if (M<0) perror_(76,l);
			/* check syntax */
			if (dimS[var].type) perror_(63,l);
			if (*pp==',') perror_(57,l); // 2-dim array
			if (*pp!=')') perror_(35,l); // tested
			else pp++;
			dimStrArray(var,T,M,N);
		}
		if (*pp==',') pp++;
	}
}


/******************************************************************************
 * The following routines define the remaining standard BASIC statements
 * generally present in BASIC since 1964 (apart from PRINT, which has been
 * reunited with PRINT#/WRITE#)
 ******************************************************************************/


/* INPUT()
 * The INPUT statement
 * Ref. LBMAA-A-D 6.2, 6-4, "INPUT Statement"
 * Ref. LBMAA-A-D 8.2, 8-2, "String Conventions" */
void INPUT(void) {
	char line[COMPSCR], *u=line, *pb=p;
	int done=1, var=0;
	double val=0.0, extraS=0.0;

	/* get timer (exclude user delay from timing) - tested */
        gettimeofday(&tv, NULL);
       	extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);

	/* check syntax of first term - all variables are accepted */
	if (varCode(p) > DOUBSTRARR) perror_(38,l);
	
redo:
	/* get user input */
	*u='\0';
	fprintf(stdout," ?");
	strncpy_(line,getString(),COMPSCR);
	if (strlen(line)>MAXSTRLEN) perror_(180,l);

	/* repeat for all variables */
	do {
		if (*p==',') p++;
		/* check syntax */
		if (varCode(p) > DOUBSTRARR) perror_(38,l);


		/* Note: in the following cases, for numerical variables
		 * and numerical arrays, I use strtod() instead of S() 
		 * because the LBMAA-A-D manual, 6.2, 6-4/5, states that only
		 * numbers may be input, with no more than 8 digits (in reality 
		 * the LCM can handle numbers at any length, and so does decb: 
		 * input numbers may exceed the 8 digits) */

		/* INPUT numerical vars A..Z/A0..Z9 
		 * Ref. LBMAA-A-D 6.2, 6-4 */
		if (varcheck(p,SIMPVAR) || varcheck(p,DOUBVAR)) {
			while (isblank(*u)) u++;
			if (isdigit(*u) || *u=='.' || *u=='-' || *u=='+') {
				char *pp=p;
				p=u;
				val=strtod(p,&u);
				if (val>INFF || val<MINFF) done=0; // tested
				else if (*u && *u!=',') done=0; 
				else {
					p=pp;
					p=setINPUTnum(p,val);
					if (*u==',') u++;
					while (isblank(*u)) u++;
					if (*u==',') u++;
				}
			}
			else done=0;
		}
		/* INPUT numerical arrays 
		 * Note: in the LBMAA-A-D there is no example about
		 * INPUT with array numerical variables */
		else if (varcheck(p,DOUBARR) || varcheck(p,SIMPARR)) {
			while (isblank(*u)) u++;
			if (isdigit(*u) || *u=='.' || *u=='-' || *u=='+') {
				char *pp=p;
				p=u;
				val=strtod(p,&u);				
				if (val>INFF || val<MINFF) done=0; // tested 
				else if (*u && *u!=',') done=0; 
				else {
					p=pp;
					p=setINPUTarray(p,val);
					if (*u==',') u++;
					while (isblank(*u)) u++;
					if (*u==',') u++;
				}
			}
			else done=0;
		}
		/* INPUT string variables and string arrays 
		 * Ref. LBMAA-A-D 8.2, 8-2 */
		else if (varcheck(p,SIMPSTR) || varcheck(p,DOUBSTR)
			|| varcheck(p,SIMPSTRARR) || varcheck(p,DOUBSTRARR)) {
			char op[MAXSTRLEN+1], *P1=op;
			*P1='\0';
			while (isblank(*u)) u++;
			/* grab string until comma */
			if (*u!='\"') {
				while (*u && *u!=',') *P1++=*u++;
				*P1='\0';
			}
			/* grab string until closing quotes */
			else {
				u++;
				while (*u && *u!='\"') *P1++=*u++;
				*P1='\0';
				if (*u=='\"') u++;
			}
			/* store assignment into variables */
			if (varcheck(p,SIMPSTR)) {
				int lk;
				var=(int)*p;
				lk=strlen(op)+1;
				if (PS[var]!=NIL) free(PS[var]);
				PS[var]=malloc(lk);
				if (!PS[var]) perror_(191,l);
				*PS[var]='\0';
				strncpy_(PS[var],op,lk);
			}
			else if (varcheck(p,DOUBSTR)) {
				int lk;
				var=in(*p,*(p+1));
				lk=strlen(op)+1;
				if (PS[var]!=NIL) free(PS[var]);
				PS[var]=malloc(lk);
				if (!PS[var]) perror_(191,l);
				*PS[var]='\0';
				strncpy_(PS[var],op,lk);
			}
			/* or into string arrays */
			else if (varcheck(p,SIMPSTRARR)) {
				int M=0;
				var=*p; p+=3;
				M=S();
				setArrayStr(var,1,M,0,op);
			}
			else if (varcheck(p,DOUBSTRARR)) {
				int M=0;
				var=in(*p,*(p+1)); p+=4;
				M=S();
				setArrayStr(var,1,M,0,op);
			}
			else done=0;
			while (*u && *u!=',') u++;
			if (*u==',') u++;
			while (isblank(*u)) u++;
			while (*p && *p!=',') p++;
		}
		while(isblank(*p)) p++;
		/* if user input is over, but there are still variables
		 * to be filled, get another user input */
		if (*p && !*u && done) {
			int i;
			u=line;
			for(i=0;i<SCREENLINE;i++) line[i]='\0';
			fprintf(stdout," ?");
			strncpy_(line,getString(),COMPSCR);
		}
	} while (*p && done);

	/* redo in case of any mistaken input, resetting parameters */
	if (!done) {
		fprintf(stdout, "\n%s\n", error[91]);
		/* reset values for repeating */
		p=pb;
		u=line;
		done=1;
		goto redo;
	}

	/* reset printing position */
	channel[CONSOLE].fprintn=channel[CONSOLE].fcounter=0;

	/* get timer (exclude user delay from timing) */
        gettimeofday(&tv, NULL);
       	extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0)-extraS;
	beginS=beginS+extraS;
}


/* getRandom()
 * return a pseudo-random number, called by the RND function.
 * The algorithm is the following:
 *   - get the decimals from third to eighth position of the division of
 *     randSeed by randDivi (at start respectively 27268 and 32767) to obtain a 
 *     number greater than 0 (excluded) and lower than 1 (excluded) as the
 *     generated random number;  
 *   - the first five decimals of this number are taken as the new randSeed for 
 *     the next iteration. 
 * Note: to reduce the risk of circular ranges I add two variables, varying
 * continuously: 'fix' that alters randSeed and div that alters randDivi; to
 * reduce also the risk of having 'exact' divisions (like 0.250000, which is 
 * 'unfair' as random number) randSeed is always odd, randDivi is even.
 * Note: This algorithm, after a variable length list of generated numbers, 
 * falls into a cycle, whose length is exactly 8532532; the start of the cycle
 * is variable, and depends on the initial values for randSeed and randDivi.
 * Note: the values of 27268 and 32767 for the starting values of randSeed and
 * randDivi were chosen to return, as the first random number, the same first
 * random number generated by the DEC-BASIC
 * Ref. LBMAA-A-D, 5-2
 * System function for the pseudo-random number generation management */
double getRandom(void) {
	static double fix=0.3; // variable randSeed part
	static double div=0.1; // variable randDivi part
	double o=100.0*randSeed/randDivi;

	/* take fractional part of the division of randSeed by randDivi
	 * (take digits from 3rd to 8th position) */
	o-=(int)o;

	/* update randSeed */
	randSeed=(unsigned int)((o*1E5)+fix);
	if (randSeed<1E3) randSeed=27268;  
	if (!randSeed%2) randSeed++;

	/* update randDivi */
	randDivi=(unsigned int)((randDivi*randSeed)%0xFFFFF+div);
	if (randDivi<1E3) randDivi=32767; 
	if (randDivi%2) randDivi++;

	/* update variable parts */
	div+=3.0; if (div>499) div=-997;
	fix+=167.0; if (fix>4999) fix=0;

	/* ensure limits are respected (see previous note) */
	if (o<ZERO||o>=1.0) return getRandom(); // discard also neg. numbers
	return o;
}


/* RANDOMIZE()
 * the actual randomizing function, called by the RANDOMIZE statement.
 * The algorithm (depending from current time) is the following:
 *   - get the module of current 'usec' measure to the sum of the value 
 *     obtained summing months (12), days (31), hours (23), minutes (59) and 
 *     seconds (59), which gives 184;
 *   - use a linear conversion of the module to get a new value for randSeed;
 *     the function is built for never returning values too close to zero or
 *     to randDivi; in particular, the range is [1/8*ranDivi, 7/8*randDivi]
 * Note: randSeed is always odd (see getRandom).
 * Ref. LBMAA-A-D 5.1.3, 5-3, "The RANDOMIZE Statement */
void RANDOMIZE(void) {
	int b;
	gettimeofday(&tv, NULL);
       	b = tv.tv_usec%184;
	randSeed=(int)(133.5611413*b+4095.875);
	if (!randSeed%2) randSeed++;
}


/* ONGOTO()
 * The ON..GOTO/ON..THEN statements.
 * Note: the ON..GOSUB statement is strangely not listed and its absence was 
 * tested on the LCM.
 * Ref. LBMAA-A-D 1.4.6, 1-9, "ON-GO TO Statement" */
void ONGOTO(void) {
	int addr[35],ac=0;
	int val;
	if (!check(p,"GOTO")) { 
		if (check(p,"THEN"));
		else perror_(35,l);
	}
	
	/* take the integer part 
	 * Ref. LBMAA-A-D 1.4.6, 1-9 */
	val=(int)S();
	/* check for a valid value (must be greater than zero) */
	if (val<=0) perror_(109,l,val);
	if (isDefRun) {
		if (val<=fn[isDefVar].start || val>fn[isDefVar].end)
			perror_(38,l);
	}
	else if (fm[val]) perror_(40,l,val);

	/* if formula is followed by a comma, skip it 
	 * Ref. LBMAA-A-D 1.4.6, 1-9 */
	if (*p==',') p++;

	/* parse addresses and store them in the array addr[] */
	if(!strncmp(p," OTO",4)){
		p+=4;
		/* check integer destination */
		if (!isdigit(*p)) perror_(39,l) ;
		/* at least an address must be given */
		if (!*p) perror_(35,l);
		addr[ac++]=(int)S();
		while (*p++==',') addr[ac++]=S();
		/* ON..GOTO overflow causes a halt */
		if (val>ac) perror_(109,l) ;
		else l=addr[val-1]-1;
		return;
	}
	else perror_(35,l);
}


/* IFTHEN()
 * The IF..THEN/IF..GOTO statements,
 * Note: THEN and GOTO are perfectly interchangeable, since THEN is turned to 
 * GOTO into tokenize(); this enables writing THEN 80 instead of GO TO 80
 * Ref. LBMAA-A-D 1.4.5, 1-9, "IF-THEN Statement"
 * Ref. LBMAA-A-D 8.2, 8-2, "String conventions" */
void IFTHEN(void){
	int flag=0;
	
	/* IF is not followed by THEN/GOTO 
	 * Ref. LBMAA-A-D 1.4.6, 1-9 */
	if (!check(p,"GOTO")) perror_(35,l);
	
	/* get IF..THEN condition status from a string relation or 
	 * from a numerical expression */
	if (isanystring(p)) flag=strRel();
	else flag=(int)S(); // formula-by-value enabled
	
	/* if there's a comma, skip it 
	 * Ref. LBMAA-A-D 1.4.5, 1-9 */
	if (*p==',') p++;

	/* now skip GOTO (THEN was turned to GOTO in tokenize) */
	if(!strncmp(p," OTO",4)) p+=4;
	/* otherwise it's an incorrect IF */
	else perror_(36,l);
	
	/* if IF..THEN condition is true, perform what follows THEN/GOTO */
	if (flag) {
		/* if after THEN/GOTO there's a destination */
		if (isdigit(*p)) GOTO();
		/* else it's an incorrect address */
		else perror_(39,l); // tested
	}
}


/* GOTO()
 * The GOTO Statement - called also by IF..THEN 
 * Ref. LBMAA-A-D 1.4.4, 1-9, "GO TO Statement" */
void GOTO(void){
        int num;
        
	/* check integer destination
	 * Note: as tested on the LCM, the number must be a pure number */
	if (!isdigit(*p)) perror_(39,l); // tested

        /* check if destination is legal 
	 * Note: as tested on the LCM, the control to a self call is not done,
	 * so decb avoids it as well, and the control is delegated to the
	 * BASIC programmer */
	num=strtol(p,&p,10);
	if (*p) perror_(65,l,makechar(p),TERMINAT); // tested
        if (!m[num]) perror_(61,l,num);
	if (isDefRun) {
		if (num<=fn[isDefVar].start || num>fn[isDefVar].end)
			perror_(38,l);
	}
	/* Thanks to D.H., who found a bug in the following line
	 * (I left behind the 'else' */
	else if (fm[num]) perror_(40,l,num);

	/* check if the GOTO jump is out of one or more FOR cycles 
	 * Note: this subject is not described in the LBMAA-A-D but I
	 * tested on the LCM that a jump out of a FOR cycle (one or more)
	 * is possible, and no warnings or error messages are shown. */
	while (forcount && (num<forStack[forTOS-4]-1||num>forStack[forTOS-5])){
		int h=forStack[forTOS-3];
		Pf[h]=FALSE;
		forTOS -= 6;
		forcount-=1;
		if (isDefRun) isDefFor--;
	}

        l=num-1;
}


/* GOSUB()
 * The GOSUB Statement. 
 * Note: in the LBMAA-A-D there's no mention to the limit of the GOSUB stack 
 * (the higher level of allowed nested GOSUBs); but as tested on the LCM, this
 * limit does not exist (or no error message seems related to this matter).
 * I set this limit to LIMIT, which is sufficiently wide to host a great number
 * of nested GOSUBs, but the relative error message is a new conception (if
 * you happen to overpass 999 GOSUB levels, you've surely gotten something
 * wrong!). The BAS17F.DOC file at the LCM, available in the DOC: directory,
 * reports the following bug error correction:
   222  BASIC DETECTS A RECURSIVE SUBROUTINE CALL ONLY AFTER THE
     SECOND CALL IS MADE.
 * In any case, the LCM does not admit auto-calling GOSUBs, a normal behavior, 
 * after all (see error #126). 
 * Ref. LBMAA-A-D 5.2, 5-6, "Subroutines"
 * Ref. LBMAA-A-D 5.2.1, 5-6, "GOSUB and RETURN Statements" */
void GOSUB(void){
        int num;

	/* check if GOSUB is within a DEF FN */
	if (isDefRun) perror_(30,l);

	/* check integer destination */
	if (!isdigit(*p)) perror_(35,l); //tested

	/* check if destination is legal 
	 * Note: as tested on the LCM, the number must be a pure number */
        num=strtol(p,&p,10);
        if (*p) perror_(65,l,makechar(p),TERMINAT); // tested
	if (!m[num]) perror_(61,l,num);
	if (fm[num]) perror_(40,l,num);

	/* check if GOSUB calls itself */
	if (isARing(num)) perror_(126,l);

	/* perform GOSUB and check GOSUB stack depth 
	 * Ref. LBMAA-A-D 5.2.1, 5-6 */
        gosubStack[++gosubTOS]=l, l=num-1;
	isGOSUB=TRUE;
	if (gosubTOS >= LIMIT) perror_(198,l); 
}


/* RETURN()
 * The RETURN Statement.
 * Note: see the note in GOSUB()
 * Ref. LBMAA-A-D 5.2.1, 5-6, "GOSUB and RETURN Statements" */ 
void RETURN(void){
	/* RETURN without GOSUB? */
        if (gosubTOS<=0) perror_(118,l);
	/* check RETURN is within a DEF FN */
	if (isDefRun) perror_(54,l);
        /* restore pointers */
        l=gosubStack[gosubTOS--];
	if (!gosubTOS) isGOSUB=FALSE;
	lastGosub=0;
}


/* FOR()
 * The FOR..TO..STEP/FOR..TO..BY Statements.
 * STEP and BY are interchangeable - actually, STEP is turned to BY into
 * tokenize().
 * if flag Pf[] is true initialize and perform the plain FOR;
 * if flag Pf[] is false, initialize to current value (NEXT was met before).
 * Note: as tested on the LCM, the FOR/NEXT in the compiled version of a 
 * LCM BASIC program worked well even if NEXT was called before the relative 
 * FOR, because the addresses were pre-calculated in the compiling phase, and 
 * the back jump to FOR occurred after the initialization of the variable 
 * index; this had the side effect of not setting the starting value, but 
 * rather conserving the current value, updated with the step value; decb, 
 * being an interpreter, has to workaround this by means of the phantom flag 
 * array Pf[]; it works this way:
 * - in normal execution, FOR finds it FALSE for index 'var'; so it sets start
 *   cycle value as in the FOR statement for index 'var' and sets Pf to TRUE; 
 *   NEXT, in turn, will find it TRUE and will reset it to FALSE when it exits 
 *   the cycle.
 * - in an inverted execution, when NEXT is called before FOR, Pf[] is found 
 *   FALSE; thus, NEXT knows that a FOR must be called in order to instantiate 
 *   the FOR stack, but first it sets it to TRUE; FOR, then, will find it TRUE,
 *   and thus will set starting index 'var' to its current value + the step.
 * - in either cases, NEXT resets Pf[] to FALSE at the end of the cycle. 
 * Ref. LBMAA-A-D 2.1, 2-1, "FOR and NEXT Statements" */
void FOR(void){
        int var=0, nextstep=0, minus=1;
        double start=0, end=0, step=0, varvalue=0;

	/* make checks and grab variable name */
	if (forcount >= FORLIM) perror_(53,l);
	if (!*p) perror_(65,l,"A FF,LF,VT, OR CR","A LETTER");
	if (!isalpha(*p)) perror_(65,l,makechar(p),"A LETTER");
	else if (varcheck(p,SIMPVAR)) var=*p++;
	else if (varcheck(p,DOUBVAR)) var=in(*p,*(p+1)),p+=2;
	else perror_(37,l);
        if (*p++!='=') perror_(65,l,makechar(p),"=");
	
	/* save values of FOR variable index */
	varvalue = P[var];
	if (*p=='-') minus=-1, p++;
	if (check(p,"TO")) start=minus*S();
	else perror_(35,l);
	if (*p != ' ' && *(p+1) !='O') perror_(35,l);
	
	/* case of a user step 
	 * Ref. LBMAA-A-D 2.1, 2-2 */
	if (check(p,"BY")) {
		p+=2, minus=1;
		if (*p=='-') minus=-1, p++;
		end=minus*S();
		p+=2;
		if (!*p) perror_(37,l);
		step=S();
	}
	/* case of an implicit step = 1 
	 * Ref. LBMAA-A-D 2.1, 2-2  */
	else {
		p+=2, minus=1;
		if (*p=='-') minus=-1, p++;
		end=minus*S();
		step=1.0;
	}

	/* set starting value for index variable */
	if (!Pf[var]) P[var]=start;
	else P[var]+=step, start=P[var];

	/* the search for closing NEXT matching the variable 
	 * was done in preParse() and stored into forAddr[] */
	nextstep=forAddr[l];

	/* if step is meaningless and thus not executed, go beyond FOR..NEXT, 
	 * restoring index variable value;
	 * Ref. LBMAA-A-D 2.1, 2-2 */
	if ((end-start>0 && step<0) || (end-start<0 && step>0) || step==0) {
		l=nextstep-1;
		P[var]=varvalue;
		/* Note: it needs to let FOR() build stack positions even
		 * if no step has to be taken, because figures like NEXT J,I
		 * may be called, and in this case, since each stack 
		 * configuration (even if useless) is removed by NEXT(), must 
		 * be written even if never used */
                //return; // removed on Beta version
	}

        /* update stack values */
	forStack[++forTOS]=nextstep;	// TOS-5 = NEXT program line
	forStack[++forTOS]=l;           // TOS-4 = next instruction
        forStack[++forTOS]=var;		// TOS-3 = var index
        forStack[++forTOS]=end;         // TOS-2 = end value
        forStack[++forTOS]=step;        // TOS-1 = step value
        forStack[++forTOS]=start;       // TOS   = start/current value
	forcount++;
	Pf[var]=TRUE;

	/* set DEFFN counter */
	if (isDefRun) isDefFor++;
}


/* NEXT()
 * The NEXT... Statement
 * Note: see the note in FOR().
 * NEXT **must** be followed by at least the first variable name.
 * Note: this version handles multiple addressing, like NEXT J,I,K
 * Ref. LBMAA-A-D 2.1, 2-1, "FOR and NEXT Statements" */
void NEXT(void) {
        int var=0,i=0;
        double step, end;
	char *qq;
	double micro=1E-7; // for floating point comparisons

	qq=p;
	while (*qq) qq++; // end of line
	while (*qq!=',' && qq>=p) qq--; qq++; // start of last variable
	/* get index of last variable in line */
        if (varcheck(qq,SIMPVAR)) var=*qq;
	else if (varcheck(qq,DOUBVAR)) var=in(*qq,*(qq+1));
	else perror_(37,l);
	/* if NEXT was called before FOR via a GOTO/GOSUB call, Pf[var]
	 * is found FALSE; so set address value, search the relative FOR
	 * calling line, to be the next statement - tested
	 * Of course, search must start from last variable in the NEXT line */
	if (!Pf[var]) {
		int found=FALSE;
		/* search FOR line */
		while (i<CORELIM) {
			if (forAddr[i]==l) {
				l=i-1;
				found=TRUE;
				break;
			}
			i++;
		}
		if (!found) perror_(47,l);
		Pf[var]=TRUE;
		return;
	}

nextvar:

	/* get index of first variable in line */
        if (varcheck(p,SIMPVAR)) var=*p++;
	else if (varcheck(p,DOUBVAR)) var=in(*p,*(p+1)),p+=2;
	else perror_(35,l);

	/* update cycle values */
	step = forStack[forTOS-1];
	end  = forStack[forTOS-2];
	if (end==((int)end)) micro=0.0; // no rounding for integers

	/* check index; if different from what stored 
	 * with the previous FOR instruction => NEXT error
	 * Ref. LBMAA-A-D 2.2, 2-4, "Nested Loops" */
	if (var != (int)forStack[forTOS-3]) perror_(47,l);

        /* Note: if beyond the limit then end cycle; after that, if there are 
	 * other indices in the list continue with the most outer cycle;
	 * Note: in version Gamma I introduced a MICRO constant to circumvent
	 * the roundoff errors that can arise while comparing floating point
	 * numbers, that cause different behaviours on different machines; but
	 * this technique caused an irregular error message to appear in cycles
	 * when the inner index depended on the outer (thanks to D.H. for this
	 * subject); this seems more important than preserving roundoff, so 
	 * I removed it from version Beta.
	 * Note: in dib the check was done on forstack[forTOS], not on the 
	 * variable, but this is not the case for the LCM BASIC, where the 
	 * variable to check for is the variable itself (this is actually
	 * meaningless for normal cycles, but when the index is altered inside
	 * the cycle, the control in dib was not made upon the altered variable 
	 * while here it is).
	 * Note: on par. 2.1, page 2-4, the LBMAA-A-D reports the errors due to 
	 * the inner precision of the computer (the DEC-10/20 family):
	 * "...The following difficulty can occur with loops, both FOR-NEXT 
	 * loops and loops explicitly written with LET and IF statements [...].
	 * The calculation of the index values (initial, final, and step-size) 
	 * is subject to precision limitations inherent in the computer. These 
	 * values are represented in the computer as binary numbers. When the 
	 * values are integer, they can be represented exactly in binary; 
	 * however, it is not always possible to represent decimal values 
	 * exactly in binary when they contain a fractional part...".
	 * decb cannot be absolutely precise, in any case, because it runs 
	 * (yes!) into a more modern computer, but with its limitations too!
	 * So do expect that some differences arise between the two, and that 
	 * some limits are common to both versions. In any case, I insert the
	 * 'micro' corrector, to solve at least all immediate issues */
        if ((((step > 0)&&(P[var]+step > end+micro))||\
			((step < 0)&&(P[var]+step < end-micro)))) {
                forTOS -= 6;
		forcount--;
		if (isDefRun) isDefFor--;
		Pf[var]=FALSE;
		/* restart in case of multiple NEXT */
		if (*p==',') {
			p++;
			goto nextvar;
		}
	}
	/* else reiterate; update counter variable (current +/- step)
	 * Ref. LBMAA-A-D 2.1, 2-4 */
        else {
        	forStack[forTOS] += step; 
	        P[var]+=step;
	        l=(int)forStack[forTOS-4];
	}
	/* reset flag for the FOR..NEXT cycle inside a DEF FN 
	 * in case no cycle is left - this should be never needed, but... */
	if (!forcount && isDefFor) isDefFor=FALSE;
}
	

/* FNEND() 
 * close a multiline DEF FN.
 * Ref. LBMAA-A-D 5.1.6, 5-5, "The Define User Function (DEF) and Function
 * End Statement (FNEND)" */
void FNEND(void) {
	isDefRun=FALSE;
}


/* DEF()
 * The DEF Statement for numerical functions; handles multiple arguments 
 * Note: this function is called in preParse() before RUN().
 * The label for FN must be in the A..Z range and not subscripted.
 * Note: this function executes a storing only; the actual command (the 
 * function interpretation and execution) is performed into getFunc() for
 * function FNX; in case of an inline DEF FN, the string is stored into an 
 * array called fn[].def; in case of a multiline DEF FN they are stored into 
 * an array of char pointers called fn[].lines[].
 * Note: the LBMAA-A-D at page 5-5 states that no string variable may appear as
 * argument in a DEF function: "... string variables [...] are not allowed..."; 
 * moreover, nowhere in the manual there's a mention of the existence of string 
 * functions like DEF FNA$..., and this is confirmed by the LCM BASIC.
 * Ref. LBMAA-A-D 5.1.6, 5-5, "The Define User Function (DEF) and Function
 * End Statement (FNEND)"  */
void DEF(int l) {
	int len, ward=*(p+2), mode=isSingleDEF(p);

	/* check if the function name has already been used */
	if (fn[ward].type==SINGLE || fn[ward].type==MULTI) perror_(31,l);
	
	/* if there are arguments, they must be saved */
	if (*p=='F' && *(p+1)=='N' && isalpha(ward) && *(p+3)=='(') {
		int varcount=0;

		/* point to the first variable */
		p+=4;

		/* store all argument-variables; 
		 * more than one A..Z/A0..Z9 variable may be used
		 * Ref. LBMAA-A-D 5.1.6, 5-5 */
		while (*p!=')') {
			if (varcheck(p,SIMPVAR)) {
				fn[ward].vars[0]=++varcount;
				fn[ward].vars[varcount]=*p++;
			}
			else if (varcheck(p,DOUBVAR)) {
				fn[ward].vars[0]=++varcount;
				fn[ward].vars[varcount]=in(*p,*(p+1));
				p+=2;
			}
			else perror_(35,l);

			/* check syntax */
			if (*p==',') p++;
		}
		if (*p++!=')') perror_(35,l);
	}
	else p+=3; // skip the three letters

	/* string functions are not admitted in the DEC-BASIC 
	 * Ref. LBMAA-A-D 5.1.6, 5-5 */
	if (*p=='$') perror_(65,l,makechar(p), TERMINAT);
	/* function names must be in the range A..Z only */
	if (*p && *p!='=' && *p!='\'') perror_(65,l,makechar(p),TERMINAT);

	/* single line DEF: store in fn[].def the following formula, caring of 
	 * tokenizing/stripblanking it, because all this is done in parse() 
	 * Ref. LBMAA-A-D 5.1.6, 5-5 */
	if (mode==SINGLE) {
		char* q=p;
		char sline[SCREENLINE+1];
		if (*q!='=') perror_(35,l);
		len=strlen(++q)+1;
		while (*q) tokenize(q++);
		p++;
		stripBlanks(p,sline);
		/* empty line is an error */
		if (!sline[0]) perror_(35,l);
		if (fn[ward].def!=NIL) free(fn[ward].def);
		fn[ward].def=malloc(len);
		if (!fn[ward].def) perror_(192,l,ward);
		strncpy_(fn[ward].def,sline,len);
		fn[ward].def[len]='\0';
		fn[ward].type=mode;
	}
	/* multiline DEF: store lines
	 * Ref. LBMAA-A-D 5.1.6, 5-5 */
	else {
		char *q;
		int i, numFOR=0, lk;
		/* find next available line after DEFFN */
		l++; while (!m[l]) l++;
		fn[ward].start=l-1;
		/* find last line (where FNEND is located) */
		while (l<CORELIM) {
			if (m[l]) {
				q=m[l];
				fm[l]=1; // inner DEFS not available for GOTO
				while (isblank(*q)) q++;
				if (!strncmp(q,"FNEND",5)) break;
			}
			l++;
		}
		if (l>=CORELIM) perror_(52,-1,ward);
		else fn[ward].end=l;

		/* set type */
		fn[ward].type=mode;

		/* copy lines*/
		for (i=fn[ward].start; i<=fn[ward].end; i++) {
			if (m[i]) {
				q=m[i];
				while (isblank(*q)) q++;
				if (!strncmp(q,"FOR",3)) numFOR++;
				else if (!strncmp(q,"NEXT",4)) numFOR--;
				lk=strlen(q)+1;
				if (fn[ward].lines[i]!=NIL) 
				    free(fn[ward].lines[i]);
				fn[ward].lines[i] = malloc(lk);
				if (!fn[ward].lines[i]) perror_(191,l);
				strncpy_(fn[ward].lines[i],q,lk);
			}
		}
		if (numFOR) perror_(28,l);
		isDefCount++;
	}
}


/* READ()
 * The READ statement 
 * this function checks the next available item in the READ line, and stores in
 * it the first available correspondent item (number or string)
 * Note: READ and DATA work on two dedicated arrays, one for numbers, one for 
 * strings, whose activation flags are dataLimit and dataLimitS and whose 
 * pointers are dc and dcs; these arrays are built in the DATA section of 
 * preParse() (there is no DATA command, actually).
 * Ref. LBMAA-A-D 1.4.2, 1-7, "READ and DATA Statements" 
 * Ref. LBMAA-A-D 8.1, 8-1, "Reading and Printing Strings" */
void READ(void) {
	/* there must be at least one DATA to read! */
	if (!dataLimit && !dataLimitS) perror_(50,l);
	
	/* start READ */
	do {
		/* READ number DATA and put into numeric variables */
		if (isnum(p)) {
			if (dc>dataLimit) perror_(110,l);
			
			/* numerical arrays */
			if (varcheck((p),SIMPARR) || varcheck((p),DOUBARR)) {
				int var=0, M=0, N=0, T=1;
				if (varcheck(p,SIMPARR)) var=*p++;
				else if (varcheck(p,DOUBARR)) 
					var=in(*p,*(p+1)), p+=2;
				else perror_(42,l);
				if (*p!='(') perror_(35,l);
				p++; // skip '('
				M=(int)S();
				if (M<0) perror_(76,l);
				if(*p==',') {
					p++; // skip ','
					N=(int)S();
					if (N<0) perror_(76,l);
					T=2;
				}
				if (*p!=')') perror_(35,l);							setArrayVal(var,T,M,N,D[dc++]);
				p++;
			}
			/* numerical variables */
			else if (varcheck(p,SIMPVAR)) { 
				P[(int)*p++]=D[dc++];
			}
			else if (varcheck(p,DOUBVAR)) {
				P[in(*p,*(p+1))]=D[dc++], p+=2;
			}
		}
		/* READ string DATA and put it into string variables */
		else if isstr(p) {
			int index;
			if (dcs>dataLimitS) perror_(110,l);
			
			/* string variables */
			if (varcheck(p,SIMPSTR)) {
				int lk;
				index=(int)*p;
				lk=strlen(DS[dcs])+1;
				if (PS[index]!=NIL) free(PS[index]);
				PS[index]=malloc(lk);
				if (!PS[index]) perror_(191,l);
				*PS[index]='\0';
				strncpy_(PS[index],DS[dcs],lk);
				p+=2;
			}
			else if (varcheck(p,DOUBSTR)) {
				int lk;
				index=in(*p,*(p+1));
				lk=strlen(DS[dcs])+1;
				if (PS[index]!=NIL) free(PS[index]);
				PS[index]=malloc(lk);
				if (!PS[index]) perror_(191,l);
				*PS[index]='\0';
				strncpy_(PS[index],DS[dcs],lk);
				p+=3;
			}
			/* string arrays */
			else if (varcheck(p,SIMPSTRARR)) {
				int M=0,T=1;
				index=*p; p+=3;
				M=S();
				if (*p!=')') perror_(37,l);
				setArrayStr(index,T,M,0,DS[dcs]);
				p++; // skip ')'
			}
			else if (varcheck(p,DOUBSTRARR)) {
				int M=0,T=1;
				index=in(*p,*(p+1)); p+=4;
				M=S();
				if (*p!=')') perror_(37,l);
				setArrayStr(index,T,M,0,DS[dcs]);
				p++; // skip ')'
			}
			while (*p && *p!=',') p++;
			dcs++;
		}
		else perror_(42,l);
	} while (*p && *p++==',');
}


/* RESTORE()
 * the RESTORE statement. 
 * Note: if used without DATA statement, a NO DATA warning is issued.
 * Note: a RESTORE followed by a digit is interpreted as a RESTORE#.
 * Ref. LBMAA-A-D 6.5, 6-6, "RESTORE Statement" */
void RESTORE(void){
	int ok=TRUE;
	if (isdigit(*p)) FRESTORE();
	else if (*p=='*') {
		if (dataLimit) dc=1; else ok=FALSE;
	}
	else if (*p=='$') {
		if (dataLimitS) dcs=1; else ok=FALSE;
	}
	else if (!*p) {
		if (dataLimit+dataLimitS) dc=dcs=1; else ok=FALSE;
	}
	else perror_(35,l);
	/* warning in case something went wrong */	
	if (!ok) perror_(50,l);
}


/* LET()
 * The LET statement (even for implicit LET)
 * address simple assignment (e.g X=3) and multi-variables assignments
 * (e.g. X=Y=T=3); the effective addressing routine is delegated to 
 * assign() for numbers and to strAssign() for strings.
 * return TRUE if assignment can be accomplished, FALSE otherwise; 
 * Note: a multi-variable assignment proceeds from right to left, that is
 * the first item is updated last; this is important in cases like
 * LET A=B(A)=expression, where B(A) is updated with the 'old' value of A,
 * while in LET B(A)=A=expression, B(A) is updated with the 'new' value of A;
 * this conforms to the DEC-20 original behavior.
 * Note: this algorithm doesn't consider the equal signs into strings (in 
 * which case they are 'characters') or into parenthesis (in which case they 
 * are logical operators).
 * Ref. LBMAA-A-D 1.4.1, 1-7, "LET Statement" */
int LET(void) {
	char *sep, *sep2, *lp;
	int v=0;
	
	/* LET is implicit */
	if (!strncmp(p,"LET",3)) p+=3;
	lp=p;

	/* short circuit for statements which are surely not assignments */
	if (!strchr(p,'=')) return FALSE;

	/* search last assignment (signaled by '=') out of strings and 
	 * out of parenthesis (in which case '=' is a logic operator) */
	v=0;
	while (TRUE) {
		sep=p+strlen(p)-1;
		do {
			/* skip explicit strings */
			if (*sep=='\"') {
				sep--; // skip opening quotes
				while (sep>lp && *sep!='\"') sep--;
				sep--; // skip closing quotes
			}
			/* skip calculations in parenthesis
			 * (since we start from the end, we first search
			 * for ')' and finally for '(' ) */
			else if (*sep==')') v++, sep--;
			else if (*sep=='(' && v) v--, sep--;
			else if (*sep=='=' && v) sep--;
			else if (*sep=='=' && !v) break; // found!
			else if (sep>lp && *sep!='=') sep--;
		} while (sep>lp);

		/* maybe no assignment was found */
		if (*sep!='=') return FALSE;

		sep2=sep-1;
		while (sep2>lp && *sep2!='=') sep2--;

		/* check if it's a single assignment or a mistaken line
		 * (for instance something like C$+A$+B$ instead of C$=A$+B$) 
		 * Note: this last case was a real experimented case 
		 * Note: the algorithm is: find next operator from start;
		 * it must match sep, which is the first position of the
		 * equal sign in the assignment*/
		if (*sep2!='=') {
			char* sep3=sep2;
			v=0;
			while (*sep3) {
				if (*sep3=='(') v++, sep3++;
				else if (*sep3==')') v--, sep3++;
				else if (isop(sep3) && v) sep3++;
				else if (isop(sep3) && !v) break;
				else sep3++;
			}
			if (sep3!=sep) perror_(35,l);
		}
		

		
		/* proceed with assignment:
		 * it's a multi-variables assignment... */
		if (*sep2=='=') {
			p=sep2+1;
			if (!assign()) return FALSE;
			*sep='\0';
			continue;
		}
		/* ...or else it's a single assignment */
		else {
			p=lp;
			return assign();
		}
	}
	return FALSE;
}



/******************************************
 *            BASIC INTERFACE             *
 ******************************************/


/* listingLen()
 * return the length of the program in memory in chars (option --length)
 * Note: the LENGTH command counts 5 for each line number, and counts 
 * characters in the listing (including spaces) as multiple of 5.
 * Note: this algorithm does not return values matching exactly the output of 
 * the BASIC interface command LENGTH, but the magnitude is correct.
 * Ref. LBMAA-A-D 9.7, 9-11, "Obtaining Information" */
int listingLen(void) {
	int olen=0;
	struct stat st;
	stat(filename, &st);
	olen=(int)st.st_size;
	return olen;
}


/* renum()
 * update inner references in a set of instructions, starting from the new line 
 * Ref. LBMAA-A-D 9.3.3, 9-5
 * Note: in the 9.3.3 paragraph there's no mention to the updating of the inner 
 * references, but this was tested on the LCM. 
 * This system routine is used into RESEQUENCE() and INSERTLINENUMBERS() */
void renum(char *mc[], int conv[]) {
	int i=0, isOnGoto=FALSE;

	/* cycle through all lines */
	while (i<CORELIM) {
		isOnGoto=FALSE;
		if (mc[i]) {
			int n;
			char *y=mc[i],*p=y;

			while (isblank(*y)) y++;

			/* manage ON..THEN */
			if (!strncmp(y,"ON",2) && (p=strstroq(y,"THEN"))) {
				p+=4;
				isOnGoto=TRUE;
			}
			/* manage ON..GO TO */
			if (!strncmp(y,"ON",2) && (p=strstroq(y,"GO"))) {
				p+=2;
				while (isblank(*p)) p++;
				if (!strncmp(p,"TO",2)) {
					p+=2;
					isOnGoto=TRUE;
				}
			}
			/* manage GOSUB */
			else if ((p=strstroq(y,"GOSUB"))) {
				p+=5;
			}
			/* manage GO TO */
			else if ((p=strstroq(y,"GO"))) {
				p+=2;
				while(isblank(*p)) p++;
				if (!strncmp(p,"TO",2)) {
					p+=2;
				}
			}
			/* manage THEN */
			else if ((p=strstroq(y,"THEN"))) {
				p+=4;
			}
			/* manage USING */
			else if ((p=strstroq(y,"USING"))) {
				p+=5;
				/* discard channel data */
				while (isblank(*p)) p++;
				if (*p=='#') {
					p++; // skip #
					while (isdigit(*p)) p++;
					if (*p==',') p++; // skip comma
				}
			}
			/* no correspondence was found */
			else p=y;

			/* update the multiple references in ON..GOTO*/
			if (isOnGoto) {
				char *pc, *base=mc[i];
				while (isblank(*p)) p++;
				pc=p;
				while (isdigit(*p)) {
					int lk;
					n=strtol(p,&p,10);
					*pc='\0';
					lk=strlen(mc[i])+intLen(conv[n])+strlen(p)+2;
					y=malloc(lk);
					if (!y) perror_(7,-1);
					sprintw(y,lk,"%s%d%s",mc[i],conv[n],p);
					free(mc[i]);
					mc[i]=y;
					p=mc[i]+(int)(pc-base)+intLen(conv[n]);
					base=mc[i];
					while (isblank(*p)) p++;
					if (*p==',') p++;
					while (isblank(*p)) p++;
					pc=p;
				}
			}
			/* update references in remaning statemenets */
			else if (*p) {
				char *pc;
				while (isblank(*p)) p++;
				pc=p;
				if (isdigit(*p)) {
					int lk;
					n=strtol(p,&p,10);
					*pc='\0';
					lk=strlen(mc[i])+intLen(conv[n])+strlen(p)+2;
					y=malloc(lk);
					if (!y) perror_(7,-1);
					sprintw(y,lk,"%s%d%s",mc[i],conv[n],p);
					free(mc[i]);
					mc[i]=y;
				}
			}
		}
		i++;
	}
}


/* listAndSave()
 * wrapper for LIST.
 * list file and re-save onto file if isReseqSave is TRUE (option -s).
 * n1 and n2: limits of the LISTing required
 * System function */
void listAndSave(int n1, int n2) {
	FILE *fd;
	/* list program resequenced program */
	LIST(stdout, n1, n2);
	/* save resequenced program on file overwriting old content 
	 * (if required) */
	if (isReseqSave) {
		fd=fopen(filename,"a");
		if (!fd) {
			fprintf(stdout, "\n");
			perror_(197,l,filename);
		}
		else {
			fclose(fd);
			fd=fopen(filename,"w");
			LIST(fd, 0, CORELIM);
			fclose(fd);
		}
	}
}

/* RESEQUENCE()
 * perform the RESEQUENCE command (Ref. LBMAA-A-D 9-8)
 * Note: the renumbering updates the inner references after GOTO, GOSUB, THEN 
 * and USING (if followed by a line number), ON..GOTO multiple addresses; 
 * Note: the command was used in the BASIC interface as 'RESEQUENCE n,f,k', 
 * where n = the new line, f = the old line from which the renumbering starts, 
 * k = the step the renumbering used from f to the end.
 * Ref. LBMAA-A-D 9.3.3, 9-5, "Renumbering Lines in the File" */
void RESEQUENCE(int newLine, int oldLine, int step) {
	/* newLine = n, oldLine = f, step = k (default values) */
	char *mc[CHUNKS*LIMIT+10];	// memory core copy
	int conv[CHUNKS*LIMIT+10];	// conversion table
	int i=0;

	/* erase core copy */
	for (i=0;i<CHUNKS*LIMIT;i++) mc[i]=NULL, conv[i]=0;

	/* find first line */
	i=0;
	while (!m[i]) i++;
	
	/* newLine was not given in -r option */
	if (newLine<0) newLine=oldLine=i;
	/* oldLine was not given in -r option */
	if (!oldLine) oldLine=i;
	if (!step) step=10;

	/* check if values can be accepted 
	 * Ref. LBMAA-A-D 9.3.3, 9-5, "...n must be greater than the line 
	 * number immediately preceding f to prevent overwriting..." */
	if (oldLine > newLine) perror_(4,-1);

	/* start resequencing on copy of core, erasing core position 
	 * and building conversion table conv[] */	
	i=0;
	while (i<CHUNKS*LIMIT) {
		if (m[i]) {
			if (i<oldLine) {
				mc[i]=m[i];
				conv[i]=i;
			}
			else {
				mc[newLine]=m[i];
				conv[i]=newLine;
				newLine+=step;
				if (newLine>DATLIM) perror_(40,l,newLine);
			}
			m[i]=NULL;
		}
		lastLine=i;
		i++;
	}
	
	/* renumber inner references */
	renum(mc,conv);

	/* update core copy on user core; this is necessary for LIST, because 
	 * it refers to the lines in memory */
	for (i=0; i<CHUNKS*LIMIT; i++) {
		if (mc[i]) m[i]=mc[i];
	}
	
	/* list renumbered file and save it if required */
	listAndSave(0, lastLine);
}


/* INSERTLINENUMBERS()
 * Insert line numbers before each line of the unnumbered BASIC file, taking
 * care of updating the inner references and separating the lines with multiple
 * instructions, separated by colon or backslash, and renumbering the whole
 * file after that.
 * System function */
void INSERTLINENUMBERS(void) {
	char *mc[CHUNKS*LIMIT+10], *p, *b;	// memory core copy
	int conv[CHUNKS*LIMIT+10];		// conversion table
	FILE *f;
	char B[SCREENLINE+10];			// host string
	int thisLastLine=0;			// remember last line number
	int i, newLine, step;

	/* erase core copy and conversion table */
	for (i=0;i<CHUNKS*LIMIT;i++) 
		m[i]=NULL, mc[i]=NULL, conv[i]=0;

	/* set numbering default values */
	newLine=10;	// set to 10, to permit a reasonable renumbering
	step=10;
	
	/* open file */
	if (!(f=fopen(filename,"r"))) {
		fprintf(stdout, "\n"); // isHeader is disabled
		perror_(10,-1,filename);
	}

	/* store file lines in memory, separating the multiple instructions
	 * lines in lines with one instruction per line */
	while(fgets(B,SCREENLINE+9,f)) {
		/* strip away '\n' left by fgets() */
		if (B[strlen(B)-1]=='\n') B[strlen(B)-1]='\0';
		/* if '\n' was not found line is too long! */
		else {
			fprintf(stdout,"\n"); // isHeader is disabled
			perror_(180,strtol(B,NULL,10));
		}
		/* strip away ASCII 13 left by DOS files */
		if (B[strlen(B)-1]==13) B[strlen(B)-1]='\0';
		p=NULL;
		b=B;
		while (isblank(*b)) b++;
		/* store lines with multiple instructions on one line, 
		 * separated by colon or backslash, except for the last 
		 * instruction, pointed by b */
		while ((p=strstroq(b,":")) || (p=strstroq(b,"\\"))) {
			int lk;
			*p='\0';
			while (isblank(*b)) b++;
			lk=strlen(b)+2+1;
			if (mc[newLine]!=NIL) free(mc[newLine]);
			mc[newLine]=malloc(lk);
			if (!mc[newLine]) perror_(8,-1);
			strncpy_(mc[newLine],"\t\0",lk);
			strncat_(mc[newLine],b,lk);
			b=p+1;
			newLine+=step;
		}
		/* store lines with one instruction per line or last
		 * multiline */
		while (isblank(*b)) b++;
		if (*b) {
			int lk=strlen(b)+2+1;
			if (mc[newLine]!=NIL)  free(mc[newLine]);
			mc[newLine]=malloc(lk);
			if (!mc[newLine]) perror_(8,-1);
			strncpy_(mc[newLine],"\t\0",lk);
			strncat_(mc[newLine],b,lk);
			thisLastLine=newLine;
			newLine+=step;
		}
	}

	/* add END if not found as last instruction */
	p=mc[thisLastLine];
	while (isblank(*p)) p++; // get rid of starting blanks
	while (isdigit(*p)) p++; // get rid of line number if present
	while (isblank(*p)) p++; // get rid of trailing blanks
	if (strncmp(p,"END",3)) {
		if (mc[newLine]!=NIL) free(mc[newLine]);
		mc[newLine]=malloc(4);
		if (!mc[newLine]) perror_(8,-1);
		strncpy_(mc[newLine],"END",4);
	}

	/* build conversion table conv[] */	
	i=0;
	while (i<CORELIM) {
		int num;
		if (mc[i]) {
			p=mc[i];
			if (isdigit(*p)) {
				num=strtol(p,&p,10);
				while (isblank(*p)) p++;
				mc[i]=p;
				conv[num]=i;
			}
		}
		i++;
	}

	/* renumber inner references */
	renum(mc,conv);

	/* update core copy on user core; this is necessary for LIST,
	 * because it refers to the lines in memory */
	for (i=0; i<CORELIM; i++) {
		if (mc[i]) m[i]=mc[i];
	}
	
	/* list new file with lines and save it if required */
	listAndSave(0, CORELIM);
}


/* printSpacedMiniTokens()
 * print the minitokens found in a string with a space before and after (if 
 * any is missing), in all sections outside a literal string; used into LIST();
 * Note: this command prints directly the minitokens, the trailing spaces and
 * the rest of the string; for the definition of minitoken see tokens.h 
 * at position 0.
 * fd: the stream to which the print is done
 * str: the string to be printed
 * System function */ 
void printSpacedMiniTokens(FILE *fd, char *str) {
	int turn=TRUE, j, k, isOver=TRUE;

	while (*str) {
		if (*str=='\"' && turn) turn=FALSE;
		else if (*str=='\"' && !turn) turn=TRUE;
		else if (turn) {
			if (*str=='=' && *(str-1)=='<') {
				fputc(*str,fd);
				str++;
			}
			else if (*str=='=' && *(str-1)=='>') {
				fputc(*str,fd);
				str++;
			}
			/* search and print the spaced minitokens */
			for (j=0;j<MINITOKENLIM;j++) {
				k=strlen(token[j]);
				if (token[j][0]&&!strncmp(str, token[j], k)) {
					isOver=FALSE;
					str--;
					/* avoid trailing space in case of
					 * minitokens following statements 
					 * which print a space on their own */
					if (j>PECMINI) addspace(str);
					fprintf(fd,token[j]);
					str+=k+1;
					addspace(str);
					printSpacedMiniTokens(fd, str);
					break;
				}
			}
		}
		if (!isOver) break;
		fprintf(fd,"%c",*str);
		str++;
	}
}


/* LIST() 
 * the LIST command
 * fd is the output channel (stdout or file) on which LIST is performed
 * Note: this statement is executed only by means of option --list/-l and
 * is not available as a programming statement.
 * Note: LIST, being executed after OLD(), preserves REM and tick comments and 
 * discard all the other kind of comments (the special markers)
 * Note: if option --grace is used, it prints all line numbers in 5 digits 
 * (as was in LMC, as reported by the TYPE command, in the MONITOR, for BAS 
 * files), the listing is indented and statements are gracefully spaced 
 * Ref. LBMAA-A-D 9.2, 9-3, "Listing Files" for LIST, LISTNH, LISTREVERSE and
 * LISTNHREVERSE segments */
void LIST(FILE *fd, int first, int last) {
	char *y, *yy;
	int c, n=0, inc;

	/* Note: setup values of start/end list
	 * LIST 25 has first=last 
	 * LIST -25 has first=0 and last=25
	 * LIST 25- has first=0 and last=CORELIM 
	 * LIST 25-50 has first=25 and last=50 */

	/* LIST direction */
	if (isReverse) {
		startList=last;
		endList=first;
		inc=-1;
	}
	else {
		startList=first;
		endList=last;
		inc=1;
	}
	
	/* cycle through all lines */
	for (c=startList;;c+=inc) {
		/* LIST ended? */
		if (isReverse) {
			if (c<endList) break;
		}
		else {
			if (c>endList) break;
		}
		if (m[c]) {
			y=m[c];
			/* treat line with grace (decb option) */
			if (isGrace) {
				int j,k,isOver=FALSE;

				/* INDENT - get rid of trailing spaces */
				while (isblank(*y)) y++;
				
				/* back away with NEXT */
				if (!strncmp(y,"NEXT",4)) {
					n-=listTab;
					/* find commas for format NEXT J,I,K */
					yy=y+4; // skip NEXT
					while (*yy) {
						if (*yy==',') n-=listTab;
						yy++;
					}
				}

				/* 5-DIGITS LINE NUMBERS (1st part of line) */
				fprintf(fd,"%05d\t%s",c,spaces(n));

				/* INDENT - advance next lines within FOR */
				if (!strncmp(y,"FOR",3)) n+=listTab;

				/* print pure tick comment */
				if (*y=='\'') {
					fprintf(fd,"%s\n",y);
					isOver=TRUE;
				}
				/* print a void line for underscore lines */
				/* SPACE STATEMENT */
				else for (j=MINITOKENLIM; j<TOKENLIM; j++) {
				    k=strlen(token[j]);
				    if (token[j][0]&&!strncmp(y,token[j],k)){
				        fprintf(fd, token[j]);
					    y+=k;
					    isOver=TRUE;
					    addspace(y);
					    /* special cases */
					    if (strcmp(token[j],"REM") &&\
						    strcmp(token[j],"FILE") &&\
						    strcmp(token[j],"FILES"))
 					        printSpacedMiniTokens(fd,y);
					    else fprintf(fd,"%s",y);
					    /* close print */
					    fprintf(fd, "\n");
					    break;
				    }
				}
				/* print line with no statements
				 * (images, implicit assignments, mistakes) */
				if (!isOver && y) fprintf(fd,"%s\n",y);
			}
			/* print line as-is, with a little modification
			 * for option -i, which has no natural divider
			 * between the line numbers and the statements */
			else {
				if (isToInsert) fprintf(fd,"%d %s\n",c,y);
				else fprintf(fd,"%d%s\n",c,y);
			}
		}
	}
}


/* OLD() 
 * execute the OLD command, loading file in memory
 * Note: this statement is executed at start automatically and is not 
 * available as a programming statement.
 * If one among '@', '&' or '#' is set as the first character of a line, 
 * the loading is stopped/suspended; this lets store documentation within the 
 * source file; this feature didn't belong to the DEC BASIC. 
 * Ref. LBMAA-A-D 9.1, 9-3, "Creating the File in Memory", OLD section */
void OLD(void) {
	FILE *f;
	char B[SCREENLINE+10];
	int isSuspended=FALSE, isAllBlanks=FALSE, i;

	/* open file */
	if (!(f=fopen(filename,"r"))) {
		beginS=-1;
		perror_(10,-1,filename);
	}

	/* erase core memory */
	for (i=0;i<CHUNKS*LIMIT;i++) m[i]=NULL;
	lastLine=0;

	/* load lines one by one */
	mback=0;
	while(fgets(B,SCREENLINE+9,f)) {
		char *pB=B;
		/* check if it's a void/NULL line (i.e. a line with
		 * no line number and no statements) */
		if (!*pB) continue;
		/* check if file is a normal or random file */
		if (*pB=='�') perror_(22,-1);
		/* stop loading when '@' is met */
		if (*pB=='@') break;
		/* suspend loading between two '�' */
		if (*pB=='&' && isSuspended) {
			isSuspended=FALSE;
			continue;
		}
		if (*pB=='&' && !isSuspended) {
			isSuspended=TRUE;
			continue;
		}
		if (isSuspended) continue;
		/* strip away '\n' left by fgets() */
		if (B[strlen(B)-1]=='\n') B[strlen(B)-1]='\0';
		/* if '\n' was not found line is too long! */
		else perror_(180,strtol(B,NULL,10));
		/* strip away ASCII 13 left by DOS files */
		if (B[strlen(B)-1]==13) B[strlen(B)-1]='\0';
		/* test for lines with blanks only */
		if (isblank(*pB)) {
			char *jB=pB;
			while (isblank(*jB)) jB++;
			if (!jB) isAllBlanks=TRUE;
		}
		/* discard leading blanks */
		if (!isAllBlanks) while (isblank(*pB)) pB++;
		/* discard void lines and lines beginning with # */
		if ((!isAllBlanks && !*pB) || *pB=='#') continue;
		/* store line */
		else storeSingleLineToCore(pB);
	}

	/* close file channel */
	if (f) fclose(f);
}


/* RUN()
 * the RUN command (Ref. LBMAA-A-D 9-12) 
 * Note: this statement is executed at start automatically and is not 
 * available as a programming statement. 
 * Ref. LBMAA-A-D 4.3, 4-4, "Executing the Program" 
 * Ref. LBMAA-A-D 9.5, 9-12, "Executing a BASIC Program", RUN n/RUNNH n section 
 * This algorithm can be interrupted by one CTRL-C, while the DEC BASIC
 * on the LCM could be interrupted by two CTRL-C 
 * Ref. LBMAA-A-D 4.5, 4-5, "Interrupting the Execution of the Program" */
void RUN(void) {
	int i;

	/* not existing line in the RUN file */
	if (startingLine && !m[startingLine]) perror_(107,-1);
	opturn=0; // for safety

	/* reset memory if required */
	if (isToReset==RESET) {
		/* reset numerical variables and relative flags*/
		for(i=0; i<LIMIT;i++) P[i]=0.0, Pf[i]=FALSE;
		/* reset numerical arrays references */
		for(i=0; i<LIMIT;i++) dim[i].elem=NIL;
		/* reset string references */
		for(i=0; i<LIMIT;i++) PS[i]=NIL;
		/* reset string arrays references */
		for(i=0; i<LIMIT;i++) dimS[i].elem=NIL;
		/* reset DEF data */
		isDefRun=isDefVar=isDefCalc=isDefFor=isDefCount=0;
		for(i=0; i<LIMIT;i++) fn[i].type=0;
		/* reset DATA and MAT vars */
		dc=dcs=dataLimit=dataLimitS=0;
		detValue=0.0, numValue=0;
	}
	
	/* reset FOR/GOSUB references and FOR/NEXT address array 
	 * specific for each RUN() */
	gosubTOS=forTOS=forcount=0;
	for(i=0; i<CHUNKS*LIMIT;i++) forAddr[i]=FALSE;

	/* reset channels info specific for each RUN() */
	for(i=1; i<=STREAMS; i++) channel[i].type=NOUSE;

	/* record starting time if not in a CHAINed program
	 * beginS is used also into the TIM function 
	 * Ref. LBMAA-A-D 6.6, 6-6 */
        if (!isChain) {
        	gettimeofday(&tv, NULL);
           	beginS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
        }

	/* and finally, execute program if everything in preParse() is OK */
	if (isHeader) fprintf(stdout,"\n\n\n");
	preParse(m);
	/* check if start line is within a DEF FN */
	if (fm[startingLine]) perror_(40,l,startingLine);
	parse(m,B);
}


/* END()
 * end program, accomplishing various tasks, such as closing opened channels,
 * print timing, fixing graphical stuff and closing regularly as C requires.
 * Note: as exit state, return the state passed to it as argument.
 * Note: as the returned states, I use:
 * EXIT_SUCCESS (which is 0) to indicate a proper successful execution
 * EXIT_FAILURE (which is 1) to indicate a stop after an error condition
 * EXIT_STOP (which is 2) to indicate an invoked (successful) STOP termination
 * Ref. LBMAA-A-D 1.4.7, 1-10, "END Statement" (not much about it, though) 
 * Ref. LBMAA-A-D 6.3, 6-5, "STOP Statement" */
void END(int state) {
	/* record end time 
	 * Note: if file was not found, beginS remains negative */
	if (beginS<0) endS=0.0;
	else {
		gettimeofday(&tv, NULL);
	       	endS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS=endS-beginS;
	}

	/* CTRL-C was pressed */
	if (isInterrupt) fprintf(stdout, "\n^C\n\nREADY\n");
	/* print time string and the READY prompt */
	else if (isHeader) {
		/* if the exit is normal (i.e. no errors), print one void line;
		 * Note: this has been tested, but the LCM has an unpredictable
		 * behaviour that I tried to simulate, not so successfully */
		if (state!=EXIT_FAILURE) fprintf(stdout,"\n");
		if (channel[0].fcounter) FCR(0);
		if (endS>0.0) fprintf(stdout, "\n");
		fprintf(stdout,"\nTIME:  %.2f SECS.\n\nREADY\n",endS);
	}
	/* one void line for RUNNH */
	else fprintf(stdout,"\n");

	/* flush all open streams, to ensure file data writing is completed */
	fflush(NULL);

	/* now it's time to stop execution... BYE! */
	exit(state);
}



/******************************************************************************
 * The following functions constitute the whole parser engine:
 * S() 		  : the numerical expression parser
 * getVal()	  : the single numerical value parser 
 * getFunc()	  : the numerical function parser
 * priority()	  : return numerical operator precedence
 * SS() 	  : the strings expression parser
 * strRel()       : the strings relation evaluator (returns a truth value)
 * conceived April 2008 for the dib project
 * modified for vibes with strings insertion September-November 2009
 * updated and verified for decb - February 2013, February-April 2014
 * Copyleft Antonio Maschio - 2008-2014 
 ******************************************************************************/


/* SS()
 * The PARSER for string expression; it's a general routine that contains
 * also evaluation of functions and concatenation of strings in series
 * if the + (plus) or & (ampersand) operators are used. 
 * The name SS() comes from S() and the second S means "strings".
 * The address of starting position into the flow stream is pointed by p 
 * The algorithm is as follows: 
 * until there is a string in any form, append it to mypad; return mypad. */
char* SS(void) {
	int i;
	char mypad[COMPSTR];

	/* reset local pad */
	for (i=0;i<=MAXSTRLEN;i++) mypad[i]='\0';
	MYPAD=mypad;
	p--;

	/* calculate string result
	 * accept only concatenation with '+' 
	 * Ref. LBMAA-A-D 8.5, 8-6, "String Concatenation" */
	do {
		p++;
		/* get errors in concatenated strings */
		if (!isanystring(p)) perror_(37,l);
		/* concat a pure explicit string */
		if (*p=='\"') {
			char op[MAXSTRLEN+1], *P1=op;
			p++;
			while (*p && *p!='\"') *P1++=*p++; 
			*P1='\0';
			if (*p=='\"') p++; // skip closing quotes
			else if (*p=='\n' || !*p) perror_(35,l); // tested
			if (strlen(mypad)+strlen(op)>MAXSTRLEN) perror_(124,l);
			strncat_(mypad,op,COMPSTR);
		}
		/* string arrays */
		else if (varcheck(p,SIMPSTRARR)) {
			int var=0,M=0;
			var=*p, p+=3; // skip var, '$' and '('
			M=(int)S();
			if(*p!=')') perror_(37,l);
			if (strlen(mypad)+strlen(getArrayStr(var,1,M,0))>\
					MAXSTRLEN)
				perror_(124,l);
			strncat_(mypad,getArrayStr(var,1,M,0),COMPSTR); 
			p++; 
		}
		else if (varcheck(p,DOUBSTRARR)) {
			int var=0,M=0;
			var=in(*p,*(p+1)), p+=4; // skip var, '$' and '('
			M=(int)S();
			if(*p!=')') perror_(37,l);
			if (strlen(mypad)+strlen(getArrayStr(var,1,M,0))>\
					MAXSTRLEN)
				perror_(124,l);
			strncat_(mypad,getArrayStr(var,1,M,0),COMPSTR); 
			p++; 
		}
		/* concatenate a simple string variable A$ */
		else if (varcheck(p,SIMPSTR)) {
			if (PS[(int)*p]) {
				if (strlen(mypad)+strlen(PS[(int)*p])>MAXSTRLEN)
					perror_(124,l);
				if (strlen(PS[(int)*p])) 
					strncat_(mypad,PS[(int)*p],COMPSTR);
			}
			p+=2;
		}
		/* concatenate a double string variable A1$ */
		else if (varcheck(p,DOUBSTR)) {
			int val=in(*p,*(p+1));
			if (PS[val]) {
				if (strlen(mypad)+strlen(PS[val])>MAXSTRLEN)
					perror_(124,l);
				if (strlen(PS[val])) 
					strncat_(mypad,PS[val],COMPSTR);
			}
			p+=3;
		}
		/* CHR$ function 
		 * Ref. LBMAA-A-D 8.6.2, 8-7, "The ASC and CHR$ Functions" */
		else if (!strncmp(p,"CHR$(",5)) {
			int chr;
			p+=5;
			chr=(char)S();
			MYPAD=mypad+strlen(mypad);
			if (chr<0 || chr>127) perror_(74,l); // tested
			if (chr>=10 && chr<=13) perror_(86,l); // tested
			if (strlen(mypad)<MAXSTRLEN-1) {
				*MYPAD++=chr;
				*MYPAD='\0';
			}
			else perror_(124,l);
			if (*p==')') p++;
			else perror_(37,l);
		}
		/* SPACE$ function
		 * Ref. LBMAA-A-D 8.6.5, 8-11, "The SPACE$ Function" */
		else if (!strncmp(p,"SPACE$(",7)) {
			int sp;
			p+=7;
			sp=(int)S();
			if (sp<0 || sp>MAXSTRLEN) perror_(122,l);
			if (strlen(mypad)+sp>MAXSTRLEN)	perror_(124,l);
			strncat_(mypad,spaces(sp),COMPSTR);
			if (*p==')') p++;
			else perror_(37,l);
		}
		/* STR$ function 
		 * Ref. LBMAA-A-D 8.6.3, 8-8, "The VAL and STR$ Functions" */
		else if (!strncmp(p,"STR$(",5)) {
			double val;
			char num[64], *pnum=num;
			p+=5;
			val=S();
			printNUM(0,val,TRUE,num);
			/* discard trailing spaces */
			pnum=num+strlen(num)-1;
			while (*pnum==' ') *pnum--='\0';
			pnum=num;
			while (*pnum==' ') pnum++;
			/* check length 	*/
			if (strlen(mypad)+strlen(pnum)>MAXSTRLEN)
				perror_(124,l);
			strncat_(mypad,pnum,COMPSTR);
			if (*p==')') p++;
			else perror_(37,l);
		}
		/* LEFT$ function   
		 * Ref. LBMAA-A-D 8.6.4, 8-9, "The LEFT$, RIGHT$, and MID$
		 * Functions" */
		else if (!strncmp(p,"LEFT$(",6)) {
			char op[COMPSTR],*P1=op;
			int pos;
			p+=6;
			sprintw(op,COMPSTR,"%s",SS());
			if (*p==',') p++;
			else perror_(37,l);
			pos=(int)S();
			/* Ref. LBMAA-A-D 8.6.4, 8-9, "...If the specified
			 * number of characters is less than or equal to zero,
			 * an error message is issued." */
			if (pos<=0) perror_(93,l); // tested
			/* Ref. LBMAA-A-D 8.6.4, 8-9, "...If the specified
			 * number of characters is greater than the length of
			 * the string, the entire string is returned." */
			if (pos>strlen(op)) pos=strlen(op);
			*(P1+pos)='\0';
			/* string is too long */
			if (strlen(mypad)+strlen(op)>MAXSTRLEN)
				perror_(124,l);
			strncat_(mypad,op,COMPSTR);
			if (*p==')') p++;
			else perror_(37,l);
		}
		/* MID$ function   
		 * Ref. LBMAA-A-D 8.6.4, 8-9, "The LEFT$, RIGHT$, and MID$
		 * Functions" */
		else if (!strncmp(p,"MID$(",5)) {
			char op[COMPSTR],*P1=op;
			int mstart,mlen;
			p+=5;
			sprintw(op,COMPSTR,"%s",SS());
			if (*p==',') p++;
			else perror_(37,l);
			mstart=(int)S();
			/* The second number formula may be omitted
			 * Ref. LBMAA-A-D 8.6.4, 8-10 */
			if (*p==',') {
				p++;
				mlen=(int)S();
			}
			else mlen=strlen(op);
			/* Ref. LBMAA-A-D 8.6.4, 8-10, "...If [the first 
			 * numeric formula] is less than or equal to zero, an 
			 * error message is issued." 
			 * "...If the number of characters [for the second 
			 * numeric formula] is less than or equal to zero, an 
			 * error message is issued." */
			if (mstart<=0 || mlen<=0) perror_(100,l);
			/* Ref. LBMAA-A-D 8.6.4, 8-10, "...MID$ returns a null
			 * string if the first numeric formula [...] is greater
			 * than the number of characters in the string 
			 * argument..." */
			if (mstart>strlen(op)) mstart=strlen(op),mlen=0;
			if (strlen(mypad)+mlen+1<MAXSTRLEN) 
				*(P1+mstart-1+mlen)='\0';
			/* string is too long */
			if (strlen(mypad)+strlen(P1+mstart-1)>MAXSTRLEN)
				perror_(124,l);
			strncat_(mypad,P1+mstart-1,COMPSTR);
			if (*p==')') p++;
			else perror_(37,l);
		}
		/* RIGHT$ function 
		 * Ref. LBMAA-A-D 8.6.4, 8-9, "The LEFT$, RIGHT$, and MID$
		 * Functions" */
		else if (!strncmp(p,"RIGHT$(",7)) {
			char op[COMPSTR],*P1=op;
			int pos;
			p+=7;
			sprintw(op,COMPSTR,"%s",SS());
			if (*p==',') p++;
			else perror_(37,l);
			pos=(int)S();
			/* Ref. LBMAA-A-D 8.6.4, 8-10, "...If the specified
			 * number of characters is less than or equal to zero,
			 * an error message is issued." */
			if (pos<=0) perror_(119,l);
			/* Ref. LBMAA-A-D 8.6.4, 8-10, "...If the specified
			 * number of characters is greater than the length of 
			 * the string, the entire string is returned." */
			if (pos>strlen(op)) pos=strlen(op);
			pos=strlen(op)-pos;
			/* string is too long */
			if (strlen(mypad)+strlen(P1+pos)>MAXSTRLEN)
				perror_(124,l);
			strncat_(mypad,P1+pos,COMPSTR);
			if (*p==')') p++;
			else perror_(37,l);
		}
		if (!*p || *p==',' || *p==';') break;
	} while (*p=='+');
	strncpy_(sspad,mypad,COMPSTR);
	MYPAD=mypad;
	return MYPAD;
}


/* strRel()
 * evaluate a string expression, with operators <, >, =, � (for <>),
 * � (for <=) and ! (for >=); 
 * always return a truth value
 * Note: in relations, any kind of string variable (even string vectors)
 * may be used into the formula.
 * Note: since evaluation of string relations is useful only into IF..THEN 
 * statements, they are recognized/used there, and not into SS(); see Ref. 
 * LBMAA-A-D, 1.3.5, 1-6, "Relational Symbols", where it's written:
 * "Six other mathematical symbols of relation are used in IF-THEN statements 
 * where it is necessary to compare values." */
int strRel(void) {
	int rel=FALSE, operator;
	char op1[LIMIT+1], op2[LIMIT+1], *P1=op1, *P2=op2;

	/* read operands and operator */
	strncpy_(op1,SS(),LIMIT+1);
	operator=*p++;
	strncpy_(op2,SS(),LIMIT+1);
	/* delete trailing spaces before and after strings */
	P1=op1+strlen(op1)-1; while (isblank(*P1)) *P1--='\0';
	P2=op2+strlen(op2)-1; while (isblank(*P2)) *P2--='\0';
	P1=op1; while (isblank(*P1)) P1++;
	P2=op2; while (isblank(*P2)) P2++;

	/* apply operator */
	switch(operator) {
		case '<': if (strcmp(P1,P2) < 0)  rel=TRUE; break;
		case '>': if (strcmp(P1,P2) > 0)  rel=TRUE; break;
		case '=': if (!strcmp(P1,P2))     rel=TRUE; break;
		case '�': if (strcmp(P1,P2))      rel=TRUE; break;
		case '�': if (strcmp(P1,P2) <= 0) rel=TRUE; break;
		case '!': if (strcmp(P1,P2) >= 0) rel=TRUE; break;
		default :   perror_(41,l);
	}

	return rel;
}


/* priority()
 * return math priority for operator op, according to the following table:
 * 6: the minus is evaluated immediately
 * 5: (..) parentheses (caught in getVal) have the highest precedence
 * 4: power (^ and **)
 * 3: multiplication, division
 * 2: addition, subtraction
 * 1: <, >, =, <=, >=, <> (also for strings)
 * 0: anything else has NULL priority and should cause error 
 * Note: string concatenation operators (in the syntax + and &) are evaluated 
 * directly into SS(); string relational operators (<, >, <=, >=, =, <>) are
 * evaluated into strRel(), which is invoked only into IFTHEN()
 * Ref. LBMAA-A-D 1.3.5, 1-6, "Relational Symbols"
 * Note: PRIOR is defined as the highest priority returned by priority(), thus
 * excluding the leading minus and the parentheses. */
int priority(const int op) {
	if (op=='^' || op=='�') return 4;
	else if (op=='*'||op=='/') return 3;
	else if (op=='+'||op=='-') return 2;
	else if (op=='<'||op=='>'||op=='='||op=='�'||op=='�'||op=='!') return 1;
	return 0;
}
#define PRIOR 4


/* S()
 * The PARSER for numerical expressions
 * The address of starting position into the flow stream is pointed by p 
 * The algorithm is as follows: 
 * an algebraic expression is turned into an RPN stack-based expression, 
 * with numbers and operators in order in their own stack; operations are 
 * performed from higher priorities down to lower and from left to right;  
 * priorities are given by the priority() function, which is part of this tool.
 * Note: the name S() is retained from Spinellis version. 
 * Note: the < and > operators (with their companion <= and >=) may not give 
 * the same results of the DEC BASIC with big numbers, because of the different 
 * ways of storing numbers; for instance, 1E29*10 is not stored in the same way 
 * of 1E30, because of rounding errors in calculating the multiplication 
 * (the error propagates rapidly when big numbers are calculated in series).
 * So don't expect the very same behaviors with big numbers.
 * Ref. LBMAA-A-D 1.3.3, 1-6, "Numbers" */
double S(void) {
	double numStack[PSTACK];
	int opStack[PSTACK], prStack[PSTACK], numTOS=0, opTOS=0, ii,jj, level;
	char* pcopy=NULL;

	/* catch unary plus at start (simply discarded because redundant)
	 * Note: the LBMAA-A-D 1.3.1, 1-6 states that two operators must not 
	 * be contiguous, apart from *, ** and ^ which may be followed by 
	 * + or -; decb respect this feature, but its parser is built in such 
	 * a way that the unary sign (+ or -) is tightly bound to the entity 
	 * following it, so that operations like -3+-2, +3+-2, -3-+2, +3-+2 are 
	 * accepted; this is a small difference with the LBMAA-A-D behavior */
	if (*p=='+') p++;
	/* catch unary minus at start */
	else if (*p=='-') {
		double res;
		p++; // skip '-'
		res=getVal();
		if (*p=='^' || *p=='�') {
			/* power following a unary minus has higher priority */
			double expon;
			int sign=1;
			p++;
			if (*p=='-') p++, sign=-1;
			else if (*p=='+') p++;
			expon=sign*getVal();
			res=-power(res,expon);
		}
		else res=-res;
		numStack[numTOS++]=res;
		opturn=1;
		/* short circuit: if number is followed by comma, semicolon
		 * or colon or closed parentheses or backslash or void, 
		 * return it immediately */
		if (!*p||*p==','||*p==';'||*p==':'||*p==')'||*p=='\\') 
			return res;
	}

	pcopy=p;
	/* reverse algebraic expression into a stack-based structure */
	while (*p && !iscs(p) && *p!='\"' && *p!='\'' && !isblank(*p) \
			&& *p!=':' && *p!='\?'){
		if (!strncmp(p,"**",2) && opturn) {
			*p='^', *(p+1)='0';
		}
		/* catch an operator */
		if (isop(p) && opturn) {
			opStack[opTOS]=*p;
			prStack[opTOS]=priority(*p);
			opTOS++;
			p++;
			opturn=0;
			/* operator followed by void is an illegal formula */
			if (!*p) perror_(37,l);
		}
		/* catch a closed parenthesis */
		else if (*p==')') break;
		/* catch the unary minus after an operator */
		else if (*p=='-' && !opturn) {
			p++;
			numStack[numTOS++]=-getVal();
			opturn=1;
		}
		/* catch the unary plus after an operator */
		else if (*p=='+' && !opturn) {
			p++;
			numStack[numTOS++]=getVal();
			opturn=1;
		}
		/* catch a number (literal or variable) */
		else {
			numStack[numTOS++]=getVal();
			opturn=1;
		}
		/* Note about the variables parsing:
		 * in the LCM BASIC two variables may be attached in a PRINT 
		 * statement, as in PRINT P2I - tested - as if it was P2;I .
		 * On the other hand, while assigning, this is not valid 
		 * anymore; E=P2I is an error. Clearly, the DEC BASIC had 
		 * two parsers, one for PRINT and one for LET.
		 * Since decb has only one solid parser, I consider to second
		 * LET, since printing things like P2I is on the edge of bad 
		 * programming style, and could safely written (and correctly 
		 * executed by decb) as P2;I */

		/* The parsing stops in case a variable follows */
		pcopy=NULL;
		if ((isstr(p) || isnum(p)|| *p=='(') && opturn) 
			perror_(65,l,makechar(p),TERMINAT);
	}

	/* No parsing has been done if the string is not void */
	if (pcopy==p) perror_(37,l);
	/* perform calculations from higher priorities downward
	 * Note: as stated in the LBMAA-A-D 1.3.5, 1-8,  the relational
	 * operators =, <, <=, >, >=, <> are used into IF-THEN statements.
	 * This algorithm, instead, consider them as usual math operators,
	 * and thus, for decb, any relation is also a math expression 
	 * Ref. LBMAA-A-D 1.3.1, 1-4, "Arithmetic Operations" 
	 * Ref. LBMAA-A-D 1.3.5, 1-6, "Relational Symbols" */
	for (ii=PRIOR;ii>=0;ii--) {
		/* calculations are performed from left to right */
		for (level=0;level<opTOS;level++) {
			if (prStack[level]==ii) {
				/* collapse stacks */
				switch(opStack[level]) {
// HERE BEGINS OPERATORS ANALYSIS
/* less than < */
case '<': numStack[level]=-(double)(numStack[level]<numStack[level+1]); break; 
/* greater than > */
case '>': numStack[level]=-(double)(numStack[level]>numStack[level+1]); break; 
/* not equal <> */
case '�': numStack[level]=-(double)(numStack[level]!=numStack[level+1]); break;
/* greater than or equal >= */
case '!': numStack[level]=-(double)(numStack[level]>=numStack[level+1]); break;
/* less than or equal <= */
case '�': numStack[level]=-(double)(numStack[level]<=numStack[level+1]); break;
/* equal = */
case '=': numStack[level]=-(double)(numStack[level]==numStack[level+1]); break;
/* power ^ */
case '^': numStack[level]=power(numStack[level],numStack[level+1]); break;
/* subtraction - */
case '-': numStack[level]-=numStack[level+1]; break;
/* addition + */
case '+': numStack[level]+=numStack[level+1]; break;
/* division / */
case '/': {
		double div=numStack[level+1];
		/* if divisor (div) is null, return INFF */
		if (div==0) {
			perror_(77,l);
			numStack[level]=numStack[level]>0?INFF:MINFF;
		}
		else numStack[level]/=div;  
	  }
	  break;
/* multiplication * */
case '*': numStack[level]*=numStack[level+1]; break;
// HERE ENDS OPERATORS ANALYSIS
				}
				/* shift stack positions */
				for (jj=level;jj<opTOS-1;jj++) {
					numStack[jj+1]=numStack[jj+2];
					opStack[jj]=opStack[jj+1];
					prStack[jj]=prStack[jj+1];
				}
				opTOS--;
				level--;
			}
		}
	}
	
	/* At this point, we have the final result into cell [0] */
	return numStack[0];
}


/* getVal()
 * get single value (number, variable, function or array element) 
 * the case of the unary minus has been caught in S() 
 * The address of starting position into the flow stream is pointed by p */
double getVal(void){
	double o=0;
	
	/* case of a real number 
	 * Note: in par. 1.3.3, page 1-7, the LBMAA-A-D states that an
	 * integer number may not contain more than 8 digits. The strtod()
	 * C function operates on bigger numbers, so that it's possible
	 * to grab numbers wider than 8 digits. But in effect this is what
	 * the DEC BASIC does - tested */
	if (isnm(p)) {
		char *basep=p;
		o=strtod(p,&p);

		/* error in number conversion */
		if (basep == p) perror_(34,l);
	}
	/* case of unary minus 
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='-') {
		p++;
		o=-getVal();
	}
	/* case of open parenthesis */ 
	else if (*p=='(') { 
		p++;
		o=S();
		if (*(p)!=')') perror_(37,l);
		else p++; 
	}
	/* case of array variable */
	else if (varcheck((p),SIMPARR) || varcheck((p),DOUBARR)) {
		int var=0,M=0,N=0,T=0;
		if (varcheck(p,SIMPARR)) var=*p++;
		else if (varcheck(p,DOUBARR)) var=in(*(p),*(p+1)),p+=2;
		else perror_(37,l);
		p++; // skip '('
		M=(int)S();
		if (M<0) perror_(76,l); 
		if (dim[var].type) T=dim[var].type;
		if (!T) T=1;
		if(*p==',') {
			p++;
		        N=(int)S();
			if (N<0) perror_(76,l);
			T=2;
		}
		o=getArrayVal(var,T,M,N); p++; 
	}
	/* case of variable A..Z */
	else if (varcheck(p,SIMPVAR)) { o=P[(int)*p++]; }
	/* case of variable A0..Z9 */
	else if (varcheck(p,DOUBVAR)) { o=P[in(*(p),*(p+1))]; p+=2; }
	/* delegate function calculations to getFunc() */
	else if (varcheck(p,FUNCTION)) { o=getFunc(), p++; }
	else perror_(37,l);
	return o;
}


/* getFunc()
 * functions calculator */
double getFunc(void){
	double o=0.0;
	int paren=TRUE;
	
	/* ABS function 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	if     (!strncmp(p,"ABS(",4)) p+=4,o=fabs(S());
	/* ASC function 
	 * Ref. LBMAA-A-D 8.6.2, 8-7, "The ASC and CHR$ Functions" */
	else if(!strncmp(p,"ASC(",4)) {
		p+=4;
		/* void argument - tested */
		if (*p==')') perror_(32,l);
		else if(!strncmp(p,"NUL",3)) o=0,p+=3;
		else if(!strncmp(p,"SOH",3)) o=1,p+=3;
		else if(!strncmp(p,"STX",3)) o=2,p+=3;
		else if(!strncmp(p,"ETX",3)) o=3,p+=3;
		else if(!strncmp(p,"EOT",3)) o=4,p+=3;
		else if(!strncmp(p,"ENQ",3)) o=5,p+=3;
		else if(!strncmp(p,"ACK",3)) o=6,p+=3;
		else if(!strncmp(p,"BEL",3)) o=7,p+=3;
		else if(!strncmp(p,"BS",2)) o=8,p+=2;
		else if(!strncmp(p,"HT",2)) o=9,p+=2;
		else if(!strncmp(p,"LF",2)) o=10,p+=2;
		else if(!strncmp(p,"VT",2)) o=11,p+=2;
		else if(!strncmp(p,"FF",2)) o=12,p+=2;
		else if(!strncmp(p,"CR",2)) o=13,p+=2;
		else if(!strncmp(p,"SO",2)) o=14,p+=2;
		else if(!strncmp(p,"SI",2)) o=15,p+=2;
		else if(!strncmp(p,"DLE",3)) o=16,p+=3;
		else if(!strncmp(p,"DC1",3)) o=17,p+=3;
		else if(!strncmp(p,"DC2",3)) o=18,p+=3;
		else if(!strncmp(p,"DC3",3)) o=19,p+=3;
		else if(!strncmp(p,"DC4",3)) o=20,p+=3;
		else if(!strncmp(p,"NAK",3)) o=21,p+=3;
		else if(!strncmp(p,"SYN",3)) o=22,p+=3;
		else if(!strncmp(p,"ETB",3)) o=23,p+=3;
		else if(!strncmp(p,"CAN",3)) o=24,p+=3;
		else if(!strncmp(p,"EM",2)) o=25,p+=2;
		else if(!strncmp(p,"SUB",3)) o=26,p+=3;
		else if(!strncmp(p,"ESC",3)) o=27,p+=3;
		else if(!strncmp(p,"FS",2)) o=28,p+=2;
		else if(!strncmp(p,"GS",2)) o=29,p+=2;
		else if(!strncmp(p,"RS",2)) o=30,p+=2;
		else if(!strncmp(p,"US",2)) o=31,p+=2;
		else if(!strncmp(p,"SP",2)) o=32,p+=2;
		else o=*p++;
		if (*p!=')') perror_(65,l,makechar(p),")"); // tested
	}
	/* ATN function 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"ATN(",4)) p+=4,o=atan(S());
	/* COS function 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"COS(",4)) {
		p+=4;
		o=S();
		if (fabs(o)>SINCOSBOUND) {
			perror_(97,l);
			o=0.0;
		}
		else o=cos(o);
	}
	/* COT function 
	 * reduce to a value between -HALFPI and HALFPI
	 * if lower than ZERO, return infinity
	 * Note: calculation follows a safer cos/sin instead of 1/tan 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"COT(",4)) {
		double v;
		p+=4;
		v=o=S();
		while (v>HALFPI) v-=HALFPI*2;
		while (v<-HALFPI) v+=HALFPI*2;
		if (fabs(HALFPI-fabs(v))<ZERO || fabs(v)<ZERO) {
			perror_(127,l);
			o=v<HALFPI?INFF:MINFF;
		}
		else o=cos(o)/sin(o);
	}
	/* DET(X) 'variable' with dummy argument det - tested */
	else if(!strncmp(p,"DET(",4)) {
		p+=4;
		o=S(); // dummy
		o=detValue;
	}
	/* DET 'variable'
	 * Ref. LBMAA-A-D 7.10, 7-4, "MAT C=INV(A) and the DET Function" */
	else if(!strncmp(p,"DET",3)) o=detValue, p+=2, paren=FALSE;
	/* ERFC(X) function - Undocumented 
	 * usage: internal testing (inner Pseudo-random Number Generator) */
	else if(!strncmp(p,"ERFC(",5)) {
		p+=5,o=S(); // argument
		o=erfc(o);
		if (fabs(o)<ZERO) o=0.0;
	}
	/* EXP function
	 * general overflow and underflow are found by printNUM 
	 * here EXP detects overflow and underflow of the argument 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"EXP(",4)) {
		p+=4,o=S(); // argument
		/* the following limits were tested on the LCM */
		if (o<-EXPOVERFLOW) { perror_(129,l); o=0.0; }
		if (o>EXPOVERFLOW) { perror_(115,l); o=EXPOVERFLOW; }
		o=exp(o);
	}
	/* FN (of DEF FN) - delegate calcDEF()
	 * Ref. LBMAA-A-D 5.1.6, 5-5, "The Define User Function (DEF) and
	 * the Function End Statements (FNEND)" */
	else if(!strncmp(p,"FN",2)) {
		double o1=0.0;
		p+=2;
		p=calcDEF(&o1);
		if (*p!=')') paren=FALSE;
		o=o1;
	}
	/* INT function 
	 * Ref. LBMAA-A-D 5.1.1, 5-1, "The Integer Function (INT)" */
	else if(!strncmp(p,"INT(",4)) { 
		p+=4;
		o=((o=(int)S())>=0)?o:o-1; 
	}
	/* LEN function 
	 * Ref. LBMAA-A-D 8.6.1, 8-6, "The LEN Function" */
	else if(!strncmp(p,"LEN(",4)) {
		p+=4;
		o=strlen(SS());
	}
	/* LN function (the forms LOGE and LOG are also available) 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions"  */
	else if(!strncmp(p,"LN(",3)) {
		p+=3, o=S();
		if (o<0)  {perror_(95,l); o=log(fabs(o));}
		else if (o==0) {perror_(96,l); o=MINFF;}
		else o=log(o);
	}
	/* CLOG function (the form LOG10 is also available) 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"CLOG(",5)) {
		p+=5, o=S();
		if (o<0)  {perror_(95,l); o=log10(fabs(o));}
		else if (o==0) {perror_(96,l); o=MINFF;}
		else o=log10(o);
	}
	/* NUM(X) function with dummy argument
	 * Ref. LBMAA-A-D 7.4, 7-3, "MAT INPUT and the NUM Function" 
	 * Ref. LBMAA-A-D 8.1, 8-1, "Reading and printing Strings" */
	else if(!strncmp(p,"NUM(",4)) { 
		p+=4;
		o=S(); // dummy
		o=numValue; 
	}
	/* NUM 'variable' */
	else if(!strncmp(p,"NUM",3)) o=numValue, p+=2, paren=FALSE;
	/* RND(N) function (dummy argument - tested)
	 * Ref. LBMAA-A-D 5.1.2, 5-1, "The Random Number Generator Function
	 * (RND)" */
        else if(!strncmp(p,"RND(",4)) p+=4, o=S(), o=getRandom();
	/* RND 'variable' */
        else if(!strncmp(p,"RND",3)) o=getRandom(), p+=2, paren=FALSE;
	/* SGN function
	 * Ref. LBMAA-A-D 5.1.4, 5-4, "The Sign Function (SGN)" */
	else if(!strncmp(p,"SGN(",4)) {p+=4, o=S(); o=(o<0?-1:(!o?0:1));}
	/* SQR function (the form SQRT is also available) 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */ 
	else if(!strncmp(p,"SQR(",4)) {
		p+=4; 
		o=S();
		/* negative argument (the message was in the original BASIC) */
		if (o<0) { 
			perror_(123,l); 
			o*=-1; 
		} 
		o=sqrt(o);
	}
	/* SIN function 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"SIN(",4)) {
		p+=4;
		o=S();
		if (fabs(o)>SINCOSBOUND) {
			perror_(97,l);
			o=0.0;
		}
		else o=sin(o);
	}
	/* TAN function 
	 * reduce to a positive value between 0 and 2*HALFPI 
	 * in the proximity of HALFPI return infinity 
	 * Ref. LBMAA-A-D 1.3.2, 1-5, "Mathematical Functions" */
	else if(!strncmp(p,"TAN(",4)) {
		double v;
		p+=4;
		v=o=S();
		while (v>2*HALFPI) v-=HALFPI;
		while (v<0) v+=2*HALFPI;
		/* this message should appear only when the argument is exactly 
		 * HALFPI, because it's the only way to write a BASIC decimal 
		 * which has a difference with HALFPI less than ZERO (which 
		 * is very very small, in the order of 1E-39) */
		if (fabs(v-HALFPI)<ZERO) {
			perror_(127,l);
			o=tan(o)>0?INFF:MINFF;
		}
		else o=tan(o);
	}
	/* TIM variable or function with dummy value 
	 * beginS is calculated in RUN() with the first program 
	 * (i.e. out of a CHAIN sequence) 
	 * Note: The original TIM function returned the elapsed execution
	 * time in seconds, from the very beginning, but excluding the load
	 * and compilation time of the first program in a CHAIN; this seems
	 * strange: why not excluding the load and compiling time of all
	 * CHAINed programs? In any case, decb must behave differently: TIM
	 * returns the elapsed execution time in seconds, from the beginning,
	 * of the interpreting and running time of all the CHAINed programs. 
	 * Ref. LBMAA-A-D 5.1.5, 5-4, "The Time Function (TIM)" */
        else if(!strncasecmp(p,"TIM",3)) { 
		double now;
		p+=3;
        	gettimeofday(&tv, NULL);
           	now = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		if (*p=='(') {
			p++;
			o=S(); // dummy
		}
		else p--, paren=FALSE;
		o=((int)(100*(now-beginS)+0.5))/100.0;
	}
	/* VAL function 
	 * Ref. LBMAA-A-D 8.6.3, 8-8, "The VAL and STR$ Functions" */
	else if (!strncmp(p,"VAL(",4)) {
		char op[LIMIT+1]; // to store string to parse for VAL
		char* pp=op;
		p+=4;
		if (isanystring(p)) {
			strncpy_(op,SS(),LIMIT+1);
		}
		else perror_(37,l); // tested
		/* Note: the only incorrect form of the argument 
		 * I can think of is if it's null */
		if (!strlen(op)) perror_(131,l); // tested
		o=strtod(pp,&pp);
		/* Ref. LBMAA-A-D 8.6.3, 8-8, "The string formula must look
		 * like a number"; this means that the original DEC BASIC 
		 * accepted only pure numbers in quotes, like "24", but not 
		 * formulas, like "23*SQR(4)", and so decb; in fact, after the 
		 * number read, there must be the end of string; if there is 
		 * any different character, the strtod() has found other than 
		 * a unique pure number (it's a formula or something), and 
		 * didn't convert it */
		if (*pp) perror_(131,l); // tested
	}
	/* INSTR function 
	 * Ref. LBMAA-A-D 8.6.6, 8-12, "The INSTR Function" */
	else if (!strncmp(p,"INSTR(",6)) {
		int pos=0;
		char op1[LIMIT+1], op2[LIMIT+1];
		char *P1;
		p+=6;
		/* the starting position has been set */
		if (!isanystring(p)) {
			pos=(int)S()-1;
			if (pos<0) perror_(92,l);
			if (*p==',') p++;
			else perror_(43,l);
		}
		/* first string is the base string */
		strncpy_(op1,SS(),LIMIT+1);
		if (*p==',') p++; else perror_(65,l,makechar(p),",");
		/* second string is the search string */
		strncpy_(op2,SS(),LIMIT+1);
		/* Ref. LBMAA-A-D 8.6.6, 8-11/12, "...If the value of the
		 * numeric formula [...] is greater than the number of 
		 * characters in the string [...], INSTR returns a value of 
		 * zero." */
		if (pos>strlen(op1)) o=0.0;
		else {
			/* set real starting position */
			P1=op1+pos;
			o=(int)(strstr(P1,op2)-op1)+1;
			/* Ref. LBMAA-A-D 8.6.6, 8-11/12, "...If the substring
			 * cannot be found in the string, INSTR returns a value 
			 * of zero." */
			if (o<0 || o>strlen(op1)) o=0.0;
		}
	}
	/* LOF function 
	 * Ref. LBMAA-A-D 10.6, 10-9, "The SET Statement and the LOC and LOF
	 * Functions" */
	else if (!strncmp(p,"LOF(",4)) {
		int ch;
		p+=4;
		if (*p==':') p++;
		ch=(int)S();
		/* check if file is open and random */
		if (ch<1 || ch>STREAMS) perror_(179,l);
		if (!channel[ch].isopen) perror_(80,l);
		if (channel[ch].type!=RANDOM) perror_(101,l);
		o=getEOF(ch);
	}
	/* LOC function 
	 * Ref. LBMAA-A-D 10.6, 10-9, "The SET Statement and the LOC and LOF
	 * Functions" */
	else if (!strncmp(p,"LOC(",4)) {
		int ch;
		p+=4;
		if (*p==':') p++;
		ch=(int)S();
		/* check if file is open and random */
		if (ch<1 || ch>STREAMS) perror_(179,l);
		if (!channel[ch].isopen) perror_(80,l);
		if (channel[ch].type!=RANDOM) perror_(101,l);
		o=channel[ch].currseek;
	}
	/* any other sequence of characters is a syntax error */
	else perror_(37,l);
	/* if more arguments follow, its a mistake */
	if (*p==',') perror_(43,l) ;
	/* check closing parenthesis - p is updated into getVal() */
	if (paren) {
		if (!*p) perror_(65,l,"A FF,LF,VT, OR CR",")");
		else if (*p!=')') perror_(33,l);
	}
	return o;
}


/******************************************************************************
 * The following functions define general system environment subroutines: 
 * they are internal routines not directly accessible as BASIC statements.
 ******************************************************************************/

/*****************************************
 *            STATEMENTS AID             *
 *****************************************/

/* formatAnalyzer()
 * Analyze the BASIC USING string for formatted output and convert it to C.
 * This is the routine used by all the PRINT/WRITE USING statements; the 
 * purpose of this function is building a C-format string from the BASIC format 
 * string, to ensure a correct printing according to the required features; 
 * the real numbers printing routine is delegated to printFormattedNumber() and 
 * the real strings printing routine is delegated to printString().
 * BForm: the BASIC formatter string
 * list: the sequence of what is to be printed (it follows the USING part)
 * isWrite: the WRITE flag: if TRUE, prints a Line Number + tab (WRITE) 
 * ch: the output/file channel id
 * Ref. LBMAA-A-D 11.2, 11-3, "Image Specifications"
 * Copyleft Antonio Maschio - April 2011 */
void formatAnalyzer(char* BForm, char* list, int isWrite, int ch) {
	char cForm[SCREENLINE+1], *cf=cForm;
	int i, ic=0,dc=0;	// ic=integers count, dc=decimals count
	int sL=0,nL=0; 	  	// sL=strings count, nL=numbers count in list
	int sF=0,nF=0; 	  	// sF=strings count, nF=numbers count in BForm
	int in,is;		// in and is are indexes for numbers/strings
	int inf,isf;		// inf and ins are field indexes
	double numb[MAXARGS];   	   // the stack for numbers in 'list'
	char stri[MAXARGS][SCREENLINE+1];  // the stack for strings in 'list'
	char *pb=p;
	char fl=' ', com=sep; 	// filler and separator
	TUsing dat[MAXARGS], datS[MAXARGS];
	// isInt = is Integer
	// isExp = is the number in exponential form
	// isMin = is the minus sign to be written at the end
	// isDol = is the dollar format enabled
	// isCom = is the thousands separator format enabled
	// isZer = is the zeroes format enabled
	int isInt, isExp, isMin, isDol, isCom, isZer;
	int len, type, items;
	int CNimage=0,VNlist=0;	// CNimage=num counter, VNlist=num counter
	int CSimage=0,VSlist=0;	// CSimage=str counter, VSlist=str counter
	int isCR=TRUE;	 	// the final Carriage Return is to be printed
	FILE* fd;

	/* erase the C-formatter */
	for (i=0; i<SCREENLINE; i++) cForm[i]='\0';

	/* get channel */
	fd=channel[ch].stream;

	/* step 1. build C images */
	while (*BForm) {
		isInt=TRUE, isExp=FALSE, isMin=FALSE;
		isDol=FALSE, isCom=FALSE, isZer=FALSE;
		len=0; type=LEFTJUST;

		ic=dc=0; isInt=TRUE;
		/* get numeric formatter; Ref. LBMAA-A-D 11.2.1, 11-3, 
		 * "Numeric Image Specifications" */
		if ((*BForm=='#' && *(BForm+1)=='#') ||\
				((*BForm=='.') && (*(BForm+1)=='#'))\
				||((*BForm=='*'&&*(BForm+1)=='*')&&((fl='*')))\
				||(*BForm=='$'&&*(BForm+1)=='$') ) {
			*cf++=NUMID;
			CNimage++;
			/* integer part 
			 * Ref. LBMAA-A-D 11.2.1.1, 11-3 
			 * "Integer Image Specifications" */
			while (*BForm && strchr(",.*#$",*BForm)) {
			        /* Ref. LBMAA-A-D 11.2.2, 11-5, "Comma"
				 * "Edited Numeric Image Specifications" */	
				if (*BForm==',') isCom=TRUE,BForm++,ic++;
			        /* Ref. LBMAA-A-D 11.2.2, 11-7, "Floating 
				 * Dollar sign", "Edited Numeric Image 
				 * Specifications"*/
				if (*BForm=='$') isDol=TRUE,BForm++,ic++;
			        /* Ref. LBMAA-A-D 11.2.2, 11-7, "Leading 
				 * Asterisk", "Edited Numeric Image 
				 * Specifications"*/
				if (*BForm=='*') BForm++,ic++;
			        /* Ref. LBMAA-A-D 11.2.1, 11-3
				 * "Numeric Image Specifications" */	
				if (*BForm=='#') BForm++,ic++;
				/* decimal part 
				 * Ref. LBMAA-A-D 11.2.1.2, 11-4
				 * "Decimal Image Specifications" */
				if (*BForm=='.') {
					BForm++;
					isInt=FALSE;
					while(*BForm&&strchr(",.*#$",*BForm)){ 
						if (*BForm==',') 
						    isCom=TRUE,BForm++,dc++;
						if (*BForm=='$') 
						    isDol=TRUE,BForm++,dc++;
						if (*BForm=='*') BForm++,dc++;
						if (*BForm=='#') BForm++,dc++;
					}
				}
			}
			/* exponential in case of float 
			 * Ref. LBMAA-A-D 11.2.1.2, 11-4
			 * "Decimal Image Specifications" */
			if (!isInt && !strncmp(BForm,"^^^^",4)) {
				BForm+=4;
				isExp=TRUE;
			}
			/* minus at the end 
			 * Ref. LBMAA-A-D 11.2.2, 11-5
			 * "Edited Numeric Image Specifications" */
			if (*BForm=='-') {
				BForm++;
				isMin=TRUE;
			}

			/* store current-image data */
			dat[nF].ic=ic;
			dat[nF].dc=dc;
			dat[nF].isInt=isInt;
			dat[nF].isExp=isExp;
			dat[nF].isMin=isMin;
			dat[nF].isCom=isCom;
			dat[nF].isDol=isDol;
			dat[nF].fill=fl;
			dat[nF].com=com;
			dat[nF].isZer=isZer;
			nF++;

		}
		/* get string formatter 
	         * Ref. LBMAA-A-D 11.2.3, 11-8,
		 * "String Image Specifications" */	
		else if (*BForm=='\'') {
			*cf++=STRID;
			CSimage++;
			len=1;
			BForm++;
			/* Ref. LBMAA-A-D 11.2.3, 11-9,
		 	 * "E Format Character" */
			if (*BForm=='E') {
				type=EXTENDED;
				while (*BForm=='E') BForm++,len++;
			}
			/* Ref. LBMAA-A-D 11.2.3, 11-9,
		 	 * "C Format Character" */
			else if (*BForm=='C') {
				type=CENTERED;
				while (*BForm=='C') BForm++,len++;
			}
			/* Ref. LBMAA-A-D 11.2.3, 11-9,
		 	 * "L Format Character" */
			else if (*BForm=='L') {
				type=LEFTJUST;
				while (*BForm=='L') BForm++,len++;
			}
			/* Ref. LBMAA-A-D 11.2.3, 11-9,
		 	 * "R Format Character" */
			else if (*BForm=='R') {
				type=RIGHTJUST;
				while (*BForm=='R') BForm++,len++;
			}
			/* store current-image data */
			datS[sF].len=len;
			datS[sF].type=type;
			sF++;
		}
		else *cf++=*BForm++;
	}
	
	/* step 2close the C-formatter */
	*cf='\0'; cf=cForm;
	
	/* step 3. grab arguments to be printed in 'list' */
	while (*list) {
		/* explicit string, variable string or function string */
		if (*list=='\"' || isstr(list) || isStrFunc(list)) {
			p=list;
			strncpy_(stri[sL++],SS(),SCREENLINE);
			list=p;
			VSlist++;
		}
		/* number */
		else {
			p=list;
			numb[nL++]=S();
			list=p;
			VNlist++;
		}
		if (!*list) isCR=TRUE;
		else if (*list==',' || *list==';') {
			list++;
			isCR=FALSE;
			if (!*list) perror_(37,l); // tested
		}
		else if (*list) perror_(65,l,FFLFVT,",");
	}

	/* step 4. check errors and discontinuities */
	if (VSlist && !VNlist && !CSimage && CNimage) perror_(68,l); // mixed
	if (!VSlist && VNlist && CSimage && !CNimage) perror_(68,l); // mixed
	if (VSlist && !CSimage) perror_(105,l); // no fields in str image
	if (VNlist && !CNimage) perror_(105,l); // no fields in num image

	/* step 5. print elements in order */
	in=is=0;
	inf=isf=0;
	items=sL+nL;
	
	while (items>0) {
		/* restart formatter if there are still items to print */
		if (!*cf) {
			FCR(ch);
			cf=cForm;
		}
		/* if the formatter is at the beginning, do WRITE line
		 * in a five digits number followed by a tab */
		if (cf==cForm && isWrite) { 
			fprintf(fd,"%05d\t",writeSeqStart);
			writeSeqStart+=writeSeqStep;
		}
		/* call print a number in a number field */
		if (*cf==NUMID) {
			printFormattedNumber(numb[in],dat[inf],ch);
			in++;
			cf++;
			inf++; if (inf>=nF) inf=0;
			items--;
		}
		/* call print a string */
		else if (*cf==STRID) {
			printString(stri[is],datS[isf],ch);
			is++;
			cf++;
			isf++; if (isf>=sF) isf=0;
			items--;
		}
		/* print the rest of the formatter string 
		 * Ref. LBMAA-A-D 11.2.4, 11-9,
		 * "Printing Characters" */
		while (*cf && *cf!=NUMID && *cf!=STRID && *cf!='\n') {
			if (*cf==',' && !*(cf+1)) break;
			fputc(*cf++,fd);
		}
	}
	/* step 6. close line */
	if (isCR) FCR(ch);
	if (strlen(BForm)>MAXSTRLEN) perror_(112,l);

	/* final step. restore general pointer */
	p=pb;
}


/* printString() 
 * print a formatted string according to BASIC formatting, following rules of 
 * chapter 11 of the LBMAA-A-D (1974);
 * str: the string to print
 * us: a TUsing structure holding formatting data
 * ch: the output channel id 
 * System function for the USING management */
void printString(char* str, TUsing us, int ch) {
	int thislen=strlen(str),i, tw=FORMATLINE*4+1;
	char format[tw];
	FILE* fd;

	/* get channel */
	fd=channel[ch].stream;

	/* set up left justification (with cut) */
	if (us.type==LEFTJUST) { // "%-s"
		if (thislen<us.len) 
			sprintw(format,tw,"%%-%d.%ds",us.len,us.len);
		else if (thislen>us.len) 
			sprintw(format,tw,"%%%d.%ds",us.len,us.len);
		else sprintw(format,tw,"%%s");
	}
	/* set up right justification (with cut) */
	else if (us.type==RIGHTJUST) 
		sprintw(format,tw,"%%%d.%ds",us.len,us.len);
	/* set up centered justification (with cut) */
	else if (us.type==CENTERED) {
		if (thislen<us.len) {
			for (i=0;i<(int)((us.len-thislen)/2);i++) {
				fputc(' ',fd);
			}
			sprintw(format,tw,"%%s");
		}
		else if (thislen>us.len) 
			sprintw(format,tw,"%%%d.%ds",us.len,us.len);
		else sprintw(format,tw,"%%s");
	}
	/* set up extended (with no cut) */
	else if (us.type==EXTENDED) sprintw(format,tw,"%%-%ds",us.len);
	/* print result */
	fprintf(fd,format,str);
	/* complete centered justification */
	if (us.type==CENTERED) 
		for(i=0;i<us.len-thislen-(int)((us.len-thislen)/2);i++) {
			fputc(' ',fd);
		}
}


/* printFormattedNumber() 
 * build the print environment of a float number according to BASIC USING 
 * formatter, following the rules of chapter 11 of the LBMAA-A-D; this routine 
 * uses the information contained in the BASIC formatter for building the 'us' 
 * formatter, leaving the physical printing of the number to outNum().
 * num: the floating point number to print
 * us: a TUsing structure holding formatting data
 * ch: the output channel id 
 * System function for the USING management */
void printFormattedNumber(double num, TUsing us, int ch) {
	int sign=1, nlen=0,b=0;
	FILE* fd;

	/* get channel */
	fd=channel[ch].stream;

	/* make checkings */
	if (us.isExp && (us.isDol || us.fill=='*')) perror_(78,l) ;

	/* convert num to a positive number, saving sign */
	if (num<0) sign=-1, num*=-1;

	/* Trap for numbers in the range ]-1,1[ when an integer is to be
	 * printed (that is, no decimal was specified in the BASIC format):
 	 * treat integer zero on its own, to avoid seeing -0 or 0- */
	if (num<1.0 && us.isInt && !us.isZer) {
		us.isZer=TRUE;
		printFormattedNumber(num,us,ch);
		return;
	}

	/* Treat minus identifier (LBMAA-A-D 11-6), which causes the
	 * possible negative minus sign to be printed afterwards;
	 * Note: the normal negative sign printing is embedded in the 
	 * following printing routine */
	if (sign<0) {
		if (us.isMin) {
			printFormattedNumber(num,us,ch);
			fputc('-',fd);
			return;
		}
		else if ((us.isDol || us.fill=='*')) perror_(67,l);
	}

	nlen=intLen(num);
	if (us.isCom) nlen+=(int)((nlen-1)/3); // add commas number
	b=nlen;
	/* normal form (options: dollar, commas or asterisk-fill) */
	if (!us.isExp) {
		if (us.isMin) {
			if (nlen < us.ic) {
				while (b++ < us.ic-1) {
					fputc(us.fill,fd);
				}
				if (us.isDol) fputc('$', fd); 
				else fputc(us.fill,fd);
			}
			if (nlen > us.ic || (nlen==us.ic && us.isDol)) {
				fputc('&',fd);
				if (us.isDol) fputc('$', fd); 
			}
		}
		else {
			if (nlen < us.ic) {
				while (b++ < us.ic-1) {
					fputc(us.fill,fd);
				}
				if (sign<0) fputc('-', fd);
				else if (us.isDol) fputc('$', fd);
				else fputc(us.fill,fd);
			}
			if (nlen > us.ic || (nlen== us.ic && sign<0)) {
				fputc('&',fd);
				if (sign<0) fputc('-',fd);
				else if (us.isDol) fputc('$', fd);
			}
		}
		outNum(num,us,ch);
	}
	/* exponential form 
	 * Note: exponentials never overflow; they adapt their format
	 * to the length of the integer part (minimum two placeholders),
	 * so that at least the sign and a digit can be represented; 
	 * if no dot is in the number image, the ^^^^ symbol is taken "as-is";
	 * if the dot is present, and isn't followed by any digits placeholders 
	 * in the number image, no decimal is printed, but the dot is. */
	else {
		char esign;
		int i=0, E=0, cut;
		if (num>ZERO) {
			int w;
			/* reduce to the 0.nnnnnnnn form */
			E=(int)(log10(num))+1;
			if (num>0.1 && num<1.0) E--;
			while (num >= 1.0) num/=10;
			while (num <  0.1) num*=10;
			/* expand to the maximum ic (integer digits count)
			 * space; in case of postponed minus, the space is 
			 * the  whole ic length, otherwise reserve one space 
			 * for the sign position (a white space in case 
			 * of positive numbers) */
			cut=us.isMin?0:1;
			while (i<us.ic-cut) i++, num*=10, E--;
			/* print sign, number and exponent */
			if (E<0) esign='-', E*=-1;
			else esign='+';
			if (sign<0) fputc('-',fd);
			else if (!us.isMin) {
				fputc(us.fill,fd);
			}
			outNum(num,us,ch);
			fprintf(fd,"E%c%02d%n",esign,E,&w);
		}
		else {
			/* in case of zero, fill with spaces before 0.0 */
			while (i<us.ic-1) {
				i++;
				fputc(us.fill,fd);
			}
			outNum(0.0,us,ch);
			fprintf(fd,"E+00");
		}
	}
}


/* intLen()
 * find the length of the integer part of any number passed as double, up to 
 * INFF (suitable for outNum). If the number is negative, it is turned to 
 * positive (the minus sign is not counted because printFormattedNumber() 
 * arranges it).
 * num: the float to be printed
 * System function for the USING management */
int intLen(double num) {
	int len=0;
	double integ;
	if (num<0) num*=-1;
	if (num<10) return 1;
	modf(num, &integ);
	while (!(1.0 > integ)) integ/=10,len++;
	return len;
}


/* outNum()
 * emit a positive float number according to the BASIC format.
 * num: the number to be printed 
 * us: a TUsing structure holding formatter data
 * ch: the output channel id 
 * System function for the USING management */
void outNum(double num, TUsing us, int ch) {
	int tw=FORMATLINE*4+1;
	char nums[tw], *np=nums, format[tw];
	int e=0, i=0, zero=FALSE, m=0;
	double temp;
	int pc=0; // print counter;
	FILE* fd; // channel stream upon ch

	/* get channel */
	fd=channel[ch].stream;

	/* if number must have no decimals and it's not an integer, it should 
	 * be rounded; so print it to a string, restore it and continue */
	if (!us.dc && !us.isInt) {
		sprintw(nums,tw,"%.0f", num);
		num=strtod(nums,NULL);
	}

	/* cut out significant digits after ninth
	 * by building number string in bare format through C */
	if (num<0) num*=-1; // just to be sure...
	if (num==0.0) zero=TRUE;
	else {
		while (num >= 1.0) num/=10, e++;
		while (num <  0.1) num*=10, e--;
	}
	sprintw(nums,tw,"%.9f",num);
	/* now number is in the form 0.XXXXXXXXX (9 significant digits)
	 * and 'e' holds the exponential factor */

	/* OUTPUT INTEGER PART */
	np+=2; // skip 0 and dot
	if (e<=0 || zero) {
		fputc('0',fd);
		pc++;
	}
	else {
		/* print all significant digits */
		while (i<e-1) {
			if (!*np) break;
			fputc(*np,fd);
			pc++;
			m=(e-i)%3;
			if (m==1 && us.isCom) {
				fputc(sep,fd);
				pc++;
			}
			i++,np++;
		}
		if (i<e && *np) {
			fputc(*np,fd);
			i++,np++,pc++;
		}
		/* if number is not finished, fill the rest with zeroes */
		while (i<e-1) {
			fputc('0',fd);
			pc++;
			m=(e-i)%3;
			if (m==1 && us.isCom) {
				fputc(sep,fd);
				pc++;
			}
			i++;
		}
		if (i<e) {
			fputc('0',fd);
			pc++;
		}
	}
	/* end up in case of integer */
	if (us.isInt) return;
	
	/* OUTPUT FRACTIONAL PART */
	i=0;
	fputc('.',fd);
	pc++;
	if (!us.dc) return; // zero decimals
	while(e<0 && i<us.dc) fputc('0',fd), i++, e++, pc++;
	if (e<0) return; // all digits have been printed; num is much lesser
	*(np-1)='.';
	temp=strtod(np-1,NULL);
	sprintw(format,tw,"%%0.%df",us.dc-i);
	sprintw(nums,tw,format,temp); // autoformat && autorounding
	fprintf(fd,"%s",nums+2);   // skip '0' and '.'
	pc+=strlen(nums)-2;
}


/* checkNames()
 * control if a file is already open (a file cannot be opened more than once, 
 * using FILES or FILE).
 * c: the channel id to check
 * fname: the file name to check 
 * return TRUE if a file already opened does exist, FALSE otherwise.
 * System function for the file management */
int checkNames(int c, char* fname) {
	int i=1, res=FALSE;
	while (TRUE) {
		if (i>STREAMS) break;
		else if (i==c);
		else if (!strcmp(channel[i].ioname,fname)) {
			res=TRUE; 
			break;
		}
		i++;
	}
	return res;
}


/* setupName()
 * check file name, returning correct file name with extension "BAS", if not
 * specified for an unexisting file; deprive name of file specifiers $ or %.
 * If an improper % character followed by number was chosen, len is -1.
 * fn: the file name string
 * mode: return character specifier '$' or '%' or NULL (e.g. $ or %)
 * len: return len of string field if specified (e.g. $15)
 * Note: this routine works with names for current directory; if names are 
 * contained into a path, this routine works if path does not contains dots;
 * if it does, the ? FILE %s NOT FOUND message will appear, unless the complete
 * name (with extension) is specified on the command line
 * Note: fn must be an array of width COMPSCR = SCREENLINE + 1
 * System function for the file management */
void setupName(char *fn, int *mode, int *len) {
	char*q=fn, ext[MAXSTRLEN];
	FILE *fd;

	/* setup defaults */
	*mode=0;
	*len=0;
	ext[0]='\0';

	/* check if the input file is a directory */
	stat(fn, &statbuf);
	if(S_ISDIR(statbuf.st_mode)) {
		beginS=-1;
		turnToUpper(fn);
		perror_(195,l,fn);
	}
	
	/* find extension start */
	while (*q) q++; // end of string
	while (*fn=='.') fn++; // skip starting points
	while (*q !='.' && q > fn && *q!='\\' && *q!='/') q--;

	/* there no extension in names with path */
	if (*q=='/' || *q=='\\') q=fn+strlen(fn)-1;
	/* there is an extension */
	else if (q > fn) {
		strncpy_(ext,q,MAXSTRLEN);
		*q='\0';
		q--;
	}
	/* there's no extension */
	else q=fn+strlen(fn)-1;

	/* there's a length (or at least I suppose there is) 
	 * Note: this function assumes that no file may be named with an ending 
	 * '$' or '%' followed by any digit, because it would be interpreted as 
	 * a random file; in any case, since it's bad practice in any OS naming 
	 * files using '$' or '%', I take it for granted. */
	if (isdigit(*q)) {
		while (isdigit(*q)) q--;
		/* it's really a field length */
		if (*q=='$') *len=(int)strtol(q+1,NULL,10);
		/* it's a wrong assignment */
		else if (*q=='%') {
			*len=-1;
			sprintw(fn,COMPSCR,"%d",(int)strtol(q+1,NULL,10));
			return;
		}
		/* it's not a field length: number is part of the filename */
		else {
			q++;
			while (isdigit(*q)) q++;
		}
	}
	
	/* there's a specifier $ or % */
	if (*q=='$' || *q=='%') *mode=*q--;

	/* delete specifier and extension */
	*++q='\0';

	/* if a dot was printed, but no extension specified, remove the dot */
	if (!strcmp(ext,".")) ext[0]='\0';

	/* if an extension was given as input, attach it */
	if (ext[0]) strncat_(fn, ext,COMPSCR);
	/* attach .BAS only if file does not exist 
	 * Note: file existence control is delegated to calling function */
	else {
		if (!(fd=fopen(fn,"r"))) strncat_(fn, EXT,COMPSCR);
		else fclose(fd);
	}
}


/* testEOF()
 * return TRUE if current file has passed the last character/item, or FALSE.
 * Note: it does NOT control if stream is open.
 * ch: the testing channel id 
 * System function for the file management */
int testEOF(int ch) {
	long res=FALSE, after, before=ftell(channel[ch].stream);
	/* get 'before' as current posision, and 'after' after position
	 * has been set to SEEK_END */
	fseek(channel[ch].stream,0,SEEK_END);
	after=ftell(channel[ch].stream);
	/* if they differ (at least by -1 factor, which is EOF), we are to the 
	 * end of file; return TRUE because we reached EOF, in BASIC slang */
	if (before-after>=-1) res=TRUE;
	/* restore position */
	fseek(channel[ch].stream,before,SEEK_SET);
	return res;
}


/* getEOF()
 * return location of last record for random access files
 * Note: it does NOT control if stream is open 
 * ch: the testing channel id 
 * System function for the file management */
int getEOF(int ch) {
	long back=ftell(channel[ch].stream);
	int res;
	/* calculate total offset in terms of records */
	fseek(channel[ch].stream,0,SEEK_END);
	res=((int)(ftell(channel[ch].stream)-FIRSTLEN)/channel[ch].reclen);
	/* restore position */
	fseek(channel[ch].stream,back,SEEK_SET);
	return res;
}


/* printContained() 
 * print a text into the MARGIN limit;
 * returns TRUE in case of correct printing.
 * ch: the output channel id
 * string: the string to be printed (number or string) 
 * margin: the channel margin (for speed)
 * System function for the printing management */
void printContained(int ch, char* string, int margin) {
	char out[margin], *o=out;
	if (!*string) return;
	if (channel[ch].fcounter+strlen(string)>=margin) FCR(ch);
	while (*string) {
		/* build part of string to be printed */
		o=out;
		while (*string && channel[ch].fcounter<margin) {
			*o++=*string++;
			channel[ch].fcounter++;
		}
		*o='\0';
		/* print string */	
		fprintf(channel[ch].stream,"%s",out);
		if (channel[ch].fcounter>=margin) FCR(ch);
	}
}


/* fillGap()
 * In a random file, fill the intermediate elements of a random access file 
 * with spaces, whenever the index is moved at least one element over the last;
 * used within FWRITECOLON() and in SET;
 * No checking is done upon channel
 * ch: the channel id
 * actualIndex: the current value of the random file position
 * System function for the printing management */
void fillGap(int ch, int actualIndex) {
	int i;
	for (i=1; i<channel[ch].currseek-actualIndex; i++) 
		fputc(' ',channel[ch].stream);
}


/* matReadAssign(result-matrix,type,rows,columns)
 * iterate through matrix indexes to assign numerical DATA values
 * var: the matrix code
 * t: the matrix type
 * m, n: matrix rows and columns numbers
 * System routine for matrix management, used into MATREAD() */
void matReadAssign(int var, int t, int m, int n){
	int i,j;
	/* vectors */
	if (1==t) {
		for(i=1;i<=m;i++) {
			if (dc>dataLimit) perror_(110,l);
			setArrayVal(var,1,i,0,D[dc++]);
		}
	}
	/* matrices */
	else {
		/* horizontal vectors */
		if (!m && n) {
			for (i=1;i<=n;i++) {
				if (dc>dataLimit) perror_(110,l);
				setArrayVal(var,2,0,i,D[dc++]);
			}
		}
		/* normal matrices */
		else for(i=1;i<=m;i++) 
			for (j=1;j<=n;j++) {
				/* if out of data, print warning */
				if (dc>dataLimit) perror_(110,l);
				setArrayVal(var,2,i,j,D[dc++]);
			}
	}
}


/* isod(string-position)
 * (IS a One Dimensional array)
 * test if p points to a one (TRUE) or two (FALSE) dimensions array.
 * p: (which is not touched) must point to the character after the opening '('. 
 * Note: to test eventually for a bidimensional array, use !isod()
 * System function for the DIM management */
int isod(char *p){
	char *h=p-1;
	while(')'!=*h && '\0'!=*h) if(','==*h++) return FALSE;
	return TRUE;
}


/* isaa(string-position)
 * (IS an Array Assignment)
 * test if the current string **begins** with an array assignment. 
 * p: (which is not touched) must point to the character that begins the array
 * variable (e.g. 'A(' or 'A1('. 
 * System function for the DIM management */
int isaa(char *p) {
	if (varcheck(p,SIMPARR)) return TRUE;
	else if (varcheck(p,DOUBARR)) return TRUE;
	else return FALSE;
}	


/* issaa(string-position)
 * (IS a String Array Assignment)
 * test if the current string **begins** with a string array assignment 
 * p: (which is not touched) must point to the character that begins the array
 * string variable (e.g. 'A$(' or 'A1$('. 
 * System function for the DIM management */
int issaa(char *p) {
	if (varcheck(p,SIMPSTRARR)) return TRUE;
	else if (varcheck(p,DOUBSTRARR)) return TRUE;
	else return FALSE;
}	


/* dimArray(matrix-index,type,rows-number,columns-number)
 * dimension a numerical array allocating the necessary memory space.
 * var: the index of the variable holding the matrix name
 * T: matrix type, 1 for unidimensional vectors, 2 for matrices
 * M: the row number (=0 for one rows matrices)
 * N: the column number (=0 for vectors and one columns matrices)
 * Note: the one-dimensional vector is supposed to be vertical (one column).
 * Note: controls over M&N are supposed to happen elsewhere.
 * Note: all elements of declared array elements are set to 0.0 = zero. 
 * System function for the DIM management */
void dimArray(int var, int T, int M, int N) {
	int i,j;
	int size1=sizeof(double)*((M+1)*2+1);
	int size2=sizeof(double)*((M+1)*(N+1)+1);
	dim[var].brow  = M;
	dim[var].bcol  = N;
	dim[var].row   = M;
	dim[var].col   = N;
	dim[var].type  = T;


	/* reserve memory space for the array */
	if (dim[var].elem!=NIL) free(dim[var].elem);
	if (T==1) dim[var].elem=malloc((size_t)size1);  
	else if (T==2) dim[var].elem=malloc((size_t)size2);
	else perror_(35,l);
	if (!dim[var].elem) perror_(190,l);

	/* erase all array elements */
	if (1==T) for(i=0;i<M+1;i++) setArrayVal(var,T,i,0,0);
	else for(i=0;i<M+1;i++) for(j=0;j<N+1;j++) setArrayVal(var,T,i,j,0);
}		


/* getArrayVal(matrix-index,type,row-position,column-position)
 * get value of an element of a numerical array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * T: matrix type, 1 for unidimensional vectors, 2 for matrices
 * M: the row number (=0 for one rows matrices)
 * N: the column number (=0 for vectors and one columns matrices)
 * Note: a two dimensional array may be referenced using the first subscript;
 * Note: the second subscript defaults to zero (Ref. BAS17F.DOC 3.8) for DIM
 * and to one (Ref. LBMAA-A-D, chapter 7) for MAT statements.
 * System function for the DIM management */
double getArrayVal(int var, int t, int m, int n) {
	/* trivial case of A(0,0) */
	if (!m && !n) {
		if (!dim[var].type) dimArray(var,2,10,10);
		return *(dim[var].elem);
	}
	/* vectors */
	else if (m>0 && !n && t==1) {
		if (m<=10 && 0==dim[var].type) dimArray(var,1,10,0);
		if (m>dim[var].row) perror_(76,l);
		return *(dim[var].elem+(dim[var].col+1)*m);
	}
	/* horizontal vectors */
	else if (!m && n>0 && t==1) {
		if (n<=10 && 0==dim[var].type) dimArray(var,1,0,10);
		if (n>dim[var].col) perror_(76,l);
		return *(dim[var].elem+n);
	}
	/* matrix identified by one column A(I) = A(0,I)  */
	else if (!m && n>0 && t==2) {
		if (n<=10 && 0==dim[var].type) dimArray(var,2,10,10);
		if (n>dim[var].col) perror_(76,l);
		return *(dim[var].elem+n);
	}
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) {
		if (m<=10 && 0==dim[var].row && n<=10 && dim[var].col==0)       
			dimArray(var,2,10,10);
		if (m>dim[var].row || n>dim[var].col) perror_(76,l);
		return *(dim[var].elem+(dim[var].col+1)*m+n); 
	}
	else perror_(76,l);
	return 0;
}


/* setArrayVal(matrix-index,type,row-position,column-position,value)
 * set an element of a numerical array to a specific value, given the value 
 * itself and the element coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices
 * m: the row number (=0 for one rows matrices)
 * n: the column number (=0 for vectors and one columns matrices)
 * val: the double value to be stored.
 * Note: a two dimensional array may be referenced using the first subscript;
 * Note: the second subscript defaults to zero (Ref. BAS17F.DOC 3.8) for DIM
 * and to one (Ref. LBMAA-A-D, chapter 7) for MAT statements.
 * System function for the DIM management */
void setArrayVal(int var, int t, int m, int n, double val){
	/* trivial case of A(0,0) */
	if (!m && !n) {
		if (!dim[var].type) dimArray(var,2,10,10);
		*(dim[var].elem)=val;
	}
	/* vectors */
	else if (m>0 && !n && t==1) {
		if (m<=10 && 0==dim[var].type) dimArray(var,1,10,0);
		if (m>dim[var].row) perror_(76,l);
		*(dim[var].elem+(dim[var].col+1)*m)=val;
	}
	/* horizontal vectors */
	else if (!m && n>0 && t==1) {
		if (n<=10 && 0==dim[var].type) dimArray(var,1,0,10);
		if (n>dim[var].col) perror_(76,l);
		*(dim[var].elem+n)=val;
	}
	/* matrix identified by one column A(I) = A(0,I) */
	else if (!m && n>0 && t==2) {
		if (n<=10 && 0==dim[var].type) dimArray(var,2,10,10);
		if (n>dim[var].col) perror_(76,l);
		*(dim[var].elem+n)=val;
	}
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) {
		if (m<=10 && 0==dim[var].row && n<=10 && dim[var].col==0) 
			dimArray(var,2,10,10);
		if (m>dim[var].row || n>dim[var].col) perror_(76,l);
		*(dim[var].elem+(dim[var].col+1)*m+n)=val;
	}
	else perror_(76,l);
	return;
}


/* dimAssign()
 * wrapper for setArrayVal(), to be called into LET(), for figures like 
 * A(N)=Expr1 or A(N,M)=Expr2. 
 * Note: the use of A0..Z9 is legal, as reported in the LBMAA-A-D 3.1.
 * System function for the DIM management */
void dimAssign(void) {
	int var=0, m=0, n=0,t;
	if (varcheck(p,SIMPARR)) var=*p++;
	else if (varcheck(p,DOUBARR)) var=in(*(p),*(p+1)),p+=2;
	else perror_(42,l);

	if ('('!=*p++) perror_(35,l);
	m=(int)S();
	if (m<0) perror_(76,l);

	/* setup type */
	if (dim[var].type) t=dim[var].type;
	else t=1;

	/* unidimensional array or bidimensional called with first arg. only */
	if (*p==')') {
		p++; // skip ')'
		if (*p++!= '=') perror_(35,l);
		if (isanystring(p)) perror_(45,l);
		setArrayVal(var,t,m,n,S());
	}
	/* bidimensional array */
	else if (*p==',') {
		p++; // skip ','
		if (dim[var].type==1) perror_(76,l);
		n=(int)S(); 
		if (n<0) perror_(76,l);
		if (')'!=*p) perror_(35,l);
		p++; // skip ')'
		if ('='!=*p) perror_(35,l);
		p++; // skip '='
		if (isanystring(p)) perror_(45,l);
		setArrayVal(var,2,m,n,S());
	}
	else perror_(35,l);
}


/* dimStrArray(matrix-index,type,rows-number,columns-number)
 * dimension a string array, allocating the necessary memory space; 
 * var: the index of the variable holding the matrix name
 * T: the matrix type, 1 for unidimensional vectors, 2 for matrices (currently
 *    not available)
 * M: the row number (=0 for one rows matrices)
 * N: the column number (=0 for vectors and one columns matrices)
 * Note: N is not used, since string matrices are not implemented yet. 
 * Note: the one-dimensional vector is supposed to be vertical (one column).
 * Note: controls over M&N are supposed to happen elsewhere 
 * Note: all elements of declared array are set to the void string.
 * System function for the DIM management */
void dimStrArray(int var, int T, int M, int N) {
	int i;
	int size1=sizeof(char)*((M+1)*COMPSTR+1);
	dimS[var].brow = M;
	dimS[var].row  = M;
	dimS[var].bcol = 0;
	dimS[var].col  = 0;
	dimS[var].type = T;
	
	/* check if it's unidimensional */
	if (T!=1) perror_(76,l);

	/* reserve memory space for the array */
	//if (dimS[var].elem!=NIL) free(dimS[var].elem);
	dimS[var].elem=valloc((size_t)size1); 
	if (!dimS[var].elem) perror_(190,l);

	/* erase all array elements */
	for(i=0;i<size1;i++) *(dimS[var].elem+i)='\0';
}		


/* getArrayStr(matrix-index,type,row-position,column-position)
 * get value of an element of a string array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices (currently
 *    not available)
 * m: the row number (=0 for one rows matrices)
 * n: the column number (always 0)
 * Note: I keep the form alive, to implement the bidimensional arrays in some
 * future.
 * System function for the DIM management */
char* getArrayStr(int var, int t, int m, int n) {
	if (n) perror_(76,l);
	else if (!m) return dimS[var].elem;
	else if (1==t) {
		if (m<=10 && 0==dimS[var].row) dimStrArray(var,1,10,0);
		else if (m>10 && 0==dimS[var].row) perror_(76,l);
		else if (m>10 && dimS[var].row<m) perror_(76,l);
		return (dimS[var].elem+m*COMPSTR);
	}
	else perror_(76,l);
	return NULL;
}


/* setArrayStr(matrix-index,type,row-position,column-position,value)
 * set an element of a string array to a specific value, given the value itself 
 * and the element coordinates 
 * Parameter n is not used, since string matrices are not yet implemented;
 * var: the index of the variable holding the matrix name
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices (currently
 *    not available)
 * m: the row number (=0 for one rows matrices)
 * n: the column number (always 0)
 * Note: I keep the form alive, to implement the bidimensional arrays in some
 * future.
 * System function for the DIM management */
void setArrayStr(int var, int t, int m, int n, char* str){
	if (1==t) {
		if (m<=10 && 0==dimS[var].row && 0==dimS[var].col)
			dimStrArray(var,1,10,0);
		else if (m>10 && 0==dimS[var].row) perror_(76,l);
		else if (m>10 && dimS[var].row<m) perror_(76,l);
		else if (dimS[var].row<m) perror_(76,l);
		strncpy_((dimS[var].elem+m*COMPSTR),str,COMPSTR);
	}
	else if (2==t) perror_(76,l);
	return;
}


/* dimStrAssign()
 * wrapper for setArrayStr to be called into LET() for figures like 
 * A$(N)=StrExpr1; usage of A0..Z9 is legal, as reported in the LBMAA-A-D 3.1. 
 * System function for the DIM management */
void dimStrAssign(void) {
	int var=0, m=0;
	if (varcheck(p,SIMPSTRARR)) var=*p, p+=2;
	else if (varcheck(p,DOUBSTRARR)) var=in(*p,*(p+1)), p+=3;
	else perror_(42,l);

	if ('('!=*p++) perror_(35,l);
	m=(int)S();
	if (m<0) perror_(76,l);

	/* unidimensional array */
	if (*p==')') {
		char str[COMPSTR];
		p++; // skip ')'
		if (*p++!= '=') perror_(35,l);
		if (isnm(p)) perror_(45,l);
		strncpy_(str,SS(),COMPSTR);
		setArrayStr(var,1,m,0,str);
	}
	else perror_(35,l);
}


/* setINPUTarray()
 * store value in a numerical array
 * pos: the variable address
 * value: the number to be stored
 * Note: return updated position of pos 
 * System function for the INPUT management */
char* setINPUTarray(char *pos, double value) {
	int M=0, N=0, T=0, var=0;
	char *h=pos;

	/* find closing parenthesis and replace it 
	 * with a space, to stop the parser */
	while (*h && *h!=')') h++; *h=' ';

	/* get var code */
	if (varcheck(pos,SIMPARR)) var=*pos, pos+=2;
	else if (varcheck(pos,DOUBARR)) var=in(*pos,*(pos+1)), pos+=3;
	else perror_(42,l);

	/* read array element coordinates */
	p=pos, M=S(), T=1;

	/* has it more than one dimension? */
	if(*p==',') p++, T=2, N=S();
	
	/* address value to correct array position */
	setArrayVal(var,T,M,N,value);
	return ++p;
}


/* setINPUTnum()
 * store value in a numerical variable
 * pos: the variable address 
 * value: the number to be stored
 * Note: return updated position of pos 
 * Service function for the INPUT management */ 
char* setINPUTnum(char*pos,  double value) {
	int var=0;

	/* get var code */
	if (varcheck(pos,SIMPVAR)) var=*pos++;
	else if (varcheck(pos,DOUBVAR)) var=in(*pos,*(pos+1)), pos+=2;

	/* address value to correct array position */
	P[var]=value;
	return pos;
}


/* isARing()
 * check if GOSUB is calling an address that is in the GOSUB chain; if so,
 * the subroutine is calling itself
 * Note: this behavior is described nowhere in the LBMAA-A-D, but I assume it
 * behaves in a very compliant way, since I have tested some little programs
 * in order to understand the behavior under stress conditions 
 * System function used into GOSUB() */
int isARing(int num) {
	int i=0;
	
	while (i<=gosubTOS) {
		if (gosubStack[i]==num) return TRUE;
		i++;
	}
	return FALSE;
}


/* skipDEF()
 * advance line number to next FNEND, whose presence had already been verified 
 * into preParse(). It's executed inside parse().
 * System function for the DEF FN management */
void skipDEF(void) {
	int ward=*(p+2);
	if (fn[ward].type==MULTI) l=fn[ward].end;
}


/* isSingleDEF()
 * check if the DEF function starting at d is a single line DEF (return SINGLE)
 * a multiline DEF (return MULTI) or a function with bugs (return FALSE) 
 * d: points to the characters after DEF (which must be 'FN')  
 * System function for the DEFFN management 
 * Note: I couldn't find anywhere in the LBMAA-A-D manual the fact that
 * arguments of a DEF FN structure must be unsubscripted variables, but I
 * tested it on the LCM.
 * Ref. LBMAA-A-D 5.1.6, 5-5 */
int isSingleDEF(char* d) {
	/* FN */
	if (!strncmp(d,"FN",2)) d+=2;
	/* XX - error */
	else return FALSE;
	/* FNA */
	if (isalpha(*d)) d++;
	/* FN_ - error */
	else return FALSE;
	/* FNA (multi line introduction) with no arguments */
	if (!*d || *d=='\'') return MULTI;
	/* FNA( */
	else if (*d=='(') d++;
	/* FNA= (no arguments) */
	else if (*d=='=') return SINGLE;
	/* FNA_ - error */
	else return FALSE;
	/* FNA(.... */
	while (*d && *d!=')') d++;
	/* FNA(....) */
	if (*d==')') d++;
	/* FNA(... - error */
	else return FALSE;
	/* FNA(....)= */
	if (*d=='=') return SINGLE;
	/* FNA(....) */
	else return MULTI;
}


/* calcDEF() 
 * calculates the DEF FN result for a single/multi line DEF FNF; 
 * data relative to DEF FN functions must have been preprocessed by preParse(),
 * in order for calcDEF to run.
 * res: the double value will hold the result of the DEF calculation
 * p points to the character after FN, which contains the function index.
 * return the updated position of p
 * System function for the DEFFN management */
char* calcDEF(double* res) {
	int defn=*p, type, i;
	double Pb[LIMIT]; 
	char *pb;
	int isVarBack, isRunBack;
	static int stackLim;
	/* masking flags */
	int Pmask[LIMIT];	// numeric variables


	/* control self calling subroutine
	 * Note: the control is done this way:
	 * 1. store information about current DEF FN only if it differs;
	 *    this enables writing recursion functions; 
	 * 2. the recursion is limited to STACKLIMIT jumps;
	 * 3. search until previous position;
	 *    this avoids calling error in case of recursion, but detects
	 *    circular calls (FNA calling FNB calling FNA) */
	if (!FNXTOS || FNXlist[FNXTOS]!=defn) 
		FNXlist[++FNXTOS]=defn, stackLim=0;
	else stackLim++; 
	if (stackLim>STACKLIM) perror_(187,l);
	for (i=1;i<FNXTOS-1;i++) {
		if (FNXlist[i]==defn) perror_(126,l);
	}

	/* assign to masks all FALSE flags 
	 * Ref. LBMAA-A-D 5.1.6, 5-6, "Any variable which is not an argument of 
	 * FN_ in a DEF loop has its current value in the program..."
	 * This means that only variables in the argument queue are *NOT*
	 * exported, and their original value is restored after loop execution
	 * (tested on the LCM) - here FALSE means export */
	for (i=0;i<LIMIT;i++) Pmask[i]=FALSE;

	/* backup variable state 
	 * REF. LBMAA-A-D 5.16, 5-5, "...each defined function may have zero,
	 * one, two, or more numeric variables; string variables [...] are
	 * not allowed,,,". I add here that neither array numerical variables 
	 * are allowed (tested on the LCM) */
	for (i=0;i<LIMIT;i++) {
		/* numeric variables */
		Pb[i]=P[i];
	}

	/* determine type (SINGLE/MULTI) */
	type=fn[defn].type;
	
	/* if there are arguments, store them */
	p++; // skip letter
	if (*p=='(')  {
		int cnt=0;
		p++; // skip '('
		/* cycle through FNA variable and get values to be used as 
		 * arguments; cnt holds number of arguments of called FNA() 
		 * function, while stored DEFFNA function has fn[defn].vars[0] 
		 * arguments (which must be respected) 
		 * Also, clear export masking for variables in the argument
		 * queue: they will be restored when the process is over */
		while (cnt <= FNALIM) {
			P[fn[defn].vars[++cnt]]=S();
			Pmask[fn[defn].vars[cnt]]=TRUE;
			if (*p==')') break;
			else if (*p==',') p++;
		}
		/* wrong number of arguments */
		if (fn[defn].vars[0]!=cnt) perror_(43,l);
	}

	/* calculate a single line DEF */
	if (type==SINGLE) {
		pb=p; 
		p=fn[defn].def;
		*res=S(); 
		p=pb; 
	}
	/* calculate a multi line DEF */
	else if (type==MULTI) {
		char Bb[SCREENLINE+1];
	
		/* execute lines */
		pb=p;
		isRunBack=isDefRun;
		isDefRun=TRUE;
		isVarBack=isDefVar;
		isDefVar=defn;
		startingLine=fn[defn].start+1;
		pushRUN();
		parse(fn[defn].lines,Bb); // this works for recursion too!
		popRUN();
		isDefVar=isVarBack;
		isDefRun=isRunBack;
		/* there's no error message for cases in which
		 * LET FNF= is not used within a multiline DEF - tested */
		if (!isDefCalc) *res=0.0;
		else *res=fn[defn].res;
		isDefCalc=FALSE;
		p=pb;
	}

	/* restore variable state */
	for (i=0;i<LIMIT;i++) {
		/* numeric variables */
		if (Pmask[i]) P[i]=Pb[i];
	}

	/* update counter for circular calling check */
	FNXTOS--;

	return p;
}


/*****************************************
 *             TIME & STACK              *
 *****************************************/

/* pushRUN() 
 * store current running state
 * used into calcDEF() */
void pushRUN(void) {
	lb[runTOS]=l;
	sb[runTOS]=startingLine;
	pb[runTOS]=channel[0].fprintn;
	cb[runTOS]=channel[0].fcounter;
	ftb[runTOS]=forTOS;
	fcb[runTOS]=forcount;
	nowb=now;
	runTOS++;
}


/* popRUN() 
 * restore current running state
 * used into calcDEF() */
void popRUN(void) {
	runTOS--;
	l=lb[runTOS];
	startingLine=sb[runTOS];
	channel[0].fprintn=pb[runTOS];
	channel[0].fcounter=cb[runTOS];
	forTOS=ftb[runTOS];
	now=nowb;
	forcount=fcb[runTOS];
}


/* getTime()
 * return current time structure */
struct tm *getTime(void) {
	time_t st_lt;
	st_lt=time(NULL);
	return localtime(&st_lt);
}


/* getMin()
 * return current min (0-59) */
int getMin(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_min;
}


/* getSec()
 * return current second (0-59) */
int getSec(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_sec;
}


/* getHour()
 * return current hour (0-23) */
int getHour(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_hour;
}

/* getDay()
 * return current day (1-31) */
int getDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_mday;
}

/* getMonth()
 * return current month (1-12) */
int getMonth(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_mon+1);
}


/* getYear()
 * return current year */
int getYear(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_year+1900);
}


/* getMonthString()
 * return current month string */
char *getMonthString(void) {
	struct tm* vt = getTime();
	return month[(int)vt->tm_mon];
}


/*****************************************
 *          OUTPUT FORMATTING            *
 *****************************************/

/* Note: the FAC()/FCR() functions are strictly connected with the 
 * PAGE/NOPAGE/<PA> features for the simulated terminal because they all 
 * use/set the page size limits */ 


/* FAC()
 * Advance Carriage on a file stream*/
void FAC(int ch) {
	channel[ch].fcounter++;
	if (channel[ch].fcounter > channel[ch].margin) FCR(ch);
	else fputc(' ',channel[ch].stream);
}


/* FCR()
 * Carriage Return onto file stream */
void FCR(int ch) {
	channel[ch].pagerow++;
	if (channel[ch].page && channel[ch].pagerow>channel[ch].page) {
		fillPage(ch);
	}
	else fputc('\n',channel[ch].stream);
	channel[ch].fcounter=0;
}


/* fillPage()
 * pad current page with PA_VOID empty lines in case of PAGE statement set
 * or paging overflowing (this behaviour, though not described in the LBMAA-A-D
 * was nonetheless tested on the LCM */
void fillPage(int ch) {
	int i;
	/* close incomplete lines */
	if (channel[ch].fcounter) channel[ch].pagerow=-1, FCR(ch);
	/* print PA_VOID void lines */
	for (i=0;i<PA_VOID;i++) {
		if (isDebug) fputc('.',channel[ch].stream);
		fputc('\n',channel[ch].stream);
	}
	channel[ch].pagerow=1;
}


/* emitNUM()
 * output number (with sign) contained into formatted string num to stream ch
 * or to string dest; update file counter ; 
 * a space follows always the number to stdout/file;
 * if flag is TRUE, redirect printing to dest, otherwise to ch 
 * Note: dest width must be COMPSTR = MAXSTRLEN + 1 */
int emitNUM(int ch, char minus, char *num, int flag, char* dest) {
	int ret=strlen(num);

	/* reset screen/file position if number length exceeds width */
	if (ret+2+channel[ch].fcounter>channel[ch].margin) FCR(ch);

	/* print into a string */
	if (flag) sprintw(dest,COMPSTR,"%c%s ",minus,num);
	/* print to screen/file */
	else fprintf(channel[ch].stream,"%c%s ", minus, num);

	/* return correct value counter/file counter */
	return channel[ch].fcounter+2+ret;
}


/* printNUM()
 * format number num to a printing output according to DEC BASIC rules 
 * (Ref. LBMAA-A-D 6-4) onto stream identified by ch
 * return updated position of counter (as yielded by emitNum) 
 * if flag is true, the number (in emitNUM) will be printed on string dest 
 * rather than on stdout 
 * Note: dest width must be COMPSTR = MAXSTRLEN + 1 
 * Note: this function does not print anything, delegating emitNUM() */
int printNUM(int ch, double num, int flag, char* dest) {
	int isFloat=TRUE, exp=0;
	char minus=' ', nums[COMPSCR], *nump;
	double base=0.0;

	/* if number is null, shorten the process! */
	if (num==0) return emitNUM(ch,' ',"0",flag,dest);
	
	/* operate only with positive numbers, storing the sign aside */
	if (num<0) num=-num , minus='-';

	/* catch UNDERFLOW for a number less than ZERO */
	if (num<ZERO) {
		perror_(130,l);
		return emitNUM(ch,minus,"0",flag,dest); 
	}

	/* catch OVERFLOW for a number > INFF in absolute value */
	else if (num > INFF) num=INFF;

	/* temporarily, use exponential or normal form 
	 * in representing the number in a raw form */
	if (num < 1E-10 || num > 1E10) sprintw(nums,COMPSCR,"%.5E", num);
	else sprintw(nums,COMPSCR,"%21.10F", num);

	/* rule 4: suppress final zeroes */
	nump=nums+strlen(nums)-1;
	while('0'==*nump) *nump--='\0';

	/* rule 1 part 1: if there's a final dot in an integer, suppress it */
	if('.'==*nump) {
		*nump--='\0';
		isFloat=FALSE;
	}

	/* suppress any possible trailing nulls */
	nump=nums;
	while(*nump == '0' || *nump == ' ') nump++;

	/* print real number */
	if(isFloat){
		/* exception to rule 3: print real number as-is if it fits */
		if (num <= 1 && strlen(nump) < 8) {
			sprintw(nums,COMPSCR,"0%s",nump);
			return emitNUM(ch,minus,nums,flag,dest);
		}
		else if (strlen(nump) < 8) {
			sprintw(nums,COMPSCR,"%s",nump);
			return emitNUM(ch,minus,nums,flag,dest);
		}

		/* rule 3: print real with exponent */
		else if (num < 0.1) {
			sprintw(nums,COMPSCR,"%.5E",num);
			doExp(nums,&base,&exp);
			if (exp<0) sprintw(nums,COMPSCR,"%.5fE%d",base,exp);
			else sprintw(nums,COMPSCR,"%.5fE+%d",base,exp);
			return emitNUM(ch,minus,nums,flag,dest);
		}
		/* rule 2: print real with 6 significant digits 
		 * retaining decimal dot (use of #)*/ 
		else {
			sprintw(nums,COMPSCR,"%#.6G",num);
			nump=strstr(nums,"E");
			/* depict number in exponential form */
			if (nump) {
				doExp(nums,&base,&exp);
				if (exp<0) 
				     sprintw(nums,COMPSCR,"%.5fE%d",base,exp);
				else sprintw(nums,COMPSCR,"%.5fE+%d",base,exp);
			}
			/* rule 4 reapplied: suppress trailing zeroes at 
			 * the end if not and exponential */
			if (!strstr(nums,"E")) {
				nump=nums+strlen(nums)-1;
				while (*nump=='0') *nump--='\0';
			}
			return emitNUM(ch,minus,nums,flag,dest);
		}
	}
	/* print integer number */
	else {
		/* rule 1 part 2: print integer till 9 significant digits */
		if (strlen(nump) < 9) return emitNUM(ch,minus,nump,flag,dest);

		/* rule 1 part 2 (reverse case): print integer with exponent
		 * and 6 significant digits (that is, 5 decimals) */
		else { 
			sprintw(nums,COMPSCR,"%.5E",num);
			nump=strstr(nums,"E");
			if (nump) {
				doExp(nums,&base,&exp);
				if (exp <0) 
				     sprintw(nums,COMPSCR,"%.5fE%d",base,exp);
				else sprintw(nums,COMPSCR,"%.5fE+%d",base,exp);
			}
			return emitNUM(ch,minus,nums,flag,dest);
		}
	}

	/* avoiding warnings.... */
	return 0;
}


/* getString()
 * get a formatted string from user keyboard
 * the ENTER key stop any input 
 * Note: the input is not capitalized, unless option -c is used */
char* getString(void) {
	char *lp=line;
	int i;

	for (i=0; i<SCREENLINE; i++) line[i]='\0';
	while (TRUE) {
		if (isCap) 
			*lp=toupper(getchar());
		else 
			*lp=getchar();
		if (*lp==10 || *lp==13) {
			*lp='\0';
			break;
		}
		else lp++;
	}
	return lp=line;
}


/* assign()
 * The assign subroutine for numbers - called by LET()
 * assign a number to a number-variable
 * variable name is taken from input string
 * if a string variable is found, delegate strAssign(), passing it the
 * address of variable and of assignment
 * return TRUE if assignment went OK, false otherwise 
 * System function */
int assign(void) {
	char *e=p;
	/* assign FN value */
	if (!strncmp(e,"FN",2)) {
		if (isDefRun) {
			int ward;
			e+=2, ward=*e++;
			if (!isalpha(ward)) return FALSE;
			if (ward!=isDefVar) return FALSE;
			if (*e=='=') e++; else return FALSE;
			if (isanystring(e)) perror_(45,l); 
			p=e; fn[ward].res=S(); 
			return isDefCalc=TRUE;
		}
		else {
			int ward;
			e+=2, ward=*e++;
			perror_(60,l,ward);
		}
	}
	/* Numerical arrays */
	if (varcheck((e),SIMPARR) || varcheck((e),DOUBARR)) dimAssign();
	/* String arrays */
	else if (varcheck(e,DOUBSTRARR)) dimStrAssign();
	else if (varcheck(e,SIMPSTRARR)) dimStrAssign();
	/* Numerical variables */
	else if (varcheck(e,SIMPVAR)) {
		p+=2;
		if (isanystring(p)) perror_(45,l);
		P[(int)*e]=S();
	}
	else if (varcheck(e,DOUBVAR)) {
		p+=3;
		if (isanystring(p)) perror_(45,l);
		P[in(*e,*(e+1))]=S();
	}
	/* String variables */
	else if (varcheck(e,SIMPSTR)) p+=3, strAssign(e);
	else if (varcheck(e,DOUBSTR)) p+=4, strAssign(e);
	else return FALSE;

	/* check syntax for what is next, */
	if (*p && *p!='\'') perror_(65,l,makechar(p),TERMINAT); // tested
	return TRUE;
}


/* strAssign()
 * the assign subroutine for strings - called by LET
 * assign a string to a string-variable
 * e contains the address of variable to be filled
 * f contains the address of assignment 
 * System function */
void strAssign(char* e) {
	int index=0;

	/* check correct assignment value */
	if (isnm(p)) perror_(45,l);
	else if (!isanystring(p)) perror_(65,l,makechar(p),TERMINAT);

	/* fill PAD with assignment value */
	strncpy_(pad,SS(),COMPSTR); 
	/* allocate string variable space */
	if (varcheck(e,SIMPSTR)) index=(int)*e;
	else if (varcheck(e,DOUBSTR)) index=in(*e,*(e+1));
	if (PS[index]!=NIL) free(PS[index]);
	PS[index]=malloc(COMPSTR);
	if (!PS[index]) perror_(191,l);
	/* check syntax after assignment value */
	if (*p && *p!=',' && *p!=';' && *p!=')') 
		perror_(65,l,makechar(p),TERMINAT); // tested
	/* do the assignment */
	strncpy_(PS[index],pad,COMPSTR);
}


/*****************************************
 *             MATH & STRINGS            *
 *****************************************/

/* isStrFunc()
 * check if q points to a string function */
int isStrFunc(char* q) {
	if (!strncmp(q,"CHR$(",5) 
			|| !strncmp(q,"SPACE$(",7) 
			|| !strncmp(q,"STR$(",5)   
			|| !strncmp(q,"LEFT$(",6)  
			|| !strncmp(q,"MID$(",5)
			|| !strncmp(q,"RIGHT$(",7)) 
		return TRUE;
	return FALSE;
}


/* check(string1,string2)
 * check if sb syntax is correct against sc; if it is, put a space in the 
 * position found, so that a subsequent parsing by S() may stop without 
 * issuing an error message from getFunc() and return true; 
 * if syntax it's not correct, return false.
 * This is done in statements with some core-words, like IF <Test> THEN
 * where the parsing of <Test> must stop just before THEN; check() inserts so 
 * a space in place of the T of THEN, causing the parser to stop there */
int check(char *sb, char *sc){
	char *qq=strstroq(sb,sc);
	/* put a space to stop S() parsing */
	if (qq) { *qq=' '; return TRUE; }
	return FALSE;
}


/* doExp(str, &base, &exp) 
 * find base and exponent of a number which must be printed in exponential 
 * form given the pointer to the string str containing the number in raw form.
 * See the BCLM manual, for some output of numbers in exponential form 
 * Used into printNUM() */
void doExp(char *pos, double *base, int *exp) {
	char *e = strstr(pos, "E");
	if (!e) return;
	*e=' ';
	*base=strtod(pos,NULL);
	*exp=strtol(e,NULL,10);
}


/* power(base,exponent)
 * powering function */
double power(double base, double expon) {
	/* if base is negative, take some cautions... */
	if (base<0) {
		/* integer exponent is always evaluable */
		if (expon==(double)((int)expon)) {
			if ((int)expon%2) 
				// odd exponent
				return -pow(-base,expon);
				// even exponent (regular case)
				else return pow(base,expon);
		}
		/* real exponent is not evaluable if base is < 0,
		 * so take absolute value */
		else {
			perror_(66,l);
			/* the absolute value was in the original BASIC */
			return pow(-base,expon);
		}
	}
	/* if base is null and exponent is negative,
	 * INFF is a safe result for 0^(<0) */
	else if (expon<0 && base==0) {
		perror_(132,l);
		return INFF;
	}
	/* if base and exponent are both null set 1 as result;
	 * 1 is the limit of function x^x if x approaches zero from right 
	 * Note: also LCM DEC returns 1, as expected */
	else if (expon==0 && base==0) return 1.0; // tested
	/* default case for positive base and any exponent (regular case) */
	else return pow(base,expon);
}


/* stripBlanks()
 * strip blanks from src and copy stripped string to dest
 * stop stripping while into a string */
void stripBlanks(char *src, char *dest) {
	int j=1; // strip flag/counter
	while (*src) {
		if (*src=='\"') j++;
		if (j&1) { 
			/* ASC() must be caught in order to preserve the
			 * first possible single space into the parenthesis */
			if (!strncmp(src,"ASC(",4)) {
				*dest++=*src++;
				*dest++=*src++;
				*dest++=*src++;
				*dest++=*src++;
				*dest++=*src;
			}
			else if (*src!=' ' && *src!='\t') 
				*dest++=*src; 
		}
		else *dest++=*src;
		src++;
	}
	*dest='\0';
}


/* in(letter-index,number-index)
 * return index for vars A0..Z9 using a math algorithm, to ensure their 
 * memory space is not the same of variables A..Z; this avoids overwriting */
int in(char c, char d) {
	return (200+((int)c-'A')*10+(int)d);
}


/* makechar()
 * returns first character of string str as a string */
char* makechar(char* str) {
	static char onechar[2];

	onechar[0]=*str;
	onechar[1]='\0';
	return onechar;
}


/* spaces() 
 * return a pointer to a string of v spaces up to LIMIT+1 characters */
char *spaces(int v) {
	static char spacePad[LIMIT+1];
	char *sp;
	int n;

	/* set limits */
	sp=spacePad;
	if (v<0) n=0;
	else if (v>LIMIT) n=LIMIT;
	else n=v;
	
	/* build spaces string */
	while (n-->0) *sp++=32;
	*sp='\0';
	return spacePad;
}


/* turnToUpper()
 * turn a string to upper in all sections outside a literal string; this means 
 * that with option -c lower and upper characters may be used for statements 
 * into the source; decb will in any case turn them to upper case statements */
void turnToUpper(char *str) {
	while (*str) {
		*str=toupper(*str);
		str++;
	}
}

/* Note: the following strncpy_() and strncat_() are my own personal versions 
 * for strcpy/strncpy and strcay/strncat.
 * I must use mine because cpy/cat functions in C have erratic behaviors within 
 * different operating systems:
 * - In Linux (tested on Suse) strncpy is error prone, and strcpy is preferred
 * - in OpenBSD strncpy is preferred and strcpy should not be used
 * - in Mac OS X 10.4 (the one I use) strcpy and strncpy both work
 * The same is (arguably) for strcat/strncat.
 * Since many reported strange things happening because of strcpy/strncpy
 * (from error in compilation to completely wrong string functions output), I 
 * made up my mind and built these substitutes for both. */


/* strncpy_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is good.)
 * The copy will take care of never going past the limit of dst, and to fill 
 * the rest of the space (if any) with nulls; 
 * System function replacing strcpy/strncpy */
char *strncpy_(char *dst, const char *src, int dw) {
	char *dp=dst;
	/* copy src onto dst but not past the end of dst */
	while (*src && (int)(dp-dst)<dw-1) *dp++=*src++;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<dw) *dp++='\0';
	/* Note: return the same value returned by strcpy/strncpy */
	return dst;
}


/* strncat_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is good.)
 * The copy will take care of never going past the limit of dst, and to fill 
 * the rest of the space (if any) with nulls; if dst is found not initialized 
 * (that is nowhere the terminator is found) it is initialized as void.
 * System function replacing strcat/strncat */
char *strncat_(char *dst, const char *src, int dw) {
	char *dp=dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* copy src onto dst but not past the end of dst */
	while (*src && (int)(dp-dst)<dw-1) *dp++=*src++;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<dw) *dp++='\0';
	/* Note: return the same value returned by strcat/strncat */
	return dst;
}

/* Note: the following sprintfw() is my own personal version wrapper for
 * snprintf(), which appear to behave erratically on my system (is does not
 * work with function return values, but works with real arrays) and probably
 * the same (with inverse properties) on other systems.
 * This wrapper assures that only physical arrays are treated by snprintf() */

/* sprintw() 
 * the snprintf wrapper 
 * dest is the destination string,
 * len is the string width (including the terminator character)
 * format is the formatting string (with the same printf rules)
 * ... is the printing string argument (may be a function return value) 
 * return the number of characters written in the host string 
 * System function replacing sprintf/snprintf */
int sprintw(char *dest, int len, char* format, ...) {
	va_list ap;
	char base[LIMIT+1];
	va_start(ap,format);
	vsnprintf(base,LIMIT,format,ap);
	snprintf(dest,len,"%s",base);
	va_end(ap);
	return strlen(base);
}


/* Note: the following strstroq() is my own personal version wrapper for
 * strstr(), to have it working only outside of quotes. */ 

/* strstroq()
 * locate string pr into string pl
 * this function has the same usage of C strstr(), but it works only if outside 
 * of a string, in BASIC normally surrounded by double quotes 
 * (strstroq = strstr Out of Quotes) 
 * System function replacing strstr */
char* strstroq(char *pl, char* pr) {
	int valid=1, l=strlen(pr);

	if (!l) return pl;
	while (*pl) {
		if (*pl=='\"') valid++;
		if (!strncmp(pl,pr,l) && (valid&1)) return pl;
		pl++;
	}
	return NULL;
}


/* storeSingleLineToCore()
 * saves into core memory the line in argument, which must be constituted
 * by a line number less than 100000 and a BASIC statement;
 * return TRUE on successful storing;
 * a void line is transparent for this command
 * System function */ 
int storeSingleLineToCore(char* line) {
	char* lp=line;
	char linenum[10];
	int row=0;

	/* check NULL (maybe unnecessary, but anyway...) */
	if (!*line) return TRUE;
	/* check line number existence */	
	if (!isdigit(*lp)) perror_(13,-1,mback);
	/* get line number */
	else {
		/* get and check line number */
		while (row<5 && isdigit(*lp)) linenum[row++]=*lp++;
		linenum[row]='\0';
		row = strtol(linenum, NULL, 10);
		/* check underflow */
		if (row<0) perror_(13,-1,0); // tested
		/* check overflow */
		if (row >= CORELIM) perror_(5,-1);

		/* if line was already been instantiated, is a double
		 * number-referenced line - free and warn */
		if (m[row]!=NIL) {
			perror_(205,row);
			free(m[row]);
		}

		/* if line is void (i.e. with line number but with no
		 * statement), fill it with some spaces; this is done
		 * because some programmers like to GO TO lines declared
		 * but void; a whim that I have got to circumvent! */
		if (!*lp) {
			m[row]=malloc(5+1);
			if (!m[row]) perror_(194,-1,row);
			strncpy_(m[row],"     ",5+1); // five spaces
		}
		/* store line; if lp is void line with only spaces and/or tabs,
		 * it's stored anyway, but it won't be executed (see up) 
		 * Note: Thanks to Arnaud Delfosse for pointing out an 
		 * irregular line in the following section that interfered 
		 * with Linux gcc, causing a memory corruption error due to 
		 * malloc(). The incriminated previous line was:
		 * strncpy(m[row],lp,SCREENLINE); */
		else {
			int lk=strlen(lp)+1;
			m[row]=malloc(lk);
			if (!m[row]) perror_(194,-1,row);
			if (isCap) turnToUpper(lp);
			strncpy_(m[row],lp,lk);
		}
		mback=row;
		if (lastLine<row) lastLine=row;
	}
	
	/* normal behavior */
	return TRUE;
}


/* varCode()
 * check which kind of variable is being parsed, returning parser var codes
 * w is a char pointer to a variable structure 
 * see also its wrapper varcheck() defined as macro
 * Ref. LBMAA-A-D 1.3.4, 1-6, "Variables"
 * System function */
int varCode(char* w) {
	if (isalpha(*w)) {
		if (*(w+1)=='(') return SIMPARR;
		else if (isdigit(*(w+1))) {
			if (*(w+2)=='(') return DOUBARR;
			else if (*(w+2)=='$') {
				if (*(w+3)=='(') return DOUBSTRARR;
				else return DOUBSTR;
			}
			else return DOUBVAR;
		}
		else if (*(w+1)=='$') {
			if (*(w+2)=='(') return SIMPSTRARR;
			else return SIMPSTR;
		}
		else if (isalpha(*(w+1))) return FUNCTION;
		else return SIMPVAR;
	}
	else return INVALID;
}


/******************************************
 *                 PARSING                *
 ******************************************/

/* tokenize()
 * substitute operators names with tokens or default statement names,
 * according to the following list:
 * '�' for <> 
 * '�' for <= 
 * '!' for >= 
 * '^' for **
 * BY for STEP
 * GOTO for THEN
 * DIM for DIMENSION
 * LN( for LOG( and LOGE(
 * CLOG( for LOG10(
 * SQR( for SQRT(
 * ;??; for <PA>
 * The substitution has the advantage to consider operators as a one-char
 * element to select, and statement/function substitution has the advantage
 * that one command/function only has to be selected for execution, being
 * certain the programmer's will is respected 
 * Note: using option -d (debug), the current executing line is printed, after
 * tokenizing and blank-stripping, to see the 'real' string under evaluation
 * System function */
void tokenize(char* q) {
	if (*q=='<' && *(q+1)=='>') *q++='�',*q=' ';
	else if (*q=='<'&& *(q+1)=='=') *q++='�',*q=' ';
	else if (*q=='>'&& *(q+1)=='=') *q++='!',*q=' ';
	else if (*q=='*'&& *(q+1)=='*') *q++='^',*q=' ';
	else if (!strncmp(q,"STEP",4)) *q++='B',*q++='Y',*q++=' ',*q=' ';
	else if (!strncmp(q,"THEN",4)) *q++='G',*q++='O',*q++='T',*q='O';
	else if (!strncmp(q,"SQRT(",5)) q+=3,*q++=' ';
	else if (!strncmp(q,"LOG(",4)&&*(q-1)!='C')  q++, *q++='N',*q=' ';
	else if (!strncmp(q,"LOGE(",5)) q++, *q++='N',*q++=' ',*q=' ';
	else if (!strncmp(q,"LOG10(",6)) 
		*q++='C',*q++='L',*q++='O',*q++='G',*q=' ';
	else if (!strncmp(q,"DIMENSION",9)) {
		q+=3;
		*q++=' ',*q++=' ',*q++=' ',*q++=' ',*q++=' ',*q=' ';
	}
	else if (!strncmp(q,"<PA>",4)) {
		*q++=';',*q++='\?',*q++='\?',*q++=';';
	}
}


/* preParse()
 * A fundamental subroutine to be run BEFORE each process.
 * Scan source in core memory and executes DATA and DEF recordings, sets DIM
 * (DIMENSION) arrays spaces, opens FILES files, detects END, and in general
 * activates all commands that must be preprocessed before program execution.
 * Check also FOR-NEXT crossed references while GOTO, GOSUB and THEN addresses 
 * are checked into their relative functions.
 * Note for subsequent add-ons: This command is executed BEFORE stripblanks()
 * into parse(), so assure to do stripblanks() before processing the line,
 * or use isblank() to skip all blanks!!! 
 * m: the array of the string pointers containing the program lines to be
 * executed.
 * System basic function */
void preParse(char **m) {
	/* the following 'endl' works as a flag for the END statement, 
	 * holding the line number in which it appears,
	 * while 'endn' holds the number of END statements found */
	int l=-1, endl=0, endn=0;
	char* q;
	dc=dataLimit=0;

	/* preset DEFFN values */
	isDefRun=FALSE;
	isDefCalc=FALSE;
	isDefVar=0;
	isDefFor=FALSE;

	/* scan source */
	while(l<=lastLine) {
		l++;
		if (l>lastLine) break;
		if (!m[l]) continue;
		q=m[l];
		while (isblank(*q)) q++;
		/* image lines (for USING) are not checked */
		if (!strncmp(q,":",1)) continue;
		/* tick comment at start of line are not checked */
		else if (*q=='\'') continue;
		/* REM statements are not checked */
		else if (!strncmp(q,"REM",3)) continue;
		/* PRINT and WRITE may contains strings which shouldn't be 
		 * checked, and in any case, PRINT() and WRITE() and their
		 * coworkers can themselves detect all errors;
		 * so avoid checking here */
		else if (!strncmp(q,"PRINT",5)) continue;
		else if (!strncmp(q,"WRITE",5)) continue;

		/* DATA Statement - saving elements 
		 * Note: this is the actual execution of the DATA instruction, 
		 * which in runtime is effectively a no-op
		 * Ref. LBMAA-A-D 1.4.2, 1-7, "READ and DATA Statements"
		 * "... Before the program is run, the computer takes all of
		 * the DATA statements in order they appear and creates a large
		 * data clock..." */
		if (!strncmp(q,"DATA",4)) {
			double val;
			/* check line length */
			if (strlen(q)>SCREENLINE-7) perror_(75,l);
			q+=4;
			while (*q) {
				while (isblank(*q)) q++;
				/* store naked strings (comma separated) */
				if (isalpha(*q)) {
					char op[MAXSTRLEN+1], *P1=op;
					int lk;
					/* check if space is over */
					if(dcs>=DATLIM-1) perror_(22,l);
					while (*q&&*q!=','&&*q!=' '&&\
							*q!='\t'&&*q!='\n') 
						*P1++=*q++;
					*P1='\0';
					++dcs;
					lk=strlen(op)+1;
					if (DS[dcs]!=NIL) free(DS[dcs]);
					DS[dcs]=malloc(lk);
					if (!DS[dcs]) perror_(193,l);
					*DS[dcs]='\0';
					strncpy_(DS[dcs],op,lk);
					if (isCap) turnToUpper(DS[dcs]);
				}
				/* store quoted strings */
				else if (*q=='\"') {
					char op[MAXSTRLEN+1], *P1=op;
					int lk;
					/* check if space is over */
					if(dcs>=DATLIM-1) perror_(22,l);
					q++;
					while (*q && *q!='\"') *P1++=*q++;
					*P1='\0';
					++dcs;
					lk=strlen(op)+1;
					if (DS[dcs]!=NIL) free(DS[dcs]);
					DS[dcs]=malloc(lk);
					if (!DS[dcs]) perror_(193,l);
					*DS[dcs]='\0';
					strncpy_(DS[dcs],op,lk);
					if (*q=='\"') q++;
					if (isCap) turnToUpper(DS[dcs]);
				}
				/* store numbers; Note: in DATA statements 
				 * only numbers are accepted, not formulas 
				 * Ref. LBMAA-A-D, 1.4.2, 1-8, bottom
				 * "..Remember that numbers, not formulas, are
				 * put in a DATA statement, and that 15/7 and
				 * SQR(3) are formulas..." */
				else if (*q) {
					/* check if space is over */
					if(dc>=DATLIM-1) perror_(22,l);
					while (isblank(*q)) q++;
					p=q;
					val=strtod(p,&p);
					if (val<MINFF || val>INFF)
						perror_(23,l);
				        D[++dc]=val;
					q=p;
				}
				while (isblank(*q)) q++;
				/* discard apostrophe comment */
				if (*q=='\'') while (*q) q++;
				/* check if datum is followed by
				 * something else than a comma */
				if (*q && *q==',') q++;
				else if (*q) perror_(23,l);
			}
			continue;
		}
		/* DEF statements are preprocessed into DEF 
		 * Note: in the LBMAA-A-D I couldn't find any reference to the 
		 * preprocessing of DEF statements, but it must be so... */
		else if (!strncmp(q,"DEF",3)) {
			char *x=J;
			p=q+3;
			stripBlanks(p,x); p=J;
			DEF(l); 
			continue;
		}
		/* END statements - store info
		 * Ref. LBMAA-A-D, 1.4.7, 1-10 */	
		else if (!strncmp(q,"END",3)) {
			endn++;
			/* is it unique?*/
			if (endn>1) perror_(24,endl);
			endl=l;
			l=lastLine; // interrupt preParse()
		}
		/* DIM/DIMENSION statements 
		 * instantiate arrays before the execution of the program.
		 * Ref. LBMAA-A-D 3.1, 3-2, "...A DIM (or DIMENSION) statement
		 * is not executed, therefore, it may appear on any line before
		 * the END statement..." */
		else if (!strncmp(q,"DIMENSION",9)) {
			char *x=J;
			p=q+9;
			stripBlanks(p,x); p=J;
			DIM(l);
			continue;
		}
		else if (!strncmp(q,"DIM",3)) {
			char *x=J;
			p=q+3;
			stripBlanks(p,x); p=J;
			DIM(l);
			continue;
		}
		/* FILES statements - delegate FFILE() 
		 * Ref. LBMAA-A-D 10.2, 10-2, "...Before execution of the 
		 * program begins, BASIC collects all of the FILES statements 
		 * in the program, makes the channel assignments, and sets the 
		 * file access types as they were declared in the FILES 
		 * statements. The FILES statements are not used again during 
		 * that execution of the program..." */	
		else if (!strncmp(q,"FILES",5)) {
			char *x=J;
			p=q+5;
			stripBlanks(p,x); p=J;
			FFILE(TRUE,l);
			continue;
		}
		/* FOR must correspond to a NEXT for the same variable
		 * (delegate error-catching to the FOR/NEXT functions) 
		 * Ref. LBMAA-A-D 2.1, 2-3, "...[NEXT] contains one variable 
		 * that must be the same as that following FOR in the FOR
		 * statement..." */
		else if (!strncmp(q,"FOR",3)) {
			int forvar, nextvar, bl=l, go=TRUE;
			char*qq;
			forvar=nextvar=0;
			q+=3; while (isblank(*q)) q++;
			if (varcheck(q,SIMPVAR)) forvar=*q;
			else if (varcheck(q,DOUBVAR)) forvar=in(*q,*(q+1));
			else continue; 
			/* search from current line to the end 
			 * Note: as tested on the LCM, the search for
			 * NEXT is only onward, since all isolated NEXT are
			 * caught and signaled by error 47 */
			while (++bl<=lastLine && go) {
				if (!m[bl]) continue;
				qq=m[bl]; while (isblank(*qq)) qq++;
				if (!strncmp(qq,"NEXT",4)) {
					qq+=4;
					while (*qq) {
						while (isblank(*qq)) qq++;
						if (varcheck(qq,SIMPVAR)) 
							nextvar=*qq++;
						else if (varcheck(qq,DOUBVAR)) 
							nextvar=in(*qq,*(qq+1)),
							       qq+=2;
						else break;
						if (nextvar==forvar) {
							forAddr[l]=bl;
							go=FALSE;
							break;
						}
						while (isblank(*qq)) qq++;
						if (*qq==',') qq++;
					}
				}
			}
			/* Note: 
			 * This error was in FOR(),but has much more sense
			 * here, avoiding all runnings if there's an unresolved
			 * FOR statement without its relative NEXT companion */
			if (!nextvar) perror_(29,l);
			continue;
		}
	}

	/* set up starting parameters for READ */
	dataLimit=dc,   dc=1;
	dataLimitS=dcs, dcs=1;

	/* check if END exists 
	 * Ref. LBMAA-A-D, 1.4.7, 1-10, "...Every program must have an END
	 * statement..." (and one only, I add) */
	if (!endn) perror_(51,-1); // missing END
	/* check if END is last
	 * Ref. LBMAA-A-D, 1.4.7, 1-10, "... END [...] must be the
	 * statement with the highest line number in the program."*/
	if (endl!=lastLine) perror_(24,endl); // END not last
	lastLine=endl; // this is the exact end of program
}


/* parse()
 * The parser 
 * It's a general purpose routine that executes lines contained into the m 
 * line-memory buffer, using B as a temporary buffer used for cleaning and 
 * tokenizing scopes 
 * System basic function */
void parse(char **m, char *B) {

	/* set starting parameters */
	l=startingLine;

	/* execute line by line */
	while(l<=lastLine){
		/* 'sub' means 'shall I substitute?' */
		int qq, sub=TRUE;
		char current[SCREENLINE+1], *cp=current;

		/* empty buffer */
		for (qq=0;qq<=SCREENLINE;qq++) B[qq]='\0';
		
		/* skip nonexistent lines in memory */
		while (!m[l]) l++;
		strncpy_((s=current),m[l],COMPSCR);
		if (!m[l]) continue;

		/* skip formatting lines */
		while (isblank(*cp)) cp++;
		if (*cp==':') {
			l++;
			continue;
		}

		/* erase inline comment specified by the tick 
		 * but not for image files 
		 * Ref. LBMAA-A-D 6.4, 6-5, "Remarks Statement (REM)" */
		if (*cp!=':') {
			if ((cp=strstroq(current,"\'")) &&\
					*(cp-1)!='(' && *(cp+1)!=')') 
				*cp='\0';
		}

		/* tokenize if out of strings */	
		p=s; d=0;
		while (*p){
			if (*p=='\"') sub = (sub ? FALSE : TRUE);
			if (sub) tokenize(p);
			p++;	
		}

		/* strip blanks if out of string (checked into stripBlanks)
		 * buffer B will hold purged execution line */
		while (isblank(*s)) s++;
		d=B; stripBlanks(s,d);

		/* put to upper letters */
		if (isCap) turnToUpper(B);

		/* DEBUGGING PURPOSES - print tokenized/stripped line */
		if (isDebug) {
			if (B[0]) fprintf(stderr, "\n[%d %s] ",l,d);
		}
		/* EXECUTION PURPOSES - print rem comments */
		if (isRemPrint) {
			char *hh=s;
			if (!strncmp(s,"REM",3)) {
				hh+=3;
				while (isblank(*hh)) hh++;
				fprintf(stderr, "** %s\n",hh);
			}
		}

		/* FNEND must be caught in order to stop the inner 
		 * parsing of multiline DEF, or the system would continue over 
		 * void lines (fn[ward].lines being already consumed); 
		 * removing this command would cause a bus error */
		if (isDefRun && !strncmp(B,"FNEND",5)) return;
	
		/* maybe it's a statement:  process it through exec(), which 
		 * returns FALSE in case of unrecognized statement */ 
		if(exec(B));
		/* if it's not a statement, maybe it's an implicit assignment: 
		 * call LET() to interpret the assignment 
		 * Ref. LBMAA-A-D 1-2, 1-7, A-1 */
		else if ((p=B) && LET());
		/* if it's neither a statement nor an implicit assignment,
		 * it's an illegal instruction */
		else perror_(44,l);
		/* process next line */
		l++;
	}
}


/* exec()
 * the statement execution subroutine (the core of the engine, which calls
 * all the statements references to execute the commands)
 * lpc is the address of the execution line (the first character after the
 * line number).
 * return TRUE if execution succeeds, FALSE otherwise
 * Note: all statements already executed in preParse, are simple no-op, here, 
 * as well as statements REM and ' (tick) are.
 * System basic function */
int exec(char* lpc) {
	if (*lpc=='\0'); // no-op for void lines (and tick comments)
	/* Ref. LBMAA-A-D 8-3, A-2 */
	else if (!strncmp(lpc,"CHANGE",6)) p=lpc+6, CHANGE(); 
	/* Ref. LBMAA-A-D 6-6, A-2 */
	else if (!strncmp(lpc,"CHAIN",5)) { p=lpc+5; CHAIN(); return TRUE; }
	/* Ref. LBMAA-A-D 1-2, 1-7, 1-8, 8-2, A-1 */
	else if (!strncmp(lpc,"DATA",4)); //no-op
	/* Ref. LBMAA-A-D 5-5, A-6 */
	else if (!strncmp(lpc,"DEF",3)) {
		/* Multiple line DEFs cannot be nested
		 * Ref. LBMAA-A-D 5.1.6, 5-6, "... Multiple line DEFs may not 
		 * be nested and there must not be a transfer from inside the 
		 * DEF to outside its range..." */
		if (isDefRun) perror_(46,l);
		else p=lpc+3,skipDEF();
	}
	/* Ref. LBMAA-A-D 3-1, 3-2, 7-1, A-1 */
	else if (!strncmp(lpc,"DIM",3)); //no-op
	/* Ref. LBMAA-A-D 1-2, 1-10, A-1 */
	else if (!strncmp(lpc,"END",3)) END(EXIT_SUCCESS);
	/* Ref. LBMAA-A-D 10-2, 10-3, A-3 */
	else if (!strncmp(lpc,"FILES",5)); //no-op
	/* Ref. LBMAA-A-D 10-2, 10-3, A-3 */
	else if (!strncmp(lpc,"FILE",4)) p=lpc+4,FFILE(FALSE,l); 
	/* Ref. LBMAA-A-D 5-5 */
	else if (!strncmp(lpc,"FNEND",5)) {
		if (isDefRun && isDefFor) perror_(28,l);
		/* FNEND must be present
		 * Ref. LBMAA-A-D 5.1.6, 5-5, "... FNEND terminates the
		 * definition..."
		 * Note: anywhere in the LBMAA-A-D I could find the 
		 * imperativeness of FNEND, but the previous extracts seems
		 * sufficiently imperative. */
		else if (!isDefRun) perror_(27,l) ;
		FNEND();
	}
	/* Ref. LBMAA-A-D 2-1, 2-4, A-1 */
	else if (!strncmp(lpc,"FOR",3)) p=lpc+3,FOR();
	/* Ref. LBMAA-A-D 5-6, A-2 */
	else if (!strncmp(lpc,"GOSUB",5)) p=lpc+5,GOSUB();
	/* Ref. LBMAA-A-D 1-3, 1-9, A-1 */
	else if (!strncmp(lpc,"GOTO",4)) p=lpc+4,GOTO();
	/* Ref. LBMAA-A-D 10-14, A-3 */
	else if (!strncmp(lpc,"IFEND",5)) p=lpc+5, IFEND();
	/* Ref. LBMAA-A-D 1-9, 8-2, A-1 */
	else if (!strncmp(lpc,"IF",2)) p=lpc+2, IFTHEN();
	/* Ref. LBMAA-A-D 10-5, A-3 */
	else if (!strncmp(lpc,"INPUT:",6)) p=lpc+6, FREADCOLON();
	/* Ref. LBMAA-A-D 10-5, A-3 */
	else if (!strncmp(lpc,"INPUT#",6)) p=lpc+6, FREADSHARP(1);
	/* Ref. LBMAA-A-D 6-4, A-2 */
	else if (!strncmp(lpc,"INPUT",5)) p=lpc+5, INPUT();
	/* Ref. LBMAA-A-D 1-2, 1-7, A-1 */
	else if (!strncmp(p=lpc,"LET",3) && LET());
	/* Ref. LBMAA-A-D 6-7, 10-12, A-2, A-3 "MARGIN" */
	/* Ref. LBMAA-A-D 6-7, 10-12, A-4 "MARGIN ALL" */
	else if (!strncmp(lpc,"MARGIN",6)) p=lpc+6, FMARGIN();
	/* Ref. LBMAA-A-D 7-3, 8-1, A-3 */
	else if (!strncmp(lpc,"MATINPUT",8)) p=lpc+8, MATINPUT();
	/* Ref. LBMAA-A-D 7-3, 8-1, A-3 */
	else if (!strncmp(lpc,"MATPRINT",8)) p=lpc+8, MATPRINT(0);
	/* Ref. LBMAA-A-D 7-1, 8-2, A-2 */
	else if (!strncmp(lpc,"MATREAD",7)) p=lpc+7, MATREAD();
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT B=A" */
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT C=A+B" */
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT C=A-B" */
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT C=A*B" */
	/* Ref. LBMAA-A-D 7-2, A-3 "MAT C=CON" */
	/* Ref. LBMAA-A-D 7-2, A-3 "MAT C=IDN" */
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT C=INV(A)" */
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT C=(K)*A" */
	/* Ref. LBMAA-A-D 7-4, A-3 "MAT C=TRN(A)" */
	/* Ref. LBMAA-A-D 7-2, A-2 "MAT C=ZER" */
	else if (!strncmp(lpc,"MAT",3)) p=lpc+3, MATtype();
	/* Ref. LBMAA-A-D 2-1, 2-2, A-1 */
	else if (!strncmp(lpc,"NEXT",4)) p=lpc+4, NEXT();
	/* Ref. LBMAA-A-D 6-8, 10-13, A-2, A-4 "NOPAGE" */
	/* Ref. LBMAA-A-D 10-13, A-4 "NOPAGE ALL" */
	else if (!strncmp(lpc,"NOPAGE",6)) p=lpc+6, FNOPAGE();
	/* Ref. LBMAA-A-D 10-10, 10-13, A-2, A-4 "NOQUOTE" */
	/* Ref. LBMAA-A-D 10-10, 10-13, A-4 "NOQUOTE ALL" */
	else if (!strncmp(lpc,"NOQUOTE",7)) p=lpc+7,FQUOTE(NOQUOTE);
	/* Ref. LBMAA-A-D 1-9, A-1 */
	else if (!strncmp(lpc,"ON",2)) p=lpc+2, ONGOTO();
	/* Ref. LBMAA-A-D 6-8, 10-13, A-2, A-4 "PAGE" */
	/* Ref. LBMAA-A-D 10-13, A-4 "PAGE ALL" */
	else if (!strncmp(lpc,"PAGE",4)) p=lpc+4, FPAGE();
	/* Ref. LBMAA-A-D 6-8, 11-1, A-4 */
	else if (!strncmp(lpc,"PRINTUSING#",11)) 
		p=lpc+11, FWRITEUSINGSHARP(TRUE,0);
	/* Ref. LBMAA-A-D 6-8, 11-1, A-2, A-4 */
	else if (!strncmp(lpc,"PRINTUSING",10)) p=lpc+10, PRINTUSING();
	/* Ref. LBMAA-A-D 1-3, 1-8, 6-1, 8-1, 8-2, 10-7, 10-9, A-1, A-4 */
	/* Ref. LBMAA-A-D 10-7, A-3 "PRINT#" */
	/* Ref. LBMAA-A-D 10-7, A-3 "PRINT:" */
	else if (!strncmp(lpc,"PRINT",5)) p=lpc+5, PRINT(TRUE);
	/* Ref. LBMAA-A-D 10-10, A-2, A-4 "QUOTE" */
	/* Ref. LBMAA-A-D 10-10, A-4 "QUOTE ALL" */
	else if (!strncmp(lpc,"QUOTE",5)) p=lpc+5, FQUOTE(QUOTE);
	/* Ref. LBMAA-A-D 5-3, A-5 */
	else if (!strncmp(lpc,"RANDOM",6)) RANDOMIZE();
	/* Ref. LBMAA-A-D 10-5, A-3 */
	else if (!strncmp(lpc,"READ#",5)) p=lpc+5, FREADSHARP(0);
	/* Ref. LBMAA-A-D 10-5, A-3 */
	else if (!strncmp(lpc,"READ:",5)) p=lpc+5, FREADCOLON();
	/* Ref. LBMAA-A-D 1-2, 1-7, 8-1, 8-2, 10-5, A-1, A-3 */
	else if (!strncmp(lpc,"READ",4)) p=lpc+4, READ();
	/* Ref. native decb statements, not in the LBMAA-A-D */
	else if (!strncmp(lpc,"REMARKPRAGMA",12)) p=lpc+12, PRAGMA();
	else if (!strncmp(lpc,"REMPRAGMA",9)) p=lpc+9, PRAGMA();
	/* Ref. LBMAA-A-D 6-5, A-2 */
	else if (!strncmp(lpc,"REM",3)); // no-op
	/* Ref. LBMAA-A-D 10-4, A-3 */
	else if (!strncmp(lpc,"RESTORE#",8)) p=lpc+7, FRESTORE();
	/* Ref. LBMAA-A-D 10-4, A-3 */
	else if (!strncmp(lpc,"RESTORE:",8)) p=lpc+7, FRESTORE();
	/* Ref. LBMAA-A-D 6-6, 8-3, A-2 */
	else if (!strncmp(lpc,"RESTORE",7)) p=lpc+7, RESTORE();
	/* Ref. LBMAA-A-D 5-6, A-2 */
	else if (!strncmp(lpc,"RETURN",6)) RETURN();
	/* Ref. LBMAA-A-D 10-4, A-3 */
	else if (!strncmp(lpc,"SCRATCH",7)) p=lpc+7, FSCRATCH();
	/* Ref. LBMAA-A-D 10-9, A-4 */
	else if (!strncmp(lpc,"SET",3)) p=lpc+3, FSET();
	/* Ref. LBMAA-A-D 6-5, A-2 */
	else if (!strcmp(lpc,"STOP")) END(EXIT_STOP);
	/* Ref. LBMAA-A-D 11-1, A-4 */
	else if (!strncmp(lpc,"WRITEUSING#",11)) 
		p=lpc+11, FWRITEUSINGSHARP(FALSE,0);
	/* Ref. LBMAA-A-D 10-7, A-3 "WRITE#" */
	/* Ref. LBMAA-A-D 10-9, A-3 "WRITE:" */
	else if (!strncmp(lpc,"WRITE",5)) {
		p=lpc+5, PRINT(FALSE);
	}
	/* if a statement is not recognized, maybe it's an implicit
	 * assignment; let parse() decide */
	else return FALSE;
	return TRUE;
}



/*****************************************
 *           ERROR TREATMENT             *
 *****************************************/

/* perror_()
 * print a string message based upon the following information data:
 * - errNum is the error code number defined in errors.h and must always be
 *   given as first argument 
 * - ll is the line number in which the error is occurred; if null, the 
 *   line reference is not printed (general errors); this must always be given 
 *   as the second argument
 * - all the other parameters should be the ones needed in the error strings,
 *   to fill the data in the % specifiers, according to their type 
 * The file name is added only in a CHAINed process, and only from the second
 * file on; the first file run has no file name reference */
void perror_(int errNum, int ll, ...) {
	va_list ap;
	int diff=0;

	/* print error message */
	if (channel[CONSOLE].fcounter) fprintf(stdout,"\n");
	va_start(ap, ll);
	vprintf(error[errNum], ap);
	if (ll>=0) fprintf(stdout," IN LINE %d",ll);
	if (isChain) {
		filename[strlen(filename)-4]='\0'; 
		fprintf(stdout," IN %s", basename(filename));
	}
	va_end(ap);
	if (!isHeader || ll<=-1) fprintf(stdout,"\n");

	/* rebuild cursor position in case of a warning */
	if (error[errNum][0]=='%') {
		fprintf(stdout,"\n");
		while (diff < channel[CONSOLE].fcounter) {
			diff++;
			putchar(' ');
		}
	}
	/* otherwise, stop execution if ll was a real error line number
	 * otherwise call printUsage (used into options with ll=-2) */
	else {
		if (ll<-1) printUsage();
		END(EXIT_FAILURE);
	}
}


/* sigquit()
 * end procedure if a SIGBUS, a SIGABRT or a SIGSEGV signal was trapped */
void sigquit(int sig) {
	/* reassign the normal behavior to signals */
	signal(SIGBUS, SIG_DFL);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGABRT, SIG_DFL);
	perror_(6,-2);
}


/* sigint()
 * end procedure if a SIGHUP or a SIGINT signal was trapped */
void sigint(int sig) {
	/* reassign the normal behavior to signals */
	signal(SIGINT, SIG_DFL);
	signal(SIGHUP, SIG_DFL);
	isInterrupt=TRUE;
	END(EXIT_STOP);
}


/***************************************
 *      DOCUMENTATION AND LICENSE      *
 ***************************************/

/* printHelp()
 * help message */
void printHelp(void) {
	printExistence();
	fprintf(stdout,"Usage: decb [options] [filename]\n\n");
	fprintf(stdout,"Options:\n");
	fprintf(stdout,"  -c, --capitalize  Enable complete capitalization\n");
	fprintf(stdout,"      --conditions  Print GPL3 redistribution conditions and exit\n");
	fprintf(stdout,"      --errors-list Print a complete errors list and exit\n");
	fprintf(stdout,"  -g, --grace       Enable grace mode in LIST (spacing and indenting)\n");
	fprintf(stdout,"  -h, --help        Display this information and exit\n");
	fprintf(stdout,"      --insert      Insert line numbers and LIST\n");
	fprintf(stdout,"      --length      Print number of characters in the program file\n");
	fprintf(stdout,"  -L [n1[-n2]]      LIST file lines from <n1> to <n2>\n");
	fprintf(stdout,"      --list        LIST all file lines\n");
	fprintf(stdout,"  -N <name>         Show in header <name> instead of current file name\n");
	fprintf(stdout,"  -n, --no-header   Disable printing of header and footer\n");
	fprintf(stdout,"      --no-reset    Disable memory resetting on CHAIN calls\n");
	fprintf(stdout,"  -P <num>          Set <num> as the maximum PAGE length for current program\n");
	fprintf(stdout,"  -R [n[,f,k]]      RESEQUENCE file lines and LIST (f becomes n, step k)\n");
	fprintf(stdout,"      --resequence  RESEQUENCE file lines and LIST (default values for f,n,k)\n");
	fprintf(stdout,"      --reverse     Reverse LIST order for list\n");
	fprintf(stdout,"  -S <num>          Start program from line number <num>\n");
	fprintf(stdout,"      --save        Set SAVE mode for list (enable overwriting file)\n");
	fprintf(stdout,"  -T <num>          Set <num> as the tab stop for list indenting, in grace mode\n");
	fprintf(stdout,"  -v, --version     Display version and exit\n");
	fprintf(stdout,"      --warranty    Print warranty conditions from GPL3 and exit\n");
	fprintf(stdout,"\nYou should have received a copy of the GNU General Public License\n");
	fprintf(stdout,"along with this program. If not, see <http:/www.gnu.org/licenses/>.\n\n");
	fprintf(stdout,"Consult the man or the info page to know about decb more in detail.\n\n");
	fprintf(stdout,"Email bugs reports to <tbin at libero dot it>.\n\n"); 
}

/* printUsage()
 * usage message */
void printUsage(void) {
	fprintf(stdout,"Usage: decb [options] [filename]\n");
	fprintf(stdout,"Type decb -h for help\n");
	exit(EXIT_FAILURE);
}

/* printExistence()
 * existence message */
void printExistence(void) {
	fprintf(stdout,"decb - DEC-20 BASIC interpreter\n");
}

/* printVersion()
 * help banner */
void printVersion(void) {
	printExistence();
	fprintf(stdout,"version %s (built on %s, at %s)\n", 
		VERSION, __DATE__ ,__TIME__);
	fprintf(stdout,"Copyleft (C) %s %s <%s>. \n", CY, AU, EM);
}


/* printLicense()
 * version message */
void printLicense(void) {
	fprintf(stdout,"This free software comes with ABSOLUTELY NO WARRANTY; for details about this,\ntype 'decb --warranty'.  You are welcome to redistribute it under certain\nconditions; type 'decb --conditions' for details.\nThis software is released under the terms of the GNU General Public License 3.\n\n");
}


/* printWarranty()
 * warranty message (required by GPL3) */
void printWarranty(void) {
	fprintf(stdout,"THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\nAPPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT\nHOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT\nWARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT\n");
	fprintf(stdout,"LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A\nPARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF\nTHE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME\nTHE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\n");
}


/* printConditions()
 * conditions message (required by GPL3) */
void printConditions(void) {
	fprintf(stdout,"You may make, run and propagate covered works that you do not convey,\nwithout conditions so long as your license otherwise remains in force.\nYou may convey covered works to others for the sole purpose of having\nthem make modifications exclusively for you, or provide you with\nfacilities for running those works, provided that you comply with the\n");
	fprintf(stdout,"terms of this License in conveying all material for which you do not\ncontrol copyright. Those thus making or running the covered works for\nyou must do so exclusively on your behalf, under your direction and\ncontrol, on terms that prohibit them from making any copies of your\ncopyrighted material outside their relationship with you.\n\n");
}

/******************************************************************************
 * MAIN
 ******************************************************************************/


/* main() 
 * Here is where it all begins... 
 * parse options, get file name, setup environment and perform, at request, 
 * the following actions:
 * - OLD
 *   Ref. LBMAA-A-D 9.1, 9-1, "Creating the File in Memory"
 * - RESEQUENCE
 *   Ref. LBMAA-A-D 9.3.3, 9-5, "Renumbering Lines in the File"
 * - LIST
 *   Ref. LBMAA-A-D 9.2, 9-3, "Listing Files"
 * - RUN
 *   Ref. LBMAA-A-D 9.5, 9-8, "Executing a BASIC Program"
 * - LENGTH
 *   Ref. LBMAA-A-F- 9.7, 9-12, "Obtaining information"
 * - And a further option: insert line numbers into files born without them */
int main(int argc, char **argv) {
	int c, ac=0;
	char hour[24], date[24];
	int n=-1, f=0, k=10; 	// RESEQUENCE defaults
	int n1=0, n2=CORELIM;	// LIST defaults

	/* reset 'fakename' */
	fakename[0]='\0';

	/* parse options; double and single dash options may be alternated,
	 * options requiring an argument may or not be attached (but must
	 * be the last options of that group)
	 * e.g.
	 * decb -c -nS40 -gL 10- 50 --save filename the_rest
	 * -c set capitalize mode
	 * -n set no-header mode
	 * -S40 set 40 as starting line
	 * -g set grace mode
	 * -L 10- 50 list lines from 10 to 50
	 * --save makes definitive the next listing
	 * filename is the file which will be the object of the action 
	 * the_rest (whatever it is) is ignored
	 * Copyleft Antonio Maschio - March 2014 */
	while (++ac < argc) {
		if (*argv[ac]=='-') {
			/* parse double-dash options */
			if (!strcmp(argv[ac], "--help")) { 
			        putchar('\n');	
				printHelp(); 
				exit(EXIT_SUCCESS); 
			}
			else if (!strcmp(argv[ac], "--errors-list") ||\
				!strcmp(argv[ac], "--errorslist") ||\
				!strcmp(argv[ac], "--errors")) { 
				int i;
				char *y;
				fprintf(stdout,"\nErrors list for decb ");
				fprintf(stdout,"version %s\n\n",VERSION);
				for (i=0;i<ERRLIM;i++) {
				    char n='\0';
				    y=error[i];
				    if (*y) {
					while (*y=='\n') y++;
				    	if (!strrchr(y,'\n')) n='\n';
				        if (!strncmp(y,"%%%%",2))	
				    	    fprintf(stdout,"%3d %s%c",i,y+1,n);
					else
					    fprintf(stdout,"%3d %s%c",i,y,n);
				    }
				}
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS); 
			}
			else if (!strcmp(argv[ac], "--version")) {
			        putchar('\n');	
				printVersion();
				printLicense();
				exit(EXIT_SUCCESS); 
			}
			else if (!strcmp(argv[ac], "--warranty")) {
			        putchar('\n');	
				printWarranty();
				exit(EXIT_SUCCESS);
			}
			else if (!strcmp(argv[ac], "--conditions")) {
			        putchar('\n');	
				printConditions();
				exit(EXIT_SUCCESS);
			}
			else if (!strcmp(argv[ac], "--grace")) {
				isGrace=TRUE;
				continue;
			}
			else if (!strcmp(argv[ac], "--insert") ||\
				!strcmp(argv[ac], "--insert-line-numbers")) {
				isToInsert=TRUE;
				continue;
			}
			else if (!strcmp(argv[ac], "--no-header") ||\
				!strcmp(argv[ac], "--no-heading") ||\
				!strcmp(argv[ac], "--no-footer")) {
				isHeader=FALSE, pagerow=0;
				continue;
			}
			else if (!strcmp(argv[ac], "--resequence") ||\
				!strcmp(argv[ac], "--renumber") ||\
				!strcmp(argv[ac], "--reseq") ||\
				!strcmp(argv[ac], "--renum")) {
				isToReseq=TRUE;
				isHeader=FALSE, pagerow=0;
				continue;
			}
			else if (!strcmp(argv[ac], "--list")) {
				isToList=TRUE;
				isHeader=FALSE, pagerow=0;
				continue;
			}
			else if (!strcmp(argv[ac], "--reverse")) {
				isReverse=TRUE;
				continue;
			}
			else if (!strcmp(argv[ac], "--save")) {
				isReseqSave=TRUE;
				continue;
			}
			else if (!strcmp(argv[ac], "--length") ||\
				!strcmp(argv[ac], "--len")) {
				isToLen=TRUE;
				isHeader=FALSE, pagerow=0;
				continue;
			}
			else if (!strcmp(argv[ac], "--no-reset") ||\
				!strcmp(argv[ac], "--noreset")) {
				isToReset=NORESET;
				continue;
			}
			else if (!strcmp(argv[ac], "--capitalize") ||\
				!strcmp(argv[ac], "--all-upper")) {
				isCap=TRUE;
				continue;
			}
			/* option --greetings
			 * this feature is intentionally undocumented;
			 * I use it to generate the README file 
			 * UNDOCUMENTED */
			else if (!strcmp(argv[ac], "--greetings") ||\
				!strcmp(argv[ac], "--ciao")) {
				fprintf(stdout,WELCOME);
				printVersion();
				printLicense();
				printHelp();
				fprintf(stdout,GREET);
				printWarranty();
				printConditions();
				fprintf(stdout,"It's GPL. Enjoy!\n\n");
				exit(EXIT_SUCCESS);
			}
			
			/* parse single-dash options */
			while (*++argv[ac]) {
				c=*argv[ac];
				/* option -h
				 * print help*/
				if (c=='h') {
			        	putchar('\n');	
					printHelp();
					exit(EXIT_SUCCESS); 
				}
				/* option -V
				 * print version number only 
				 * UNDOCUMENTED */
				else if (c=='V') {
					fprintf(stdout,"%s\n", VERSION);
					exit(EXIT_SUCCESS); 
				}
				/* option -E
				 * print existence and version number only 
				 * UNDOCUMENTED */
				else if (c=='E') {
					printExistence();
					fprintf(stdout,"version %s (built on %s, at %s)\n", VERSION, __DATE__ ,__TIME__);
;
					exit(EXIT_SUCCESS); 
				}
				/* option -v 
				 * print version and license */
				else if (c=='v') {
			        	putchar('\n');	
					printVersion();
					printLicense(); 
					exit(EXIT_SUCCESS); 
				}
				/* option -c
				 * set Capitalize-input mode */
				else if (c=='c') {
					isCap=TRUE;
				}
				/* option -C
				 * set Comments printing 
				 * UNDOCUMENTED */
				else if (c=='C') {
					isRemPrint=TRUE;
				}
				/* option -d
				 * set Debug mode
				 * UNDOCUMENTED */
				else if (c=='d') {
					isDebug=TRUE;
				}
				/* option -g 
				 * enable grace mode for LIST */
				else if (c=='g') {
					isGrace=TRUE;
				}
				/* option -L (LIST)
				 * activate listing of BASIC code */
				else if (c=='L') {
					char *u;
					isToList=TRUE;
					isHeader=FALSE, pagerow=0;
					if (!*++argv[ac]) ac++;
					u=argv[ac];
					if (isdigit(*u)) 
						n1=strtol(u,&u,10);
					if (!*u) u=argv[++ac];
					if (*u=='-'||*u==',') {
						u++;
						if (!*u) u=argv[++ac];
						if (isdigit(*u)) 
							n2=strtol(u,&u,10);
						else {
							ac--;
							break;
						}
					}
					else {
						n2=n1;
						ac--;
					}
					if (!n1 && !n2) n2=DATLIM;
					/* check/set limits */
					if (n1<0) n1=0;
					if (n1>DATLIM) n1=DATLIM;
					if (n2<0) n2=0;
					if (n2>DATLIM) n2=DATLIM;
					/* swap if inverted and activate
					 * reverse listing */
					if (n1>n2) {
						int n3=n2;
						n2=n1;
						n1=n3;
						isReverse=TRUE;
					}
					break;
				}
				/* option -n (RUNNH)
				 * disable header and footer */
				else if (c=='n') {
					isHeader=FALSE, pagerow=0;
					break;
				}
				/* option -N <name>
				 * set alternate banner name */
				else if (c=='N') {
					char *u;
					if (!*++argv[ac]) ac++;
					u=argv[ac];
					if (!u) perror_(196,-2);
					else if (*u!='-') 
						strncpy_(fakename,u,COMPSTR);
					else perror_(200,-2);
					break;
				}
				/* option -S <num> (RUN + Start)
				 * set starting line */
				else if (c=='S') {
					char *u;
					if (!*++argv[ac]) ac++;
					u=argv[ac];
					if (!u) perror_(196,-2);
					else if (isdigit(*u)) 
						startingLine=strtol(u,&u,10);
					else perror_(203,-2,"", c);
					if (startingLine<0) 
						startingLine=0;
					if (startingLine>DATLIM) 
						startingLine=DATLIM;
					break;
				}
				/* option -R <n,f,k> (RESEQUENCE) */
				else if (c=='R') {
					char *u;
					isToReseq=TRUE;
					isHeader=FALSE, pagerow=0;
					if (!*++argv[ac]) ac++;
					u=argv[ac];
					if (!u) perror_(196,-2);
					else if (isdigit(*u)) 
						n=strtol(u,&u,10);
					if (!*u) u=argv[++ac];
					if (!u) perror_(196,-2);
					else if (*u==',' || *u=='-') {
						u++;
						if (!*u) u=argv[++ac];
						if (!u) perror_(196,-2);
						else if (isdigit(*u)) 
							f=strtol(u,&u,10);
						if (*u==','||*u=='-') u++;
						if (!*u) u=argv[++ac];
						if (!u) perror_(196,-2);
						else if (isdigit(*u)) 
							k=strtol(u,&u,10);
						else ac--;
					}
					else ac--;
					break;
				}
				/* option -P <num>
				 * set maximum page length (user-defined) */
				else if (c=='P') {
					char *u;
					int tt=LIMIT;
					if (!*++argv[ac]) ac++;
					u=argv[ac];
					if (!u) perror_(196,-2);
					else if (isdigit(*u)) 
						tt=strtol(u,&u,10);
					else tt=DEFPAGEHEIGHT;
					if (tt<=0) {
						perror_(201,-2,c);
						tt=DEFPAGEHEIGHT;
					}
					else if (tt>LIMIT) {
						perror_(201,-2,c);
						tt=LIMIT;
					}
					PAGEHEIGHT=tt;
					break;

				}
				/* option -T <num>
				 * set tab stop for LIST */
				else if (c=='T') {
					char *u;
					int tt=listTab;
					if (!*++argv[ac]) ac++;
					u=argv[ac];
					if (!u) perror_(196,-2);
					else if (isdigit(*u)) 
						tt=strtol(u,&u,10);
					else tt=listTab;
					if (tt<0 || tt>16) {
						perror_(201,-2,c);
						tt=listTab;
					}
					listTab=tt;
					break;

				}
				else perror_(202,-2,c);
			}
		}
		else break;
	}

	/* OK; now, if after any option no file name was given (or if decb was 
	 * launched with no executive options), issue an error */
	if ((ac==argc)||(1==argc)) perror_(196,-2); 

	/* get input file name (discard following arguments) 
	 * and setup name, attaching extension if not present */ 
	strncpy_(filename, argv[ac], COMPSTR);
	setupName(filename,&c ,&c);
	
	/* once found the filename, insert lines numbers if required */
	if (isToInsert) {
		INSERTLINENUMBERS();
		if (isToReseq) RESEQUENCE(n,f,k);
		return 0;
	}

	/* print header for the main program (not for CHAINed sections) 
	 * according to the BASIC interface format string and to present time; 
	 * if 'fakename' was given in option -N, it's used in place of
	 * current proper filename; extension is cut off if it's .BAS */
	if (isHeader) {
		if (fakename[0]) strncpy_(longname,fakename,COMPSTR);
		else strncpy_(longname,filename,COMPSTR);
		turnToUpper(longname);
		if (!strcmp(longname+strlen(longname)-strlen(EXT), EXT))
			longname[strlen(longname)-strlen(EXT)]='\0';
		sprintw(hour,24,"%02d:%02d", getHour(), getMin());
		sprintw(date,24,"%02d-%s-%02d",getDay(),getMonthString(),
				getYear()-2000);
		fprintf(stdout,THISHEADER, basename(longname), hour, date);
		fprintf(stdout,"\n");
	}
	/* one void line for RUNNH (but not for LIST, Insert and RESEQUENCE) */
	else if (!(isToList+isToReseq+isToInsert)) fprintf(stdout,"\n");
	/* set starting time for features that work upon time */
	now=time(NULL);

	/* set up console channels data (which is the terminal, in decb) 
	 * Note: only meaningful data for sequential output are set 
	 * Note: this is done here because every decb functions must find
	 * CONSOLE set up and running for error messages printing */
	channel[CONSOLE].stream=stdout;
	channel[CONSOLE].isopen=TRUE;
	channel[CONSOLE].type=SEQ;
	channel[CONSOLE].fcounter=0;
	channel[CONSOLE].wayout=VWRITE;
	channel[CONSOLE].quote=NOQUOTE;
	channel[CONSOLE].page=0;
	channel[CONSOLE].pagerow=6;
	channel[CONSOLE].margin=SCRLIM;
	channel[CONSOLE].fprintn=TRUE;
	/* erase all channel streams 
	 * (just to be sure, they should be already null...) */
	for (c=1; c<=STREAMS; c++) 
		channel[c].isopen=FALSE, channel[c].stream=NULL;

	/* Trap memory errors */
	signal(SIGABRT, sigquit);
	signal(SIGSEGV, sigquit);
	signal(SIGBUS, sigquit);
	/* Trap interrupts */
	signal(SIGHUP, sigint);
	signal(SIGINT, sigint);

	/* OLD (implicit!)
	 * store program in memory 
	 * Ref. LBMAA-A-D 9.1, 9-1, "Creating the File in Memory" */
	OLD();

	/* LENGTH
	 * it must be executed before RUN and after OLD
	 * LBMAA-A-D 9.7, 9-12, "Obtaining Information" */
	if (isToLen) {
		fprintf(stdout,"LENGTH\n%d CHARACTERS\n\n",listingLen());
		return EXIT_SUCCESS;
	}

	/* RESEQUENCE
	 * it must be executed before RUN and after OLD
	 * Ref. LBMAA-A-D 9.3.3, 9-5, "Renumbering Lines in the File" */
	if (isToReseq) {
		RESEQUENCE(n,f,k);
		return EXIT_SUCCESS;
	}

	/* LIST
	 * it must be executed before RUN and after OLD 
	 * Ref. LBMAA-A-D 9.2, 9-3, "Listing Files" */
	if (isToList) {
		listAndSave(n1,n2);
		return EXIT_SUCCESS;
	}

	/* RUN (finally!)
	 * Note: RUN records also starting timer 
	 * Note: Starting line, if given, is stored in variable startingLine
	 * Ref. LBMAA-A-D 9.5, 9-8, "Executing a BASIC Program" */
	RUN();
    
	/* exit
	 * Note: the program gets here only if no error caused an anticipated 
	 * exiting in some line which is not the last END; thus, a SYSTEM ERROR 
	 * message is shown (error not controlled by the BASIC language) */
	perror_(58,-2);

	/* ... and here is where it all ends.*/
	return 0; // hopefully never executed, but necessary for C

} /* end main */

/* end of decb.c */
