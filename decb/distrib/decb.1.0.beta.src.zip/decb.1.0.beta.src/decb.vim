" Vim syntax file
" Language:	DEC-10 BASIC 17D (= version V of Dartmouth)
" Creator:	Antonio Maschio <tbin at libero dot it>
" Maintainer:	Antonio Maschio <tbin at libero dot it>
" Last updated: November 2014

" Based on Allan Kelly's BASIC vim file
" With the active help of Mike Soyka, Brett Stahlman and Christian Brabandt

" For version 5.x: Clear all syntax items
" For version 6.x: Quit when a syntax file was already loaded
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif

syn clear

" expand keywords characters set (thanks to Mike Soyka for this tip)
set iskeyword+=#,$,*,:

" functions
syn keyword decbFunction ABS ATN COS COT DET EXP INT NUM RND SIN TAN SGN LEN 
syn keyword decbFunction LOG LN LOGE CLOG LOG10 SQR SQRT TIM LOC LOF ASC 
syn keyword decbFunction  INSTR VAL POS MEM
syn match   decbFunction "FN[A-Z]\+"
syn keyword decbStrFunction  SPACE$ STR$ LEFT$ MID$ RIGHT$ CHR$

" facilities
syn keyword decbTodo contained	TODO
syn match   decbTodo "PRAGMA.*"
syn match   decbTodo "PRAGMA.*\'"me=e-1

" statements always without arguments or connective elements
syn keyword decbStatement END STEP BY THEN RETURN STOP TO RANDOMIZE FNEND

" statements with arguments, divided in standard and file arguments
" (thanks to Brett Stahlman and Christian Brabandt for their helpful tips)
syn match  decbStatement "IF\s*[-(A-Z0-9\.\-]"me=s+2
syn match  decbStatement "IF\s*["]"me=s+2
syn match  decbErr       "IF\s*[$']"me=s+2
syn match  decbStatement "LET\s*[A-Z][0-9]*$\s*="me=s+3
syn match  decbStatement "LET\s*[A-Z][0-9]*$\s*("me=s+3
syn match  decbStatement "LET\s*[A-Z][0-9]*\s*="me=s+3
syn match  decbStatement "LET\s*[A-Z][0-9]*\s*("me=s+3
syn match  decbStatement "LET\s*FN*"me=s+3
syn match  decbErr       "LET\s*[$']"me=s+3
syn match  decbStatement "ON\s*[A-Z]"me=s+2
syn match  decbErr  	  "ON\s*[0-9$']"me=s+2
syn match  decbStatement "PRINT"
syn match  decbStatement "INPUT\s*[A-Z]"me=s+5
syn match  decbErr       "INPUT\s*[$']"me=s+5
syn match  decbStatement "READ"
syn match  decbStatement "RESTORE"
syn match  decbStatement "CHANGE\s*[A-Z\"]"me=s+6
syn match  decbErr       "CHANGE\s*[$']"me=s+6
syn match  decbErr       "CHAIN\s*[$']"me=s+5
syn match  decbStatement "CHAIN\s*\""me=e-1
syn match  decbStatement "DATA\s*-*[0-9A-Z\.\"]"me=s+4
syn match  decbErr       "DATA\s*[$']"me=s+4
syn match  decbStatement "DEF\s*FN[A-Z]"
syn match  decbStatement "DIMENSION\s*[A-Z][0-9]\=\$\=("me=s+9
syn match  decbErr       "DIMENSION\s*[$']"me=s+9
syn match  decbStatement "DIM\s*[A-Z][0-9]\=\$\=("me=s+3
syn match  decbErr       "DIM\s*[$']"me=s+3
syn match  decbStatement "FOR\s*[A-Z]"me=s+3
syn match  decbErr       "FOR\s*[$']"me=s+3
syn match  decbStatement "NEXT\s*[A-Z]"me=s+4
syn match  decbErr       "NEXT\s*[$']"me=s+4
syn match  decbStatement "GOSUB\s*[0-9]"me=s+5
syn match  decbErr       "GOSUB\s*[$']"me=s+5
syn match  decbStatement "GO\s*TO\s*[0-9]"me=e-1
syn match  decbErr       "GO\s*TO\s*[$']"me=s+5
syn match  decbFile 	  "FILES\s*[A-Z0-9\"]\+"me=s+5
syn match  decbErr  	  "FILES\s*[$']"me=s+5
syn match  decbFile 	  "FILE\s*[#:]\s*[A-Z0-9\.]\s*[:,]\+"
syn match  decbErr  	  "FILE\s*[0-9$']"
syn match  decbErr  	  "FILE\s*[$']"me=s+4
syn match  decbFile 	  "PRINT\s*#\s*\d\+"
syn match  decbFile 	  "WRITE\s*#\s*\d\+"
syn match  decbFile 	  "PRINT\s*:\s*\d\+"
syn match  decbFile 	  "WRITE\s*:\s*\d\+"
syn match  decbErr  	  "WRITE\s*[$']"me=s+5
syn match  decbErr  	  "WRITE\s*[0-9]\+"
syn match  decbFile 	  "INPUT\s*#\s*\d\+"
syn match  decbErr 	  "INPUT\s*\d\+"
syn match  decbFile 	  "READ\s*#\s*\d\+"
syn match  decbErr	  "READ\s*\d\+"
syn match  decbFile 	  "INPUT\s*:\s*\d\+"
syn match  decbFile 	  "READ\s*:\s*\d\+"
syn match  decbErr  	  "READ\s*[$']"me=s+4
syn match  decbFile 	  "QUOTE\s*[#,]"me=s+5
syn match  decbFile 	  "QUOTE\s*[0-9]*"me=s+5
syn match  decbFile 	  "QUOTE\s*[$']"me=s+5
syn match  decbFile 	  "QUOTE\s*ALL"
syn match  decbFile 	  "NOQUOTE\s*[#,]"me=s+7
syn match  decbFile 	  "NOQUOTE\s*[0-9]*"me=s+7
syn match  decbFile 	  "NOQUOTE\s*[$']"me=s+7
syn match  decbFile 	  "NOQUOTE\s*ALL"
syn match  decbFile 	  "IF\s*END\s*[#:]\s*\d\+"
syn match  decbErr  	  "IF\s*END\s*[0-9$']"
syn match  decbErr  	  "IF\s*END\s*[$']"me=s+6
syn match  decbFile 	  "NOPAGE\s*\d*\s*[$']"me=s+6
syn match  decbFile 	  "NOPAGE\s*#\s*\d\+"
syn match  decbFile 	  "NOPAGE\s*ALL"
syn match  decbFile 	  "PAGE\s*#\s*\d\+"
syn match  decbFile 	  "PAGE\s*ALL"
syn match  decbFile  	  "PAGE\s*[0-9]*"
syn match  decbErr  	  "PAGE\s*[$']"me=s+4
syn match  decbFile 	  "PAGE\s*\d\+\s*[$']"me=s+4
syn match  decbErr  	  "PAGE\s*ALL\s*[$']"me=s+8
syn match  decbFile 	  "RESTORE\s*[#:]*\s*\d\+" 
syn match  decbFile 	  "RESTORE\s*\d\+"he=e-1 
syn match  decbFile 	  "SCRATCH\s*[#:]*\s*\d\+"
syn match  decbFile 	  "SCRATCH\s*\d\+"he=e-1 
syn match  decbErr  	  "SCRATCH\s*[$']"me=s+7
syn match  decbFile 	  "MARGIN\s*#\s*\d\+"
syn match  decbFile 	  "MARGIN\s*ALL\s*[A-Z0-9\.-]"he=e-1
syn match  decbFile  	  "MARGIN\s*[0-9]*"
syn match  decbErr  	  "MARGIN\s*[$']"me=s+6
syn match  decbFile 	  "MARGIN\s*\d\+\s*[$']"me=s+6
syn match  decbErr  	  "MARGIN\s*ALL\s*[$']"me=s+10
syn match  decbFile 	  "SET\s*[:]"me=s+3
syn match  decbErr  	  "SET\s*[$']"me=s+3
syn match  decbErr  	  "SET\s*#\d\+"
syn match  decbErr  	  "SET\s*[0-9]"

" matrix syntax
syn match  decbMAT 	  "MAT"
syn match  decbErr 	  "MAT\s*[0-9$']"me=s+3
syn match  decbMAT 	  "MAT\s*PRINT"
syn match  decbMAT 	  "MAT\s*INPUT"
syn match  decbMAT 	  "MAT\s*READ"
syn keyword decbMAT 	  ZER CON IDN TRN INV 

" variable
syn match  decbStrVar    "\a\$"
syn match  decbStrVar    "\a\d\$"

" file arguments
syn match  decbFile      "[#:]\s*\d\+"
syn match  decbFile      "[#:]\s*\d\+[,:]"he=e-1
syn match  decbFile      "[#:]\s*[A-Z\.]\+"me=e-1
syn match  decbErr       "#\s*[,:]\s*\d\+"

" line number
syn match decbLineNumber "^\d"
syn match decbLineNumber "^\d\d"
syn match decbLineNumber "^\d\d\d"
syn match decbLineNumber "^\d\d\d\d"
syn match decbLineNumber "^\d\d\d\d\d"

" strings and USING formatters constants
syn region decbString	start="\""  end="\""
syn region decbString	start="^\d*\s*:"hs=e-1 end="$" contains=decbLineNumber

" comments
" linear comment
syn region  decbComment start="^#"   end="$" contains=decbTodo
" REM comment
syn region  decbComment start="REM"  end="$" contains=decbTodo
" tick comment
syn region  decbComment start="\'"   end="$" contains=decbTodo
" tail comment
syn region  decbComment start="^@"   end="\%$"
" inner comment
syn region  decbComment start="^&"   end="^&.*$"

" file names
syn match decbString "[0-9A-Z]\{1,6}\.[0-9A-Z]\{0,3}[\$\%]*[0-9]*"
syn match decbString "[0-9A-Z]\{1,6}\.*[0-9A-Z]*[\$\%]\+[0-9]*"
syn match decbString "<PA>"

" other instructions that may be affected by the 'file names' section
syn match  decbStatement "RESTORE\s*\*\+"
syn match  decbStatement "RESTORE\s*\$\+"
syn match  decbFloat     "\d*\.\d\+E*\d*"
syn match  decbStatement "PRINT\s*USING\s*\d*"
syn match  decbStatement "PRINT\s*USING\s*[A-Z]\+[0-9]*\$"
syn region decbStatement start="PRINT\s*USING\s*\"" end="\""
syn match  decbFile 	  "PRINT\s*USING\s*#\d*\s*,\s*\d*"
syn match  decbFile 	  "PRINT\s*USING\s*#[0-9]\+\s*,\s*[A-Z]\+[0-9]*\$"
syn region decbFile 	  start="PRINT\s*USING\s*#[0-9]\+\s*,\s*\"" end="\""
syn match  decbFile 	  "PRINT\s*#\s*\d\+\s*,*\s*USING\s*\d*"
syn match  decbFile 	  "PRINT\s*#\s*\d\+\s*,*\s*USING\s*[A-Z]\+[0-9]*\$"
syn region decbFile 	  start="PRINT\s*#\s*[0-9]\+\s*,*\s*USING\s*\"" end="\""
syn match  decbFile 	  "WRITE\s*USING\s*#\d*\s*,\s*\d*"
syn match  decbFile 	  "WRITE\s*USING\s*#[0-9]\+\s*,\s*[A-Z]\+[0-9]*\$"
syn region decbFile 	  start="WRITE\s*USING\s*#[0-9]\+\s*,\s*\"" end="\""
syn match  decbFile 	  "WRITE\s*#\s*\d\+\s*,*\s*USING\s*\d*"
syn match  decbFile 	  "WRITE\s*#\s*\d\+\s*,*\s*USING\s*[A-Z]\+[0-9]*\$"
syn region decbFile 	  start="WRITE\s*#\s*[0-9]\+\s*,*\s*USING\s*\"" end="\""

" Define the default highlighting.
" For version 5.7 and earlier: only when not done already
" For version 5.8 and later: only when an item doesn't have highlighting yet
if version >= 508 || !exists("did_decb_syntax_inits")
  if version < 508
    let did_decb_syntax_inits = 1
    command -nargs=+ HiLink hi link <args>
  else
    command -nargs=+ HiLink hi def link <args>
  endif

  HiLink decbLineNumber	Comment
  HiLink decbStatement		Statement
  HiLink decbFile		Function
  HiLink decbString		Constant
  HiLink decbComment		Comment
  HiLink decbTodo		Todo
  HiLink decbFunction		PreProc
  HiLink decbStrFunction	Constant
  HiLink decbMAT 		Special
  HiLink decbMathsOperator 	PreProc
  HiLink decbStrVar             Constant
  HiLink decbErr		Error
 

  delcommand HiLink
endif

let b:current_syntax = "decb"
set ts=8
set nocin
set nosi
set columns=80

" vim: ts=8
