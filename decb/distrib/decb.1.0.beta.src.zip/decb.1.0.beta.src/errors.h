/* errors.h 
 * Copyleft (C) 2009-2014 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 24 October 2014
 * 
 * This file contains all the error strings put out by perror_().
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * It's GPL! Good decb!
 */

/* Note:
 * in the following list, the words 'originally' or 'original' refer to the 
 * list in the LBMAA-A-D, Appendix B, Tables B-1, B-2, B-3; since the DEC-10 at
 * the Living Computer Museum sometimes shows little differences in the error 
 * messages text, I updated the text to reflect the 'real' machine, advicing 
 * the reader that the changed lines are not equal to the relative book lines.*/

char* error[]= {

/* BASIC OS INTERFACE ERRORS 
 * the meaningful error messages are retained, tho sometime slightly changed */

/* 0 */	"",
/* 1 */	"",
/* 2 */	"",
/* 3 */	"",
/* the following error 4 originally was "COMMAND ERROR..."; I changed it
 * because in decb there's no command system */
/* 4 */	"\n? MEMORY ERROR (YOU MAY NOT OVERWRITE LINES OR CHANGE THEIR ORDER)\n",
/* the following error 5 originally was like "COMMAND ERROR..."; I changed it
 * because in decb there's no command system */
/* 5 */	"? MEMORY ERROR (LINE NUMBERS MAY NOT EXCEED 99999)\n",
/* the following errors 6-7-8 are brand new */
/* 6 */	"? MEMORY ERROR",
/* 7 */	"? MEMORY ERROR (RENUM CANNOT BE PERFORMED)",
/* 8 */	"? MEMORY ERROR (NUMBER INSERTION CANNOT BE PERFORMED)",
/* 9 */	"",
/*10 */	"? FILE %s NOT FOUND",

/*11 */	"",
/*12 */	"",
/*13 */	"? MISSING LINE NUMBER FOLLOWING LINE %d",
/*14 */	"",
/*15 */	"",
/*16 */	"", 
/*17 */	"",
/*18 */	"",
/*19 */	"",
/*20 */	"",
/*21 */	"",

/* BASIC LANGUAGE ERRORS */
	
/* The following error 22 originally was "BAD DATA INTO LINE n" */
/*22 */	"? BAD DATA",
/* The following error 23 was originally "DATA IS NOT ..." */
/*23 */	"? DATA NOT IN CORRECT FORM",
/*24 */	"? END IS NOT LAST",
/*25 */	"? EOF",
/*26 */	"? FAILURE ON ENTRY",
/*27 */	"? FNEND BEFORE DEF",
/*28 */	"? FNEND BEFORE NEXT",
/*29 */	"? FOR WITHOUT NEXT",
/*30 */	"? GOSUB WITHIN DEF",
/*31 */	"? FUNCTION DEFINED TWICE",
/*32 */	"? ILLEGAL ARGUMENT FOR ASC FUNCTION",

/*33 */	"? ILLEGAL CHARACTER",
/*34 */	"? ILLEGAL CONSTANT",
/*35 */	"? ILLEGAL FORMAT",
/*36 */	"? ILLEGAL FORMAT WHERE THE WORDS THEN OR GO TO WERE EXPECTED",
/*37 */	"? ILLEGAL FORMULA",
/*38 */	"? ILLEGAL INSTRUCTION",
/* The following error 39 had no space at the end */
/*39 */	"? ILLEGAL LINE REFERENCE ",
/*40 */	"? ILLEGAL LINE REFERENCE %d",
/*41 */	"? ILLEGAL RELATION",
/*42 */	"? ILLEGAL VARIABLE",
/*43 */	"? INCORRECT NUMBER OF ARGUMENTS",
/*44 */	"? INITIAL PART OF STATEMENT NEITHER MATCHES A STATEMENT KEYWORD NOR HAS A FORM LEGAL FOR AN IMPLIED LET--CHECK FOR MISSPELLING",
/*45 */	"? MIXED STRINGS AND NUMBERS",
/*46 */	"? NESTED DEF",
/*47 */	"? NEXT WITHOUT FOR",
/*48 */	"? %d IS NOT AN IMAGE",

/*49 */	"? NO CHARACTERS IN IMAGE",
/*50 */	"? NO DATA",
/*51 */	"? NO END INSTRUCTION",
/*52 */	"? NO FNEND FOR DEF FN%c",
/*53 */	"? OUT OF ROOM",
/*54 */	"? RETURN WITHIN DEF",
/*55 */	"? SPECIFIED LINE IS NOT AN IMAGE",
/*56 */	"? STRING RECORD LENGTH > 132 OR < 1",	// see 125
/*57 */	"? STRING VECTOR IS 2-DIM ARRAY",
/*58 */	"? SYSTEM ERROR", 
/*59 */	"? TOO MANY FILES",
/*60 */	"? UNDEFINED FUNCTION -- FN%c",
/*61 */	"? UNDEFINED LINE NUMBER %d",
/*62 */	"? USE VECTOR, NOT ARRAY",
/*63 */	"? VARIABLE DIMENSIONED TWICE",
/*64 */	"? VECTOR CANNOT BE ARRAY",
/*65 */	"? %s WAS SEEN WHERE %s WAS EXPECTED",

/*66 */	"%% ABSOLUTE VALUE RAISED TO POWER",
/*67 */	"? ATTEMPT TO OUTPUT A NEGATIVE NUMBER TO A * OR $ FIELD",
/*68 */	"? ATTEMPT TO OUTPUT A NUMBER TO A STRING FIELD OR A STRING TO A NUMERIC FIELD",
/*69 */	"? ATTEMPT TO READ# OR INPUT# FROM A FILE WHICH DOES NOT EXIST",
/*70 */	"? ATTEMPT TO READ# OR INPUT# FROM A FILE WHICH IS IN WRITE# OR PRINT# MODE",
/*71 */	"? ATTEMPT TO WRITE A LINE NUMBER > 99,999",
/*72 */	"? ATTEMPT OT WRITE# OR PRINT# TO A FILE WHICH HAS NOT BEEN SCRATCH#ED",
/*73 */	"? ATTEMPT TO WRITE# OR PRINT# FROM A FILE WHICH IS IN READ# OR INPUT# MODE",
/*74 */	"? CHR$ ARGUMENT OUT OF BOUNDS",
/*75 */	"? DATA FILE LINE TOO LONG",
/*76 */	"? DIMENSION ERROR",
/*77 */	"%% DIVISION BY ZERO",
/*78 */	"? EXPONENT REQUESTED FOR * OR $ FIELD",
/*79 */	"? FILE IS NOT RANDOM ACCESS",
/*80 */	"? FILE NEVER ESTABLISHED - REFERENCED",

/*81 */	"? FILE NOT FOUND BY RESTORE COMMAND",
/*82 */	"? FILE %s ON MORE THAN ONE CHANNEL",
/*83 */	"? FILE NOT IN CORRECT FORM", // UNUSED
/*84 */	"? FILE RECORD LENGTH OR TYPE DOES NOT MATCH",
/*85 */	"? IF END ASKED FOR UNREADABLE FILE",
/*86 */	"? ILLEGAL CHARACTER IN STRING",
/*87 */	"? ILLEGAL CHARACTER SEEN",
/*88 */	"? ILLEGAL FILENAME",
/*89 */	"? ILLEGAL LINE REFERENCE IN CHAIN",
/*90 */	"? IMPOSSIBLE VECTOR LENGTH",
/* the following error 91 originally ended with "PLEASE RETYPE LINE" */
/*91 */	"? INPUT DATA NOT IN CORRECT FORM--PLEASE RETYPE", // outside perror_()
/*92 */	"? INSTR ARGUMENT OUT OF BOUNDS",
/*93 */	"? LEFT$ ARGUMENT OUT OF BOUNDS",
/*94 */	"? LINE NUMBER OUT OF BOUNDS",
/*95 */	"%% LOG OF NEGATIVE NUMBER",
/*96 */	"%% LOG OF ZERO",
/*97 */	"%% MAGNITUDE OF SIN OR COS TOO LARGE TO BE SIGNIFICANT",
/*98 */	"? MARGIN  OUT OF BOUNDS", // double space checked

/*99 */	"? MARGIN TOO SMALL",
/*100*/	"? MID$ ARGUMENT OUT OF BOUNDS",
/* the following error 101 originally had SEQUENTIAL instead of SEQ. */
/*101*/	"? MIXED RANDOM & SEQ. ACCESS",
/*102*/	"? MIXED READ#/INPUT#",
/*103*/	"? MIXED WRITE#/PRINT#",
/*104*/	"? NEGATIVE STRING LENGTH",
/* the following error 105 used FIELD instead of FIELDS */
/*105*/	"? NO FIELDS IN IMAGE",	// tested
/*106*/	"? NO ROOM FOR STRING",
/*107*/	"? NO SUCH LINE IN RUN (NH) OR CHAIN",
/*108*/	"? NOT ENOUGH -- ADD MORE", // UNUSED (??)
/*109*/	"? ON EVALUATED OUT OF RANGE",
/*110*/	"? OUT OF DATA",
/*111*/	"? OUTPUT ITEM TOO LONG FOR LINE",
/*112*/	"? OUTPUT LINE > 132 CHARACTERS",
/*113*/	"? OUTPUT STRING LENGTH > RECORD LENGTH",
/*114*/	"%% OVERFLOW",

/*115*/	"%% OVERFLOW IN EXP",
/*116*/	"? PAGE LENGTH OUT OF BOUNDS",
/*117*/	"? QUOTA EXCEEDED OR BLOCK NO. TOO LARGE ON OUTPUT DEVICE", // UNUSED
/*118*/	"? RETURN BEFORE GOSUB",
/*119*/	"? RIGHT$ ARGUMENT OUT OF BOUNDS",
/*120*/	"? SET ARGUMENT OUT OF BOUNDS",
/*121*/	"%% SINGULAR MATRIX INVERTED",
/*122*/	"? SPACE$ ARGUMENT OUT OF BOUNDS",
/*123*/	"%% SQRT OF NEGATIVE NUMBER",
/*124*/	"? STRING FORMULA > 132 CHARACTERS",
/*125*/	"? STRING RECORD LENGTH > 132 OR < 1",	    // see 56
/*126*/	"? SUBROUTINE OR FUNCTION CALLS ITSELF",
/*127*/	"%% TAN OF PI/2 OR COTAN OF ZERO",
/* The following error 128 had a space between ELEMENTS and -- */
/*128*/	"? TOO MANY ELEMENTS-- RETYPE LINE", // outside perror_() 

/*129*/	"%% UNDERFLOW IN EXP",
/*130*/	"%% UNDERFLOW",
/*131*/	"? VAL ARGUMENT NOT IN CORRECT FORM",
/*132*/	"%% ZERO TO A NEGATIVE POWER",

/* MONITOR ERRORS (estracted from section 4 of the NGZB-D manual)
 * -- NOT USED -- */

/*133*/	"",
/*134*/	"",
/*135*/	"",
/*136*/	"",
/*137*/	"",
/*138*/ "",
/*139*/ "",
/*140*/	"",
/*141*/ "",
/*142*/ "",
/*143*/	"",
/*144*/	"",
/*145*/	"",
/*146*/	"",
/*147*/	"",
/*148*/	"",
/*149*/	"",
/*150*/ "",
/*151*/ "",
/*152*/ "",
/*153*/ "",
/*154*/ "",
/*155*/ "",
/*156*/ "",
/*157*/ "",
/*158*/ "",
/*159*/ "",
/*160*/ "",
/*161*/ "",
/*162*/ "",
/*163*/ "",
/*164*/ "",
/*165*/ "",
/*166*/ "",
/*167*/ "",
/*168*/ "",
/*169*/ "",
/*170*/ "",
/*171*/ "",
/*172*/ "",
/*173*/	"",
/*174*/	"",
/*175*/	"",
/*176*/	"",
/*177*/	"",	
/*178*/	"",

/* error messages reported by the PDP-10 MONITOR and the BASIC interface
 * (version 17F) which don't appear on the DEC-20-LBMAA-A-D */

/*179*/ "? CHANNEL NUMBER IS <1 OR >9",		
/*180*/ "? LINE TOO LONG",		
/*181*/ "",		
/*182*/ "",		
/*183*/ "",
/*184*/ "",
/*185*/ "",
/*186*/ "",
/*187*/ "",
/*188*/ "",
/*189*/ "",

/* system error messages, peculiar to decb, in a DEC-10 fashion */

/*190*/ "? OUT OF MEMORY WHILE DIMENSIONING AN ARRAY", 		// memory
/*191*/ "? OUT OF MEMORY WHILE DEALING WITH VARIABLES", 	// memory
/*192*/ "? OUT OF MEMORY WHILE DEFINING DEF FN%c FUNCTION", 	// memory
/*193*/ "? OUT OF MEMORY WHILE STORING DATA STRINGS", 		// memory
/*194*/ "? OUT OF MEMORY WHILE STORING LINE %d", 		// memory
/*195*/ "? %s IS A DIRECTORY -- CANNOT EXECUTE",		// file
/*196*/ "? MISSING FILE NAME",					// file
/*197*/ "? CANNOT ACCESS FILE %s",				// file
/*198*/ "? OUT OF MEMORY FOR NESTED GOSUB",			// BASIC
/*199*/ "? THE PRAGMA STATEMENT MUST BE USED ONCE ONLY",	// BASIC
/*200*/ "? MISSING NAME FOR OPTION -N\n",			// option
/*201*/ "%% VALUE OUT OF BOUNDS FOR OPTION -%c: SETTING DEFAULT\n", // option
/*202*/ "? UNRECOGNIZED OPTION -%c\n",				// option
/*203*/ "? MISSING %sARGUMENT FOR OPTION -%c\n",		// option
/*204*/ "? RECURSION LIMIT VIOLATED",				// BASIC
/*205*/ "%% LINE NUMBER ALREADY REFERENCED",			// memory
/*206*/ "",
/*207*/ "",
/*208*/ "",
/*209*/ "",
/*210*/ "",
/*211*/ "",
/*212*/ "",
/*213*/ "",
/*214*/ "",
/*215*/ "",
/*216*/ "",
/*217*/ "",
/*218*/ "",
/*219*/ "",
/*220*/ "",
/*221*/ "",
/*222*/ "",
/*223*/ "",

/*L+1*/ ""					// last + 1
};

#define ERRLIM 224				// L + 1

