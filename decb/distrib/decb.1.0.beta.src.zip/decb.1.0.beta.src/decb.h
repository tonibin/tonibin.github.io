/* decb.h 
 * Copyleft (C) 2009-2014 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 27 November 2014
 *
 * This file is the general header, with calls to main default headers
 * and definition of main structures, prototypes and global variables
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * It's GPL! Good decb!
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stddef.h>
#include <sys/dir.h>
#include <dirent.h>
#include <sys/param.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <termios.h>
#include <fnmatch.h>
#include <stdarg.h>
#include <libgen.h>
#include "errors.h"
#include "tokens.h"

/* customizable values - use your printer values, if any */
#define DEFPAGEHEIGHT 54	// value of my printer

/* Hardwired version strings */
#define VERSION "1.0.beta"
#define AU "Antonio Maschio"		/* Author */
#define EM "tbin at libero dot it"  	/* Email */
#define CY "2009-2014"		  	/* Copyright Year(s) */

/* Hardwired constants */
#define TRUE  1
#define FALSE 0
#define NIL 0
#define SCREENLINE 143			// length of an input line
#define COMPSCR 144			// length of a c-string input line
#define FILELINE 143			// length of file input line (142+"\n")
#define COMPFIL 144			// length of a c-string file input line
#define TABSPACE 8			// tab characters in getString()
#define LIMIT 999			// decb's core extension chunk length
#define CHUNKS 120			// decb's chunks number
#define SCRLIM 72 			// screen limit 1�72
#define MAXSTRLEN 132			// maximum length of a string
#define COMPSTR 133			// maximum length of a C-string
#define MAXARGS 16			// max arguments for commands
#define FORLIM 256			// FOR limit
#define FNALIM 16			// DEFFN formulae arguments limit
#define DATLIM 99999			// DATA limit
#define STACKLIM 511			// recursion stack limit (FN self call)
#define TEMPVAR 24			// temp MAT var (don't change!)
#define ZONE 14				// width of printing zone
#define MINFF -1.7014118346E38		// greater negative real (-2^127)
#define INFF 1.7014118346E38	 	// greater positive real (2^127)
#define ZERO 1.46936793853E-39 		// smaller real not zero (2^-129)
#define HALFPI 1.57079632679		//  
#define SINCOSBOUND 1E8			// boundary for SIN and COS
#define EXPOVERFLOW 88.028		// limit for EXP exponent
#define MICRO 0.0000001			// rounding quantity for FOR/NEXT
#define PSTACK 256			// dimension of the inner RPN stack
#define CORELIM 100000 	 		// limit for invalid line number
#define STREAMS 	9		// max number of file channels
#define SEQ     	100		// sequential file id
#define RANDOM  	200		// random file id
#define NUMBER  	300		// random file number sub-id
#define STRING  	4000		// random file string sub-id
#define NUMRECLEN 	24		// default random number record length
#define STRRECLEN 	34		// default random string record length
#define FIRSTLEN 	8		// length of first random sector
#define NOUSE -1			// quote modes
#define QUOTE  1
#define NOQUOTE 0
#define MARGINDEF 72			// 1..72 = 72 characters
#define MARGINMAX 132			// 1..132 = 132 characters
#define MARGINMIN 7			// 1..7 = 7 characters (tested)
#define VREAD  1			// read/write modes
#define VWRITE 2
#define VINPUT 3
#define VPRINT 4
#define CREATED_VOID 99
#define PA_VOID 8			// number of separation lines in files
#define NUMID -127			// USING number id
#define STRID -126			// USING string id
#define CENTERED  10			// USING string output
#define LEFTJUST  20
#define RIGHTJUST 30
#define EXTENDED  40
#define FORMATLINE 64			// (arbitrary): output format = 64*4+1
#define SINGLE 10			// identifiers for DEF
#define MULTI  99
#define RESET 23			// --no-reset option values
#define NORESET 27
#define EXIT_STOP 2
#define LISTTAB 3			// value for LIST automated indenting
#define TERMINAT "A LINE TERMINATOR OR APOSTROPHE" 	// system strings
#define FFLFVT "A FF,LF,VT, OR CR"
#define EXT ".BAS"
#define THISHEADER "\n%-13s %-14s%-13s"
#define GREET "Notes:\n- to compile type \'make\' as user in decb\' source directory.\n- to install type \'make install\' as root after compiling.\n  (but I'm sure you know better than me what to do!)\n\n"
#define WELCOME "\nWelcome, user! I hope you\'ll like this program.\nHere\'s some information about it and its license...\n"

/* system struct entities */
/* DEF FN structure */
struct t_definition {
	int vars[LIMIT];	// variables as arguments holder 
				//    vars[0] holds variable number
	char* def;		// pointer to the single line DEF string
	int type;		// 1=single line, 2=multi line
	int start;		// start and end hold line numbers
	int end;		//    limits of the DEF FN multiline structure
	double res;		// result of a multiline structure
	char* lines[LIMIT];	// storing of the multilines structure
};
typedef struct t_definition Tdef;

/* DIM structure for numeric arrays */
struct t_array {
	int brow;		// base row and column define the memory usage
	int bcol;		///   and hold the declared dimension
	int row;		// row and col are used into calculation
	int col;		//    and hold the current dimension
	int type; 		// type 0=undeclared, 1=vector, 2=matrix
	double *elem;		// pointer to the array base
};
typedef struct t_array Tarray;

/* DIM structure for string arrays 
 * Note: decb implements only one dimension string arrays, but this structure
 * permits implementation of two dimensions arrays for possible future
 * extensions*/
struct ts_array {
	int brow;		// base row and column define the memory usage
	int bcol;
	int row;		// row and col are used into calculation
	int col;
	int type; 		// type 0=undeclared, 1=vector, 2=matrix
	char *elem;		// pointer to the array string
};
typedef struct ts_array TSarray;

/* stream structure for I/O channels */
struct t_iostream {
	/* general parameters */
	FILE * stream;		// file descriptor
	char ioname[COMPSTR];	// file name
	int isopen;		// file open flag
	int type;		// SEQ | RANDOM
	int mode;		// STRING | NUMBER (rand)
	int fcounter;		// printing position in the file (seq)
	int fprintn;		// flag TRUE | FALSE for printing CR
	int wayout;		// VREAD | VWRITE | CREATED_VOID (seq)
	int reclen;		// length of record (for seek advancing) (rand)
	int currseek;		// holds current pos for random files (rand)
	int randomaccessed;	// TRUE or FALSE; if FALSE, read line 0 (rand)
	int quote;		// QUOTE | NOQUOTE (seq)
	int margin;		// NOUSE | int from 1 to MARGIN (seq)
	int page;		// 0 | int (seq)
	int pagerow;		// current page in channel (1�page) (seq)
	int reader;		// NOUSE | VREAD  | VINPUT
	int writer;		// NOUSE | VWRITE | VPRINT
};
typedef struct t_iostream Tiostream;

/* USING structure for storing parameters of strings & numbers */
struct t_using {
	/* numbers */
	int ic;			// integer digits count
	int dc;			// decimals digits count
	int isInt;		// flag for integer (TRUE) or float
	int isExp;		// flag for Exponential
	int isMin;		// flag for minus at the end
	int isCom;		// flag for thousands separators
	char com;		// character for thousands separator
	int isDol;		// flag for preprinting the dollar sign
	char fill;		// character to be used for filler (' '|'*')
	int isZer;		// in case isInt is TRUE and |num| < 1.0
	/* strings */
	int len;		// string length
	int type;		// justification type: C,R,L,E
};
typedef struct t_using TUsing;

/* Functions prototypes */
/* USING statements */
void FWRITEUSINGSHARP(int flag, int ch) ;
void PRINTUSING(void) ;
void formatAnalyzer(char* BForm, char* list, int isWrite, int ch) ;
void printString(char* str, TUsing us, int ch) ;
void printFormattedNumber(double num, TUsing us, int ch) ;
int intLen(double num) ;
void outNum(double num, TUsing us, int ch) ;
int checkNames(int c, char* fname) ;
/* FILE and PRINT statements */
void FFILE(int isFiles, int l) ;
void setupName(char *fn, int *m, int *l);
int testEOF(int ch) ;
int getEOF(int ch) ;
void IFEND(void) ;
void FMARGIN(void) ;	
void FPAGE(void) ;
void FNOPAGE(void) ;
void FQUOTE(int quotemode) ;
void FWRITESHARP(int flag) ;
void fillGap(int ch, int actualIndex) ;
void callPrint(int ch, int marg, int flag, int *cnt);
void printContained(int ch, char* string, int margin);
void FWRITECOLON(void) ;
void FREADSHARP(int flag) ;
void FREADCOLON(void) ;
void FRESTORE(void) ;
void FAPPEND(void) ;
void FSCRATCH(void) ;
void FSET(void) ;
/* CHAIN and CHANGE statements */
void CHAIN(void) ;
void CHANGE(void) ;
/* MAT statements */
void MATbyK(int varr);
void MATTRN(int varr);
void matinvert(int varr, int var1) ;
void MATINV(int varr);
void MATIDN(int var);
void MATZER(int var, double op);
void MATsum(int varr, int var1, int var2, int op);
void MATmul(int varr, int var1, int var2);
void MATtype(void) ;
void matCopy(int dst, int src);
void matReadAssign(int var, int t, int m, int n);
void MATINPUT(void) ;
void MATREAD(void);
void MATPRINT(int ch);
/* DIM statements */
int isod(char *p);
int isaa(char *p) ;
int issaa(char *p) ;
void dimArray(int var, int T, int M, int N) ;
double getArrayVal(int var, int t, int m, int n) ;
void setArrayVal(int var, int t, int m, int n, double val);
void dimAssign(void) ;
void dimStrArray(int var, int T, int M, int N) ;
char *getArrayStr(int var, int t, int m, int n) ;
void setArrayStr(int var, int t, int m, int n, char* str);
void dimStrAssign(void) ;
void DIM(int l);
/* INPUT statements */
char *setINPUTarray(char *pos, double value) ;
char *setINPUTnum(char*pos,  double value) ;
void INPUT(void) ;
/* BASIC statements */
int isStrFunc(char* q) ;
double getRandom(void);
void DEF(int l) ;
void END(int s) ;
void FNEND(void) ;
void FOR(void);
void GOSUB(void);
void GOTO(void);
void IFTHEN(void);
void NEXT(void) ;
void ONGOTO(void) ;
void PRINT(int flag) ;
void RANDOMIZE(void) ;
void READ(void) ;
void RESTORE(void);
void RETURN(void);
void skipDEF(void) ;
/* LET statements */
int LET(void) ;
int assign(void) ;
void strAssign(char* e) ;
/* System parser statements */
char* strstroq(char *pl, char* pr);
char *strncpy_(char *dst, const char *src, int dw);
char *strncat_(char *dst, const char *src, int dw);
int sprintw(char *dest, int len, char* format, ...);
char *sec_alloc(size_t n);
char *SS(void) ;
double S(void) ;
double getFunc(void);
double getVal(void);
int priority(const int op) ;
int strRel(void);
/* System functions */
char *calcDEF(double* res) ;
char *getMonthString(void) ;
char *getString(void) ;
char *makechar(char* str) ;
char *spaces(int v);
void printSpacedMiniTokens(FILE *f, char *str);
double power(double base, double expon) ;
int check(char *sb, char *sc);
int exec(char* lpc) ;
int getDay(void) ;
int getHour(void) ;
int getMin(void) ;
int getMonth(void) ;
int getSec(void) ;
int getYear(void) ;
int in(char c, char d) ;
int isSingleDEF(char *d) ;
int storeSingleLineToCore(char* line) ;
int varCode(char* w) ;
struct tm *getTime(void) ;
void FAC(int ch) ;
void FCR(int ch) ;
void fillPage(int c) ;
void doExp(char *pos, double *base, int *exp) ;
int emitNUM(int ch, char minus, char *num, int flag, char *dest) ;
int printNUM(int ch, double num, int flag, char *dest) ;
void parse(char**m, char*B) ;
void popRUN(void) ;
void preParse(char**m) ;
void pushRUN(void) ;
void stripBlanks(char *src, char *dest) ;
void tokenize(char* q) ;
void turnToUpper(char *str) ;
/* BASIC Interface emulators */
int listingLen(void);
char *change(char *p, int conv[]);
void renum(char *mc[], int conv[]);
void RESEQUENCE(int newLine, int oldLine, int step);
void INSERTLINENUMBERS(void); // not a BASIC Interface emulator, I know...
void LIST(FILE *fd, int n1, int n2);
void OLD(void) ;
void RUN(void) ;
/* Error messaging */
void perror_(int errNum, int l, ...) ;
void sigquit(int sig);
void sigint(int sig);
/* Info messaging */
void printConditions(void) ;
void printExistence(void);
void printHelp(void) ;
void printVersion(void) ;
void printHelpBanner(void) ;
void printUsage(void) ;
void printWarranty(void) ;
int isARing(int num);


/* Variables indentifiers */
#define SIMPVAR     0 	// var A..Z
#define DOUBVAR     1 	// var A0..Z9
#define SIMPARR     2 	// var A()..Z()
#define DOUBARR     3 	// var A0()..Z9()
#define SIMPSTR    10 	// var A$..Z$
#define DOUBSTR    11 	// var A0$..Z9$
#define SIMPSTRARR 12 	// var A$()..Z$()
#define DOUBSTRARR 13 	// var A0$()..Z9$()
#define FUNCTION   20 	// function
#define INVALID   999 	// invalid code

/* Inspective macros 
 * isnum checks if var pointed by p is a numeric variable
 * isstr checks if var pointed by p is a string variable
 * varcheck is a wrapper for varCode checking type
 * isnm check if entity pointed by p is a number
 * ismo checks if p is a math operator
 * isro checks if p is a relational operator
 * isop checks if p is an operator (that is math, relational or logical)
 * iscs checks if p is a comma or a semicolon
 * isalfnum checks if p is valid character for a file name 
 * isanystring checks if p points to any string format
 * isanynumber checks if p points to any number format
 * isblanckcommatab checks if p points to aspace, tab or comma 
 * isdivider checks if p points to colon or slash (for multiple statements)*/
#define isnum(p) (varCode(p)<SIMPSTR)
#define isstr(p) ((varCode(p)>=SIMPSTR)&&(varCode(p)<FUNCTION))
#define varcheck(p,t) (varCode(p)==(t))
#define isnm(p) (isdigit(*(p)) || *(p)=='.' || *(p)=='-')
#define ismo(p) (*(p)=='+' || *(p)=='-' || *(p)=='*' || *(p)=='/' || *(p)=='^' || *(p)=='�')
#define islo(p) (*(p)=='�' || *(p)=='�' || *(p)=='�' || *(p)=='�' || *(p)=='�' || *(p)=='�' || *(p)=='�')
#define isro(p) (*(p)=='<'||*(p)=='>'||*(p)=='='||*(p)=='�'||*(p)=='!'||*(p)=='�')
#define isop(p) (ismo(p) || isro(p) || islo(p))
#define iscs(p) (*(p)==',' || *(p)==';')
#define isalfnum(p) (isalnum(p) || (p)=='_' || (p)=='?' || (p)=='*')
#define isanystring(p) (isstr(p) || issaa(p) || *p=='\"' || isStrFunc(p))
#define isanynumber(p) (isnum(p) || isnm(p))
#define isblankcommatab(p) (strchr((p),' ')||strchr((p),'\t')||strchr((p),','))
#define isdivider(p) (*(p)==':' || *(p)=='/')
#define addspace(X) if(*(X) && *(X)!=' ')fprintf(stdout," ")

/* Lotsa global variables! */
/* System variables */
char* _null_;			// for realloc
char filename[COMPSCR];
char longname[COMPSCR];
char fakename[COMPSCR];
struct stat statbuf;
char line[COMPSCR];
int isHeader=TRUE;
int isToList=FALSE;
int startList=0;
int endList=CORELIM;
int isReverse=FALSE;
int listTab=LISTTAB;
int isToInsert=FALSE;
int isToReseq=FALSE;
int isReseqSave=FALSE;
int isToLen=FALSE;
int isGrace=FALSE;
int isToReset=RESET;
int pragmaCalls=0;
int isDebug=FALSE;
int isRemPrint=FALSE;
int isInterrupt=FALSE;
int mback=0;
int PAGEHEIGHT=DEFPAGEHEIGHT;	// value of my printer
char sep=',';
static char* month[]=
{"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC" };
int isCap=FALSE;

/* Memory variables
 * l holds the current program line number
 * P is an integers-array holding variables contents 
 * PS is a character-pointers-array holding references to strings
 * startingLine holds user specified starting line (for RUN)
 * pad and sspad are temporary string buffers */
int l;
double P[LIMIT];
char* PS[LIMIT];
int startingLine = 0;
char sspad[COMPSTR], pad[COMPSTR], *PAD=pad, *MYPAD=sspad;
/* B is the general input buffer;
 * Note: in recursive RUNs, B must be an independent array for each
 * recursion; that's why parse() is built in such a way to receive a copy
 * of B, which is local to it, so that different Bs are passed to RUN, in
 * normal or chained RUNs
 * J is a general purpose buffer used in preParse()
 * F is a character-holder used by the blank stripper */
char B[COMPSCR], J[COMPSCR], F[2];
/* m is an array holding pointers to program lines 
 * Note: in recursive RUNs, m must be an independent array for each
 * recursion; that's why parse() is built in such a way to receive a copy
 * of m, which is local to it, so that different ms are passed to RUN, in
 * normal or chained RUNs
 * p is the main char pointer to the current buffer position
 * s and d are various char pointer helpers used into RUN 
 * fm is a flag mask of all file lines; if TRUE, the corresponding line
 * is marked as not available for GOTO/GOSUB 
 * lastLine holds END line number */ 
char *m[CHUNKS*LIMIT+10], *p,*s,*d;
int  fm[CHUNKS*LIMIT+10];
int lastLine=0;
/* pagerow is the current next printing row on the screen line  */
int pagerow=5; // don't change
/* parser variable - TRUE when an operator is expected */
int opturn=0;	// don't change!
/* the flag for exp overflow */
int isExpOF=FALSE;
/* the CHAIN flag - TRUE if into a program CHAIN - from second file on */
int isChain=FALSE;

/* DATA management
 * D is an array holding DATA numbers
 * DS is an array of pointer to char holding DATA strings
 * dc (data counter) yields current pointer to numeric data
 * dcs (data counter for strings) yields current pointer to string data
 * dataLimit is the total of DATA numbers found into the listing 
 * dataLimitS is the total od DATA strings found into the listing */
double D[DATLIM];
char* DS[DATLIM];
int dc=0, dcs=0;
int dataLimit=0, dataLimitS=0;

/* DEF FN management
 * fn holds the DEF FN definitions in a proper struct
 * isDefRun is TRUE during a Multiline DEF evaluation
 * isDefVar holds var code during a Multiline DEF evaluation 
 * isDefCalc flag is set into LET() if a correct assignment is done 
 * isDefFor is incremented into FOR() during a Multiline DEF evaluation 
 * isDefCount holds number of multiline DEFs currently open
 * FNXlist holds value of variables in the FN, to check a self call
 * FNXTOS holds last FN value */ 
Tdef fn[LIMIT];
int isDefRun, isDefVar, isDefCalc, isDefFor, isDefCount=0;
int FNXlist[LIMIT];
int FNXTOS=0;


/* GOSUB data management and storing
 * gosubStack holds the jump data for RETURN
 * gosubTOS is the pointer to gosubStack
 * GOSLIM is the limit of the recursive GOSUBs
 * Note: there's no mention to available jumps in DEC-10
 * isGOSUB is a flag to check if a jump out of a FOR..NEXT cycle is a GOSUB 
 * (not breaking the cycle) or a GOTO/IF..THEN (breaking the cycle) */
int gosubStack[LIMIT];
int gosubTOS = 0;
int lastGosub=-1;
int isGOSUB=FALSE;

/* FOR..NEXT data management 
 * forStack holds data for cycles
 * forAddr holds addresses of relative NEXT for each FOR statement
 * Pf holds flag for FOR index variables (TRUE = set by FOR)
 * forTOS is the pointer to forStack
 * forcount is a counter for nested FOR cycles */
double forStack[6*FORLIM+6];
int forAddr[CHUNKS*LIMIT+10];
int Pf[CHUNKS*LIMIT+10];
int forTOS = 0;
int forcount=0;

/* DIM arrays data management 
 * dim is the numerical array 
 * dimS is the string array */
Tarray dim[LIMIT];
TSarray dimS[LIMIT];

/* MAT variables management
 * detValue is a placeholder for DET (MAT INV determinant)
 * numValue is a placeholder for NUM (numeric MAT INPUT entries) 
 * Note: in the LCM BASIC, if used before any MAT INPUT statement, this 
 * function, either in 'variable' mode NUM or in pseudo-argument mode NUM(X),
 * returns the number -2.18953E-47, a value clearly in UNDERFLOW regime 
 * So, I set this value, coherently, to zero */
double detValue=0.0; 	
int numValue=0;

/* Timing variables 
 * tv is used for time calculations 
 * beginS is calculated at start for the TIM() function and the times
 * now contains seed for current number generator */
struct timeval tv;  
double beginS=-1.0, endS=0.0;
time_t now;

/* running-state backup arrays 
 * - lb for l (line numbers)
 * - sb for startingLine
 * - pb for printn
 * - cb for counter
 * - ftb for forTOS
 * - fcb for forcount
 * - nowb for the random generator */
#define RUNSTACK 512
int lb[RUNSTACK], sb[RUNSTACK], pb[RUNSTACK],cb[RUNSTACK];
int ftb[RUNSTACK], fcb[RUNSTACK];
int runTOS=0;
time_t nowb;

/* I/O variables 
 * channel contains the channel 0-9 data (0 = console) 
 * currChan yields current channel id (used into FILES) 
 * writeSeqStart and writeSeqStep contains data for WRITE# */
#define CONSOLE 0
Tiostream channel[STREAMS+2];		// channels 1-9 (ch. 0 is ignored)
int currChan=0;				// used into FILES
int writeSeqStart=1000;			// used into WRITE#
int writeSeqStep=10;			// used into WRITE#

/* Random number generator algorithm variables 
 * randDivi contains the divisor value
 * randSeed contains first seed (recalculated each time) */
unsigned int randSeed=27268;
unsigned int randDivi=32767;

/* end of decb.h */

