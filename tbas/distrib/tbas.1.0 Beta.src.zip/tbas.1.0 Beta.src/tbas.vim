" Vim syntax file
" Language:	tonibin's basic (tbas)
" Creator:	Antonio Maschio <tbin at libero dot it>
" Maintainer:	Antonio Maschio <tbin at libero dot it>
" Last updated: August 2014

" Based on Allan Kelly's BASIC vim file
" With the active help of Mike Soyka, Brett Stahlman and Christian Brabandt

" For version 5.x: Clear all syntax items
" For version 6.x: Quit when a syntax file was already loaded
if version < 600
  syntax clear
elseif exists("b:current_syntax")
  finish
endif

" specials
syn case ignore

" functions
syn match   tbasStatement "end"
syn keyword tbasFunction abs atn cos cot det exp int num rnd sin tan sgn len 
syn keyword tbasFunction log ln loge clog log10 sqr sqrt tim loc lof asc 
syn keyword tbasFunction instr pos mem length ascii ord ceiling
syn keyword tbasFunction acos acosec acosech acosh acot acoth asec asech csc
syn keyword tbasFunction asin asinh atan atanh atnh ceil cosec cosech cosh coth
syn keyword tbasFunction deg idiv div floor integer frac inf lgt mod pi rad 
syn keyword tbasFunction round rof fix sec sech sinh tanh ten acscsh
syn keyword tbasFunction max min sum vmax vmin vsum lastf lastchannel
syn keyword tbasFunction true false eps maybe cscs cscsh acscs acsc acsch csch
syn keyword tbasFunction degrees fp ip lgamma gamma radians shl shr
syn keyword tbasFunction and or not xor eqv imp nand nor exists val
syn keyword tbasFunction day year hour minute second cr freechannel
syn match   tbasFunction     "exec"
syn match   tbasFunction     "eval"
syn match   tbasFunction     "expr"
syn match   tbasStrFunction  "eval\$"
syn match   tbasStrFunction  "expr\$"
syn match   tbasStrFunction  "weekday\$"
syn match   tbasStrFunction  "space\$"
syn match   tbasStrFunction  "str\$"
syn match   tbasStrFunction  "left\$"
syn match   tbasStrFunction  "mid\$"
syn match   tbasStrFunction  "right\$"
syn match   tbasStrFunction  "chr\$"
syn match   tbasStrFunction  "cls\$"
syn match   tbasFunction     "clk"
syn match   tbasStrFunction  "clk\$"
syn match   tbasFunction     "date"
syn match   tbasStrFunction  "date\$"
syn match   tbasStrFunction  "dat\$"
syn match   tbasStrFunction  "upper\$"
syn match   tbasStrFunction  "lower\$"
syn match   tbasStrFunction  "spc\$"
syn match   tbasStrFunction  "seg\$"
syn match   tbasStrFunction  "input\$"
syn match   tbasStrFunction  "string\$"
syn match   tbasStrFunction  "trim\$"
syn match   tbasStrFunction  "lpad\$"
syn match   tbasStrFunction  "rpad\$"
syn match   tbasStrFunction  "rpt\$"
syn match   tbasStrFunction  "env\$"
syn match   tbasStrFunction  "dir\$"
syn match   tbasStrFunction  "format\$"
syn match   tbasStrFunction  "using\$"
syn match   tbasStrFunction  "inkey\$"
syn match   tbasStrFunction  "env\$"
syn match   tbasFunction     "month"
syn match   tbasStrFunction  "month\$"
syn match   tbasStrFunction  "num\$"
syn match   tbasStrFunction  "hexof\$"
syn match   tbasStrFunction  "octof\$"
syn match   tbasStrFunction  "binof\$"
syn match   tbasStrFunction  "hex\$"
syn match   tbasStrFunction  "oct\$"
syn match   tbasStrFunction  "bin\$"
syn match   tbasStrFunction  "rev\$"
syn match   tbasStrFunction  "program\$"
syn match   tbasStrFunction  "usr\$"
syn match   tbasStrFunction  "pipe\$"
syn match   tbasFunction     "fn[a-zA-Z]\+"
syn match   tbasWhen "err"
syn match   tbasWhen "err\$"
syn match   tbasWhen "esm"
syn match   tbasWhen "esm\$"
syn keyword tbasWhen nxl esl erl asl eln aln
syn match   tbasFunction     "end("me=s+3
syn match   tbasFunction     "end\s*#"
syn match   tbasFunction     "end\s*:"
syn match   tbasFunction     "end.+"me=s+3
syn match   tbasFunction     "more("me=s+4
syn match   tbasFunction     "more\s#"
syn match   tbasFunction     "more\s:"
syn match   tbasFunction     "more.*"me=s+4
syn match   tbasFunction     "eof(.*"me=s+3
syn keyword tbasFile scratch free

" escaping characters
syn match   tbasSpecChar display contained "\\\(x\x\+\|\o\{1,3}\|.\|$\)"

" facilities
syn keyword tbasTodo contained	TODO
syn match   tbasPragma "option.*"

" statements always without arguments or connective elements
syn keyword tbasStatement then return stop randomize fnend wait declare
syn keyword tbasStatement sub export call otherwise system dim dimension
syn keyword tbasStatement select case default erase redim locate color
syn keyword tbasStatement read let else change command abort clear cls
syn keyword tbasStatement swap errprint
syn keyword tbasLoops for to next by step exit loop while break copy in
syn keyword tbasFile  queue route chain pipe
syn keyword tbasWhen  jump handler use retry resume
syn region  tbasStatement    start="program[^\$]" end="$"
syn region  tbasStatement    start="title" end="$"
syn region  tbasStatement    start="_title" end="$"
syn match   tbasStrFunction  "command\$"


" color codes
syn keyword tbasString reverse adjust black gray grey red
syn keyword tbasString green yellow blue magenta cyan white
syn match tbasString "light\s*blue"
syn match tbasString "dark\s*green"
syn match tbasString "dark\s*gray"
syn match tbasString "dark\s*grey"

" statements with arguments, divided in standard and file arguments
" (thanks to Brett Stahlman and Christian Brabandt for their helpful tips)
syn match  tbasWhen 	  "continue\s*[$']"me=s+8
syn match  tbasLoops 	  "continue\s*[a-zA-Z][a-zA-Z]*"
syn match  tbasErr	  "cause\s*error"
syn match  tbasWhen 	  "on\s*error.*"
syn match  tbasWhen 	  "on\s*attention.*"
syn match  tbasWhen 	  "no\s*data.*"
syn match  tbasWhen 	  "end\s*when"
syn match  tbasWhen 	  "end\s*handler"
syn match  tbasStatement  "end\s*if"
syn match  tbasStatement  "end\s*select"
syn match  tbasStatement  "end\s*sub"
syn match  tbasStatement  "write"
syn match  tbasStatement  "print"
syn match  tbasStatement  "line\s*print"
syn match  tbasStatement  "lprint"
syn match  tbasStatement  "common"
syn match  tbasStatement  "common\s*all"
syn match  tbasStatement  "common\s*none"
syn match  tbasLoops 	  "end\s*while"
syn match  tbasLoops 	  "wend"
syn match  tbasWhen       "when\s*error\s*\d*\s*in"
syn match  tbasWhen 	  "when\s*error\s*\d*\s*use.*"
syn match  tbasWhen 	  "exit\s*handler"
syn match  tbasStatement  "else\s*if"
syn match  tbasStatement  "elseif"
syn match  tbasStatement  "as\s*integer"
syn match  tbasStatement  "as\s*real"
syn match  tbasStatement  "as\s*string"
syn match  tbasLoops 	  "do"
syn match  tbasLoops 	  "do\s*while"
syn match  tbasLoops 	  "dowhile"
syn match  tbasLoops 	  "do\s*until"
syn match  tbasLoops 	  "until"
syn match  tbasLoops 	  "dountil"
syn match  tbasLoops 	  "loop\s*until"
syn match  tbasLoops 	  "loopuntil"
syn match  tbasLoops 	  "loop\s*while"
syn match  tbasLoops 	  "loopwhile"
syn match  tbasStatement  "if\s*[-(a-z0-9\.\-]"me=s+2
syn match  tbasStatement  "if\s*["]"me=s+2
syn match  tbasStatement  "enter\s*\""me=s+5
syn match  tbasStatement  "enter\s*[a-zA-Z]"me=s+5
syn match  tbasStatement  "input\s*\""me=s+5
syn match  tbasStatement  "input\s*[a-zA-Z]"me=s+5
syn match  tbasStatement  "linput\s*\""me=s+6
syn match  tbasStatement  "linput\s*[a-zA-Z]"me=s+6
syn match  tbasStatement  "accept\s*\""me=s+6
syn match  tbasStatement  "accept\s*[a-zA-Z]"me=s+6
syn match  tbasStatement  "line\s*input\s*\""me=s+6
syn match  tbasStatement  "line\s*input\s*[a-zA-Z]"me=s+6
syn match  tbasStatement  "chain\s*\""me=e-1
syn match  tbasStatement  "data.*"me=s+4
syn match  tbasStatement  "def\s*FN[a-zA-Z]"
syn match  tbasStatement  "go\s*sub"
syn match  tbasStatement  "go\s*to"
syn match  tbasFile 	  "files\s*[a-zA-Z0-9\"]\+"me=s+5
syn match  tbasFile 	  "file\s*[#:]"me=e-1
syn match  tbasFile 	  "close\s*[#:]"me=e-1
syn match  tbasFile 	  "print\s*[#:]"me=e-1
syn match  tbasFile 	  "write\s*[#:]"me=e-1
syn match  tbasFile 	  "lread\s*[#:]"me=e-1
syn match  tbasFile 	  "input\s*[#:]"me=e-1
syn match  tbasFile 	  "linput\s*[#:]"me=e-1
syn match  tbasFile 	  "line\s*input\s*[#:]"me=e-1
syn match  tbasFile 	  "lprint\s*[#:]"me=e-1
syn match  tbasFile 	  "line\s*print\s*[#:]"me=e-1
syn match  tbasFile 	  "put\s*#"me=e-1
syn match  tbasFile 	  "get\s*#"me=e-1
syn match  tbasFile 	  "read\s*[#:]"me=e-1
syn match  tbasFile 	  "quote"
syn match  tbasFile 	  "quote\s*all"
syn match  tbasfile 	  "no\s*quote"
syn match  tbasfile 	  "no\s*page\s*all"
syn match  tbasfile 	  "no\s*pagenum"
syn match  tbasfile 	  "no\s*pagenum\s*all"
syn match  tbasFile 	  "margin"
syn match  tbasFile 	  "margin\s*all"
syn match  tbasfile 	  "no\s*margin"
syn match  tbasfile 	  "no\s*margin\s*all"
syn match  tbasFile 	  "page" 
syn match  tbasFile 	  "page\s*all" 
syn match  tbasFile 	  "no\s*page" 
syn match  tbasFile 	  "no\s*page\s*all" 
syn match  tbasFile 	  "pagenum" 
syn match  tbasFile 	  "pagenum\s*all" 
syn match  tbasFile 	  "no\s*pagenum" 
syn match  tbasFile 	  "no\s*pagenum\s*all" 
syn match  tbasFile 	  "update\s*#"me=e-1
syn match  tbasFile 	  "fillpage" 
syn match  tbasFile 	  "append\s*#"me=e-1 
syn match  tbasFile 	  "prepend\s*#"me=e-1 
syn match  tbasFile 	  "set\s*:"me=e-1
syn match  tbasStatement  "reset" 
syn match  tbasFile 	  "reset\s*[#:]"me=e-1
syn match  tbasStatement  "restore" 
syn match  tbasFile 	  "restore\s*[#:]"me=e-1
syn match  tbasFunction   "set\s*digits"

" matrix syntax
syn match  tbasMAT 	  "mat"
syn match  tbasMAT 	  "mat\s*print"
syn match  tbasMAT 	  "mat\s*write"
syn match  tbasFile 	  "mat\s*print\s*#"me=e-1
syn match  tbasFile 	  "mat\s*write\s*#"me=e-1
syn match  tbasMAT 	  "mat\s*input"
syn match  tbasMAT 	  "mat\s*read"
syn match  tbasMAT 	  "zer"
syn match  tbasMAT 	  "zero"
syn match  tbasMAT 	  "value"
syn match  tbasMAT 	  "identity"
syn match  tbasMAT 	  "transpose"
syn match  tbasMAT 	  "invert"
syn match  tbasMAT 	  "con"
syn match  tbasMAT 	  "unity"
syn match  tbasMAT 	  "idn"
syn match  tbasMAT 	  "trn"
syn match  tbasMAT 	  "nul\$"
syn match  tbasMAT 	  "null\$"
syn keyword tbasFunction  inv dot ubound lbound ldim udim
syn keyword tbasStatement const constant

" comments
" linear comment
syn region  tbasComment start="^\s*#"   end="$" contains=tbasTodo
" REM comment
syn region  tbasComment start="^\d*\s*rem"hs=e-2  end="$" contains=tbasTodo
syn region  tbasComment start=":\s*rem"hs=e-2  end="$" contains=tbasTodo
syn region  tbasComment start="^\s*rem"hs=e-2  end="$" contains=tbasTodo
" tick comment
syn region  tbasComment start="\'"   end="$" contains=tbasTodo
" tail comment
syn region  tbasComment start="^\s*@"   end="\%$"
" inner comment
syn region  tbasComment start="^\s*&"   end="^\s*&.*$"

" strings and USING formatters constants
syn region tbasString	start="\"" end="\"" contains=tbasSpecChar
syn region tbasString	start="^\s*\d*\s*:"hs=e end="$" contains=tbasLineNumber,tbasSpecChar
syn region tbasString	start="^\s*\d*\s*image"hs=e-4 end="$" contains=tbasLineNumber,tbasSpecChar 

" special
syn match  tbasString "<pa>"
syn match  tbasFloat     "\d*\.\d\+E*\d*"
syn match  tbasStatement "using\s*\d*"
syn match  tbasStatement "using\s*off"
syn match  tbasStatement "print\s*using\s*\d*"
syn match  tbasStatement "print\s*using\s*[a-zA-Z]\+[0-9]*\$"
syn region tbasStatement start="print\s*using\s*\"" end="\""
syn match  tbasStatement "write\s*using\s*\d*"
syn match  tbasStatement "write\s*using\s*[a-zA-Z]\+[0-9]*\$"
syn region tbasStatement start="write\s*using\s*\"" end="\""
syn match  tbasFile 	  "print\s*using\s*#\d*\s*,\s*\d*"
syn match  tbasFile 	  "print\s*using\s*#[0-9]\+\s*,\s*[a-zA-Z]\+[0-9]*\$"
syn region tbasFile 	  start="print\s*using\s*#[0-9]\+\s*,\s*\"" end="\""
syn match  tbasFile 	  "print\s*#\s*\d\+\s*,*\s*using\s*\d*"
syn match  tbasFile 	  "print\s*#\s*\d\+\s*,*\s*using\s*[a-zA-Z]\+[0-9]*\$"
syn region tbasFile 	  start="print\s*#\s*[0-9]\+\s*,*\s*using\s*\"" end="\""
syn match  tbasFile 	  "write\s*using\s*#\d*\s*,\s*\d*"
syn match  tbasFile 	  "write\s*using\s*#[0-9]\+\s*,\s*[a-zA-Z]\+[0-9]*\$"
syn region tbasFile 	  start="write\s*using\s*#[0-9]\+\s*,\s*\"" end="\""
syn match  tbasFile 	  "write\s*#\s*\d\+\s*,*\s*using\s*\d*"
syn match  tbasFile 	  "write\s*#\s*\d\+\s*,*\s*using\s*[a-zA-Z]\+[0-9]*\$"
syn region tbasFile 	  start="write\s*#\s*[0-9]\+\s*,*\s*using\s*\"" end="\""
syn match  tbasFile 	  "open.*"
syn match  tbasFile 	  "library.*"
" remainder is here, **after** rem
syn match  tbasFunction   "remainder"

" Define the default highlighting.
" For version 5.7 and earlier: only when not done already
" For version 5.8 and later: only when an item doesn't have highlighting yet
if version >= 508 || !exists("did_tbas_syntax_inits")
  if version < 508
    let did_tbas_syntax_inits = 1
    command -nargs=+ HiLink hi link <args>
  else
    command -nargs=+ HiLink hi def link <args>
  endif

  HiLink tbasLineNumber		Comment
  HiLink tbasStatement		Statement
  HiLink tbasFile		Special
  HiLink tbasString		String
  HiLink tbasSpecChar		String
  HiLink tbasComment		Comment
  HiLink tbasTodo		Todo
  HiLink tbasPragma		Todo
  HiLink tbasFunction		Function
  HiLink tbasStrFunction	String
  HiLink tbasMAT 		Function
  HiLink tbasMAT1 		Function
  HiLink tbasLoops 		PreProc
  HiLink tbasStrVar             String
  HiLink tbasErr		Error
  HiLink tbasWhen		Underlined
 

  delcommand HiLink
endif

let b:current_syntax = "tbas"
set ts=8
set nocin
set nosi
set columns=80

" vim: ts=8
