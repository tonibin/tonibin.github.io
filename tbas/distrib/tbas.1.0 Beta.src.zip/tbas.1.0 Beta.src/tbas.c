/* tbas.c 
 * tbas BASIC interpreter - Copyleft (C) 2015-2019 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 14 September 2019
 * 
 * This is tbas, a BASIC interpreter written in c99 for the UNIX world.
 * You must have gcc 4.X to compile (I suppose, though even 3.X may suffice).
 * 
 * This program is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) 
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with 
 * this program. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */
#include "tbas.h"	// catch-all header file

/******************************************************************************
 * The following routine is related to the INCLUDE statement
 ******************************************************************************/

/* INCLUDE()
 * perform the INCLUDE statement, that sets file argument as the standard
 * input 
 * Syntax:
 * INCLUDE <s>
 * where <s> is a file name. Conditions are:
 * - <s> must be an existent file;
 * when file is over (or in case file is empty), the default standard input
 * (from keyboard) is restored.
 * */
int INCLUDE(void) {
	FILE *fd;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);
	strncpy_(includename,SS(),COMPSCR);
	
	/* check if file exists */
	fd=fopen(includename,"r");
	if (!fd) return perror_(__LINE__,232,l);
	else fclose(fd);
	
	/* open channel[CONSOLE] as the default input */	
	CONSOLEIN=fopen(includename,"r");
	return TRUE;
}


/******************************************************************************
 * The following routines are related to the EXEC, SWAP and COPY statements
 ******************************************************************************/

/* COPY()
 * perform the COPY statement, that copies one array to another 
 * Syntax:
 * COPY <t1> TO <t2>
 * where <t> are two arrays. Conditions are:
 * - <t1> and <t2> must be consistent (both string or both numeric)
 * - any <t1> dimension must be equal or lower to the same dimension of <t2>
 * */
int COPY(void) {
	int var[1], type[1];
	int M[1], N[1], T[1];
	int i,j,in=0, col=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* start COPY */
	for (in=0; in<=1; in++) {
		int cs;
		forceArray=TRUE;
		cs=findDEC(p);
		var[in]=cs;
		p+=_len;
		type[in]=vn[cs].rettype;
		M[in]=dim[cs].row;
		N[in]=dim[cs].col;
		T[in]=dim[cs].type;
		if (bcomp(p,"TO")) p+=4;
		else if (!in) return perror_(__LINE__,35,l);
		forceArray=FALSE;
	}

	/* read column */
	if (bcomp(p,"IN")) {
		p+=4;
		col=(int)S();
	}

	/* check coherence */
	if (type[0]!=type[1]) return perror_(__LINE__,179,l);

	/* check dimensions */
	if (M[0]>M[1] || N[0]>N[1]) return perror_(__LINE__,181,l);
	if (T[0]>1 && T[1]<2) return perror_(__LINE__,181,l);
	if (col<0 || col>N[1]) return perror_(__LINE__,183,l);
	
	/* copy table to table */
	if (T[0]==2 && T[1]==2) for (i=0;i<=M[0];i++) for (j=0;j<=N[0];j++) {
		setArrayVal(var[1],T[1],i,j,getArrayVal(var[0],T[0],i,j));
	}
	/* copy vector to vector */
	else if (T[0]==1 && T[1]==1) for (i=0;i<=M[0];i++) {
		setArrayVal(var[1],T[1],i,0,getArrayVal(var[0],T[0],i,0));
	}
	/* copy vector to column in table */
	else if (T[0]==1 && T[1]==2) for (i=0;i<=M[0];i++) {
		setArrayVal(var[1],T[1],i,col,getArrayVal(var[0],T[0],i,0));
	}
	/* other cases are invalid (e.g. copy table to vector) */
	else return perror_(__LINE__,181,l);
	return TRUE;
}


/* SWAP()
 * perform the SWAP statement 
 * Syntax:
 * SWAP <nv1> <nv2>
 * SWAP <sv1> <sv2>
 * where <nv> and <sv> are respectively numerical and string variables 
 * or arrays elements */
int SWAP(void) {
	int var[2], isArr[2], type[2];
	int M[2], N[2], T[2];
	int in=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* start SWAP */
	for (in=0; in<2; in++) {
		int cs;
		isArr[in]=FALSE;
		type[in]=NUM;
		cs=findDEC(p);
		var[in]=cs, p+=_len;
		type[in]=vn[cs].rettype;
		if (*p=='(') isArr[in]=TRUE;

		/* numeric or string array */
		if (isArr[in]) {
			M[in]=0, N[in]=0, T[in]=1;
			if (*p=='(') p++;
			M[in]=(int)S();
			if (isEndOfStatement) return FALSE;
			if (*p==',') {
				p++;
				N[in]=(int)S();
				if (isEndOfStatement) return FALSE;
				T[in]=2;
			}
			p++; // skip )
		}
		if (*p==',' || *p==';') p++;
		else if (!in) return perror_(__LINE__,130,l);
	}

	/* check coherence */
	if (type[0]!=type[1]) return perror_(__LINE__,171,l);

	/* numeric world */
	if (type[0]!=STR) {
		double temp;
		/* swap var-var */
		if (!isArr[0] && !isArr[1]) {
			temp=P[var[0]];
			P[var[0]]=P[var[1]];
			P[var[1]]=temp;
		}
		/* swap var-array */
		else if (!isArr[0] && isArr[2]) {
			temp=P[var[0]];
			P[var[0]]=getArrayVal(var[1],T[1],M[1],N[1]);
			setArrayVal(var[1],T[1],M[1],N[1],temp);
		}
		/* swap array-var */
		else if (isArr[0] && !isArr[1]) {
			temp=getArrayVal(var[0],T[0],M[0],N[0]);
			setArrayVal(var[0],T[0],M[0],N[0],P[var[1]]);
			P[var[1]]=temp;
		}
		/* swap array-array */
		else {
			double temp0=getArrayVal(var[0],T[0],M[0],N[0]);
			double temp1=getArrayVal(var[1],T[1],M[1],N[1]);
			setArrayVal(var[0],T[0],M[0],N[0],temp1);
			setArrayVal(var[1],T[1],M[1],N[1],temp0);
		}
	}
	/* string world */
	else {
		char temp[COMPSTR];
		/* swap var-var */
		if (!isArr[0] && !isArr[1]) {
			strcpy(temp,PS[var[0]]);
			strcpy(PS[var[0]],PS[var[1]]);
			strcpy(PS[var[1]],temp);
		}
		/* swap var-array */
		else if (!isArr[0] && isArr[2]) {
			strcpy(temp,PS[var[0]]);
			strcpy(PS[var[0]],getArrayStr(var[1],T[1],M[1],N[1]));
			setArrayStr(var[1],T[1],M[1],N[1],temp);
		}
		/* swap array-var */
		else if (isArr[0] && !isArr[1]) {
			strcpy(temp,getArrayStr(var[0],T[0],M[0],N[0]));
			setArrayStr(var[0],T[0],M[0],N[0],PS[var[1]]);
			strcpy(PS[var[1]],temp);
		}
		/* swap array-array */
		else {
			char temp0[COMPSTR];
			char temp1[COMPSTR];
			strcpy(temp0,getArrayStr(var[0],T[0],M[0],N[0]));
			strcpy(temp1,getArrayStr(var[1],T[1],M[1],N[1]));
			setArrayStr(var[0],T[0],M[0],N[0],temp1);
			setArrayStr(var[1],T[1],M[1],N[1],temp0);
		}
	}
	return TRUE;
}


/* DOCALL
 * perform CALL, the calling of any user function as a procedure
 * It is of course transparent to procedures */
int DOCALL(void) {
	int ns, type, rettype;
	double numRes;
	char strRes[COMPSTR];
	/* check if statement is a SUB */
	ns=findSUB(p,&p,&type,&rettype);
	if (!ns) return perror_(__LINE__,230,l);
	/* execSUB() is called without checking the type */
	execSUB(ns,p,&numRes,strRes);
	return TRUE;
}


/* EXEC
 * perform the EXEC statement, that 'executes' a string expecting it is a 
 * BASIC statement that ends its duty on a single line 
 * Syntax:
 * EXEC <s1>, <s2>, ...
 * where <s> are any string values */
int EXEC(void) {
	char ex[COMPSTR], *pb;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* do for each string in the list */
	while (*p) {
		strncpy_(ex,SS(),COMPSTR);
		pb=p;
		parseLine(ex,0); // changes p!
		p=pb;
		if (*p==',' || *p==';') p++;
	}
	return TRUE;
}


/******************************************************************************
 * The following routines are related to the APPEND and PREPEND statements
 ******************************************************************************/

/* closePrepend()
 * close procedures opened by the PREPEND function, that is closing current
 * input file (the prepended text), copies on it all the lines of the original
 * file (the appended text) and removes the temporary file, reopening the
 * channel on the original file.
 * Called by FAPPEND(), FCLOSE(), END(), FSCRATCH() and its companions.
 * Also, resets the isPrepend flag.
 * ch: the channel on which to act the changes
 * System function for the PREPEND function */
int closePrepend(int ch) {
	FILE *f;
	char stamp[COMPSTR];

	/* assure the file is open */
	if (!channel[ch].isopen) return 80; //perror_(__LINE__,80,l);
	/* assures PREPEND is active */
	if (!channel[ch].isPrepend) return 0;

	/* queue text to current */
	f=fopen(channel[ch].ioname,"r");
	if (!f) return 151; // perror_(__LINE__,151,l); 
	while (fgets(stamp, MAXSTRLEN, f)) 
		fputs(stamp, channel[ch].stream);
	fclose(f);

	/* reassign and reset */
	fclose(channel[ch].stream);
	remove(channel[ch].ioname);
	rename(channel[ch].queuename,channel[ch].ioname);
	channel[ch].queuename[0]='\0';
	channel[ch].isPrepend=FALSE;
	channel[ch].stream=fopen(channel[ch].ioname,"a+");
	if (!channel[ch].stream) return 151; // perror_(__LINE__,151,l);
	return 0;
}


/* FAPPEND()
 * implementation of the APPEND statement for sequential files
 * the # (sign number) is not required
 * set file pointer to the end of file, so that subsequent writing operations 
 * are performed by adding text to the original file, not overwriting it */
int FAPPEND(void) {
	int ch, ern=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	do {
		/* sequential file */
		if (*p=='#') p++;
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		/* check if channel is valid */
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		/* assures PREPEND is closed */
		if (channel[ch].isPrepend) {
			ern=closePrepend(ch);
			if (ern>0) return perror_(__LINE__,ern,l);
		}
		/* check if file exists */
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		/* check if file is random, which results in an error*/
		if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
		/* check is file is read-only */
		if (channel[ch].isReadonly)
			return perror_(__LINE__,155,l,channel[ch].ioname);
		/* set file in write mode and move seek to end */
		channel[ch].wayout=VWRITE;
		fseek(channel[ch].stream,0,SEEK_END);
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}


/* FPREPEND()
 * perform the PREPEND statement, which is the contrary of the APPEND
 * statement, that is set writing text to the beginning of the file, until
 * a new state change
 * The PREPEND statement may be given once only at a time. */
int FPREPEND(void) {
	int ch;
	char stamp[COMPSTR];

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	do {
		/* sequential file */
		if (*p=='#') p++;
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		/* check if channel is valid */
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		/* assures PREPEND is not already active on this channel
		 * or print a warning and proceed with next attribution */
		if (channel[ch].isPrepend) {
			perror_(__LINE__,180,l,ch); // warning
			if (*p==',' || *p==';') p++;
			continue;
		}
		/* check if file exists */
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		/* check if file is random, which results in an error*/
		if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
		/* check is file is read-only */
		if (channel[ch].isReadonly)
			return perror_(__LINE__,155,l,channel[ch].ioname);
		/* set file in prepend mode */
		channel[ch].isPrepend=TRUE;
		/* build queue file name */
		sprintw(stamp,COMPSTR,"%0d_%0d%0d%0d",ch,\
				getHour(),getMin(),getSec());
		strncpy_(channel[ch].queuename,TEMPROUTE,COMPSTR);
		strncat_(channel[ch].queuename,stamp,COMPSTR);
		/* close current channels */
		fclose(channel[ch].stream);
		channel[ch].stream=fopen(channel[ch].queuename,"w+");
		if (!channel[ch].stream) return perror_(__LINE__,142,l);
		/* set file in write mode */
		channel[ch].wayout=VWRITE;
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}
	
	
/******************************************************************************
 * The following routines are related to the LIBRARY/LIBRARIES statements
 ******************************************************************************/


/* includeLibs()
 * add to the existing running program all libs from an external program, 
 * identified by its file name
 * unitname: contains the external program name.
 * Note: in the external unit, only SUBs and DEFs are loaded in the caller 
 * memory, and subsequently preParsed; all comments and root statements of the 
 * included file are discarded.
 * The preparsing is done only if LOAD returns 0 (which means success)
 * System function for the OPEN AS LIBRARY/LIBRARY functions */
void includeLibs(char *unitname) {
	int oldEndCore, status=TRUE;
	oldEndCore=endCore;
	
	/* load lines one by one starting from position after endCore 
	 * Note: new endCore value is set into LOAD() */
	status=LOAD(m,unitname,endCore,ONLY_SUBS);

	/* preParse new lines (to add SUBs and DEFS) 
	 * Note: endCore was updated into LOAD() */
	if (!status) preParse(m,oldEndCore,endCore);
}


/* OPENASLIBRARY()
 * perform the OPENASLIBRARY/LIBRARY statements with the following
 * syntax:
 *
 * [OPEN AS] LIBRARY "lib1", "lib2", ...
 *
 * where "lib1", "lib2"... are BASIC programs separated by comma or semicolon */
int OPENASLIBRARY(char *p) {
	char unitname[COMPSTR], *u=unitname, *pb;
	int c=0, ern=0;

	/* the using of LIBRARY in the interactive environment as
	 * a single command is forbidden */
	if (isSingleBASICCommand) return perror_(__LINE__,231,0);

	while (TRUE) {
		/* argument required */
		if (!*p) return perror_(__LINE__,125,l);
		if (isanystring(p)) {
			if (*p=='\"') {
				p++;
				while (*p && *p!='\"') *u++=*p++;
				if (*p=='\"') p++;
				*u='\0';
			}
			else {
				strncpy_(unitname,SS(),COMPSCR);
				if (isEndOfStatement) return FALSE;
			}
		}
		else return perror_(__LINE__,88,l);
		ern=setupName(unitname,&c,&c);
		if (ern>0) return perror_(__LINE__,ern,-1);
		pb=p;
		includeLibs(unitname);
		p=pb;
		if (*p==',' || *p==';') p++;
		else break;
	}
	return TRUE;
}


/******************************************************************************
 * The following routines define the CLEAR, COMMON, ERASE and REDIM statements
 ******************************************************************************/

/* CLS
 * Note: this command uses VT100 monitor codes that should apply to all 
 * monitors; [2J clears the entire screen (arg.=2), and the [H command 
 * reposition the cursor in the upper left corner of the screen. 
 * Note: the  character is the ESC code (CTRL-C + ESC in VIM) */ 
int CLS(void) {
	fprintf(stdout,"[2J");	// clear screen
	fprintf(stdout,"[H");		// reposition cursor
	fprintf(stdout,"[m");		// reset colors
	return TRUE;
}


/* getcolors()
 * return default color values for pre-imposed strings
 * sources from http://www.tayloredmktg.com/rgb/
 * BLACK      0,0,0
 * GRAY       190,190,190
 * DARKGRAY   49,79,79
 * RED        255,0,0
 * DARKGREEN  0,128,0
 * GREEN      50,205,50	     
 * YELLOW     255,255,0
 * BLUE       0,0,255
 * LIGHTBLUE  70,130,180
 * MAGENTA    255,0,255
 * CYAN       0,255,255
 * WHITE      255,255,255 
 * System function for the COLOR family words */
void getcolors(char *p, int *red, int *green, int *blue) {
	if (!strncasecmp_(p,"BLACK",5)) {
		*red=*green=*blue=0;
	}
	else if (!strncasecmp_(p,"GRAY",4)) {
		*red=*green=*blue=190;
	}
	else if (!strncasecmp_(p,"DARKGRAY",8)) {
		*red=49;
		*green=*blue=79;
	}
	else if (!strncasecmp_(p,"RED",3)) {
		*red=255;
		*green=*blue=0;
	}
	else if (!strncasecmp_(p,"DARKGREEN",9)) {
		*red=0;
		*green=128;
		*blue=0;
	}
	else if (!strncasecmp_(p,"GREEN",5)) {
		*red=50;
		*green=205;
		*blue=50;
	}
	else if (!strncasecmp_(p,"YELLOW",6)) {
		*red=*green=255;
		*blue=0;
	}
	else if (!strncasecmp_(p,"BLUE",4)) {
		*red=0;
		*green=0;
		*blue=255;
	}
	else if (!strncasecmp_(p,"LIGHTBLUE",9)) {
		*red=70;
		*green=130;
		*blue=180;
	}
	else if (!strncasecmp_(p,"MAGENTA",7)) {
		*red=255;
		*green=0;
		*blue=255;
	}
	else if (!strncasecmp_(p,"CYAN",4)) {
		*red=0;
		*green=*blue=255;
	}
	else if (!strncasecmp_(p,"WHITE",5)) {
		*red=*green=*blue=255;
	}
}


/* COLOR */
int COLOR(void) {
	char output [COMPSTR];
	/* no arguments: reset color */
	if (!*p) {
		fprintf(stdout,"[0m"); // reset code
		return TRUE;
	}
	else if (!strncasecmp_(p,"REVERSE",7)) {
		fprintf(stdout,"[7m");
		return TRUE;
	}
	else if (!strncasecmp_(p,"ADJUST",6)) {
		fprintf(stdout,"[27m");
		return TRUE;
	}
	/* string colors */
	else if (isalpha(*p)) {
		getcolors(p,&red,&green,&blue);
	}
	/* direct RGB values */	
	else {
		red=(int)S();
		if (isEndOfStatement) return FALSE;
		if (*p!=',') return perror_(__LINE__,43,l);
		else p++;
		green=(int)S();
		if (isEndOfStatement) return FALSE;
		if (*p!=',') return perror_(__LINE__,43,l);
		else p++;
		blue=(int)S();
		if (isEndOfStatement) return FALSE;
		/* check values */
		if (red<0) red=0; 
		if (red>255) red=255;
		if (green<0) green=0; 
		if (green>255) green=255;
		if (blue<0) blue=0; 
		if (blue>255) blue=255;
	}
	/* build coloring string */
	sprintw(output,COMPSTR,"[38;2;%d;%d;%dm",red,green,blue);
	/* print string (by resetting before) */
	fprintf(stdout,"[0m"); // reset code
	fprintf(stdout,"%s",output);
	return TRUE;
}


/* LOCATE 
 * set the screen coordinates, according to the following syntax:
 *
 * LOCATE row, col
 *
 * LOCATE col
 *
 * Note: this command resets values automatically if lower than one */ 
int LOCATE(void) {
	int te;
	/* no arguments */
	if (!*p) {
		valrow=1;
		valcol=1;
		return TRUE;
	}
	if (*p=='(') p++;
	te=(int)S();
	if (isEndOfStatement) return FALSE;
	if (*p==',' || *p==';') {
		p++;
		valrow=te;
		valcol=(int)S();
		if (isEndOfStatement) return FALSE;
	}
	/* in case one argument only is given, the value is the column
	 * retaining previous row value */
	else valcol=te;	
	if (*p==')') p++;
	if (valrow<1) valrow=1;
	if (valcol<1) valcol=1;
	fprintf(stdout,"\x1b[%d;%dH", valrow, valcol);
	return TRUE;
}


/* TCLEAR() 
 * perform the CLEAR statement, to clear the screen. 
 * Note: the 'clear' statement for the UNIX terminal depends on the terminfo 
 * or termcap database, and searches into the environment for the terminal 
 * type, in order to deduce how to clear the screen, but this is done 
 * implicitly, and thus tbas does not take in account any other action. */
int TCLEAR(void) {
	system("clear");
	return TRUE;
}
	

/* TCOMMON() 
 * perform the COMMON statement, to pass variables to a chained program,
 * according to the following syntax:
 * 
 * COMMON A7,name$,C22,Days(),Extract$
 * to pass only variables in the list
 * 
 * COMMON ALL
 * to pass all variables;
 *
 * COMMON NONE
 * to pass no variables;
 *
 * Note: open-close parentheses () indicate arrays. */
int TCOMMON(void) {
	int i=0, done=FALSE, cn;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* ALL case, equivalent to OPTION RESET OFF */
	if (!strncasecmp_(p,"ALL",3)) {
		p+=3;
		isCommon=FALSE;
		isToReset=FALSE;
		return TRUE;
	}
	/* NONE case, equivalent to OPTION RESET ON */
	else if ((cn=recog(2,p,"NONE","CLEAR"))) {
		p+=cn;
		/* As a safety measure, the isCommon flag is reset */
		for(i=0; i<VLIMIT;i++) vn[i].isCommon=FALSE;
		isCommon=FALSE;
		isToReset=TRUE;
		return TRUE;
	}
	/* list case */
	else while (*p) {
		char name[COMPSTR], *nn=name;
		isCommon=TRUE;
		/* advance to next, discarding separators */
		if (*p==',' || *p==';') p++;
		if (isbeginnamechar(p)){
			while (isnamechar(p)) *nn++=*p++;
			*nn='\0';
		}
		else return perror_(__LINE__,35,l);
		i=1;
		done=FALSE;
		while (i<=decCount) {
			/* variable name found */
			if (!strncmp(name,vn[i].name,COMPSTR)) {
				if (*p=='(' && *(p+1)==')') {
					/* if () is found: array*/
					if(!vn[i].isArr) return perror_(__LINE__,34,l);
					p+=2;
				}
				/* if () is not found: no array*/
				else if (vn[i].isArr) return perror_(__LINE__,34,l); 
				vn[i].isCommon=done=TRUE;
				break;
			}
			/* erase the Common property in all other cases 
			 * Note: I check against not-TRUE because isCommon
			 * may be uninitialized...*/
			else if (vn[i].isCommon!=TRUE) vn[i].isCommon=FALSE;
			i++;
			
		}
		/* if variable was not found, issue an error*/
		if (!done) return perror_(__LINE__,170,l);
		isToReset=FALSE;
	}
	return TRUE;
}


/* ERASE()
 * perform the ERASE statement, to erase arrays and variables from memory, 
 * with the following syntax:
 *
 * ERASE <var>, <var>, .
 * 
 * Its general action is to erase references for variables and arrays, 
 * free arrays memory and set strings and numbers to null. */
int ERASE(void) {
	int arr=0, type=0, i=decCount;
	char name[COMPSTR], *n=name;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get DEC name */
	while (isnamechar(p)) *n++=*p++;
	if (*p=='%') *n++=*p++;
	else if (*p=='$') *n++=*p++;
	*n='\0';

	/* search DEC item */
	while (i>0) {	// search all variables
		if (vn[i].name!=NIL && !strcmp(vn[i].name,name)) break;
		i--;
	}

	/* if not found is a wrong ERASE */
	if (i<=0) return perror_(__LINE__,42,l);

	/* erase DECLARED */
	type=vn[i].rettype;
	vn[i].rettype=0;
	arr=vn[i].isArr;
	vn[i].isArr=0;
	vn[i].isInt=0;
	vn[i].isCommon=FALSE;

	/* debug features */
	if (isDebug) {
		if (isInvDebug) fprintf(stdout,INVCOLOR);
		fprintf(stdout,"Erased %s [%d] %s\n",arr?"array":vn[i].isConst?"const":"variable", i,\
				vn[i].name!=NIL?vn[i].name:"obj.");
		if (isInvDebug) fprintf(stdout,RESETCOLOR);
	}

	/* task is done for DECLARE variables; reset memory */
	if (!arr) {
		if (type==NUM) P[i]=0.0;
		else if (type==STR) PS[i][0]='\0';
	}
	/* free array memory and reset array pointers */
	else if (arr && type==NUM) {
		if (dim[i].elem!=NIL) {
			free(dim[i].elem);
			dim[i].elem=NIL;
		}
		dim[i].type=dim[i].brow=dim[i].bcol=0;
		dim[i].row=dim[i].col=0;
	}
	else if (arr && type==STR){
		if (dimS[i].elem!=NIL) {
			free(dimS[i].elem);
			dimS[i].elem=NIL;
		}
		dimS[i].type=dimS[i].brow=dimS[i].bcol=0;
		dimS[i].row=dimS[i].col=0;
	}

	/* get rid of it in the vn array by putting a fake name in it */
	strncpy_(vn[i].name,"*",2);

	if (!strncasecmp_(p,"()",2)) p+=2;

	/* repeat for other variables */
	if (*p==',' || *p==';') {
		p++;
		ERASE();
	}
	return TRUE;
}


/* REDIM()
 * perform the REDIM statement, to redimension existing arrays, with the
 * following syntax:
 *
 * REDIM <arr>(newM,newN),<arr>(newM,newN),...
 * 
 * REDIM redefines memory for existing arrays with conservation of memory. 
 * Note: if the new row and col values determine a space which can be contained 
 * in the original array space (brow and bcol), a simple redefinition of row 
 * and col is done. If the new row and col determine a space which is larger 
 * that the existing space, a new space is created, the old space is copied in 
 * the new space, the array is completely redefined (brow, bcol, row and col 
 * are all set to new values), and it appears as if it was created as such from
 * the start; in this last case only, the original space is freed. */
int REDIM(void) {
	int cs, type=NUM, var=0;
	int M=0,N=0,T=1, total=0, newtotal=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get variable id */
	if ((cs=findDEC(p)) && _arr) var=cs, p+=_len, type=_rettype;
	else return perror_(__LINE__,42,l);

	/* get new dimensions M and N (required!) */
	if (*p=='(') {
		p++;
		M=(int)S();
		if (isEndOfStatement) return FALSE;
		if (*p==',') {
			p++;
			N=(int)S();
			if (isEndOfStatement) return FALSE;
			T=2;
		}
	}
	else return perror_(__LINE__,35,l);
	
	/* check if the required space can be contained in the existing space, 
	 * and if not create a new space, both for vectors and matrices, both 
	 * for the numerical and the strings worlds */
	/* numerical arrays */
	if (type==NUM) {
		if (dim[var].type==1) {
			newtotal=sizeof(double)*((M+1)*2+1);
			total=sizeof(double)*((dim[var].row+1)*2+1);
		}
		else if (dim[var].type==2) {
			newtotal=sizeof(double)*((M+1)*(N+1)+1);
			total=sizeof(double)*((dim[var].brow+1)*(dim[var].bcol+1)+1);
		}
		/* space is not sufficient */
		if (newtotal>total) {
			double *elemcopy=xmalloc((size_t)newtotal);
			if (!elemcopy) return perror_(__LINE__,190,l);
			memset(elemcopy, 0, newtotal);
			if (dim[var].elem!=NIL) {
				memcpy(elemcopy,dim[var].elem,total);
				free(dim[var].elem);
				dim[var].elem=NIL;
			}
			dim[var].elem=xmalloc((size_t)newtotal);
			if (!dim[var].elem) return perror_(__LINE__,190,l);
			memcpy(dim[var].elem,elemcopy,total);	
			dim[var].brow=M;
			dim[var].bcol=N;
			free(elemcopy);
		}
		/* re-attribute values */
		dim[var].row=M;
		dim[var].col=N;
		dim[var].type=T;
	}
	/* string arrays */
	else {
		if (dimS[var].type==1) {
			newtotal=sizeof(char)*((M+1)*COMPSTR+1);
			total=sizeof(char)*((dimS[var].brow+1)*COMPSTR+1);
		}
		else if (dimS[var].type==2) {
			newtotal=sizeof(char)*((M+1)*(N+1)*COMPSTR+1);
			total=sizeof(char)*((dimS[var].brow+1)*(dimS[var].bcol+1)*COMPSTR+1);
		}
		/* space is not sufficient */
		if (newtotal>total) {
			char *elemcopy=xmalloc((size_t)newtotal);
			if (!elemcopy) return perror_(__LINE__,190,l);
			memset(elemcopy, 0, newtotal);
			if (dimS[var].elem!=NIL) {
				memcpy(elemcopy,dimS[var].elem,total);
				free(dimS[var].elem);
				dimS[var].elem=NIL;
			}
			dimS[var].elem=xmalloc((size_t)newtotal);
			if (!dimS[var].elem) return perror_(__LINE__,190,l);
			memcpy(dimS[var].elem,elemcopy,total);	
			dimS[var].brow=M;
			dimS[var].bcol=N;
			free(elemcopy);
		}
		/* re-attribute values */
		dimS[var].row=M;
		dimS[var].col=N;
		dimS[var].type=T;
	}

	/* repeat for other variables */
	if (*p==',' || *p==';') {
		p++;
		REDIM();
	}
	return TRUE;
}


/******************************************************************************
 * The following routines define the QUEUE, ROUTE and LPRINT statements
 ******************************************************************************/

/* openRoute()
 * setup the routing channel for printing in a file and then send it to
 * the printer (with ROUTE or at the end of program) 
 * routefile is the file name to be open and setup in the routing channel
 * System function for the QUEUE and LPRINT statements */
int openRoute(void) {
	channel[ROUTECHANNEL].stream=fopen(routefile,"w+");
	if (!channel[ROUTECHANNEL].stream) // perror_(__LINE__,153,l);
		return FALSE;
	strncpy_(channel[ROUTECHANNEL].ioname,routefile,COMPSTR);
	channel[ROUTECHANNEL].type=SEQ;
	channel[ROUTECHANNEL].mode=NUMBER;
	channel[ROUTECHANNEL].fcounter=0;
	channel[ROUTECHANNEL].wayout=VWRITE;
	channel[ROUTECHANNEL].currseek=1;
	channel[ROUTECHANNEL].reclen=NUMRECLEN;
	channel[ROUTECHANNEL].randomaccessed=FALSE;
	channel[ROUTECHANNEL].quote=NOQUOTE;
	channel[ROUTECHANNEL].margin=MARGINDEF;
	channel[ROUTECHANNEL].page=0;
	channel[ROUTECHANNEL].pagerow=1;
	channel[ROUTECHANNEL].height=PAGEHEIGHT;
	channel[ROUTECHANNEL].pagenumber=FALSE;
	channel[ROUTECHANNEL].writer=NOUSE;
	channel[ROUTECHANNEL].reader=NOUSE;
	channel[ROUTECHANNEL].fprintn=1;
	return TRUE;
}


/* QUEUE 
 * perform the QUEUE statement, that queues all console output to a temporary
 * file rather than to screen from now on. Syntax:
 *
 * QUEUE
 * QUEUE "file_name"
 * 
 * If followed by nothing, QUEUE uses a standard temporary file name to store 
 * the printing, and this file will be deleted at the end.
 * If followed by a string, that 'string' is taken as the temporary file name; 
 * in this case the file is retained at the end of program. */
int QUEUE(void) {
	char stamp[COMPSTR];
	sprintw(stamp,COMPSTR,"_%0d%0d%0d",getHour(),getMin(),getSec());
	/* name given */
	if (*p) {
		strncpy_(routefile,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		fileStays=TRUE;
	}
	/* tempname */
	else {
		strncpy_(routefile,TEMPROUTE,COMPSTR);
		strncat_(routefile,stamp,COMPSTR);
		fileStays=FALSE;
	}
	if (!openRoute()) return perror_(__LINE__,153,l);
	isQueued=TRUE;
	return TRUE;
}


/* LPRINT()
 * perform the LPRINT/LINEPRINT statement, that temporary redirects the
 * output to a file, which will be sent to printer when ROUTE is executed
 * or at the end of execution by END(). Syntax is the very same of PRINT
 * It is the very same statement of PRINT, which is called accordingly */
int LPRINT(void) {
	char stamp[COMPSTR];
	sprintw(stamp,COMPSTR,"%0d%0d%0d",getHour(),getMin(),getSec());
	/* this is the first LPRINT statement */
	if (!isLPrintEnabled) {
		strncpy_(routefile,TEMPROUTE,COMPSTR);
		strncat_(routefile,stamp,COMPSTR);
		if (!openRoute()) return perror_(__LINE__,153,l);
		fileStays=FALSE;
		isLPrintEnabled=TRUE;
	}
	isLPrint=TRUE;
	PRINT(TRUE);
	return TRUE;
}


/* ROUTE()
 * perform the ROUTE statement, that sends the route file content to the 
 * default printer; this command cannot be executed before the QUEUE statement.
 * Notes: if fileStays is TRUE, do not remove the route file; if otherwise 
 * fileStays is FALSE, save the file to a secure position and update the
 * queueFileCount counter.
 * At the end, the QUEUE feature is disabled, and standard output is restored.
 * Note: for the sake of completeness, in END(), if for any reason, isQueue
 * is still TRUE at exit, the ROUTE() function is called again. */
int ROUTE(void) {
	char command[COMPSTR];
	if (!(isQueued+isLPrintEnabled)) return perror_(__LINE__,154,l);
	if (channel[ROUTECHANNEL].stream)
		fclose(channel[ROUTECHANNEL].stream);
	/* if ROUTE is open, send the file to printer */
	if (isRoute) {
		sprintw(command,COMPSTR,"cat %s | %s",routefile,ROUTESTRING);
		system(command);
	}
	/* or else, copy file to secure user file (in case of a temporary
	 * file created by the O.S.) */
	else if (!fileStays) {
		char com[COMPSTR];
		sprintw(com,COMPSTR,"cp -f %s %s%d.txt",routefile,TEMPROUTE,queueFileCount);
		system(com);
		queueFileCount++;
	}
	isQueued=FALSE;
	isLPrint=isLPrintEnabled=FALSE;
	if (!fileStays) remove(routefile);
	routefile[0]=channel[ROUTECHANNEL].ioname[0]='\0';
	return TRUE;
}


/******************************************************************************
 * The following routines define the GET#, PUT# and WAIT statements
 ******************************************************************************/

/* DOGET() 
 * perform the GET# statement, according to the following syntax:
 *
 * GET #N, M
 * GET #N, A$
 * 
 * If followed by a numerical variable, it will be instantiated with the ASCII 
 * value read in the range 0-255.
 * If followed by a string variable, this will be instantiated with the 
 * one-character string containing the ASCII character read.
 * Warning: characters in the range 128-255 are printed following the terminal 
 * coding, and this may vary on each computer. */
int DOGET(void) {
	int val=0, ch=0, cn, isNum=TRUE;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* sharp symbol is optional*/
	if (*p=='#') p++;

	/* get channel */
	if (isanynumber(p)) {
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		/* checks if channel is valid */
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		/* checks if file is open and RANDOM and in READ mode*/
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
		if (channel[ch].wayout!=VREAD) return perror_(__LINE__,72,l);
		if (feof(channel[ch].stream)) 
			return perror_(__LINE__,58,l,channel[ch].ioname);
	}
	else return perror_(__LINE__,65,l,makechar(p),"a valid channel id");

	/* discard comma or semicolon */
	if (*p==',' || *p==';') p++;

	/* determine output data */
	if (isanystring(p)) {
		if ((cn=findDEC(p)) && _rettype==STR && !_arr) p+=_len;
		else return perror_(__LINE__,42,l);
		isNum=FALSE;
	}
	else {
		if ((cn=findDEC(p)) && _rettype==NUM && !_arr) p+=_len;
		else return perror_(__LINE__,42,l);
	}	
	/* get value and put into proper variable */
	val=fgetc(channel[ch].stream);
	if (isNum) P[cn]=val;
	else PS[cn][0]=val, PS[cn][1]='\0';
	return TRUE;
}


/* DOPUT() 
 * perform the PUT# statement, putting to file the ASCII value of the variable 
 * following, according to the following syntax:
 *
 * PUT #N, A$
 * PUT #N, M
 * 
 * If followed by a string variable, convert the first character in the
 * string to its ASCII value and puts it to file;
 * otherwise, put the numerical value as ASCII code to file */
int DOPUT(void) {
	int ch=0, val=0;
	char str[COMPSTR];

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* sharp symbol is optional*/
	if (*p=='#') p++;

	/* get channel */
	if (isanynumber(p)) {
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		/* checks if channel is valid */
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		/* checks if file is open and RANDOM and in READ mode*/
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
		if (channel[ch].wayout!=VWRITE) return perror_(__LINE__,74,l);
	}
	else return perror_(__LINE__,65,l,makechar(p),"a validi channel id");

	/* discard comma or semicolon */
	if (*p==',' || *p==';') p++;

	/* determine output data */
	if (isanystring(p)) {
		strncpy_(str,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		val=str[0];
	}
	else {
		val=(int)S();
		if (isEndOfStatement) return FALSE;
	}
	/* put value onto stream */
	fputc(val,channel[ch].stream);
	return TRUE;
}


/* DOWAIT()
 * perform the WAIT statement, according to the following syntax:
 *
 * WAIT
 * WAIT N
 * 
 * If the argument is present, wait for that amount of seconds, otherwise
 * wait for 3 seconds. 
 * Note: the current implementation doesn't check for interrupts or flag,
 * while waiting, because it does not return control to the system */
int DOWAIT(void) {
	struct timeval wait_time;  
	time_t wait_now, wait_until;
	int howmuch=0;

	/* get user seconds; if nothing is specified, wait for 3 seconds */
	if (*p) {
		howmuch=(int)S();
		if (isEndOfStatement) return FALSE;
	}
	else howmuch=3;
	/* check value */
	if (howmuch<0) howmuch*=-1;
	if (howmuch>60) howmuch=60;
	/* get current instant */
	gettimeofday(&wait_time, NULL);
	wait_now=((double)wait_time.tv_sec);
	/* wait for the desired time */
	do {
		gettimeofday(&wait_time, NULL);
		wait_until=((double)wait_time.tv_sec);
	} while (wait_until<wait_now+howmuch);
	return TRUE;
}


/******************************************************************************
 * The following routines define the ON ERROR/NO DATA/ON ATTENTION statements 
 ******************************************************************************/

/* ONERROR()
 * implementation of the ON ERROR statement; in can be used in these ways:
 *
 * ON ERROR [GOTO|THEN] <label>
 * - This form traps all errors, redirecting to line with label <label>
 * 
 * ON ERROR <err> [GOTO|THEN] <label>
 * - This form traps error with code <err>, redirecting to line with label 
 *   <label>
 * 
 * ON ERROR
 * - This form disables the ON ERROR features
 * 
 * If ON ERROR is used more than once, only the most recent will be used.
 * ON ERROR can be used with 'WITH ERROR IN' and 'WITH ERROR USE' structures */
int ONERROR(void) {
	int val=0, trap=0;
	/* if ON ERROR is followed by nothing, disable the ON ERROR feature */
	if (!*p) {
		isOnErrorPos=isOnErrorTrap=errLine=errValue=0;
		return TRUE;
	}
	/* parse and discard GO TO / THEN that follows immediately */
	if (bcomp(p,"GOTO")) p+=6;
	else if (bthencomp(p)) {
		p+=5;
		if (isblank(*p)) p++;
	}

	/* there's an any-name label */
	if (isbeginnamechar(p)) val=getLabelAddr(p, &p);
	/* there's a number: is it a code number or an address? */
	else {
		char *pp=p;
		val=strtol(pp,&pp,10);
		/* there's something after the number: it is the code */
		if (*pp) {
			trap=val;
			/* parse and discard GO TO / THEN after the code */
			if (bcomp(pp,"GOTO")) pp+=6;
			else if (bthencomp(pp)) {
				pp+=5;
				if (isblank(*p)) p++;
			}
			val=getLabelAddr(pp,&pp);
			p=pp;
		}
		/* there's nothing after the number: re-get it as label */
		else val=getLabelAddr(p,&p);
	}
	/* enable the ON ERROR feature */
	if (val>=0) {
		isOnErrorPos=val;
		isOnErrorTrap=trap;
	}
	/* or else print error */
	else {
		isOnErrorPos=isOnErrorTrap=errLine=errValue=0;
		syserr_(__LINE__,61,l);
	}
	return TRUE;
}


/* ONATTENTION()
 * implementation of the ON ATTENTION statement, to intercept the user
 * interrupt and redirect program flow; in can be used in these ways:
 *
 * ON ATTENTION [GOTO|THEN] <label>
 * - This form traps interrupts redirecting to line with label <label>
 * 
 * ON ATTENTION
 * - This form disables the ON ATTENTION features
 * 
 * Note: ON ATTENTION makes no use of perror_(), and thus is does not activate
 * errValue and errLine; rather, it sets and uses arrValue and arrLine, for
 * it proper functioning; ON ATTENTION can be used with all the error-catching 
 * strategies, since it only cares to intercept the user interrupts */
int ONATTENTION(void) {
	int val=0;
	/* if ON ATTENTION is followed by nothing, disable the feature */
	if (!*p) {
		isOnAttentionPos=arrLine=arrValue=0;
		/* Restore trapping interrupts */
		signal(SIGHUP, sigint);
		signal(SIGINT, sigint);
		return TRUE;
	}
	/* parse and discard GO TO / THEN that follows immediately */
	if (bcomp(p,"GOTO")) p+=6;
	else if (bthencomp(p)) {
		p+=5;
		if (isblank(*p)) p++;
	}

	/* get destination label */
	val=getLabelAddr(p,&p);
	/* enable the ON ATTENTION feature */
	if (val>=0) {
		/* Restore trapping interrupts */
		signal(SIGHUP, sigtrap);
		signal(SIGINT, sigtrap);
		isOnAttentionPos=val;
	}
	/* or else print error */
	else syserr_(__LINE__,61,l);
	return TRUE;
}


/* JUMP()
 * implementation of the JUMP statement, to be used only within an ON ERROR, ON
 * ATTENTION or NO DATA structure, and provided the error that caused the jump 
 * to the handling section appeared. Syntax:
 *
 * JUMP <pl>
 * JUMP(<pl>)
 *
 * The jump is done to the BASIC file physical line number <pl>, not the label;
 * it was conceived to be used in conjunction with NXL() and ESM()/ERL(), 
 * thus the argument of JUMP must be a number */
int JUMP(void) {
	int val=0;
	
	/* argument required */
	if (!*p) syserr_(__LINE__,125,l);

	/* cannot use JUMP if ON ERROR/NO DATA features are both disabled 
	 * i.e. no error condition was raised */
	if (!(isOnErrorPos + isNoDataPos + isOnAttentionPos)) {
		errValue=errLine=arrValue=arrLine=0;
		syserr_(__LINE__,21,l);
	}
	/* get destination label */
	if (*p) val=(int)S(); // no getLabelAddr() here!
	if (isEndOfStatement) return FALSE;
	/* check if destination is legal and JUMP!*/
        if (val<1 || val > endCore) syserr_(__LINE__,61,l,val);
	else l=val-1;
	return TRUE;
}


/* RESUME()
 * implementation of the RESUME statement, to address execution to the line 
 * following the line that caused error; RESUME cannot be used out of an 
 * ON ERROR/ON ATTENTION feature and, in any case, not if no error/attention 
 * condition is active; this guarantees that since the ON ERROR/ON ATTENTION 
 * handler is not a confined code, as WHEN ERROR handlers are, the eventual 
 * execution of such lines in normal condition (that is with no error occurred
 * and anyway out of an ON ERROR segment) an error is printed, avoiding further
 * execution of improper code. */
int RESUME(void) {
	/* cannot use RESUME outside of a ON ERROR/ON ATTENTION structure */
	if (!(errValue+arrValue)) syserr_(__LINE__,13,l);
	if (!(isOnErrorPos+isOnAttentionPos)) syserr_(__LINE__,12,l);
	/* re-execute the failing line resetting error conditions */
	if (errValue) {
		l=errLine; // go to line following the error line!
		errLine=errValue=0;
	}
	else if (arrValue) {
		l=arrLine; // go to line following the interrupt line!
		arrLine=arrValue=0;
	}
	return TRUE;
}


/* NODATA()
 * implementation of the NO DATA statement, to catch the error condition of the
 * OUT OF DATA message (error 110); it can be used in these ways:
 *
 * NO DATA [GOTO|THEN] <label>
 * - This form traps error 110 redirecting to line with label <label>
 * 
 * NO DATA
 * -  This form disables the NO DATA features
 * 
 * Note: If NO DATA is used more than once, only the most recent will be used.
 * NO DATA can be used with 'WITH ERROR IN' and 'WITH ERROR USE' structures
 * Note: this command may be simulated by ON ERROR 110 GOTO <label>, but in
 * perror_() NO DATA has precedence over ON ERROR and is evaluated earlier. */
int NODATA(void) {
	int val=0;
	/* if NO DATA is followed by nothing, disable the NO DATA feature */
	if (!*p) {
		isNoDataPos=isOnErrorTrap=errLine=errValue=0;
		return TRUE;
	}
	/* parse and discard GO TO / THEN */
	if (!strncasecmp_(p,"GOTO",4)||(!strncasecmp_(p,"THEN",4))) p+=4;
	/* get destination label */
	val=getLabelAddr(p,&p);
	/* enable the NO DATA feature */
	if (val>=0) {
		isNoDataPos=val;
		isOnErrorTrap=110; // preset code
	}
	/* or else print error */
	else syserr_(__LINE__,61,l);
	return TRUE;
}


/******************************************************************************
 * The following routines define the WHEN ERROR IN/USE/RETRY and the WHEN
 * ERROR USE <handler>/HANDLER/END HANDLER statements.
 * These statements come from the OpenVMS and HP traditions, that implemented 
 * such statements in their BASIC language for their Eighties mainframe; 
 * they in turn owe the design of WHEN ERROR to the Dartmouth tradition evolved 
 * in the TRUE BASIC compiler devised by John Kemeny.
 ******************************************************************************/

/* WHENERROR()
 * activate the WHEN ERROR IN/WHEN ERROR USE <handler> features, that intercept
 * the error (in perror_() and get to go to the handler (USE section for WHEN
 * ERROR IN and the handler <handler> address for WHEN ERROR USE), handler
 * where the error is treated by user code. Syntax:
 *
 * WHEN ERROR IN 
 * WHEN ERROR USE <handler>
 *
 * The first form isolates the fragments of code between WHEN and USE, and if
 * an error arises, the USE section is called, to perform the resolution
 * statements. The second form set <handler> (which must exist) as the
 * resolution executor. */
int WHENERROR(void) {
	int i=0;
	char hname[COMPSTR], *h=hname;
	
	/* check if WHEN ERROR is inside the sub */
	if (isDefRun || isSubRun) syserr_(__LINE__,22,l);

	/* perform WHEN ERROR IN */
	if (!strncasecmp_(p,"IN",2)) {
		isWhenErrorInPos=l; 	// WHEN address
		isUsePos=whenAddr[l];	// USE address
		return TRUE;
	}

	/* if after ERROR there is 'USE', perform WHEN ERROR USE <handler>;
	 * otherwise it's rubbish text */
	if (bcomp(p,"USE")) p+=5;
	else syserr_(__LINE__,19,l);

	/* get WHEN ERROR USE handler name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p)) *h++=*p++;
		*h='\0';
	}
	else syserr_(__LINE__,11,l);

	/* check if WHEN ERROR USE is used into a SUB, which is not possible */
	if (XCount) {
		if (sn[XCount].start<l && sn[XCount].end>l)
			syserr_(__LINE__,23,l);
	}

	/* search handler in the handler database created by preParse
	 * and, if found, set public handler number */
	while (i<=handlerTOS) {
		if (handler[i].hname && !strcmp(handler[i].hname,hname)) break;
		i++;
	}

	/* if handler is not found print error */
	if (!i || i>handlerTOS) syserr_(__LINE__,20,l,hname);
	/* set parameters */
	else { 
		isHandlerNum=i;
		isWhenErrorUsePos=l;		// WHEN pos
		endWhenUse=whenAddr[l];		// END WHEN pos
	}
	return TRUE;
}


/* USE()
 * activate the USE handler section of the WHEN ERROR IN feature; 
 * in this handler, errors found are regularly printed and errValue and errLine 
 * are available as error codes, because they were instantiated by perror_() */
int USE(void) {
	/* cannot use USE outside of a WHEN ERROR IN structure */
	if (!isWhenErrorInPos) syserr_(__LINE__,18,l);
	/* no error occurred: go to END WHEN immediately */
	if (!errValue) l=whenAddr[l]-1;
	/* error: execute the USE section and store the END WHEN address
	 * for eventual future usage (the EXIT HANDLER statement) */
	else endWhenIn=whenAddr[l], isUseActive=TRUE;
	return TRUE;
}


/* EXITWHEN()
 * causes the immediate exit of the USE handler section of the WHEN ERROR IN
 * feature, jumping to END WHEN unconditionally */
int EXITWHEN(void) {
	/* cannot use EXITWHEN outside of a Use section */
	if (!isUseActive) syserr_(__LINE__,24,l);
	/* go to END WHEN immediately */
	l=endWhenIn-1;
	return TRUE;
}


/* RETRY()
 * address execution to the line that caused error, hopefully after the user
 * has treated the error in the USE section; 
 * RETRY cannot be used outside of a USE section (the only one with error 
 * codes enabled and not null) */
int RETRY(void) {
	/* cannot use RETRY outside of a USE handler/WHEN ERROR IN structure 
	 * or out of a HANDLER handler/WHEN ERROR USE structure*/
	if (!(isUseActive + isHandlerActive)) syserr_(__LINE__,17,l);
	/* re-execute the failing line resetting error conditions */
	l=errLine-1;
	errLine=errValue=0;
	isUseActive=isHandlerActive=0;
	return TRUE;
}


/* DOCONTINUE()
 * perform the CONTINUE statement (which works without argument) to resume
 * execution from line following the mistaken line; it works in a similar
 * way of RETRY, but the mistaken line is overridden.
 * Note: in case arguments are used, pass execution to EXIT, which controls
 * CONTINUE in the cycles statements */
int DOCONTINUE(void) {
	/* cannot use CONTINUE outside of a USE handler/WHEN ERROR IN structure 
	 * or out of a HANDLER handler/WHEN ERROR USE structure*/
	if (!*p && !(isUseActive + isHandlerActive)) syserr_(__LINE__,16,l);
	else if (!*p) {
		/* go to line following the error condition */
		l=errLine;
		errLine=errValue=0;
		isUseActive=isHandlerActive=0;
	}
	else EXIT(1);
	return TRUE;
}


/* HANDLER()
 * start a handler section of a WHEN ERROR USE structure; syntax:
 *
 * HANDLER <handler>
 *
 * where <handler> is any valid name; the resolution code is terminated by
 * END HANDLER; this function checks also if it's the active handler that calls 
 * the handler or if the normal flow is getting here; in such a case, jump 
 * safely to END HANDLER. */
int HANDLER(void) {
	/* check if HANDLER is inside the sub */
	if (isDefRun || isSubRun) syserr_(__LINE__,23,l);
	
	/* no error occurred or this is not the right handler: 
	 * go to END HANDLER immediately */
	if (!errValue || handler[isHandlerNum].pos!=l) { 
		l=handlerAddr[l]-1;
	}
	/* otherwise don't do nothing and enter the handler */
	else isHandlerActive=TRUE;
	return TRUE;
}


/* ENDHANDLER()
 * perform the END HANDLER statement to terminate a handler section of a 
 * WHEN ERROR USE structure; if it was a handler that called the handler 
 * (and not a normal program flow) jump back to the END WHEN line of the 
 * calling WHEN ERROR USE structure (that is the one responsible for the 
 * enabling of the current handler reference, the public handler number). */
int ENDHANDLER(void) {
	/* go to END WHEN in case handler was active */
	if (errValue) l=endWhenUse-1, isHandlerActive=FALSE;
	/* otherwise don't do nothing and let program flow after END HANDLER */
	return TRUE;
}


/* EXITHANDLER()
 * perform the EXIT HANDLER statement: in a WHEN ERROR structure, jump to the 
 * END WHEN, to exit the WHEN section; variables and flags are all reset 
 * accordingly */
int EXITHANDLER(void) {
	/* EXIT HANDLER as handler terminator in a WHEN ERROR USE structure */
	if (isWhenErrorUsePos) l=endWhenUse-1;
	/* EXIT HANDLER in a WHEN ERROR IN structure */
	else if (isWhenErrorInPos) l=endWhenIn-1, isHandlerActive=FALSE;
	else syserr_(__LINE__,15,l); // warning
	return TRUE;
}


/* ENDWHEN()
 * perform the END WHEN statement, to terminate a WHEN ERROR structure, 
 * resetting parameters and letting prosecuting the program execution 
 * starting from subsequent line */
int ENDWHEN(void) {
	char *pp;
	/* cannot terminate a WHEN ERROR structure outside of it */
	if (!(isWhenErrorInPos+isWhenErrorUsePos)) {
		errValue=errLine=0;
		syserr_(__LINE__,14,l);
	}
	/* reset data of the WHEN ERROR IN features */
	if (checkCommand(m[whenAddr[l]],"WHEN ERROR IN",&pp)) {
		isWhenErrorInPos=isUsePos=endWhenIn=0;
		isUseActive=FALSE;
	}
	/* reset data of the WHEN ERROR USE features */
	if (checkCommand(m[whenAddr[l]],"WHEN ERROR USE",&pp)) {
		isWhenErrorUsePos=isHandlerNum=endWhenUse=0;
		isHandlerActive=FALSE;
	}
	/* reset the error codes */
	errLine=errValue=0;
	return TRUE;
}


/* CAUSEERROR()
 * raise an error condition; it can be used with this syntax:
 *
 * CAUSE ERROR
 * - raise error condition 0 (a default error condition not related to BASIC)
 * 
 * CAUSE ERROR <n>
 * - raise error condition <n> 
 * 
 * If <n> is not a valid error number code, it is resized accordingly 
 * (no error message, here, it would be misinterpreted!) */
int CAUSEERROR(void) {
	int val=0;
	if (!isdigit(*p)) val=0;
	else val=strtol(p,&p,10);
	if (val < 0) val=0;
	if (val > ERRLIM) val=ERRLIM;
	perror_(__LINE__,val,ERRORCODE); // it MUST use perror_()!
	return TRUE;
}


/******************************************************************************
 * The following routines define the OPTION and COMMAND statements; The COMMAND 
 * statement is not a typical BASIC statement. The OPTION statement was 
 * instead implemented in various form in many BASIC dialects since Seventies.
 ******************************************************************************/


/* COMMAND()
 * read following string (in any format) and send it to system, with the
 * following syntax:
 *
 * COMMAND command
 * COMMAND(command)
 * 
 * Note: The argument may also be enclosed in parentheses.
 * Note: this is a potentially dangerous command, since no control is
 * made upon the string. To be used it with care. */
int COMMAND(void) {
	char sys[COMPSTR];
	int par=FALSE;
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	if (*p=='(') par=TRUE, p++;
	if (!isanystring(p)) return perror_(__LINE__,161,l);
	strncpy_(sys,SS(),COMPSTR);
	if (isEndOfStatement) return FALSE;
	if (*p==')') p++;
	else if (par) {
		return perror_(__LINE__,37,l);
	}
	system(sys);
	return TRUE;
}


/* OPTION()
 * evaluates some extra-BASIC option, those influencing the interpreter and
 * not the language;
 * This option is built to maximize the compatibility effect, showing no errors
 * in case of unrecognized option or unresolved/unfitting arguments
 *
 * OPTION				default value
 * --------------------------------------------------
 * OPTION ANGLE DEGREES|RADIANS         RADIANS
 * OPTION BASE 0|1                      0
 * OPTION CAPS ON|OFF*                  OFF 
 * OPTION CASE ON|OFF*                  OFF
 * OPTION COMPARISON RELATIVE|ABSOLUTE  RELATIVE
 * OPTION DEBUG ON|OFF*                 OFF
 * OPTION DIFFERENCE 0�n|OFF            6|OFF
 * OPTION ECHO ON|OFF*                  ON (for UNIX only)
 * OPTION ERRORSTREAM ON|OFF            OFF
 * OPTION EXPLICIT ON|OFF*              OFF
 * OPTION FORMAT AMERICAN|EUROPEAN      AMERICAN
 * OPTION HEADER ON|OFF                 OFF (caught also into preparse)
 * OPTION IGNOREEMPTYLINES ON|OFF       OFF
 * OPTION NULLS ON|OFF                  ON
 * OPTION PRECISION -1|0�16|OFF         OFF/-1
 * OPTION PROMPT ON|OFF*                ON
 * OPTION RAWPRINT ON|OFF*              OFF
 * OPTION RESET ON|OFF*                 ON
 * OPTION ROUTING ON|OFF*               ON
 * OPTION SPACING ON|OFF*               OFF
 * OPTION TAB 0�n|OFF                   ZONEBASE|OFF
 * OPTION TIMING ON|OFF                 OFF
 * OPTION VINTAGE ON|OFF                OFF  (caught also into preparse)
 * OPTION WARNINGS ON|OFF*              ON
 * OPTION ZERO 0�n|OFF*                 0|OFF
 * Note: OPTION with (*) can be enabled with the sole identifier (e.g. OPTION 
 * SPACING ON can be written also as OPTION SPACING, with obvious purposes)
 * Note: since the header should be written before any output, OPTION HEADER
 * and OPTION VINTAGE are caught into preParse() 
 * Note: OPTION is iterable */
int OPTION(void) {
	while (isblank(*p)) p++;
	/* OPTION [ANGLE] RADIANS|DEGREES 
	 * This option sets the default angle measure in radians or degrees.
	 * Default is RADIANS */
	if (!strncasecmp_(p,"ANGLE",5)) {
		p+=5;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"RADIANS",7)) isRadians=TRUE, p+=7;
		else if (!strncasecmp_(p,"DEGREES",7)) isRadians=FALSE, p+=7;
	}
	/* Corollaries to the previous statement: OPTION RADIANS and
	 * OPTION DEGREES are also valid as a bonus.*/
	else if (!strncasecmp_(p,"RADIANS",7)) isRadians=TRUE, p+=7;
	else if (!strncasecmp_(p,"DEGREES",7)) isRadians=FALSE, p+=7;
	/* OPTION BASE 0|1 
	 * This option sets the array index to 0 if OPTION BASE 0 is used, 
	 * to 1 if OPTION BASE 1 is used; in any case, matrices are not 
	 * affected, since they work always with index 1 (no change with 
	 * respect to decb).
	 * Default is 0 */
	else if (!strncasecmp_(p,"BASE",4)) {
		int u;
		p+=4;
		while (isblank(*p)) p++;
		u=(int)S();
		if (isEndOfStatement) return FALSE;
		if (!u) BASE=0;
		else BASE=1;
	}
	/* OPTION CAPS ON|OFF 
	 * This option sets all output to capital letters
	 * Neither the inner memory state of string nor the PRINT USING 
	 * statement nor the INPUT and MAT INPUT statements are affected by 
	 * this option (strings are input as-is); the effect is only related
	 * to the output, to what appears on the screen.
	 * Default is OFF */
	else if (!strncasecmp_(p,"CAPS",4)) {
		p+=4;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isCap=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isCap=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isCap=FALSE, p+=3;
	}
	/* OPTION CASE ON|OFF 
	 * This option sets case sensitiveness in case of string comparison.
	 * Default is OFF */
	else if (!strncasecmp_(p,"CASE",4)) {
		p+=4;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isCaseSensitive=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isCaseSensitive=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isCaseSensitive=FALSE, p+=3;
	}
	/* OPTION COMPARISON RELATIVE|ABSOLUTE 
	 * This option sets relative or absolute string comparison (relative
	 * considers trimming of spaces, while absolute considers strings
	 * as they are, trailing spaces included).
	 * Default is RELATIVE */
	else if (!strncasecmp_(p,"COMPARISON",10)) {
		p+=10;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"RELATIVE",8)) isComparison=RELATIVE;
		else if (!strncasecmp_(p,"ABSOLUTE",8)) isComparison=ABSOLUTE;
		p+=8;
	}
	/* OPTION DEBUG ON|OFF 
	 * This option enable/disable debug 
	 * Default is OFF */
	else if (!strncasecmp_(p,"DEBUG",5)) {
		p+=5;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isDebug=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isDebug=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isDebug=FALSE, p+=3;
	}
	/* OPTION DIFFERENCE <n>|OFF
	 * This option sets the quasi-equal feature (|= operator for numbers), 
	 * which evaluates TRUE the equivalence between two numbers whose
	 * difference is in absolute value lesser than 10^(-<n>)
	 * if OFF is used, the default value is set.
	 * <n> may be any numerical formula result, whose positive integer 
	 * part is used; a zero value cause the setting of the default value.
	 * Default is 1.0E-6)|OFF */
	else if (!strncasecmp_(p,"DIFFERENCE",10)) {
		int val;
		p+=10;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"OFF",3)) ZEROEQUAL=1.0E-6, p+=3;
		else {
			val=abs((int)S());
			if (isEndOfStatement) return FALSE;
			if (!val) ZEROEQUAL=1.0E-6;
			else ZEROEQUAL=pow(10,-val);
		}
	}
	/* OPTION ECHO ON|OFF 
	 * This option enable/disable echoing during input
	 * Default is ON 
	 * Note: for UNIX only */
	else if (!strncasecmp_(p,"ECHO",4)) {
		p+=4;
		while (isblank(*p)) p++;
		termiosHasOccurred=TRUE;
		if (!strncasecmp_(p,"OFF",2)) {
			modes.c_lflag &= ~ECHO;
			tcsetattr(0, 0, &modes);
			isEcho=FALSE;
			p+=3;
		}
		else if (!*p || !strncasecmp_(p,"ON",2)) {
			tcsetattr(0, 0, &savemodes);
			isEcho=TRUE;
			p+=2;
		}
	}
	else if (!strncasecmp_(p,"NOECHO",6)) {
			modes.c_lflag &= ~ECHO;
			tcsetattr(0, 0, &modes);
			isEcho=FALSE;
			p+=6;
	}
	/* OPTION EXPLICIT ON|OFF 
	 * This option enable/disable explicit declaration of variables
	 * Default is OFF */
	else if (!strncasecmp_(p,"EXPLICIT",8)) {
		p+=8;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isExplicit=TRUE;
		else if (!strncasecmp_(p,"OFF",3)) isExplicit=FALSE, p+=3;
		else if (!strncasecmp_(p,"ON",2)) isExplicit=TRUE, p+=2;
	}
	/* OPTION FORMAT AMERICAN|EUROPEAN 
	 * This option sets American format (dot for decimal separator,
	 * comma for triple unities - e.g. 123,456.789 for 123456.789) or
	 * European format (comma for decimal separator, tick for triple 
	 * unities - e.g. 123'456,789).
	 * Default is AMERICAN */
	else if (!strncasecmp_(p,"FORMAT",6)) {
		p+=6;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"AMERICAN",8)) 
			isAmericanFormat=TRUE;
		else if (!*p || !strncasecmp_(p,"EUROPEAN",8)) 
			isAmericanFormat=FALSE;
		p+=8;
	}
	/* OPTION HEADER is intercepted into preParse() 
	 * Here is the evaluation for the Interactive session */
	else if (!strncasecmp_(p,"HEADER",6)) {
		p+=6;
		while (isblank(*p)) p++;
		while (isblank(*p)) p++;
		if (!*p || !strcasecmp(p,"ON"))
			isHeader=TRUE;
		else if (!strcasecmp(p,"OFF"))
			isHeader=FALSE;
	}
	/* OPTION IGNOREEMPTYLINES ON|OFF 
	 * This option enable/disable the returning of empty lines
	 * for the statements LINEINPUT# and LINPUT# (only from file-reading)
	 * Default is OFF */
	else if (!strncasecmp_(p,"IGNOREEMPTYLINES",16)) {
		p+=16;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isIgnoreEmptyLines=TRUE;
		else if (!strncasecmp_(p,"OFF",3)) 
			isIgnoreEmptyLines=FALSE, p+=3;
		else if (!strncasecmp_(p,"ON",2)) 
			isIgnoreEmptyLines=TRUE, p+=2;
	}
	/* OPTION ERRORSTREAM ON|OFF 
	 * This option sets/unsets the output, redirecting it on the standard 
	 * error channel (stderr) if ON, or resetting the default output 
	 * (stdout) if OFF; Default is -1|OFF */
	else if (!strncasecmp_(p,"ERRORSTREAM",11)) {
		p+=11;
		while (isblank(*p)) p++;
		while (isblank(*p)) p++;
		if (!*p || !strcasecmp(p,"ON"))
			channel[CONSOLE].stream=stderr;
		else if (!strcasecmp(p,"OFF"))
			channel[CONSOLE].stream=stdout;
	}
	/* OPTION PRECISION <n> 
	 * This option sets numerical output precision for floats;
	 * if OFF is used, the default output is set ("automatic" display");
	 * <n> may be any numerical formula result, whose integer part is used;
	 * if PRECISION = -1 the default output is set ("automatic" display); 
	 * if PRECISION is in the range 0-16 then printNUM() is intercepted
	 * and print is made through fprintf() with the desired precision.
	 * Since emitNUM() is used as the actual printing routine, the numeric 
	 * output in length and counter updating is automatic. 
	 * Default is -1|OFF */
	else if (!strncasecmp_(p,"PRECISION",9)) {
		p+=9;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"OFF",3)) PRECISION=-1, p+=3;
		else SETDIGITS(); // it advances p
		if (isEndOfStatement) return FALSE;
	}
	/* OPTION NULLS ON|OFF 
	 * This option sets the 'real' empty string for the MAT PRINT/MAT
	 * WRITE statements.
	 * Default is OFF */
	else if (!strncasecmp_(p,"NULLS",5)) {
		p+=5;
		while (isblank(*p)) p++;
		if (!*p || *p==',') phantomString=FALSE;
		else if (!strncasecmp_(p,"ON",2)) phantomString=FALSE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) phantomString=TRUE, p+=3;
	}
	/* OPTION PROMPT ON|OFF 
	 * This option sets the displaying of the "?" prompt with INPUT and 
	 * MAT INPUT statements.
	 * Default is ON */
	else if (!strncasecmp_(p,"PROMPT",6)) {
		p+=6;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isPrompt=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isPrompt=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isPrompt=FALSE, p+=3;
	}
	/* OPTION RAWPRINT ON|OFF 
	 * This option sets the raw print style, in which the fcounter is not
	 * considered and thus the printing is as-is.
	 * Default is OFF */
	else if (!strncasecmp_(p,"RAWPRINT",8)) {
		p+=8;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isRawPrint=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isRawPrint=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) {
			isRawPrint=FALSE, p+=3;
			/* with OFF, reset parameters for normal output */
			channel[CONSOLE].fcounter=0;
			channel[CONSOLE].pagerow=1;
			channel[CONSOLE].page++;
		}
	}
	/* OPTION RESET ON|OFF 
	 * This option controls the resetting of memory between two 
	 * consecutive CHAIN calls.
	 * Default is RESET */
	else if (!strncasecmp_(p,"RESET",5)) {
		p+=5;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isToReset=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isToReset=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isToReset=FALSE, p+=3;
	} 
	/* OPTION ROUTING ON|OFF 
	 * This option sets the sending to printer of the QUEUE temporary file
	 * Default is ON */
	else if (!strncasecmp_(p,"ROUTING",7)) {
		p+=7;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isRoute=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isRoute=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isRoute=FALSE, p+=3;
	}
	/* OPTION SPACING ON|OFF 
	 * This option controls the printing of compact string matrices,
	 * setting the printing of a single space to separate the output.
	 * Default is OFF */
	else if (!strncasecmp_(p,"SPACING",7)) {
		p+=7;
		while (isblank(*p)) p++;
		if (!*p || *p==',') isSpacing=TRUE;
		else if (!strncasecmp_(p,"ON",2)) isSpacing=TRUE, p+=2;
		else if (!strncasecmp_(p,"OFF",3)) isSpacing=FALSE, p+=3;
	} 
	/* OPTION TAB <n>|OFF
	 * This option sets the tab value
	 * if OFF is used, the standard value is set.
	 * <n> may be any numerical formula result, whose positive integer 
	 * part is used; a zero value sets standard value.
	 * Default is 0|OFF */
	else if (!strncasecmp_(p,"TAB",3)) {
		int val;
		p+=3;
		while (isblank(*p)) p++;
		if (!strncasecmp_(p,"OFF",3)) ZONE=ZONEBASE, p+=3;
		else {
			val=(int)S();
			if (isEndOfStatement) return FALSE;
			if (!val) ZONE=ZONEBASE;
			else if (val>=MARGINMIN && val<=MARGINMAX) ZONE=val;
		}
	}
	/* OPTION TIMING ON|OFF 
	 * This option controls the printing of the execution time in seconds
	 * of the running program (or the total of the CHAINed programs)
	 * Default is OFF */
	else if (!strncasecmp_(p,"TIMING",6)) {
		p+=6;
		while (isblank(*p)) p++;
		if (!*p || !strcasecmp(p,"ON"))
			isTiming=TRUE;
		else if (!strcasecmp(p,"OFF"))
			isTiming=FALSE;
	} 
	/* OPTION VINTAGE is intercepted into preParse() */
	else if (!strncasecmp_(p,"VINTAGE",7)) {
		p+=7;
		while (isblank(*p)) p++;
		if (!*p || !strcasecmp(p,"ON"))
			doVintage(VINTAGESET);
		else if (!strcasecmp(p,"OFF"))
			doVintage(VINTAGERESET);
	} 
	/* OPTION WARNINGS ON|OFF */
	else if (!strncasecmp_(p,"WARNINGS",8)) {
		p+=8;
		while (isblank(*p)) p++;
		if (!*p || !strcasecmp(p,"ON"))
			warnState=ONWARN;
		else if (!strcasecmp(p,"OFF"))
			warnState=OFFWARN;
	} 
	/* OPTION ZERO <n>|OFF
	 * This option sets the zero feature, which prints as zero all numbers
	 * that as absolute value are lesser than 10^(-<n>), and enables the
	 * printing of a signed 'inf' in case the number is beyond INF or MINFF
	 * if OFF is used, the feature is disabled.
	 * if OPTION ZERO is used without parameters, use 1E-6 as default limit
	 * <n> may be any numerical formula result, whose positive integer 
	 * part is used; a zero value disables the feature.
	 * Default is 0|OFF */
	else if (!strncasecmp_(p,"ZERO",4)) {
		int val;
		p+=4;
		while (isblank(*p)) p++;
		if (!*p) ZEROLIM=1E-6,isZeroLim=TRUE;
		else if (!strncasecmp_(p,"OFF",3)) isZeroLim=FALSE, p+=3;
		else {
			val=-abs((int)S());
			if (isEndOfStatement) return FALSE;
			if (!val) isZeroLim=FALSE;
			else ZEROLIM=pow(10,val), isZeroLim=TRUE;
		}
	}
	/* print a warning advising the OPTION is not recognized */
	else perror_(__LINE__,79,l); // warning

	/* iterate */
	if (*p==',') {
		p++;
		OPTION();
	}
	/* remove every other instance of OPTION written in the list */
	if (!strncasecmp_(p,"OPTION",6)) p+=6;
	return TRUE;
}


/* SETDIGITS()
 * set PRECISION to the number following with the following syntax:
 *
 * SETDIGITS <n>
 * SETDIGITS(<n>)
 *
 * where n is any integer value in the range 0�PRECLIM (by default=16)
 * number is restrained to the range 0-PRECLIM */
int SETDIGITS(void) {
	int tt=(int)S();
	if (isEndOfStatement) return FALSE;
	if (tt<0) tt=-1;
	else if (tt>PRECLIM) tt=PRECLIM;
	PRECISION=tt;
	return TRUE;
}


/******************************************************************************
 * The following routines define the behavior of all the statements involving 
 * the USING feature
 *****************************************************************************/


/* FWRITEUSINGSHARP()
 * perform the 'PRINT/WRITE USING', the 'PRINT/WRITE USING #N' and the 
 * 'PRINT/WRITE #N, USING' statements.
 * The algorithm is: get the image and call printFormatted() upon it.
 * flag: if it's TRUE, perform the PRINT statement, otherwise WRITE#, printing
 * a line number in front of new lines 
 * isChan: if TRUE the form is PRINT USING #1, and comes from exec(): in this
 * case the number after the statement is not the image line but the channel
 * and tbas must be informed...
 * ch: a channel id in case command comes from FWRITESHARP()
 * p either points to the character after USING# in the first form or to the 
 * USING string in the second for*/
int FWRITEUSINGSHARP(int flag, int isChan, int ch) {
	char image[COMPSTR];
	int jj, ern=0;

	/* clean buffer */
	for (jj=0;jj<COMPSTR;jj++) image[jj]='\0';	
	strncpy_(singleUSING,"",COMPSTR);
	isSingleUSING=FALSE;
	
	/* statement in the form PRINT/WRITE USING #1,<spec>,list
	 * this form comes exec(): recover the # character */
	if (isChan) p--;

	/* statement in the form PRINT/WRITE #1[,]USING<spec>,list
	 * this form comes from FWRITESHARP() */
	if (!strncasecmp_(p,"USING",5)) p+=5;
	/* statement in the form PRINT/WRITE USING #1,<spec>,list
	 * this form comes from parse() */
	else if (*p=='#') {
		p++;
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
		if (ch<1 || ch>9) return perror_(__LINE__,133,l);
		/* checks comma/colon, which must be present */
		if (','!=*p && ':'!=*p) 
			return perror_(__LINE__,65,l,makechar(p),": OR ,");
		else p++;
	}
	/* else ch is assigned */
	
	/* string image */
	if (isanystring(p)) {
		strncpy_(image,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
	}
	/* line image */
	else if (isdigit(*p)) {
		int line=strtol(p,&p,10);
		int v=getAddr(line);
		char *mp, *im=image;
		if (v<0) return perror_(__LINE__,61,l);
		if (m[v]==NIL) return perror_(__LINE__,55,l);
		mp=m[v];
		while (*mp && isblank(*mp)) mp++;
		if (*mp!=':' && strncasecmp_(mp,"IMAGE",5)) 
			return perror_(__LINE__,105,l);
		if (*mp==':') mp++; // skip ':'
		else if (!strncasecmp_(mp,"IMAGE",5)) {
			mp+=5;
			/* skip the space after IMAGE */
			if (isblank(*mp)) mp++;
		}
		while (*mp && *mp!='\n') *im++=*mp++;
		*im='\0';
		/* if there are no variables, but there's an image line,
		 * print it bare */
		if (!*p && image[0]) {
			fprintf(channel[ch].stream,"%s\n",image);
			return TRUE;
		}
	}
	else return perror_(__LINE__,48,l);

	/* checks comma */
	if (*p!=',' && *p!=';') return perror_(__LINE__,65,l,makechar(p),",");
	else p++;
	if (image[0]) {
		ern=printFormatted(image, p, !flag, 0.0);
		if (ern>0) perror_(__LINE__,ern,l);
	}
	else return perror_(__LINE__,49,l);
	/* checks if WRITE# and PRINT# are mixed for the same channel
	 * in sequential files, which is an error */
	if (channel[ch].writer==NOUSE && ch>0) {
		if (flag) channel[ch].writer=VPRINT;
		else channel[ch].writer=VWRITE;
	}
	else if (channel[ch].writer==VWRITE && flag) return perror_(__LINE__,103,l);
	else if (channel[ch].writer==VPRINT && !flag) return perror_(__LINE__,103,l);	
	fprintf(channel[ch].stream,"%s",_FORMAT);
	return TRUE;
}


/******************************************************************************
 * The following routines define the behavior of all the FILES statements
 ******************************************************************************/
/* For the files types, consult:
 * Ref. LBMAA-A-D 10.1, 10-1, "Types of Data Files"
 * Ref. LBMAA-A-D 10.1.1, 10-1, "Sequential Access Files" 
 * Ref. LBMAA-A-D 10.1.2, 10-2, "Random Access Files" */


/* FUPDATE()
 * perform the UPDATE statement, which ensures data flushing on current file 
 * in the argument channel. Syntax:
 *
 * UPDATE [#]<n>
 * UPDATE [:]<n>
 *
 * where <n> is any channel number id. the # or : symbols are optional. This 
 * function does not check what kind of file is in the argument (sequential 
 * or random); if this file is not open, no errors are reported. */
int FUPDATE(void) {
	int ch=0,ern=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* UPDATE is valid for streams, not for the terminal */
	while (*p) {
		/* discard file type id */
		if (*p==':' || *p=='#') p++;
		ch=(int)S(); 
		if (isEndOfStatement) return FALSE;
		if (ch < 1 || ch > STREAMS) return perror_(__LINE__,133,l);
		/* assures PREPEND is closed */
		if (channel[ch].isPrepend) {
			ern=closePrepend(ch);
			if (ern>0) return perror_(__LINE__,ern,l);
		}
		/* flush channel data */
		if (channel[ch].isopen) fflush(channel[ch].stream);
		if (*p==',' || *p==';') p++;
	}
	return TRUE;
}


/* FOPEN()
 * implementation of the OPEN statement in a more modern fashion than 
 * FILE/FILES.
 * Syntax:
 *
 * OPEN "xxx" FOR [NEW] <id>[,] AS [RANDOM] [FILE] [:|#]<ch>[,] TYPE NUM|STR<n>
 * OPEN "xxx" AS LIBRARY
 * 
 * Notes:
 * - if READONLY is specified after OPEN, the read-only INPUT is assumed
 * - "xxx" may be any file name; 
 * - <id> may be INPUT or OUTPUT
 * - if the word NEW is found and <id> is OUTPUT, then the file is erased if 
 *   found. NEW is ignored in case it is used with INPUT (there's no meaning in 
 *   opening a file for input and erase it before starting reading!)
 * - if READONLY is found and <id> is not specified or it is INPUT, the 
 *   read-only INPUT is assumed
 * - <ch> must be any valid channel 1-9 not yet open; the channel is SEQ by
 *   default and may be preceded by # (dummy); if <ch> is preceded by ":",
 *   the RANDOM type is set
 * - if RANDOM is found after AS, the type is set as RANDOM
 * - if READONLY is found after AS, the read-only (in INPUT) is assumed
 * - if FILE is found before the channel, it is ignored
 * - if <ch> is preceded by # (optional) RANDOM must not be used
 * - if <ch> is preceded by : (optional) RANDOM is optional
 * - if TYPE is used, the type is set as RANDOM (NUM or STR); 
 * - if type is not used and RANDOM is set elsewhere, NUM is assumed (numeric 
 *   random type); 
 * - if TYPE STR <n> is used, STR is assumed (string random type); <n> is the 
 *   record length for random string type; if <n> is not set, STRRECLEN is used
 * - if no FOR <id> is found, INPUT is assumed. Thus, file must exist.
 * - if no AS <ch> is found (e.g. OPEN "name" FOR OUTPUT), channel is assigned
 *   according to the first available channel (but the user in unaware of this)
 * - if no FOR and no AS are used (e.g. OPEN "name"), INPUT and the first
 *   available channel are assumed. Thus, file must exist.
 * - if READONLY is not used, any INPUT will be treated as "r+" (read-mode with
 *   possibility to turn the mode to write-mode in append-mode)
 * - unlike FILE, OPEN treats one file at each invocation.
 * - if LIBRARY is found after AS, all other segments are ignored, and OPEN
 *   behaves like OPEN AS LIBRARY */
int FOPEN(void) {
	int currChan=0;		// channel #
	int id=FORINPUT;	// FORINPUT | FOROUTPUT
	int type=SEQ;		// SEQ by default
	int reclen=NUMRECLEN;	// NUM rec len by default
	int mode=NUMBER;	// NUMBER by default
	int isNew=FALSE;	// NEW holder TRUE | FALSE
	int wayout=VREAD;	// SEQ wayout type
	int fchar,flen;		// name-type detection aids
	int isReadonly=FALSE;	// read-only flag
	char op[COMPSCR], *q=op;	// holds file name
	int ern=0;

	/* there must be at least one argument */
	if (!*p) return perror_(__LINE__,65,l,FFLFVT,"A FILE NAME");

	/* look for READONLY flag (OPEN READONLY ... case) */
	if (!strncasecmp_(p,"READONLY",8)) isReadonly=TRUE, p+=8;

	/* look for AS LIBRARY call (OPEN AS LIBRARY ... case) */
	if (bcomp(p,"AS")) {
		p+=4;
		if (!strncasecmp_(p,"LIBRARY",7)) {
			p+=7;
			OPENASLIBRARY(p);
			return TRUE;
		}
		else return perror_(__LINE__,183,l);	
	}
	
	/* find first available free channel */
	for (currChan=1; currChan<=STREAMS; currChan++)
		if (!channel[currChan].isopen) break;

	/* get file name (copy input text into op);
	 * Note: unquoted constants are not permitted with OPEN */
	if (isanystring(p)) {
		if (*p=='\"') {
			p++;
			while (*p && *p!='\"') *q++=*p++;
			if (*p=='\"') p++;
			*q='\0';
		}
		else {
			strncpy_(op,SS(),COMPSCR);
			if (isEndOfStatement) return FALSE;
		}
	}
	else return perror_(__LINE__,88,l);
	
	/* determine file characteristics: first attribution by name */
	ern=setupName(op,&fchar,&flen);
	if (ern>0) return perror_(__LINE__,ern,-1);
	if (flen<0) return perror_(__LINE__,65,l,makechar(op),"; OR ,");
	if (fchar=='%') type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
	else if (fchar=='$') {
		type = RANDOM, mode=STRING;
		if (flen>0) reclen=flen;
		else reclen=NOUSE;
		if ((reclen<1 || reclen>STRRECMAX) && reclen!=NOUSE) 
			return perror_(__LINE__,56,l);
	}

	if (*p==',' || *p==';') p++;

	/* FOR <id> specifier INPUT OR OUTPUT */
	if (bonecomp(p,"FOR")) {
		p+=4;
		/* intercept NEW (ignored with INPUT) */
		if (!strncasecmp_(p,"NEW",3)) {
			p+=3;
			isNew=TRUE;
		}
		/* look for READONLY flag (OPEN  ... FOR READONLY INPUT case) */
		else if (!strncasecmp_(p,"READONLY",8)) {
			p+=8;
			isReadonly=TRUE;
			id=FORINPUT;
		}
		/* search for INPUT */
		if (!strncasecmp_(p,"INPUT",5)) {
			p+=5;
			if (doesExist(op)==DOWRITE) 
				return perror_(__LINE__,158,l,basename(op));
			id=FORINPUT;
		}
		else if (!strncasecmp_(p,"OUTPUT",6)) {
			p+=6;
			if (doesExist(op)==DOREAD) 
				return perror_(__LINE__,157,l,basename(op));
			if (isReadonly) return perror_(__LINE__,156,l,basename(op));
			id=FOROUTPUT;
			/* intercept NEW (If used after OUTPUT) */
			if (!strncasecmp_(p,"NEW",3)) {
				p+=3;
				isNew=TRUE;
			}
		}
		else return perror_(__LINE__,150,l);
	}
	
	if (*p==',' || *p==';') p++;

	/* AS <ch> specifier: second attribution by RANDOM specifier 
	 * and by channel id % or #*/
	if (bcomp(p,"AS")) {
		int this=0;
		p+=4;
		/* load library if required */
		if (!strncasecmp_(p,"LIBRARY",7)) {
			p+=7;
			includeLibs(op);
			return TRUE;
		}
		/* set random if required */
		else if (!strncasecmp_(p,"RANDOM",6)) 
			p+=6, type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		/* look for READONLY flag (OPEN  ...  AS READONLY ... case) */
		else if (!strncasecmp_(p,"READONLY",8)) {
			p+=8;
			isReadonly=TRUE;
			/* cannot open as read-only a write file */
			if (id==FOROUTPUT) return perror_(__LINE__,156,l,op); 
		}
		/* discard FILE if found */
		if (!strncasecmp_(p,"FILE",4)) p+=4;
		/* discard the # if found */
		if (*p=='#' || *p==':') this=*p++;
		/* make checks */
		if (this==':') type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		else if (this=='#') type=SEQ, mode=STRING, reclen=STRRECLEN;
		currChan=(int)S();
		if (isEndOfStatement) return FALSE;
		if (currChan>STREAMS || currChan<1) return perror_(__LINE__,133,l);
	}
	
	if (*p==',' || *p==';') p++;

	/* TYPE specifier: third attribution by direct specifier */
	if (!strncasecmp_(p,"TYPE",4)) {
		p+=4;
		if (!strncasecmp_(p,"NUM",3)) 
			p+=3, type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		else if (!strncasecmp_(p,"STR",3)) {
			p+=3;
			if (*p) {
				flen=(int)S();
				if (isEndOfStatement) return FALSE;
			}
			else flen=STRRECLEN;
			type=RANDOM, mode=STRING, reclen=flen;
			if (reclen<1 || reclen>MAXSTRLEN) 
				return perror_(__LINE__,56,l);
		}
	}

	/* check if channel is already opened by another command, and
	 * check if file has neither read nor write permissions*/
	if (channel[currChan].isopen) return perror_(__LINE__,83,l,currChan);
	if (!doesExist(op)) return perror_(__LINE__,152,l,basename(op)); 

	/* erase name if already set */
	if (channel[currChan].ioname[0]) channel[currChan].ioname[0]='\0'; 

	/* name cannot be opened more than once */
	if (checkNames(currChan,op)) return perror_(__LINE__,82,l,op);

	/* set INPUT channel values */ 
	if (id==FORINPUT) {
		if (isReadonly) channel[currChan].stream=fopen(op,"r");
		else channel[currChan].stream=fopen(op,"r+");
		if (!channel[currChan].stream) return perror_(__LINE__,151,l);
		else wayout=VREAD;
	}
	/* set OUTPUT channel values */
	else if (id==FOROUTPUT) {
		/* test safe open */
		channel[currChan].stream=fopen(op,"r+");
		/* if file does not exist, or if isNew is required 
		 * create it empty */
		if (!channel[currChan].stream || isNew) {
			if (channel[currChan].stream)
				fclose(channel[currChan].stream);
			channel[currChan].stream=fopen(op,"w+");
		}
		/* if file exist and isNew is not required,
		 * create it for append */
		else {
			if (channel[currChan].stream)
				fclose(channel[currChan].stream);
			channel[currChan].stream=fopen(op,"a+");
		}
		wayout=VWRITE;
	}
	/* check result: if file couldn't anyway be open, raise an error */
	if (!channel[currChan].stream) return perror_(__LINE__,151,l);
	/* otherwise set it as open */
	else channel[currChan].isopen=TRUE;

	/* setup file data */
	strncpy_(channel[currChan].ioname,op,COMPSTR);
	channel[currChan].type=type;
	channel[currChan].mode=mode;
	channel[currChan].fcounter=0;
	channel[currChan].wayout=wayout; // only for SEQ
	channel[currChan].currseek=1;
	channel[currChan].reclen=reclen;
	channel[currChan].randomaccessed=FALSE;
	channel[currChan].quote=NOQUOTE;
	channel[currChan].margin=MARGINDEF;
	channel[currChan].page=0;
	channel[currChan].pagerow=1;
	channel[currChan].height=PAGEHEIGHT;
	channel[currChan].pagenumber=FALSE;
	channel[currChan].writer=NOUSE;
	channel[currChan].reader=NOUSE;
	channel[currChan].fprintn=1;
	channel[currChan].isReadonly=isReadonly;
	channel[currChan].isPrepend=FALSE;
	lastChannel=currChan;
	return TRUE;
}


/* FFILE()
 * implementation of the FILE/FILES statements. 
 * isFiles: flag: if TRUE, execute FILES (which does not accept variables and 
 * is executed before program start by preParse); if FALSE, execute FILE (which
 * accepts variables and is executed during runtime).
 * l: contains current line number for perror_() (needed for FILES, because 
 * in preParse() execution has not begun yet);
 * p holds address of character after FILE/FILES */
int FFILE(int isFiles, int l) {
	int currChan=0;		// channel #
	int type, mode, filelen, reclen, ern=0;
	/* the default mode for FILES/FILE opened file is read mode */
	int wayout=VREAD;
	int fchar,flen;
	char op[COMPSCR];
	char fop[COMPFIL];

	/* there must be at least one argument */
	if (!*p) {
		if (isFiles) return perror_(__LINE__,88,l); 
		else return perror_(__LINE__,65,l,FFLFVT,"# OR :");
	}

	/* perform the FILES statement */
	if (isFiles) do {
		char *o;
		op[0]='\0';o=op;
		reclen=STRRECLEN; mode=STRING; type=SEQ;
		while (channel[currChan].isopen) currChan++; 
		if (currChan>STREAMS) return perror_(__LINE__,59,l);
		if (*p==',') {
			p++;
			continue;
		}

		/* variables are not admitted with FILES because FILES
		 * is executed into preParse(), when any variable is still
		 * uninstantiated, and thus not known */
		if (isstrvar(p)) return perror_(__LINE__,88,l);
		/* get file name, enclosed into double quotes */
		if (*p=='\"') {
			p++;
			while (*p && *p!='\"') *o++=*p++;
			if (*p=='\"') p++; // skip closing quotes
		}
		/* name as constant */
		else while (*p && *p != ',' && *p !=';') *o++=*p++;
		*o='\0';


		/* discard separators , and ; on the input line
		 * (for next iteration) */
		if (*p==',' || *p==';') p++;

		/* determine file characteristics */
		ern=setupName(op,&fchar,&flen);
		if (ern>0) return perror_(__LINE__,ern,-1);
		if (flen<0) return perror_(__LINE__,65,l,makechar(op),"; OR ,");
		if (fchar=='%') type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		else if (fchar=='$') {
			type = RANDOM, mode=STRING;
			if (flen>0) reclen=flen;
			else reclen=NOUSE;
			if ((reclen<1 || reclen>STRRECMAX) && reclen!=NOUSE)
				return perror_(__LINE__,56,l);
		}
		
		/* set channel values */
		/* open file, checks before if file has already been
		 * opened into another channel stream */
		if (checkNames(currChan,op)) return perror_(__LINE__,82,l,op);

		/* set channel values */
		channel[currChan].stream=fopen(op,"r+");
		channel[currChan].isopen=TRUE;
		/* in case file does not exist, create it empty 
		 * Note: I couldn't find references about this, but I take it 
		 * for granted */
		if (!channel[currChan].stream) {
			channel[currChan].stream=fopen(op,"w");
			fclose(channel[currChan].stream);
			channel[currChan].stream=fopen(op,"r+");
			if (reclen==NOUSE) reclen=STRRECLEN;
			wayout=VREAD;
		}
		/* if file exists and type is RANDOM and mode is STRING
		 * get first item to set filelen to file length */
		else {
			if (mode==STRING && type==RANDOM) {
				char op1[COMPSTR];
				fread(op1,sizeof(char),MAXSTRLEN,
						channel[currChan].stream);
				filelen=(int)strtod(op1+1,NULL);
				if (filelen>STRING) filelen-=STRING;
				else return perror_(__LINE__,101,l);
				if (filelen>MAXSTRLEN || filelen<1) 
					return perror_(__LINE__,56,l);
				if (reclen==NOUSE) reclen=filelen;
				else if (reclen!=filelen) return perror_(__LINE__,84,l);
				/* file existed not as random file: reset it */
				if (reclen<0) {
					fclose(channel[currChan].stream);
					channel[currChan].stream=fopen(op,"w");
					fclose(channel[currChan].stream);
					reclen=STRRECLEN;
				}
				else if (reclen!=filelen) 
					return perror_(__LINE__,84,l);
				/* reset file position */
				fseek(channel[currChan].stream,0,SEEK_SET);
				lastChannel=currChan;
			}
		}

		/* print identifier in case of random files */
		if (type==RANDOM) {
			int i;
			for (i=0; i<COMPFIL; i++) fop[i]='\0';
			if (mode==STRING)
				sprintw(fop,COMPFIL,"�%d",reclen+STRING);
			else if (mode==NUMBER)
				sprintw(fop,COMPFIL,"�%d",reclen+NUMBER);
			fseek(channel[currChan].stream,0,SEEK_SET);
			fwrite(fop,sizeof(char),
					FIRSTLEN,channel[currChan].stream);
		}

		/* setup file */
		strncpy_(channel[currChan].ioname,op,COMPSTR);
		channel[currChan].type=type;
		channel[currChan].mode=mode;
		channel[currChan].fcounter=0;
		channel[currChan].wayout=wayout; // (only for SEQ)
		channel[currChan].currseek=1;
		channel[currChan].reclen=reclen;
		channel[currChan].randomaccessed=FALSE;
		channel[currChan].quote=NOQUOTE;
		channel[currChan].margin=MARGINDEF;
		channel[currChan].page=0;
		channel[currChan].pagerow=1;
		channel[currChan].height=PAGEHEIGHT;
		channel[currChan].pagenumber=FALSE;
		channel[currChan].writer=NOUSE;
		channel[currChan].reader=NOUSE;
		channel[currChan].fprintn=1;
		channel[currChan].isReadonly=FALSE;
		channel[currChan].isPrepend=FALSE;
	} while (*p); 

	/* perform the FILE command */
	else do {
		reclen=STRRECLEN;
		mode=STRING;
		type=SEQ;

		/* get type and channel */
		if (*p==':') type=RANDOM, p++;
		else if (*p=='#') p++;
		else if (!isdigit(*p))
			return perror_(__LINE__,133,l); // tested
		currChan=strtol(p,&p,10);
		if (currChan>STREAMS || currChan<1) 
			return perror_(__LINE__,133,l);
		if (*p==',' || *p==':') p++;
		else return perror_(__LINE__,65,l,makechar(p),": OR ,");
		
		/* check if channel is already opened by another command */
		if (channel[currChan].isopen) return perror_(__LINE__,83,l,currChan);
		
		/* get file name (copy input text into op);
		 * Note: unquoted constants are not permitted with FILE */
		if (isanystring(p)) {
			strncpy_(op,SS(),COMPSCR);
			if (isEndOfStatement) return FALSE;
		}
		else return perror_(__LINE__,37,l); // tested

		/* discard separators , and ; on the input line */
		if (*p==',' || *p==';') p++;

		/* determine file characteristics */
		ern=setupName(op,&fchar,&flen);
		if (ern>0) return perror_(__LINE__,ern,-1);
		if (flen<0) return perror_(__LINE__,65,l,makechar(op),"; OR ,");
		if (fchar=='%') type=RANDOM, mode=NUMBER, reclen=NUMRECLEN;
		else if (fchar=='$') {
			type = RANDOM, mode=STRING;
			if (flen) reclen=flen;
			else reclen=NOUSE;
			if ((reclen<1 || reclen>STRRECMAX) && reclen!=NOUSE)
				return perror_(__LINE__,56,l);
		}
		/* the FILE: statement must be followed by a specifier for 
		 * the random file type (this behavior has been tested on the
		 * LCM), and this specifier must reside into the double quotes 
		 * or in the string variable */
		else if (type==RANDOM) return perror_(__LINE__,101,l);

		/* if FILE finds open the required channel, it disconnects it 
		 * and the relative file, and reopens the channel connecting it
		 * to the new file; old file type is immaterial */
		if (channel[currChan].stream!=NIL ||\
			       	*channel[currChan].ioname) {
			fflush(channel[currChan].stream);
			fclose(channel[currChan].stream);
		}

		/* name cannot be opened more than once;
		 * Note: I couldn't find news about this but I take it for 
		 * granted */
		if (checkNames(currChan,op)) return perror_(__LINE__,82,l,op);

		/* set channel values */ 
		channel[currChan].stream=fopen(op,"r+");
		channel[currChan].isopen=TRUE;
		/* in case file does not exist, create it empty 
		 * Note: I couldn't find references about this, but I take it 
		 * for granted */
		if (!channel[currChan].stream) {
			channel[currChan].stream=fopen(op,"w");
			fclose(channel[currChan].stream);
			channel[currChan].stream=fopen(op,"r+");
			if (reclen==NOUSE) reclen=STRRECLEN;
			wayout=VREAD;
		}
		/* if file exists and type is RANDOM and mode is STRING
		 * get first item to set file length */
		else {
			if (mode==STRING && type==RANDOM) {
				char op1[COMPSTR];
				fread(op1,sizeof(char),MAXSTRLEN,
						channel[currChan].stream);
				filelen=(int)strtod(op1+1,NULL);
				if (filelen>STRING) filelen-=STRING;
				else return perror_(__LINE__,101,l);
				if (filelen>MAXSTRLEN || filelen<1) 
					return perror_(__LINE__,56,l);
				if (reclen==NOUSE) reclen=filelen;
				/* file existed not as random file: reset it */
				if (reclen<0) {
					fclose(channel[currChan].stream);
					channel[currChan].stream=fopen(op,"w");
					fclose(channel[currChan].stream);
					reclen=STRRECLEN;
				}
				else if (reclen!=filelen) 
					return perror_(__LINE__,84,l);
				/* reset file position */
				fseek(channel[currChan].stream,0,SEEK_SET);
			}
		}

		/* print identifier in case of random files */
		if (type==RANDOM) {
			int i;
			for (i=0; i<COMPFIL; i++) fop[i]='\0';
			if (mode==STRING)
				sprintw(fop,COMPFIL,"�%d",reclen+STRING);
			else if (mode==NUMBER)
				sprintw(fop,COMPFIL,"�%d",reclen+NUMBER);
			fseek(channel[currChan].stream,0,SEEK_SET);
			fwrite(fop,sizeof(char),
					FIRSTLEN,channel[currChan].stream);
		}
		/* setup file */
		strncpy_(channel[currChan].ioname,op,COMPSTR);
		channel[currChan].type=type;
		channel[currChan].mode=mode;
		channel[currChan].fcounter=0;
		channel[currChan].wayout=wayout; // only for SEQ
		channel[currChan].currseek=1;
		channel[currChan].reclen=reclen;
		channel[currChan].randomaccessed=FALSE;
		channel[currChan].quote=NOQUOTE;
		channel[currChan].margin=MARGINDEF;
		channel[currChan].page=0;
		channel[currChan].pagerow=1;
		channel[currChan].height=PAGEHEIGHT;
		channel[currChan].pagenumber=FALSE;
		channel[currChan].writer=NOUSE;
		channel[currChan].reader=NOUSE;
		channel[currChan].fprintn=1;
		channel[currChan].isReadonly=FALSE;
		channel[currChan].isPrepend=FALSE;
	} while (*p); 
	return TRUE;
}


/* FMARGIN()
 * implementation of the MARGIN statement */
int FMARGIN(void) {
	int ch, msize;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* MARGIN ALL statement */
	if (!strcasecmp(p,"ALL")) {
		/* get margin size */
		p+=3; // 'ALL' specifier must be followed by direct formula
		if (*p==',' || *p==':') p++;
		msize=(int)S();
		if (isEndOfStatement) return FALSE;
		if (msize<1 || msize>MARGINMAX) return perror_(__LINE__,98,l);
		for (ch=1;ch<=STREAMS;ch++)
			if (channel[ch].isopen && channel[ch].type==SEQ)
				channel[ch].margin=msize;
	}
	/* files or terminal MARGIN statement */
	else do {
		if (*p==':') return perror_(__LINE__,101,l);
		if (*p=='#') { 
			p++; 
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		}
		else ch=CONSOLE; // terminal
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		if (*p==':' || *p==',') p++;
		msize=(int)S();
		if (isEndOfStatement) return FALSE;
		if (msize<1 || msize>MARGINMAX) return perror_(__LINE__,98,l);
		channel[ch].margin=msize;
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}


/* FNOMARGIN()
 * implementation of the NOMARGIN [ALL] statement */
int FNOMARGIN(void) {
	int ch;

	/* NOMARGIN ALL statement for files only */
	if (!strcasecmp(p,"ALL")) {
		p+=3;
		if (*p) return perror_(__LINE__,65,l,makechar(p),TERMINAT);
		for (ch=1;ch<=STREAMS;ch++)
			if (channel[ch].isopen && channel[ch].type==SEQ)
				channel[ch].margin=MARGINDEF;
	}
	/* NOMARGIN alone for terminal */
	else if (!*p) channel[CONSOLE].margin=MARGINDEF;
	/* NOMARGIN for single channels */
	else while (*p) {
		if (*p==':') return perror_(__LINE__,101,l);
		/* get channel */
		if (*p==',' || *p==';') ch=CONSOLE; // implicit
		else if (*p=='#') { 
			p++; 
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l); 
		}
		else ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		channel[ch].margin=MARGINDEF;
		if (*p==',' || *p==';') p++;
	}
	return TRUE;
}


/* FPIPE()
 * implementation of the PIPE statement */
int FPIPE(void) {
	FILE *fd;
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* copy bash/DOS command */
	strncpy_(Tcommand,SS(),COMPSTR);
	if (isEndOfStatement) return FALSE;
	/* open command */
	fd=popen(Tcommand,"r");
	if (fd) {
		int i,c;
		comlen=COMPSTR;
		/* erase command output buffer */
		if (comout) {
			free(comout);
			comout=NULL;
		}
		comout=xmalloc(comlen+1);
		if (!comout) {
			pclose(fd);
			return perror_(__LINE__,145,l);
		}
		i=0;
		/* erase base line */
		while (i<comlen) *(comout+i++)='\0';
		i=0;
		c=fgetc(fd);
		while (c!=EOF) {
			*(comout+i++)=c;
			chread++;
			if (chread>comlen-1) {
				comlen*=2;
				comout=realloc(comout,comlen+1);
			}
			c=fgetc(fd);
		}
		while (i<comlen) *(comout+i++)='\0';
		Tslice=0;
	}
	else {
		pclose(fd);
		return perror_(__LINE__,177,l);
	}
	pclose(fd);
	return TRUE;
}


/* FPAGE()
 * implementation of the PAGE [ALL] statement */
int FPAGE(void) {
	int ch, psize;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* PAGE ALL statement */
	if (!strncasecmp_(p,"ALL",3)) {
		/* get page size */
		p+=3; // 'ALL' specifier must be followed by direct formula
		if (*p==',' || *p==':') p++;
		psize=(int)S();
		if (isEndOfStatement) return FALSE;
		if (psize<1 || psize> MAXPAGEHEIGHT) return perror_(__LINE__,116,l);
		for (ch=1;ch<=STREAMS;ch++)
			if (channel[ch].isopen && channel[ch].type==SEQ)
				channel[ch].height=psize;
	}
	/* files or terminal statement */
	else do {
		if (*p==':') return perror_(__LINE__,101,l);
		if (*p=='#') { 
			p++; 
			ch=(int)S(); 
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l); 
		}
		else ch=CONSOLE; // terminal
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		if (*p==':' || *p==',') p++;
		psize=(int)S();
		if (isEndOfStatement) return FALSE;
		if (psize<1 || psize> MAXPAGEHEIGHT) return perror_(__LINE__,116,l);
		channel[ch].height=psize;
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}


/* FNOPAGE()
 * implementation of the NOPAGE [ALL] statement */
int FNOPAGE(void) {
	int ch;

	/* NOPAGE ALL statement (for files) */
	if (!strcasecmp(p,"ALL")) {
		p+=3;
		if (*p) return perror_(__LINE__,65,l,makechar(p),TERMINAT);
		for (ch=1;ch<=STREAMS;ch++)
			if (channel[ch].isopen && channel[ch].type==SEQ)
				channel[ch].height=0;
	}
	/* NOPAGE alone for terminal */
	else if (!*p) channel[CONSOLE].height=0;
	/* NOPAGE for single channels */
	else while (*p) {
		if (*p==':') return perror_(__LINE__,101,l);
		/* get channel */
		if (*p==',' || *p==';') ch=CONSOLE; // implicit
		else if (*p=='#') { 
			p++; 
			ch=(int)S(); 
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l); 
		}
		else ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		channel[ch].height=0;
		if (*p==',' || *p==';') p++;
	}
	return TRUE;
}


/* FPAGENUM()
 * implementation of the PAGE NUM [ALL]/NOPAGE NUM [ALL] statements 
 * state: a flag to set/reset pagenum mode; if TRUE, set PAGENUM mode, if 
 * FALSE, set NOPAGENUM mode*/
int FPAGENUM(int state) {
	int ch;

	/* files: PAGENUM ALL/NOPAGENUM ALL statements */
	if (!strncasecmp_(p,"ALL",3)) {
		p+=3; 
		if (*p) return perror_(__LINE__,65,l,makechar(p),TERMINAT);
		for (ch=1;ch<=STREAMS;ch++) {
			if (channel[ch].isopen && channel[ch].type==SEQ) {
				channel[ch].page=1;
				channel[ch].pagerow=1;			
				channel[ch].pagenumber=state;
			}
		}
	}
	/* PAGENUM/NOPAGENUM alone for terminal */
	else if (!*p) {
		channel[CONSOLE].page=1;
		channel[CONSOLE].pagerow=1;			
		channel[CONSOLE].pagenumber=state;
	}
	/* PAGENUM/NOPAGENUM for single channels */
	else while (*p) {
		if (*p==':') return perror_(__LINE__,101,l);
		/* get channel */
		if (*p==',' || *p==';') ch=CONSOLE; // implicit
		else if (*p=='#') { 
			p++; 
			ch=(int)S(); 
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l); 
		}
		else ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		channel[ch].page=1;
		channel[ch].pagerow=1;
		channel[ch].pagenumber=state;
		if (*p==',' || *p==';') p++;
	} 
	return TRUE;
}


/* FILLPAGE()
 * statement to execute the page filling on terminal/file; it executes the 
 * <PA> (page advance) as a statement and not as a PRINT specifier */
int FFILLPAGE(void) {
	int ch=0;

	/* Note: the FILLPAGE ALL has little sense, and is avoided. */
	/* FILLPAGE for terminal */
	if (!*p) {
		fillPage(CONSOLE);	
		channel[CONSOLE].fprintn=0;
		channel[CONSOLE].fcounter=0;
	}
	/* FILLPAGE for single channels */
	else while (*p) {
		if (*p==':') return perror_(__LINE__,101,l);
		/* get channel */
		if (*p==',' || *p==';') ch=CONSOLE; // implicit
		else if (*p=='#') {
			p++;
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		}
		else if (!*p) ch=CONSOLE; // terminal
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		fillPage(ch);
		channel[ch].fprintn=0;
		channel[ch].fcounter=0;
		if (*p==',' || *p==';') p++;
	}
	return TRUE;
}


/* FQUOTE()
 * implementation of the QUOTE/NOQUOTE [ALL] statement
 * quotemode: a flag to set/reset quote mode; if TRUE, set QUOTE mode, if 
 * FALSE, set NOQUOTE mode */
int FQUOTE(int quotemode) {
	int ch;

	/* QUOTE ALL/NOQUOTE ALL statement for files only */
	if (!strcasecmp(p,"ALL")) {
		p+=3;
		if (*p) return perror_(__LINE__,65,l,makechar(p),TERMINAT);
		for (ch=1;ch<=STREAMS;ch++)
			if (channel[ch].isopen && channel[ch].type==SEQ)
				channel[ch].quote=quotemode;
	}
	/* QUOTE/NOQUOTE alone for terminal */
	else if (!*p) channel[CONSOLE].quote=quotemode;
	/* QUOTE #N/NOQUOTE #N for single channels */
	else while (*p) {
		if (*p==':') return perror_(__LINE__,101,l);
		/* get channel */
		if (*p==',' || *p==';') ch=CONSOLE; // implicit
		else if (*p=='#') { 
			p++; 
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l); 
		}
		else ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=SEQ) return perror_(__LINE__,100,l);
		channel[ch].quote=quotemode;
		if (*p==',' || *p==';') p++;
	}
	return TRUE;
}


/* USING()
 * Perform the USING statement */
int USING(void) {
	while (isblank(*p)) p++;
	if (!*p || !strcasecmp(p,"OFF")) {
		strncpy_(singleUSING,"",COMPSTR);
		isSingleUSING=FALSE;
	}
	else {
		strncpy_(singleUSING,SS(),COMPSTR);
		isSingleUSING=TRUE;
	}
	return TRUE;
}


/* PRINT()
 * Wrapper to the PRINT family statements to select the correct path (designed
 * for PRINT/PRINT#/WRITE#) 
 * flag: if TRUE, perform PRINT/PRINT#, otherwise perform WRITE#
 * p points to the character after PRINT or WRITE */
int PRINT(int flag) {
	/* PRINT#/WRITE */
	if (*p=='#') FWRITESHARP(flag);
	/* PRINT:/WRITE: */
	else if (*p==':') FWRITECOLON();
	/* USING */
	else if (isSingleUSING) {
		int ern=printFormatted(singleUSING, p, FALSE, 0.0);
		if (ern>0) return perror_(__LINE__,ern,l);
		fprintf(channel[CONSOLE].stream,"%s",_FORMAT);
		channel[CONSOLE].fcounter+=strlen(_FORMAT);
		if (channel[CONSOLE].fcounter>channel[CONSOLE].margin && !isRawPrint) {
			FCR(CONSOLE);
			channel[CONSOLE].fprintn=0;
		}
	}
	/* PRINT */
	else FWRITESHARP(TRUE);
	return TRUE;
}


/* FWRITESHARP()
 * implementation of the PRINT/PRINT#/WRITE# statement (sequential files only) 
 * flag: if TRUE, perform PRINT/PRINT#, otherwise perform WRITE# */
int FWRITESHARP(int flag) {
	int ch, marg;
	int pagenum=0;

	/* choose destination */
	/* print on screen/terminal or on route file */
	if (*p!='#') {
		if (!(isQueued+isLPrint)) ch=CONSOLE;
		else ch=ROUTECHANNEL;
	}
	/* print on file: get file channel */
	else {
		p++;
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		if (*p==','||*p==':') p++; // optional comma/colon
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
	
		/* if p points to USING, it's a PRINT/WRITE #1[,]USING<spec>
		 * form of the command - delegate FWRITEUSINGSHARP() */
		if (!strncasecmp_(p,"USING",5)) {
			FWRITEUSINGSHARP(flag,FALSE,ch);
			return TRUE;
		}
	}
	
	/* set default print CR state */
	channel[ch].fprintn=1;

	/* if file is new, set writer mode */
	if (channel[ch].writer==NOUSE && ch>0) {
		if (flag) channel[ch].writer=VPRINT;
		else channel[ch].writer=VWRITE;
	}
	/* checks if WRITE# and PRINT# are mixed for the same channel
	 * in sequential files, which is an error */
	else {
		if (flag && channel[ch].type==SEQ) {
			if (channel[ch].writer==VWRITE) 
				return perror_(__LINE__,103,l);
		}
		if (!flag && channel[ch].type==SEQ) {
			if (channel[ch].writer==VPRINT) 
				return perror_(__LINE__,103,l);
		}
	}

	/* checks if this seq file is in READ mode, which is an error */
	if (channel[ch].wayout==VREAD) return perror_(__LINE__,73,l);

	/* get current margin for subsequent evaluations */
	marg=channel[ch].margin;

	/* check if PAGE row counter is already beyond limit
	 * Note: a channel[ch].page=0 means that PAGE option is off
	 * Note: pagenum reserves two lines for the page footer */ 
	if (channel[ch].pagerow>channel[ch].height-pagenum) {
		fillPage(ch);
		channel[ch].fprintn=0;
		channel[ch].fcounter=0;
		channel[ch].pagerow=1;
	}
	/* WRITE#/PRINT# without argument */
	if (!*p) channel[ch].fprintn=1;
	/* WRITE#/PRINT# with argument */
	else while (*p) {
		/* WRITE# begins a line with a 5-digit number, 
		 * starting from 1000, followed by a tab */
		if (!flag) {
			if (!channel[ch].fcounter) {
				/* for WRITE, the MARGIN must be at least 7 or 
				 * line number and the tab can't be printed */
				if (marg<=MARGINMIN) 
					return perror_(__LINE__,99,l);
				/* line numbers must be <= DATLIM */
			       	if (writeSeqStart>DATLIM) 
					return perror_(__LINE__,71,l);
				fprintf(channel[ch].stream,"%05d\t",\
						writeSeqStart);
				writeSeqStart+=writeSeqStep;
				channel[ch].fcounter=6;
			}
		}

		/* found an open bracket */
		if (*p=='(') {
			char *j=p;
			while (*j=='(') j++;
			if (isanystring(j)) {
				p++;
				FWRITESHARP(flag);
				if (*p==')') p++;
				else return perror_(__LINE__,37,l);
				continue;
			}
		}
		/* print a string (explicit or into a variable or into a string 
		 * expression); in QUOTE mode, string is enclosed into double 
		 * quotes and preceded by a blank */
		/* print a string (explicit or into a variable or into a string 
		 * expression); in QUOTE mode, string is enclosed into double 
		 * quotes and preceded by a blank */
		if (isanystring(p)) {
			int i;
			char res[COMPSTR]; 
			res[0]='\0';
			strncpy_(res,SS(),COMPSTR); 
			if (isEndOfStatement) return FALSE;
			for (i=0;i<COMPSTR;i++) pad[i]='\0';
			/* QUOTE mode for channel */
			if (channel[ch].quote==QUOTE) {
				/* string in quote mode cannot contain quote
				 * character (ASCII 34) */
				if (strchr(res,34)) return perror_(__LINE__,86,l);
				strncpy_(pad," ",COMPSTR);
				/* quotes only if a blank/comma/tab is found */
				if (isblankcommatab(res) || !strlen(res)) {
					strncat_(pad,"\"",COMPSTR);
					strncat_(pad,res,COMPSTR); //sp+dq
					strncat_(pad,"\"",COMPSTR);
				}
				else strncat_(pad,res,MAXSTRLEN-1); // space
				/* check length: if string is too long, it
				 * would be printed broken, and this would
				 * screw the QUOTE mode feature up */
				if ((int)strlen(pad)>marg) 
					perror_(__LINE__,111,l);
				/* if string is too long, it would be printed
				 * broken (part here and part on next line)
				 * so put it entirely to next line */
				if ((int)strlen(pad)+channel[ch].fcounter>marg)
					FCR(ch);
				printContained(ch,pad,marg);
				if (channel[ch].fcounter>marg && !isRawPrint) {
					FCR(ch);
					channel[ch].fprintn=0;
				}
				else channel[ch].fprintn=1;
			}
			/* normal NO QUOTE mode for channel */
			else {
				strncpy_(pad,res,COMPSTR);
				printContained(ch,pad,marg);
				channel[ch].fprintn=1;
			}
			/* if after a comma/semicolon there's a TAB, the
			 * comma/semicolon function must not be performed */
			if (!strncasecmp_(p,";TAB(",5)||\
					!strncasecmp_(p,",TAB(",5)) p++;
			/* p is updated into SS() */
			/* only the + and & operator are admitted */
			if (*p && *p!='+' && *p!='&') {
				if ((isro(p))) return perror_(__LINE__,35,l);
			}
		}
		/* adjust comma position (go to next ZONE) 
		 * Note: WRITE starts counting ZONEs after the five numbers
		 * plus the TAB character, so we must subtract this value */
		else if (*p==',') {
			int k=flag?0:6; // WRITE line-number space
			if (!channel[ch].fcounter) channel[ch].fcounter+=k;
			if (!channel[ch].fcounter) FAC(ch);
			while ((channel[ch].fcounter)%ZONE) FAC(ch);
			/* in case of multiple commas, force advancing */
			p++;
			if (*p==',') FAC(ch);
			channel[ch].fprintn=0;
		}
		/* adjust semicolon position (actually doing nothing) */
		else if (*p==';') {
			/* in case of sequent comma, force advancing */
			if (*(p+1)==',') FAC(ch);
			p++, channel[ch].fprintn=0;
		}
		/* <PA> delimiter for PRINT/PRINT#/WRITE# */
		else if (is_pa(p)) {
			fillPage(ch);
			p+=4;
			channel[ch].fprintn=0;
			channel[ch].fcounter=0;
		}
		/* TAB() function */
		else if (!strncasecmp_(p,"TAB(",4)) {
			int i,tab;
			p+=4;
			channel[ch].fprintn=0;
			tab=(int)S();
			if (isEndOfStatement) return FALSE;
			tab=(abs(tab)%marg);
			if (')'==*p) p++; // skip ')'
			else return perror_(__LINE__,37,l);
			if (tab > channel[ch].fcounter)
				for (i=0; i<tab-channel[ch].fcounter; i++) 
					fputc(' ',channel[ch].stream);
			channel[ch].fcounter=tab;
		}
		/* case of closed calculation */
		else if (*p==')') {
			return TRUE;
		}
		/* print a numerical expression;
		 * regardless of QUOTE mode, a space is printed after the 
		 * number to prevent contiguous characters and a space is
		 * printed before the number if the number is negative
		 * (the positive number takes the empty sign space with it) */ 
		else {
			double res;
			char out[COMPSTR], *o=out, pad[COMPSTR];
			*o='\0';
			res=S();
			if (isEndOfStatement) return FALSE;
			/* catch special 'inf' string in case of OPTION ZERO */
			if (res>=INFF && isZeroLim) {
				strncpy_(pad," inf",COMPSTR);
			}
			else if (res<=MINFF && isZeroLim) {
				strncpy_(pad,"-inf",COMPSTR);
			}
			/* normal processing */
			else {
				printNUM(ch,res,1,out);
				if (res<0 && channel[ch].quote==QUOTE) 
					sprintw(pad,COMPSTR," %s",out);
				else strncpy_(pad,out,COMPSTR);	
			}
			
			/* print number */
			fprintf(channel[ch].stream,"%s",pad);
			channel[ch].fcounter+=(int)strlen(pad);
			channel[ch].fprintn=1;
			
			/* if after a comma/semicolon there's a TAB, the
			 * comma/semicolon function must not be performed */
			if (!strncasecmp_(p,";TAB(",5)||\
					!strncasecmp_(p,",TAB(",5)) p++;
			/* p is updated into S() */
		}
	}
	
	/* close LPRINT */
	isLPrint=FALSE;

	/* update the cursor */
	if (channel[ch].fprintn) FCR(ch);
	return TRUE;
}


/* FWRITECOLON()
 * implementation of the WRITE:/PRINT: statement (random files only) 
 * Note: WRITE: and PRINT: statements are completely equivalent, 
 * and may be used on the same channel consecutively and/or alternatively */
int FWRITECOLON(void) {
	int ch, gap;
	char op[COMPFIL];

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get channel and make checks */
	p++;
	ch=(int)S();
	if (isEndOfStatement) return FALSE;
	if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
	if (!channel[ch].isopen) return perror_(__LINE__,80,l);
	if (channel[ch].type!=RANDOM) return perror_(__LINE__,101,l);
	if (*p==':' || *p==',') p++;
	else return perror_(__LINE__,38,l);

	/* calculate gap in case of file already accessed*/
	if (channel[ch].randomaccessed) {
		gap=ftell(channel[ch].stream)/channel[ch].reclen;
		if (channel[ch].currseek>gap) fillGap(ch,gap);
	}
	/* case of file not yet accessed 
	 * print random identifier and record length */
	else if (channel[ch].mode==STRING) {
		channel[ch].randomaccessed=TRUE;
		sprintw(op,COMPFIL,"�%d",channel[ch].reclen+STRING);
		fseek(channel[ch].stream,0,SEEK_SET);
		fwrite(op,sizeof(char),
				FIRSTLEN,channel[ch].stream);
		channel[ch].currseek=1;
	}
	/* case of file not yet accessed  
	 * print random identifier and record length */
	else if (channel[ch].mode==NUMBER) {
		channel[ch].randomaccessed=TRUE;
		sprintw(op,COMPFIL,"�%d",channel[ch].reclen+NUMBER);
		fseek(channel[ch].stream,0,SEEK_SET);
		fwrite(op,sizeof(char),
				FIRSTLEN,channel[ch].stream);
		channel[ch].currseek=1;
	}
	
	/* get elements to be written */
	do {
		/* string variable or literal */
		if (channel[ch].mode==STRING) {
			/* checks type */
			if (channel[ch].mode!=STRING) return perror_(__LINE__,45,l);
			/* get element and print it on file */
			strncpy_(op,SS(),COMPFIL);
			if (isEndOfStatement) return FALSE;
			if ((int)strlen(op)>channel[ch].reclen) 
				return perror_(__LINE__,113,l);
			fwrite(op,sizeof(char),channel[ch].reclen,
				channel[ch].stream);
			channel[ch].currseek++;
		}
		/* it's a numeric formula */
		else {
			double val;
			/* checks type */
			if (channel[ch].mode!=NUMBER) return perror_(__LINE__,45,l);

			/* get element and print it on file */
			val=S();
			if (isEndOfStatement) return FALSE;
			if (val>INFF) val=INFF;
			else if (val<MINFF) val=MINFF;
			printNUM(ch,val,TRUE,op);
			fwrite(op,sizeof(char),channel[ch].reclen,
				channel[ch].stream);
			channel[ch].currseek++;
		}
		if (*p==',' || *p==';') p++;
		else if (*p) return perror_(__LINE__,38,l);

	} while (*p);
	return TRUE;
}


/* FREADSHARP()
 * implementation of the READ#/INPUT# statements
 * Note: READ# and INPUT# differ: READ expects a line number for each data file 
 * line, and this number is discarded; if no number is found, an error is 
 * issued; INPUT#, does not expect a line number, and if found, treats it as a 
 * datum. These commands may not be mixed in the same channel.
 * flag: if TRUE, perform INPUT#, otherwise perform READ# 
 * mode: if TRUE, read a whole line (LINPUT#/LINEINPUT and LREAD#/LINEREAD#
 * mode), else read a datum in the standard way (INPUT# and READ# mode) */
int FREADSHARP(int flag, int mode) {
	char line[FILELINE+1], *u;
	int c, ch, var, j,isArr=FALSE,type=NUM;
	static int startofline=TRUE;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get channel and make checks */
	ch=(int)S();
	if (isEndOfStatement) return FALSE;
	if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
	if (*p==',' || *p==':') p++;
	else return perror_(__LINE__,38,l);
	if (!channel[ch].isopen) return perror_(__LINE__,69,l);
	if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);

	/* checks if sequential file is in WRITE mode, which is an error */
	if (channel[ch].wayout==VWRITE) return perror_(__LINE__,70,l);
	
	/* checks if end of file */
	if (testEOF(ch)) return perror_(__LINE__,25,l);
		
	/* checks if READ# and INPUT # are mixed for the same
	 * channel, which results in an error */
	if (channel[ch].reader==NOUSE) {
		if (flag) channel[ch].reader=VINPUT;
		else channel[ch].reader=VREAD;
		fseek(channel[ch].stream,0,SEEK_SET);
	}
	else {
		if (flag && channel[ch].reader==VREAD) 
			return perror_(__LINE__,102,l);
		if (!flag && channel[ch].reader==VINPUT) 
			return perror_(__LINE__,102,l);
	}
	for (j=0; j<=FILELINE;j++) line[j]='\0';
	
	/* read first character */
	c=fgetc(channel[ch].stream);

	/* repeat for all variables */
	while (*p) {
		int cs;
		double val=0.0;

		/* restore parameters */
		isArr=FALSE,type=NUM;
		
		/* is it an existing variable? */
		if ((cs=findDEC(p))) {
			var=cs, p+=_len;
			type=vn[cs].rettype;
			isArr=vn[cs].isArr;
		}
		else return perror_(__LINE__,42,l);
		
		/* get next available character */
		u=line;
		while (isblank(c) || c=='\n') c=fgetc(channel[ch].stream);

		/* READ# reads and discards starting line number */
		if (!flag && startofline) {
			if (isdigit(c)) {
				while (isdigit(c)) {
					c=fgetc(channel[ch].stream);
				}
			}
			else return perror_(__LINE__,97,-1,l);
			startofline=FALSE;
			while (isblank(c)) c=fgetc(channel[ch].stream);
		}
		
		/* read a string enclosed into double quotes */
		if (c=='\"' && !mode) {
			c=fgetc(channel[ch].stream);
			while (c!=EOF && c!='\n' && c!='\"' &&\
					(int)(u-line)<FILELINE) {
				*u++=c;
				c=fgetc(channel[ch].stream);
			}
			if (c=='\"') c=fgetc(channel[ch].stream);
		        if (c==',') c=fgetc(channel[ch].stream);	
		}
		/* read a normal string or number-string
		 * (the comma separates strings as well as spaces */
		else if (!mode) {
			while (!isblank(c) && c!=',' && c!='\n' && c!=EOF &&\
					(int)(u-line)<FILELINE) {
				*u++=c; // store even one starting space
				c=fgetc(channel[ch].stream);
			}
		        if (c==',') c=fgetc(channel[ch].stream);	
		}
		/* read a line until EOL */
		else {
			while (c && c!=EOF && c!='\n'&& (int)(u-line)<FILELINE){
				*u++=c; // store even one starting space
				c=fgetc(channel[ch].stream);
			} 
		}
		*u='\0'; // close line!

		/* consume spaces on the file */
		while (isblank(c)) c=fgetc(channel[ch].stream); 
		
		/* Reset counter if end of line is reached */
		if (c=='\n'|| !c) {
			startofline=TRUE;
		}
		/* treat exhausted lines 
		 * (last character read was an end-of-line) */
		else if (c==EOF) break;

		/* treat lines beginning with spaces */
		u=line;
		while (*u && (isblank(*u) || *u==',')) u++, startofline=FALSE;

		/* get numeric value */
		if (type==NUM && isnm(u)) {
			char *pp=p;
			p=u;
			val=S();
			if (isEndOfStatement) return FALSE;
			u=p;
			p=pp;
		}

		/* numeric variable */
		if (!isArr && type==NUM){
			if (vn[var].isInt) P[var]=(int)val;
			else P[var]=val;
		}
		/* string variable) */
		else if (!isArr && type==STR) strncpy_(PS[var],u,COMPSTR);
		/* numeric or string array */
		else if (isArr) {
			int M=0, N=0, T=1;
			if (*p=='(') p++;
			else return perror_(__LINE__,37,l);
			M=(int)S();
			if (isEndOfStatement) return FALSE;
			if (*p==',') {
				p++;
				N=(int)S();
				if (isEndOfStatement) return FALSE;
				T=2;
			}
			p++;
			if (vn[var].isInt) val=(int)val;
			if (type==NUM) {
				setArrayVal(var,T,M,N,val);
			}
			else {
				setArrayStr(var,T,M,N,u);
			}
		}
		if (*p==',') p++;
	}

	/* discard all remaining spaces in the line */
	while (c==' ' || c=='\t' || c=='\n') 
		c=fgetc(channel[ch].stream);

	/* reset file position */
	u=line;
	while (*u) u++;
	fseek(channel[ch].stream,-(int)strlen(line)+(int)(u-line)-1,SEEK_CUR);
	return TRUE;
}


/* FREADCOLON()
 * implementation of the READ:/INPUT: statements
 * Note: The READ: and INPUT: statements are completely equivalent, and may be 
 * used in the same channel consecutively without raising errors  */
int FREADCOLON(void) {
 	char op[FILELINE+1];
	int i,ch;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get channel and make checks */
	ch=(int)S();
	if (isEndOfStatement) return FALSE;
	if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
	if (*p==',' || *p==':') p++;
	else return perror_(__LINE__,38,l);
	if (!channel[ch].isopen) return perror_(__LINE__,80,l);
	if (channel[ch].type!=RANDOM) return perror_(__LINE__,101,l);

	/* checks if end of file */
	if (testEOF(ch)) return perror_(__LINE__,25,l);
		
	/* in case this command is executed on a not accessed file,
	 * read data file line 0 */
	if (!channel[ch].randomaccessed) {
		int rl;
		int ft=ftell(channel[ch].stream);
		channel[ch].randomaccessed=TRUE;
		fseek(channel[ch].stream,0,SEEK_SET);
		fread(op,sizeof(char),FIRSTLEN,channel[ch].stream);
		op[0]='0'; // get rid of � identifier
		rl=(int)strtod(op,NULL);
		if (channel[ch].mode==STRING) {
			rl-=STRING;
			if (rl>MAXSTRLEN||rl<1) return perror_(__LINE__,56,l);
		}
		else if (channel[ch].mode==NUMBER) rl-=NUMBER;
		if (rl!=channel[ch].reclen) return perror_(__LINE__,84,l);
		fseek(channel[ch].stream,ft,SEEK_SET); // restore position
		channel[ch].currseek=1;
	}

	/* repeat for all variables */
	while (*p) {
		int cs;

		/* clear buffer and read data from file */
		for (i=0;i<COMPFIL;i++) op[i]='\0';
		fread(op,sizeof(char),channel[ch].reclen,channel[ch].stream);

		/* detect vars */
		if ((cs=findDEC(p))) {
			p+=_len;
			/* numeric vars */
			if (vn[cs].rettype==NUM && !vn[cs].isArr)
				P[cs]=strtod(op,NULL);
			/* string variables */
			if (vn[cs].rettype==STR && !vn[cs].isArr) 
				strncpy_(PS[cs],op,COMPSTR);
			/* string and numeric arrays */
			else if (vn[cs].isArr) {
				int M=0, N=0,T=1;
				if (*p=='(') p++;
				else return perror_(__LINE__,37,l);
				M=(int)S();
				if (isEndOfStatement) return FALSE;
				if (*p==',') {
					p++;
					N=(int)S();
					if (isEndOfStatement) return FALSE;
					T=2;
				}
				if (*p==')') p++;
				else return perror_(__LINE__,37,l);
				if (vn[cs].rettype==STR) {
					setArrayStr(cs,T,M,N,op);
				}
				else {
					setArrayVal(cs,T,M,N,strtod(op,NULL));
				}
			}
		}
		channel[ch].currseek++;
		if (*p==','||*p==';') p++;
	}
	return TRUE;
}


/* FRESTORE()
 * implementation of the RESTORE statement for files;
 * omitting the # (sign number) or the : (colon) is and error */
int FRESTORE(void) {
	int ch,ern=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	do {
		/* sequential file */
		if (*p=='#') {
			if (*p=='#') p++;
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
			/* check if file exists */
			if (!channel[ch].isopen) return perror_(__LINE__,81,l);
			/* assure PREPEND is closed */
			if (channel[ch].isPrepend) {
				ern=closePrepend(ch);
				if (ern>0) return perror_(__LINE__,ern,l);
			}
			/* check if file is random, which results in an error*/
			if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
			/* set file in read mode and move seek to start */
			channel[ch].wayout=VREAD;
			fseek(channel[ch].stream,0,SEEK_SET);
		}
		/* random file */
		else if (*p==':') {
			p++;
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
			/* check if file exists */
			if (!channel[ch].isopen) return perror_(__LINE__,81,l);
			/* check if file is seq, which results in an error*/
			if (channel[ch].type!=RANDOM) return perror_(__LINE__,101,l);
			/* set to first item */
			channel[ch].currseek=1;
			channel[ch].randomaccessed=FALSE;
			fseek(channel[ch].stream,channel[ch].reclen,SEEK_SET);
		}
		else return perror_(__LINE__,38,l);
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}


/* FCLOSE()
 * implementation of the CLOSE statement for files; 
 * Note: the # (sign number) or the : (colon) are optional */
int FCLOSE(void) {
	int ch, ern=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	do {
		/* get channel */
		if (*p=='#' || *p==':') p++;
		if (isanynumber(p)) {
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
		}
		else return perror_(__LINE__,38,l);
		/* check if channel is valid */
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		/* check if file is not open 
		 * Note: I call perror_ on isopen and not the call
		 * on stream, because this last may not be portable 
		 * (e.g. BSD systems and Linux) */
		if (!channel[ch].isopen) perror_(__LINE__,149,l,ch); // warning
		/* assure PREPEND is closed */
		if (channel[ch].isPrepend) {
			ern=closePrepend(ch);
			if (ern>0) return perror_(__LINE__,ern,l);
		}
		/* close file and reset flags 
		 * (the check is left for getting rid of any doubt) */
		if (channel[ch].stream) fclose(channel[ch].stream);
		channel[ch].isopen=FALSE;
		strncpy_(channel[ch].ioname,"",COMPSTR);
		channel[ch].type=NOUSE;
		channel[ch].mode=NOUSE;
		channel[ch].fcounter=0;
		channel[ch].wayout=NOUSE;
		channel[ch].currseek=1;
		channel[ch].reclen=0;
		channel[ch].randomaccessed=FALSE;
		channel[ch].quote=NOQUOTE;
		channel[ch].margin=MARGINDEF;
		channel[ch].page=0;
		channel[ch].pagerow=1;
		channel[ch].height=PAGEHEIGHT;
		channel[ch].pagenumber=FALSE;
		channel[ch].writer=NOUSE;
		channel[ch].reader=NOUSE;
		channel[ch].fprintn=1;
		
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}


/* FSCRATCH() 
 * implementation of the SCRATCH statement;
 * omitting the # (sign number) or the : (colon) is interpreted as a SCRATCH on 
 * a sequential file */
int FSCRATCH(void) {
	int ch, ern=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	do {
		/* sequential file */
		if (*p=='#' || isdigit(*p)) {
			if (*p=='#') p++;
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
			/* assures PREPENDED is closed */
			if (channel[ch].isPrepend) {
				ern=closePrepend(ch);
				if (ern>0) return perror_(__LINE__,ern,l);
			}
			/* check if file exists */
			if (!channel[ch].isopen) return perror_(__LINE__,80,l);
			/* check if file is random, which results in an error*/
			if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);
			/* check is file is read-only */
			if (channel[ch].isReadonly)
				return perror_(__LINE__,155,l,channel[ch].ioname);
			/* erase and reset to write mode */
			if (channel[ch].stream) {
				fclose(channel[ch].stream);
				channel[ch].stream=
					fopen(channel[ch].ioname,"w+");
				channel[ch].wayout=VWRITE;
			}
		}
		/* random file */
		else if (*p==':') {
			p++;
			ch=(int)S();
			if (isEndOfStatement) return FALSE;
			/* check if channel is valid */
			if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
			/* check if file exists */
			if (!channel[ch].isopen) return perror_(__LINE__,80,l);
			/* check if file is seq, which results in an error*/
			if (channel[ch].type!=RANDOM) return perror_(__LINE__,101,l);
			/* erase and reset to first item */
			if (channel[ch].stream) {
				fclose(channel[ch].stream);
				channel[ch].stream=
					fopen(channel[ch].ioname,"w+");
				channel[ch].currseek=1;
				channel[ch].randomaccessed=FALSE;
			}
		}
		else return perror_(__LINE__,38,l);
		if (*p==',' || *p==';') p++;
	} while (*p);
	return TRUE;
}


/* FSET() 
 * implementation of the SET statement */
int FSET(void) {
	int ch=0, setpos=0, eof=0, reclen=0;

	/* there must be an argument */
	if (!*p) return perror_(__LINE__,125,l);
	
	do {
		/* colon can be omitted */
		if (*p==':') p++;
		
		/* get and check channel */
		ch=(int)S();
		if (isEndOfStatement) return FALSE;
		if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
		if (!channel[ch].isopen) return perror_(__LINE__,80,l);
		if (channel[ch].type!=RANDOM) return perror_(__LINE__,101,l);

		 /* get and check position */
		if (*p!=':' && *p!=',') return perror_(__LINE__,38,l);
		p++;
		setpos=(int)S();
		if (isEndOfStatement) return FALSE;
		reclen=channel[ch].reclen;
		if (setpos<=0) return perror_(__LINE__,120,l);
		/* fill positions in case SET value is past EOF */
		eof=getEOF(ch);
		if (setpos>eof) {
			fseek(channel[ch].stream,0,SEEK_END);
			fwrite("\0",sizeof(char),(setpos-eof-1)*reclen,
					channel[ch].stream);
		}
		/* set position */
		fseek(channel[ch].stream,FIRSTLEN+(setpos-1)*reclen,SEEK_SET);
		channel[ch].currseek=setpos;
		if (*p==',' || *p==';') p++;
	} while (*p);		
	return TRUE;
}


/* CHAIN()
 * implementation of the CHAIN command;
 * enable a program to load and parse an external program.
 * Note: the CHAIN statement is the last to be executed, so anything following
 * it is discarded, both in listing and in the program flow. In practice, the 
 * caller program transfers the control to the CHAINed file.
 * The CHAINed file doesn't inherit the caller's variables
 * The starting line of the CHAINed program may be specified after a comma */
int CHAIN(void) {
	char fname[COMPSCR], *tf=fname;
	FILE* fd;
	int z=0, ph=TRUE, ern=0;
	
	/* there must be an argument */
	if (!*p) return perror_(__LINE__,125,l);
	
	/* Note: the CHAIN command may be issued into a FOR, or with a pending
	 * GOSUB subroutine, or within a multiline DEF function; so there's no
	 * need to prevent the call to CHAIN in those cases */

	/* get file name 
	 * name may be given as CHAIN FILE1 or CHAIN "FILE1" or CHAIN A$; 
	 * FILE1 without quotes must of course not contain quotes, spaces,
	 * commas; if it contains any of such peculiar characters, it must be 
	 * written enclosed by double quotes */
	while (isblank(*p)) p++;
	/* get name from string (case a)*/
	if (!isstrvar(p)) 
		{	
			/* string enclosed by "" */
			if (*p=='\"') {
				p++;
				while (*p && *p!='\"') *tf++=*p++;
				*tf='\0';
				p++;
			}
			/* plain name until comma or end of string */
			else {
				while (*p && *p!=',' && *p!='\0') *tf++=*p++;
				*tf='\0';
			}
		}
	/* get name from variable (case b) */
	else {
		strncpy_(fname,SS(),COMPSCR);
		if (isEndOfStatement) return FALSE;
	}
	while (isblank(*p)) p++;

	/* get starting line, if given as argument; check if into bounds */
	if (*p){
		if (*p!=',') return perror_(__LINE__,38,l);
		p++; // skip comma
		startingLine=(int)S(); // label value
		if (isEndOfStatement) return FALSE;
		if (startingLine<0 || startingLine>DATLIM) 
			return perror_(__LINE__,94,l);
		ph=FALSE;// still label
	}
	/* if no argument was found, set default starting line */
	else startingLine=1; // physical address

	/* checks file existence */
	ern=setupName(fname,&z,&z);
	if (ern>0) return perror_(__LINE__,ern,-1);
	if (!(fd=fopen(fname,"r"))) return perror_(__LINE__,1,-1,fname);
	else fclose(fd);
	
	/* set CHAIN flag, load file name */
	isChain=TRUE;
	strncpy_(filename,fname,COMPSCR);
	OLD();

	/* convert label address to physical address */
	if (!ph) {
		startingLine=getAddr(startingLine);
		if (startingLine<0) return perror_(__LINE__,107,l);
	}

	/* not existing line in the CHAINed file: search for next */
	while (!m[startingLine] && startingLine<=DATLIM) startingLine++;
	/* irregular line (line inside a multiline DEF FN, for instance) */
	if (fm[startingLine]) return perror_(__LINE__,89,l);
	/* all's good: execute the CHAINed program 
	 * Note: RUN erases all memory and calls both preParse() and parse() */
	RUN();
	return TRUE;
}


/******************************************************************************
 * The following routines define the behavior of the MAT statements, which were
 * included as a CardBasic option since 1964 version II of Dartmouth BASIC, and
 * as standard since 1966 version III.
 ******************************************************************************/

/* MATDOT()
 * The DOT statement (this is a math-function rather than a matrix-function)
 * return dot product between two unidimensional vectors, yielding a real
 * argument vectors are taken from stream
 * Vectors may be vertical or horizontal in either side */
double MATDOT(void) {
	int var1=0,var2=0;
	double res=0.0;
	int cs, dim1=0, dim2=0;

	/* there must be an argument */
	if (!*p) return (double) perror_(__LINE__,35,l);
	
	/* get first matrix codes */
	forceArray=TRUE;
	if ((cs=findDEC(p)) && _rettype==NUM && _arr) var1=cs,p+=_len;
	else return (double) perror_(__LINE__,42,l);
	if (*p++!=',') return (double) perror_(__LINE__,35,l);
	/* get second matrix codes */
	if ((cs=findDEC(p)) && _rettype==NUM && _arr) var2=cs,p+=_len;
	else return (double) perror_(__LINE__,42,l);
	forceArray=FALSE;

	/* check types (they must exist and not be matrices) */
	if (dim[var1].row==0 && dim[var1].col==0) return (double) perror_(__LINE__,51,l);
	if (dim[var2].row==0 && dim[var2].col==0) return (double) perror_(__LINE__,51,l);
	if (dim[var1].row>0 && dim[var1].col>0) return (double) perror_(__LINE__,51,l); 
	if (dim[var2].row>0 && dim[var2].col>0) return (double) perror_(__LINE__,51,l); 
	
	/* get dimensions */
	if (dim[var1].row!=0 && dim[var1].col==0)      dim1=dim[var1].row;
	else if (dim[var1].row==0 && dim[var1].col!=0) dim1=dim[var1].col;
	else return (double) perror_(__LINE__,51,l);
	if (dim[var2].row!=0 && dim[var2].col==0)      dim2=dim[var2].row;
	else if (dim[var2].row==0 && dim[var2].col!=0) dim2=dim[var2].col;
	else return (double) perror_(__LINE__,51,l);
	
	/* check dimensions validity */
	if (dim1!=dim2) return (double) perror_(__LINE__,117,l);

	/* perform dot product */
	else {
		double vec1[dim1+2], vec2[dim1+2]; // dim1=dim2!!
		int i;
		
		/* copy var1 from either type */
		if (dim[var1].type==1) {
			for (i=0;i<=dim1;i++) {
				vec1[i]=getArrayVal(var1,1,i,0);
			}
		}	
		else {
			if (dim[var1].row!=0 && dim[var1].col==0)
				for (i=0;i<=dim1;i++) {
				       vec1[i]=getArrayVal(var1,2,i,0);
				}
			else if (dim[var1].row==0 && dim[var1].col!=0) 
				for (i=0;i<=dim1;i++) { 
					vec1[i]=getArrayVal(var1,2,0,i);
				}
		}
		/* copy var 2 from either type */
		if (dim[var2].type==1) {
			for (i=0;i<=dim1;i++) {
				vec2[i]=getArrayVal(var2,1,i,0);
			}
		}
		else {
			if (dim[var2].row!=0 && dim[var2].col==0)
				for (i=0;i<=dim2;i++) {
					vec2[i]=getArrayVal(var2,2,i,0);
				}
			else if (dim[var2].row==0 && dim[var2].col!=0) 
				for (i=0;i<=dim2;i++) { 
					vec2[i]=getArrayVal(var2,2,0,i);
				}
		}

		/* calculate dot product from copies */
		for (i=0;i<=dim1;i++) res+=vec1[i]*vec2[i];
	}
	return res;
}


/* MATbyK(result-matrix)
 * multiply a matrix by an expression, both taken from stream; read multiplier
 * and argument matrix from stream, multiply to the result matrix
 * varr: the result matrix code, checked into MATtype() and passed here */
int MATbyK(int varr){
	double exp;
	int var1=0, i=0,j=0,m=0,n=0,t=0, cs=0;

	/* get expression value */
	exp=S();
	if (isEndOfStatement) return FALSE;
	
	/* there must be an argument */
	if (!*p) return perror_(__LINE__,125,l);
	
	/* result matrix existence was checked into MATtype() */

	/* check syntax */
	if (*p++!= ')') return perror_(__LINE__,35,l);
	if (*p++!= '*') return perror_(__LINE__,35,l);
	
	/* get argument matrix code */
	forceArray=TRUE;
	cs=findDEC(p);
	if (cs && _rettype==NUM && _arr) var1=cs,p+=_len;
	else return perror_(__LINE__,42,l);
	forceArray=FALSE;

	/* check dimensions coherence and redimension result matrix */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)<\
			(dim[var1].row+1)*(dim[var1].col+1)) 
		return perror_(__LINE__,76,l);
	else {
		m=dim[varr].row=dim[var1].row;
		n=dim[varr].col=dim[var1].col;
		t=dim[varr].type;
	}

	/* perform multiplication by expression */
	/* Legal procedures for special cases:
	 * MAT A=(K)*A */
	i=1; j=(t==1)?0:1;
	while (i<=m) {
		setArrayVal(varr,t,i,j,exp*getArrayVal(var1,t,i,j));
		j++;
		if (j>n) {i++; j=(t==1)?0:1;}
	}
	return TRUE;
}


/* MATTRN(result-matrix)
 * The MAT TRN statement for transposing a numerical matrix; read argument 
 * matrix from stream, transpose it to the result matrix 
 * Note: there's not much sense in transposing a string matrix, isn't it?
 * varr: the result matrix, checked into MATtype() and passed here */
int MATTRN(int varr){
	int var1,i,j,t,t1,y,cs,ern=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* result matrix existence was checked into MATtype */

	/* get argument matrix code */
	forceArray=TRUE;
	if (*p++=='(') {
		cs=findDEC(p);
		if (cs && _rettype==NUM && _arr) var1=cs, p+=_len;
		else return perror_(__LINE__,42,l);
	}
	else return perror_(__LINE__,35,l);
	forceArray=FALSE;

	/* check dimensions coherence */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)<\
			(dim[var1].row+1)*(dim[var1].col+1))
		return perror_(__LINE__,76,l);

	/* Legal procedures for special cases:
	 * MAT C=TRN(C) 
	 * calculate values for result matrix and copy argument matrix to
	 * temporary matrix for enabling the legal case MAT C=TRN(C) 
	 * TEMPVAR = var1 */
	t=dim[varr].type;
	t1=dim[var1].type;
	ern=dimArray(TEMPVAR,t1,dim[var1].row,dim[var1].col);
	if (ern>0) return perror_(__LINE__,ern,l);
	for(i=0;i<=dim[var1].row;i++) for(j=0;j<=dim[var1].col;j++) {
		setArrayVal(TEMPVAR,t1,i,j,getArrayVal(var1,t1,i,j));
	}

	/* transpose argument vector (previously copied over temporary) 
	 * to result horizontal vector */
	if (dim[var1].type==1) {
		dim[varr].type=2;
		dim[varr].col=dim[var1].row;
		dim[varr].row=0; // ??
		i=1;
		while (i<=dim[varr].col) {
			setArrayVal(varr,2,0,i,getArrayVal(TEMPVAR,1,i,0));
			i++;
		}
	}
	/* transpose argument horizontal vector (previously copied over 
	 * temporary) to result vector */
	else if (dim[var1].type==2 && dim[var1].row==0 && dim[var1].col) {
		dim[varr].type=1;
		dim[varr].row=dim[var1].col;
		dim[varr].col=0; // ??
		i=1;
		while (i<=dim[varr].row) {
			setArrayVal(varr,1,i,0,getArrayVal(TEMPVAR,t1,0,i));
			i++;
		}
	}
	/* transpose argument matrix (previously copied over temporary) 
	 * to result matrix */
	else {
		/* redimension result matrix */
		y=dim[var1].row;
		dim[varr].row=dim[var1].col;
		dim[varr].col=y;
		i=1;
		while (i<=dim[varr].col) {
			j=1;
			while (j<=dim[varr].row) {
			   setArrayVal(varr,t,j,i,getArrayVal(TEMPVAR,t1,i,j));
			   j++;
			}
			i++;
		}
	}
	return TRUE;
}


/* MATINV(result-matrix)
 * The MAT INV statement for inverting a matrix
 * Read parameters from the stream, setup parameters and pass them to 
 * matinvert(), the **real** matrix inverter. 
 * varr: the result matrix, checked into MATtype() and passed here */
int MATINV(int varr){
	int var1=0, cs=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* existence was checked into MATtype() */
	
	/* get argument matrix code */
	forceArray=TRUE;
	if (*p++=='(') {
		cs=findDEC(p);
		if (cs && _rettype==NUM && _arr) var1=cs,p+=_len;
		else return perror_(__LINE__,42,l);
		if (*p!=')') return perror_(__LINE__,37,l);
		else p++;
	}
	else return perror_(__LINE__,42,l);
	forceArray=FALSE;

	/* ELSE case */
	invElseCase=FALSE; // reset each time
	if (bcomp(p,"ELSE")) invElseCase=TRUE;

	/* check matrix coherence */
	if (dim[var1].type!=2) return perror_(__LINE__,76,l);

	/* redimension result matrix if its dimensions are greater than
	 * matrix to invert
	 * Note: in the expression MAT C=INV(A) C may be a vector; it is turned 
	 * to square, provided it has sufficient space for the NxN elements;
	 * Note: MAT A=INV(A) is considered legal (no control) */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)>=\
			(dim[var1].row+1)*(dim[var1].col+1)) {
		dim[varr].type=2; // in case of a transformed vector
		dim[varr].row = dim[var1].row;
		dim[varr].col = dim[var1].col;
	}
	else return perror_(__LINE__,76,l);
	
	/* delegate inversion to matinvert */
	matinvert(varr,var1);

	/* check the ELSE CASE */
	if (unresCase && invElseCase) {
		p+=6;
		GOTO();
	}
	unresCase=FALSE;
	return TRUE;
}


/* matinvert(result-matrix, argument-matrix)
 * Invert matrix 'argument' into matrix 'result' and calculate the determinant 
 * using the Gauss factorization scheme. Variables:
 * - varr: the unknown result global inverted matrix (NxN) in the BASIC code
 * - var1: the global knowns matrix to be inverted (NxN) in the BASIC code, it
 *    is used to form ma
 * ma is the local composed matrix (2NxN) (to the left the knowns matrix, to 
 *    the right the identity matrix); this matrix is invisible to BASIC
 * x is the local calculated inverted matrix (NxN), invisible to BASIC and 
 *    later copied back to varr. 
 * detValue is the global determinant value, visible to BASIC through DET.
 * Copyleft Antonio Maschio - March 2008 */
void matinvert(int varr, int var1) {
	int n = (dim[var1].row), d=2*n+1; 	
	int i=0, j=0, k=0;
	double x[n+1][n+1],ma[n+1][d+1];
	double mul=0.0,piv=0.0;

	/* set determinant base multiplier */
	detValue=1.0;
	/* create composed matrix AI, with the same rows number of A,
	 * and twice the columns number of A; in the second half lies I */
	for (i=1;i<=n;i++) for(j=1;j<=n;j++) {
		ma[i][j]=getArrayVal(var1,2,i,j);
		/* setting I to all zeroes */
		ma[i][j+n+1]=0.0;
	}
	/* set diagonal of I to all ones */
	for (i=1;i<=n;i++) ma[i][i+n+1]=1.0;
	
	/* erase destination matrix */
	for (i=1; i<=n; i++) for (j=1; j<=n; j++) x[i][j]=0.0;
	
	/* Gauss factorization over AI with partial pivoting */
	for (k=1;k<n;k++) {
		piv=ma[k][k];
		if (!piv) {
			double maxx=0;
			int r=k;
			/* k is the row where pivot is zero
			 * now find the row where pivot is max */
			for (i=k+1;i<=n;i++) 
				if (maxx<fabs(ma[i][k])){ 
					maxx=ma[i][k]; 
					r=i; 
				}
			/* matrix is singular if r hasn't changed */
			if (r==k) { 
				/* warning */
				if (!invElseCase) perror_(__LINE__,121,l); 
				detValue=0.0; 
				unresCase=TRUE;
				return; 
			}
			/* exchange rows r and k */
			for (i=1;i<=d;i++) {
				maxx=ma[r][i];
				ma[r][i]=ma[k][i];
				ma[k][i]=maxx;
			}
			piv=ma[k][k];
			/* matrix is singular if pivot is still null */
			if (!piv) { 
				/* warning */
				if (!invElseCase) perror_(__LINE__,121,l); 
				detValue=0.0; 
				unresCase=TRUE;
				return; 
			}
			/* update determinant sign */
			detValue*=-1; 
		}
		/* update the rest of the rows */
		for (i=k+1;i<=n;i++) {
			mul=ma[i][k]/piv;
			for (j=k;j<=d;j++) ma[i][j]=ma[i][j]-mul*ma[k][j];
		} 
		
	}

	/* calculate determinant */
	for (i=1;i<=n;i++) detValue*=ma[i][i];
	
	/* check singularity; this should not be the case, since singularity
	 * should emerge from the calculation, but if, after all, determinant
	 * is null, print a message, to warn the user without stopping
	 * the program in any case.
	 * Actually, in some cases (notably, for the inverse of test matrix 
	 * {1 2 3}{4,5,6}{7,8,9}) this algorithm returns determinant zero
	 * and therefore the matrix is singular (not invertible); for this
	 * I take comfort using some online matrix inversion algorithms (mainly
	 * matrix.reshish.com, www.quickmath.com, matrixcalc.org/en/), which
	 * don't return any inverted matrix because the determinant is zero */
	if (detValue==0.0) {
		/* warning */
		if (!invElseCase) perror_(__LINE__,121,l);
		unresCase=TRUE;
		return;
	}

	/* calculate the inverse of A through back-substitution */
	for (i=1;i<=n;i++) {
		x[n][i]=ma[n][i+n+1]/ma[n][n];
		for (j=n-1;j>=0;j--) {
			piv=0;
			for(k=j+1;k<=n;k++) piv+=ma[j][k]*x[k][i];
			x[j][i]=(ma[j][i+n+1]-piv)/ma[j][j];
		}
	}

	/* set varr to the resulting inverted matrix */
	for (i=1; i<=n; i++) for (j=1; j<=n; j++)  {
		setArrayVal(varr,2,i,j,x[i][j]);
	}
}


/* MATIDN(result-matrix)
 * The MAT IDN statement for setting a square array to identity matrix;
 * var: the code of the matrix to be IDNed (there is no argument matrix) */
int MATIDN(int var){
	int m=0, n=0, t=0;
	int i=0, j=0;

	/* set array values */
	m=dim[var].row;
	n=dim[var].col;
	t=dim[var].type;
	if (m!=n || t!=2) return perror_(__LINE__,122,l);

	/* resizing values (only square matrices) */
	if (*p=='(') {
		p++;
		m=(int)S();
		if (isEndOfStatement) return FALSE;
		if (*p==',') {
			p++;
			n=(int)S();
			if (isEndOfStatement) return FALSE;
		}
		else return perror_(__LINE__,122,l);
		if (m!=n) return perror_(__LINE__,122,l); 
		if ((m+1)*(n+1)<=(dim[var].brow+1)*(dim[var].bcol+1)) {
			dim[var].row=m;
			dim[var].col=n;
			dim[var].type=t;
		}
		else return perror_(__LINE__,176,l);
		if (*p!=')') return perror_(__LINE__,37,l);
		else p++;
	}

	/* result matrix existence was checked into MATtype() */

	/* set values for IDN */
	for (i=0;i<=m;i++) for (j=0;j<=n;j++) {
		setArrayVal(var,2,i,j,0.0);
	}
	for (i=0;i<=m;i++) {
		setArrayVal(var,2,i,i,1.0);
	}
	return TRUE;
}


/* MATZER(result-matrix, option-value)
 * The MAT ZER and MAT CON statements for setting (or resetting) an array to 
 * all zeroes (MAT ZER) or given value (MAT CON), depending on option value 
 * 'op' (= 0 for ZER, 1 for CON) */
int MATZER(int var, double op){
	int t=0, m=0, n=0;
	int i=0, j=0;

	/* set array values */
	t=dim[var].type;
	m=dim[var].row;
	n=dim[var].col;

	/* resizing values */
	if (*p=='(') {
		p++;
		m=(int)S();
		if (isEndOfStatement) return FALSE;
		n=0;
		t=1;
		if (*p==',') {
			p++;
			n=(int)S();
			if (isEndOfStatement) return FALSE;
			t=2;
		}
		if ((m+1)*(n+1)<=(dim[var].brow+1)*(dim[var].bcol+1)) {
			dim[var].row=m;
			dim[var].col=n;
			dim[var].type=t;
		}
		else return perror_(__LINE__,176,l);
		if (*p!=')') return perror_(__LINE__,37,l);
		else p++;
	}

	/* result matrix existence was checked into MATtype() */
	
	/* set values for ZER or CON */
	if (t==1) for (i=0;i<m;i++) {
		setArrayVal(var,t,i+1,0,op);
	}
	else for (i=0;i<m;i++) for (j=0;j<n;j++) {
		setArrayVal(var,t,i+1,j+1,op);
	}
	return TRUE;
}


/* MATNUL(result-matrix)
 * The MAT NUL$ statement for setting a string matrix to all void strings */
int MATNUL(int var){
	int t=0, m=0, n=0;
	int i=0, j=0;

	/* set array values */
	t=dimS[var].type;
	m=dimS[var].row;
	n=dimS[var].col;

	/* resizing values */
	if (*p=='(') {
		p++;
		m=(int)S();
		if (isEndOfStatement) return FALSE;
		n=0;
		t=1;
		if (*p==',') {
			p++;
			n=(int)S();
			if (isEndOfStatement) return FALSE;
			t=2;
		}
		if ((m+1)*(n+1)<=(dimS[var].brow+1)*(dimS[var].bcol+1)) {
			dimS[var].row=m;
			dimS[var].col=n;
			dimS[var].type=t;
		}
		else return perror_(__LINE__,176,l);
		if (*p!=')') return perror_(__LINE__,37,l);
		else p++;
	}

	/* result matrix existence was checked into MATtype() */
	
	/* set values for NUL$ */
	if (t==1) for (i=0;i<m;i++) {
		setArrayStr(var,t,i+1,0, NULLSTR);
	}
	else for (i=0;i<m;i++) for (j=0;j<n;j++) { 
		setArrayStr(var,t,i+1,j+1, NULLSTR);
	}
	return TRUE;
}


/* MATsum(result-matrix,matrix1,matrix2,option-value)
 * Add two matrices or subtract the second from the first.
 * varr: the result matrix code
 * var1: first matrix addendum
 * var2: second matrix addendum
 * op: if -1, do subtraction, if 1 do addition */
int MATsum(int varr, int var1, int var2, int op){
	int i=0,j=0;
	int M=0, N=0,ern=0;
	int T=dim[varr].type;
	int T1=dim[var1].type;
	int T2=dim[var2].type;
	
	/* existences of result matrix and of argument matrices var1 and var2 
	 * have already been checked into MATtype() */

	/* check matching of dimensions 
	 * Note: one can only sum vectors with vectors, matrices with
	 * matrices, and not use unidimensional vectors or
	 * degenerated matrices of one row or of one column */
	if (dim[var1].row!=dim[var2].row ||\
			dim[var1].col!=dim[var2].col)
		 return perror_(__LINE__,76,l);
	if (T1!=T2) return perror_(__LINE__,76,l);

	/* Legal procedures for special cases:
	 * MAT A=A+B, A=A-B 
	 * MAT A=B+A, A=B-A (which should succeed for the same reasons)
	 * MAT A=A+A, A=A-A */

	/* redimension result matrix */
	if ((dim[var1].brow+1)*(dim[var1].bcol+1)>\
			(dim[varr].brow+1)*(dim[varr].bcol+1))
		return perror_(__LINE__,76,l);
	else {
		M=dim[varr].row=dim[var1].row;
		N=dim[varr].col=dim[var1].col;
	}

	/* create dummy matrix dimensionally equal to varr */
	ern=dimArray(TEMPVAR,T,M,N);
	if (ern>0) return perror_(__LINE__,ern,l);
	
	/* perform sum and copy data back to varr;
	 * TEMPVAR serves as a buffer for not overwriting any values */
	i=1; j=(T==1)?0:1;
	while (i<=M) {
		setArrayVal(TEMPVAR,T,i,j,getArrayVal(var1,T1,i,j)+op*getArrayVal(var2,T2,i,j));
		setArrayVal(varr,T,i,j,getArrayVal(TEMPVAR,T,i,j));
		j++;
		if (j>N) {i++; j=(T==1)?0:1;}
	}

	return TRUE;
}


/* MATmul(result-matrix,matrix1,matrix2)
 * The cross-product between two matrices or vectors 
 * varr: the result matrix code
 * var1: first matrix 
 * var2: second matrix */
int MATmul(int varr, int var1, int var2){
	int i,j,k,ern=0;
	int M=dim[varr].row;
	int N=dim[var1].col;
	int P=dim[var2].col;
	int T=dim[varr].type;
	int T1=dim[var1].type;
	int T2=dim[var2].type;

	/* existences of result matrix and of argument matrices var1 and var2 
	 * have already been checked into MATtype() */

	/* instantiate temporary matrix with result matrix dimensions */
	ern=dimArray(TEMPVAR,T,M,dim[varr].col);
	if (ern>0) return perror_(__LINE__,ern,l);

	/* check dimensions validity */
	if ((dim[varr].brow+1)*(dim[varr].bcol+1)<\
			(dim[var1].row+1)*(dim[var2].col+1))
		return perror_(__LINE__,76,l);

	/* redimension result matrix (and temporary) */
	M=dim[varr].row=dim[TEMPVAR].row=dim[var1].row;
	dim[varr].col=dim[TEMPVAR].col=dim[var2].col;
	
	 /* Legal procedures for special cases:
	 * MAT B=A*A 
	 * MAT A=A*B, A=B*A and A=A*A */

	/* perform cross multiplication and copy data back to varr 
	 * TEMPVAR serves as a buffer for not overwriting any values */
	if (T==2) {
		for(i=1;i<=M;i++) {
			for(j=1;j<=P;j++) {
				double res=0.0;
				for(k=1;k<=N;k++) {
					res+=getArrayVal(var1,T1,i,k)*getArrayVal(var2,T2,k,j);
				}
				setArrayVal(TEMPVAR,T,i,j,res);
			}
		}
		for (i=1;i<=M;i++)  for (j=1;j<=P;j++) {
			setArrayVal(varr,T,i,j,getArrayVal(TEMPVAR,T,i,j));
		}
	}
	else if (T==1) {
		for(i=1;i<=M;i++) {
			double res=0.0;
			for(k=1;k<=N;k++) {
				res+=getArrayVal(var1,T1,i,k)*getArrayVal(var2,T2,k,0);
			}
			setArrayVal(TEMPVAR,T,i,0,res);
		}
		for (i=1;i<=M;i++) {
			setArrayVal(varr,T,i,0,getArrayVal(TEMPVAR,T,i,0));
		}
	}
	return TRUE;
}



/* MATtype()
 * this function is invoked by parse when a MAT statement is met (other than 
 * MAT READ, MAT PRINT or MAT INPUT, which follow their way), to choose the 
 * correct command. 
 * Controls are done on result matrix (instantiating it if not existing), and
 * in case of addition, subtraction and multiplication between matrices, 
 * control is done on argument matrices; peculiar functions like IDN, CON,
 * ZER, INV and TRN check argument matrix on their own. */
int MATtype(void) {
	int varr=0; 
	int var1=0;
	int var2=0;
	int op=0;
	int mode=NUM, cs;

	/* get result matrix code */
	forceArray=TRUE;
	cs=findDEC(p);
	if (cs && _rettype==NUM && _arr) varr=cs, p+=_len;
	else if (cs && _rettype==STR && _arr) varr=cs, p+=_len, mode=STR;
	else return perror_(__LINE__,42,l);
	forceArray=FALSE;

	if (*p++!='=') return perror_(__LINE__,35,l);
	
	/* string mat operations */
	if (mode==STR) {
		/* perform the erasing of string matrix (delegate MATNUL) */
		if (!strncasecmp_(p,"NULL$",5)) {
			p+=5; 
			MATNUL(varr);
			return TRUE;
		}
		else if (!strncasecmp_(p,"NUL$",4)) {
			p+=4; 
			MATNUL(varr);
			return TRUE;
		}
		/* perform the matrix copying (delegate matStrCopy) */
		else {
			/* get first matrix operand code */
			forceArray=TRUE;
			if ((cs=findDEC(p)) && _rettype==STR && _arr) 
				var1=cs,p+=_len;
			else return perror_(__LINE__,42,l);
			forceArray=FALSE;
			if (!*p) matStrCopy(varr, var1);
			return TRUE;
		}
	}
	/* numeric mat functions */
	else if (!strncasecmp_(p,"ZERO",4)) p+=4, MATZER(varr,0.0);
	else if (!strncasecmp_(p,"ZER",3)) p+=3, MATZER(varr,0.0);
	else if (!strncasecmp_(p,"UNITY",5)) p+=5, MATZER(varr,1.0);
	else if (!strncasecmp_(p,"CON",3)) p+=3, MATZER(varr,1.0);
	else if (!strncasecmp_(p,"TRANSPOSE",9)) p+=9, MATTRN(varr);
	else if (!strncasecmp_(p,"TRN",3)) p+=3, MATTRN(varr);
	else if (!strncasecmp_(p,"IDENTITY",8)) p+=8, MATIDN(varr);
	else if (!strncasecmp_(p,"IDN",3)) p+=3, MATIDN(varr);
	else if (!strncasecmp_(p,"INVERT",6)) p+=6, MATINV(varr);
	else if (!strncasecmp_(p,"INV",3)) p+=3, MATINV(varr);
	else if (*p=='(') p++, MATbyK(varr);
	/* numeric mat operations */
	else {
		/* get first matrix operand code */
		forceArray=TRUE;
		if ((cs=findDEC(p)) && _rettype==NUM && _arr)
			var1=cs,p+=_len;
		else return perror_(__LINE__,42,l);
		forceArray=FALSE;
		
		/* perform the simple copy (no operators) */
		if (!*p) matCopy(varr, var1);
		/* perform the matrix operations */
		else {
			/* get op */
			if (*p!='+' && *p!='-' && *p!='*' && *p!='\0') 
				return perror_(__LINE__,35,l);
			else op=*p++;

			/* get second matrix operand code */
			forceArray=TRUE;
			cs=findDEC(p);
			if (op!='\0') {
				if (cs && _rettype==NUM && _arr) 
					var2=cs, p+=_len;
				else return perror_(__LINE__,42,l);
			}
			forceArray=FALSE;
			
			/* perform numerical operations */
			     if (op=='-') MATsum(varr, var1, var2, -1);
			else if (op=='+') MATsum(varr, var1, var2, 1);
			else if (op=='*') MATmul(varr, var1, var2);
			else return perror_(__LINE__,35,l);
		}
	}
	return TRUE;
}


/* matCopy(result-matrix, argument-matrix)
 * copy src argument matrix into dst result matrix;
 * dst: destination matrix
 * src: source matrix
 * Automatic redimension is performed in case target matrix can hold argument 
 * matrix dimensions */
int matCopy(int dst, int src){
	int i,j;
	/* source data */
	int ms=dim[src].row;
	int ns=dim[src].col;
	int ts=dim[src].type;
	/* destination data */
	int MD=dim[dst].row;
	int ND=dim[dst].col;
	int TD=dim[dst].type;

	/* existence of argument matrix var1 has already 
	 * been checked into MATtype() */

	/* check immediate compatibility */
	if (dst==src) return TRUE;
	if (ts!=TD || ts==0 || TD==0) return perror_(__LINE__,76,l);
	
	/* redimension */
	if (ms!=MD || ns!= ND) {
		if ((MD+1)*(ND+1)>=(dim[src].brow+1)*(dim[src].bcol+1)) {
			MD=dim[dst].row=dim[src].row;
			ND=dim[dst].col=dim[src].col;
		}
		else return perror_(__LINE__,76,l);
	}
	
	/* check compatibility */
	if (ms!=MD || ns!=ND) return perror_(__LINE__,76,l);

	/* copy (copy column 0 and row 0 too!) */
	if (ts==2) for (i=0;i<=ms;i++) for (j=0;j<=ns;j++) {
		setArrayVal(dst,TD,i,j,getArrayVal(src,ts,i,j));
	}
	else if (ts==1) for (i=0;i<=ms;i++) {
		setArrayVal(dst,TD,i,0,getArrayVal(src,ts,i,0));
	}
	return TRUE;
}


/* matStrCopy(result-matrix, argument-matrix)
 * copy src argument matrix into dst result matrix;
 * dst: destination matrix
 * src: source matrix
 * Automatic redimension is performed in case target matrix can hold argument 
 * matrix dimensions */
int matStrCopy(int dst, int src){
	int i,j;
	/* source data */
	int ms=dimS[src].row;
	int ns=dimS[src].col;
	int ts=dimS[src].type;
	/* destination data */
	int MD=dimS[dst].row;
	int ND=dimS[dst].col;
	int TD=dimS[dst].type;

	/* existence of argument matrix var1 has already 
	 * been checked into MATtype() */

	/* check immediate compatibility */
	if (dst==src) return TRUE;
	if (ts!=TD || ts==0 || TD==0) return perror_(__LINE__,76,l);
	
	/* redimension */
	if (ms!=MD || ns!= ND) {
		if ((MD+1)*(ND+1)>=(dimS[src].brow+1)*(dimS[src].bcol+1)) {
			MD=dimS[dst].row=dimS[src].row;
			ND=dimS[dst].col=dimS[src].col;
		}
		else return perror_(__LINE__,76,l);
	}
	
	/* check compatibility */
	if (ms!=MD || ns!=ND) return perror_(__LINE__,76,l);

	/* copy (copy column 0 and row 0 too!) */
	if (ts==2) for (i=0;i<=ms;i++) for (j=0;j<=ns;j++) {
		setArrayStr(dst,TD,i,j,getArrayStr(src,ts,i,j));
	}
	else if (ts==1) for (i=0;i<=ms;i++) {
		setArrayStr(dst,TD,i,0,getArrayStr(src,ts,i,0));
	}
	return TRUE;
}


/* MATFINPUT()
 * The MAT INPUT# wrapper
 * Multiple-matrices printing enabled */
int MATFINPUT(int isWrite) {
	int ch=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* print on file: get file channel */
	ch=(int)S();
	if (isEndOfStatement) return FALSE;
	if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
	if (*p==',' || *p==':') p++; // optional comma/colon
	if (!channel[ch].isopen) return perror_(__LINE__,80,l);

	/* delegate MATINPUT */
	MATINPUT(ch,isWrite);
	return TRUE;
}


/* MATINPUT()
 * The MAT INPUT statement
 * mode 1 is for numerical matrices, mode 2 for string matrices.
 * Multiple-matrices input enabled, each with its own question point, and
 * the ability to break the input and require a continuation adding & after 
 * the last input number */ 
int MATINPUT(int ch, int isWrite) {
	char line[COMPSCR], *u=line, *pp=p;
	int cs=0, mode=0, M=0, N=0, T=0, var=0;

	numValue=0; 
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get user input */
	if (!ch) {
		if (isPrompt) fprintf(stdout,INPUTS);
		p=pp; u=line; *u='\0';
		strncpy_(line,getString(),COMPSCR);
		if (!isEcho) fprintf(stdout,"\n");
		if ((int)strlen(line)>MAXSTRLEN) return perror_(__LINE__,124,l);
	}
	/* get file input */
	else {
		fgets(line,COMPSCR,channel[ch].stream);
		if ((int)strlen(line)>0) {
			if (line[(int)strlen(line)-1]=='\r')
				line[(int)strlen(line)-1]='\0';
			if (line[(int)strlen(line)-1]=='\n')
				line[(int)strlen(line)-1]='\0';
			if (line[(int)strlen(line)-1]=='\r')
				line[(int)strlen(line)-1]='\0';
		}
		numValue++;
		u=line;
		/* read line number and discard it */
		if (isWrite) {
			while (isblank(*u)) u++;
			if (isdigit(*u)) while (isdigit(*u)) u++;
			else return perror_(__LINE__,97,-1,l);
		}
	}
	
	/* get array type */
	while (isblank(*u)) u++;
	forceArray=TRUE;
	cs=findDEC(p);
	if (cs && _rettype==STR && _arr) var=cs, mode=2, p+=_len;
	else if (cs && _rettype==NUM && _arr) var=cs, p+=_len, mode=1;
	else return perror_(__LINE__,42,l);
	forceArray=FALSE;

	/* resizing values */
	if (*p=='(') {
		p++;
		M=(int)S();
		if (isEndOfStatement) return FALSE;
		N=0;
		T=1;
		if (*p==',') {
			p++;
			N=(int)S();
			if (isEndOfStatement) return FALSE;
			T=2;
		}
		if ((M+1)*(N+1)<=(dim[var].brow+1)*(dim[var].bcol+1)) {
			dim[var].row=M;
			dim[var].col=N;
			dim[var].type=T;
		}
		else return perror_(__LINE__,176,l);
		if (*p!=')') return perror_(__LINE__,37,l);
		else p++;
	}

	/* setup for horizontal arrays or normal matrices */
	if (mode==1) {
		T=dim[var].type; 
		if (!dim[var].row && dim[var].col) M=0, N=1;
		else M=1, N=1;
	}
	else {
		T=dimS[var].type;
		if (!dimS[var].row && dimS[var].col) M=0, N=1;
		else M=1, N=1;
	}

	/* INPUT a numerical vector */
	if (mode==1 && T==1 && *u) do {
		char *pp=p;
		double res;
		if (*u==',') u++;
		while (isblank(*u)) u++;
		/* asking for more in case of ampersand */
		if (!ch) {
			if (*u=='&') {
				if (isPrompt) fprintf(stdout,INPUTS);
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				if (!isEcho) fprintf(stdout,"\n");
			}
		}
		/* asking for more in case of file reading */
		else if (!*u) {
			if (fgets(line,COMPSCR,channel[ch].stream)) {
				if ((int)strlen(line)>0) {
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\n')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
				}
				u=line;
				/* read line number and discard it */
				if (isWrite) {
					while (isblank(*u)) u++;
					if (isdigit(*u)) 
						while (isdigit(*u)) u++;
					else return perror_(__LINE__,97,-1,l);
				}
			}
			else break;
		}
		while (isblank(*u)) u++;
		if (!*u) break;
		p=u; res=S();
		if (isEndOfStatement) return FALSE;
		setArrayVal(var,T,M,0,res);
		u=p; p=pp;
		M++;
		if (M>dim[var].row) break;
		numValue++;
		while (isblank(*u)) u++;
		if (*u==',') u++;
	} while (TRUE);
	/* INPUT from keyboard a numerical matrix or horizontal vector 
	 * Note: the MAT INPUT for a matrix works in this way: first item is 
	 * attributed to element at pos (1,1), the remaining are lined in 
	 * memory consecutively, excluding item at pos (0,X) or (X,0)
	 * Note: M and N go through the whole matrix/vector 
	 * Note: M is set to 0 in case of horizontal vector */
	else if (mode==1 && T==2 && *u) do {
		char *pp=p;
		double res;
		if (*u==',') u++;
		while (isblank(*u)) u++;
		/* asking for more in case of ampersand */
		if (!ch) {
			if (*u=='&') {
				fprintf(stdout," ?");
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				if (!isEcho) fprintf(stdout,"\n");
			}
		}
		/* asking for more in case of file reading */
		else if (!*u) {
			if (fgets(line,COMPSCR,channel[ch].stream)) {
				if ((int)strlen(line)>0) {
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\n')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
				}
				u=line;
				/* read line number and discard it */
				if (isWrite) {
					while (isblank(*u)) u++;
					if (isdigit(*u)) 
						while (isdigit(*u)) u++;
					else return perror_(__LINE__,97,-1,l);
				}
			}
			else break;
		}
		while (isblank(*u)) u++;
		if (!*u) break;
		p=u; res=S();
		if (isEndOfStatement) return FALSE;
		setArrayVal(var,T,M,N,res);
		u=p; p=pp;
		N++;
		if (N>dim[var].col) {
			M++;
			N=1;
			if (M>dim[var].row) break;
		}
		numValue++;
		while (isblank(*u)) u++;
		if (*u==',') u++;
	} while (TRUE);
	/* INPUT from keyboard a string vector */
	else if (*u && T==1) do {
		char op[COMPSTR], *P1;
		P1=op, *P1='\0';
		if (*u==',') u++;
		while (isblank(*u)) u++;
		/* asking for more in case of ampersand */
		if (!ch) {
			if (*u=='&') {
				fprintf(stdout," ?");
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				if (!isEcho) fprintf(stdout,"\n");
			}
		}
		/* asking for more in case of file reading */
		else if (!*u) {
			if (fgets(line,COMPSCR,channel[ch].stream)) {
				if ((int)strlen(line)>0) {
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\n')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
				}
				u=line;
				/* read line number and discard it */
				if (isWrite) {
					while (isblank(*u)) u++;
					if (isdigit(*u)) 
						while (isdigit(*u)) u++;
					else return perror_(__LINE__,97,-1,l);
				}
			}
			else break;
		}
		while (isblank(*u)) u++;
		if (!*u) break;
		/* grab next input string until comma or blank */
		if (*u!='\"') {
			while (*u && *u!=',' && *u!='&' &&!isblank(*u)) 
				*P1++=*u++;
			*P1='\0';
		}
		/* grab next input string until closing quotes */
		else {
			u++;
			while (*u && *u!='\"' && *u!='&') *P1++=*u++;
			*P1='\0';
			if (*u=='\"') u++;
			if (*u=='&') *--u=',';
			while (isblank(*u)) u++;
		}
		setArrayStr(var,T,M,0,op);
		M++;
		if (M>dimS[var].row) break;
		numValue++;
		while (isblank(*u)) u++;
	} while (TRUE);
	/* INPUT from keyboard a string matrix 
	 * Note: the MAT INPUT for a matrix works in this way: first item is 
	 * attributed to element at pos (1,1), the remaining are lined in 
	 * memory consecutively, including item at pos (X,1)
	 * Note: M and N go through the whole matrix/vector */
	else if (*u && T==2) do {
		char op[COMPSTR], *P1;
		P1=op, *P1='\0';
		if (*u==',') u++;
		while (isblank(*u)) u++;
		/* asking for more in case of ampersand */
		if (!ch) {
			if (*u=='&') {
				if (isPrompt) fprintf(stdout,INPUTS);
				u=line;
				*u='\0';
				strncpy_(line,getString(),COMPSCR);
				if (!isEcho) fprintf(stdout,"\n");
			}
		}
		/* asking for more in case of file reading */
		else if (!*u) {
			if (fgets(line,COMPSCR,channel[ch].stream)) {
				if ((int)strlen(line)>0) {
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\n')
						line[(int)strlen(line)-1]='\0';
					if (line[(int)strlen(line)-1]=='\r')
						line[(int)strlen(line)-1]='\0';
				}
				u=line;
				/* read line number and discard it */
				if (isWrite) {
					while (isblank(*u)) u++;
					if (isdigit(*u)) 
						while (isdigit(*u)) u++;
					else return perror_(__LINE__,97,-1,l);
				}
			}
			else break;
		}
		while (isblank(*u)) u++;
		if (!*u) break;
		/* grab next input string until comma or blank */
		if (*u!='\"') {
			while (*u && *u!=',' && *u!='&' && !isblank(*u)) 
				*P1++=*u++;
			*P1='\0';
		}
		/* grab next input string until closing quotes */
		else {
			u++;
			while (*u && *u!='\"' && *u!='&') *P1++=*u++;
			*P1='\0';
			if (*u=='\"') u++;
			if (*u=='&') *--u=',';
			while (isblank(*u)) u++;
		}
		setArrayStr(var,T,M,N,op);
		N++;
		if (N>dimS[var].col) {
			M++;
			N=1;
			if (M>dimS[var].row) break;
		}
		numValue++;
		while (isblank(*u)) u++;
	} while (TRUE);
	/* NUM returns the total number of items INPUT so far, even 
	 * those not used; so count remaining items (future usage) */
	if (*u && mode==1) {
		numValue++;
		while (*u) {
			if (*u==',') numValue++;
			u++;
		}
	}

	/* redo in case of comma */
	if (*p==',') p++;
	if (*p) MATINPUT(ch, isWrite);
	
	/* reset printing position */
	channel[0].fprintn=channel[0].fcounter=0;
	return TRUE;
}


/* MATREAD()
 * The MAT READ statement for DATA elements
 * Multiple-matrices reading enabled */
int MATREAD(void) {
	int cs, var=0, m=0, n=0, t=0, mode=0; // mode=0 => number, 1 => string
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);
	
	/* start loop on all MAT READ arrays */	
	do {
		mode=0;
		/* get variable code */
		forceArray=TRUE;
		cs=findDEC(p);
		if (cs && _rettype==NUM && _arr) 
			var=cs, p+=_len;
		else if (cs && _rettype==STR && _arr) 
			var=cs, p+=_len, mode=1;
		else return perror_(__LINE__,65,l,makechar(p+1),TERMINAT);
		forceArray=FALSE;
		
		/* resizing values */
		if (*p=='(') {
			p++;
			m=(int)S();
			if (isEndOfStatement) return FALSE;
			n=0;
			t=1;
			if (*p==',') {
				p++;
				n=(int)S();
				if (isEndOfStatement) return FALSE;
				t=2;
			}
			if ((m+1)*(n+1)<=(dim[var].brow+1)*(dim[var].bcol+1)) {
				dim[var].row=m;
				dim[var].col=n;
				dim[var].type=t;
			}
			else return perror_(__LINE__,176,l);
			if (*p!=')') return perror_(__LINE__,37,l);
			else p++;
		}

		/* READ numerical array */
		if (!mode && _rettype==NUM) {
			int ern=0;
			if (dataLimit==0) return perror_(__LINE__,50,l);
			/* use implicit data */
			else if (*p=='\0' || *p==',') {
				m=dim[var].row;
				n=dim[var].col;
			}
			else return perror_(__LINE__,34,l);
	
			/* assign DATA values */
			ern=matReadAssign(var,dim[var].type,m,n);
			if (ern>0) perror_(__LINE__,ern,l);	
		} 
		/* READ string array */
	
		else if (_rettype==STR) {
			int ern=0;
			if (dataLimitS==0) return perror_(__LINE__,50,l);
			/* use implicit data */
			else if (*p=='\0' || *p==',') {
				m=dimS[var].row;
				n=dimS[var].col;
			}
			else return perror_(__LINE__,34,l);

			/* assign DATA values */
			ern=matStrReadAssign(var,dimS[var].type,m,n);
			if (ern>0) perror_(__LINE__,ern,l);	

		}
		else return perror_(__LINE__,34,l);
	} while (*p++==',');
	return TRUE;
}


/* WFCR()
 * print a carriage return doing the MAT WRITE line
 * prepending a five digits number followed by a tab */
void WFCR(int ch, int isWrite) {
	FCR(ch);
	if (isWrite && ch) { 
		fprintf(channel[ch].stream,"%05d\t",writeSeqStart);
		writeSeqStart+=writeSeqStep;
	}
}


/* MATFPRINT()
 * The MAT PRINT# wrapper
 * Multiple-matrices printing enabled */
int MATFPRINT(int isWrite) {
	int ch=0;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* print on file: get file channel */
	ch=(int)S();
	if (isEndOfStatement) return FALSE;
	if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
	if (*p==',' || *p==':') p++; // optional comma/colon
	if (!channel[ch].isopen) return perror_(__LINE__,80,l);

	/* delegate MATPRINT */
	MATPRINT(ch, isWrite);
	return TRUE;
}


/* MATPRINT()
 * The MAT PRINT statement 
 * Multiple-matrices printing enabled */
int MATPRINT(int ch, int isWrite) {
	int var=0, m=0, n=0, t=0;	// matrix data
	int mode=0, ma;			// mode=TRUE=string array, ma=margin
	int cs,i,j;			// counters
	char outstr[COMPSTR];
	static int spacing=0;		// 1=comma, 2=semicolon, 0=vertical

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* resolve irregular format */
	if (!isbeginnamechar(p)) return perror_(__LINE__,35,l);

	/* get variable codes */
	forceArray=TRUE;
	cs=findDEC(p);
	if (cs && _arr &&_rettype==NUM) var=cs, p+=_len;
	else if (cs && _arr && _rettype==STR) var=cs,mode=1,p+=_len;
	else return perror_(__LINE__,42,l);
	forceArray=FALSE;
	if (*p==',') spacing=1,p++;
	else if (*p==';') spacing=2, p++;

	/* print starting WRITE line */
	if (isWrite && ch) { 
		fprintf(channel[ch].stream,"%05d\t",writeSeqStart);
		writeSeqStart+=writeSeqStep;
	}

	/* PRINT a string array */
	if (mode) {
		/* store string matrix/vector basic data */
		t=dimS[var].type;
		m=dimS[var].row;
		n=dimS[var].col; 
		ma=channel[ch].margin;

		/* print a string vector */
		if (t==1) {
			i=1;
			do {
				strncpy_(outstr,getArrayStr(var,t,i,0),COMPSTR);
				if (outstr[0]) 
					fprintf(channel[ch].stream,"%s",outstr);
				else {
					if (phantomString) {
						fprintf(channel[ch].stream,"%s",NULLS);
					}
					else
						fprintf(channel[ch].stream,"%s","");
				}
				/* add a separator space */
				if (isSpacing) 
					fprintf(channel[ch].stream," ");
				if (spacing==1) { 
					while (channel[ch].fcounter%ZONE) 
						FAC(ch);
				}
				else if (!spacing) WFCR(ch,isWrite);
				if (channel[ch].fcounter>ma) WFCR(ch,isWrite);
				i++;
			} while (i<=m);
			if (spacing>0) FCR(ch);
			FCR(ch);
		}
		/* print a horizontal string vector */
		else if (!m && n) {
			i=1;
			do {
				strncpy_(outstr,getArrayStr(var,t,0,i),COMPSTR);
				if (outstr[0]) 
					fprintf(channel[ch].stream,"%s",outstr);
				else { 
					if (phantomString)
						fprintf(channel[ch].stream,"%s",NULLS);
					else
						fprintf(channel[ch].stream,"%s","");
				}
				/* add a separator space */
				if (isSpacing) 
					fprintf(channel[ch].stream," ");
				if (spacing<2) { 
					while (channel[ch].fcounter%ZONE) 
						FAC(ch);
				}
				if (channel[ch].fcounter>ma) WFCR(ch,isWrite);
				i++;
			} while (i<=n);
			FCR(ch);
			FCR(ch);
		}
		/* print a string matrix */
		else {
			i=1;
			do {
				j=1;
				do {
				   strncpy_(outstr,getArrayStr(var,t,i,j),COMPSTR);
				   if (outstr[0]) 
					   fprintf(channel[ch].stream,"%s",outstr);
				   else { 
					if (phantomString)
						fprintf(channel[ch].stream,"%s",NULLS);
					else
						fprintf(channel[ch].stream,"%s","");
				   }
				   /* add a separator space */
				   if (isSpacing) 
					   fprintf(channel[ch].stream," ");
				   if (channel[ch].fcounter>ma)WFCR(ch,isWrite);
				   if (spacing!=2) { 
				      while(channel[ch].fcounter%ZONE) FAC(ch);
				   }
				   if (channel[ch].fcounter>ma)WFCR(ch,isWrite);
				   j++;
				} while (j<=n);
				i++;
				if (i<=m) WFCR(ch,isWrite);
			} while (i<=m);
			FCR(ch);
			FCR(ch);
		}
	}

	/* PRINT a numerical array/matrix */
	else {
		/* get numeric matrix/vector elements */
		t=dim[var].type;
		m=dim[var].row;
		n=dim[var].col;
		ma=channel[ch].margin;
		
		/* print a numeric vector */
		if (t==1) {
			i=1;
			do {
				channel[ch].fcounter=printNUM(ch,getArrayVal(var,t,i,0),0,NIL);
				if (spacing==1) {
				      while (channel[ch].fcounter%ZONE) FAC(ch);
				}
				else if (!spacing) WFCR(ch,isWrite);
				if (channel[ch].fcounter>ma) WFCR(ch,isWrite);
				i++;
			} while (i<=m);
			if (spacing>0) FCR(ch);
			FCR(ch);
		}
		/* print a numeric horizontal vector */
		else if (!m && n) {
			i=1;
			do {
				channel[ch].fcounter=printNUM(ch,getArrayVal(var,t,0,i),0,NIL);
				if (spacing<2) {
					while (channel[ch].fcounter%ZONE) 
						FAC(ch);
				}
				if (channel[ch].fcounter>ma) 
					WFCR(ch,isWrite);
				i++;
			} while (i<=n);
			FCR(ch);
			FCR(ch);
		}
		/* print a numeric matrix */
		else {
			i=1;
			do {
				j=1;
				do {
					channel[ch].fcounter=printNUM(ch,getArrayVal(var,t,i,j),0,NIL);
					if (channel[ch].fcounter>ma)
						WFCR(ch,isWrite);
					if (spacing!=2) { 
					     while(channel[ch].fcounter%ZONE) 
						FAC(ch);
					}
					if (channel[ch].fcounter>ma)
						WFCR(ch,isWrite);
					j++;
				} while (j<=n);
				i++;
				if (i<=m) WFCR(ch,isWrite);
			} while (i<=m);
			FCR(ch);
			FCR(ch);
		}
	}
	
	/* if there's something else to print, recall MATPRINT again 
	 * or close operations resetting data */
	if (*p==',' || *p==';') p++;
	if (*p) MATPRINT(ch,isWrite);
	else spacing=0;
	return TRUE;
}


/****************************************************************************** 
 * The following routines define the behavior of the statements involved with 
 * the CHANGE statement;
 * the CHANGE statement was included since 1967 version IV (not including the 
 * add-on variation CHANGE..TO..BIT, which appeared in 1969 version V). 
 ******************************************************************************/


/* CHANGE() 
 * The CHANGE statement
 * convert the explicit string (a variable or a constant enclosed into 
 * parentheses) to the series of ASCII character it's composed of, and store it 
 * into the vector specified after TO;
 * convert also the vector which holds the string data to the string variable
 * specified after TO. 
 * The vector need not to be dimensioned if the string is shorter than 10 
 * characters (pos. 0 holds the length, pos. 1 through 10 hold the string), but
 * if it's longer it must be declared, otherwise an error will be raised 
 * Note: the CHANGE statement accepts any kind of strings as argument, even any
 * DECLAREd string, but not string arrays elements */
int CHANGE(void) {
	char op[COMPSTR], *P1=op;
	int var=0, varS=0, len, cs;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	forceArray=TRUE;
	/* in case first argument is a numerical variable (which stands for 
	 * the array name) perform CHANGE vector TO string */
	if ((cs=findDEC(p)) && _arr && _rettype==NUM) {
		int c,val;

		/* get var name */
		forceArray=FALSE;
		var=cs, p+=_len;

		/* check vector existence and dimension 
		 * (only unidimensional vectors are valid) */
		if (dim[var].type==2) return perror_(__LINE__,62,l);
		
		/* check syntax */
		if (bcomp(p,"TO")) p+=4;
		else return perror_(__LINE__,38,l);

		/* check if a string variable is used */
		cs=findDEC(p);
		if (cs) {
			if (vn[cs].isArr) return perror_(__LINE__,93,l);
			if (vn[cs].rettype!=STR) return perror_(__LINE__,106,l);
			varS=cs;
		}
		
		/* fill string if len was correct
		 * (in general, error 90 depends on a file corruption) */
		len=(int)getArrayVal(var,1,0,0);
		if (len>=MAXSTRLEN) len=MAXSTRLEN;
		else if (len<=0) return perror_(__LINE__,90,l);
		for (c=0; c<len; c++) {
			val=getArrayVal(var,1,c+1,0);
			/* Note; illegal character is a negative val, here */
			if (val<0) return perror_(__LINE__,87,l);
			PS[varS][+c]=val;
		}
		PS[varS][len]='\0';
	}
	
	/* otherwise perform CHANGE string TO vector */
	else {
		int i=0;
		forceArray=FALSE;

		/* get string variable code */
		if ((cs=findDEC(p)) && !_arr && _rettype==STR) var=cs;
		else if (isanystring(p));
		else return perror_(__LINE__,93,l);
		
		/* store string 
		 * Note: tbas is able of reading here string arrays elements 
		 * too, but for uniformity with the CHANGE vector TO string 
		 * feature, only string variables are allowed here. */
		*P1='\0';
		strncpy_(op,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		len=(int)strlen(op);
		/* check syntax */
		if (bcomp(p,"TO")) p+=4;
		else return perror_(__LINE__,38,l);
		
		/* check if a string variable is used */
		forceArray=TRUE;
		cs=findDEC(p);
		if (cs) {
			if (vn[cs].rettype!=NUM) return perror_(__LINE__,106,l);
			if (!vn[cs].isArr && dim[cs].type!=2) 
				return perror_(__LINE__,62,l);
		}
		forceArray=FALSE;

		/* get vector code */
		if (cs) var=cs, p+=_len;
		else return perror_(__LINE__,62,l);

		/* check vector existence and dimension 
		 * (only unidimensional vectors are valid) */
		if (dim[var].type==2) return perror_(__LINE__,76,l);
		if (len>dim[var].row) return perror_(__LINE__,106,l);
	
		/* do the string conversion, storing in 0 string length */
		setArrayVal(var,1,i++,0,len);
		while (*P1) {
			setArrayVal(var,1,i++,0,*P1++);
		}
	}
	return TRUE;
}


/******************************************************************************
 * The following routines define the remaining standard BASIC statements;
 * most were present in BASIC since 1964 (apart from PRINT, which has been
 * reunited with PRINT#/WRITE#) but many (above all loops and cycles) have been 
 * introduced after the quick BASIC language defined a sort of standard for 
 * the BASIC language after 1985, when it was introduced for DOS.
 ******************************************************************************/

/* EXITSUB()
 * the EXIT SUB statement to exit prematurely from a subroutine 
 * Note: if the subroutine is a function, and the return value is not
 * yet been calculated, a warning is printed */
int EXITSUB(void) {
	if (!isSubRun) return perror_(__LINE__,221,l);
	if (!isSubCalc && sn[isSubVar].type==FUNC) 
		perror_(__LINE__,220,l); // warning
	l=sn[isSubVar].end;
	
	/* restore SUB cycle and decisional structures */
	ifTOS=subBackup[XCount].ifTOS;
	selectTOS=subBackup[XCount].selectTOS;
	selectcount=subBackup[XCount].selectcount;
	whileTOS=subBackup[XCount].whileTOS;
	whilecount=subBackup[XCount].whilecount;
	doTOS=subBackup[XCount].doTOS;
	docount=subBackup[XCount].docount;
	forTOS=subBackup[XCount].forTOS;
	forcount=subBackup[XCount].forcount;
	
	return TRUE;
}


/* _RETURNTOSUB() 
 * the RETURN statement for SUB 
 * Not to be confused with the RETURN statement for the GOSUB/RETURN feature 
 * Note: the RETURN statement into SUB does not work as the return command 
 * in C or other similar languages; whereas in those language 'return' exit
 * immediately from the function, RETURN here is a mere return-value-storage;
 * any time it is met into SUB, the return value is stored, and will be
 * returned when out of SUB (for function, not procedures). To specifically
 * exit after a return, use it in conjunction with EXIT SUB */
int _RETURNTOSUB(void) {
	if (sn[isSubVar].type==FUNC && sn[isSubVar].rettype==NUM) {
		sn[isSubVar].numres=S();
		if (isEndOfStatement) return FALSE;
	}
	else if (sn[isSubVar].type==FUNC && sn[isSubVar].rettype==STR) {
		if (sn[isSubVar].strres!=NIL && sn[isSubVar].strres[0]) {
			free(sn[isSubVar].strres);
			sn[isSubVar].strres=NIL;
		}
		sn[isSubVar].strres=xmalloc((size_t)COMPSTR);
		if (!sn[isSubVar].strres) return perror_(__LINE__,195,l);
		else strncpy_(sn[isSubVar].strres,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
	}
	else return perror_(__LINE__,216,l);
	isSubCalc=TRUE;
	return TRUE;
}


/* EXPORT()
 * the EXPORT statement 
 * marks the variable in the list as exportable; at the end of the SUB
 * they won't be overwritten.
 * Note: if a global variable is set as to be EXPORTED, nothing happens 
 * Note: if an undeclared variable is set as to be EXPORTED, it is created 
 * as new*/
int EXPORT(void) {
	int cs;

	/* EXPORT cannot be used in main or into a DEF FN */
	if (isDefRun || !isSubRun) return perror_(__LINE__,201,l);

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* export all in one turn 
	 * Note: if ALL is followed by something else (a letter, a number, the 
	 * comma), it is not interpreted as the ALL  token, but is left to the 
	 * rest of the algorithm to find if it's an any-name variable beginning 
	 * with ALL */
	if (!strncasecmp_(p,"ALL",3) && !*(p+3)) {
		saveSubCount[XCount]=decCount;
		p+=3;
		return TRUE;
	}

	/* check variable list and set mask */
	while (*p) {
		cs=findDEC(p);
		/* main-DECLARE variables 
		 * Note: these variables need not any rearranging */
		if (cs && cs<=saveSubCount[XCount] && !vn[cs].isArr){
			p+=_len;
		}
		/* sub-DECLARE variables 
		 * Note: in order to EXPORT these variables, they need to
		 * be rearranged: the chosen variable, if not already set
		 * as the first variable after saveSubCount, is swapped
		 * with the variable in that place; subsequently, the
		 * saveSubCount index is incremented to include the new
		 * swapped variable in the caller world */
		else if (cs && cs>saveSubCount[XCount] && !vn[cs].isArr){
			int dd=saveSubCount[XCount]+1;
			/* swap vn structure and values */
			if (cs>dd) swapDEC(cs,dd); // avoid cs=dd
			saveSubCount[XCount]++;
			p+=_len;
		}
		/* main DECLARE arrays 
		 * Note: these variables need not any rearranging */
		else if (cs && cs<=saveSubCount[XCount] && vn[cs].isArr) {
			p+=_len;
			if (!strncmp(p,"()",2)) p+=2;
		}
		/* sub-DECLARE arrays 
		 * Note: see sub-DECLARE variables process */
		else if (cs && cs>saveSubCount[XCount] && vn[cs].isArr) {
			int dd=saveSubCount[XCount]+1;
			/* swap vn structure and values */
			if (cs>dd) swapDEC(cs,dd); // avoid cs=dd
			p+=_len;
			saveSubCount[XCount]++;
			/* the () token is optional */
			if (!strncmp(p,"()",2)) p+=2;
		}

		/* check syntax: if there's something else not recognized,
		 * it's a global variable or a not existing name*/
		if (*p && *p!=',' && *p!=';') return perror_(__LINE__,37,l);
		else if (*p) p++;
	}
	return TRUE;
}


/* LINPUT()
 * The LINPUT#/LINE INPUT# statements */
int LINPUTSHARP(void) {
	int ch, done=1, var=0, isArr=FALSE, type=NUM;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get channel and make checks */
	ch=(int)S();
	if (isEndOfStatement) return FALSE;
	if (ch<1 || ch>STREAMS) return perror_(__LINE__,133,l);
	if (*p==',' || *p==':') p++;
	else return perror_(__LINE__,38,l);
	if (!channel[ch].isopen) return perror_(__LINE__,69,l);
	if (channel[ch].type!=SEQ) return perror_(__LINE__,101,l);

	/* checks if sequential file is in WRITE mode, which is an error */
	if (channel[ch].wayout==VWRITE) return perror_(__LINE__,70,l);
	
	/* checks if end of file */
	if (testEOF(ch)) return perror_(__LINE__,25,l);
		
	/* repeat for all variables */
	do {
		int cs;
		char op[COMPSTR];
		double val=0.0;
		
		/* restore parameters */
		isArr=FALSE,type=NUM;

		/* is it an existing variable? */
		if ((cs=findDEC(p))) {
			var=cs, p+=_len;
			type=vn[cs].rettype;
			isArr=vn[cs].isArr;
		}
		else return perror_(__LINE__,42,l);

		/* proceed reading lines until the right one */
		while (fgets(op,COMPSTR,channel[ch].stream)) {
			/* depure from END-OF-LINE codes*/
			if (op[strlen(op)-1]=='\n') op[strlen(op)-1]=0;
			if (op[strlen(op)-1]=='\r') op[strlen(op)-1]=0;
			if (op[strlen(op)-1]=='\n') op[strlen(op)-1]=0;
	
			/* accept or not the empty line basing on OPTION 
			 * IGNOREEMPTYLINES */
			if (!isIgnoreEmptyLines) break;
			else {
				if (op[0]) break;
			}
		}

		/* string variable */
		if (!isArr && type==STR) strncpy_(PS[var],op,COMPSTR);
		/* string array */
		else if (isArr) {
			int M=0, N=0, T=1;
			if (*p=='(') p++;
			else return perror_(__LINE__,37,l);
			M=(int)S();
			if (isEndOfStatement) return FALSE;
			if (*p==',') {
				p++;
				N=(int)S();
				if (isEndOfStatement) return FALSE;
				T=2;
			}
			p++;
			if (vn[var].isInt) val=(int)val;
			if (type==NUM) {
				setArrayVal(var,T,M,N,val);
			}
			else {
				setArrayStr(var,T,M,N,op);
			}
		}
		else return perror_(__LINE__,218,l);
		if (*p==',') p++;
		if (!*p) break;

	} while (*p && done);

	return TRUE;
}


/* INPUT()
 * The INPUT/LINPUT statements
 * if mode is 1 perform INPUT, if 0 perform LINPUT/LINEINPUT (get line up to 
 * EOL) */
int INPUT(int mode) {
	char line[SCREENLINE+1], *u=line, *pb=p;
	int done=1, var=0, isArr=FALSE, type=NUM;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* detect a possible LINPUT: statement */
	if (*p==':') return perror_(__LINE__,92,l);

	/* input welcome string in the form INPUT "prompt";<varlist>
	 * only quoted strings are accepted */
	if (*p=='\"') {
		p++; // skip first "
		while (*p!='\"') fprintf(stdout,"%c", *p++);
		p++; // skip last "
		if (*p==',' || *p==';') p++;
		pb=p; // updating
	}

redo:
	/* get user input and store it into u
	 * the "?" character is printed only in case of true isPrompt*/
	*u='\0'; u=line;
	if (isPrompt) fprintf(stdout,INPUTS);
	strncpy_(line,getString(),COMPSCR);
	if ((int)strlen(line)>MAXSTRLEN) return perror_(__LINE__,124,l);
	if (!isEcho) fprintf(stdout,"\n");

	/* repeat for all variables */
	do {
		int cs;
		char op[COMPSTR], *P1=op;
		double val=0.0;
		
		/* restore parameters */
		isArr=FALSE,type=NUM;

		/* there's another input string: recap */
		if (*p=='\"') {
			INPUT(mode);
			return TRUE;
		}
		/* or is it an existing variable? */
		else if ((cs=findDEC(p))) {
			var=cs, p+=_len;
			type=vn[cs].rettype;
			if (*p=='(') isArr=TRUE;
			else isArr=FALSE;
		}
		else return perror_(__LINE__,42,l); 

		/* get numerical value
		 * Note: in the following case, for numerical variables
		 * and numerical arrays, I use S() and not strtol, so any 
		 * formula may be used with INPUT. Numbers may also exceed 
		 * the 8 digits limit and be in any format */
		if (type==NUM) {
			char *pp=p;
			p=u;
			val=S();
			if (isEndOfStatement) return FALSE;
			u=p;
			p=pp;
		}
		/* get string value */
		else {
			P1=op; *P1='\0';
			/* INPUT mode */
			if (mode) {
				/* INPUT: grab string until comma */
				if (*u!='\"') {
					while (*u && *u!=',') *P1++=*u++;
					*P1='\0';
				}
				/* INPUT: grab string until closing quotes */
				else {
					u++;
					while (*u && *u!='\"') *P1++=*u++;
					*P1='\0';
					if (*u=='\"') u++;
				}
			}
			/* LINPUT mode */
			else {
				/* LINPUT: grab string until EOL */
				while (*u && *u!='\n') *P1++=*u++;
				*P1='\0';
			}
		}

		/* numeric variable */
		if (!isArr && type==NUM){
			if (vn[var].isInt) P[var]=(int)val;
			else P[var]=val;
		}
		/* string variable */
		else if (!isArr && type==STR) strncpy_(PS[var],op,COMPSTR);
		/* numeric or string array */
		else if (isArr) {
			int M=0, N=0, T=1;
			if (*p=='(') p++;
			else return perror_(__LINE__,37,l);
			M=(int)S();
			if (isEndOfStatement) return FALSE;
			if (*p==',') {
				p++;
				N=(int)S();
				if (isEndOfStatement) return FALSE;
				T=2;
			}
			p++;
			if (vn[var].isInt) val=(int)val;
			if (type==NUM) {
				setArrayVal(var,T,M,N,val);
			}
			else {
				setArrayStr(var,T,M,N,op);
			}
		}
		else done=0;
		if (*p==',') p++;
		if (!*p) break;

		while (*u && *u!=',') u++;
		if (*u==',') u++;
		while (isblank(*u)) u++;
		/* if user input is over, but there are still variables
		 * to be filled, get another user input */
		if (*p && *p!='\"' && !*u) {
			int i;
			u=line;
			for(i=0;i<SCREENLINE;i++) line[i]='\0';
			if (isPrompt) fprintf(stdout,INPUTS);
			strncpy_(line,getString(),COMPSCR);
		}
	} while (*p && done);

	/* redo in case of any mistaken input, resetting parameters */
	if (!done) {
		perror_(__LINE__,91,l); // warning
		/* reset values for repeating */
		p=pb;
		u=line;
		done=1;
		goto redo;
	}

	/* reset printing position */
	channel[CONSOLE].fprintn=channel[CONSOLE].fcounter=0;
	return TRUE;
}


/* RANDOMIZE()
 * perform the RANDOMIZE statement.
 * The algorithm (depending from current time) is the following:
 *   - divide current 'usec' measure with the sum of the value obtained summing 
 *     months (12), days (31), hours (23), minutes (59) and seconds (59), which 
 *     always gives 184;
 *   - divide this value (always in the range [1,184]) with the logarithm of 
 *     276.00 which is 184.00x1.5, obtaining a value between 0.177923252 and 
 *     32.73787838, a range with medium value 16.45790082, the starting default
 *     value of the getRandom() function 
 * Used in conjunction with the getRandom() function. */
int RANDOMIZE(void) {
	int b;
	gettimeofday(&tv, NULL);
       	b = tv.tv_usec%184;
	rand2Seed=b/LOG276;
	return TRUE;
}


/* ONGOTO()
 * The ON..GOTO/ON..THEN/ON..GOSUB statements */
int ONGOTO(void) {
	int addr[ONLIM], ac=0;
	int val=0, isOtherwise=FALSE, tempad=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* reset references */
	for (val=0; val<ONLIM; val++) addr[val]=0;
	
	/* take the integer control value */
	val=S();
	if (isEndOfStatement) return FALSE;
	/* check for a valid value */
	if (isDefRun) {
		if (val<=fn[isDefVar].start || val>fn[isDefVar].end+1)
			return perror_(__LINE__,188,l,isDefVar,val);
	}
	else if (isSubRun) {
		if (val<=sn[isSubVar].start || val>sn[isSubVar].end)
			return perror_(__LINE__,189,l,\
				sn[isSubVar].name[0]?sn[isSubVar].name:"-",\
				val);
	}

	/* perform ON GOTO */
	if (bcomp(p,"GOTO")) {
		int v=0;
		p+=6;
		/* at least an address must be given */
		if (!*p) return perror_(__LINE__,35,l);
		addr[ac++]=getLabelAddr(p,&p); // first address
		while (*p==',') {
			p++;
			if (bcomp(p,"OTHERWISE")) {
				p+=11,isOtherwise=TRUE;
				addr[ac++]=getLabelAddr(p,&p);
				break;
			}
			addr[ac++]=getLabelAddr(p,&p);
		}
		/* go to OTHERWISE */
		if (val>ac || val<1) {
			/* ON..GOTO overflow causes a halt if no OTHERWISE
			 * was specified */
			if (!isOtherwise) return perror_(__LINE__,109,l);
			else {
				v=addr[ac-1];
				if (norow(v)) return perror_(__LINE__,61,l);
				l=v-1;
			}
		}
		/* goto to nth address */
		else {
			v=addr[val-1];
			if (norow(v)) return perror_(__LINE__,61,l);
			l=v-1;
		}
	}
	/* perform ON THEN */
	else if (bthencomp(p)) {
		int v=0;
		p+=5;
		if (isblank(*p)) p++;
		/* at least an address must be given */
		if (!*p) return perror_(__LINE__,35,l);
		addr[ac++]=getLabelAddr(p,&p); // first address
		while (*p==',') {
			p++;
			if (bcomp(p,"OTHERWISE")) {
				p+=11,isOtherwise=TRUE;
				addr[ac++]=getLabelAddr(p,&p);
				break;
			}
			addr[ac++]=getLabelAddr(p,&p);
		}
		/* go to OTHERWISE */
		if (val>ac || val<1) {
			/* ON..GOTO overflow causes a halt if no OTHERWISE
			 * was specified */
			if (!isOtherwise) return perror_(__LINE__,109,l);
			else {
				v=addr[ac-1];
				if (norow(v)) return perror_(__LINE__,61,l);
				l=v-1;
			}
		}
		/* goto to nth address */
		else {
			v=addr[val-1];
			if (norow(v)) return perror_(__LINE__,61,l);
			l=v-1;
		}
	}
	/* perform ON GOSUB */
	else if (bcomp(p,"GOSUB")) {
		p+=7;
		/* at least an address must be given */
		if (!*p) return perror_(__LINE__,35,l);
		addr[ac++]=getLabelAddr(p,&p);
		while (*p==',') {
			p++;
			if (bcomp(p,"OTHERWISE")) {
				p+=11,isOtherwise=TRUE;
				addr[ac++]=getLabelAddr(p,&p);
				break;
			}
			addr[ac++]=getLabelAddr(p,&p);
		}

		/* ON..GOSUB overflow  */
		if (val>ac || val<1) {
			/* ON..GOSUB overflow causes a halt if no OTHERWISE
			 * was specified */
			if (!isOtherwise) return perror_(__LINE__,109,l);
			else tempad=addr[ac-1];
		}
		else tempad=addr[val-1];
		gosubStack[++gosubTOS]=l;
		l=tempad-1;
	}
	else return perror_(__LINE__,35,l);
	return TRUE;
}


/* IFTHEN()
 * The IF..THEN/IF..GOTO statements, and treat the IF-THEN part of the
 * IF-THEN/ELSE/ELSEIF/ENDIF clause
 * Note: THEN and GOTO are perfectly interchangeable */
int IFTHEN(void) {
	int flag=0;
	static char *el; // ELSE position in a one line code
	el=NULL; // reset ELSE

	/* search for ELSE */
	if ((el=strcasestr_oq(p," ELSE "))) *el='\0', el+=6; // skip ELSE
	
	/* get IF..THEN condition status from a string relation or 
	 * from a numerical expression */
	flag=(int)S(); // formula-by-value enabled
	if (isEndOfStatement) return FALSE;
	
	/* perform THEN which can execute addresses and statements */
	if (bthencomp(p)) {
		p+=5;
		if (isblank(*p)) p++;
		/* treat number (destination) */
		if (isdigit(*p)) { 
			if (flag) GOTO(); 
			/* the ELSE clause may be followed by a number
			 * or a direct execution */
			else if (el) {
				p=el;
				if (isdigit(*p)) GOTO();
				else {
					strncpy_(parseSpace,p,COMPSTR);
					parseLine(parseSpace,l);
				}
			}
		}
		/* treat multiline instructions (THEN/ELSE) */
		else if (!*p) {
			if (flag) ifStack[++ifTOS]=CASEEND;
			else {
				ifStack[++ifTOS]=CASEVALUE;
				l=ifAddr[l]-1; // jump to next ELSE/END
			}
		}
		/* treat direct execution */
		else {
			if (flag) {
				strncpy_(parseSpace,p,COMPSTR);
				parseLine(parseSpace,l);
			}
			/* the ELSE clause may be followed by a direct 
			 * execution or by a number */
			else if (el) {
				p=el;
				if (isdigit(*p)) GOTO();
				else {
					strncpy_(parseSpace,p,COMPSTR);
					parseLine(parseSpace,l);
				}
			}
		}
	}
	/* perform GOTO, which can only jump to addresses */
	else if (bcomp(p,"GOTO")) {
		p+=6;
		if (flag) GOTO();
	}
	/* otherwise it's an incorrect IF */
	else return perror_(__LINE__,36,l);
	return TRUE;
}


/* ELSEIF() 
 * The ELSE IF execution 
 * if in the stack there's a CASEEND, relative statement have been already 
 * executed, so jump to END IF;
 * if otherwise in the stack there's an CONTINUE, call IFTHEN to proceed */ 
int ELSEIF(void) {
	if (ifTOS<1) return perror_(__LINE__,206,l);
	/* jump to END IF in case of true condition (THEN clause) */
	if (ifStack[ifTOS]==CASEEND) l=ifAddr[l]-1;
	else {
		ifTOS--; // decrease because IFTHEN increases
		IFTHEN();
	}
	return TRUE;
}


/* ELSE()
 * The ELSE execution 
 * if in the stack there's a CASEEND, relative statement have been already 
 * executed, so jump to END IF;
 * if otherwise in the stack there's a CONTINUE, do nothing */
int ELSE(void) {
	if (ifTOS<1) return perror_(__LINE__,206,l);
	/* jump to END IF in case of true condition (THEN clause) */
	if (ifStack[ifTOS]==CASEEND) l=ifAddr[l]-1;
	return TRUE;
}


/* ENDIF()
 * the ENDIF execution
 * its task is merely to clear the stack position of the current IF-ENDIF 
 * level clause, leaving the underlying levels untouched */
int ENDIF(void) {
	if (ifTOS<1) return perror_(__LINE__,207,l);
	/* pop (clear) */
	ifTOS--;
	return TRUE;
}


/* GOTO()
 * The GOTO Statement
 * called also by IF..THEN when followed by any address */
int GOTO(void){
        int num;
        
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

        /* check if destination is legal (the number may be a formula) 
	 * Note: the control to a self call is not done, so the control is 
	 * left to the BASIC programmer */
	num=getLabelAddr(p,&p);
	if (norow(num)) return perror_(__LINE__,61,l);

	/* A jump outside of a multi-line DEF (from inside) is forbidden */
	if (isDefRun) {
		if ((num<fn[isDefVar].start)||(num>(fn[isDefVar].end+1)))
			return perror_(__LINE__,39,l);
	}
	else if (fm[num]) return perror_(__LINE__,39,l);
	
	/* Note: a jump from inside a SUB to outside a SUB or from inside
	 * a cycle to outside the same cycle is not strictly forbidden,
	 * but the programmer must know what is being done (and wishingly
	 * make a jump back to restore pointers), except for the FOR..NEXT
	 * cycle, to let tbas be compatible with the DEC BASIC compiler.
	 * Note: this subject is not described in the LBMAA-A-D but I
	 * tested on the LCM that a jump out of a FOR cycle (one or more)
	 * is possible, and no warnings or error messages are shown. */
	while (forcount && (num<forStack[forTOS-4]-1||num>forStack[forTOS-5])){
		forTOS -= 6;
		forcount-=1;
		if (isDefRun) isDefFor--;
	}

	/* jump! */
	l=num-1;
	return TRUE;
}


/* GOSUB()
 * The GOSUB Statement */
int GOSUB(void){
        int num;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* check if GOSUB is within a DEF FN */
	if (isDefRun || isSubRun) return perror_(__LINE__,30,l);

	/* check if destination is legal
	 * The number may be a formula */
	num=getLabelAddr(p,&p);
	if (norow(num)) return perror_(__LINE__,61,l);
	if (fm[num]) return perror_(__LINE__,39,l);

	/* check if GOSUB calls itself */
	if (isARing(num)) return perror_(__LINE__,126,l);

	/* perform GOSUB and check GOSUB stack depth */
        gosubStack[++gosubTOS]=l;
	if (gosubTOS >= LIMIT) return perror_(__LINE__,196,l); 
	l=num-1;
	return TRUE;
}


/* _RETURN()
 * The RETURN Statement */ 
int _RETURN(void){
	/* RETURN without GOSUB? */
        if (gosubTOS<=0) return perror_(__LINE__,118,l);
	/* check if RETURN is within a DEF FN */
	if (isDefRun || isSubRun) return perror_(__LINE__,54,l);
        /* restore pointers */
        l=gosubStack[gosubTOS--];
	return TRUE;
}


/* WHILE()
 * The WHILE Statement */
int WHILE(void) {
        int nextstep=0, cond;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* make checks and calculate condition value */
	if (whilecount >= FORLIM) return perror_(__LINE__,53,l);
	if (isanystring(p)) cond=strRel();
	else cond=(int)S();
	if (isEndOfStatement) return FALSE;
	if (*p) return perror_(__LINE__,35,l);
	
	/* the search for closing END WHILE matching the variable 
	 * was done in preParse() and stored into whileAddr[] */
	nextstep=whileAddr[l];

	/* If 'nextstep' is still null, no closing END WHILE was found,
	 * so end program emitting a warning */
	if (!nextstep) return perror_(__LINE__,28,l);

        /* update stack values */
	whileStack[++whileTOS]=nextstep;    // TOS-1 = ENDWHILE line
	whileStack[++whileTOS]=l;           // TOS   = WHILE instruction
	whilecount++;

	/* set DEFFN counter */
	if (isDefRun) isDefWhile++;
	
	/* check if WHILE must be performed (only if condition is true) */
	if (!cond) {
		whileTOS-=2;
		whilecount--;
		/* jump beyond END WHILE */
		l=nextstep;
	}
	return TRUE;
}


/* EXIT()
 * The EXIT statement 
 * Select the following keywords (DO/FOR/WHILE) and unload relative
 * decision structures and cycles 
 * if mode = 0 perform EXIT, if = 1 perform CONTINUE */
int EXIT(int mode) {
	int i=0, rl=0; 	// return line for end address

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* first pass: find return address line rl
	 * Note: return line is the physical last line of the specified
	 * object of statement
	 * EXIT: l will be put equal to rl, and parse() will increment then 
	 * l to rl+1 and thus jumping beyond the last specified cycle
	 * CONTINUE: l will be put equal to rl-mode, and parse() will increment
	 * l to rl+1-mode = rl+1-1 = rl itself, thus continuing the cycle */
	i=l+1;
	while (*p) {
		if (!strncasecmp_(p,"FOR",3)) {
			p+=3;
			while (!forAddr[i] && i<=endCore) i++;
			if (i>endCore) return perror_(__LINE__,199,l);
			else rl=i;
		}
		else if (!strncasecmp_(p,"WHILE",5)) {
			p+=5;
			while (!whileAddr[i] && i<=endCore) i++;
			if (i>endCore) return perror_(__LINE__,198,l);
			else rl=i;
		}
		else if (!strncasecmp_(p,"DO",2)) {
			p+=2;
			while (!doAddr[i] && i<=endCore) i++;
			if (i>endCore) return perror_(__LINE__,197,l);
			else rl=i;
		}
		else return perror_(__LINE__,202,l);
		if (*p==',' || *p==';') p++;
		i++;
	}

	/* check return address */
	if (rl<1 || rl>endCore) return perror_(__LINE__,203,l);

	/* second pass: scan source from l=current line to rl=return line to 
	 * do a real unload of all IF, SELECT, WHILE, DO, FOR in the range */
	for (i=l+1;i<=rl-mode;i++) {
		if (ifAddr[i] && cAddr[i]<l) ifTOS--;
		else if (selectAddr[i] && cAddr[i]<l) 
			selectTOS-=3, selectcount--;
		else if (whileAddr[i] && cAddr[i]<l) 
			whileTOS-=2, whilecount--;
		else if (doAddr[i] && cAddr[i]<l) doTOS-=2, docount--;
		else if (forAddr[i] && cAddr[i]<l) forTOS-=6, forcount--;
	}

	/* set program count to prosecution line */
	l=rl-mode;
	return TRUE;
}


/* BREAK()
 * The BREAK statement 
 * Exits from the most external loop and unload relative
 * decision structures and cycles */
int BREAK(void) {
	int i=0, rl=0; 	// return line for end address

	/* first pass: find return address line rl
	 * Note: return line is the physical last line of the specified
	 * object of statement */
	i=l+1;
	while (i<=endCore) {
		if (cAddr[i]) {
			if (forAddr[i] || whileAddr[i] || doAddr[i]) {
				rl=i;
				break;
			}
		}
		i++;
	}

	/* break used out of any cycle */
	if (i>endCore) return perror_(__LINE__,204,l);

	/* check return address */
	if (rl<1 || rl>endCore) return perror_(__LINE__,204,l);

	/* second pass: scan source from l=current line to rl=return line to 
	 * do a real unload of all IF, SELECT, WHILE, DO, FOR in the range */
	for (i=l+1;i<=rl;i++) {
		if (ifAddr[i] && cAddr[i]<l) ifTOS--;
		else if (selectAddr[i] && cAddr[i]<l) 
			selectTOS-=3, selectcount--;
		else if (whileAddr[i] && cAddr[i]<l) 
			whileTOS-=2, whilecount--;
		else if (doAddr[i] && cAddr[i]<l) doTOS-=2, docount--;
		else if (forAddr[i] && cAddr[i]<l) forTOS-=6, forcount--;
	}

	/* set program count to prosecution line */
	l=rl;
	return TRUE;
}


/* ENDWHILE()
 * The END WHILE statement
 * Its only scope is to jump back to WHILE, because if condition is false
 * it's WHILE() that jumps over END WHILE, putting the cycle to an end*/
int ENDWHILE(void) {
	if (!whilecount) return perror_(__LINE__,209,l);
	/* jump unconditionally back to WHILE */
	l=whileStack[whileTOS]-1;
	/* unload WHILE data, which will be reloaded by the call to WHILE */
	whileTOS -= 2;
	whilecount--;
	return TRUE;
}


/* DOWHILE()
 * The DOWHILE Statement */
int DOWHILE(void) {
        int nextstep=0, cond;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);
	if (isblank(*p)) p++;

	/* make checks and calculate condition value */
	if (docount >= FORLIM) return perror_(__LINE__,53,l);
	if (isanystring(p)) cond=strRel();
	else cond=(int)S();
	if (isEndOfStatement) return FALSE;
	if (*p) return perror_(__LINE__,35,l);
	
	/* the search for closing LOOP 
	 * was done in preParse() and stored into doAddr[] */
	nextstep=doAddr[l];

	/* If 'nextstep' is still null, no closing END WHILE was found,
	 * so end program emitting a warning */
	if (!nextstep) return perror_(__LINE__,28,l);

        /* update stack values */
	doStack[++doTOS]=nextstep;    // TOS-1 = ENDWHILE line
	doStack[++doTOS]=l;           // TOS   = WHILE instruction
	docount++;

	/* set DEFFN counter */
	if (isDefRun) isDefDo++;
	
	/* check if WHILE must be performed (only if condition is true) */
	if (!cond) {
		doTOS-=2;
		docount--;
		/* jump beyond LOOP */
		l=nextstep;
	}
	return TRUE;
}


/* DOUNTIL()
 * The DOUNTIL Statement */
int DOUNTIL(void) {
        int nextstep=0, cond;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);
	if (isblank(*p)) p++;

	/* make checks and calculate condition value */
	if (docount >= FORLIM) return perror_(__LINE__,53,l);
	if (isanystring(p)) cond=strRel();
	else cond=(int)S();
	if (isEndOfStatement) return FALSE;
	if (*p) return perror_(__LINE__,35,l);
	
	/* the search for closing LOOP 
	 * was done in preParse() and stored into doAddr[] */
	nextstep=doAddr[l];

	/* If 'nextstep' is still null, no closing END WHILE was found,
	 * so end program emitting a warning */
	if (!nextstep) return perror_(__LINE__,28,l);

        /* update stack values */
	doStack[++doTOS]=nextstep;    // TOS-1 = ENDWHILE line
	doStack[++doTOS]=l;           // TOS   = WHILE instruction
	docount++;

	/* set DEFFN counter */
	if (isDefRun) isDefDo++;
	
	/* check if WHILE must be performed (only if condition is false) */
	if (cond) {
		doTOS-=2;
		docount--;
		/* jump beyond LOOP */
		l=nextstep;
	}
	return TRUE;
}


/* LOOP()
 * The LOOP statement for the DO WHILE|UNTIL .. LOOP
 * Its scope is merely to jump back to DO WHILE, because if condition is true
 * it's DOWHILE() that jumps over LOOP, putting the cycle to an end*/
int LOOP(void) {
	if (!docount) return perror_(__LINE__,219,l);
	/* jump unconditionally back to WHILE */
	l=doStack[doTOS]-1;
	/* unload WHILE data, which will be reloaded by the call to WHILE */
	doTOS -= 2;
	docount--;
	return TRUE;
}


/* LOOPWHILE()
 * The LOOPWHILE Statement for the DO..LOOP WHILE */
int LOOPWHILE(void) {
        int prevstep=0, cond;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);
	if (isblank(*p)) p++;

	/* make checks and calculate condition value */
	if (docount >= FORLIM) return perror_(__LINE__,53,l);
	if (isanystring(p)) cond=strRel();
	else cond=(int)S();
	if (isEndOfStatement) return FALSE;
	if (*p) return perror_(__LINE__,35,l);
	
	/* the search for opening DO 
	 * was done in preParse() and stored into doAddr[] */
	prevstep=doAddr[l];

	/* If 'prevtep' is still null, no closing END WHILE was found,
	 * so end program emitting a warning */
	if (!prevstep) return perror_(__LINE__,28,l);

        /* update stack values */
	docount++;

	/* set DEFFN counter */
	if (isDefRun) isDefDo++;

	/* unload stack data */
	doTOS -= 2;
	docount--;
	
	/* check if LOOP must be performed (only if condition is true) */
	if (cond) l=prevstep;
	return TRUE;
}


/* LOOPUNTIL()
 * The LOOPUNTIL Statement for the DO..LOOP UNTIL */
int LOOPUNTIL(void) {
        int prevstep=0, cond;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);
	if (isblank(*p)) p++;

	/* make checks and calculate condition value */
	if (docount >= FORLIM) return perror_(__LINE__,53,l);
	if (isanystring(p)) cond=strRel();
	else cond=(int)S();
	if (isEndOfStatement) return FALSE;
	if (*p) return perror_(__LINE__,35,l);
	
	/* the search for opening DO 
	 * was done in preParse() and stored into doAddr[] */
	prevstep=doAddr[l];

	/* If 'prevtep' is still null, no closing END WHILE was found,
	 * so end program emitting a warning */
	if (!prevstep) return perror_(__LINE__,28,l);

        /* update stack values */
	docount++;

	/* set DEFFN counter */
	if (isDefRun) isDefDo++;
	
	/* unload stack data */
	doTOS -= 2;
	docount--;
	
	/* check if LOOP must be performed (only if condition is false) */
	if (!cond) l=prevstep;
	return TRUE;
}


/* SELECT()
 * the SELECT statement */
int SELECT(void) {
	int type=0;
	char sf[COMPSTR], sres[COMPSTR], *f=sf, *pb;
	double nres;

	/* update count */
	selectcount++;

	/* case of string formula */
	if (isanystring(p)) {
		int len=0;
		type=STR;
		while (*p) *f++=*p++;
		*f='\0';
		pb=p;
		p=sf;
		strncpy_(sres,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		p=pb;
		if (strformula[selectcount]!=NIL) {
			free(strformula[selectcount]);
			strformula[selectcount]=NIL;
		}
		len=((int)strlen(sres)+1)*sizeof(char);
		strformula[selectcount]=xmalloc((size_t)len);
		if (strformula[selectcount]==NIL) 
			return perror_(__LINE__,175,l);
		strncpy_(strformula[selectcount],sres,len);
		isMuteSelect[selectcount]=FALSE;
	}
	/* case of numeric formula */
	else if (*p) {
		type=NUM;
		nres=S();
		if (isEndOfStatement) return FALSE;
		numformula[selectcount]=nres;
		isMuteSelect[selectcount]=FALSE;
	}
	/* case of TRUE clauses (mute select) */
	else {
		isMuteSelect[selectcount]=TRUE;
	}

	/* set up select stack */
	selectStack[++selectTOS]=selectcount;   // TOS -2 count
	selectStack[++selectTOS]=type;		// TOS -1 type
	selectStack[++selectTOS]=CASEVALUE;	// TOS    operation
	return TRUE;
}


/* CASE() 
 * the CASE statement of the SELECT-END SELECT decision structure */
int CASE(void) {
	double nval;
	char sval[COMPSTR];
	int count,type,op, flag, isRangeCase=FALSE;

	/* check if CASE is possible */
	if (selectTOS<3) return perror_(__LINE__,224,l);

	count=selectStack[selectTOS-2];
	type=selectStack[selectTOS-1];
	op=selectStack[selectTOS];

	/* end operation, because another previous CASE has matched */
	if (op==CASEEND) {
		l=selectAddr[l]-1;
		return TRUE;
	}

	/* if = is used, skip it */
	if (*p=='=') p++;

	/* find range case */
	if (strcasestr_oq(p," TO ")) isRangeCase=TRUE;

	/* calculate flag for mute select */
	if (isMuteSelect[count]) {
		if (isanystring(p)) flag=strRel();
		else flag=S();
		if (bcomp(p,"TO")) return perror_(__LINE__,226,l);
		if (isEndOfStatement) return FALSE;
	}
	/* calculate range numeric value */
	else if (type==NUM && isRangeCase) {
		double lowrange,highrange;
		lowrange=S();
		if (isEndOfStatement) return FALSE;
		if (bcomp(p,"TO")) p+=4;
		highrange=S();
		if (isEndOfStatement) return FALSE;
		if (numformula[count]>=lowrange &&\
				numformula[count]<=highrange) 
			flag=TRUE;
		else flag=FALSE;
	}
	/* calculate range numeric value */
	else if (type==STR && isRangeCase){ 
		char lowrange[COMPSTR],highrange[COMPSTR];
		strncpy_(lowrange,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		if (bcomp(p,"TO")) p+=4;
		strncpy_(highrange,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		if (strcmp(lowrange,strformula[count])<=0 &&\
				strcmp(strformula[count],highrange)<=0) 
			flag=TRUE;
		else flag=FALSE;
	}
	/* calculate string value */
	else if (type==STR && !isRangeCase) {
		strncpy_(sval,SS(),COMPSTR);
		if (isEndOfStatement) return FALSE;
		if (!strcmp(sval,strformula[count])) flag=TRUE;
		else flag=FALSE;
	}
	/* calculate numeric value */
	else if (type==NUM && !isRangeCase) {
		nval=S();
		if (isEndOfStatement) return FALSE;
		if (nval==numformula[count]) flag=TRUE;
		else flag=FALSE;
	}

	/* values do match! Let program flow */
	if (flag) selectStack[selectTOS]=CASEEND;
	/* values don't match: look for next CASE/ENDSELECT*/
	else {
		int end=selectAddr[l], lb=l+1;
		char *ll;
		while (lb<=end) {
			ll=m[lb];
			if (!strncasecmp_(ll,"CASE",4)) break;
			else if (checkCommand(ll,"END SELECT",&ll)) break;
			lb++;
		}
		/* jump to next position */
		l=lb-1;
	}
	return TRUE;
}


/* CASEDEFAULT() 
 * the CASE DEFAULT statement of the SELECT-END SELECT decision structure */
int CASEDEFAULT(void) {
	/* check if CASE DEFAULT is possible */
	if (selectTOS<3) return perror_(__LINE__,224,l);

	/* end operation, because another previous CASE has matched */
	if (selectStack[selectTOS]==CASEEND) l=selectAddr[l]-1;
	
	/* Ensure that this is the last CASE DEFAULT used */
	selectStack[selectTOS]=CASEEND;
	return TRUE;
}


/* ENDSELECT()
 * the END SELECT statement of the SELECT-END SELECT decision structure */
int ENDSELECT(void) {
	if (selectTOS<3) return perror_(__LINE__,222,l);
	isMuteSelect[selectStack[selectTOS-2]]=FALSE;
	selectTOS-=3;
	selectcount--;
	return TRUE;
}


/* FOR()
 * The FOR..TO..STEP/FOR..TO..BY Statements.
 * STEP and BY are interchangeable */
int FOR(void){
        int var=0, nextstep=0, minus=1, cs=0;
        double start=0.0, end=0.0, step=0.0, varvalue=0.0;
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* make checks and grab variable name */
	if (forcount >= FORLIM) return perror_(__LINE__,53,l);
	else if ((cs=findDEC(p)) && !vn[cs].isArr && vn[cs].rettype==NUM) {
		var=cs, p+=_len;
	}
	else return perror_(__LINE__,37,l);
        if (*p!='=') return perror_(__LINE__,65,l,makechar(p),"=");
	else p++;
	
	/* save values of FOR variable index */
	varvalue = P[var];
	if (*p=='-') minus=-1, p++;

	/* get limits  */
	start=minus*S();
	if (isEndOfStatement) return FALSE;
	if (bcomp(p,"TO")) p+=4;
	else return perror_(__LINE__,37,l);
	minus=1;
	if (*p=='-') minus=-1, p++;
	end=minus*S();
	if (isEndOfStatement) return FALSE;
	/* case of a user step using BY */
	if (bcomp(p,"BY")) {
		p+=4;
		if (!*p) return perror_(__LINE__,37,l);
		step=S();
		if (isEndOfStatement) return FALSE;
	}	
	/* case of a user step using STEP */
	else if (bcomp(p,"STEP")) {
		p+=6;
		if (!*p) return perror_(__LINE__,37,l);
		step=S();
		if (isEndOfStatement) return FALSE;
	}	
	else if (*p) return perror_(__LINE__,37,l);
	/* case of an implicit step = 1 */
	else step=1.0;
	
	/* set starting value for index variable */
	P[var]=start;

	/* the search for closing NEXT matching the variable 
	 * was done in preParse() and stored into forAddr[] */
	nextstep=forAddr[l];

	/* If 'nextstep' is still null, no closing NEXT was found,
	 * so end program emitting a warning */
	if (!nextstep) {
		return perror_(__LINE__,29,l);
	}
	
	/* if step is meaningless and thus not executed, go beyond FOR..NEXT, 
	 * restoring index variable value, and return */
	if ((end-start>0 && step<0) || (end-start<0 && step>0) || step==0) {
		l=nextstep-1;
		P[var]=varvalue;
		return TRUE;
	}

        /* update stack values */
	forStack[++forTOS]=nextstep;	// TOS-5 = NEXT program line
	forStack[++forTOS]=l;           // TOS-4 = FOR instruction
        forStack[++forTOS]=var;		// TOS-3 = var index
        forStack[++forTOS]=end;         // TOS-2 = end value
        forStack[++forTOS]=step;        // TOS-1 = step value
        forStack[++forTOS]=start;       // TOS   = start/current value
	forcount++;

	/* set DEFFN counter */
	if (isDefRun) isDefFor++;
	return TRUE;
}


/* NEXT()
 * The NEXT... Statement
 * Note: see the note in FOR().
 * Note: this version handles multiple addressing, like NEXT J,I, as well as
 * a NEXT alone; in this case, the last variable in the FOR cycle is used as 
 * the current NEXT variable. */
int NEXT(void) {
        int var=0, cs=0;
        double step=0.0, end=0.0;

nextvar:

	/*check if a NEXT is possible */
	if (forTOS<6) return perror_(__LINE__,47,l);

	/* get index of first variable in line */
        if ((cs=findDEC(p)) && !vn[cs].isArr && vn[cs].rettype==NUM) {
		var=cs, p+=_len;
	}
	else if (!*p) var=forStack[forTOS-3];
	else return perror_(__LINE__,35,l);

	/* update cycle values */
	step = forStack[forTOS-1];
	end  = forStack[forTOS-2];

	/* check index; if different from what stored 
	 * with the previous FOR instruction => NEXT error */
	if (var != (int)forStack[forTOS-3]) return perror_(__LINE__,47,l);

        /* Note: if beyond the limit, put cycle to an end; after that, if there 
	 * are other indices in the list continue with the most outer cycle;
	 * Note: the variable to check for is the variable itself (this is 
	 * actually meaningless for normal cycles, but when the index is 
	 * altered inside the cycle this is important).
	 * Note: tbas cannot be absolutely precise with limits and indices
	 * with fractional parts because they may not be correctly stored
	 * in the C double format; it runs (yes!) into a more modern computer, 
	 * but with its limitations too! So do expect that some mislead cycle
	 * may happen. */
        if (((step > 0) && (P[var]+step > end)) || \
		((step < 0) && (P[var]+step < end))) {
                        if (forTOS>5) forTOS -= 6;
			forcount--;
			if (isDefRun) isDefFor--;
			/* restart in case of multiple NEXT */
			if (*p==',') {
				p++;
				goto nextvar;
			}
	}
	/* else reiterate; update counter variable (current +/- step*/
        else {
        	forStack[forTOS] += step; 
	        P[var]+=step;
	        l=(int)forStack[forTOS-4];
	}
	/* reset flag for the FOR..NEXT cycle inside a DEF FN 
	 * in case no cycle is left - this should be never needed, but... */
	if (!forcount && isDefFor) isDefFor=FALSE;
	return TRUE;
}
	

/* READ()
 * The READ statement 
 * this function checks the next available item in the READ line, and stores in
 * it the first available correspondent item (number or string)
 * Note: READ and DATA work on two dedicated arrays, one for numbers, one for 
 * strings, whose activation flags are dataLimit and dataLimitS and whose 
 * pointers are dc and dcs; these arrays are built in the DATA section of 
 * preParse() (there is no DATA command, actually) */
int READ(void) {
	int var=0, isArr=FALSE, type=NUM;
	
	/* there must be at least one DATA to read! */
	if (!dataLimit && !dataLimitS) return perror_(__LINE__,50,l);
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* start READ */
	do {
		int cs;
		char op[COMPSTR];
		double val=0.0;
		isArr=FALSE,type=NUM;

		/* is it an existing variable? */
		if ((cs=findDEC(p))) {
			var=cs, p+=_len;
			type=vn[cs].rettype;
			if (*p=='(') isArr=TRUE;
			else isArr=FALSE;
		}
		else return perror_(__LINE__,42,l);

		/* check that there's still something to read */
		if (type==STR) {
			if (dcs>dataLimitS) {
				return perror_(__LINE__,110,l);
			}
		}
		else if (type==NUM) {
			if (dc>dataLimit) {
				return perror_(__LINE__,110,l);
			}
		}

		/* get numerical value */
		if (type==NUM) val=D[dc++];
		/* get string value */
		else strncpy_(op,DS[dcs++],COMPSTR);

		/* numeric variable */
		if (!isArr && type==NUM){
			if (vn[var].isInt) P[var]=(int)val;
			else P[var]=val;
		}
		/* string variable */
		else if (!isArr && type==STR) strncpy_(PS[var],op,COMPSTR);
		/* numeric or string array */
		else if (isArr) {
			int M=0, N=0, T=1;
			if (*p=='(') p++;
			else return perror_(__LINE__,37,l);
			M=(int)S();
			if (isEndOfStatement) return FALSE;
			if (*p==',') {
				p++;
				N=(int)S();
				if (isEndOfStatement) return FALSE;
				T=2;
			}
			p++;
			if (vn[var].isInt) val=(int)val;
			if (type==NUM) {
				setArrayVal(var,T,M,N,val);
			}
			else {
				setArrayStr(var,T,M,N,op);
			}
		}
		if (*p==',') p++;
	} while (*p);
	return TRUE;
}


/* RESTORE()
 * the RESTORE statement. 
 * Note: a RESTORE followed by a number restore the pointers to the first 
 * label value not greater than this number 
 * If followed by * restores only numbers; if by $ only strings 
 * Note: if the specific * or $ symbol is used, the line number must exist, 
 * because we are requiring a precise entity; but if the simple RESTORE N is 
 * used, no error is printed because the string and number DATA are not 
 * necessarily lined. */
int RESTORE(void){
	int ok=TRUE;
	/* restore to a specific line label */
	if (isdigit(*p)) {
		int val=strtol(p,&p,10);
		/* restore number index; for both blocks the algorithm is:
		 * ~- search for first item in line with label 'val' 
		 * ~- if you find it, let the pointer there, but decrease it
		 *    until you find the first item in the line
		 * ~- otherwise raise an error */
		if (*p=='*') {
			p++;
			if (dataLimit) {
				dc=dataLimit;
				while (dc>=1) {
					if(ln[DN[dc]]>0 && ln[DN[dc]]<=val) 
						break;
					dc--;
				}
				while (DN[dc]==DN[dc-1]) dc--;
				if (dc<=0 || ln[DN[dc]]!=val) 
					return perror_(__LINE__,114,l,"numeric",val);
			}
		}
		/* restore string index */
		else if (*p=='$') {
			p++;
			if (dataLimitS) {
				dcs=dataLimitS;
				while (dcs>=1) {
					if(ln[DSN[dcs]]>0 && ln[DSN[dcs]]<=val) 
						break;
					dcs--;
				}
				while (DSN[dcs]==DSN[dcs-1]) dcs--;
				if (dcs<=0 || ln[DSN[dcs]]!=val) 
					return perror_(__LINE__,114,l,"string",val);
			}
		}
		/* restore both number and string indices
		 * for both blocks the algorithm is:
		 * ~- search for first item in line with label 'val' 
		 * ~- if you find it, let the pointer there, but decrease it
		 *    until you find the first item in the line
		 * ~- if you don't find it, restore it to the value it had */
		else if (!*p) {
			if (dataLimit) {
				int dcb=dc;
				dc=dataLimit;
				while (dc>=1) {
					if(ln[DN[dc]]>0 && ln[DN[dc]]<=val) 
						break;
					dc--;
				}
				while (DN[dc]==DN[dc-1]) dc--;
				if (dc<=0 || ln[DN[dc]]<val) dc=dcb; 
			}
			if (dataLimitS) {
				int dcsb=dcs;
				dcs=dataLimitS;
				while (dcs>=1) {
					if(ln[DSN[dcs]]>0 && ln[DSN[dcs]]<=val) 
						break;
					dcs--;
				}
				while (DSN[dcs]==DSN[dcs-1]) dcs--;
				if (dcs<=0 || ln[DSN[dcs]]<val) dcs=dcsb;
			}
		}
	}
	/* restore number index */
	else if (*p=='*') {
		if (dataLimit) dc=1; 
		else ok=FALSE;
	}
	/* restore string index */
	else if (*p=='$') {
		if (dataLimitS) dcs=1; 
		else ok=FALSE;
	}
	/* restore both number and string indices*/
	else if (!*p) {
		if (dataLimit+dataLimitS) dc=dcs=1; 
		else ok=FALSE;
	}
	else return perror_(__LINE__,35,l);
	/* warning in case something went wrong */	
	if (!ok) return perror_(__LINE__,50,l);
	return TRUE;
}


/* multiLET()
 * wrapper for LET(), in order to catch multiple assignments 
 * if a colon is found, put a NIL there and call LET(); 
 * then call recursively itself on the rest
 * if a colon is not found, call LET() */
int multiLET(void) {
	char *br=NIL; // break

	/* find next colon */
	if ((br=strcasestr_oq(p,":"))) {
		*br='\0';
		if (!LET()) return FALSE;
		if (br) p=br+1;
		br=NIL;
		multiLET();
	}
	else return LET();
	return TRUE;
}


/* LET()
 * The LET statement (even for implicit LET)
 * address simple assignment (e.g X=3) and multi-variables assignments
 * (e.g. X=Y=T=3) 
 * return TRUE if assignment can be accomplished, FALSE otherwise 
 * Note: a multi-variable assignment proceeds from right to left, that is
 * the first item is updated last; this is important in cases like
 * LET A=B(A)=expression, where B(A) is updated with the 'old' value of A,
 * while in LET B(A)=A=expression, B(A) is updated with the 'new' value of A. 
 * Note: the effective addressing routine is delegated to assign() 
 * Note: this algorithm doesn't consider the equal signs into strings (in 
 * which case they are 'characters') or into parenthesis (in which case they 
 * are logical operators). */
int LET(void) {
	char *sep, *sep2, *lp;
	int v=0;
	
	/* LET is implicit */
	if (!strncasecmp_(p,"LET",3)) p+=3;
	
	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);


	/* if assignment begins with LEFT$( or with RIGHT$( or MID$(
	 * let assign decide; it may be a left assignment */
	lp=p;
	if (!strncasecmp_(p,"LEFT$(",6)) return assign();
	else if (!strncasecmp_(p,"RIGHT$(",7)) return assign();
	else if (!strncasecmp_(p,"MID$(",5)) return assign();

	/* short circuit for statements which are surely not assignments */
	if (!strchr(p,'=')) return FALSE;

	/* search last assignment (signaled by '=') out of strings and 
	 * out of parenthesis (in which case '=' is a logic operator) */
	v=0;
	while (TRUE) {
		if ((int)strlen(p)>0) sep=p+(int)strlen(p)-1;
		else sep=p;
		do {
			/* skip explicit strings */
			if (*sep=='\"') {
				sep--; // skip opening quotes
				while (sep>lp && *sep!='\"') sep--;
				sep--; // skip closing quotes
			}
			/* skip calculations in parenthesis
			 * (since we start from the end, we first search
			 * for ')' and finally for '(' ) */
			else if (*sep==')') v++, sep--;
			else if (*sep=='(' && v) v--, sep--;
			else if (*sep=='=' && v) sep--;
			else if (*sep=='=' && !v) break; // found!
			else if (sep>lp && *sep!='=') sep--;
		} while (sep>lp);

		/* maybe no assignment was found */
		if (*sep!='=') return FALSE;

		sep2=sep-1;
		while (sep2>lp && *sep2!='=') sep2--;

		/* proceed with assignment:
		 * it's a multi-variables assignment... */
		if (*sep2=='=') {
			p=sep2+1;
			if (!assign()) return FALSE;
			*sep='\0';
			continue;
		}
		/* ...or else it's a single assignment */
		else {
			p=lp;
			return assign();
		}
	}
	return FALSE;
}


/****************************************************************************
 * The following routines define the DEFFN and the SUB functions, used in
 * preParse to store data respectively of the DEF FN functions (single and
 * multi lines) and the SUB functions/procedure
 ****************************************************************************/

/* showDEF()
 * DEBUG FUNCTION 
 * i is the DEF to be shown
 * if mode is ALL_LINES, print also DEF lines */
void showDEF(int i, int mode) {
	int j, y=2;

	if (isInvDebug) fprintf(stdout,INVCOLOR);	
	fprintf(stdout,"DEF#%d:\tName = FN%c\n",i,i);
	fprintf(stdout,"\ttype: %s\n",fn[i].type==SINGLE?"single line":"multiline");
	fprintf(stdout,"\tVars: #%d",fn[i].vars[0]);
	for (j=0;j<fn[i].vars[0];j++) {
		fprintf(stdout,"\n\t   ");
		while (fn[i].vars[y]>0)
		       fprintf(stdout,"%c",fn[i].vars[y++]);
		y+=3;
	}
	fprintf(stdout,"\n");
	if (mode==ALL_LINES) {
		fprintf(stdout,"\tLines:\n");
		if (fn[i].type==SINGLE) fprintf(stdout,"\t%d\t|%s|\n",fn[i].start,fn[i].def);
		else for (j=fn[i].start;j<=fn[i].end;j++)
			fprintf(stdout,"\t%d\t|%s|\n",j,m[j]);
	}
	fprintf(stdout,"End of FN%c\n\n",i);
	if (isInvDebug) fprintf(stdout,RESETCOLOR);	
}


/* DEF()
 * The DEF Statement for numerical functions; handles multiple arguments 
 * Note: this function is called in preParse() before RUN().
 * The label for FN must be in the A..Z range and not subscripted.
 * Note: this function executes a storing only; the actual command (the 
 * function interpretation and execution) is performed into getFunc() for
 * function FNX; in case of an inline DEF FN, the string is stored into an 
 * array called fn[].def; in case of a multi line DEF FN they are stored into 
 * an array of char pointers called fn[].lines[] */
int DEF(int l) {
	int len, currDEF=*(p+2), mode=isSingleDEF(p);
	int varcount;

	/* check if the function name has already been used */
	if (fn[currDEF].type==SINGLE || fn[currDEF].type==MULTI) 
		return perror_(__LINE__,31,l);

	/* if there are arguments, they must be saved */
	varcount=0;
	if (!strncasecmp_(p,"FN",2) && isalpha(currDEF) && *(p+3)=='(') {
		int vn=0;

		/* point to the first variable */
		p+=4;
		/* store all argument-variables */
		while (*p && *p!=')') {
			if (isstrvar(p) || isnumvar(p)) {
				int typ=NUM;
				fn[currDEF].vars[++varcount]=DECADD;
				while (isnamechar(p))
					fn[currDEF].vars[++varcount]=*p++;
				if (*p=='%' && *(p+1)!='%') typ=NUMINT,
					fn[currDEF].vars[++varcount]=*p++;
				else if (*p=='$') typ=STR,
					fn[currDEF].vars[++varcount]=*p++;
				fn[currDEF].vars[++varcount]=-1; // termin
				fn[currDEF].vars[++varcount]=DECADD+typ;
				vn++;
				if (*p!=')' && *p!=',') 
					return perror_(__LINE__,129,l);
			}
			else return perror_(__LINE__,35,l);
	
			/* check syntax */
			if (*p==',') p++;
		}
		if (*p!=')') return perror_(__LINE__,35,l);
		else p++;
	
		/* assign variable count */
		fn[currDEF].vars[0]=vn;
	}
	else {  
		p+=3; // point to text
		fn[currDEF].vars[0]=0;
	}	


	/* single line DEF: store in fn[].def the following formula, caring of 
	 * stripblanking it, because all this is done in parse() */
	if (mode==SINGLE) {
		char dline[SCREENLINE+1];
		int qq=0;
		for (qq=0;qq<=SCREENLINE;qq++) dline[qq]='\0';
		if (*p!='=') return perror_(__LINE__,35,l);
		len=((int)strlen(++p)+1)*sizeof(char);
		stripBlanks(p,dline);
		/* empty line is an error */
		if (!dline[0]) return perror_(__LINE__,35,l);
		if (fn[currDEF].def!=NIL) {
			free(fn[currDEF].def);
			fn[currDEF].def=NIL;
		}
		fn[currDEF].def=xmalloc((size_t)len);
		if (!fn[currDEF].def) return perror_(__LINE__,192,l,currDEF);
		strncpy_(fn[currDEF].def,dline,len);
		fn[currDEF].type=mode;
		fn[currDEF].start=l;
	}
	/* multiline DEF: store lines */
	else {
		char *q;
		int i;
		/* find next available line after DEFFN */
		l++; while (!m[l] && l<=DATLIM) l++;
		fn[currDEF].start=l;
		fm[l]=TRUE;
		/* find last line (where FNEND is located) */
		while (l<=endCore) {
			if (m[l]) {
				q=m[l];
				while (isblank(*q)) q++;
				if (!strcasecmp(q,"FNEND")) break;
			}
			l++;
		}
		if (l>endCore) return perror_(__LINE__,52,-1,currDEF);
		else fn[currDEF].end=l-1;

		/* set type */
		fn[currDEF].type=mode;

		/* find lines and mask them*/
		for (i=fn[currDEF].start; i<=fn[currDEF].end; i++) {
			fm[i]=TRUE;
		}
	
		/* update count */
		isDefCount++;
	}
	
	/* DEBUGGING show DEF contents */	
	if (isDebug) showDEF(currDEF,ALL_LINES);
	return TRUE;
}


/* showSUB()
 * DEBUG FUNCTION 
 * i is the sub number to be shown 
 * if mode is ALL_LINES then all lines of the sub are printed */
void showSUB(int i, int mode) {
	int j,y=2;

	if (isInvDebug) fprintf(stdout,INVCOLOR);	
	fprintf(stdout,"Sub#%d:\tName = %s\n",i,sn[i].name[0]?sn[i].name:"obj.");
	fprintf(stdout,"\ttype: %s\n",sn[i].type==FUNC?"FUNC":"PROC");
	if (sn[i].type==FUNC) 
		fprintf(stdout,"\treturn type: %s\n",sn[i].rettype==NUM?"numeric":"string");
	fprintf(stdout,"\tVars: #%d",sn[i].vars[0]);
	for (j=0;j<sn[i].vars[0];j++) {
		int t=0, ta=FALSE;
		fprintf(stdout,"\n\t   ");
		while (sn[i].vars[y]>0)
		       fprintf(stdout,"%c",sn[i].vars[y++]);
		y++; // skip -1
		t=sn[i].vars[y++]-DECADD;
		if (t>STRNUMARR) t-=STRNUMARR, ta=TRUE;
		if (t==STR) fprintf(stdout,", string");
		else if (t==NUM) fprintf(stdout,", numeric");
		if (ta) fprintf(stdout," array");
		else fprintf(stdout," variable");
		y++;
	}
	fprintf(stdout,"\n");
	if (mode==ALL_LINES) {
		fprintf(stdout,"\tLines:\n");
		for (j=sn[i].start;j<=sn[i].end;j++) {
			fprintf(stdout,"\t%d\t|%s|\n",j,m[j]);
		}
	}
	fprintf(stdout,"End of SUB %s\n\n",sn[i].name[0]?sn[i].name:"obj.");
	if (isInvDebug) fprintf(stdout,RESETCOLOR);	
}


/* SUB()
 * The SUB Statement for subroutines; handles multiple arguments 
 * Note: this function is called in preParse() before RUN().
 * Note: this function executes a storing only; the actual command (the 
 * function interpretation and execution) is performed by execSUB() called
 * into getFunc() and SS() for function names and in exec() for procedures */
int SUB(int l) {
	int len=l, rettype=NUM, type=PROC;
	char subname[COMPSTR], *sp=subname;
	char *q;
	int i,varcount, namelen=0;

	/* argument required */
	if (!*p) return perror_(__LINE__,125,l);

	/* get sub name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p)) *sp++=*p++;
	}
	else return perror_(__LINE__,172,l);

	/* determine string return type */
	if (*p=='$') *sp++=*p++,rettype=STR;
	*sp='\0';

	/* setup sub */
	subCount++;
	if (subCount>2*LIMIT-1) return perror_(__LINE__,195,l,subname);
	sn[subCount].number=subCount;
	namelen=((int)strlen(subname)+1)*sizeof(char);
	if (namelen>PROCNAMEMAX) return perror_(__LINE__,172,l,subname);
	else strncpy_(sn[subCount].name,subname,namelen);

	/* if there are arguments, they must be saved */
	varcount=0;
	if (*p=='(') {
		int vn=0;
		/* point to the first variable */
		p++;
		/* store all argument-variables */
		while (*p && *p!=')') {
			if (isstrvar(p) || isnumvar(p)) {
				int ret=NUM;
				sn[subCount].vars[++varcount]=DECADD;
				while (isnamechar(p))
					sn[subCount].vars[++varcount]=*p++;
				if (*p=='%' && *(p+1)!='%') ret=NUMINT,
					sn[subCount].vars[++varcount]=*p++;
				else if (*p=='$') ret=STR,
					sn[subCount].vars[++varcount]=*p++;
				sn[subCount].vars[++varcount]=-1; // end
				sn[subCount].vars[++varcount]=DECADD+ret;
				if (!strncasecmp_(p,"()",2)) {
					p+=2;
					sn[subCount].vars[varcount]+=STRNUMARR;
				}
				vn++;
				if (*p!=')' && *p!=',') 
					return perror_(__LINE__,129,l);
			}
			else return perror_(__LINE__,35,l);

			/* check syntax */
			if (*p==',') p++;
		}
		if (*p!=')') return perror_(__LINE__,35,l);
		else p++;
	
		/* assign variable count */
		sn[subCount].vars[0]=vn;
	}
	else sn[subCount].vars[0]=0; 

	/* find next available line after SUB */
	l++; while (!m[l] && l<DATLIM) l++;
	sn[subCount].start=l;
	fm[l]=TRUE;
	
	/* find last line (where END SUB is located)
	 * and check if RETURN is used */
	while (l<=endCore) {
		if (m[l]) {
			q=m[l];
			while (isblank(*q)) q++;
			if (strcasestr_oq(q,"RETURN")) type=FUNC;
			if (checkCommand(q,"END FUNCTION",&q)) 
				return perror_(__LINE__,208,l);
			if (checkCommand(q,"END SUB",&q)) break;
		}
		l++;
	}

	if (l>endCore+1) return perror_(__LINE__,210,len,subname);
	else sn[subCount].end=l-1;

	/* set type */
	sn[subCount].type=type;
	sn[subCount].rettype=rettype;

	/* find lines and mask them */
	for (i=sn[subCount].start; i<=sn[subCount].end; i++) {
		fm[i]=TRUE;
	}
	/* DEBUGGING show SUB contents */	
	if (isDebug) showSUB(sn[subCount].number,ALL_LINES);
	return TRUE;
}


/****************************************************************************
 * The following routines define the DECLARE/DIM statements:
 * the DIM statement for numerical arrays with one-letter or one-letter-and-a-
 * number names was included since 1964 version II of the Dartmouth BASIC, 
 * and for strings since 1967 version IV
 ****************************************************************************/

/* showDEC()
 * DEBUG FUNCTION 
 * flag= TRUE for DECLARE, false for implicit declaration into SUBs */
void showDEC(int decCount, int flag) {
	/* DEBUGGING show SUB contents */
	if (isInvDebug) fprintf(stdout,INVCOLOR);
	if (flag) fprintf(stdout,"Declared ");
	else fprintf(stdout,"Declared implicit ");
	if (vn[decCount].isConst) fprintf(stdout,"const ");
	else fprintf(stdout,"var ");
	fprintf(stdout,"%s [#%d], type %s%s",\
			vn[decCount].name!=NIL?vn[decCount].name:"obj.",\
			decCount,\
			vn[decCount].isInt?"integer ":"",
			vn[decCount].rettype==NUM?"numeric":"string");
	if (vn[decCount].isArr) {
		fprintf(stdout," array");
		if (vn[decCount].rettype==NUM)
			fprintf(stdout," (%dx%d)",1+dim[decCount].brow,1+dim[decCount].bcol);
		else
			fprintf(stdout," (%dx%d)",1+dimS[decCount].brow,1+dimS[decCount].bcol);
	}
	else if (isSingleBASICCommand) {
		fprintf(stdout," with value = ");
		if (vn[decCount].rettype==NUM) 
			fprintf(stdout, "%f",P[decCount]);
		else fprintf(stdout, "%s",PS[decCount]);
	}
	fprintf(stdout,"\n");
	if (isInvDebug) fprintf(stdout,RESETCOLOR);
}	


/* DECLARE()
 * The DECLARE Statement for any-name variables 
 * Note: this function is run-time.
 * Note: this function executes a storing only; the actual command (the 
 * function interpretation and execution) is performed by findDEC(), called
 * into getFunc() and SS() for function names and in LET() for assignments, and
 * in all functions dealing with variables. */
int DECLARE(int isConst) {
	char decname[COMPSTR], *sp=decname;
	int var=0, type=NUM, namelen=0, isInt=FALSE, ern=0;
	
	/* get var name */
	if (isbeginnamechar(p)) {
		while (isnamechar(p)) *sp++=*p++;
	}
	else return perror_(__LINE__,170,l);

	/* determine string return type */
	if (*p=='%' && *(p+1)!='%') *sp++=*p++, isInt=TRUE;
	else if (*p=='$') *sp++=*p++, type=STR;
	*sp='\0'; //decCount++;
	/* provisional value for decCount */
	var=decCount+1;
	if (var>=VLIMIT) return perror_(__LINE__,169,l);
	vn[var].isArr=FALSE;
	vn[var].isInt=isInt;
	
	/* array figure without specified dimensions */
	if (!strncmp(p,"()",2) && !isConst) {
		if (type==STR) dimStrArray(var,2,10,10);
		else {
			ern=dimArray(var,2,10,10);
			if (ern>0) return perror_(__LINE__,ern,l);
		}
		vn[var].isArr=TRUE;
		p+=2;
	}
	/* array figure */
	else if (*p=='(' && !isConst) {
		int M=0,N=0,T=1;
		vn[var].isArr=TRUE;
		p++;
		/* get N (and N) */
		M=(int)S();
		if (isEndOfStatement) return FALSE;
		if (M<0) return perror_(__LINE__,76,l);
		if (*p==',') {
			p++;
			N=(int)S();
			if (isEndOfStatement) return FALSE;
			if (N<0) return perror_(__LINE__,76,l);
			T=2;
		}
		if (!M && N) T=2;
		else if (M && !N) T=1;
		
		/* check correspondence */
		if (type==STR) {
			/* variable should be still free, anyway... */
			if (dimS[var].type) return perror_(__LINE__,63,l);
			if (dimS[var].type==1 && T==2) return perror_(__LINE__,64,l);
			dimStrArray(var,T,M,N);
		}
		else {
			/* again, variable should be still free, anyway... */
			if (dim[var].type) return perror_(__LINE__,63,l);
			if (dim[var].type==1 && T==2) return perror_(__LINE__,64,l);
			ern=dimArray(var,T,M,N);
			if (ern>0) return perror_(__LINE__,ern,l);
		}
		/* check syntax */
		if (*p!=')') return perror_(__LINE__,35,l);
		else p++;
	}
	/* user preset value for variables */
	else if (*p=='=') {
		p++;
		/* numeric variables */
		if (type==NUM) {
			P[var]=S();
			if (isEndOfStatement) return FALSE;
		}
		/* string variables */
		else {
			char op[COMPSTR];
			strncpy_(op,SS(),COMPSTR);
			if (isEndOfStatement) return FALSE;
			strncpy_(PS[var],op,COMPSTR);
		}
	}
	/* signal error in case of missing assignment to constants */
	else if (isConst) return perror_(__LINE__,191,l);
	/* preset null values for uninstantiated variables */
	else  {
		/* numeric variables */
		if (type==NUM) P[var]=0.0;
		/* string variables */
		else if (type==STR) strncpy_(PS[var],"",COMPSTR);
	}

	/* integer */
	if (bcomp(p,"AS")) {
		p+=4;
		if (!strncasecmp_(p,"INTEGER",7)) {
			p+=7;
			if (type==STR) return perror_(__LINE__,183,l);
			vn[var].isInt=TRUE;
			if (!vn[var].isArr) P[var]=(int)P[var];
		}
		else if (!strncasecmp_(p,"REAL",4)) {
			p+=4;
			if (type==STR) return perror_(__LINE__,183,l);
			if (isInt) return perror_(__LINE__,183,l);
			/* no-op */
		}
		else if (!strncasecmp_(p,"STRING",6)) {
			p+=6;
			if (type!=STR) return perror_(__LINE__,183,l);
			if (isInt) return perror_(__LINE__,183,l);
			/* no-op */
		}
		else return perror_(__LINE__,183,l);
	}
	
	/* set constant flag */
	if (isConst) vn[var].isConst=TRUE;
	else vn[var].isConst=FALSE;
	
	/* set name/type */
	namelen=((int)strlen(decname)+1)*sizeof(char);
	if (vn[var].name!=NIL) {
		free(vn[var].name);
		vn[var].name=NIL;
	}
	vn[var].name=xmalloc((size_t)namelen);
	if (!vn[var].name) return perror_(__LINE__,173,l);
	else strncpy_(vn[var].name,decname,namelen);
	vn[var].rettype=type;
	vn[var].isCommon=FALSE;

	/* update index
	 * Note: the update must be done here (i.e. after all other 
	 * operations) to prevent the fact that S() and SS() would read
	 * the variable before it is officially declared (S() and SS()
	 * start reading from decCount) */
	decCount++;

	/* debug features */
	if (isDebug) showDEC(decCount, TRUE);

	/* next assignment */
	if (*p==',' || *p==';') {
		p++;
		DECLARE(isConst);
	}
	return TRUE;
}


/******************************************
 *            BASIC INTERFACE             *
 ******************************************/


/* OLD() 
 * execute the OLD command, erasing memory and calling LOAD
 * Note: this statement is not available as a programming statement */
void OLD(void) {
	int i;

	/* erase core memory */
	for (i=0;i<MEMLIMIT;i++) {
		if (m[i]!=NIL && (int)strlen(m[i])>0) {
			free(m[i]);
			m[i]=NIL;
		}
		ln[i]=0;
	}
	/* LOAD */
	endCore=0;
	LOAD(m,filename,0,ALL_LINES);
	libStart=endCore;
} // OLD()


/* LOAD() 
 * load file in memory, from position 'stt'
 * filestr: name of file to open
 * m: memory where program is stored
 * what: specifies if all lines should be loaded or only SUBs (for libs)
 * Note: this statement is is not available as a programming statement.
 * If one among '@', '&' or '#' is set as the first character of a line, 
 * the loading is stopped/suspended; this lets store documentation within the 
 * source file; this feature didn't belong to the DEC BASIC 
 * Return 0 in case of correct execution */
int LOAD(char **m, char *filestr, int stt, int what) {
	FILE *f;
	char B[SCREENLINE+10], *pB=B;
	int isSuspended=FALSE;
	int saveSubs=FALSE;
	int linenum=stt;
	int isVoid=TRUE;

	/* open file */
	if (!(f=fopen(filestr,"r"))) {
		strcat(filestr,".bas");
		if (!(f=fopen(filestr,"r"))) {
			beginS=-1;
			return perror_(__LINE__,1,-1,filestr);
		}
		strcpy(filename,filestr);
	}

	/* load lines one by one */
	while(fgets(B,SCREENLINE+9,f) && linenum<MEMLIMIT-1) {
		pB=B;
		if (!*pB) continue;
		while (isblank(*pB)) pB++;
		/* check if it's a void/NIL line (i.e. a line with
		 * no line number and no statements) */
		if (!*pB) continue;
		/* check if it's in Interactive mode (loading mode before
		 * starting sessions) and it's not numbered: do an implicit
		 * CONVERT and load the source */
		if (!isLOAD && startInteractive && !endCore) {
			if (*pB<'0' || *pB>'9') {
				if (convert(f,100,10));
				else return perror_(__LINE__,182,-1);
				return 0; // end up here
			}
		}	
		/* check if it's in Interactive mode (LOAD is used after
		 * starting sessions) and it's not numbered: issue an
		 * error because file is not implicitly converted */
		else if (isLOAD && startInteractive && !endCore) {
			if (*pB<'0' || *pB>'9') {
				return perror_(__LINE__,182,-1);
				return 0; // end up here
			}
		}
		/* check if file is a normal or random file */
		if (*pB=='�') {
			if (f) fclose(f);
			return perror_(__LINE__,97,-1);
		}
		/* suspend loading between two '@' */
		if (*pB=='@' && isSuspended) {
			isSuspended=FALSE;
			continue;
		}
		if (*pB=='@' && !isSuspended) {
			isSuspended=TRUE;
			continue;
		}
		if (isSuspended) continue;
		if ((int)strlen(B)>0) {
			char *w=B;
			/* strip away EOL */
			while (*(w+strlen(w)-1)=='\r') *(w+strlen(w)-1)='\0';
			while (*(w+strlen(w)-1)=='\n') *(w+strlen(w)-1)='\0';
			while (*(w+strlen(w)-1)=='\r') *(w+strlen(w)-1)='\0';
			/* if line has no end-of-string, maybe it's too long */
			if (strlen(w)>=COMPSTR) {
				if (f) fclose(f);
				return perror_(__LINE__,10,linenum);
			}
			/* remove trailing spaces and EOL */
			while (isblank(*w)) w++;
			pB=w;
			while (isblank(*(w+strlen(w)-1))) *(w+strlen(w)-1)='\0';
		}
		/* discard empty lines and lines beginning with # */
		if (*pB=='#') continue;
		/* well, this is the point to increment */
		linenum++;
		/* store line */
		if (what==ONLY_SUBS) {
			char *t; // dull
			char *bB=pB;
			/* get rid of label if present */
			if (isdigit(*pB)) {
				while (isdigit(*pB)) pB++;
			}
			/* now empty lines that are empty only here, are
			 * discarded */
			if (!*pB) {
				linenum--;
				continue;
			}
			/* unnumbered library: load it and add line numbers, 
			 * not overlapping existing program lines */
			else if (startInteractive) {
				char temp[COMPSTR];
				int lne=ln[endCore], k=1;
				if (lne%10) k=2;
				lne=((int)(lne/10.0)+k)*10;
				strcpy(temp,pB);
				sprintw(B,COMPSTR,"%d ",lne);
				strcat(B,temp);
				pB=B;
				bB=pB;
				while (isdigit(*pB)) pB++;
			}
			while (isblank(*pB)) pB++;
			/* set saving flag when SUB starts */
			if (!strncasecmp_(pB,"SUB",3)) {
				saveSubs=TRUE;
				tlib[libTOS].start=linenum;
			}
			/* set saving flag when DECLARE SUB starts */
			else if (checkCommand(pB,"DECLARE SUB",&t)) {
				saveSubs=TRUE;
				tlib[libTOS].start=linenum;
			}
			/* set saving flag with DEF */
			else if (!strncasecmp_(pB,"DEF",3)) {
				char *pC=pB+3;
				while (isblank(*pC)) pC++;
				/* set DEF flag with multiline DEF starts */
				if (isSingleDEF(pC)==MULTI) {
					saveSubs=TRUE;
					tlib[libTOS].start=linenum;
				}
				/* save directly line with single line DEF*/
				else if (isSingleDEF(pC)==SINGLE) {
					int ern=0;
					ern=storeSingleLineToCore(pB,linenum);
					if (ern>0) 
						return perror_(__LINE__,ern,l);
					saveSubs=FALSE;
					tlib[libTOS].start=linenum;
					tlib[libTOS].end=linenum;
				}
				/* it's a malformed DEF */
				else {
					if (f) fclose(f);
					return perror_(__LINE__,37,l);
				}
			}
			/* save only in case saving flag is TRUE 
			 * (use the labelled position of bB) */
			if (saveSubs) {
				int ern=0;
				ern=storeSingleLineToCore(bB,linenum);
				if (ern>0) return perror_(__LINE__,ern,l);
			}
			else linenum--;
			/* reset saving flag when SUB or multiline DEF end */
			if (checkCommand(pB,"END SUB",&pB)) {
				saveSubs=FALSE;
				tlib[libTOS].end=linenum;
				libTOS++;
			}
			else if (!strncasecmp_(pB,"FNEND",5)) {
				saveSubs=FALSE;
				tlib[libTOS].end=linenum;
				libTOS++;
			}
			if (libTOS>SUBSTACKLIM-1) 
				return perror_(__LINE__,187,l);
		}
		else {
			int ern=0;
			ern=storeSingleLineToCore(pB,linenum); 
			if (ern>0) return perror_(__LINE__,ern,l);
		}
		isVoid=FALSE;
		endCore=linenum;
	}

	/* check if file was entirely loaded */
	if (!feof(f) && linenum==MEMLIMIT-1) {
		if (f) fclose(f);
		return perror_(__LINE__,9,-2);
	}

	/* check void files */
	if (isVoid) {
		if (f) fclose(f);
		return perror_(__LINE__,2,-1,filename);
	}

	/* close file channel */
	if (f) fclose(f);
	return 0;
}


/* resetVars()
 * clear all data about memory management */
void resetVars(void) {
	int i=0;
	/* reset variables and constants data */
	for(i=0; i<VLIMIT; i++) {
		/* set numerical variables and relative flags*/
		P[i]=0.0;
		/* set numerical arrays references */
		if (dim[i].elem) *dim[i].elem=0.0;
		dim[i].type=NIL;
		/* set string references */
		PS[i][0]='\0';
		/* set string arrays references */
		if (dimS[i].elem) dimS[i].elem=NIL;
		dimS[i].type=NIL;
		/* reset COMMON flag */
		vn[i].isCommon=FALSE;
	}
	/* reset DEFFN references */
	for(i=0; i<2*LIMIT; i++) {
		fn[i].type=0;
		gosubStack[i]=0;
	}
	/* reset inner addresses references */
	for(i=0; i<=MEMLIMIT; i++) {
		cAddr[i]=0;
		forAddr[i]=0;
		whileAddr[i]=0;
		doAddr[i]=0;
		selectAddr[i]=0;
		ifAddr[i]=0;
		/* masking flag */
		fm[i]=0;
	}
	decCount=0;
	/* reset DEF, SUB and DECLARE data */
	isDefRun=isDefVar=isDefCalc=isDefFor=isDefWhile=isDefDo=isDefCount=0;
	isSubRun=isSubVar=isSubCalc=isSubFor=XCount=subCount=decCount=0;
	/* reset DATA and MAT vars */
	numValue=dc=dcs=dataLimit=dataLimitS=0;
	detValue=0.0;
	/* reset GOSUB, FOR, WHILE, DO data */
	gosubTOS=forTOS=forcount=whileTOS=whilecount=doTOS=docount=0;
	/* reset SELECT and IF data */
	selectTOS=selectcount=ifTOS=0;
	/* reset WHEN ERROR and ON ATTENTION data */
	errLine=arrLine=errValue=arrValue=isOnErrorPos=isOnErrorTrap=0;
	isNoDataPos=isWhenErrorInPos=isWhenErrorUsePos=isUsePos=0;
	isUseActive=isHandlerActive=FALSE;
	isHandlerNum=endWhenIn=endWhenUse=handlerTOS=isOnAttentionPos=0;
}


/* evalPragra()
 * evaluate PRAGMA line to execute options that have distributable sense 
 * System function for RUN
 * (PRAGMA is a noop) */
void evalPragma(char *str) {
	while (*str) {
		while (isblank(*str)) str++;
		if (!strncmp(str,"-d",2)) {
			isDebug=TRUE,debugRaw=FALSE;
		}
		else if (!strncmp(str,"-N",2)) {
			phantomString=TRUE;
		}
		else if (!strncmp(str,"-r",2)) {
			isDebug=debugRaw=TRUE;
		}
		else if (!strncmp(str,"-T",2)) {
			isTiming=TRUE;
		}
		else if (!strncmp(str,"-H",2)) {
			isHeader=TRUE;
			printHeader();
		}
		else if (!strncmp(str,"-D",2)) {
			isInvDebug=FALSE;
		}
		str+=2;
	}
}

/* RUN()
 * the RUN command 
 * Note: this statement is executed at start automatically and is not 
 * available as a programming statement */
int RUN(void) {
	int i,j;

	opturn=0; // for safety

	/* COMMON passing */
	if (isCommon) {
		i=1;
		/* cycle through all variables */
		while (i<decCount) {
			/* in case of a not-COMMON variable, try exchanging
			 * it with the first COMMON onward */
			if (!vn[i].isCommon) {
				j=i+1;
				/* search next COMMON */
				while (!vn[j].isCommon && j<=decCount) j++;
				/* change only in the range of current vars */
				if (vn[j].isCommon && j<=decCount) {
					swapDEC(i,j);
					futureDecCount=i;
				}
			}
			/* in case of a COMMON variable, simply update
			 * future counter */
			else futureDecCount=i;
			i++;
		}
		/* rule last variable, in case it's COMMON (this means the
		 * last swap was not done) */
		if (vn[i].isCommon) futureDecCount=i;
		/* set DEF, SUB and DECLARE data */
		isDefRun=isDefVar=isDefCalc=isDefFor=isDefCount=0;
		isSubRun=isSubVar=isSubCalc=isSubFor=subCount=0;
		decCount=futureDecCount;
	}
	/* reset memory if required */
	else if (isToReset) {
		resetVars();
	}

	/* reset memory beyond endCore */
	removeLibs();
	for (i=endCore+1;i<=MEMLIMIT;i++) {
		if (m[i] && *m[i] && strlen(m[i])) {
			free(m[i]);
		}
	}

	/* reset hide flag */
	for (i=0;i<=MEMLIMIT;i++) fm[i]=0;
	
	/* reset FOR/GOSUB references and FOR/NEXT address array 
	 * specific for each RUN() */
	gosubTOS=forTOS=forcount=0;

	/* reset channels info specific for each RUN() */
	for(i=1; i<=STREAMS; i++) channel[i].type=NOUSE;

	/* record starting time if not in a CHAINed program
	 * beginS is used also into the TIM function */
        if (!isChain) {
        	gettimeofday(&tv, NULL);
           	beginS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
        }

	/* check if start line is within a DEF FN */
	if (fm[startingLine]) return perror_(__LINE__,39,l);

	/* preparsing operations */
	if (endCore<1) return TRUE;
	preParse(m,1,endCore);
	/* list in bare mode, and see what tbas sees */
	if (listingDo==BARE) {
		int i;
		char s[COMPSTR];
		for (i=1; i<=endCore; i++) {
			if (!m[i] || !*m[i]) continue;
			stripBlanks2(m[i],s);
			silenceTick(s);
			/* print BASIC line */
			if (ln[i]>0) 
			      fprintf(stdout, "%05d  %s\n",ln[i],s);
			else  
			      fprintf(stdout, "       %s\n",s);
		}
		isNoExecute=TRUE;
	}
	/* list in gracious indented mode, see what the user should see */
	else if (listingDo==INDENT) {
		list_indented(FALSE,libStart,ln[1],ln[endCore],stdout,fullLines);
		fprintf(stdout,"\n");
		isNoExecute=TRUE;
	}
	if (isNoExecute) return TRUE;
	isRunOn=TRUE; // needed by perror_()
	/* and finally, execute program if everything in preParse() is OK */
	isInterrupt=FALSE;
	parse(m,startingLine,endCore);
	return TRUE;
}



/* ABORT */
int ABORT(void) {
	/* ABORT alone behaves as STOP */
	while (isblank(*p)) p++;
	if (!*p) END(EXIT_STOP);
	else fprintf(stderr,"%s\n",SS());
	if (isEndOfStatement) return FALSE;
	if (!startInteractive) END(EXIT_ABORT);
	return TRUE;
}


/* closeFiles()
 * close all PREPEND features and close all files in the queue */
int closeFiles(void) {
	int i=0, none=TRUE;

	/* file streams */
	for (i=1; i<=STREAMS;i++) {
		/* I don't check for errors here, because the function
		 * assures only that opened channels must be closed.*/
		if (channel[i].isPrepend) closePrepend(i);
		if (channel[i].isopen) {
			if (channel[i].stream) 
				fclose(channel[i].stream);
			none=FALSE;
		}
	}
	/* INCLUDE input file  */
	if (CONSOLEIN!=stdin) {
		if (CONSOLEIN) 
			fclose(CONSOLEIN);
		CONSOLEIN=stdin;
	}
	return none;
}


/* in case of timing, add the timed calculation string 
 * (avoid though to do it at the end of the interactive sessio */
void timedString(double endS) {
	int hour=0,min=0;
	double secs=endS;
	/* precalculate intermediate time values */
	if (endS>60) {
		min=endS/60;
		endS=endS-min*60;
	}
	if (min>60) {
		hour=min/60;
		min=min-hour*60;
	}
	/* depict time in condensed form */
	if (!hour && !min) 
		fprintf(stdout,"TIME:  %.2f SECS.\n",endS);
	else if (!hour)
		fprintf(stdout,"TIME:  %.2d:%.2d MINS   (%.2f SECS).\n",min,(int)(endS+0.5),secs);
	else 	
		fprintf(stdout,"TIME:  %.2d:%.2d:%.2d HOUR%c   (%.2f SECS).\n",hour,min,(int)(endS+0.5),hour>1?'S':'\0',secs);
}


/* END()
 * end program, accomplishing various tasks, such as closing opened channels,
 * print timing, fixing graphical stuff and closing regularly as C requires.
 * Note: as exit state, return the state passed to it as argument.
 * Note: as the returned states, I use:
 * EXIT_SUCCESS (which is 0) to indicate a proper successful execution
 * EXIT_FAILURE (which is 1) to indicate a stop after an error condition
 * EXIT_STOP (which is 2) to indicate an invoked STOP termination */
int END(int state) {
	int i, none=TRUE;

	if (startInteractive) l=endCore; //force ending

	/* FILE OPERATIONS */
	/* close and setup all files */
	none=closeFiles();

	/* DEBUGGING INFO */
	if (isDebug && !isNoExecute) {
		if (isInvDebug) fprintf(stdout,INVCOLOR);
		fprintf(stdout,"\ndebug: structures and files remnants:");
		if (!(ifTOS+selectcount+forcount+docount+whilecount))
			fprintf(stdout," none.\n\n");
		else fprintf(stdout,"\n\n");
		if (ifTOS) 
			fprintf(stdout,"'If' remnants       : %lld\n",ifTOS);
		if (selectcount)
			fprintf(stdout,"'Select' remnants   : %d\n",selectcount);
		if (forcount)
			fprintf(stdout,"'For-Next' remnants : %d\n",forcount);
		if (docount)
			fprintf(stdout,"'Do-Loop' remnants  : %d\n",docount);
		if (whilecount)
			fprintf(stdout,"'While' remnants    : %d\n",whilecount);
		if (!none) {
			fprintf(stdout,"Streams left open   : ");
			for (i=1; i<=STREAMS;i++) {
				if (channel[i].isopen) {
					channel[i].isopen=FALSE;
					fprintf(stdout,"%d, ",i);
				}
			}
			fprintf(stdout,"\n");
			channel[CONSOLE].fcounter=0;
		}
		if (isInvDebug) fprintf(stdout,RESETCOLOR);
	}
	/* TIMING OPERATIONS */
	/* record end time 
	 * Note: if file was not found, beginS remains negative */
	if (beginS<0) endS=0.0;
	else {
		gettimeofday(&tv, NULL);
	       	endS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		endS=endS-beginS;
	}

	/* free sub memory */
	for (i=1; i<=subCount;i++) {
		if (sn[i].strres) {
			free(sn[i].strres);
			sn[i].strres=NIL;
		}
	}
					

	/* ROUTING OPERATIONS */
	/* send routing file to printer in case ROUTE is not used */
	if (isQueued || isLPrintEnabled) ROUTE();

	/* GRAPHICAL OPERATIONS */
	/* CTRL-C was pressed in the console execution: print to signal */
	if (isInterrupt && !startInteractive) {
		fprintf(stdout, "\n\ntbas stopped after user interrupt at line %d",l);
		if (ln[l] && l>=0) fprintf(stdout," (labelled as %d)",ln[l]);
		fprintf(stdout,"\n\n");
	}
	/* SYSTEM READY string */
	else if (state==EXIT_SYSTEM) {
		fprintf(stdout, "\n\nREADY.\n\n");
	}
	/* add a Carriage Return in case of suspended PRINT */
	else if (channel[CONSOLE].fcounter) fprintf(stdout, "\n");

	/* in case the NOECHO option was specified, disable */
	if (!isEcho) {
		termiosHasOccurred=TRUE;
		tcsetattr(0, 0, &savemodes);
		modes.c_lflag &= ~ECHO;
	}

	/* add timed string */
	
	if (isTiming) {
		fprintf(stdout,"\n\n\n");
		timedString(endS);
		fprintf(stdout,"\n");
	}
		
	/* QUITTING */
	/* flush all open streams, to ensure file data writing is completed */
	fflush(NULL);
	/* console mode */
	if (!startInteractive) {
		s_exit(state);
	}
	/* interactive mode */
	else {
		beginS=-1;
		endS=0.0;
	}
	return TRUE;
}


/* s_exit()
 * safe exit - avoid messing up of colours, and force the screen resetting
 * return 'state' as current state
 * system function */
void s_exit(int state) {
	/* check for closing brackets */
	if (termiosHasOccurred) tcsetattr(0, 0, &savemodes);
	if (isDebug) {
		if (isInvDebug) fprintf(stdout,RESETCOLOR);
	}
	setrlimit(RLIMIT_STACK,&origrlim);
	if (isSystem && sysqueue[0]) system(sysqueue);
	exit(state);
}


/******************************************************************************
 * The following functions define the whole parser engine:
 * SS() 	  : the strings expression parser
 * strRel()       : the strings relation evaluator (returns a truth value)
 * S() 		  : the numerical expression parser
 * getVal()	  : the single numerical value parser 
 * getFunc()	  : the numerical function parser
 * priority()	  : return numerical operator precedence
 * conceived April 2008 for the dib project
 * modified for vibes with strings insertion September-November 2009
 * updated and verified for tbas - February 2013, February-Summer 2014
 * Copyleft Antonio Maschio - 2008-2015 
 ******************************************************************************/

/* SS()
 * The PARSER for string expression; it's a general routine that contains
 * also evaluation of functions and concatenation of strings in series
 * if the + (plus) or & (ampersand) operators are used. 
 * The name SS() comes from S() and the second S means "strings".
 * The address of starting position into the flow stream is pointed by p 
 * The algorithm is as follows: 
 * until there is a string in any form, append it to mypad; return mypad. */
char* SS(void) {
	int i,ns,type=0,rettype=0,cn=0;
	double numres;
	char mypad[COMPSTR], strres[COMPSTR], *opT;

	/* create local pad and reset */
	for (i=0;i<COMPSTR;i++) mypad[i]='\0';
	MYPAD=mypad;
	p--;

	/* calculate string result
	 * accept concatenation with '+' and '&' */
	do {
		p++;
		/* open/close parenthesis */
		if (*p=='(') {
			p++;
			strncat_(mypad,SS(),COMPSTR);
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
		}
		/* explicit string */
		else if (*p=='\"') {
			char op[COMPSTR], *P1=op;
			p++;
			while (*p && *p!='\"') {
				if (isRawPrint && *p=='\\' && *(p+1)=='\"') {
					*P1++='\\';
					*P1++='\"';
					p+=2;
				}
				else *P1++=*p++;
			}	
			*P1='\0';
			if (*p=='\"') p++; // skip closing quotes
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) { 
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* SUB string functions */
		else if ((ns=findSUB(p,&opT,&type,&rettype))) {
			if (type==FUNC && rettype==STR)	{
				execSUB(ns,opT,&numres,strres);
				strncat_(mypad,strres,COMPSTR);
			}
			else {
				perror_(__LINE__,218,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
		}
		/* PIPE$ return bash/DOS program output
		 * the connection with the program command is done 
		 * by the file statement PIPE  */
		else if (!strncasecmp_(p,"PIPE$",5)) {
			int sliceDim=0, isImmediate=FALSE;
			p+=5;
			/* set user slice dimension */
			if (*p=='(') {
				p++; // skip open
				sliceDim=S();
				if (*p==')') p++;
			}
			else isImmediate=TRUE;
			/* check for length correctness */
			if (sliceDim>MAXSTRLEN) {
				perror_(__LINE__,146,l);
				return MYPAD;
			}
			else if (!isImmediate && sliceDim<1) {
				perror_(__LINE__,146,l);
				return MYPAD;
			}
			/* if command is empty, copy empty string */
			else if (((comout && !strlen(comout)) || !comout)) {
				strncat_(mypad,"",COMPSTR);
			}
			/* return whole output (immediate mode PIPE$) */
			else if (isImmediate || sliceDim<1) {
				strncat_(mypad,comout,COMPSTR);
			}
			/* return next slice (user mode PIPE$() )*/
			else {
				int add=0, i=0;
				/* count EOL in this slice */
				while (i<sliceDim)  {
					if (*(comout+Tslice+i)=='\0') break;
					/* UNIX EOL && second Windows EOL */
					if (*(comout+Tslice+i)==10) add++;
					/* First Windows EOL */
					else if (*(comout+Tslice+i)==13) add++;
					i++;
				}
				sliceDim+=add;
				char base[sliceDim+1]; // store adder
				if ((int)strlen(mypad)+sliceDim>MAXSTRLEN) {
					perror_(__LINE__,124,l);
					return MYPAD;
				}
				i=0;
				while (i<sliceDim) {
					if (*(comout+Tslice+i)=='\0') break;
					base[i]=*(comout+Tslice+i);
					i++;
				}
				base[i]='\0';
				strncat_(mypad,base,COMPSTR);
				Tslice+=sliceDim;
			}
		}
		/* INKEY$ (one-char input buffer) */
		else if (!strncasecmp_(p,"INKEY$",6)) {
			char cc[2];
			double extraS;
			struct termios thismodes, thissavemodes;
			int thistermiosHasOccurred=termiosHasOccurred;
			int secs=0;
			p+=6;
			/* get optional argument: timed inkey$ */
			if (*p=='(') {
				p++;
				secs=(int)S();
				if (secs<0) secs=-secs;
				if (secs>60) secs=60;
				if (*p==')') p++;
				else {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
			}

			/* delay time */
        		gettimeofday(&tv, NULL);
       			extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);

			/* set tcgetattr values backing up current state */
			tcgetattr(0, &thismodes);
			thissavemodes = thismodes;
			termiosHasOccurred=TRUE;
			thismodes.c_lflag &= ~ICANON;
			thismodes.c_lflag &= ~ECHO;
			/* normal INKEY$ */
			if (!secs) {
				tcsetattr(0, 0, &thismodes);
				/* Note: INKEY$ requires **always** the
				 * input from keyboard */
				cc[0] = (char)fgetc(stdin);
				cc[1]='\0';
			}
			/* timed INKEY$ */
			else {
				cc[0]='\0';
				cc[1]='\0';
				thismodes.c_cc[VMIN]=0;
				thismodes.c_cc[VTIME]=secs*10;
				tcsetattr(0, 0, &thismodes);
				read(0, cc, 1);
				cc[1]='\0';
			}
			tcsetattr(0, 0, &thissavemodes);
			termiosHasOccurred=thistermiosHasOccurred;
			if ((int)strlen(mypad)+1>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,cc,COMPSTR);
			/* get timer again to exclude user delay from timing 
			 * and update beginS */
		        gettimeofday(&tv, NULL);
		       	extraS=((double)tv.tv_sec+tv.tv_usec/1000000.0)-extraS;
			beginS=beginS+extraS;
		}
		/* INPUT$ (& cut) string from keyboard */
		else if (!strncasecmp_(p,"INPUT$",6)) {
			char op[COMPSTR];
			op[0]='\0';
			struct termios thismodes, thissavemodes;
			int thistermiosHasOccurred=termiosHasOccurred;
			int num=0;
			p+=6;
			/* no arguments in UNIX: use getString */
			if (*p!='(') {
				FILE *fin=CONSOLEIN;
				CONSOLEIN=stdin;
				strncpy_(op,getString(),COMPSTR);
				CONSOLEIN=fin;
			}
			/* there's an argument in UNIX: string length */
			else {
				char *lp=op;
				int li=0;
				p++;
				num=(int)S();
				if (num<0) num*=-1;
				if (!num || num>MAXSTRLEN) num=MAXSTRLEN;
				if (*p!=')') {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
				else p++;
				/* set tcgetattr values 
				 * backing up current state */
				tcgetattr(0, &thismodes);
				thissavemodes = thismodes;
				termiosHasOccurred=TRUE;
				thismodes.c_lflag &= ~ICANON;
				thismodes.c_lflag &= ~ECHO;
				/* set up termios data, 
				 * included controlling features */
				tcsetattr(0, 0, &thismodes);
				while (li<num) {
					*lp=fgetc(stdin);
					if (*lp==10 || *lp==13 || *lp=='\n') {
						*lp='\0';
						break;
					}
					else {
						if (isEcho)
							fputc(*lp,stdout);
						lp++;
					}
					li++;
				}
				*lp='\0';
				tcsetattr(0, 0, &thissavemodes);
				termiosHasOccurred=thistermiosHasOccurred;
			}
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* FORMAT$() function (CDC tradition)
		 * ~return string with number formatted according to the
		 * laws of PRINT USING (through printFormatted().
		 * The intermediate result is stored into _FORMAT )*/
		else if (!strncasecmp_(p,"FORMAT$(",8)) {
			double val;
			char op[COMPSTR];
			int ern=0;
			p+=8;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,214,l);
				return MYPAD;
			}
			if (*p==',') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			if (isanynumber(p)) {
				val=S();
			}
			else {
				perror_(__LINE__,215,l);
				return MYPAD;
			}
			ern=printFormatted(op,NIL,FALSE,val);
			if (ern>0) {
				perror_(__LINE__,ern,l);
				return MYPAD;
			}
			if ((int)strlen(mypad)+(int)strlen(_FORMAT)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,_FORMAT,COMPSTR);
		}
		/* LTRIM$() function
		 * ~return a string with trimmed left trailing spaces
		 * (ahead only) */
		else if (!strncasecmp_(p,"LTRIM$(",7)) {
			char op[COMPSTR], res[COMPSTR];
			p+=7;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,214,l);
				return MYPAD;
			}
			strncpy_(res,dotrim(op,1),COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(res)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,res,COMPSTR);
		}
		/* RTRIM$() function
		 * ~return a string with trimmed right trailing spaces
		 * (behind only) */
		else if (!strncasecmp_(p,"RTRIM$(",7)) {
			char op[COMPSTR], res[COMPSTR];
			p+=7;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,214,l);
				return MYPAD;
			}
			strncpy_(res,dotrim(op,2),COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(res)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,res,COMPSTR);
		}
		/* TRIM$() function (CDC tradition)
		 * ~return a string with trimmed trailing spaces
		 * (ahead and behind) */
		else if (!strncasecmp_(p,"TRIM$(",6)) {
			char op[COMPSTR], res[COMPSTR];
			p+=6;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,214,l);
				return MYPAD;
			}
			strncpy_(res,dotrim(op,3),COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(res)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,res,COMPSTR);
		}
		/* ENV$() function
		 * ~return a string with the content of the environment variable
		 * passed as a string argument */
		else if (!strncasecmp_(p,"ENV$(",5)) {
			char env[COMPSTR], value[COMPSTR];
			p+=5;
			if (!isanystring(p)) {
				perror_(__LINE__,218,l);
				return MYPAD;
			}
			strncpy_(env,SS(),COMPSTR);
			if (!getenv(env) || !env[0]) value[0]='\0';
			else strncpy_(value,getenv(env),COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(value)>MAXSTRLEN) { 
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,value,COMPSTR);
		}
		/* FREE$ 
		 * ~return number of free program slots as a string; 
		 * the argument is dummy */
		else if (!strncasecmp_(p,"FREE$",5)) {
			char value[COMPSTR];
			p+=5;
			if (*p=='(') {
				p++;
				S();
				if (*p==')') p++;
				else {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
			}
			sprintw(value, COMPSTR, "%d", MEMLIMIT-endCore);
			if ((int)strlen(mypad)+(int)strlen(value)>MAXSTRLEN) { 
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,value,COMPSTR);
		}
		/* DIR$ system variable
		 * ~return a string with the content of current working
		 * directory; the argument is dummy */
		else if (!strncasecmp_(p,"DIR$",4)) {
			char value[COMPSTR];
			p+=4;
			if (*p=='(') {
				p++;
				S();
				if (*p==')') p++;
				else {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
			}
			strncpy_(value,getenv("PWD"),COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(value)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,value,COMPSTR);
		}
		/* ESM$()/ERR$() functions (CDC and HP tradition)
		 * ~return a string with error message of the code argument
		 * or current error message if argument is null 
		 * Note: this function requires an argument! 
		 * Note: this function cannot return an error, so
		 * any strange input is overridden */
		else if ((cn=recog(2,p,"ESM$(","ERR$("))) {
			int o;
			char op[COMPSTR];
			p+=cn;
			op[0]='\0';
			if (!isanynumber(p)) {
				o=0;
				if (*p!=')') syserr_(__LINE__,217,l);					}
			else o=(int)S();
			if (o<0) o=0;
			if (o>ERRLIM) o=ERRLIM;
			if (!op[0]) strncpy_(op,error[o?o:errValue],COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN || *p!=')') {
				strncat_(mypad,"",COMPSTR);
			}
			else strncat_(mypad,op,COMPSTR);
			if (*p==')') p++;
			else syserr_(__LINE__,37,l);
		}
		/* STRING$() function 
		 * ~return a string composed by n copies in the first argument
		 * of ASCII character or string in second argument */
		else if (!strncasecmp_(p,"STRING$(",8)) {
			int o;
			char op[COMPSTR];
			int c=0;
			p+=8;
			o=(int)S();
			if (*p!=',') {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			else p++;
			if (o<0) o=1;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				c=(char)S();
				sprintw(op,COMPSTR,"%c",c);
			}
			if ((int)strlen(mypad)+o*(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			while (o>0) {
				strncat_(mypad,op,COMPSTR);
				o--;
			}
		}
		/* LPAD$() function (CDC tradition)
		 * ~return a string a$ in first argument left-padded with 
		 * spaces if shorter than the length n in second argument */
		else if (!strncasecmp_(p,"LPAD$(",6)) {
			int o=0, tl=0;
			char op[COMPSTR];
			p+=6;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,218,l);
				return MYPAD;
			}
			if (*p!=',') {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			else p++;
			o=(int)S();
			if (o<0) {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			tl=(int)strlen(op);
			o=o>tl?o:tl;
			if ((int)strlen(mypad)+o>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			o-=tl;
			while (o-->0) strncat_(mypad," ",COMPSTR);
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* RPAD$() function (CDC tradition)
		 * ~return a string a$ in first argument right-padded with 
		 * spaces if shorter than the length n in second argument */
		else if (!strncasecmp_(p,"RPAD$(",6)) {
			int o=0, tl=0;
			char op[COMPSTR];
			p+=6;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,218,l);
				return MYPAD;
			}
			if (*p!=',') {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			else p++;
			o=(int)S();
			if (o<0) {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			tl=(int)strlen(op);
			o=o>tl?o:tl;
			if ((int)strlen(mypad)+o>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
			o-=tl;
			while (o-->0) strncat_(mypad," ",COMPSTR);
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
		}
		/* RPT$()/REPEAT$() function (CDC tradition)
		 * ~return a string composed by repeated copies of the string
		 * in the first argument by n copies in second argument */
		else if ((cn=recog(2,p,"RPT$(","REPEAT$("))) {
			int o;
			char op[COMPSTR];
			p+=cn;
			if (isanystring(p)) {
				strncpy_(op,SS(),COMPSTR);
			}
			else {
				perror_(__LINE__,218,l);
				return MYPAD;
			}
			if (*p!=',') {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			else p++;
			o=(int)S();
			if (o<0) {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			if ((int)strlen(mypad)+o*(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			while (o>0) {
				strncat_(mypad,op,COMPSTR);
				o--;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
		}
		/* WEEKDAY$()
		 * ~return current week day 
		 * Note: the algorithm for a casual date is simple and, for 
		 * dates between YEARLIMIT (currently set equal to 1583) and 
		 * the current year, it returns always correct 
		 * values (at least as far as I can test); the algorithm:
		 * ~- convert date to Gregorian day number
		 * ~- subtract 1 because we start with Sunday=0 not Sunday=1
		 * ~- subtract another 1
		 * ~- return mod 7: value is 0~6 (Sun~Sat) 
		 * ~Antonio Maschio - August 2014 */
		else if (!strncasecmp_(p,"WEEKDAY$",8)) {
			double o;
			int cut=0;
			char mon[32];
			p+=8;
			if (*p=='(') {
				o=S();
				if (*p==',') {
					p++;
					cut=(int)S();
				}
				if (*p==')') p++;
				else {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
			}
			else o=0.0;
			if (cut<0) cut=0;
			if (cut>3) cut=3;
			if (o==0.0) {
				if (cut) 
				     strncpy_(mon,daylabel[getWDay()],cut+1);
				else 
				     strncpy_(mon,daylabel[getWDay()],32);
			}
			else {
				/* any date's weekday - some dates tested on
				 * http://www.timeanddate.com/date/weekday.html
				 * The leap year is implicit (02/29 converted
				 * 03/01 implicitly) */
				int w,ty,tm,td; // from decimal date
				ty=(int)o; // yy or yyyy
				tm=(int)((o-ty)*100); // mm
				td=(int)((o*100-tm-100*ty)*100+0.5); // day
				ty=setYear(ty);
				w=gregDayNumber(ty,tm,td)-2;
				if (cut) strncpy_(mon,daylabel[w%7],cut+1);
				else strncpy_(mon,daylabel[w%7],32);
			}
			if ((int)strlen(mypad)+(int)strlen(mon)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,mon,COMPSTR);
		}
		/* MONTH$() 
		 * ~if argument is 0, return current month
		 * ~if argument is in the format yy.mmdd or yyyy.mmdd, 
		 * extract month label */
		else if (!strncasecmp_(p,"MONTH$",6)) {
			double o, cut=0;
			char mon[32];
			p+=6;
			if (*p=='(') {
				p++;
				o=S();
				if (*p==',') {
					p++;
					cut=(int)S();
				}
				if (*p==')') p++;
				else {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
			}
			else o=0.0;
			if (cut<0) cut=0;
			if (cut>3) cut=3;
			/* get current values */
			if (o==0.0) {
				if (cut) 
				  strncpy_(mon,monthlabel[getMonth()],cut+1);
				else 
				  strncpy_(mon,monthlabel[getMonth()],32);
			}
			/* get decimal argument values */
			else {
				o-=(int)o;
				o=(int)(o*100+0.5);
				if (cut) 
				  strncpy_(mon,monthlabel[(int)(o)],cut+1);
				else 
				  strncpy_(mon,monthlabel[(int)(o)],32);
			}
			if ((int)strlen(mypad)+(int)strlen(mon)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,mon,COMPSTR);
		}
		/* COMMAND$ function
		 * ~return tbas arguments string */
		else if (!strncasecmp_(p,"COMMAND$",8)) {
			p+=8;
			strncat_(mypad,command_string,MAXSTRLEN);	
		}
		/* PROGRAM$ function
		 * ~return the file name string */
		else if (!strncasecmp_(p,"PROGRAM$",8)) {
			p+=8;
			strncat_(mypad,filename,MAXSTRLEN);	
		}
		/* CLK$ function (CDC tradition)
		 * ~return the hour in the format HH.MM.SS  */
		else if (!strncasecmp_(p,"CLK$",4)) {
			int h=getHour(),m=getMin(),s=getSec();
			char str[16];
			p+=4;
			sprintw(str,16," %02d.%02d.%02d",h,m,s);
			if ((int)strlen(mypad)+9>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,str,COMPSTR);	
		}
		/* EXPR$ function
		 * return the rest of the string evaluated 
		 * by the most recent EXPR() */
		else if (!strncasecmp_(p,"EXPR$",5)) {
			p+=5;
			if ((int)strlen(mypad)+strlen(exprRest)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,exprRest,COMPSTR);	
		}
		/* EVAL$ function
		 * return the rest of the string evaluated 
		 * by the most recent EVAL() */
		else if (!strncasecmp_(p,"EVAL$",5)) {
			p+=5;
			if ((int)strlen(mypad)+strlen(exprRest)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,evalRest,COMPSTR);	
		}
		/* VAL$ function
		 * return the rest of the string evaluated 
		 * by the most recent VAL() */
		else if (!strncasecmp_(p,"VAL$",4)) {
			p+=4;
			if ((int)strlen(mypad)+strlen(exprRest)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,valRest,COMPSTR);	
		}
		/* CHR$ function 
		 * ~return a one-character string with the picture of the
		 * ASCII numeric value in argument */
		else if (!strncasecmp_(p,"CHR$(",5)) {
			char chop[2];
			char val;
			p+=5;
			val=(char)S();
			chop[0]=val;
			chop[1]='\0';
			if ((int)strlen(mypad)+1>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,chop,COMPSTR);
		}
		/* DATE$/DAT$ function (based on DAT$ of CDC tradition)
		 * ~return the date in the format YY/MM/DD (KRONOS/NOS feat.)*/
		else if ((cn=recog(2,p,"DATE$","DAT$"))) {
			int y=getYear(),m=getMonth(),d=getDay();
			char str[16];
			p+=cn;
			/* retain year's last two digits only */
			while (y>1000) y-=1000;
			while (y>100) y-=100;
			sprintw(str,16," %02d/%02d/%02d",y,m,d);
			if ((int)strlen(mypad)+9>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,str,COMPSTR);	
		}
		/* SPACE$/SPC$ function (SPC$ from Dartmouth tradition)
		 * ~return a string of as much spaces as the argument value */
		else if ((cn=recog(2,p,"SPACE$(","SPC$("))) {
			int sp;
			p+=cn;
			sp=(int)S();
			if (sp<0) sp=0;
		       	if (sp>MAXSTRLEN)sp=MAXSTRLEN; 
			if ((int)strlen(mypad)+sp>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,spaces(sp),COMPSTR);
		}
		/* STR$/NUM$ function (NUM$ from HP BASIC tradition) 
		 * ~convert the value in argument to a string without
		 * trailing spaces ahead and behind */
		else if ((cn=recog(2,p,"STR$(","NUM$("))){
			double val;
			char num[64], *pnum=num;
			p+=cn;
			val=S();
			printNUM(0,val,TRUE,num);
			/* discard trailing spaces */
			if ((int)strlen(num)>0) pnum=num+(int)strlen(num)-1;
			else pnum=num;
			while ((int)(pnum-num)>0 && isblank(*pnum)) 
				*pnum--='\0';
			pnum=num;
			while ((int)(pnum-num)<64 && isblank(*pnum)) pnum++;
			/* check length 	*/
			if ((int)strlen(mypad)+(int)strlen(pnum)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;			
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,pnum,COMPSTR);
		}
		/* LEFT$ function 
		 * ~return the left substring of string in the first argument 
		 * from start according to the second argument length */
		else if (!strncasecmp_(p,"LEFT$(",6)) {
			int llen;
			char op[COMPSTR], *P1=op;
			p+=6;
			strncpy_(op,SS(),COMPSTR);
			if (*p==',') {
				p++;
				llen=(int)S();
			}
			else {
				perror_(__LINE__,200,l);
				return MYPAD;
			}
			if (llen<0) {
				perror_(__LINE__,223,l);
				return MYPAD;
			}
			if (llen>(int)strlen(op)) llen=(int)strlen(op);
			if ((int)strlen(mypad)+llen>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			*(P1+llen)='\0';
			strncat_(mypad,op,COMPSTR);
		}
		/* MID$ function 
		 * ~return the substring of string in the first argument from 
		 * start to the second argument for the number of characters 
		 * contained in the third argument 
		 * This function differs from SEG$ in that the numerical
		 * arguments specify the start and length of selection, rather
		 * than the start and end of selection.
		 * Note: arguments may be 0 (return the NULL string) 
		 * Note: third argument is optional, and if not specified 
		 * length is set to cover the rest of the string */
		else if (!strncasecmp_(p,"MID$(",5)) {
			int mstart=0,mlen=0;
			char op[COMPSTR], *P1=op;
			p+=5;
			strncpy_(op,SS(),COMPSTR);
			if (*p==',') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			mstart=(int)S();
			if (mstart<=0) {
				perror_(__LINE__,225,l);
				return MYPAD;
			}
			if (*p==',') {
				p++;
				mlen=(int)S();
			}
			else mlen=strlen(op)-mstart+1;
			if (mlen<0) {
				perror_(__LINE__,223,l);
				return MYPAD;
			}
			if (mstart>(int)strlen(op)+1) mstart=strlen(op)+1;
			if ((int)strlen(mypad)+mlen+1<MAXSTRLEN) 
				*(P1+mstart-1+mlen)='\0';
			if ((int)strlen(mypad)+(int)strlen(P1+mstart-1)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,P1+mstart-1,COMPSTR);
		}
		/* RIGHT$ function  
		 * ~return the right substring of the string in the first 
		 * argument from end according to the second argument length
		 * Note: second argument is optional, and if not specified 
		 * length is set to 1 */
		else if (!strncasecmp_(p,"RIGHT$(",7)) {
			int rlen=0;
			char op[COMPSTR], *P1=op;
			p+=7;
			strncpy_(op,SS(),COMPSTR);
			if (*p==',') {
				p++;
				rlen=(int)S();
			}
			else {
				perror_(__LINE__,200,l);
				return MYPAD;
			}
			if (rlen<0) rlen=0;
			if (rlen>(int)strlen(op)) rlen=(int)strlen(op);
			rlen=(int)strlen(op)-rlen;
			if ((int)strlen(mypad)+rlen>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,P1+rlen,COMPSTR);
		}
		/* UPPER$ function 
		 * ~return the same string in argument turned to all upper
		 * characters in the alphabetical sections */
		else if ((cn=recog(2,p,"UPPER$(","UCASE$("))) {
			char op[COMPSTR], *P1=op;
			p+=cn;
			/* case of a char argument */
			if (*(p+1)==')') sprintw(op,COMPSTR,"%c",*p++);
			/* case of any string */
			else strncpy_(op,SS(),COMPSTR);
			/* string is too long */
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			while (*P1) {
				*P1=toupper(*P1);
				P1++;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* LOWER$ function 
		 * ~return the same string in argument turned to all lower
		 * characters in the alphabetical sections */
		else if ((cn=recog(2,p,"LOWER$(","LCASE$("))) {
			char op[COMPSTR], *P1=op;
			p+=cn;
			/* case of a char argument */
			if (*(p+1)==')') sprintw(op,COMPSTR,"%c",*p++);
			/* case of any string */
			else strncpy_(op,SS(),COMPSTR);
			/* string is too long */
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			while (*P1) {
				*P1=tolower(*P1);
				P1++;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* CAP$ function 
		 * ~return the same string in lower characters with the first
		 * letter capitalized */
		else if (!strncasecmp_(p,"CAP$(",5)) {
			char op[COMPSTR], *P1=op;
			p+=5;
			/* case of a char argument */
			if (*(p+1)==')') sprintw(op,COMPSTR,"%c",*p++);
			/* case of any string */
			else strncpy_(op,SS(),COMPSTR);
			/* string is too long */
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			/* turn to lower */
			while (*P1) *P1=tolower(*P1), P1++;
			/* capitalize initials; rules:
			 * ~ capitalize first letter 
			 * ~ capitalize letter following a dash (e.g.
			 *   ROMAN-CATHOLIC is turned to Roman-Catholic 
			 * ~ capitalize the whole string (until space or
			 *   end-of-string) if % is met before the token */
			P1=op;
			*P1=toupper(*P1), P1++;
			while (*P1) {
				if (isblank(*P1)) {
					P1++;
					if (isalpha(*P1)) *P1=toupper(*P1);
				}
				else if (*P1=='-') {
					P1++;
					if (isalpha(*P1)) *P1=toupper(*P1);
				}
				P1++;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* SEG$ function (Dartmouth tradition) 
		 * ~return the substring of the string in the first argument
		 * from the second argument to the third argument places 
		 * This function differs from MID$ in that the numerical
		 * arguments specify the start and end of selection, rather
		 * than the start and length of selection. 
		 * Note: If arguments are meaningless, inverted or identifying 
		 * a substring out of the length of string - e.g. 
		 * SEG$("free"10,14), the NULL string is returned */
		else if (!strncasecmp_(p,"SEG$(",5)) {
			char op[COMPSTR], *P1=op;
			int sstart,send;
			p+=5;
			strncpy_(op,SS(),COMPSTR);
			if (*p==',') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			sstart=(int)S();
			if (sstart<=0) {
				perror_(__LINE__,225,l);
				return MYPAD;
			}
			if (*p==',') {
				p++;
				send=(int)S();
			}
			else send=strlen(op)+1;
			if (send<0) {
				perror_(__LINE__,223,l);
				return MYPAD;
			}
		       	if (send<sstart) sstart=1, send=0;
			*(P1+send)='\0';
			if ((int)strlen(mypad)+(int)strlen(P1+sstart-1)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,P1+sstart-1,COMPSTR);
		}
		/* HEX$/HEXOF$ function 
		 * ~return the hex form string of the number in argument */
		else if ((cn=recog(2,p,"HEX$(","HEXOF$("))) {
			int val;
			char num[BITS+1];
			p+=cn;
			val=(int)S();
			sprintw(num,BITS+1,"%X",val);
			/* check length 	*/
			if ((int)strlen(mypad)+(int)strlen(num)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;			
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,num,COMPSTR);
		}
		/* OCT$/OCTOF$ function 
		 * ~return the octal form string of the number in argument */
		else if ((cn=recog(2,p,"OCT$(","OCTOF$("))) {
			int val;
			char num[BITS+1];
			p+=cn;
			val=(int)S();
			sprintw(num,BITS+1,"%o",val);
			/* check length 	*/
			if ((int)strlen(mypad)+(int)strlen(num)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;			
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,num,COMPSTR);
		}
		/* BIN$ function 
		 * ~return the binary form string of the number in argument;
		 * if number is followed by 0, add all leading zeroes to the
		 * 32 bits number; if number is followed by 1 or by nothing,
		 * print the number in compact form; a negative number is
		 * anyway printed in full 32 bits. */
		else if ((cn=recog(2,p,"BIN$(","BINOF$("))) {
			int val;
			int mode=1;	// no zeroes
			char num[BITS+1];
			p+=cn;
			val=(int)S();
			if (*p==',') {
				p++;
				mode=(int)S();
				if (mode) mode=1; // always 1 for true
			}
			mode=fprintb(num,val,mode);
			if ((int)strlen(mypad)+mode>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;			
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,num,COMPSTR);
		}
		/* REV$ function 
		 * ~reverse the string in argument */
		else if (!strncasecmp_(p,"REV$(",5)) {
			char op[COMPSTR],rop[COMPSTR];
			int i,h;
			p+=5;
			strncpy_(op,SS(),COMPSTR);
			i=h=strlen(op)-1;
			while (i>=0) {
				rop[h-i]=op[i];
				i--;
			}
			rop[h+1]='\0';
			if ((int)strlen(mypad)+(int)strlen(rop)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			if (*p==')') p++;			
			else {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			strncat_(mypad,rop,COMPSTR);
		}
		/* TIME$ function 
		 * ~return the standard time string in the form "HH:MM:SS" 
		 * Note: this has a dummy argument */
		else if (!strncasecmp_(p,"TIME$",5)) {
			char op[COMPSTR];
			p+=5;
			/* dummy argument */
			if (*p=='(') {
				p++;
				S();
				if (*p!=')') {
					perror_(__LINE__,37,l);
					return MYPAD;
				}
				else p++;
			}
			/* build time string */
			sprintw(op,COMPSTR,"%02d:%02d:%02d",getHour(),getMin(),getSec());
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR);
		}
		/* USR$ function 
		 * ~return the log string (see tbas.h for LOGAS) 
		 * Note: this is a dummy function */
		else if (!strncasecmp_(p,"USR$",4)) {
			p+=4;
			/* dummy argument */
			if (*p=='(') {
				p++;
				S();
				if (*p!=')') { 
					perror_(__LINE__,37,l);
					return MYPAD;
				}
				else p++;
			}
			if ((int)strlen(mypad)+(int)strlen(LOGAS)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,LOGAS,COMPSTR);
		}
		/* numeric variables are illegal */
		else if ((ns=findDEC(p)) && !_arr && _rettype==NUM) {
			perror_(__LINE__,86,l);
			return MYPAD;
		}
		/* string variables */
		else if ((ns=findDEC(p)) && !_arr) {
			int var=ns;
			p+=_len;
			if (PS[var][0]) {
				if ((int)strlen(mypad)+(int)strlen(PS[var])>MAXSTRLEN) {
					perror_(__LINE__,124,l);
					return MYPAD;
				}
				if ((int)strlen(PS[var]))
					strncat_(mypad,PS[var],COMPSTR);
			}
		}
		/* string arrays */
		else if ((ns=findDEC(p)) && _arr) {
			int var=0,M=0,N=0,T=1;
			char op[COMPSTR];
			var=ns, p+=_len+1; // skip var, '$' and '('
			M=(int)S();
			if (*p==',') {
				p++;
				N=(int)S();
				if (dimS[var].type!=2) {
					perror_(__LINE__,76,l);
					return MYPAD;
				}
				else T=2;
			}
			if (*p!=')') {
				perror_(__LINE__,37,l);
				return MYPAD;
			}
			else p++;
			strncpy_(op,getArrayStr(var,T,M,N),COMPSTR);
			if ((int)strlen(mypad)+(int)strlen(op)>MAXSTRLEN) {
				perror_(__LINE__,124,l);
				return MYPAD;
			}
			strncat_(mypad,op,COMPSTR); 
		}
		/* no possible evaluation */
		else {
			/* wrong string evaluation in string assignment */
			if (!numEval) {
				perror_(__LINE__,86,l);
				return MYPAD;
			}
			/* wrong string relation in numeric assignment */
			else {
				perror_(__LINE__,37,l); 
				return MYPAD;
			}
		}
		if (!*p || *p==',') break;
	} while (*p=='+' || *p=='&');
	strncpy_(sspad,mypad,COMPSTR);
	// MYPAD=mypad;
	return sspad;
}


/* strRel()
 * evaluate a string expression, with operators <, >, =, # (for <> and ><),
 * � (for <= and =<) and ! (for >= and =>) and | (for ==); 
 * always return a truth value
 * Note: in relations, any kind of string variable (even string arrays)
 * may be used into the formula.
 * Note: since evaluation of string relations returns a truth value, which is
 * a number, it is useful only into IF..THEN statements and into S(); so they 
 * are recognized/used there, and not into SS() */
int strRel(void) {
	int rel=FALSE, operator;
	char op1[COMPSTR], op2[COMPSTR], *P1=op1, *P2=op2;

	/* read operands and operator */
	strncpy_(op1,SS(),COMPSTR);
	if (ispro(p)) operator='|', p+=2;	// ==
	else if (isdif(p)) operator='#', p+=2;	// <> or ><
	else if (isleq(p)) operator='�', p+=2;	// <= or =<
	else if (isgeq(p)) operator='!', p+=2;	// >= or =>
	else operator=*p++;
	strncpy_(op2,SS(),COMPSTR);
	/* delete trailing spaces before and after strings */
	if (operator!='|' && isComparison==RELATIVE) {
		if ((int)strlen(op1)>0) {
			P1=op1+(int)strlen(op1)-1; 
			while ((int)(P1-op1)>0 && isblank(*P1)) *P1--='\0';
		}
		if ((int)strlen(op2)>0) {
			P2=op2+(int)strlen(op2)-1; 
			while ((int)(P2-op2)>0 && isblank(*P2)) *P2--='\0';
		}
		P1=op1; while ((int)(P1-op1)<COMPSTR && isblank(*P1)) P1++;
		P2=op2; while ((int)(P2-op2)<COMPSTR && isblank(*P2)) P2++;
	}
	/* apply operator */
	/* case of STRING and string as different strings */
	if (isCaseSensitive) {
		switch(operator) {
		case '<': if (strcmp(P1,P2) < 0)  rel=TRUE; break;
		case '>': if (strcmp(P1,P2) > 0)  rel=TRUE; break;
		case '=': if (!strcmp(P1,P2))     rel=TRUE; break;
		case '|': if (!strcmp(P1,P2))     rel=TRUE; break;
		case '#': if (strcmp(P1,P2))      rel=TRUE; break;
		case '�': if (strcmp(P1,P2) <= 0) rel=TRUE; break;
		case '!': if (strcmp(P1,P2) >= 0) rel=TRUE; break;
		default:  perror_(__LINE__,41,l);
		}
	}
	/* case of STRING and string as same strings */
	else {
		switch(operator) {
		case '<': if (strcasecmp(P1,P2) < 0)  rel=TRUE; break;
		case '>': if (strcasecmp(P1,P2) > 0)  rel=TRUE; break;
		case '=': if (!strcasecmp(P1,P2))     rel=TRUE; break;
		case '|': if (!strcasecmp(P1,P2))     rel=TRUE; break;
		case '#': if (strcasecmp(P1,P2))      rel=TRUE; break;
		case '�': if (strcasecmp(P1,P2) <= 0) rel=TRUE; break;
		case '!': if (strcasecmp(P1,P2) >= 0) rel=TRUE; break;
		default:  perror_(__LINE__,41,l);
		}
	}

	return rel;
}


/* priority()
 * return math priority for operator op, according to the following table:
 * 8: the minus and the NOT (caught in S()) are evaluated immediately
 * 7: (..) parentheses (caught in getVal) have the highest precedence
 * 6: power (^ and **), shift left/right and modulus
 * 5: multiplication, division
 * 4: addition, subtraction
 * 3: <, >, =, <=, >=, <> 
 * 2: &&, ||, !!, &, |, {, }
 * 1: IMP, EQV
 * 0: anything else has NIL priority and should cause error 
 * Note: string concatenation operators (in the syntax + and &) are evaluated 
 * directly into SS(); string relational operators (<, >, <=, >=, =, <>) are
 * evaluated into strRel(), which is invoked only into IFTHEN()*/
int priority(const int op) {
	if (op=='^'||op==']'||op=='['||op=='%') return 6;
	else if (op=='*'||op=='/'||op=='\\') return 5;
	else if (op=='+'||op=='-') return 4;
	else if (op=='<'||op=='>'||op=='='||op=='�'||op=='#'||op=='!') 
		return 3;
	else if (op=='�'||op=='�'||op=='�'||op=='&'||op=='|'||op=='{'||op=='}')
		return 2;
	else if (op=='�'||op=='�') return 1;
	return 0;
}
#define PRIOR 6


/* S()
 * The PARSER for numerical expressions
 * The address of starting position into the flow stream is pointed by p 
 * The algorithm is as follows: 
 * an algebraic expression is turned into an RPN stack-based expression, 
 * with numbers and operators in order in their own stack; operations are 
 * performed from higher priorities down to lower and from left to right;  
 * priorities are given by the priority() function, which is part of this tool.
 * Note: the name S() is retained from Mr. Spinellis version. 
 * Note: the < and > operators (with their companion <= and >=) may not give 
 * correct results with big numbers, because of the ways of storing numbers; 
 * for instance, 1E29*10 is not stored in the same way of 1E30, because of 
 * rounding errors in calculating the multiplication (the error propagates 
 * rapidly when big numbers are calculated in series) */
double S(void) {
	double numStack[PSTACK];
	int opStack[PSTACK], prStack[PSTACK], numTOS=0, opTOS=0, ii,jj, level;
	char* pcopy=NIL;
	
	/* catch unary plus at start (simply discarded because redundant)
	 * Note: tbas parser is built in such a way that the unary sign 
	 * (+ or -) is tightly bound to the entity following it, so that 
	 * operations like -3+-2, +3+-2, -3-+2, +3-+2 are accepted */
	if (*p=='+') p++;
	/* catch unary minus at start */
	else if (*p=='-') {
		double res;
		p++; // skip '-'
		res=getVal();
		if (*p=='^' || istim(p)) {
			/* power following a unary minus has higher priority */
			double expon;
			int sign=1;
			if (*p=='^') p++;
			else p+=2;
			if (*p=='-') p++, sign=-1;
			else if (*p=='+') p++;
			expon=sign*getVal();
			res=-power(res,expon);
		}
		else res=-res;
		numStack[numTOS++]=res;
		opturn=1;
		/* short circuit: if number is followed by comma, semicolon
		 * or colon or closed parentheses or void, 
		 * return result immediately */
		if (!*p||*p==','||*p==';'||*p==':'||*p==')') return res;
		/* short circuit #2: if the -a^x exponent is not followed
		 * by an operator, return result immediately */
		if (!isop(p)) return res;
	}
	pcopy=p;
	/* reverse algebraic expression into a stack-based structure */
	while (*p && !iscs(p) && *p!='\"' && *p!='\'' && !isblank(*p) \
			&& !(*p=='&'&&!*(p+1)) && *p!=':' && *p!='\?'){
		/* catch an operator */
		if ((isop(p)) && opturn) {
			     if (isand(p)) opStack[opTOS]='�',p++;
			else if (is_or(p)) opStack[opTOS]='�',p++; 
			else if (isqua(p)) opStack[opTOS]='�',p++; 
			else if (isxor(p)) opStack[opTOS]='�',p++; 
			else if (iseqv(p)) opStack[opTOS]='�',p++; 
			else if (isimp(p)) opStack[opTOS]='�',p++; 
			else if (isdif(p)) opStack[opTOS]='#',p++; 
			else if (isleq(p)) opStack[opTOS]='�',p++; 
			else if (isgeq(p)) opStack[opTOS]='!',p++; 
			else if (issri(p)) opStack[opTOS]=']',p++; 
			else if (issle(p)) opStack[opTOS]='[',p++; 
			else if (istim(p)) opStack[opTOS]='^',p++; 
			else if (ismod(p)) opStack[opTOS]='%',p++; 
			else opStack[opTOS]=*p;
			prStack[opTOS]=priority(opStack[opTOS]);
			opTOS++;
			p++;
			opturn=0;
			/* operator followed by void is an illegal formula */
			if (!*p) {
				perror_(__LINE__,37,l);
				return 0.0;
			}
		}
		/* catch a closed parenthesis */
		else if (*p==')') break;
		/* catch the unary minus after an operator */
		else if (*p=='-' && !opturn) {
			p++;
			numStack[numTOS++]=-getVal();
			opturn=1;
		}
		/* catch the not as symbol after an operator */
		else if (*p=='~' && !opturn) {
			p++;
			numStack[numTOS++]=-(double)(!getVal());
			opturn=1;
		}
		/* catch the not as keyword after an operator */
		else if (!strncasecmp_(p,"NOT",3) && !opturn) {
			p+=3;
			numStack[numTOS++]=-(double)(!getVal());
			opturn=1;
		}
		/* catch the unary plus after an operator */
		else if (*p=='+' && !opturn) {
			p++;
			numStack[numTOS++]=getVal();
			opturn=1;
		}
		/* catch a number (literal or variable) */
		else {
			numStack[numTOS++]=getVal();
			opturn=1;
			if (*p && !isop(p)) break;
		}
		
		/* Since the string was evaluated, change pcopy to signal
		 * the work is done */
		pcopy=NIL;
	}

	/* No parsing has been done if the string is not void */
	if (*p && pcopy==p) {
		perror_(__LINE__,37,l);
		return 0.0;
	}
	/* perform calculations from higher priorities downward
	 * Note: for tbas, any relation is also a math expression */
	for (ii=PRIOR;ii>=0;ii--) {
		/* calculations are performed from left to right */
		for (level=0;level<opTOS;level++) {
			if (prStack[level]==ii) {
				/* collapse stacks */
				switch(opStack[level]) {
/* HERE BEGINS OPERATORS ANALYSIS */
/* lesser than < */
case '<': numStack[level]=-(double)(numStack[level]<numStack[level+1]); break; 
/* greater than > */
case '>': numStack[level]=-(double)(numStack[level]>numStack[level+1]); break; 
/* not equal <> */
case '#': numStack[level]=-(double)(numStack[level]!=numStack[level+1]); break;
/* greater than or equal >= */
case '!': numStack[level]=-(double)(numStack[level]>=numStack[level+1]); break;
/* lesser than or equal <= */
case '�': numStack[level]=-(double)(numStack[level]<=numStack[level+1]); break;
/* equal to */
case '=': numStack[level]=-(double)(numStack[level]==numStack[level+1]); break;
/* quasi-equal to */
case '�': {
		  if (sign(numStack[level])!=sign(numStack[level+1]))
			numStack[level]=0;
		  else if (fabs((fabs(numStack[level]-fabs(numStack[level+1]))))<ZEROEQUAL)
			numStack[level]=-1;
		  else numStack[level]=0; 
	  }
	  break;
/* power ^ */
case '^': numStack[level]=power(numStack[level],numStack[level+1]); break;
/* subtraction - */
case '-': numStack[level]-=numStack[level+1]; break;
/* addition + */
case '+': numStack[level]+=numStack[level+1]; break;
/* division */
case '/': {
		double div=numStack[level+1];
		/* if divisor (div) is null, return INFF */
		if (fabs(div)<ZERO) {
			perror_(__LINE__,77,l); // warning 
			numStack[level]=numStack[level]<0?MINFF:INFF;
		}
		else numStack[level]/=div;
	  }
	  break;
/* integer division */
case '\\': {
		int div2=(int)numStack[level+1];
		int div1=(int)numStack[level];
		/* if divisor (div) is null, return INFF */
		if (abs(div2)<ZERO) {
			perror_(__LINE__,77,l); // warning
			numStack[level]=numStack[level]<0?MINFF:INFF;
		}
		else numStack[level]=(double)((int)(div1/div2));  
	  }
	  break;
/* modulus operator */
case '%': {
		double o1=(int)numStack[level+1];
		double o=(int)numStack[level];
		/* if divisor (div) is null, return INFF */
		if (fabs(o1)<ZERO) {
			perror_(__LINE__,77,l); // warning
			numStack[level]=numStack[level]<0?MINFF:INFF;
		}
		else numStack[level]=(double)(o-o1*(int)(o/o1));  
	  }
	  break;
/* multiplication * */
case '*': numStack[level]*=numStack[level+1]; break;
/* bitwise & */
case '&': numStack[level]=(int)numStack[level] & (int)numStack[level+1]; break;
/* bitwise | */
case '|': numStack[level]=(int)numStack[level] | (int)numStack[level+1]; break;
/* logical && AND */
case '�': 
	numStack[level]=-(double)(!(!numStack[level])&&!(!numStack[level+1]));
	break;
/* logical || OR */
case '�': 
	numStack[level]=-(double)(!(!numStack[level])||!(!numStack[level+1]));
	break;
/* logical !! XOR */
case '�':
        if (!(!numStack[level]) != !(!numStack[level+1])) numStack[level]=-1;
	else numStack[level]=0;
	break;
/* logical -> IMP */
case '�': 
        if (!(!numStack[level]) && !(!(!numStack[level+1]))) numStack[level]=0;
	else numStack[level]=-1;
	break;
/* logical ## EQV */
case '�': 
        if (!(!numStack[level]) == !(!numStack[level+1])) numStack[level]=-1;
	else numStack[level]=0;
	break;
/* logical NOR */
case '{': 
	numStack[level]=-(double)!(!(!numStack[level])||!(!numStack[level+1]));
	break;
/* logical NAND */
case '}': 
	numStack[level]=-(double)!(!(!numStack[level])&&!(!numStack[level+1]));
	break;
/* ']' (shift right */
case ']': 
	numStack[level]=((int)numStack[level])>>((int)numStack[level+1]);
	break;
/* '[' (shift left */
case '[': 
	numStack[level]=((int)numStack[level])<<((int)numStack[level+1]);
	break;
/* HERE ENDS OPERATORS ANALYSIS */
				}
				/* shift stack positions */
				for (jj=level;jj<opTOS-1;jj++) {
					numStack[jj+1]=numStack[jj+2];
					opStack[jj]=opStack[jj+1];
					prStack[jj]=prStack[jj+1];
				}
				opTOS--;
				level--;
			}
		}
	}

	/* At this point, we have the final result into cell [0] */
	return numStack[0];
}


/* getVal()
 * get single value (number, variable, function or array element) 
 * the case of the unary minus for entities has been caught in S(); here is
 * treated the case of open parentheses
 * The double operators ++ and -- in the prefix notation are treated here
 * The address of starting position into the flow stream is pointed by p */
double getVal(void){
	double o=0;

	/* case of a real number */
	if (isnm(p)) o=strtod(p,&p);
	/* case of unary minus 
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='-') {
		p++;
		o=-getVal();
	}
	/* case of ~ (tilde) - NOT operator
	 * (for general cases, e.g. before a parenthesis) */
	else if (*p=='~') {
		p++;
		o=-(double)(!getVal());
	}
	/* case of NOT
	 * (for general cases, e.g. before a parenthesis) */
	else if (!strncasecmp_(p,"NOT",3)) {
		p+=3;
		o=-(double)(!getVal());
	}
	/* case of open parenthesis */ 
	else if (*p=='(') { 
		p++;
		o=S();
		if (*p!=')') {
			perror_(__LINE__,37,l);
			return 0.0;
		}
		else p++; 
	}
	/* case of a string relation (which returns a numeric truth value) */
	else if (isanystring(p)) {
		numEval=TRUE;
		o=strRel();
		numEval=FALSE;
	}
	/* delegate function calculations to getFunc() */
	else if (isbeginnamechar(p)) { 
		o=getFunc();
		p++; 
	}
	/* unrecognized object */
	else {
		perror_(__LINE__,37,l);
		return 0.0;
	}
	/* normal end */
	return o;
}

/* getFunc()
 * functions calculator 
 * Note: I know trigonometry and hyperbolic functions since my High School days
 * and University years; in any case, for what about the organization of facts,
 * domain limits, graphs and alternative representations, I owe much  to the 
 * Wolfram|Alpha team guys (https://www.wolframalpha.com/), where a lot of info 
 * is freely available for anyone interested in math facts! 
 * Note: in the following:
 * - the symbol -> must be read as "belongs to",
 * - the symbol : means "such as" 
 * Note: the DEC BASIC had very powerful math functions, but they worked in
 * a very "strange" sense: if you tried to get SQR(-3) a warning appeared and
 * the SQR(3) was returned. This is not fair. Or, if you wanted to get LOG(-1)
 * a warning appeared, returning LOG(1).
 * This is not a good math behaviour, because I'd like, as a programmer, to
 * know if my algorithm has a fault and calculates wrong numbers, and the
 * warning, mixed to the output, may get unnoticed. 
 * On the other hand, if the function has an infinite for some domain values,
 * why stopping signaling the fact? In these cases, such limit may be output
 * as INFF, and this big big value is a substitute for the infinite value.
 * So I redesigned all math functions along these two principles:
 * 1. if the function goes to infinite for some values, INFF is returned, no 
 * error message is printed, with the convention that the sign of the INFF 
 * value depends on the sign of the function on the relative side (there may be 
 * cases where errors in representing the number cause shifts that fall in the 
 * wrong side, and INFF is printed with the opposite sign: a minor effect...)
 * 2. if the value of the function given as argument is out of dominion (for
 * instance ASIN(2) which is senseless), an error message is printed.
 * The previous rules define also the behavior of SQR and LOG, because negative
 * values fall in rule 2 (and an error message, not a warning, is printed), and
 * execution is stopped, while TAN(PI/2) falls in rule 1 (no error message is 
 * printed, INFF is returned) and execution is not stopped.*/
double getFunc(void) {
	double o=0.0, o1=0.0;
	int paren=TRUE, ns=0, type=0, rettype=0, cn=0;
	char strres[COMPSTR], *op;

	/* SUB FUNCTIONS - delegate execSUB() */
	if (!isValOn && (ns=findSUB(p,&op,&type,&rettype))) {
		if (type==FUNC && rettype==NUM)	{
			execSUB(ns,op,&o,strres);
		}
		else {
			perror_(__LINE__,217,l);
			return 0.0;
		}
		if (*p!=')') paren=FALSE;
	}
	/* FN (DEFFN structure) - delegate calcDEF() 
	 * Domain: depending on user function */
	else if (!isValOn && !strncasecmp_(p,"FN",2)) {
		p+=2;
		p=calcDEF();
		o=calcres;
		if (*p==')') paren=TRUE;
		else paren=FALSE;
	}
	
	/* MATH FUNCTIONS */ 

	/* ABS(x) absolute value function
	 * Domain: x -> R 
	 * Range:  y -> R : y >= 0 */
	else if (!strncasecmp_(p,"ABS(",4)) {
		p+=4;
		o=S();
		o=fabs(o);
	}
	/* ACOS(x) arc cosine function 
	 * Domain: x -> R : -1 <= x <= 1 
	 * Range:  y -> R : 0 <= y < pi (angular measure) */
	else if (!strncasecmp_(p,"ACOS(",5)) {
		p+=5;
		o=S();
		/* domain error */
		if (o<-1.0 || o>1.0) {
			perror_(__LINE__,135,l);
			return 0.0;
		}
		o=acos(o);
		if (!isRadians) o*=RATIO;
	}
	/* ACOSEC(x)/ACSC(x) arc cosecant function 
	 * Domain: x -> R - { ]-1,1[ }
	 * Range:  y -> R : -pi/2 < y < pi/2 (angular measure) */
	else if ((cn=recog(2,p,"ACOSEC(","ACSC("))) {
		p+=cn;
		o=S();
		/* domain error */
		if (o>-1 && o<1) {
			perror_(__LINE__,137,l);
			return 0.0;
		}
		o=asin(1.0/o);
		if (!isRadians) o*=RATIO;
	}
	/* ACOSECH(x)/ACSCH(x) hyperbolic arc cosecant function
	 * Domain: x -> R - { 0 }
	 * Range:  y -> R - { 0 }
	 * Note: case of x=0 is treated */
	else if ((cn=recog(2,p,"ACOSECH(","ACSCH("))) {
		p+=cn;
		o=S();
		if (fabs(o)<ZERO) o=(o<0.0?MINFF:INFF);
		else {
			o=1.0/o;
			o=log(o+sqrt(1.0+o*o));
		}
	}
	/* ACOSH(x) hyperbolic arc cosine function 
	 * Domain: x -> R : x >= 1
	 * Range:  y -> R : y >= 0 */
	else if (!strncasecmp_(p,"ACOSH(",6)) {
		p+=6;
		o=S();
		/* domain error */
		if (o<1.0) {
			perror_(__LINE__,138,l);
			return 0.0;
		}
		o=log(o+sqrt(o*o-1.0));
	}
	/* ACOT(x) arc cotangent function 
	 * Domain: x -> R 
	 * Range:  y -> R : 0 < y < pi (angular measure) */
	else if (!strncasecmp_(p,"ACOT(",5)) {
		p+=5;
		o=S();
		o=atan(1.0/o);
		if (o<0) o+=TBASPI;
		if (!isRadians) o*=RATIO;
	}
	/* ACOTH(x) hyperbolic arc cotangent function
	 * Domain: x -> R - { ]-1,1[ } 
	 * Range:  y -> R - { 0 } */
	else if (!strncasecmp_(p,"ACOTH(",6)) {
		p+=6;
		o=S();
		/* domain error */
		if (o>-1.0 && o<1.0) {
			perror_(__LINE__,140,l);
			return 0.0;
		}
		else if (o==-1.0) o=MINFF;
		else if (o==1.0) o=INFF;
		else o=0.5*log((o+1.0)/(o-1.0));
	}
	/* ALPHA Function */ 
	else if (!strncasecmp_(p,"ALPHA(",6)) {
		int res=TRUE;
		char lop[COMPSTR], *t;
		p+=6;
		strncpy_(lop,SS(),COMPSTR);
		t=lop;
		while (*t) {
			if ((*t<'A' || (*t>'Z' && *t<'a') || *t>'z'))
				res=FALSE;
			t++;
		}
		o=res;
	}
	/* ASEC(x) arc secant function 
	 * Domain: x -> R - { ]-1,1[ }
	 * Range:  y -> R : 0 <= y < pi (angular measure) */
	else if (!strncasecmp_(p,"ASEC(",5)) {
		p+=5;
		o=S();
		/* domain error */
		if (o>-1.0 && o<1.0) {
			perror_(__LINE__,136,l);
			return 0.0;
		}
		o=acos(1.0/o);
		if (!isRadians) o*=RATIO;
	}
	/* ASECH(x) hyperbolic arc secant function 
	 * Domain: x -> R : 0 < x <= 1
	 * Range:  y -> R : y >= 0 
	 * Note: the cases x=0 and x=1 are treated */
	else if (!strncasecmp_(p,"ASECH(",6)) {
		p+=6;
		o=S();
		/* domain error */
		if (o<0.0 || o>1.0) {
			perror_(__LINE__,141,l);
			return 0.0;
		}
		else if (fabs(o)<ZERO) o=INFF; // o>0 here!
		else if (o==1.0) o=0.0;
		else {
			o=1.0/o;
			o=log(o+sqrt(o*o-1.0));
		}
	}
	/* ASIN(x) arc sin function 
	 * Domain: x -> R : -1 <= x <=1 
	 * Range:  y -> R : -pi/2 < y < pi/2 (angular measure) */
	else if (!strncasecmp_(p,"ASIN(",5)) {
		p+=5;
		o=S();
		/* domain error */
		if (o<-1.0 || o>1.0) {
			perror_(__LINE__,134,l);
			return 0.0;
		}
		o=asin(o);
		if (!isRadians) o*=RATIO;
	}
	/* ASINH(x) hyperbolic arc sin function 
	 * Domain: x -> R 
	 * Range:  y -> R */
	else if (!strncasecmp_(p,"ASINH(",6)) {
		p+=6;
		o=S();
		o=log(o+sqrt(1+o*o));
	}
	/* ATN(y[,x])|ATAN(y[,x]) arc tangent function (one or two arguments)
	 * From the manual page - man atan2:
	 * ~The atan2() function is used mostly to convert from rectangular 
	 * (x,y) to polar (r,theta) coordinates that must satisfy: 
	 * ~x = r*cos theta
	 * ~y = r*sin theta
	 * Note: In general, conversions to polar coordinates should be 
	 * computed like this:
	 * ~r := sqrt(x*x+y*y)
	 * ~theta := atan2(y,x)
	 * Domain:       x -> R
	 * Range: ATAN:  y -> R : -pi/2 < y < pi/2 (angular measure)  
	 * Range: ATAN2: y -> R : -pi < y < pi (angular measure) */
	else if ((cn=recog(2,p,"ATN(","ATAN("))) {
		p+=cn,o=S();
		/* atan2 case (sign of the two arguments decide the quadrant)*/
		if (*p==',') {
			p++;
			o1=S();
			o=atan2(o,o1);
		}
		/* atan case */
		else o=atan(o);
		if (!isRadians) o*=RATIO;
	}
	/* ATNH(x)|ATANH(x) hyperbolic arc tangent function 
	 * Domain: x -> R : -1 <= x <= 1
	 * Range:  y -> R 
	 * Note the cases x=1 and x=-1 are treated */
	else if ((cn=recog(2,p,"ATNH(","ATANH("))) {
		p+=cn;
		o=S();
		/* domain error */
		if (o<-1.0 || o>1.0) {
			perror_(__LINE__,139,l);
			return 0.0;
		}
		else if (o==-1.0) o=MINFF;
		else if (o==1.0) o=INFF;
		else o=0.5*log((1.0+o)/(1.0-o));
	}
	/* BIN(x$) binary conversion 
	 * ~return the decimal value of the binary number string
	 * in the argument */
	else if (!strncasecmp_(p,"BIN(",4)) {
		char op[COMPSTR], *bo;
		int n=0;
		p+=4;
		o=0.0;
		strncpy_(op,SS(),COMPSTR);
		bo=op+strlen(op)-1;
		while (bo>=op && (*bo=='1' || *bo=='0')) 
			o+=(*bo-48)*pow(2,n++), bo--;
		if (bo!=op) perror_(__LINE__,143,l); // warning
	}
	/* CEIL(x)/CEILING(x) ceiling function 
	 * ~return the smallest following integer */
	else if ((cn=recog(2,p,"CEIL(","CEILING("))) {
		int k=0;
		p+=cn;
		o=S();
		if (o>0 && o!=(int)o) k=1;
		o=(int)o+k;  
	}
	/* COS(x) cosine function 
	 * Domain: x -> R (angular measure) 
	 * Range:  y -> R : -1 <= y <= 1 */
	else if (!strncasecmp_(p,"COS(",4)) {
		p+=4;
		o=S();
		if (!isRadians) o/=RATIO;
		o=cos(o);
	}
	/* COSEC(x)/CSC(x) cosecant function 
	 * Domain: x -> R - { pi/2+kpi } (angular measure) 
	 * Range:  y -> R - { ]-1,1[ } 
	 * Note: the case x=pi/2+kpi is treated after calculation of the sine 
	 * value, which must not be null */
	else if ((cn=recog(2,p,"COSEC(","CSC("))) {
		p+=cn;
		o=S();
		if (!isRadians) o/=RATIO;
		o=sin(o);
		/* Note: I check here against ZEROCALC=2E-13 and not ZERO 
		 * because the rendition of sin(pi) is never really zero, 
		 * since the argument is never really pi; so the absolute value 
		 * of sin(pi) is never lesser than ZERO, and the least value it
		 * can reach is around 2E-13 */
		if (fabs(o)<ZEROCALC) o=o<0.0?MINFF:INFF;
		else o=1.0/o;
	}
	/* COSECH(x)/CSCH(x) hyperbolic cosecant function
	 * Domain: x -> R - {0}
	 * Range:  y -> R - {0} 
	 * Note: the case x=0 is treated */
	else if ((cn=recog(2,p,"COSECH(","CSCH("))) {
		p+=cn;
		o=S();
	       	if (fabs(o)<ZERO) o=o<0.0?MINFF:INFF;
		else o=2.0/(exp(o)-exp(-o));
	}
	/* COSH(x) hyperbolic cosine function 
	 * Domain: x -> R
	 * Range:  y -> R : y >= 1 */
	else if (!strncasecmp_(p,"COSH(",5)) {
		p+=5;
		o=S();
		o=(exp(-o)+exp(o))/2.0;
	}
	/* COT(x) cotangent function 
	 * Domain: x -> R - { kpi } (angular measure) 
	 * Range:  y -> R 
	 * Note: the case x=kpi is treated */
	else if (!strncasecmp_(p,"COT(",4)) {
		p+=4;
		o=S();
		if (!isRadians) o/=RATIO;
		/* set value to the range 0-pi */
		while (o>TBASPI) o-=TBASPI;
		while (o<0) o+=TBASPI;
		if (fabs(o)<ZERO) {
			perror_(__LINE__,127,l); // warning
			o=INFF;
		}
		else if (fabs(o-TBASPI)<ZERO) {
			perror_(__LINE__,127,l); // warning
			o=MINFF;
		}
		else o=1.0/tan(o);
	}
	/* COTH(x) hyperbolic cotangent function
	 * Domain: x -> R - { 0 }
	 * Range:  y -> R - { ]-1,1[ } 
	 * Note: the case x=0 is treated */
	else if (!strncasecmp_(p,"COTH(",5)) {
		p+=5;
		o=S();
		if (fabs(o)<ZERO) o=o<0.0?MINFF:INFF;
		else o=(exp(o)+exp(-o))/(exp(o)-exp(-o));
	}
	/* CR (constant) return character of end-of-line \n */
	else if (!strncasecmp_(p,"CR",2) && !isalnum(*(p+2))) {
		p++;
		o=_CR;
		paren=FALSE;
	}
	/* DEG(x)/DEGREES(x) function - argument in radians */
	else if ((cn=recog(2,p,"DEG(","DEGREES("))) {
		p+=cn;
		o=S(); 
		o*=RATIO;
	}
	/* DET(x) function
	 * ~return the determinant of the square matrix in argument.
	 * Note: the matrix is internally inverted, but no attribution of
	 * the inversion is made to any variable; the process is done only
	 * to obtain a determinant. 
	 * Note: if matrix is singular, return 0.0 */
	else if (!strncasecmp_(p,"DET(",4)) {
		int ns=0;
		p+=4;
		detValue=0;
		forceArray=TRUE;
		ns=findDEC(p);
		if (!ns || _rettype!=NUM) {
			perror_(__LINE__,128,l);
			return 0.0;
		}
		if (!dim[ns].row || !dim[ns].col) {
			perror_(__LINE__,128,l);
			return 0.0;
		}
		if (dim[ns].row!=dim[ns].col) {
			perror_(__LINE__,122,l);
			return 0.0;
		}
		matinvert(0,ns); // 0 is the temp variable (not used by tbas)
		forceArray=FALSE;
		o=detValue;
		p+=_len;
	}
	/* DET variable 
	 * ~return the determinant of the last inverted matrix. If no matrix 
	 * was ever inverted, return 0.0  */
	else if (!strncasecmp_(p,"DET",3) && !isalnum(*(p+3))) {
		o=detValue;
		p+=2;
		paren=FALSE;
	}
	/* IDIV(x,y) integer division (Classic  Math) */
	else if (!strncasecmp_(p,"IDIV(",5)) {
		int A=0, B=0, div=0, mod=0;
		p+=5;
		A=(int)S(); // dividend
		if (*p!=',') {
			perror_(__LINE__,35,l);
			return 0.0;
		}
		else p++;
		B=(int)S(); // divisor
		modulo(A,B,&div,&mod,TRUE);
		o=(double)div;
	}
	/* DIV(x,y) integer division (Number Theory) */
	else if (!strncasecmp_(p,"DIV(",4)) {
		int A=0, B=0, div=0, mod=0;
		p+=4;
		A=(int)S(); // dividend
		if (*p!=',') {
			perror_(__LINE__,35,l);
			return 0.0;
		}
		else p++;
		B=(int)S(); // divisor
		modulo(A,B,&div,&mod,FALSE);
		o=(double)div;
	}
	/* DOT(A,B) dot product */
	else if (!strncasecmp_(p,"DOT(",4)) {
		p+=4;
		o=MATDOT();
	}
	/* EPS constant
	 * ~return the lowest number for this version, a number which is 
	 * at the lower edge of any interpretability */
	else if (!strncasecmp_(p,"EPS",3) && !isalnum(*(p+3))) {
		o=ZERO;
		p+=2;
		paren=FALSE;
	}
	/* ERFC(X) function
	 * ~return the complementary error function of X, computing the
	 * difference of the error function from 1.0; the error function is
	 * known as erf() in most languages, and its value may be obtained
	 * by 1-erfc().
	 * usage: internal testing (inner Pseudo-random Number Generator) */
	else if (!strncasecmp_(p,"ERFC(",5)) {
		p+=5,o=S(); // argument
		o=erfc(o);
		if (fabs(o)<ZERO) o=0.0;
	}
	/* EXP(x) exponential function (base e)
	 * Domain: x -> R 
	 * Range:  y -> R : y >= 0 */
	else if (!strncasecmp_(p,"EXP(",4)) {
		p+=4;
		o=S();
		o=exp(o);
	}
	/* EXPR(x$) function 
	 * ~return the value of the number or formula in the argument, 
	 * which must be a regular string */
	else if (!strncasecmp_(p,"EXPR(",5)) {
		char op[COMPSTR], pe[COMPSTR];
		char *pp;
		p+=5;
		o=0.0;
		strncpy_(op,SS(),COMPSTR);
		stripBlanks(op, pe);
		/* Note: the only incorrect forms of the argument I can think 
		 * of is if it's null; if so, return 0.0 with a warning */
		if (!pe[0]) {
			perror_(__LINE__,131,l);
			return 0.0;
		}
		/* in case it holds a number or a formula, turn string 
		 * to float using regular tbas rules */
		pp=p;
		p=pe;
		o=S();
		strncpy_(exprRest,p,COMPSTR);
		p=pp;
	}
	/* FALSE constant
	 * ~return the false condition 0 */
	else if (!strncasecmp_(p,"FALSE",5) && !isalnum(*(p+5))) {
		o=FALSE;
		p+=4;
		paren=FALSE;
	}
	/* FLOOR(x)/INT(x) integer floor function 
	 * ~return the largest previous following integer 
	 * Note: thanks to Tom Lake who noticed I initially built INT
	 * to behave like IP rather than FLOOR, and this put tbas into
	 * an antihistorical point of view. */
	else if ((cn=recog(3,p,"FLOOR(","INT(","INTEGER("))) {
		int k=0;
		p+=cn;
		o=S();
		if (o<0.0 && (o-(int)o)!=0.0) k=1;
		o=(int)o-k;  
	}
	/* FRAC(x)/FP(x) fractional part function 
	 * ~return fractional part of x */
	else if ((cn=recog(2,p,"FRAC(","FP("))) {
		p+=cn;
		o=S();
		o=o-(int)o;
	}
	/* FREE(x)  
	 * ~return number of free slots for program */
	else if (!strncasecmp_(p,"FREE(",5)) {
		p+=5;
		o=S(); // dummy
		o=MEMLIMIT-endCore;
	}
	/* GAMMA(x) function 
	 * ~return the gamma function value of x 
	 * Domain: x -> R
	 * Range:  y -> R */
	else if (!strncasecmp_(p,"GAMMA(",6)) {
		p+=6;
		o=S();
		o=tgamma(o);
	}
	/* HEX(x$) hexadecimal conversion 
	 * ~return the decimal value of the hex number string
	 * in the argument */
	else if (!strncasecmp_(p,"HEX(",4)) {
		char op[COMPSTR], *ho;
		p+=4;
		strncpy_(op,SS(),COMPSTR);
		o=strtol(op,&ho,16);
		if (*ho) perror_(__LINE__,143,l); // warning
	}
	/* TRUE constant
	 * ~return the true condition */
	else if (!strncasecmp_(p,"TRUE",4) && !isalnum(*(p+4))) {
		o=TRUE;
		p+=3;
		paren=FALSE;
	}
	/* INF constant
	 * ~return the larger number for this version, a number which is 
	 * at the higher edge of any interpretability */
	else if (!strncasecmp_(p,"INF",3) && !isalnum(*(p+3))) {
		o=INFF;
		p+=2;
		paren=FALSE;
	}
	/* IP(x) integer part function
	 * ~return the integer part
	 * Domain: x -> R 
	 * Range:  y -> N */
	else if (!strncasecmp_(p,"IP(",3)) {
		p+=3;
		o=(int)S(); 
	}
	/* INV(x) invert function
	 * ~return the ratio 1/x
	 * Domain: x -> R - {0}
	 * Range:  y -> R 
	 * Note: the case x=0 is treated */
	else if (!strncasecmp_(p,"INV(",4)) {
		p+=4;
		o=S();
		if (fabs(o)<ZERO) {
			perror_(__LINE__,77,l); // warning
			o=o<0?MINFF:INFF;
		}
		else o=1.0/o;
	}
	/* LASTF constant
	 * ~return the last DEF calculation result */
	else if (!strncasecmp_(p,"LASTF",5) && !isalnum(*(p+5))) {
		o=calcres;
		p+=4;
		paren=FALSE;
	}
	/* LEN(x$)|LENGTH(x$) string length function 
	 * ~return length of the argument string */
	else if ((cn=recog(2,p,"LEN(","LENGTH("))) {
		char lop[COMPSTR];
		p+=cn;
		strncpy_(lop,SS(),COMPSTR);
		o=(double)strlen(lop);
	}
	/* LGAMMA(x) function 
	 * ~return the natural logarithm of the absolute value of the gamma 
	 * function of value x
	 * Domain: x -> R
	 * Range:  y -> R */
	else if (!strncasecmp_(p,"LGAMMA(",7)) {
		p+=7;
		o=S();
		o=lgamma(o);
	}
	/* LOGE(x)|LOG(x)|LN(x) natural logarithm function
	 * ~return the natural logarithm
	 * Domain: x -> R : x > 0 
	 * Range:  y -> R 
	 * Note: the case x=0 is treated */
	else if ((cn=recog(3,p,"LN(","LOG(","LOGE("))) {
		p+=cn;
		o=S();
		/* domain errors (negative and equal to zero) */
		if (o<0) {
			perror_(__LINE__,95,l); 
			return 0.0;
		}
		else if (o<ZERO) { // o>0 here!
			perror_(__LINE__,96,l); // warning
			o=MINFF; 
		}
		else o=log(o);
	}
	/* LOG10(x)|CLOG(x)|LGT(x) 10-base logarithm function 
	 * ~return the logarithm in base 10
	 * Domain: x -> R : x > 0 
	 * Range:  y -> R
	 * Note: LGT comes from the CDC tradition 
	 * Note: the case x=0 is treated */
	else if ((cn=recog(3,p,"LGT(","LOG10(","CLOG("))) {
		p+=cn;
		o=S();
		/* domain errors (negative and equal to zero) */
		if (o<0) {
			perror_(__LINE__,95,l); 
			return 0.0;
		}
		else if (o<ZERO) { // o>0 here!
			perror_(__LINE__,96,l); // warning
			o=MINFF; 
		}
		else o=log10(o);
	}
	/* MAX(x,y,z...) maximum value of a list */
	else if (!strncasecmp_(p,"MAX(",4)) {
		double o2;
		p+=4, o=0.0; 
		if (*p!=')') o=S();
		if (*p==',') p++;
		while (*p!=')') {
			o2=S();
			if (o2>o) o=o2;
			if (*p==',') p++;
		}
	}
	/* VMAX(x) maximum value of a vector/matrix */
	else if (!strncasecmp_(p,"VMAX(",5)) {
		double o2;
	       	int cn=0;
		p+=5, o=0.0;
		forceArray=TRUE;
		cn=findDEC(p);
		forceArray=FALSE;
		if (!cn && vmaxLast) cn=vmaxLast;
		else vmaxLast=cn;
		/* invalid cases */
		if (cn && vn[cn].rettype==STR) {
			perror_(__LINE__,215,l);
			return 0.0;
		}
		else if (cn && !vn[cn].isArr) {
			perror_(__LINE__,34,l);
			return 0.0;
		}
		/* max of an array */
		else if (cn) {
			int i,j,m=dim[cn].row, n=dim[cn].col;
			o=getArrayVal(cn,dim[cn].type,0,0);
			p+=_len;
			for (i=0;i<=m;i++) {
				for (j=0;j<=n;j++) {
					o2=getArrayVal(cn,dim[cn].type,i,j);
					if (o2>o) o=o2;
				}
			}
		}
		else o=0;
	}
	/* MAYBE - random TRUE or FALSE */
	else if (!strncasecmp_(p,"MAYBE",5) && !isalnum(*(p+5))) {
		p+=4;
		o=getRandom();
		if (o<0.5) o=FALSE;
		else o=TRUE;
		paren=FALSE;
	}
	/* MIN(x,y,z...) minimum value of a list */
	else if (!strncasecmp_(p,"MIN(",4)) {
		double o2;
		p+=4, o=0.0; 
		if (*p!=')') o=S();
		if (*p==',') p++;
		while (*p!=')') {
			o2=S();
			if (o2<o) o=o2;
			if (*p==',') p++;
		}
	}
	/* VMIN(x) minimum value of a vector/matrix */
	else if (!strncasecmp_(p,"VMIN(",5)) {
		double o2;
	       	int cn=0;
		p+=5, o=0.0;
		forceArray=TRUE;
		cn=findDEC(p);
		forceArray=FALSE;
		if (!cn && vminLast) cn=vminLast;
		else vminLast=cn;
		/* invalid cases */
		if (cn && vn[cn].rettype==STR) {
			perror_(__LINE__,215,l);
			return 0.0;
		}
		else if (cn && !vn[cn].isArr) {
			perror_(__LINE__,34,l);
			return 0.0;
		}
		/* min of an array */
		else if (cn){
			int i,j,m=dim[cn].row, n=dim[cn].col;
			o=getArrayVal(cn,dim[cn].type,0,0);
			p+=_len;
			for (i=0;i<=m;i++) {
				for (j=0;j<=n;j++) {
					o2=getArrayVal(cn,dim[cn].type,i,j);
					if (o2<o) o=o2;
				}
			}
		}
		else o=0;
	}
	/* MOD(x,y) integer modulus (Classic Math) */
	else if (!strncasecmp_(p,"MOD(",4)) {
		int A=0, B=0, div=0, mod=0;
		p+=4;
		A=(int)S(); // dividend
		if (*p!=',') {
			perror_(__LINE__,43,l);
			return 0.0;
		}
		else p++;
		B=(int)S(); // divisor
		modulo(A,B,&div,&mod,TRUE);
		o=mod;
	}
	/* REMAINDER(x,y) integer modulus (Number Theory) */
	else if (!strncasecmp_(p,"REMAINDER(",10)) {
		int A=0, B=0, div=0, mod=0;
		p+=10;
		A=(int)S(); // dividend
		if (*p!=',') {
			perror_(__LINE__,43,l);
			return 0.0;
		}
		else p++;
		B=(int)S(); // divisor
		modulo(A,B,&div,&mod,FALSE);
		o=mod;
	}
	/* NUM(x)
	 * ~MAT INPUT function with dummy argument */
	else if (!strncasecmp_(p,"NUM(",4)) { 
		p+=4;
		o=S(); // dummy
		o=numValue; 
	}
	/* NUM
	 * ~MAT INPUT variable */
	else if (!strncasecmp_(p,"NUM",3) && !isalnum(*(p+3))) {
		o=numValue;
		p+=2;
		paren=FALSE;
	}
	/* NUMBER Function */ 
	else if (!strncasecmp_(p,"NUMBER(",7)) {
		int res=TRUE;
		char lop[COMPSTR], *t;
		p+=7;
		strncpy_(lop,SS(),COMPSTR);
		t=lop;
		while (*t) {
			if ((*t<'0' || *t>'9'))
				res=FALSE;
			t++;
		}
		o=res;
	}
	/* OCT(x$) octal conversion 
	 * ~return the decimal value of the octal number string
	 * in the argument */
	else if (!strncasecmp_(p,"OCT(",4)) {
		char op[COMPSTR], *ho;
		p+=4;
		strncpy_(op,SS(),COMPSTR);
		o=strtol(op,&ho,8);
		if (*ho) perror_(__LINE__,143,l);  // warning
	}
	/* PI (greek PI) constant */
        else if (!strncasecmp_(p,"PI",2) && !isalnum(*(p+2))) {
		p++;
		o=TBASPI;
		if (!isRadians) o*=RATIO;
		paren=FALSE;
	}
	/* PICT Function */ 
	else if (!strncasecmp_(p,"PICT(",5)) {
		int res=TRUE;
		char lop[COMPSTR], *t;
		p+=5;
		strncpy_(lop,SS(),COMPSTR);
		t=lop;
		while (*t) {
			if ((*t<32 || (*t>47 && *t<58) ||\
				(*t>64 && *t<91) ||\
				(*t>96 && *t<123) ||\
				*t>127))
				res=FALSE;
			t++;
		}
		o=res;
	}
	/* RAD(x)/RADIANS(x) radians function
	 * ~convert x to radians (argument in degrees) */
	else if ((cn=recog(2,p,"RAD(","RADIANS("))) {
		p+=cn;
		o=S(); 
		o/=RATIO;
	}
	/* REAL(x)  
	 * ~return x as real (no-op) */
        else if (!strncasecmp_(p,"REAL(",5)) {
	       p+=5;
	       o=S();
	}
	/* RND(x) random function (dummy argument) 
	 * ~return a random number */
        else if (!strncasecmp_(p,"RND(",4)) {
	       p+=4;
	       o=S();
	       o=getRandom();
	}
	/* RND random variable 
	 * ~return a random number */
        else if (!strncasecmp_(p,"RND",3) && !isalnum(*(p+3))) {
		o=getRandom();
		p+=2;
		paren=FALSE;
	}
	/* ROUND(x[,y])|ROF(x[,y])|FIX(x[,y]|TRUNCATE(x[,y]) round function
	 * ~round x to integer (rounding last digit according to first decimal)
	 * or round x to yth decimal place, round last digit according to the
	 * digit in y+1 position
	 * Note: ROF comes from the CDC tradition */
        else if ((cn=recog(4,p,"ROF(","FIX(","ROUND(","TRUNCATE("))) {
		double v;
		int r=0;
		p+=cn;
		v=S();
		/* no second argument: round to integer */
		if (*p==')') o=(int)(v+(v>0?0.5:-0.5));
		/* specified number of decimals to be rounded */
		else if (*p==',') {
			p++; // skip comma
			r=(int)S();
			o=(int)(v*pow(10.0,r)+(v>0?0.5:-0.5))/pow(10.0,r);
		}
		else {
			perror_(__LINE__,37,l);
			return 0.0;
		}
	}
	/* SEC(x) secant function
	 * Domain: x -> R - { kpi } (angular measure) 
	 * Range:  y -> R -{ ]-1,1[ } 
	 * Note: the case x=kpi is treated */
	else if (!strncasecmp_(p,"SEC(",4)) {
		p+=4;
		o=S();
		if (!isRadians) o/=RATIO;
		o=cos(o);
		/* Note: I check here against ZEROCALC=2E-13 and not ZERO 
		 * because the rendition of cos(pi/2) is never really zero, 
		 * since the argument is never really pi/2 */
		if (fabs(o)<ZEROCALC) o=o<0?MINFF:INFF;
		else o=1.0/o;
	}
	/* SECH(x) hyperbolic secant function 
	 * Domain: x -> R 
	 * Range:  y -> R : 0 <= y <= 1 */
	else if (!strncasecmp_(p,"SECH(",5)) {
		p+=5;
		o=S();
		o=2.0/(exp(o)+exp(-o));
	}
	/* SGN(x)/SIGN(x) sign function 
	 * Domain: x -> R
	 * Range   y -> N, : y = -1 or 0 or 1 */
	else if ((cn=recog(2,p,"SGN(","SIGN("))) {
		p+=cn;
		o=sign(S()); 
	}
	/* SHL(n,m) shift left function (2 parameters) */
	else if (!strncasecmp_(p,"SHL(",4)) {
		int a,b;
		p+=4;
		a=(int)S();
		if (*p!=',') {
			perror_(__LINE__,43,l);
			return 0.0;
		}
		else p++;
		b=(int)S();
		o=(double)(a<<b);
	}
	/* SHR(n,m) shift right function (2 parameters) */
	else if (!strncasecmp_(p,"SHR(",4)) {
		int a,b;
		p+=4;
		a=(int)S();
		if (*p!=',') {
			perror_(__LINE__,43,l);
			return 0.0;
		}
		else p++;
		b=(int)S();
		o=(double)(a>>b);
	}
	/* SIN(x) sin function 
	 * Domain: x -> R (angular measure) 
	 * Range:  y -> R : -1 <= y <= 1 */
	else if (!strncasecmp_(p,"SIN(",4)) {
		p+=4;
		o=S();
		if (!isRadians) o/=RATIO;
		o=sin(o);
	}
	/* SINH(x) hyperbolic sin function 
	 * Domain: x -> R 
	 * Range:  y -> R */
	else if (!strncasecmp_(p,"SINH(",5)) {
		p+=5;
		o=S();
		o=(-exp(-o)+exp(o))/2;
	}
	/* SQRT(x)|SQR(x) square root function 
	 * Domain: x -> R : x >= 0 
	 * Range:  y -> R : y >= 0 */ 
	else if ((cn=recog(2,p,"SQR(","SQRT("))) {
		p+=cn;
		o=S();
		/* domain error */
		if (o<0.0) {
			perror_(__LINE__,123,l); 
			return 0.0;
		}
		else o=sqrt(o);
	}
	/* SUM(x) summation of list terms */
	else if (!strncasecmp_(p,"SUM(",4)) {
		p+=4, o=0.0;
		while (*p!=')') {
			o+=S();
			if (*p==',') p++;
		}
	}
	/* VSUM(x) summation of a vector/matrix items */
	else if (!strncasecmp_(p,"VSUM(",5)) {
	       	int cn=0;
		p+=5, o=0.0;
		forceArray=TRUE;
		cn=findDEC(p);
		forceArray=FALSE;
		if (!cn && vsumLast) cn=vsumLast;
		else vsumLast=cn;
		/* invalid cases */
		if (cn && vn[cn].rettype==STR) {
			perror_(__LINE__,215,l);
			return 0.0;
		}
		else if (cn && !vn[cn].isArr) {
			perror_(__LINE__,34,l);
			return 0.0;
		}
		/* sum of array items */
		else if (cn) {
			int i,j,m=dim[cn].row, n=dim[cn].col;
			p+=_len;
			for (i=0;i<=m;i++) {
				for (j=0;j<=n;j++) {
					o+=getArrayVal(cn,dim[cn].type,i,j);
				}
			}
		}
		else o=0;
	}
	/* TAN(x) tangent function 
	 * Domain: x -> R - { pi/2+kpi } (angular measure)
	 * Range:  y -> R 
	 * Note: the case x=pi/2+kpi is treated */
	else if (!strncasecmp_(p,"TAN(",4)) {
		p+=4;
		o=S();
		if (!isRadians) o/=RATIO;
		/* set value to the range -pi/2 +pi/2 */
		while (o>HALFPI) o-=TBASPI;
		while (o<-HALFPI) o+=TBASPI;
		if (fabs(fabs(o)-HALFPI)<ZEROCALC) {
			perror_(__LINE__,127,l); // warning
			o=o<0?MINFF:INFF;
		}
		else o=tan(o);
	}
	/* TANH(x) hyperbolic tangent function
	 * Domain: x -> R
	 * Range:  y -> R : -1 < y < 1 */
	else if (!strncasecmp_(p,"TANH(",5)) {
		p+=5;
		o=S();
		o=(exp(o)-exp(-o))/(exp(o)+exp(-o));
	}
	/* TEN(x) ten power function
	 * ~tenth power function (base 10)
	 * Domain: x -> R 
	 * Range:  y -> R : y >= 0 */
	else if (!strncasecmp_(p,"TEN(",4)) {
		p+=4;
		o=S();
		o=pow(10.0,o);
	}
	/* VAL(x$) function 
	 * ~return the value of the literal number in the argument,
	 * which must be a regular string */
	else if (!strncasecmp_(p,"VAL(",4)) {
		char op[LIMIT+1]; // to store string to parse for VAL
		char *pp, pe[COMPSTR];
		p+=4;
		o=0.0;
		strncpy_(op,SS(),LIMIT+1);
		/* Note: the only incorrect forms of the argument I can think 
		 * of is if it's null; if so, return 0.0 with a warning */
		if (!op[0]) {
			perror_(__LINE__,131,l);
			return 0.0;
		}
		stripBlanks(op,pe);
		pp=p;
		p=pe;
		o=strtod(p,&p);
		strncpy_(valRest,p,COMPSTR);
		if (*p) perror_(__LINE__,229,l); // warning
		p=pp;
	}
	/* EVAL(x$) function 
	 * ~return the value of the number or ground formula in the argument, 
	 * which must be a regular string */
	else if (!strncasecmp_(p,"EVAL(",5)) {
		char op[COMPSTR];
		char *pp, pe[COMPSTR];
		p+=5;
		o=0.0;
		strncpy_(op,SS(),COMPSTR);
		/* Note: the only incorrect forms of the argument I can think 
		 * of is if it's null; if so, return 0.0 with a warning */
		if (!op[0]) {
			perror_(__LINE__,131,l);
			return 0.0;
		}
		/* in case it holds a number or a ground formula, turn string 
		 * to float using tbas rules 
		 * Note: isValOn is a flag that forces interpretation of
		 * string as a ground formula (no variables) */
		stripBlanks(op,pe);
		pp=p;
		isValOn=TRUE;
		p=pe;
		o=S();
		isValOn=FALSE;
		strncpy_(evalRest,p,COMPSTR);
		p=pp;
	}
	/* DIM-RELATED FUNCTIONS */
	/* LBOUND()/LDIM() function
	 * ~return the lowest index */
	else if ((cn=recog(2,p,"LBOUND(","LDIM("))) {
		p+=cn;
		o=getBound(FALSE);
	}
	/* UBOUND()/UDIM() function
	 * ~return the highest index */
	else if ((cn=recog(2,p,"UBOUND(","UDIM("))) {
		p+=cn;
		o=getBound(TRUE);
	}
	/* TIME-RELATED FUNCTIONS */
	/* CLK/CLK(d) variable or function with dummy argument
	 * ~return hour in the format hh.nnnn (hour plus minutes and seconds
	 * in a percentage as decimals)
	 * ~es. 15h 26' 34" = 15.4428 (= 44% of the 15th hour) */
	else if (!strncasecmp_(p,"CLK",3) && !isalnum(*(p+3))) {
		p+=3;
		if (*p=='(') {
			p++;
			o=S(); // dummy
		}
		else p--, paren=FALSE;
		o=(getMin()*60.0+getSec())/3600.0+getHour();
	}	
	/* HOUR/HOUR() function 
	 * ~if argument is absent or 0, return current hour
	 * ~if argument is in the decimal format hh.nnnn, extract hour  */
	else if (!strncasecmp_(p,"HOUR",4) && !isalnum(*(p+4))) {
		p+=4;
		o=0.0;
		if (*p=='(') {
			p++;
			o=S();
		}
		else p--, paren=FALSE;
		if (o==0.0) o=getHour();
		else o=(int)o;		// int
	}
	/* MINUTE/MINUTE() function 
	 * ~if argument is absent or 0, return current minute
	 * ~if argument is in the decimal format hh.nnnn, extract minutes  */
	else if (!strncasecmp_(p,"MINUTE",6) && !isalnum(*(p+6))) {
		p+=6;
		o=0.0;
		if (*p=='(') {
			p++;
			o=S();
		}
		else p--, paren=FALSE;
		if (o==0.0) o=getMin();
		else {
			o-=(int)o;	// frac
			o=(int)(60*o);	
		}
	}
	/* SECOND/SECOND() function 
	 * ~if argument is absent or 0, return current second
	 * ~if argument is in the decimal format hh.nnnn, extract seconds  */
	else if (!strncasecmp_(p,"SECOND",6) && !isalnum(*(p+6))) {
		p+=6;
		o=0.0;
		if (*p=='(') {
			p++;
			o=S();
		}
		else p--, paren=FALSE;
		if (o==0.0) o=getSec();
		else {
			int m;
			o-=(int)o; 	// frac
			m=(int)(60*o); 	// min
			o=(int)(3600.0*(o-m/60.0)+0.5);
		}
	}
	/* DATE/DATE(d) variable or function with dummy value
	 * ~return current date in the decimal format yy.mmdd */
	else if (!strncasecmp_(p,"DATE",4) && !isalnum(*(p+4))) {
		int y,m,d;
		y=getYear();
		p+=4;
		if (*p=='(') {
			p++;
			o=S(); // dummy
		}
		else p--, paren=FALSE;
		/* retain year's last two digits only */
		while (y>1000) y-=1000;
		while (y>100) y-=100;
		m=getMonth();
		d=getDay();
		o=y+m/100.0+d/10000.0;
	}	
	/* TIM/TIM(d) variable or function with dummy value 
	 * ~'begin' time is calculated in RUN() with the first program 
	 * (i.e. out of a CHAIN sequence) 
	 * Note: TIM returns the elapsed execution time in milliseconds up to 
	 * the TIM call, including all the programs (in the CHAIN) met so far */
        else if (!strncasecmp_(p,"TIM",3) && !isalnum(*(p+3))) { 
		double now;
		p+=3;
        	gettimeofday(&tv, NULL);
           	now = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		if (*p=='(') {
			p++;
			o=S(); // dummy
		}
		else p--, paren=FALSE;
		o=((int)(1000*(now-beginS)+0.5)); // milliseconds
	}
	/* DAY/DAY() function 
	 * ~if argument is absent or 0, return current day
	 * ~if argument is in the format yy.mmdd or yyyy.mmdd, extract day */
	else if (!strncasecmp_(p,"DAY",3) && !isalnum(*(p+3))) {
		p+=3;
		o=0.0;
		if (*p=='(') {
			p++;
			o=S();
		}
		else p--, paren=FALSE;
		if (o==0.0) o=getDay();
		else {
			o*=100;
			o-=(int)o;
			o=(int)(o*100.0+0.5);
		}
	}
	/* MONTH/MONTH() function 
	 * ~if argument is absent or 0, return current month
	 * ~if argument is in the format yy.mmdd or yyyy.mmdd, extract month */
	else if (!strncasecmp_(p,"MONTH",5) && !isalnum(*(p+5))) {
		p+=5;
		o=0.0;
		if (*p=='(') {
			p++;
			o=S();
		}
		else p--, paren=FALSE;
		if (o==0.0) o=getMonth();
		else {
			o-=(int)o;
			o=(int)(o*100);
		}
	}
	/* YEAR/YEAR() function 
	 * ~if argument is absent or 0, return current year
	 * ~if argument is in the format yy.mmdd or yyyy.mmdd, extract year 
	 * for current century 
	 * ~year is returned in yyyy format */
	else if (!strncasecmp_(p,"YEAR",4) && !isalnum(*(p+4))) {
		p+=4;
		o=0.0;
		if (*p=='(') {
			p++;
			o=S();
		}
		else p--, paren=FALSE;
		o=(int)setYear(o);
	}
	/* STRING-RELATED FUNCTIONS */
	/* ASC(x)|ASCII(x)/ORD(x) function 
	 * ~return ASCII code of character argument; argument can be:
	 * ~a label identifying a standard ASCII name
	 * ~a character only in the range 0-127
	 * ~a string in any form (enclosed into double quotes, a variable,
	 * a string function): in this case the first character of the string 
	 * is returned.
	 * Note: the ASCII table represented by ASC() is in the range 0-255 */
	else if ((cn=recog(3,p,"ASC(","ASCII(","ORD("))) {
		p+=cn;
		/* void argument */
		if (*p==')') o=32; // ASC() = ASC( )
		else if (!strncasecmp_(p,"NUL",3)) o=0,p+=3;
		else if (!strncasecmp_(p,"SOH",3)) o=1,p+=3;
		else if (!strncasecmp_(p,"STX",3)) o=2,p+=3;
		else if (!strncasecmp_(p,"ETX",3)) o=3,p+=3;
		else if (!strncasecmp_(p,"EOT",3)) o=4,p+=3;
		else if (!strncasecmp_(p,"ENQ",3)) o=5,p+=3;
		else if (!strncasecmp_(p,"ACK",3)) o=6,p+=3;
		else if (!strncasecmp_(p,"BEL",3)) o=7,p+=3;
		else if (!strncasecmp_(p,"BS",2)) o=8,p+=2;
		else if (!strncasecmp_(p,"HT",2)) o=9,p+=2;
		else if (!strncasecmp_(p,"LF",2)) o=10,p+=2;
		else if (!strncasecmp_(p,"VT",2)) o=11,p+=2;
		else if (!strncasecmp_(p,"FF",2)) o=12,p+=2;
		else if (!strncasecmp_(p,"CR",2)) o=13,p+=2;
		else if (!strncasecmp_(p,"SO",2)) o=14,p+=2;
		else if (!strncasecmp_(p,"SI",2)) o=15,p+=2;
		else if (!strncasecmp_(p,"DLE",3)) o=16,p+=3;
		else if (!strncasecmp_(p,"DC1",3)) o=17,p+=3;
		else if (!strncasecmp_(p,"DC2",3)) o=18,p+=3;
		else if (!strncasecmp_(p,"DC3",3)) o=19,p+=3;
		else if (!strncasecmp_(p,"DC4",3)) o=20,p+=3;
		else if (!strncasecmp_(p,"NAK",3)) o=21,p+=3;
		else if (!strncasecmp_(p,"SYN",3)) o=22,p+=3;
		else if (!strncasecmp_(p,"ETB",3)) o=23,p+=3;
		else if (!strncasecmp_(p,"CAN",3)) o=24,p+=3;
		else if (!strncasecmp_(p,"EM",2)) o=25,p+=2;
		else if (!strncasecmp_(p,"SUB",3)) o=26,p+=3;
		else if (!strncasecmp_(p,"ESC",3)) o=27,p+=3;
		else if (!strncasecmp_(p,"FS",2)) o=28,p+=2;
		else if (!strncasecmp_(p,"GS",2)) o=29,p+=2;
		else if (!strncasecmp_(p,"RS",2)) o=30,p+=2;
		else if (!strncasecmp_(p,"US",2)) o=31,p+=2;
		else if (!strncasecmp_(p,"SP",2)) o=32,p+=2;
		else if (!strncasecmp_(p,"DEL",3)) o=127,p+=3;
		else if (*(p+1)==')') o=*p++; // any single char
		else if (isanystring(p)) {
			char str[COMPSTR];
			strncpy_(str,SS(),COMPSTR);
			o=*str;
			if (o<0) o+=256;
		}
		else if ((cn=findDEC(p)) && _rettype==STR && !_arr) {
			char str[COMPSTR];
			strncpy_(str,SS(),COMPSTR);
			o=*str;
			if (o<0) o+=256;
		}
		else {
			perror_(__LINE__,32,l);
			return 0.0;
		}
		if (*p!=')') {
			perror_(__LINE__,65,l,makechar(p),")");
			return 0.0;
		}
	}
	/* INSTR([n,]a$,b$) function 
	 * ~return position of string b$ into string a$ (starting at
	 * position n if specified, or else at first character of a$) */
	else if (!strncasecmp_(p,"INSTR(",6)) {
		int pos=0;
		char op1[COMPSTR], op2[COMPSTR];
		char *P1;
		p+=6;
		/* the starting position has been set */
		if (!isanystring(p)) {
			pos=(int)S()-1;
			if (*p==',') p++;
			else {
				perror_(__LINE__,43,l);
				return 0.0;
			}
		}
		/* first string is the base string */
		strncpy_(op1,SS(),COMPSTR);
		if (pos<0) pos=0;
		if (pos>(int)strlen(op1)) pos=(int)strlen(op1);
		/* set starting position */
		P1=op1+pos;
		if (*p==',') p++; 
		else {
			perror_(__LINE__,37,l);
			return 0.0;
		}
		/* second string is the search string */
		strncpy_(op2,SS(),COMPSTR);
		if (isCaseSensitive) o=(double)(strstr(P1,op2)-op1)+1;
		else o=(double)(strcasestr_(P1,op2)-op1)+1;
		if (o<0 || o>(int)strlen(op1)) o=0.0;
	}
	/* POS(a$,b$[,n]) function (Dartmouth and HP BASIC tradition)
	 * ~return position of string b$ into string a$ (starting at
	 * position n if specified, or else at first character of a$) */
	else if (!strncasecmp_(p,"POS(",4)) {
		int pos=0;
		char op1[COMPSTR], op2[COMPSTR];
		char *P1;
		p+=4;
		/* first string is the base string */
		strncpy_(op1,SS(),COMPSTR);
		if (*p==',') p++; 
		else {
			perror_(__LINE__,43,l);
			return 0.0;
		}
		/* second string is the search string */
		strncpy_(op2,SS(),COMPSTR);
		/* the starting position has been set */
		if (*p==',') {
			p++;
			pos=(int)S()-1;
		}
		/* set starting position*/
		if (pos<0) pos=0;
		if (pos>(int)strlen(op1)) pos=(int)strlen(op1);
		P1=op1+pos;
		if (isCaseSensitive) o=(double)(strstr(P1,op2)-op1)+1;
		else o=(double)(strcasestr_(P1,op2)-op1)+1;
		if (o<0 || o>(int)strlen(op1)) o=0.0;
	}
	/* FILE-RELATED FUNCTIONS */
	/* EXISTS() function
	 * check if a file exists and what permissions it has
	 * Note: only read and write permissions are given here, because
	 * it's supposed that data file written or read by tbas are not
	 * executable but only text files or random access files */
	else if (!strncasecmp_(p,"EXISTS(",7)) {
		char op[COMPSTR];
		p+=7;
		strncpy_(op,SS(),COMPSTR);
		o=(double)doesExist(op);
	}
	/* FREECHANNEL function 
	 * return the index of the first free (i.e. not used yet) 
	 * channel openable thorugh OPEN, FILE or FILES */
	else if (!strncasecmp_(p,"FREECHANNEL",11)) {
		int i;
		p+=11;
		o=0.0;
		for (i=1; i<=STREAMS; i++) {
			if (!channel[i].isopen) {
				o=(double)i;
				break;
			}
		}
		paren=FALSE;
	}
	/* STREAM function 
	 * return the index of current output stream, which is 0 for stdout
	 * and 1 for stderr */
	else if (!strncasecmp_(p,"STREAM",6)) {
		p+=6;
		if (channel[CONSOLE].stream==stdout) o=0.0;
		else o=1.0;
		paren=FALSE;
	}
	/* LASTCHANNEL function 
	 * return the index of the last successful opened channel
	 * thorugh OPEN, FILE or FILES */
	else if (!strncasecmp_(p,"LASTCHANNEL",11)) {
		p+=11;
		o=(double)lastChannel;
		paren=FALSE;
	}
	/* EOF(#x)/EOF(:x)/EOF(x)/EOFx/EOF#x/EOF:x
	 * END(#x)/END(:x)/END(x)/ENDx/END#x/END:x
	 * ~return true if EOF of the file on channel x is reached */
	else if ((cn=recog(2,p,"EOF","END")) && !isalnum(*(p+cn))) {
		int ch, type=SEQ;
		p+=cn; paren=FALSE;
		if (*p=='#') p++, type=SEQ; // case 5
		else if (*p==':') p++, type=RANDOM; // case 6
		else if (*p=='(') {
			p++;
			if (*p=='#') p++, type=SEQ; // case 2
			else if (*p==':') p++, type=RANDOM; // case 3
			paren=TRUE;
		}
		ch=(int)S();
		if (!paren) p--;
		/* test for sequential file*/
		if (channel[ch].type==SEQ) {
			/* check syntax */
			if (type && type==RANDOM) {
				perror_(__LINE__,101,l); 
				return 0.0;
			}
			/* checking if channel is valid */
			if (ch<1 || ch>STREAMS) {
				perror_(__LINE__,133,l);
				return 0.0;
			}
			/* checking if file is open */
			if (!channel[ch].isopen) {
				perror_(__LINE__,80,l);
				return 0.0;
			}
			if (channel[ch].wayout!=VREAD) {
				perror_(__LINE__,85,l);
				return 0.0;
			}
		}
		/* test for random-access file */
		else if (channel[ch].type==RANDOM) {
			/* check syntax */
			if (type && type==SEQ) {
				perror_(__LINE__,101,l); 
				return 0.0;
			}
			/* checking if channel is valid */
			if (ch<1 || ch>STREAMS) {
				perror_(__LINE__,133,l);
				return 0.0;
			}
			/* checking if file is open */
			if (!channel[ch].isopen) {
				perror_(__LINE__,80,l);
				return 0.0;
			}
		}
		/* unrecognized type */
		else {
			perror_(__LINE__,104,l);
			return 0.0;
		}
		/* check EOF */
		o=(double)testEOF(ch); 
	}
	/* MORE(x)/MORE(#x)/MORE(:x)/MOREx/MORE#x/MORE:x
	 * ~return true if EOF of the file on channel x is not reached */
	else if (!strncasecmp_(p,"MORE",4) && !isalnum(*(p+4))) {
		int ch, type=SEQ;
		p+=4; paren=FALSE;
		if (*p=='#') p++, type=SEQ; // case 5
		else if (*p==':') p++, type=RANDOM; // case 6
		else if (*p=='(') {
			p++;
			if (*p=='#') p++, type=SEQ; // case 2
			else if (*p==':') p++, type=RANDOM; // case 3
			paren=TRUE;
		}
		ch=(int)S();
		if (!paren) p--;
		/* test for sequential file*/
		if (channel[ch].type==SEQ) {
			/* check syntax */
			if (type && type==RANDOM) {
				perror_(__LINE__,101,l); 
				return 0.0;
			}
			/* checks if channel is valid */
			if (ch<1 || ch>STREAMS) {
				perror_(__LINE__,133,l);
				return 0.0;
			}
			/* checks if file is open */
			if (!channel[ch].isopen) {
				perror_(__LINE__,80,l);
				return 0.0;
			}
			if (channel[ch].wayout!=VREAD) {
				perror_(__LINE__,85,l);
				return 0.0;
			}
		}
		/* test for random-access file */
		else if (channel[ch].type==RANDOM) {
			/* check syntax */
			if (type && type==SEQ) {
				perror_(__LINE__,101,l); 
				return 0.0;
			}
			/* checks if channel is valid */
			if (ch<1 || ch>STREAMS) {
				perror_(__LINE__,133,l);
				return 0.0;
			}
			/* checks if file is open */
			if (!channel[ch].isopen) {
				perror_(__LINE__,80,l);
				return 0.0;
			}
		}
		/* unrecognized type */
		else {
			perror_(__LINE__,104,l);
			return 0.0;
		}
		/* check EOF */
		o=-(double)(!testEOF(ch)); 
	}
	/* LOC([:]x) function - (LOCation)
	 * ~return the number of the current record in the random file
	 * on the specified channel */
	else if (!strncasecmp_(p,"LOC",3) && !isalnum(*(p+3))) {
		int ch;
		p+=3;
		if (*p==':') p++;
		else if (*p=='(') {
			p++;
			if (*p==':') p++;
			paren=TRUE;
		}
		ch=(int)S();
		if (!paren) p--;
		/* check if file is open and random */
		if (ch<1 || ch>STREAMS) {
			perror_(__LINE__,133,l);
			return 0.0;
		}
		if (!channel[ch].isopen) {
			perror_(__LINE__,80,l);
			return 0.0;
		}
		if (channel[ch].type!=RANDOM) {
			perror_(__LINE__,101,l);
			return 0.0;
		}
		o=channel[ch].currseek;
	}
	/* LOF([:]x) function - (Last Of File)
	 * ~return the number of the last record in the random file
	 * on the specified channel */
	else if (!strncasecmp_(p,"LOF",3) && !isalnum(*(p+3))) {
		int ch;
		p+=3;
		if (*p==':') p++;
		else if (*p=='(') {
			p++;
			if (*p==':') p++;
			paren=TRUE;
		}
		ch=(int)S();
		if (!paren) p--;
		/* check if file is open and random */
		if (ch<1 || ch>STREAMS) {
			perror_(__LINE__,133,l);
			return 0.0;
		}
		if (!channel[ch].isopen) {
			perror_(__LINE__,80,l);
			return 0.0;
		}
		if (channel[ch].type!=RANDOM) {
			perror_(__LINE__,101,l);
			return 0.0;
		}
		o=getEOF(ch);
	}
	/* ERROR-RELATED FUNCTIONS */
	/* ESM/ESM()/ERR/ERR() with (): dummy argument
	 * Error State Message / Error
	 * ~return error message code */
	else if ((cn=recog(2,p,"ESM","ERR")) && !isalnum(*(p+cn))) {
		p+=cn;
		if (*p=='(') {
			p++;
			if (isanynumber(p)) o=S(); // dummy
			else if (*p!=')') syserr_(__LINE__,217,l);
			else o=0;
		}
		else p--, paren=FALSE;
		o=errValue;
	}
	/* ASL/ASL() with (): dummy argument
	 * Attention State Line
	 * ~return line number where interrupt occurred */
	else if (!strncasecmp_(p,"ASL",3) && !isalnum(*(p+3))) {
		p+=3;
		if (*p=='(') {
			p++;
			if (isanynumber(p)) o=S(); // dummy
			else if (*p!=')') syserr_(__LINE__,217,l);
			else o=0;
		}
		else p--, paren=FALSE;
		o=arrLine;
	}
	/* ALN/ALN() with (): dummy argument
	 * Attention Line Number (Label)
	 * ~return label of line number where interrupt occurred */
	else if (!strncasecmp_(p,"ALN",3) && !isalnum(*(p+3))) {
		p+=3;
		if (*p=='(') {
			p++;
			if (isanynumber(p)) o=S(); // dummy
			else if (*p!=')') syserr_(__LINE__,217,l);
			else o=0;
		}
		else p--, paren=FALSE;
		o=ln[arrLine];
	}
	/* ESL/ESL()/ERL/ERL() with (): dummy argument
	 * Error State Line / Error Line
	 * ~return line number where error occurred */
	else if ((cn=recog(2,p,"ESL","ERL")) && !isalnum(*(p+cn))) {
		p+=cn;
		if (*p=='(') {
			p++;
			if (isanynumber(p)) o=S(); // dummy
			else if (*p!=')') syserr_(__LINE__,217,l);
			else o=0;
		}
		else p--, paren=FALSE;
		o=errLine;
	}
	/* ELN/ELN() with (): dummy argument
	 * Error Line Number (Label)
	 * ~return label of line number where error occurred */
	else if (!strncasecmp_(p,"ELN",3) && !isalnum(*(p+3))) {
		p+=3;
		if (*p=='(') {
			p++;
			if (isanynumber(p)) o=S(); // dummy
			else if (*p!=')') syserr_(__LINE__,217,l);
			else o=0;
		}
		else p--, paren=FALSE;
		o=ln[errLine];
	}
	/* NXL() function - NeXt Line
	 * ~return next line number of line in argument (if the argument is
	 * the line where error occurred - ESL - it returns the line 
	 * immediately after, suitable for a JUMP */
	else if (!strncasecmp_(p,"NXL(",4)) {
		p+=4;
		o=0.0;
		if (isanynumber(p)) {
			o=(int)S()+1;
			if (o==0.0) perror_(__LINE__,147,l); // warning
		}
		else if (*p!=')') syserr_(__LINE__,217,l);
	}
	/* DECLARE variables */
	else if (!isValOn && (ns=findDEC(p))) {
		int var=ns, M=0, N=0, T=1;
		p+=_len;
		if (_rettype && _rettype==STR) {
			perror_(__LINE__,217,l);
			return 0.0;
		}
		/* return a number */
		else if (*(p)!='(' && !_arr) {
			if (vn[ns].isInt) o=(int)P[ns];
			else o=P[ns];
			paren=FALSE;
			p+=-1;
		}
		/* return an array */
		else if (*(p)=='(' && _arr) {
			p++;
			M=(int)S();
			if (*p==',') {
				p++;
				N=(int)S();
				T=2;
			}
			/* check dimensions */
			if (T>dim[var].type||M>dim[var].row||N>dim[var].col) {
				perror_(__LINE__,76,l);
				return 0.0;
			}
			else if (vn[ns].isInt) { 
				o=(int) getArrayVal(ns,T,M,N);
			}
			else { 
				o=getArrayVal(ns,T,M,N);
			}
		}
	}
	/* any other sequence of characters is a syntax error 
	 * Note: within EVAL, the error message is dedicated. */
	else if (!isValOn) {
		perror_(__LINE__,37,l);
		return 0.0;
	}
	else {
		perror_(__LINE__,115,l);
		return 0.0;
	}

	/* check closing parenthesis for functions requiring an argument;
	 * p is updated into getVal() */
	if (paren) {
		if (!*p) {
			perror_(__LINE__,65,l,"A FF,LF,VT, OR CR",")");
			return 0.0;
		}
		else if (*p!=')') {
			perror_(__LINE__,33,l,*p);
			return 0.0;
		}
	}
	/* return sweated value! */
	return o;
}


/* optoken()
 * substitute operators names with establishes symbols,
 * according to the following list:
 * && for AND
 * || for OR
 * !! for XOR
 * -> for IMP
 * ## for EQV
 * '{' for NOR
 * '}' for NAND 
 * '' for single ' (only inside strings)
 * Also, get rid of inline REM comments changing them to tick comments.
 * The substitution has the advantage to consider operators as established
 * operators already in use.
 * Note: using option -r (debug), current line is printed after tokenization 
 * and blank-stripping, to see the 'real' string under evaluation
 * System function */
void optoken(char* q) {
	char *qq;
	while((qq=strcasestr_oq(q,"AND")) && qq>q && isante(qq) && ispost(qq+2))
		*qq++='&', *qq++='&',*qq=' ';
	while((qq=strcasestr_oq(q,"OR")) && qq>q && isante(qq) && ispost(qq+1))
		*qq++='|', *qq++='|',*qq=' ';
	while((qq=strcasestr_oq(q,"XOR")) && qq>q && isante(qq) && ispost(qq+2))
		*qq++='!', *qq++='!',*qq=' ';
	while((qq=strcasestr_oq(q,"IMP")) && qq>q && isante(qq) && ispost(qq+2))
		*qq++='-', *qq++='>',*qq=' ';
	while((qq=strcasestr_oq(q,"EQV")) && qq>q && isante(qq) && ispost(qq+2))
		*qq++='#', *qq++='#',*qq=' ';
	while((qq=strcasestr_oq(q,"NOR")) && qq>q && isante(qq) && ispost(qq+2))
		*qq++='{', *qq++=' ',*qq=' ';
	while((qq=strcasestr_oq(q,"NAND"))&& qq>q && isante(qq) && ispost(qq+3))
		*qq++='}', *qq++=' ',*qq++=' ', *qq=' ';
	if ((qq=strcasestr_oq(q,":"))) {
		char *kp=qq+1;
		while (isblank(*kp)) kp++;
		if (!strncasecmp_(kp,"REM",3)) *qq='\'';
	}
}


/******************************************************************************
 * The following functions define general system environment subroutines: 
 * they are internal routines not directly accessible as BASIC statements.
 ******************************************************************************/

/*****************************************
 *            STATEMENTS AID             *
 *****************************************/

/* printFormatted()
 * This is the routine used by all the PRINT/WRITE USING statements and the 
 * FORMAT$ function; its purpose is to build a C-format string from the BASIC 
 * format string, to ensure a correct output according to the required features
 * ad leaving the result in _FORMAT[] (global variable).
 * The number-printing routine is delegated to printFormattedNumber() and the
 * string-printing routine is delegated to printFormattedString().
 * Note: the C-formatter is not a classic C-string formatter (es. "%05f") but
 * a special series of data that identifies the objects that are included in
 * the BASIC formatter, and which is used by the prin:tFormatted subroutines.
 * BForm: the BASIC formatter string
 * list: the sequence of what is to be printed (it follows the USING part)
 *       (FORMAT$() uses NIL here)
 * isWrite: the WRITE flag: if TRUE, prints a Line Number + tab (WRITE)
 * 	 (FORMAT$() uses FALSE here)
 * val: the value to be printed (given only by FORMAT$)
 * 	 (PRINT USING uses 0.0 here)
 * System function for the USING feature */
int printFormatted(char* BForm, char* list, int isWrite, double val) {
	char cForm[SCREENLINE+1], *cf=cForm;
	int ic=0,dc=0;	// ic=integers count, dc=decimals count
	int sL=0,nL=0; 	// sL=strings count, nL=numbers count in list
	int sF=0,nF=0; 	// sF=strings count, nF=numbers count in BForm
	int in,is;	// in and is are indexes for numbers/strings
	int inf,isf;	// inf and ins are field indexes
	double numb[MAXARGS];   	   // the stack for numbers in 'list'
	char stri[MAXARGS][SCREENLINE+1];  // the stack for strings in 'list'
	char fin[COMPSTR];
	char *pb=p;		// secure program counter backup
	char fl=' ', com=sep; 	// filler and separator
	TUsing dat[MAXARGS], datS[MAXARGS];// dat for numbers, datS for strings
	int isInt;	// isInt = is the number in Integer form?
	int isExp;	// isExp = is the number in exponential form?
	int isMin;	// isMin = is the minus sign to be written at the end?
	int isDol;	// isDol = is the dollar format enabled?
	int isCom;	// isCom = is the thousands separator format enabled?
	int isZer;	// isZer = is the zeroes format enabled?
	int isCR=TRUE;	// isCR  = is the final Carriage Return to be printed?
	int CNimage=0,VNlist=0;	// CNimage=num counter, VNlist=num counter
	int CSimage=0,VSlist=0;	// CSimage=str counter, VSlist=str counter
	int i,len,type,items;   // process tools

	/* erase the C-formatter and the destination string (global) */
	for (i=0; i<SCREENLINE; i++) cForm[i]='\0';
	for (i=0; i<COMPSTR; i++) _FORMAT[i]='\0';

	/* check length of BASIC formatter */
	if ((int)strlen(BForm)>MAXSTRLEN) return 112; 
	
	/* step 1. build C images */
	while (*BForm) {
		isInt=TRUE, isExp=FALSE, isMin=FALSE;
		isDol=FALSE, isCom=FALSE, isZer=FALSE;
		len=0; type=LEFTJUST;

		ic=dc=0; isInt=TRUE;
		/* get numeric formatter */
		if ((*BForm=='#' && *(BForm+1)=='#')\
				||((*BForm=='.') && (*(BForm+1)=='#'))\
				||((*BForm=='#') && (*(BForm+1)=='.'))\
				||((*BForm=='*'&&*(BForm+1)=='*')&&((fl='*')))\
				||((*BForm=='0'&&*(BForm+1)=='0')&&((fl='0')))\
				||(*BForm=='$'&&*(BForm+1)=='$') ) {
			*cf++=NUMID;
			CNimage++;
			/* integer part */
			while (*BForm && strchr(",.*#$0",*BForm)) {
				if (*BForm==',') isCom=TRUE,BForm++,ic++;
				if (*BForm=='$') isDol=TRUE,BForm++,ic++;
				if (*BForm=='*') BForm++,ic++;
				if (*BForm=='0') BForm++,ic++;
				if (*BForm=='#') BForm++,ic++;
				/* decimal part */
				if (*BForm=='.') {
					BForm++;
					isInt=FALSE;
					while(*BForm&&strchr(",.*#$0",*BForm)){ 
						if (*BForm==',') 
						    isCom=TRUE,BForm++,dc++;
						else if (*BForm=='$') 
						    isDol=TRUE,BForm++,dc++;
						else if (*BForm=='*') 
						    BForm++,dc++;
						else if (*BForm=='0') 
						    BForm++,dc++;
						else if (*BForm=='#') 
						    BForm++,dc++;
						else break;
					}
					break;
				}
			}
			/* exponential in case of float */
			if (!isInt && !strncmp(BForm,"^^^^",4)) {
				BForm+=4;
				isExp=TRUE;
			}
			/* minus at the end */
			if (*BForm=='-') {
				BForm++;
				isMin=TRUE;
			}

			/* store current-image data */
			dat[nF].ic=ic;
			dat[nF].dc=dc;
			dat[nF].isInt=isInt;
			dat[nF].isExp=isExp;
			dat[nF].isMin=isMin;
			dat[nF].isCom=isCom;
			dat[nF].isDol=isDol;
			dat[nF].fill=fl;
			dat[nF].com=com;
			dat[nF].isZer=isZer;
			nF++;

		}
		/* get string formatter #1 <###, <###< and <###> */	
		else if (*BForm=='<' && *(BForm+1)=='#') {
			*cf++=STRID;
			CSimage++;
			len=1;
			BForm++;
			while (*BForm=='#') BForm++, len++;
			if (*BForm=='>') BForm++, len++, type=CENTERED;
			else if (*BForm=='<') BForm++, len++, type=EXTENDED;
			else type=LEFTJUST;
			datS[sF].len=len;
			datS[sF].type=type;
			sF++;
		}
		/* get string formatter #1 >### */	
		else if (*BForm=='>' && *(BForm+1)=='#') {
			*cf++=STRID;
			CSimage++;
			len=1;
			BForm++;
			while (*BForm=='#') BForm++, len++;
			type=RIGHTJUST;
			datS[sF].len=len;
			datS[sF].type=type;
			sF++;
		}
		/* get string formatter #2 (DEC-20 features)*/	
		else if (*BForm=='\'') {
			*cf++=STRID;
			CSimage++;
			len=1;
			BForm++;
			/* E Format Character */
			if (*BForm=='E') {
				type=EXTENDED;
				while (*BForm=='E') BForm++,len++;
			}
			/* C Format Character */
			else if (*BForm=='C') {
				type=CENTERED;
				while (*BForm=='C') BForm++,len++;
			}
			/* L Format Character */
			else if (*BForm=='L') {
				type=LEFTJUST;
				while (*BForm=='L') BForm++,len++;
			}
			/* R Format Character */
			else if (*BForm=='R') {
				type=RIGHTJUST;
				while (*BForm=='R') BForm++,len++;
			}
			/* store current-image data */
			datS[sF].len=len;
			datS[sF].type=type;
			sF++;
		}
		else {
			/* escape */
			if (*BForm=='\\') BForm++;
			*cf++=*BForm++;
		}
	}
	
	/* step 2. close the C-formatter */
	*cf='\0'; cf=cForm;

	/* step 3a. add val argument (called with list=NIL)*/
	if (!list) {
		numb[nL++]=val;
		VNlist++;
		isCR=FALSE;

	}
	/* step 3b. grab arguments to be printed in 'list' and add them */
	else while (*list) {
		/* string in any form */
		if (isanystring(p)) {
			p=list;
			strncpy_(stri[sL++],SS(),COMPSCR);
			list=p;
			VSlist++;
		}
		/* number in any form */
		else {
			double res=0;
			p=list;
			res=S();
			numb[nL++]=res;
			list=p;
			VNlist++;
		}
		/* is string ended? */
		if (!*list) isCR=TRUE;
		else if (*list==',' || *list==';') {
			list++;
			isCR=FALSE;
		}
		else if (*list) return 87; 
	}

	/* step 4. check errors and discontinuities */
	if (VSlist && !VNlist && !CSimage && CNimage) return 68; 
	if (!VSlist && VNlist && CSimage && !CNimage) return 68; 
	if (VSlist && !CSimage) return 105; 
	if (VNlist && !CNimage) return 105; 

	/* step 5. add elements in order */
	in=is=0;
	inf=isf=0;
	items=sL+nL;
	
	while (items>0) {
		/* restart formatter if there are still items to print */
		if (!*cf) {
			chrcat_(_FORMAT,'\n',COMPSTR);
			cf=cForm;
		}
		/* if the formatter is at the beginning, do the WRITE line
		 * prepending a five digits number followed by a tab */
		if (cf==cForm && isWrite) { 
			sprintw(fin,COMPSTR,"%05d\t",writeSeqStart);
			strncat_(_FORMAT,fin,COMPSTR);
			writeSeqStart+=writeSeqStep;
		}
		/* add a number in a number field */
		if (*cf==NUMID) {
			int ern=0;
			ern=printFormattedNumber(numb[in],dat[inf],_FORMAT);
			if (ern>0) return ern;
			in++;
			cf++;
			inf++; if (inf>=nF) inf=0;
			items--;
		}
		/* add a string */
		else if (*cf==STRID) {
			printFormattedString(stri[is],datS[isf],_FORMAT);
			is++;
			cf++;
			isf++; if (isf>=sF) isf=0;
			items--;
		}
		/* add the rest of the formatter string */
		while (*cf && *cf!=NUMID && *cf!=STRID && *cf!='\n') {
			if (*cf==',' && !*(cf+1)) break;
			chrcat_(_FORMAT,*cf++,COMPSTR);
		}
	}
	/* step 6. close line */
	if (isCR) chrcat_(_FORMAT,'\n',COMPSTR);

	/* the result is in _FORMAT: let the PRINTUSING family to print
	 * result after calling this printFormatted() and let FORMAT$() to
	 * add _FORMAT to mypad[] */

	/* final step. restore general pointer */
	p=pb;
	return TRUE;
}


/* printFormattedString() 
 * build a formatted string according to information contained in the 'us' 
 * formatter.
 * str: the string to print
 * us: a TUsing structure holding formatting data
 * dest: the destination string 
 * System function for the USING management */
void printFormattedString(char* str, TUsing us, char *dest) {
	int thislen=(int)strlen(str),i;
	char format[FORMATLINE*4+1];
	char fin[COMPSTR]="";

	/* set up left justification (with cut) */
	if (us.type==LEFTJUST) { // "%-s"
		if (thislen<us.len) 
			sprintw(format,FORMATLINE*4+1,"%%-%d.%ds",us.len,us.len);
		else if (thislen>us.len) 
			sprintw(format,FORMATLINE*4+1,"%%%d.%ds",us.len,us.len);
		else sprintw(format,FORMATLINE*4+1,"%%s");
	}
	/* set up right justification (with cut) */
	else if (us.type==RIGHTJUST) 
		sprintw(format,FORMATLINE*4+1,"%%%d.%ds",us.len,us.len);
	/* set up centered justification (with cut) */
	else if (us.type==CENTERED) {
		if (thislen<us.len) {
			for (i=0;i<(int)((us.len-thislen)/2);i++) {
				chrcat_(dest,' ',COMPSTR);
			}
			sprintw(format,FORMATLINE*4+1,"%%s");
		}
		else if (thislen>us.len) 
			sprintw(format,FORMATLINE*4+1,"%%%d.%ds",us.len,us.len);
		else sprintw(format,FORMATLINE*4+1,"%%s");
	}
	/* set up extended (with no cut) */
	else if (us.type==EXTENDED) 
		sprintw(format,FORMATLINE*4+1,"%%-%ds",us.len);
	/* append result */
	sprintw(fin,COMPSTR,format,str);
	strncat_(dest,fin,COMPSTR);
	/* complete centered justification appending spaces as needed*/
	if (us.type==CENTERED) {
		for(i=0;i<us.len-thislen-(int)((us.len-thislen)/2);i++) {
			chrcat_(dest,' ',COMPSTR);
		}
	}
}


/* printFormattedNumber() 
 * build a float number according to the information contained in the 'us' 
 * formatter, leaving to outNum() the task to append the number digits. 
 * num: the floating point number to print
 * us: a TUsing structure holding formatting data
 * dest: the destination string 
 * System function for the USING management */
int printFormattedNumber(double num, TUsing us, char *dest) {
	int sign=1,nlen=0,b=0;
	char temp[MAXSTRLEN], *t=temp;

	/* make checks */
	if (us.isExp && (us.isDol || us.fill=='*'|| us.fill=='0')) 
		return 78; 

	/* convert num to a positive number, saving sign */
	if (num<0) sign=-1, num*=-1;
	if (num>INFF) num=INFF;

	/* Trap for numbers in the range ]-1,1[ when an integer is to be
	 * printed (that is, no decimal was specified in the BASIC format):
	 * since num has already been turned into a positive number, 
 	 * restart to avoid seeing -0 or 0- in the output figure */
	if (num<1.0 && us.isInt && !us.isZer) {
		int ern=0;
		us.isZer=TRUE;
		ern=printFormattedNumber(num,us,dest);
		if (ern>0) return ern;
		return TRUE;
	}

	/* Treat minus identifier, which causes the possible negative minus 
	 * sign to be printed afterwards;
	 * Note: the normal negative sign printing is embedded in the 
	 * following printing routine */
	if (sign<0) {
		if (us.isMin) {
			int ern=0;
			ern=printFormattedNumber(num,us,dest);
			if (ern>0) return ern;
			chrcat_(dest,'-',COMPSTR);
			return TRUE;
		}
		else if ((us.isDol || us.fill=='*'|| us.fill=='0')) 
			return 67;
	}
	nlen=intLen(num);
	if (us.isCom) nlen+=(int)((nlen-1)/3); // add commas number
	b=nlen;

	/* reset number in case of the special case 1E-N as a difference number
	 * because it cannot be rendered exactly in memory due to the storing 
	 * technique and the fact there is only one significant digit.
	 * The algorithm is: print the number in the exponential format of C
	 * on the string temp; if the number of significant digits is only 1, 
	 * convert the number from this string, otherwise use original one */
	sprintw(temp, MAXSTRLEN,"%g",num);
	while (*t!='e' && *t!='E') t++; // 'E' should be pleonastic, but...
	if ((int)(t-temp)<2) num=strtod(temp,NULL);

	/* normal form (options: dollar, commas or asterisk-fill) */
	if (!us.isExp) {
		/* minus at the end */
		if (us.isMin) {
			if (nlen < us.ic) {
				while (b++ < us.ic-1) {
					chrcat_(dest,us.fill,COMPSTR);
				}
				if (us.isDol) chrcat_(dest,'$',COMPSTR); 
				else chrcat_(dest,us.fill,COMPSTR);
			}
			if (nlen > us.ic || (nlen==us.ic && us.isDol)) {
				chrcat_(dest,'&',COMPSTR);
				if (us.isDol) chrcat_(dest,'$',COMPSTR); 
			}
		}
		/* normal minus ahead of number */
		else {
			if (nlen < us.ic) {
				while (b++ < us.ic-1) {
					chrcat_(dest,us.fill,COMPSTR);
				}
				if (sign<0) chrcat_(dest,'-',COMPSTR);
				else if (us.isDol) chrcat_(dest,'$',COMPSTR);
				else chrcat_(dest,us.fill,COMPSTR);
			}
			if (nlen > us.ic || (nlen==us.ic && sign<0)) {
				chrcat_(dest,'&',COMPSTR);
				if (sign<0) chrcat_(dest,'-',COMPSTR);
				else if (us.isDol) chrcat_(dest,'$',COMPSTR);
			}
		}
		outNum(num,us,dest);
	}
	/* exponential form 
	 * Note: exponentials never overflow; they adapt their format
	 * to the length of the integer part (minimum two placeholders),
	 * so that at least the sign and a digit can be represented; 
	 * if no dot is in the number image, the ^^^^ symbol is taken "as-is";
	 * if the dot is present, and isn't followed by any digits placeholders 
	 * in the number image, no decimal is printed, but the dot is. */
	else {
		char esign, fin[COMPSTR]="";
		int i=0, E=0, cut, w;
		if (num>ZERO) {
			/* reduce to the 0.nnnnnnnn form */
			while (num < 0.1) num*=10.0, E--;
			while (num > 1.0) num/=10.0, E++;
			/* expand to the maximum ic (integer digits count)
			 * space; in case of postponed minus, the space is 
			 * the  whole ic length, otherwise reserve one space 
			 * for the sign position (a white space in case 
			 * of positive numbers) */
			cut=us.isMin?0:1;
			while (i<us.ic-cut) i++, num*=10.0, E--;
			/* append sign */
			if (E<0) esign='-', E*=-1;
			else esign='+';
			if (sign<0) chrcat_(dest,'-',COMPSTR);
			else if (!us.isMin) chrcat_(dest,us.fill,COMPSTR);
			/* append integer part, dot and float part */
			outNum(num,us,dest);
			/* append E.XX*/
			sprintw(fin,COMPSTR,"E%c%02d%n",esign,E,&w);
			strncat_(dest,fin,COMPSTR);
		}
		else {
			/* in case of ZERO, fill before 0.0 */
			while (i<us.ic-1) {
				i++;
				chrcat_(dest,us.fill,COMPSTR);
			}
			outNum(0.0,us,dest);
			strncat_(dest,"E+00",COMPSTR);
		}
	}
	return 0;
}


/* intLen()
 * find the length of the integer part of any number passed as double, up to 
 * INFF (suitable for outNum). If the number is negative, it is turned to 
 * positive (the minus sign is not counted because printFormattedNumber() 
 * arranges it).
 * num: the float to be printed
 * System function for the USING management */
int intLen(double num) {
	int len=0;
	double integ;
	if (num<0) num*=-1;
	if (num<10) return 1;
	modf(num,&integ);
	while (!(1.0 > integ)) integ/=10,len++;
	return len;
}


/* outNum()
 * build a positive number in float according to the BASIC format, appending
 * it to the destination string.
 * num: the number to be printed 
 * us: a TUsing structure holding formatter data
 * dest: the destination string
 * System function for the USING management */
void outNum(double num, TUsing us, char* dest) {
	char nums[FORMATLINE*4+1], *np=nums, format[FORMATLINE*4+1];
	int e=0, i=0, zero=FALSE, m=0;
	double temp, integ;

	/* if number must have no decimals and it's not an integer, it should 
	 * be rounded; so print it to a string, restore it and continue */
	if (!us.dc && !us.isInt) {
		sprintw(nums,FORMATLINE*4+1,"%.0f", num);
		num=strtod(nums,NULL);
	}

	/* cut out significant digits after fifteenth
	 * by building number string in bare format through C */
	if (num<0) num*=-1; // just to be sure...
	if (num<ZERO) zero=TRUE;
	else {
		while (num >= 1.0) num/=10, e++;
		while (num < 0.1) num*=10, e--;
	}
	sprintw(nums,FORMATLINE*4+1,"%.15f",num);

	/* now number is in the form 0.XXXXXXXXXXXXXXX (15 significant digits)
	 * and 'e' holds the exponential factor */

	/* BUILD INTEGER PART */
	np+=2; // skip 0 and dot
	if (!isAmericanFormat) sep='\'';
	if (e<=0 || zero) {
		chrcat_(dest,'0',COMPSTR);
	}
	else {
		/* add all significant digits */
		while (i<e-1) {
			if (!*np) break;
			chrcat_(dest,*np,COMPSTR);
			m=(e-i)%3;
			if (m==1 && us.isCom) {
				chrcat_(dest,sep,COMPSTR);
			}
			i++,np++;
		}
		if (i<e && *np) {
			chrcat_(dest,*np,COMPSTR);
			i++,np++;
		}
		/* if number is not finished, fill the rest with zeroes */
		while (i<e-1) {
			chrcat_(dest,'0',COMPSTR);
			m=(e-i)%3;
			if (m==1 && us.isCom) {
				chrcat_(dest,sep,COMPSTR);
			}
			i++;
		}
		if (i<e) {
			chrcat_(dest,'0',COMPSTR);
		}
	}

	/* end up in case of integer */
	if (us.isInt) return;

	/* APPEND THE DOT */
	if (isAmericanFormat) chrcat_(dest,'.',COMPSTR);
	else chrcat_(dest,',',COMPSTR);

	/* BUILD FRACTIONAL PART */
	i=0;

	/* end up in case there are no decimals */
	if (!us.dc) return;

	/* add all necessary zeros that follow the dot */
	while(e<0 && i<us.dc) chrcat_(dest,'0',COMPSTR), i++, e++;

	/* end up in case all digits were printed (num may not be over) */
	if (e<0 || i>=us.dc) return;

	/* add the rest of the decimal digits */
	*(np-1)='.';
	temp=modf(atof(np-1),&integ);
	sprintw(format,FORMATLINE*4+1,"%%0.%df",us.dc-i);
	sprintw(nums,FORMATLINE*4+1,format,temp); // autoformat && autorounding
	strncat_(dest,nums+2,COMPSTR);   // skip '0' and '.'
}


/* checkNames()
 * control that a file cannot be opened more than once, using FILES or FILE.
 * c: the channel id to check
 * fname: the file name to check 
 * return TRUE if a file already opened does exist, FALSE otherwise.
 * System function for the file management */
int checkNames(int ch, char* fname) {
	int i=1, res=FALSE;
	while (i<=STREAMS) {
		if (i==ch);
		else if (!strcasecmp(channel[i].ioname,fname)) {
			res=TRUE; 
			break;
		}
		i++;
	}
	return res;
}


/* doesExist()
 * this function determines if the file whose name is in the argument is 
 * accessible in read, write or both modes by current tbas session.
 * The sequence of the permissions follows these lines:
 * - if the user owns the file, the permission is the user file permission
 * - if the file is not owned by the user, but the groups are the same, the 
 *   permission is the group file permission
 * - if the file is not owned by the user, and the groups differ, the 
 *   permission is the world file permission
 * - else the file is not accessible.
 * Return values are as follows:
 * - For a file that exists but is not a file (a directory or a block file) -4 
 *   is returned; if the string is empty, return also -4 along with a warning
 * - For a file that does not exist, -8 is returned
 * - For a file that exists but is not accessible by tbas, 0 is returned
 * - For a file that exists and is accessible in read mode only, 1 is returned
 * - For a file that exists and is accessible in write mode only, 2 is returned
 * - For a file that exists and is accessible in read and write mode, 3 is 
 *   returned (that is 1+2) */
int doesExist(char *fn) {
	int read=0, write=0;
	int readu=0, readg=0, reado=0;
	int writeu=0, writeg=0, writeo=0;
	int fgroup=0, ugroup=0, fuser=0, uuser=0;

	/* if string is null, it is not a file */
	if (!*fn) {
		perror_(__LINE__,159,l);
		return NOTAFILE;
	}
	
	/* get file attributes and check existence */
	if (stat(fn,&statbuf)<0) return NOEXIST;
	/* is it a directory? */ 
	if (S_ISDIR(statbuf.st_mode)) return NOTAFILE;
	/* is it a block file? */
	if (S_ISBLK(statbuf.st_mode)) return NOTAFILE;
	
	/* find file and tbas process group ids */
	fgroup=(int)statbuf.st_gid;
	ugroup=(int)getegid();
	/* find file and tbas process user ids */
	fuser=(int)statbuf.st_uid;
	uuser=(int)geteuid();
	
	/* calculate READ permissions */
	readu=statbuf.st_mode & S_IRUSR;
	readg=statbuf.st_mode & S_IRGRP;
	reado=statbuf.st_mode & S_IROTH;
	/* check READ permissions */
	if (fuser==uuser) {
		if (readu) read=DOREAD;
	}
	else if (fuser!=uuser && fgroup==ugroup) {
		if (readg) read=DOREAD;
	}
	else if (fuser!=uuser && fgroup!=ugroup) {
		if (reado) read=DOREAD;
	}
	else read=NOACCESS;
	
	/* calculate WRITE permissions */
	writeu=statbuf.st_mode & S_IWUSR;
	writeg=statbuf.st_mode & S_IWGRP;
	writeo=statbuf.st_mode & S_IWOTH;
	/* check WRITE permissions */
	if (fuser==uuser) {
		if (writeu) write=DOWRITE;
	}
	else if (fuser!=uuser && fgroup==ugroup) {
		if (writeg) write=DOWRITE;
	}
	else if (fuser!=uuser && fgroup!=ugroup) {
		if (writeo) write=DOWRITE;
	}
	else write=NOACCESS;

	/* return the total permissions */
	return (read + write);
}


/* setupName()
 * check file name, returning correct file name with extension "bas", if not
 * specified for an unexisting file; deprive name of file specifiers $ or %.
 * If an improper % character followed by number was chosen, len is -1.
 * fn: the file name string
 * mode: return character specifier '$' or '%' or NIL (e.g. $ or %)
 * len: return len of string field if specified (e.g. $15)
 * Note: the file specifiers $, $<num> and % are applied to 'names' of files,
 * or to 'extensions'; thus, a file may be named NUMBER%.DTA or NUMBER.DTA%
 * with the very same effect: random number file called NUMBER.DTA
 * Note: this version does not attach .bas to files called as names only. This
 * characteristic belongs to the DEC-20 O.S. and family
 * System function for the file management */
int setupName(char *fn, int *mode, int *len) {
	int isExt=TRUE;
        char*q=fn, ext[COMPSTR], tempf[COMPFIL];
	FILE *fd;

	/* setup defaults */
	*mode=0;
	*len=0;
	ext[0]='\0';

	/* check if the input file is a directory */
	stat(fn, &statbuf);
	if (S_ISDIR(statbuf.st_mode)) {
		beginS=-1;
		return 3;
	}
	
	/* find extension start (and check eventual specifiers set after
	 * extension in place of after the name) */
	while (*q) q++;
	while (*fn=='.') fn++;
	while (*q !='.' && q > fn) {
		if (*q=='$' || *q=='%') {
			*mode=*q;
			if (*q=='$' && isdigit(*(q+1)))
				*len=strtol(q+1,NULL,10);
			*q='\0';
		}
		q--;
	}

	/* there is an extension */
	if (q > fn) {
		strncpy_(ext,q,COMPSTR);
		*q='\0';
		q--;
	}
	/* there's no extension */
	else {
		if ((int)strlen(q)>0) q=fn+(int)strlen(q)-1;
		isExt=FALSE;
	}

	/* there's a length (or at least I suppose there is) 
	 * Note: this function assumes that no file may be named with an ending 
	 * '$' or '%' followed by any digit, because it would be interpreted as 
	 * a random file; in any case, since it's bad practice in any OS naming 
	 * files using '$' or '%', I take it for granted. */
	if (isdigit(*q)) {
		while ((int)(q-fn)>0 && isdigit(*q)) q--;
		/* it's really a field length */
		if (*q=='$') *len=(int)strtol(q+1,NULL,10);
		/* it's a wrong assignment */
		else if (*q=='%') {
			*len=-1;
			sprintw(fn,COMPSCR,"%d",(int)strtol(q+1,NULL,10));
		}
		/* it's not a field length: number is part of the filename */
		else {
			q++;
			while (isdigit(*q)) q++;
		}
	}
	
	/* there's a specifier $ or % */
	if (*q=='$' || *q=='%') *mode=*q, *q--='\0';

	/* if a dot was printed, but no extension specified, remove the dot */
	if (!strcasecmp(ext,".")) ext[0]='\0', isExt=FALSE;

	/* if an extension was given as input, attach it */
	if (isExt) strncat_(fn, ext, COMPSCR);
	/* search for implicit extension or check if it's needed */
	else {
		/* first attempt: the name alone, extension not present */
		sprintw(tempf,COMPFIL,"%s",fn);
		if ((fd=fopen(tempf,"r"))) {
			fclose(fd);
			return 0;
		}
		/* second attempt: .BAS extension not specified */
		sprintw(tempf,COMPFIL,"%s%s",fn,EXTU);
		if ((fd=fopen(tempf,"r"))) {
			fclose(fd);
			strncat_(fn,EXTU,COMPSCR);
			return 0;
		}
		/* third attempt: .bas extension not specified */
		sprintw(tempf,COMPFIL,"%s%s",fn,EXTL);
		if ((fd=fopen(tempf,"r"))) {
			fclose(fd);
			strncat_(fn,EXTL,COMPSCR);
			return 0;
		}
	}
	return 0;
}


/* testEOF()
 * return TRUE if current file has passed the last character/item, or FALSE.
 * Note: it does NOT control if stream is open.
 * ch: the testing channel id 
 * System function for the file management */
int testEOF(int ch) {
	int res=FALSE, after, before=ftell(channel[ch].stream);
	fseek(channel[ch].stream,0,SEEK_END);
	after=ftell(channel[ch].stream);
	if (before-after>=-1) res=TRUE;
	fseek(channel[ch].stream,before,SEEK_SET);
	return res;
}


/* getEOF()
 * return location of last record for random access files
 * Note: it does NOT control if stream is open 
 * ch: the testing channel id 
 * System function for the file management */
int getEOF(int ch) {
	int back=ftell(channel[ch].stream);
	int res;
	/* calculate total offset */
	fseek(channel[ch].stream,0,SEEK_END);
	res=((int)(ftell(channel[ch].stream)-FIRSTLEN)/channel[ch].reclen);
	/* restore position */
	fseek(channel[ch].stream,back,SEEK_SET);
	return res;
}


/* printContainedRaw() 
 * print a text as-is
 * does not update channel fcounter
 * ch: the output channel id
 * string: the string to be printed (number or string) 
 * System function for the printing management */
void printContainedRaw(int ch, char* st) {
	char out[COMPSTR], *o=out;
	int i=0;
	if (!*st) return;
	while (*st) {
		/* build part of string to be printed */
		o=out;
		while (*st && i< COMPSTR) {
/* alarm beep */	     if (*st=='\\' && *(st+1)=='a') *o++='\a',st+=2;
/* backspace */		else if (*st=='\\' && *(st+1)=='b') *o++='\b',st+=2;
/* formfeed */		else if (*st=='\\' && *(st+1)=='f') *o++='\f',st+=2;
/* newline */		else if (*st=='\\' && *(st+1)=='n') *o++='\n',st+=2;
/* carriage return */	else if (*st=='\\' && *(st+1)=='r') *o++='\r',st+=2;
/* horizontal tab */	else if (*st=='\\' && *(st+1)=='t') *o++='\t',st+=2;
/* vertical tab */	else if (*st=='\\' && *(st+1)=='v') *o++='\v',st+=2;
/* backslash */		else if (*st=='\\' && *(st+1)=='\\') *o++='\\',st+=2;
/* single quote */	else if (*st=='\\' && *(st+1)=='\'') *o++='\'',st+=2;
/* double quote */	else if (*st=='\\' && *(st+1)=='\"') *o++='\"',st+=2;
             		else *o++=*st++; 
			channel[ch].fcounter++;
			i++;
		}
		*o='\0';
		if (isCap) turnToUpper(out);
		/* print string */	
		fprintf(channel[ch].stream,"%s",out);
	}
}



/* printContainedPlain() 
 * print a text into the MARGIN limit;
 * updates channel fcounter
 * ch: the output channel id
 * string: the string to be printed (number or string) 
 * margin: the channel margin (for speed)
 * System function for the printing management */
void printContainedPlain(int ch, char* string, int margin) {
	char out[margin], *o=out;
	if (!*string) return;
	while (*string) {
		/* build part of string to be printed */
		o=out;
		while (*string && channel[ch].fcounter<margin) {
			if (*string==_CR) channel[ch].fcounter=0;
			*o++=*string++; 
			channel[ch].fcounter++;
		}
		*o='\0';
		if (isCap) turnToUpper(out);
		/* print string */	
		fprintf(channel[ch].stream,"%s",out);
		if (channel[ch].fcounter>=margin && *string) {
			FCR(ch);
			channel[ch].fcounter=0;
		}
	}
}


/* printContained()
 * wrapper for directing the print of strings to the Plain (BASIC) and
 * the Raw (print as-is and filters escape characters))
 * System function for the printing management */
void printContained(int ch, char* string, int margin) {
	if (isRawPrint) printContainedRaw(ch,string);
	else printContainedPlain(ch,string,margin);
}


/* fillGap()
 * In a random file, fill the intermediate elements of a random access file 
 * with spaces, whenever the index is moved at least one element over the last;
 * used within FWRITECOLON();
 * No checks is done upon channel
 * ch: the channel id
 * actualIndex: the current value of the random file position
 * System function for the printing management */
void fillGap(int ch, int actualIndex) {
	int i;
	for (i=1; i<channel[ch].currseek-actualIndex; i++) 
		fputc(' ',channel[ch].stream);
}


/* matStrReadAssign(result-matrix,type,rows,columns)
 * iterate through matrix indexes to assign string DATA values
 * var: the matrix code
 * t: the matrix type
 * m, n: matrix rows and columns
 * System routine for matrix management, used into MATREAD() */
int matStrReadAssign(int var, int t, int m, int n){
	int i,j;
	/* vectors */
	if (1==t) {
		for(i=1;i<=m;i++) {
			if (dcs>dataLimitS) return 110; 
			setArrayStr(var,1,i,0,DS[dcs++]);
		}
	}
	/* matrices */
	else {
		/* horizontal vectors */
		if (!m && n) {
			for (i=1;i<=n;i++) {
				if (dcs>dataLimitS) return 110;
				setArrayStr(var,2,0,i,DS[dcs++]);
			}
		}
		/* normal matrices */
		else for(i=1;i<=m;i++) 
			for (j=1;j<=n;j++) {
				/* if out of data, print warning */
				if (dcs>dataLimitS) return 110; 
				setArrayStr(var,2,i,j,DS[dcs++]);
			}
	}
	return 0;
}


/* matInputAssign(result-matrix,type,rows,columns)
 * iterate through matrix indexes to assign values in string
 * var: the matrix code
 * t: the matrix type
 * m, n: matrix rows and columns numbers
 * System routine for matrix management, used into MATREAD() */
int matReadAssign(int var, int t, int m, int n){
	int i,j;
	/* vectors */
	if (1==t) {
		for(i=1;i<=m;i++) {
			if (dc>dataLimit) return 110;
			setArrayVal(var,1,i,0,D[dc++]);
		}
	}
	/* matrices */
	else {
		/* horizontal vectors */
		if (!m && n) {
			for (i=1;i<=n;i++) {
				if (dc>dataLimit) return 110;
				setArrayVal(var,2,0,i,D[dc++]);
			}
		}
		/* normal matrices */
		else for(i=1;i<=m;i++) 
			for (j=1;j<=n;j++) {
				/* if out of data, print warning */
				if (dc>dataLimit) return 110;
				setArrayVal(var,2,i,j,D[dc++]);
			}
	}
	return 0;
}


/* isfn(string-position) 
 * (IS a FN function implicit assignment) 
 * test if the current string **begins** with a FN + char
 * p is not touched
 * System function for the parsing management */
int isfn(char *p) {
	if (!strncasecmp_(p,"FN",2) && isalpha(*(p+2))) return TRUE;
	else return FALSE;
}


/* issaa(string-position)
 * (IS a String ArrAy)
 * System function for the DIM management */
int issaa(char *lp) {
	if (!isbeginnamechar(lp)) return FALSE;
	while (isnamechar(lp)) lp++;
	if (*lp!='$') return FALSE;
	else lp++;
	if (*lp!='(') return FALSE;
	return TRUE;
}	


/* isstrvar(string-position)
 * (IS a STRing VAR)
 * System function for the DIM management 
 * Note: the figure var() is trated as a var name (used in sub arguments) */
int isstrvar(char *lp) {
	if (!isbeginnamechar(lp)) return FALSE;
	while (isnamechar(lp)) lp++;
	if (*lp!='$') return FALSE;
	else lp++;
	if (*lp=='(' && *(lp+1)==')') return TRUE;
	if (*lp!='(') return TRUE;
	return FALSE;
}	


/* isnumvar(string-position)
 * (IS a NUMeric VAR)
 * System function for the DIM management 
 * Note: the figure var() is trated as a var name (used in sub arguments) */
int isnumvar(char *lp) {
	if (!isbeginnamechar(lp)) return FALSE;
	while (isnamechar(lp)) lp++;
	if (*lp=='$') return FALSE;
	if (*lp=='(' && *(lp+1)==')') return TRUE;
	return TRUE;
}	


/* dimArray(matrix-index,type,rows-number,columns-number)
 * dimension a numerical array allocating the necessary memory space.
 * var: the index of the variable holding the matrix name
 * T: matrix type, 1 for unidimensional vectors, 2 for matrices
 * M: the row number (=0 for one rows matrices)
 * N: the column number (=0 for vectors and one columns matrices)
 * Note: the one-dimensional vector is supposed to be vertical (one column).
 * Note: controls over M&N are supposed to happen elsewhere.
 * Note: all elements of declared array elements are set to 0.0 = zero. 
 * System function for the DIM management */
int dimArray(int var, int T, int M, int N) {
	int i,j;
	int size1=sizeof(double)*((M+1)*2+1);
	int size2=sizeof(double)*((M+1)*(N+1)+1);
	dim[var].brow  = M;
	dim[var].bcol  = N;
	dim[var].row   = M;
	dim[var].col   = N;
	dim[var].type  = T;

	/* reserve memory space for the array */
	if (dim[var].elem!=NIL) {
		free(dim[var].elem);
		dim[var].elem=NIL;
	}
	if (T==1) dim[var].elem=xmalloc((size_t)size1);  
	else if (T==2) dim[var].elem=xmalloc((size_t)size2);
	else  return 35;
	if (!dim[var].elem) return 190;

	/* erase all array elements */
	if (1==T) for(i=0;i<M+1;i++) {
		setArrayValFast(var,T,i,0,0);
	}
	else for(i=0;i<M+1;i++) for(j=0;j<N+1;j++) {
		setArrayValFast(var,T,i,j,0);
	}
	return 0;
}	


/* setArrayValFast(matrix-index,type,row-position,column-position,value)
 * a subset of setArrayVal() for fast assignments 
 * System function for the dimArray function to override the BASE */
void setArrayValFast(int var, int t, int m, int n, double val){
	/* vectors */
	if (m>0 && !n && t==1) *(dim[var].elem+(dim[var].col+1)*m)=val;
	/* horizontal vectors */
	else if (!m && n>0 && t==1) *(dim[var].elem+n)=val;
	/* matrix identified by one column A(I) = A(0,I) */
	else if (!m && n>0 && t==2) *(dim[var].elem+n)=val;
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) *(dim[var].elem+(dim[var].col+1)*m+n)=val;
}


/* setArrayStrFast(matrix-index,type,row-position,column-position,value)
 * a subset of setArrayStr() for fast assignments 
 * System function for the dimArray function to override the BASE */
void setArrayStrFast(int var, int t, int m, int n, char* str){
	/* vectors */
	if (m>0 && !n && t==1) strncpy_(dimS[var].elem+(dimS[var].col+1)*m*COMPSTR,str,COMPSTR);
	/* horizontal vectors */
	else if (!m && n>0 && t==1) strncpy_(dimS[var].elem+n*COMPSTR,str,COMPSTR);
	/* matrix identified by one column A(I) = A(0,I) */
	else if (!m && n>0 && t==2) strncpy_(dimS[var].elem+n*COMPSTR,str,COMPSTR);
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) strncpy_(dimS[var].elem+(n+(dimS[var].col+1)*m)*COMPSTR,str,COMPSTR);
}


/* getArrayVal(matrix-index,type,row-position,column-position)
 * get value of an element of a numerical array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * T: matrix type, 1 for unidimensional vectors, 2 for matrices
 * M: the row number (=0 for one rows matrices)
 * N: the column number (=0 for vectors and one columns matrices)
 * Note: a two dimensional array may be referenced using the first subscript;
 * Note: the second subscript defaults to zero for DIM and to one for MAT.
 * System function for the DIM management */
double getArrayVal(int var, int t, int m, int n) {
	/* check BASE validity */
	if (t==1) {
	       if (m<BASE) perror_(__LINE__,108,l);
	}
	else if (t==2 && !m && n) {
		if (n<BASE) perror_(__LINE__,108,l);
	}
	else if (m<BASE || n<BASE) perror_(__LINE__,108,l);
	/* trivial case of A(0,0) */
	if (!m && !n) {
		if (!dim[var].type) dimArray(var,2,10,10);
		return *(dim[var].elem);
	}
	/* vectors */
	else if (m>0 && !n && t==1) {
		if (m<=10 && 0==dim[var].type) dimArray(var,1,10,0);
		if (m>dim[var].row) perror_(__LINE__,76,l);
		return *(dim[var].elem+m);
	}
	/* horizontal vectors */
	else if (!m && n>0 && t==1) {
		if (n<=10 && 0==dim[var].type) dimArray(var,1,0,10);
		if (n>dim[var].col) perror_(__LINE__,76,l);
		return *(dim[var].elem+n);
	}
	/* matrix identified by one column A(I) = A(0,I) - first row */
	else if (!m && n>0 && t==2) {
		if (n<=10 && 0==dim[var].type) dimArray(var,2,10,10);
		if (n>dim[var].col) perror_(__LINE__,76,l);
		return *(dim[var].elem+n);
	}
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) {
		if (m<=10 && 0==dim[var].row && n<=10 && dim[var].col==0)       
			dimArray(var,2,10,10);
		if (m>dim[var].row || n>dim[var].col) perror_(__LINE__,76,l);
		return *(dim[var].elem+(dim[var].col+1)*m+n); 
	}
	else perror_(__LINE__,76,l);
	return 0;
}


/* setArrayVal(matrix-index,type,row-position,column-position,value)
 * set an element of a numerical array to a specific value, given the value 
 * itself and the element coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices
 * m: the row number (=0 for one rows matrices)
 * n: the column number (=0 for vectors and one columns matrices)
 * val: the double value to be stored.
 * Note: a two dimensional array may be referenced using the first subscript;
 * Note: the second subscript defaults to zero  for DIM and to one for MAT.
 * System function for the DIM management */
void setArrayVal(int var, int t, int m, int n, double val){
	/* set integer value if the case */
	if (vn[var].isInt) val=(int)val;
	/* check BASE validity */
	if (t==1) {
	       if (m<BASE) perror_(__LINE__,108,l);
	}
	else if (t==2 && !m && n) {
		if (n<BASE) perror_(__LINE__,108,l);
	}
	else if (m<BASE || n<BASE) perror_(__LINE__,108,l);
	/* trivial case of A(0,0) */
	if (!m && !n) {
		if (!dim[var].type) dimArray(var,2,10,10);
		*(dim[var].elem)=val;
	}
	/* vectors */
	else if (m>0 && !n && t==1) {
		if (m<=10 && 0==dim[var].type) dimArray(var,1,10,0);
		if (m>dim[var].row) perror_(__LINE__,76,l);
		*(dim[var].elem+m)=val;
	}
	/* horizontal vectors */
	else if (!m && n>0 && t==1) {
		if (n<=10 && 0==dim[var].type) dimArray(var,1,0,10);
		if (n>dim[var].col) perror_(__LINE__,76,l);
		*(dim[var].elem+n)=val;
	}
	/* matrix identified by one column A(I) = A(0,I) - first row */
	else if (!m && n>0 && t==2) {
		if (n<=10 && 0==dim[var].type) dimArray(var,2,10,10);
		if (n>dim[var].col) perror_(__LINE__,76,l);
		*(dim[var].elem+n)=val;
	}
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) {
		if (m<=10 && 0==dim[var].row && n<=10 && dim[var].col==0) 
			dimArray(var,2,10,10);
		if (m>dim[var].row || n>dim[var].col) perror_(__LINE__,76,l);
		*(dim[var].elem+(dim[var].col+1)*m+n)=val;
	}
	else perror_(__LINE__,76,l);
}


/* dimStrArray(matrix-index,type,rows-number,columns-number)
 * dimension a string array, allocating the necessary memory space; 
 * var: the index of the variable holding the matrix name
 * T: the matrix type, 1 for unidimensional vectors, 2 for matrices
 * M: the row number (=0 for one rows matrices)
 * N: the column number (=0 for vectors and one columns matrices)
 * Note: the one-dimensional vector is supposed to be vertical (one column).
 * Note: controls over M&N are supposed to happen elsewhere 
 * Note: all elements of declared array are set to the void string.
 * System function for the DIM management */
int dimStrArray(int var, int T, int M, int N) {
	int i,j;
	int size1=sizeof(char)*((M+1)*COMPSTR+1);
	int size2=sizeof(char)*((M+1)*(N+1)*COMPSTR+1);
	dimS[var].brow = M;
	dimS[var].row  = M;
	dimS[var].bcol = N;
	dimS[var].col  = N;
	dimS[var].type = T;
	
	/* reserve memory space for the array */
	if (dimS[var].elem!=NIL) {
		free(dimS[var].elem);
		dimS[var].elem=NIL;
	}
	if (T==1) dimS[var].elem=xmalloc((size_t)size1);  
	else if (T==2) dimS[var].elem=xmalloc((size_t)size2);
	else return 35; 
	if (!dimS[var].elem) return 190;;

	/* erase all array elements */
	if (1==T) for(i=0;i<M+1;i++) {
		setArrayStrFast(var,T,i,0,"");
	}
	else for(i=0;i<M+1;i++) for(j=0;j<N+1;j++) {
		setArrayStrFast(var,T,i,j,"");
	}
	return 0;
}		

/* getArrayStr(matrix-index,type,row-position,column-position)
 * get value of an element of a string array, given its coordinates.
 * var: the index of the variable holding the matrix name
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices 
 * m: the row number (=0 for one rows matrices)
 * n: the column number (always 0)
 * System function for the DIM management */
char* getArrayStr(int var, int t, int m, int n) {
	/* check BASE validity */
	if (t==1) {
	       if (m<BASE) perror_(__LINE__,108,l);
	}
	else if (t==2 && !m && n) {
		if (n<BASE) perror_(__LINE__,108,l);
	}
	else if (m<BASE || n<BASE) perror_(__LINE__,108,l);
	/* trivial case of A$(0,0) */
	if (!m && !n) {
		if (!dimS[var].type) dimStrArray(var,2,10,10);
		return dimS[var].elem;
	}
	/* vectors */
	else if (m>0 && !n && t==1) {
		if (m<=10 && 0==dimS[var].type) dimStrArray(var,1,10,0);
		if (m>dimS[var].row) perror_(__LINE__,76,l);
		return dimS[var].elem+m*COMPSTR;
	}
	/* horizontal vectors */
	else if (!m && n>0 && t==1) {
		if (n<=10 && 0==dimS[var].type) dimStrArray(var,1,0,10);
		if (n>dimS[var].col) perror_(__LINE__,76,l);
		return dimS[var].elem+n*COMPSTR;
	}
	/* matrix identified by one column A(I) = A(0,I) - first row */
	else if (!m && n>0 && t==2) {
		if (n<=10 && 0==dimS[var].type) dimStrArray(var,2,10,10);
		if (n>dimS[var].col) perror_(__LINE__,76,l);
		return dimS[var].elem+n*COMPSTR;
	}
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) {
		if (m<=10 && 0==dimS[var].row && n<=10 && dimS[var].col==0)
			dimStrArray(var,2,10,10);
		if (m>dimS[var].row || n>dimS[var].col) perror_(__LINE__,76,l);
		return dimS[var].elem+(n+(dimS[var].col+1)*m)*COMPSTR; 
	}
	else perror_(__LINE__,76,l);
	return NULLSTR;
}


/* setArrayStr(matrix-index,type,row-position,column-position,value)
 * set an element of a string array to a specific value, given the value itself 
 * and the element coordinates 
 * Parameter n is not used, since string matrices are not yet implemented;
 * var: the index of the variable holding the matrix name
 * t: matrix type, 1 for unidimensional vectors, 2 for matrices 
 * m: the row number (=0 for one rows matrices)
 * n: the column number (always 0)
 * System function for the DIM management */
void setArrayStr(int var, int t, int m, int n, char *str){
	/* check BASE validity */
	if (t==1) {
	       if (m<BASE) perror_(__LINE__,108,l);
	}
	else if (t==2 && !m && n) {
		if (n<BASE) perror_(__LINE__,108,l);
	}
	else if (m<BASE || n<BASE) perror_(__LINE__,108,l);
	/* trivial case of A$(0,0) */
	if (!m && !n) {
		if (!dimS[var].type) dimStrArray(var,2,10,10);
		strncpy_(dimS[var].elem,str,COMPSTR);
	}
	/* vectors */
	else if (m>0 && !n && t==1) {
		if (m<=10 && 0==dimS[var].type) dimStrArray(var,1,10,0);
		if (m>dimS[var].row) perror_(__LINE__,76,l);
		strncpy_(dimS[var].elem+m*COMPSTR,str,COMPSTR);
	}
	/* horizontal vectors */
	else if (!m && n>0 && t==1) {
		if (n<=10 && 0==dimS[var].type) dimStrArray(var,1,0,10);
		if (n>dimS[var].col) perror_(__LINE__,76,l);
		strncpy_(dimS[var].elem+n*COMPSTR,str,COMPSTR);
	}
	/* matrix identified by one column A(I) = A(0,I) - first row */
	else if (!m && n>0 && t==2) {
		if (n<=10 && 0==dimS[var].type) dimStrArray(var,2,10,10);
		if (n>dimS[var].col) perror_(__LINE__,76,l);
		strncpy_(dimS[var].elem+n*COMPSTR,str,COMPSTR);
	}
	/* regular matrix */
	else if (m>0 && n>=0 && t==2) {
		if (m<=10 && 0==dimS[var].row && n<=10 && dimS[var].col==0) 
			dimStrArray(var,2,10,10);
		if (m>dimS[var].row || n>dimS[var].col) perror_(__LINE__,76,l);
		strncpy_(dimS[var].elem+(n+(dimS[var].col+1)*m)*COMPSTR,str,COMPSTR);
	}
}


/* getBound()
 * return the lowest or the upper bound of array in argument.
 * The request is in the form L/UBOUND(V[,N]), where V is the array name and
 * N (optional) is the dimension. If omitted, dimension 1 is considered;
 * At present, N may be 1 or 2; if different, an error message is shown
 * if mode = TRUE search for UBOUND (upper bound)
 * if mode = FALSE, search for LBOUND (lower bound = BASE).
 * The array is identified by its letters, if () is reported, it is skipped
 * system function for the LBOUND and UBOUND functions */
int getBound(int mode) {
	int lb=BASE, ub=0,cs=0;
	int var=0, alt=1;
	int number=TRUE;	// if false, it is a string array

	/* get array name */
	forceArray=TRUE;
	cs=findDEC(p);
	if (cs && _rettype==NUM && _arr) 
		var=cs, p+=_len;
	else if (cs && _rettype==STR && _arr) 
		var=cs,p+=_len,number=FALSE;
	else perror_(__LINE__,42,l);
	forceArray=FALSE;
	if (*p=='(' && *(p+1)==')') p+=2;
	/* dimension index is explicit */
	if (*p==',') {
		p++;
		alt=(int)S();
		if (alt<1 || alt>2) perror_(__LINE__,148,l);
	}

	/* LBOUND returns always BASE */
	if (!mode) return lb;

	/* return number UBOUND */
	if (number) {
		if (alt==1) ub=dim[var].row;
		else ub=dim[var].col;
	}
	/* return string UBOUND */
	else  {
		if (alt==1) ub=dimS[var].row;
		else ub=dimS[var].col;
	}
	return ub;
}


/* getRandom()
 * return a pseudo-random number, called by the RND function.
 * The algorithm is the following:
 *  1. randSeed and randDivi at start are respectively 7139 and 32768
 *  2. divide randSeed by randDivi, and get the decimals part, from third digit
 *     to obtain a number greater than 0 (excluded) and lower than 1 (excluded) 
 *     as the generated random number (0.217864990 -> 0.7864990)
 *  3. the first five decimals of this number are taken as the new randSeed for 
 *     the next iteration (randSeed=21787)
 *  4. proceed from step 2.
 * Note: to reduce the risk of circular ranges I add two variables, varying
 * continuously: 'fix' that alters randSeed and div that alters randDivi; to
 * reduce also the risk of having 'exact' divisions (like 0.250000, which is 
 * 'unfair' as random number) randSeed is always odd, randDivi is even.
 * Note: This algorithm, after a variable length list of generated numbers, 
 * falls into a cycle, whose length is exactly 8532532; the start of the cycle
 * is variable, and depends on the initial values for randSeed and randDivi.
 * Note: the values of 27268 and 32767 for the starting values of randSeed and
 * randDivi were chosen to return as the first random number the same first
 * random number generated by the DEC-BASIC
 * System function for the pseudo-random number generation management */
double getRandom(void) {
	static double fix=0.3; // variable randSeed part
	static double div=0.1; // variable randDivi part
	double o=100.0*randSeed/randDivi;

	/* take fractional part of the division of randSeed by randDivi
	 * (take digits from 3rd to 8th position) */
	o-=(int)o;

	/* update randSeed */
	randSeed=(unsigned int)((o*1E5)+fix);
	if (randSeed<1E3) randSeed=27268;  
	if (!randSeed%2) randSeed++;

	/* update randDivi */
	randDivi=(unsigned int)((randDivi*randSeed)%0xFFFFF+div);
	if (randDivi<1E3) randDivi=32767; 
	if (randDivi%2) randDivi++;

	/* update variable parts */
	div+=3.0; if (div>499) div=-997;
	fix+=167.0; if (fix>4999) fix=0;

	/* ensure limits are respected (see previous note) */
	if (o<ZERO||o>=1.0) return getRandom(); // discard also neg. numbers
	return o;
}


/* isARing()
 * check if GOSUB is calling an address that is the GOSUB chain; if so,
 * the subroutine is calling itself
 * System function used into GOSUB() */
int isARing(int num) {
	int i=0;
	
	while (i<=gosubTOS) {
		if (gosubStack[i]==num) return TRUE;
		i++;
	}
	return FALSE;
}


/* isSingleDEF()
 * check if the DEF function starting at d is a single line DEF (return SINGLE)
 * a multiline DEF (return MULTI) or a function with bugs (return FALSE) 
 * d: points to the characters after DEF (which must be 'FN')  
 * System function for the DEFFN management */
int isSingleDEF(char* d) {
	/* FN */
	if (!strncasecmp_(d,"FN",2)) d+=2;
	/* XX - error */
	else return FALSE;
	/* FNA */
	if (isalpha(*d)) d++;
	/* FN_ - error */
	else return FALSE;
	/* FNA (multi line introduction) with no arguments */
	if (!*d) return MULTI;
	/* FNA( */
	else if (*d=='(') d++;
	/* FNA= (no arguments) */
	else if (*d=='=') return SINGLE;
	/* FNA_ - error */
	else return FALSE;
	/* FNA(.... */
	while (*d && *d!=')') d++;
	/* FNA(....) */
	if (*d==')') d++;
	/* FNA(... - error */
	else return FALSE;
	/* FNA(....)= */
	if (*d=='=') return SINGLE;
	/* FNA(....) */
	else return MULTI;
}


/* calcDEF() 
 * calculates the DEF FN result for a single/multi line DEF FNF; 
 * data relative to DEF FN functions must have been preprocessed by preParse(),
 * In order for calcDEF to run.
 * the double result of DEF calculation will be store in calcres
 * p points to the character after FN, which contains the function index.
 * Return the updated position of p
 * System function for the DEFFN management */
char *calcDEF(void) {
	char *pb;
	int defn=*p++, type, i, lb;
	int fmb[MEMLIMIT], cnt=0, decCountBack=decCount;
	int isVarBack, isRunBack, isDefCalcBack, ic, isArr=FALSE;
	static int stackLim;
	double nvalue[fn[defn].vars[0]+1];
	char svalue[fn[defn].vars[0]+1][COMPSTR];

	/* control self calling subroutine
	 * Note: the control is done this way:
	 * 1. store information about current DEF FN only if it differs;
	 *    this enables writing recursion functions; 
	 * 2. the recursion is limited to STACKLIMIT jumps;
	 * 3. search until previous position;
	 *    this avoids calling error in case of recursion, but detects
	 *    circular calls (FNA calling FNB calling FNA) */
	if (!FNXTOS || FNXlist[FNXTOS]!=defn) 
		FNXlist[++FNXTOS]=defn, stackLim=0;
	else stackLim++; 
	if (stackLim>STACKLIM) perror_(__LINE__,187,l);
	for (i=1;i<FNXTOS-1;i++) {
		if (FNXlist[i]==defn) perror_(__LINE__,126,l);
	}

	/* get type (SINGLE/MULTI) */
	type=fn[defn].type;
	
	/* backup masking line state to enable execution of DEF */
	for (i=fn[defn].start;i<=fn[defn].end;i++) fmb[i]=fm[i],fm[i]=FALSE;
	
	/* if there are arguments get their value them */
	if (*p=='(')  {
		cnt=0;
		ic=1;
		++p; // skip '('
		/* cycle through DEF arguments and get values to be used; 
		 * cnt holds number of arguments of called proc, stored by 
		 * DEF() in fn[defn].vars[0] list (which must be respected) */
		while (cnt < fn[defn].vars[0]) {
			cnt++;
			/* DEC variable */
			if (fn[defn].vars[ic]>=DECADD) {
				int rettype=0;
				ic++; // skip DECADD
				while (fn[defn].vars[ic]>=0) ic++;
				ic++;
				rettype=fn[defn].vars[ic]-DECADD;
				/* DEC numeric variable */
				if (rettype==NUMINT || rettype==NUM) {
					if (isanystring(p)) 
						perror_(__LINE__,215,l);
					nvalue[cnt]=S();
				}
				/* DEC string variable */
				else if (rettype==STR) {
					if (!isanystring(p)) 
						perror_(__LINE__,214,l);
					strncpy_(svalue[cnt],SS(),COMPSTR);
				}
			}
			else perror_(__LINE__,119,l);
			if (*p==',') p++;
		}
		if (*p!=')') {
			perror_(__LINE__,43,l);
			return p;
		}
	}
	
	/* wrong number of arguments */
	if (fn[defn].vars[0]!=cnt) {
		perror_(__LINE__,43,l);
		return p;
	}

	/* instantiate DEC variables with gotten values */
	cnt=0; ic=1;
	while (cnt < fn[defn].vars[0]) {
		int rettype=0, namelen=0;
		char name[COMPSTR], *np=name;
		cnt++;
		ic++; // skip DECADD
		/* store name until -1 */
		while (fn[defn].vars[ic]>=0)
			*np++=fn[defn].vars[ic++];
		*np='\0'; ic++; // skip -1
		rettype=fn[defn].vars[ic]-DECADD;
		ic++; // skip DECADD + ret
		decCount++;
		if (decCount>=VLIMIT) perror_(__LINE__,169,l);
		vn[decCount].isArr=isArr;
		if (rettype==NUMINT) {
			strncpy(PS[decCount],"",COMPSTR);
			P[decCount]=(int)nvalue[cnt];
			vn[decCount].rettype=NUM;
			vn[decCount].isInt=TRUE;
		}
		else if (rettype==NUM) {
			strncpy(PS[decCount],"",COMPSTR);
			P[decCount]=nvalue[cnt];
			vn[decCount].rettype=NUM;
			vn[decCount].isInt=FALSE;
		}
		else {
			strncpy(PS[decCount],svalue[cnt],COMPSTR);
			P[decCount]=0.0;
			vn[decCount].rettype=STR;
			vn[decCount].isInt=FALSE;
		}
		vn[decCount].isCommon=FALSE;
		namelen=strlen(name)+1;
		if (vn[decCount].name!=NIL) {
			free(vn[decCount].name);
			vn[decCount].name=NIL;
		}
		vn[decCount].name=xmalloc((size_t)namelen);
		if (!vn[decCount].name) 
			perror_(__LINE__,173,l);
		else strncpy_(vn[decCount].name,name,namelen);
		/* debug feature */
		if (isDebug) showDEC(decCount, FALSE);
	}
	
	/* calculate a single line DEF */
	if (type==SINGLE) {
		pb=p; 
		p=fn[defn].def;
		calcres=S(); 
		p=pb; 
	}
	/* calculate a multi line DEF */
	else {
		/* execute lines */
		pb=p; lb=l;
		isRunBack=isDefRun; isDefRun=TRUE;
		isVarBack=isDefVar; isDefVar=defn;
		isDefCalcBack=isDefCalc;
		pushRUN();
		parse(m,fn[defn].start,fn[defn].end);
		popRUN();
		isDefVar=isVarBack;
		isDefRun=isRunBack;
		/* there's no error message for cases in which
		 * LET FNF= is not used within a multiline DEF */
		if (!isDefCalc) calcres=0.0;
		else calcres=fn[defn].res;
		isDefCalc=isDefCalcBack;
		p=pb; l=lb;
	}

	/* restore masking lines state and make DEF invisible again */
	for (i=fn[defn].start;i<=fn[defn].end;i++) fm[i]=fmb[i];
	
	/* update counter for circular calling check */
	FNXTOS--;
	decCount=decCountBack;
	
	return p;
}


/* findSUB() 
 * find SUB in current parsing line, among SUBs found by preParse()
 * p points to the SUB name in getFunc(), exec() or SS() 
 * return in p2 updated position of p (just after the proc name), unless
 *    p2 is NIL
 * store in type and rettype relative values for an immediate check 
 * System function for the SUB management */
int findSUB(char *p, char **p2, int *type, int *rettype) {
	int i=subCount,isStr;
	char name[COMPSTR], *n=name;
	/* get SUB name */
	isStr=FALSE;
	while (isnamechar(p)) *n++=*p++;
	if (*p=='$') *n++=*p++,isStr=TRUE;
	*n='\0'; 

	/* return immediately if it's last call */
	if (!strcmp(rememberName,name)) {
		if (p2) *p2=p;
		*type=sn[rememberCode].type;
		*rettype=sn[rememberCode].rettype;
		return rememberCode;
	}

	/*  find SUB */
	while (i>0) {
		if (sn[i].name[0]) {
			if (!strcasecmp(sn[i].name,name)) {
				*type=sn[i].type;
				*rettype=sn[i].rettype;
				if (p2) *p2=p;
				if (*type==FUNC && *rettype==NUM && isStr) {
					i++;
					continue;
				}
				strncpy_(rememberName,sn[i].name,COMPSTR);
				rememberCode=i;
				return i;
			}
		}
		i--;
	}
	/* restore p: SUB not found */
	if (p2) *p2=p;
	return FALSE;
}


/* execSUB() 
 * execute a subroutine; 
 * data relative to the SUB are preprocessed by preParse(), in order for 
 * execSUB to run.
 * subn: the sub number found by findSUB()
 * pc: the position in the incoming string where arguments (if any) are stored,
 *    pointing to the character after SUB name. pc is used local, instead of
 *    global p, because execSUB() is supposed to execute any type of string
 * numres: the double result pointer
 * strres; the string result pointer
 * return the updated position of pc in pc
 * System function for the SUB management */
char* execSUB(int subn, char*pc, double *numres, char* strres) {
	char *pb, subname[COMPSTR];
	int i,isSubVarBack,isSubCalcBack,isSubRunBack;
	int fmb[MEMLIMIT], cnt, ic, isArr=FALSE;
	double nvalue[sn[subn].vars[0]+1];
	char svalue[sn[subn].vars[0]+1][COMPSTR];
	int arrvalue[sn[subn].vars[0]+1];
	int inttype[sn[subn].vars[0]+1];

	/* SUB does not exist */
	if (!sn[subn].number) {
		perror_(__LINE__,212,l);
		return pc;
	}

	/* increase the SUB state */
	currentExecSub=subn;
	XCount++; // first call in main sets it to 1
	if (XCount>SUBSTACKLIM) {
		perror_(__LINE__,187,l);
		return pc;
	}

	/* backup SUB cycle and decisional structures */
	subBackup[XCount].ifTOS=ifTOS;
	subBackup[XCount].selectTOS=selectTOS;
	subBackup[XCount].selectcount=selectcount;
	subBackup[XCount].whileTOS=whileTOS;
	subBackup[XCount].whilecount=whilecount;
	subBackup[XCount].doTOS=doTOS;
	subBackup[XCount].docount=docount;
	subBackup[XCount].forTOS=forTOS;
	subBackup[XCount].forcount=forcount;
	saveSubCount[XCount]=decCount;

	/* set subroutine name */
	if (sn[subn].name[0]) strncpy_(subname,sn[subn].name,COMPSTR);
	else strncpy_(subname,"obj.",COMPSTR);

	/* backup masking lines state to enable execution of SUB */
	for (i=sn[subn].start;i<=sn[subn].end;i++) fmb[i]=fm[i],fm[i]=FALSE;
	
	/* if there are arguments, get their value 
	 * (it works even in case of the () figure */
	if (*pc=='(')  {
		cnt=0;
		ic=1;
		++pc; // skip '('
		/* cycle through SUB arguments and get values to be used; 
		 * cnt holds number of arguments of called proc, stored by 
		 * SUB() in sn[subn].vars[0] list (which must be respected) 
		 * NOTE: if you think that cnt is not a proper name,
		 * it's none of your business... ;-) I like it :-0 */
		while (cnt < sn[subn].vars[0]) {
			cnt++;
			/* DEC variable/array */
			if (sn[subn].vars[ic]>=DECADD) {
				int rettype=0;
				int ns=0, varOnly=FALSE;
				int kk=decCount;
				ic++;
				while (sn[subn].vars[ic]>=0) ic++;
				ic++; // skip -1
				rettype=sn[subn].vars[ic]-DECADD;
				/* search for a specific array */
				if (rettype>STRNUMARR) {
					rettype-=STRNUMARR;	
					while (kk>0) {
						ns=searchDEC(pc,kk);
						if (ns && _arr) {
							break;
						}
						kk--;
					}
					/* set anyway as array even not found*/
					if (!ns) {
						ns=-1;
						_arr=TRUE;
					}
				}
				/* or for any variable */
				else ns=searchDEC(pc,decCount);
				/* decide if it's an expression or not */
				if (*(pc+_len)==',' || *(pc+_len)==')') 
					varOnly=TRUE;
				arrvalue[cnt]=0; // default value
				/* DEC array passed 
				 * Note: the type is not considered here
				 * because the actual copy is done
				 * during variable instantiation */ 
				if (ns && _arr && varOnly) {
					arrvalue[cnt]=ns;
					if (ns && vn[ns].isInt) {
						inttype[cnt]=NUMINT;
					}
					pc+=_len;
				}
				/* DEC string variable passed */
				else if (ns&&!_arr&&rettype==STR&&varOnly) {
					strncpy_(svalue[cnt],PS[ns],COMPSTR);
					inttype[cnt]=0;
					pc+=_len;
				}
				/* DEC numeric variable passed */
				else if (ns && !_arr && varOnly) {
					if (vn[ns].isInt) {
						nvalue[cnt]=(int)P[ns];
						inttype[cnt]=NUMINT;
					}
					else {
						nvalue[cnt]=P[ns];
						inttype[cnt]=0;
					}
					pc+=_len;
				}
				/* DEC numeric expression passed */
				else if ((rettype==NUMINT||rettype==NUM)){
					char *pb=p;
					if (isanystring(pc)) {
						perror_(__LINE__,215,l);
						return pc;
					}
					/* look for the integer type of any
					 * passed integer variable, if any */
					if (ns && vn[ns].isInt)
						inttype[cnt]=NUMINT;
					else inttype[cnt]=0;
					p=pc;
					nvalue[cnt]=S();
					pc=p;
					p=pb;
				}
				/* DEC string expression passed */
				else if (rettype==STR) {
					char *pb=p;
					if (!isanystring(pc)) { 
						perror_(__LINE__,214,l);
						return pc;
					}
					p=pc;
					strncpy_(svalue[cnt],SS(),COMPSTR);
					pc=p;
					p=pb;
					inttype[cnt]=0;
				}
			}
			/* anything else is not admitted */
			else {
				perror_(__LINE__,119,l);
				return pc;
			}
			/* go for next */
			if (*pc==',') pc++;
		}
		/* check syntax */
		if (*pc!=')') {
			perror_(__LINE__,43,l);
			return pc;
		}
	}
				
	/* wrong number of arguments */
	if (sn[subn].vars[0]!=cnt) {
		perror_(__LINE__,43,l);
		return pc;
	}

	/* instantiate DEC variables with gotten values 
	 * and arrays basing on the ns reference */
	cnt=0; ic=1;
	while (cnt < sn[subn].vars[0]) {
		int rettype=0, namelen=0;
		char name[COMPSTR], *np=name;
		cnt++;
		ic++; // skip DECADD
		/* save isArr value (= ns) */
		isArr=!(!arrvalue[cnt]);
		/* store name until -1 */
		while (sn[subn].vars[ic]>=0)
			*np++=sn[subn].vars[ic++];
		*np='\0'; ic++; // skip -1
		rettype=sn[subn].vars[ic]-DECADD;
		if (rettype>STRNUMARR) rettype-=STRNUMARR;
		ic++; // skip DECADD + ret
		decCount++;
		if (decCount>=VLIMIT) {
			perror_(__LINE__,169,l);
			return pc;
		}
		vn[decCount].isArr=isArr;
		/* copy integer numeric array */
		if (arrvalue[cnt] && (rettype==NUMINT||inttype[cnt]==NUMINT)){
			int i,j,t;
			int ns=arrvalue[cnt];
			strncpy(PS[decCount],"",COMPSTR);
			vn[decCount].rettype=NUM;
			vn[decCount].isInt=TRUE;
			if (ns>0) {
				dimArray(decCount,dim[ns].type,dim[ns].row,dim[ns].col);
				t=dim[decCount].type;
				for (i=0;i<=dim[ns].row;i++)
					for (j=0;j<dim[ns].row;j++)
						setArrayVal(decCount,t,i,j,(int)getArrayVal(ns,t,i,j));
			}
			else {
				dimArray(decCount,2,10,10);
			}
		}
		/* copy numeric array */
		else if (arrvalue[cnt] && (rettype==NUM||inttype[cnt]==NUM)) {
			int i,j,t;
			int ns=arrvalue[cnt];
			strncpy(PS[decCount],"",COMPSTR);
			vn[decCount].rettype=NUM;
			vn[decCount].isInt=FALSE;
			if (ns>0) {
				dimArray(decCount,dim[ns].type,dim[ns].row,dim[ns].col);
				t=dim[decCount].type;
				for (i=0;i<=dim[ns].row;i++)
					for (j=0;j<dim[ns].row;j++)
						setArrayVal(decCount,t,i,j,getArrayVal(ns,t,i,j));
			}
			else {
				dimArray(decCount,2,10,10);
			}
		}
		/* copy string array */
		else if (arrvalue[cnt] && rettype==STR) {
			int i,j,t;
			int ns=arrvalue[cnt];
			P[decCount]=0.0;
			vn[decCount].rettype=STR;
			vn[decCount].isInt=FALSE;
			if (ns>0) {
				dimStrArray(decCount,dimS[ns].type,dimS[ns].row,dimS[ns].col);
				t=dimS[decCount].type;
				for (i=0;i<=dimS[ns].row;i++)
					for (j=0;j<dimS[ns].row;j++)
						setArrayStr(decCount,t,i,j,getArrayStr(ns,t,i,j));
			}
			else {
				dimStrArray(decCount,2,10,10);
			}
		}
		/* copy numeric integer variables */
		else if (rettype==NUMINT || inttype[cnt]==NUMINT) {
			strncpy(PS[decCount],"",COMPSTR);
			P[decCount]=(int)nvalue[cnt];
			vn[decCount].rettype=NUM;
			vn[decCount].isInt=TRUE;
		}
		/* copy numeric variables */
		else if (rettype==NUM) {
			strncpy(PS[decCount],"",COMPSTR);
			P[decCount]=nvalue[cnt];
			vn[decCount].rettype=NUM;
			vn[decCount].isInt=FALSE;
		}
		/* copy string variables */
		else {
			strncpy(PS[decCount],svalue[cnt],COMPSTR);
			P[decCount]=0.0;
			vn[decCount].rettype=STR;
			vn[decCount].isInt=FALSE;
		}
		/* setup some common parameters */
		vn[decCount].isCommon=FALSE;
		namelen=strlen(name)+1;
		if (vn[decCount].name!=NIL) {
			free(vn[decCount].name);
			vn[decCount].name=NIL;
		}
		/* setup var name */
		vn[decCount].name=xmalloc((size_t)namelen);
		if (!vn[decCount].name) {
			perror_(__LINE__,173,l);
			return pc;
		}
		else strncpy_(vn[decCount].name,name,namelen);
		/* debug feature */
		if (isDebug) showDEC(decCount, FALSE);
	}

	/* setup for execution of SUB lines */
	pb=pc;
	isSubRunBack=isSubRun; isSubRun=TRUE;
	isSubVarBack=isSubVar; isSubVar=subn;
	isSubCalcBack=isSubCalc;
	/* execute SUB lines */
	pushRUN();
	parse(m,sn[subn].start,sn[subn].end);
	popRUN();
	/* restore */
	isSubVar=isSubVarBack;
	isSubRun=isSubRunBack;
	/* there's no error message for cases in which
	 * RETURN is not called within a SUB stored as function */
	if (sn[subn].type==FUNC) {
	       if (!isSubCalc && sn[subn].rettype==NUM) *numres=0.0;
	       else if (!isSubCalc && sn[subn].rettype==STR) 
		       strncpy_(strres,"",COMPSTR);
	       else if (isSubCalc && sn[subn].rettype==NUM) 
		       *numres=sn[subn].numres;
	       else if (isSubCalc && sn[subn].rettype==STR) 
		       strncpy_(strres,sn[subn].strres,COMPSTR);
	}
	isSubCalc=isSubCalcBack;
	pc=pb;
	
	/* restore masking lines state and make SUB invisible again */
	for (i=sn[subn].start;i<=sn[subn].end;i++) fm[i]=fmb[i];
	
	/* closing parenthesis is automatic for getFunc() and SS() 
	 * but not for functions, so close it here */
	if (sn[subn].type==PROC && *pc==')') pc++;

	/* restore variable index */
	decCount=saveSubCount[XCount];

	/* restore SUB cycle and decisional structures */
	ifTOS=subBackup[XCount].ifTOS;
	selectTOS=subBackup[XCount].selectTOS;
	selectcount=subBackup[XCount].selectcount;
	whileTOS=subBackup[XCount].whileTOS;
	whilecount=subBackup[XCount].whilecount;
	doTOS=subBackup[XCount].doTOS;
	docount=subBackup[XCount].docount;
	forTOS=subBackup[XCount].forTOS;
	forcount=subBackup[XCount].forcount;

	/* leave this SUB state */
	XCount--; // first call in main sets it to zero
	p=pc;
	return pc;
}


/* searchDEC()
 * find a DECLAREd variable/array in the vn[] struncture 
 * lp points to the DEC name in getFunc(), LET() or SS() and get its value;
 * term is the last decCount to be counter
 * store in _len the length of the variable name
 * store in _rettype relative values for an immediate check
 * store in _arr the array flag
 * System function for the execSUB management */
int searchDEC(char *lp, int term) {
	int i=term;
	char name[COMPSTR], *n=name;

	/* set anyway a valid value as a safety measure */	
	_len=0;
	_arr=0;
	_rettype=0;

	if (!*lp) return FALSE;
	if (!(isbeginnamechar(lp))) return FALSE;
	/* get DEC name */
	while (isnamechar(lp)) *n++=*lp++;
	if (*lp=='%' && *(lp+1)!='%') *n++=*lp++;
	else if (*lp=='%' && *(lp+1)=='%' && *(lp+2)=='%') 
		*n++=*lp++;
	else if (*lp=='$') *n++=*lp++;
	*n='\0';
	_len=(int)strlen(name);
	if (!_len || !name[0]) return FALSE;

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (vn[i].name!=NIL && !strcasecmp(vn[i].name,name)) {
			_rettype=vn[i].rettype;
			_arr=vn[i].isArr;
			return i;
		}
		i--;
	}
	return 0;
}


/* findDEC() 
 * find a DECLAREd variable/array in the vn[] structure;
 * lp points to the DEC name in getFunc(), LET() or SS() and get its value;
 * store in _len the length of the variable name
 * store in _rettype relative values for an immediate check
 * store in _arr the array flag
 * Instantiate the variable if not found and if not in EXPLICIT mode
 * System function for the DECLARE management */
int findDEC(char *lp) {
	int i=decCount, rr=NUM, ii=FALSE;
	char name[COMPSTR], *n=name;
	int lArray=FALSE;	// locally detection of arrays
	int found=FALSE;

	/* set anyway a valid value as a safety measure */	
	_len=0;
	_arr=0;
	_rettype=0;

	if (!*lp) return FALSE;
	if (!(isbeginnamechar(lp))) return FALSE;
	/* get DEC name */
	while (isnamechar(lp)) *n++=*lp++;
	if (*lp=='%' && *(lp+1)!='%') *n++=*lp++, ii=TRUE;
	else if (*lp=='%' && *(lp+1)=='%' && *(lp+2)=='%') 
		*n++=*lp++, ii=TRUE;
	else if (*lp=='$') *n++=*lp++, rr=STR;
	*n='\0';
	_len=(int)strlen(name);
	if (!_len || !name[0]) return FALSE;
	if (*lp=='(') lArray=TRUE;

	/*  find DEC and attribute values */
	while (i>0) {	// search all variables
		if (vn[i].name!=NIL && !strcasecmp(vn[i].name,name)) {
			if (!vn[i].isArr && !forceArray && !lArray)
				found=TRUE;
			else if (vn[i].isArr && lArray) 
				found=TRUE;
			else if (vn[i].isArr && !lArray && forceArray)
				found=TRUE;
			if (found) {
				_rettype=vn[i].rettype;
				_arr=vn[i].isArr;
				return i;
			}
		}
		found=FALSE;
		i--;
	}

	/* DEC not found: try to instantiate the variable */
	if (!isExplicit && *lp!='(' && !forceArray) {
		int namelen=0;
		decCount++;
		if (decCount>=VLIMIT) perror_(__LINE__,169,l);
		vn[decCount].isInt=ii;
		vn[decCount].rettype=_rettype=rr;
		vn[decCount].isArr=_arr=FALSE;
		vn[decCount].isConst=FALSE;
		vn[decCount].isCommon=FALSE;
		_len=(int)strlen(name);
		namelen=(_len+1)*sizeof(char);
		if (vn[decCount].name!=NIL) {
			free(vn[decCount].name);
			vn[decCount].name=NIL;
		}
		vn[decCount].name=xmalloc((size_t)namelen);
		if (!vn[decCount].name) perror_(__LINE__,173,l);
		else strncpy_(vn[decCount].name,name,namelen);
		P[decCount]=0.0;
		strncpy_(PS[decCount],"",COMPSTR);
		/* debug feature */
		if (isDebug) showDEC(decCount, FALSE);
		return decCount;
	}
	/* DEC not found: try to instantiate the array 
	 * Note: if forceArray is TRUE, the name comes from the MAT 
	 * istructions, and thus, even if it's a variable name, it must be 
	 * considered a matrix name, and it's made 11x11 because it's the
	 * most general use. Vectors must be instantiated explicitly */
	else if (!isExplicit && (*lp=='(' || forceArray)) {
		int namelen=0, M=0, N=0, T=0;
		char *pp=p;
		decCount++;
		if (*lp=='(' && *(lp+1)!=')') {
			T=1;
			lp++;
			p=lp; M=(int)S();
			if (*p==',') {
				p++;
				N=(int)S(); 
				T=2;
			}
			lp=p;
		}
		T=2;
		/* implicit dimensioning if values are into the 0-10 range */
		if (rr==NUM && M<=10 && N<=10) {
			if (T==1) dimArray(decCount,1,10,0);
			else if (T==2) dimArray(decCount,2,10,10);
		}
		else if (rr==STR && M<=10 && N<=10) {
			if (T==1) dimStrArray(decCount,1,10,0);
			else if (T==2) dimStrArray(decCount,2,10,10);
		}
		else {	
			perror_(__LINE__,76,l);
		}
		if (decCount>=VLIMIT) perror_(__LINE__,169,l);
		vn[decCount].isInt=ii;
		vn[decCount].rettype=_rettype=rr;
		vn[decCount].isArr=_arr=TRUE;
		vn[decCount].isConst=FALSE;
		vn[decCount].isCommon=FALSE;
		_len=(int)strlen(name);
		namelen=(_len+1)*sizeof(char);
		if (vn[decCount].name!=NIL) {
			free(vn[decCount].name);
			vn[decCount].name=NIL;
		}
		vn[decCount].name=xmalloc((size_t)namelen);
		if (!vn[decCount].name) perror_(__LINE__,173,l);
		else strncpy_(vn[decCount].name,name,namelen);
		/* debug feature */
		if (isDebug) showDEC(decCount, FALSE);
		p=pp;
		return decCount;
	}

	/* DEC irremediably not found */
	_len=0;
	return FALSE;
}


/*****************************************
 *             TIME & STACK              *
 *****************************************/

/* pushRUN() 
 * store current running state
 * used into calcDEF() */
void pushRUN(void) {
	lb[runTOS]=l;
	sb[runTOS]=startingLine;
	pb[runTOS]=channel[0].fprintn;
	cb[runTOS]=channel[0].fcounter;
	eCb[runTOS]=endCore;
	nowb=now;
	runTOS++;
}


/* popRUN() 
 * restore current running state
 * used into calcDEF() */
void popRUN(void) {
	runTOS--;
	l=lb[runTOS];
	startingLine=sb[runTOS];
	channel[0].fprintn=pb[runTOS];
	channel[0].fcounter=cb[runTOS];
	endCore=eCb[runTOS];
	now=nowb;
}


/* swapDEC()
 * swap two DECLARE variables, given their var-value as arguments 
 * Variables are swapped in their totality, included the values in the
 * proper value-structures P/PS/dim/dimS */
void swapDEC(int v1, int v2) {
	char name1[COMPSTR], name2[COMPSTR]; // names buffer
	int i1=v1, i2=v2, namelen=0;
	/* vars buffers */ 
	int nex;
	double ex;
	char Sex[COMPSTR]; // like the name?
	Tarray ax;
	TSarray Sax;

	/* exchange names in temporary placeholders*/
	if (vn[i2].name) strncpy_(name1,vn[i2].name,COMPSTR);
	else name1[0]='\0';
	if (vn[i1].name) strncpy_(name2,vn[i1].name,COMPSTR);
	else name2[0]='\0';
	/* set first name */
	if (vn[i1].name!=NIL) {
		free(vn[i1].name);
		vn[i1].name=NIL;
	}
	namelen=((int)strlen(name1)+1)*sizeof(char);
	vn[i1].name=xmalloc((size_t)namelen);
	if (!vn[i1].name) perror_(__LINE__,173,l);
	else strncpy_(vn[i1].name,name1,namelen);
	/* set second name */
	if (vn[i2].name!=NIL) {
		free(vn[i2].name);
		vn[i2].name=NIL;
	}
	namelen=((int)strlen(name2)+1)*sizeof(char);
	vn[i2].name=xmalloc((size_t)namelen);
	if (!vn[i2].name) perror_(__LINE__,173,l);
	else strncpy_(vn[i2].name,name2,namelen);

	/* exchange flags */
	nex=vn[i1].isInt;
	vn[i1].isInt=vn[i2].isInt;
	vn[i2].isInt=nex;	

	nex=vn[i1].isArr;
	vn[i1].isArr=vn[i2].isArr;
	vn[i2].isArr=nex;

	nex=vn[i1].rettype;
	vn[i1].rettype=vn[i2].rettype;
	vn[i2].rettype=nex;	
	
	nex=vn[i1].isCommon;
	vn[i1].isCommon=vn[i2].isCommon;
	vn[i2].isCommon=nex;	
	
	/* exchange values */
	ex=P[v1]; 
	P[v1]=P[v2]; 
	P[v2]=ex;
	
	strncpy_(Sex,PS[v1],COMPSTR); 
	strncpy_(PS[v1],PS[v2],COMPSTR); 
	strncpy_(PS[v2],Sex,COMPSTR);
	
	ax=dim[v1]; 
	dim[v1]=dim[v2]; 
	dim[v2]=ax;
	
	Sax=dimS[v1]; 
	dimS[v1]=dimS[v2]; 
	dimS[v2]=Sax;
}


/* fprintb() - used with BIN$()
 * return an integer in binary format according to the following format:
 *   - bit 0 appears on the right (e.g. 13 => 1101);
 *   - negative numbers occupy all 32 bits;
 *   - if mode=FALSE return a number with leading zeroes
 * 'res' is the output string;
 * 'n' is the integer to be converted. */
int fprintb(char *res, int n, int mode) {
	int num[BITS+1], c=-1;
	char *pp=res;
	if (!n && mode) *pp++='0';
	while (n && (c < (BITS - 1))) num[++c] = n & 1, n >>= 1;
	if (!mode) {
		int y=BITS;
		while (--y>c) *pp++='0';
	}
	while (c >= 0) *pp++='0'+num[c--];
	*pp='\0';
	return (int)strlen(res);
}


/* modulo() - modulo and division calculation 
 * if flag=TRUE perform classic math, otherwise perform Integer Theory math
 * A = dividend
 * B = divisor
 * *div = result of division
 * *mod = result of modulo 
 * Note: the case B=0 is treated with the restitution of mod=A and div=A;
 * actually, if 1/0 is performed, the result is an infinite, but to build
 * the original number with a divisor, a dividend, a quotient and a rest,
 * my algorithm worlks on the following theory:
 * A normal integer division, such as 7/2 yields 7=3x2+1, where
 * 	dividend = 7
 * 	divisor  = 2
 * 	quotient = 3
 * 	rest     = 1 (modulo)
 * Suppose now we have to treat 1/0; I suppose the result is inf; so I can 
 * assume that inf x 0 = 1 (or any computable number, but 1 fits my scopes). 
 * Thus we have:
 * 	dividend = 1
 * 	divisor  = 0
 * 	quotient = inf
 * 	rest     = ?
 * I assume rest=0 because inf multiplied by zero returns the divisor; thus, 
 * the rest must yield zero, as in the following equation:
 *      1 = inf x 0 + 0 = 1 + 0 = 1 */
void modulo(int A, int B, int *div, int *mod, int flag) {
	/* special case of null divisor */
	if (!B) {
		perror_(__LINE__,77,l); // warning
		*div=A<0?(int)MINFF:(int)INFF;
		*mod=0;
	}
	/* classic */
	else if (flag) {
		*div=A/B;
		*mod=A-*div*B;
	}
	/* integer theory */
	else {
		int k=A<0?(B<0?-1:1):0;
		*div=A/B;
		*mod=A-*div*B;
		if (*mod<0) {
			*div=*div-k;
			*mod=A-*div*B;
		}
	}
}


/* sign()
 * if argument is positive, return 1
 * if argument is negative, return -1
 * if argument is exactly zero, return 0 */
int sign(double s) {
	if (s<0.0) return -1;
	else if (s>0.0) return 1;
	return 0;
}


/* getTime()
 * return current time structure */
struct tm *getTime(void) {
	time_t st_lt;
	st_lt=time(NULL);
	return localtime(&st_lt);
}


/* getMin()
 * return current min (0-59) */
int getMin(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_min;
}


/* getSec()
 * return current second (0-59) */
int getSec(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_sec;
}


/* getHour()
 * return current hour (0-23) */
int getHour(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_hour;
}


/* getWDay()
 * return current week day (0-6) */
int getWDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_wday;
}


/* getDay()
 * return current day (1-31) */
int getDay(void) {
	struct tm* vt = getTime();
	return (int) vt->tm_mday;
}


/* getMonth()
 * return current month (1-12) */
int getMonth(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_mon+1);
}


/* getYear()
 * return current year */
int getYear(void) {
	struct tm* vt = getTime();
	return (int) (vt->tm_year+1900);
}


/* getMonthString()
 * return current month string */
char *getMonthString(void) {
	return month[getMonth()];
}


/* gregDayNumber()
 * return gregorian day number for date in arguments */
int gregDayNumber(int year,int month, int day) {
	int y,m;
	y=year; // it must be greater than 0
	if (y<=0) y=1;
	m=month;
	if (month < 3) y=y-1, m=m+12;
	return floor(365.25*y)-floor(y/100)+(y/400)+floor(30.6*(m+1))+day-62;
}


/* setYear()
 * adjust year value from a yy to a yyyy (setting for current century) 
 * - if value is negative or it is in the form yyyy and lesser than YEARLIMIT, 
 *   set it to YEARLIMIT and print a warning
 * - if yy is in the range 0-99, if it goes past 15 years from now, return
 *   current century + yy
 * - if yy is in the range 0-99, if it goes back 85 year from now, return
 *   previous century + yy
 * - otherwise return the year itself in the form yyyy
 * Note: since the gregDayNumber return wrong days count for my
 * algorithm if the year is lower than YEARLIMIT, I limit it to YEARLIMIT */
int setYear(int year) {
	int offset=getYear()+TIMEOFFSET-currcentury;
	if (year<=0.0) year=getYear();
	else if (year>=100) {
		if (year<YEARLIMIT) {
			perror_(__LINE__,160,l,YEARLIMIT); // warning
			year=YEARLIMIT;
		}
	}
	else if (year<offset) year+=currcentury;
	else year+=currcentury-100;
	return year;
}


/* dotrim()
 * perform the trimming:
 * - if mode = 3 perform left and right trimming
 * - if mode = 2 perform right trimming
 * - if mode = 1 perform left trimming
 *   */
char *dotrim(char *op, int mode) {
	char res[COMPSTR], *r=res;
	if ((int)strlen(op)>0) strncpy_(res,op,COMPSTR);
	else res[0]='\0';
	if (mode==3 || mode==1) {
		while (isblank(*r)) r++;
	}
	if (mode==3 || mode==2) {
		while (isblank(*(r+strlen(r)-1))) *(r+strlen(r)-1)='\0';
	}
	return r;
}

/*****************************************
 *        INPUT/OUTPUT FORMATTING        *
 *****************************************/

/* Note: the FAC()/FCR() functions are strictly connected with the 
 * PAGE/NOPAGE/<PA> features for the simulated terminal because they all 
 * use/set the page size limits */ 


/* FAC()
 * Advance Carriage on a file stream*/
void FAC(int ch) {
	channel[ch].fcounter++;
	fputc(' ',channel[ch].stream);
	if (!isRawPrint && channel[ch].fcounter > channel[ch].margin) 
		FCR(ch);
}


/* FCR()
 * Carriage Return onto file stream */
void FCR(int ch) {
	channel[ch].fcounter=0;
	channel[ch].pagerow++;
	/* force printing footer if this is last line */
	if (channel[ch].pagerow==channel[ch].height && channel[ch].pagenumber) {
		printFooter(ch);
		channel[ch].pagerow++;
	}
	if (channel[ch].pagerow>channel[ch].height) {
		if (channel[ch].page) channel[ch].page++;
		channel[ch].pagerow=1;
	}
	fputc('\n',channel[ch].stream);
}


/* fillPage()
 * fill page on current channel with void lines in case of PAGE statement set */
void fillPage(int ch) {
	while (channel[ch].pagerow<channel[ch].height) {
		channel[ch].pagerow++;
		fputc('\n',channel[ch].stream);
	}
	if (channel[ch].pagerow==channel[ch].height && channel[ch].pagenumber)
		printFooter(ch);
	else fputc('\n',channel[ch].stream);
	channel[ch].pagerow=1;
	if (channel[ch].page) channel[ch].page++;
}


/* printFooter()
 * print the "- PAGE # -" string at the page footer */
void printFooter(int ch) {
	int i,k=(channel[ch].margin-12)/2;
	for (i=0;i<k;i++) fputc(' ',channel[ch].stream);
	fprintf(channel[ch].stream,"- PAGE %d -\n",channel[ch].page);
}


/* emitNUM()
 * output number (with sign) contained into formatted string num to stream ch
 * or to string dest; update file counter ; 
 * a space follows always the number to stdout/file;
 * if flag is TRUE, redirect printing to dest, otherwise to ch 
 * Note: dest width must be COMPSTR = MAXSTRLEN + 1 */
int emitNUM(int ch, char minus, char *num, int flag, char* dest) {
	int ret=(int)strlen(num);
	char build[COMPSTR];

	/* reset screen/file position if number length exceeds width */
	if (ret+2+channel[ch].fcounter>channel[ch].margin) {
		if (!isRawPrint) FCR(ch);
	}

	/* intercept the RAW PRINT mode with positive number*/
	if (isRawPrint && minus!='-') sprintw(build,COMPSCR,"%s",num);
	/* intercept the RAW PRINT mode with negative number*/
	else if (isRawPrint) sprintw(build,COMPSCR,"%c%s",minus,num);
	/* intercept the normal mode with any-sign number*/
	else sprintw(build,COMPSCR,"%c%s ",minus,num,' ');

	/* print into a string */
	if (flag) sprintw(dest,COMPSCR,"%s",build);
	/* print to screen/file */
	else fprintf(channel[ch].stream,"%s",build);

	/* return correct value counter/file counter */
	return channel[ch].fcounter+2+ret;
}


/* printNUM()
 * format number num to a printing output according to DEC BASIC rules 
 * (ref. LBMAA-A-D 6-4) onto stream identified by ch
 * return updated position of counter (as yielded by emitNum) 
 * if flag is true, the number (in emitNUM) will be printed on string dest 
 * rather than on stdout 
 * Note: dest width must be COMPSTR = MAXSTRLEN + 1 
 * Note: this function does not print anything, delegating emitNUM() */
int printNUM(int ch, double num, int flag, char* dest) {
	int isFloat=TRUE;
	char minus=' ';
	char nums[COMPSCR], *nump;
	double base=0.0;
	int exp=0;
	
	/* intercept the OPTION ZERO feature (only in printing processes)
	 * print number lesser than ZEROLIM as zero */
	if (isZeroLim) {
		if (fabs(num) < ZEROLIM) num=0;
	}
	
	/* intercept the floating depth feature
	 * print number with the specified precision, rather than with the 
	 * standard BASIC printer engine */
	if (PRECISION>=0) {
		char pnum[64] ,dnum[64];
		int isInt=FALSE;
		pnum[0]='\0';
		if (num<0) num=-num, minus='-';
		if (num-(int)num==0.0) isInt=TRUE;
		if (num<pow(10,-PRECISION) && !isInt)
			sprintw(pnum,64,"%%.%dE",PRECISION);
		else if (!isInt)
			sprintw(pnum,64,"%%.%df",PRECISION);
		else 
			sprintw(pnum,64,"%%d");
		if (isInt) snprintf(dnum,64,pnum,(int)num);
		else snprintf(dnum,64,pnum,num);
		return emitNUM(ch,minus,dnum,flag,dest);
	}
	/* intercept the OPTION RAW PRINT ON feature */
	if (isRawPrint) 

	/* if number is null, shorten the process! */
	if (num==0) return emitNUM(ch,' ',"0",flag,dest);
	
	/* operate only with positive numbers, storing the sign aside */
	if (num<0) num=-num , minus='-';

	/* catch UNDERFLOW for a number less than ZERO */
	if (num<ZERO) return emitNUM(ch,minus,"0",flag,dest); 

	/* catch OVERFLOW for a number > INFF in absolute value */
	else if (num > INFF) num=INFF;

	/* temporarily, use exponential or normal form 
	 * in representing the number in a raw form */
	if (num < 1E-10 || num > 1E10) sprintw(nums,COMPSCR,"%.5E", num);
	else sprintw(nums,COMPSCR,"%21.10F", num);

	/* rule 4: suppress final zeroes */
	if ((int)strlen(nums)>0) nump=nums+(int)strlen(nums)-1;
	else nump=nums;
	while((int)(nump-nums)>0 && '0'==*nump) *nump--='\0';

	/* rule 1 part 1: if there's a final dot in an integer, suppress it */
	if ('.'==*nump) {
		*nump--='\0';
		isFloat=FALSE;
	}

	/* suppress any possible trailing nulls */
	nump=nums;
	while((int)(nump-nums)<COMPSCR && (*nump=='0' || *nump==' ')) nump++;

	/* print real number */
	if (isFloat){
		/* exception to rule 3: print real number as-is if it fits */
		if (num <= 1 && (int)strlen(nump) < 8) {
			sprintw(nums,COMPSCR,"0%s",nump);
			return emitNUM(ch,minus,nums,flag,dest);
		}
		else if ((int)strlen(nump) < 8) {
			sprintw(nums,COMPSCR,"%s",nump);
			return emitNUM(ch,minus,nums,flag,dest);
		}

		/* rule 3: print real with exponent */
		else if (num < 0.1) {
			sprintw(nums,COMPSCR,"%.5E",num);
			doExp(nums,&base,&exp);
			if (exp<0) sprintw(nums,COMPSCR,"%.5fE%d",base,exp);
			else sprintw(nums,COMPSCR,"%.5fE+%d",base,exp);
			return emitNUM(ch,minus,nums,flag,dest);
		}
		/* rule 2: print real with 6 significant digits 
		 * retaining decimal dot (use of #)*/ 
		else {
			sprintw(nums,COMPSCR,"%#.6G",num);
			nump=strstr(nums,"E");
			/* depict number in exponential form */
			if (nump) {
				doExp(nums,&base,&exp);
				if (exp<0) 
				     sprintw(nums,COMPSCR,"%.5fE%d",base,exp);
				else sprintw(nums,COMPSCR,"%.5fE+%d",base,exp);
			}
			/* rule 4 reapplied: suppress trailing zeroes at 
			 * the end if not and exponential */
			if (!strstr(nums,"E")) {
				if ((int)strlen(nums)>0) 
					nump=nums+strlen(nums)-1;
				else nump=nums;
				while ((int)(nump-nums)>0 && *nump=='0') 
					*nump--='\0';
			}
			return emitNUM(ch,minus,nums,flag,dest);
		}
	}
	/* print integer number */
	else {
		/* rule 1 part 2: print integer till 9 significant digits */
		if ((int)strlen(nump) < 9) 
			return emitNUM(ch,minus,nump,flag,dest);

		/* rule 1 part 2 (reverse case): print integer with exponent
		 * and 6 significant digits (that is, 5 decimals) */
		else { 
			sprintw(nums,COMPSCR,"%.5E",num);
			nump=strstr(nums,"E");
			if (nump) {
				doExp(nums,&base,&exp);
				if (exp <0) 
				     sprintw(nums,COMPSCR,"%.5fE%d",base,exp);
				else sprintw(nums,COMPSCR,"%.5fE+%d",base,exp);
			}
			return emitNUM(ch,minus,nums,flag,dest);
		}
	}

	/* avoiding warnings.... */
	return 0;

}


/* getString()
 * get a formatted string from user keyboard, excluding user delay */
char *getString(void) {
	char *lp=line;
	int i;
	double extraS;

	/* get timer */
        gettimeofday(&tv, NULL);
       	extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);

	/* get string */
	for (i=0; i<SCREENLINE; i++) line[i]='\0';
	while (TRUE) {
		*lp=fgetc(CONSOLEIN);
		/* manage default standard input (altered by INCLUDE) */
		if (*lp==EOF) {
			/* warning */
			perror_(__LINE__,233,l);
			fclose(CONSOLEIN);
			CONSOLEIN=stdin;
			continue;
		}
		if (*lp==10 || *lp==13 || *lp=='\n') {
			*lp='\0';
			if (CONSOLEIN!=stdin) 
				fputc('\n',channel[CONSOLE].stream); 
			break;
		}
		else lp++;
	}

	/* get timer again to exclude user delay from timing 
	 * and update beginS */
        gettimeofday(&tv, NULL);
       	extraS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0)-extraS;
	beginS=beginS+extraS;

	/* reset counter (since the user pressed ENTER) */
	channel[CONSOLE].fcounter=0;
	
	/* return string */
	return lp=line;
}


/*****************************************
 *             ASSIGNMENTS               *
 *****************************************/

/* assign()
 * The assign subroutine called by LET()
 * assign a number to a number-variable or assign a string to a string-variable
 * variable name is taken from input string
 * return TRUE if assignment went OK, false otherwise 
 * System function */
int assign(void) {
	char *e=p;
	int ns;

	/* don't assign in case of error in the command line */
	if (isEndOfStatement) return TRUE;
	
	/* return left assignment of LEFT$ */
	if (!strncasecmp_(p,"LEFT$(",6)) {
		p+=6;
		assignLeft();
	}
	/* return left assignment of RIGHT$ */
	else if (!strncasecmp_(p,"RIGHT$(",7)) {
		p+=7;
		assignRight();
	}
	/* return left assignment of MID$ */
	else if (!strncasecmp_(p,"MID$(",5)) {
		p+=5;
		assignMid();
	}
	/* assign FN value */
	else if (!strncasecmp_(e,"FN",2)) {
		if (isDefRun) {
			int ward;
			e+=2, ward=*e++;
			if (!isalpha(ward)) return FALSE;
			if (ward!=isDefVar) return FALSE;
			if (*e=='=') e++; 
			else return FALSE;
			if (isanystring(e)) perror_(__LINE__,45,l); 
			p=e; fn[ward].res=S(); 
			return isDefCalc=TRUE;
		}
		else {
			int ward;
			e+=2, ward=*e++;
			perror_(__LINE__,60,l,ward);
		}
	}
	/* assign to variables */
	else if ((ns=findDEC(p))) {
		/* constants cannot be assigned */
		if (vn[ns].isConst) perror_(__LINE__,205,l,vn[ns].name);
		p+=_len;
		/* numerical variables */
		if (_rettype==NUM && !vn[ns].isArr) {
			if (*p=='=') p++; 
			else perror_(__LINE__,37,l);
			if (vn[ns].isInt) P[ns]=(int)S();
			else P[ns]=S();
		}
		/* string variables */
		else if (_rettype==STR && !vn[ns].isArr) {
			char op[COMPSTR];
			if (*p=='=') p++; 
			else perror_(__LINE__,37,l);
			strncpy_(op,SS(),COMPSTR);
			strncpy_(PS[ns],op,COMPSTR);
		}
		/* numeric and string arrays */
		else if (vn[ns].isArr) {
			int M=0, N=0, T=1, rb=_rettype;
			if (*p=='(') p++; 
			else perror_(__LINE__,37,l);
			M=(int)S();
			if (*p==',') {
				p++;
				N=(int)S();
				T=2;
			}
			if (*p==')') p++; 
			else perror_(__LINE__,37,l);
			if (*p=='=') p++; 
			else perror_(__LINE__,37,l);
			_rettype=rb;
			/* numeric arrays */
			if (_rettype==NUM) {
				double val=S();
				if (vn[ns].isInt) {
					setArrayVal(ns,T,M,N,(int)val);
				}
				else {
					setArrayVal(ns,T,M,N,val);
				}
			}
			/* string arrays */
			else {
				char op[COMPSTR];
				strncpy_(op,SS(),COMPSTR);
				setArrayStr(ns,T,M,N,op);
			}
		}
		/* TRACE option */
		if (startInteractive && !vn[ns].isArr) {
			//showDEC(traceISval,TRUE);
			int vv=searchDEC(traceISval,decCount);
			if (vv==ns) {
				if (isInvDebug) fprintf(stdout,INVCOLOR);
				fprintf(stdout,"%s [#%d], type %s, ",vn[vv].name!=NIL?vn[vv].name:"obj.",vv,vn[vv].rettype==NUM?"numeric":"string");
				if (vn[vv].rettype==NUM) 
					fprintf(stdout,"value = %f\n",P[vv]);
				else fprintf(stdout,"value = |%s|\n",PS[vv]);
				if (isInvDebug) fprintf(stdout,RESETCOLOR);
			}
		}
	}
	else return FALSE;

	return TRUE;
}


/* assignLeft()
 * calculate the left-assignment with LEFT$()*/
char *assignLeft(void) {
	int index=0, num=0, curr=0, cs;
	char lefts[COMPSTR], op[COMPSTR];
	
	/* check that a variable is used and nothing else */
	if ((cs=findDEC(p)) && _rettype==STR && !_arr) {
		index=cs;
		p+=_len;
	}
	else perror_(__LINE__,42,l);
	
	/* get string argument */
	strncpy_(op,PS[index],COMPSTR);

	/* get length (implicitly set to 1 if not given) */
	if (*p==',') {
		p++;
		num=(int)S();
	}
	else num=1;
	curr=(int)strlen(op);
	/* check length */
	if (num<0) num=0;
	if (num>curr+1) num=curr+1;
	if (strncmp(p,")=",2)) perror_(__LINE__,35,l);
	else p+=2;
	/* get argument string (after =) and compose */
	strncpy_(lefts,SS(),COMPSTR);
	strncat_(lefts,op+num,COMPSTR);
	/* allocate space for the new string and abandon previous */
	num=(int)strlen(lefts)+1;
	strncpy_(PS[index],lefts,num);
	return p;
}


/* assignRight()
 * calculate the left-assignment with RIGHT$()*/
char *assignRight(void){
	int index=0, num=0, curr=0, cs;
	char rights[COMPSTR], op[COMPSTR];
	
	/* check that a variable is used and nothing else */
	if ((cs=findDEC(p)) && _rettype==STR && !_arr) {
		index=cs;
		p+=_len;
	}
	else perror_(__LINE__,42,l);

	/* get string argument */
	strncpy_(op,PS[index],COMPSTR);

	/* get length (implicitly set to 1 if not given) */
	if (*p==',') {
		p++;
		num=(int)S();
	}
	else num=1;
	curr=(int)strlen(op);
	/* check length */
	if (num<0) num=0;
	if (num>curr+1) num=curr+1;
	if (strncmp(p,")=",2)) perror_(__LINE__,35,l);
	else p+=2;
	/* get argument string (after =) and compose */
	strncpy_(rights,op,curr-num+1);
	strncat_(rights,SS(),COMPSTR);
	/* allocate space for the new string and abandon previous */
	num=(int)strlen(rights)+1;
	strncpy_(PS[index],rights,num);
	return p;
}


/* assignMid()
 * calculate the left-assignment with MID$()*/
char *assignMid(void){
	int index=0, start=0, len=0, curr=0, cs;
	char mids[COMPSTR], op[COMPSTR];

	/* check that a variable is used and nothing else */
	if ((cs=findDEC(p)) && _rettype==STR && !_arr) {
		index=cs;
		p+=_len;
	}
	else perror_(__LINE__,42,l);

	/* get string argument */
	strncpy_(op,PS[index],COMPSTR);

	/* get and check arguments */
	if (*p!=',') perror_(__LINE__,65,l,makechar(p),",");
	else p++;
	curr=(int)strlen(op);
	/* get start position */
	start=(int)S();
	if (start<=0) start=1;
	if (start>curr+1) start=curr+1;
	/* get length (implicitly set to 1 if not given) */
	if (*p==',') {
		p++;
		len=(int)S();
	}
	else len=1;
	/* check length */
	if (len<0) len=0;
	if (len>curr+1) len=curr+1;
	if (strncmp(p,")=",2)) perror_(__LINE__,35,l);
	else p+=2;
	/* get argument string (after =) and compose */
	strncpy_(mids,op,start);
	strncat_(mids,SS(),COMPSTR);
	strncat_(mids,op+start+len-1,COMPSTR);
	/* allocate space for the new string and abandon previous */
	len=(int)strlen(mids)+1;
	strncpy_(PS[index],mids,len);
	return p;
}


/*****************************************
 *             MATH & STRINGS            *
 *****************************************/

/* getLabelAddr()
 * return the physical address of a label, both in numeric and in alphanumeric
 * format;
 * return -1 in case no useful value has been found */
int getLabelAddr(char *lp, char **rp) {
	int val;
	char num[10], *n=num;
	/* numeric label */
	if (isdigit(*lp)) {
		int c=0;
		while (c<5 && isdigit(*lp)) *n++=*lp++, c++;
		*n='\0';
		val=strtol(num,NULL,10);
		*rp=lp;
	}
	/* alphanumeric label */
	else val=setAddr(lp,rp); // rp is updated in setAddr() 
	/* check value */
	if (norow(val)) return -1;
	return getAddr(val);
}	


/* setAddr()
 * calculate the numerical correspondence of any string label 
 * in chunks of 8 characters*/
int setAddr(char *lp, char **rp) {
	int val=CORELIM, c=0, i=0;
	while (isnamechar(lp) && i<NAMEDIM) {
		c=0;
		while (isnamechar(lp) && c<8) {
			if (isdigit(*lp))
				val+=pow(10,c++)*(toupper(*lp++)-'0'+1);
			else val+=pow(10,c++)*(toupper(*lp++)-'A'+1);
			i++;
		}
	}
	if (**rp) *rp=lp;
	return val;
}


/* getAddr()
 * convert the label into a physical address
 * return -1 in case no address was found */
int getAddr(int label) {
	int i;
	for (i=0;i<MEMLIMIT;i++) if (ln[i]==label) return i;
	return -1;
}


/* doExp(str, &base, &exp, work) 
 * find base and exponent of a number which must be printed in exponential 
 * form given the pointer to the string str containing the number in raw form.
 * Note: See the BCLM manual, for some output of numbers in exponential form.
 * str is the base string hosting the number
 * base and exp are char arrays to host base and exponent pictures
 * work is a space area for the exponent calculation
 * System function used into printNUM() */
void doExp(char *pos, double *base, int *exp) {
	char *e = strstr(pos, "E");
	if (!e) e = strstr(pos, "e");
	if (!e) return;
	*e=' ';
	*base=strtod(pos,NULL);
	*exp=strtol(e,NULL,10);
}


/* power(base,exponent)
 * safe powering function */
double power(double base, double expon) {
	/* if base is negative, take some cautions... */
	if (base<0) {
		/* integer exponent is always evaluable */
		if (expon==(double)((int)expon)) {
			if ((int)expon%2) 
				/* odd exponent */
				return -pow(-base,expon);
				/* even exponent (regular case) */
				else return pow(base,expon);
		}
		/* real exponent is not evaluable if base is < 0 */
		else perror_(__LINE__,66,l);
	}
	/* error in case of 0^(<0) */
	else if (expon<0 && base==0) perror_(__LINE__,132,l);
	/* 1 is the limit of function x^x if x approaches zero from right */
	else if (expon==0 && base==0) return 1.0;
	/* default case for base > 0 and any exponent (regular case) */
	return pow(base,expon);
}


/* bonecomp()
 * blank compare
 * compares the keyword + 1 blank 
 * System function for preParse() */
int bonecomp(char *src, char *key) {
	if (strncasecmp_(src,key,strlen(key))) return FALSE;
	src+=strlen(key);
	if (!isblank(*src)) return FALSE;
	return TRUE;
}


/* bthencomp()
 * blank compare
 * compares one blank + THEN 
 * System function for stripBlanks */
int bthencomp(char *src) {
	if (!isblank(*src)) return FALSE;
	src++;
	if (strncasecmp_(src,"THEN",4)) return FALSE;
	return TRUE;
}


/* bcomp()
 * blank compare
 * compares one blank + the keyword + one blank against the source
 * System function for stripBlanks */
int bcomp(char *src, char *key) {
	if (!isblank(*src)) return FALSE;
	src++;
	if (strncasecmp_(src,key,strlen(key))) return FALSE;
	src+=strlen(key);
	if (!isblank(*src)) return FALSE;
	return TRUE;
}


/* stripBlanks()
 * strip blanks from src and copy stripped string to dest; 
 * stop stripping while into a string */
void stripBlanks(char *src, char *dest) {
	int j=1; // strip flag/counter - don't change!
	while (*src) {
		if (*src=='\"') j++;
		if (j&1) { 
			if (*src!=' ' && *src!='\t') 
				*dest++=*src; 
		}
		else *dest++=*src;
		src++;
	}
	*dest='\0';
}



/* stripBlanks() - 2.0
 * strip blanks from src and copy stripped string to dest, taking care
 * of skipping syntax blanks;
 * stop stripping while into a string */
void stripBlanks2(char *src, char *dest) {
	int j=1; // strip flag/counter - don't change!
	while (*src) {
		if (*src=='\"') j++;
		if (j&1) { 
			if (bcomp(src,"TO")) *dest++=*src++, 
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bcomp(src,"IN")) *dest++=*src++, 
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bcomp(src,"USE")) *dest++=*src++, *dest++=*src++, 
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bcomp(src,"AS")) *dest++=*src++, 
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"GO")) {
				*dest++=*src++, *dest++=*src++;
				if (bcomp(src,"TO")) *dest++=*src++, 
					*dest++=*src++, *dest++=*src++;
				else if (bcomp(src,"SUB")) 
					*dest++=*src++, *dest++=*src++,
					*dest++=*src++, *dest++=*src++;
			}
			if (bcomp(src,"GOSUB")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bcomp(src,"GOTO")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bthencomp(src))  {
				/* THEN */
				*dest++=*src++, *dest++=*src++, *dest++=*src++, 
				*dest++=*src++, *dest++=*src++;
				/* THEN followed by GOTO */
				if (bcomp(src,"GOTO")) {
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++, *dest++=*src++;
				}
				/* THEN followed by GOSUB */
				else if (bcomp(src,"GOSUB")) {
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++, *dest++=*src++,
					*dest++=*src++;
				}
				/* THEN followed by GO */
				else if (bcomp(src,"GO")) {
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++;
					/* THEN GO followed by TO */
					if (bcomp(src,"TO")) {
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++, *dest++=*src++;
					}
					/* THEN GO followed by SUB */
					if (bcomp(src,"SUB")) {
					*dest++=*src++, 
					*dest++=*src++, *dest++=*src++, 
					*dest++=*src++, *dest++=*src++;
					}
					else *dest++=*src++;
				}
			}
			if (bcomp(src,"ELSE"))  *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bcomp(src,"BY"))  *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bcomp(src,"STEP"))  *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bcomp(src,"OTHERWISE")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"DO")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"IF")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"FOR")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"SUB")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"DECLARE")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"HANDLER")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"SELECT")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"WHILE")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (bonecomp(src,"UNTIL")) *dest++=*src++,
				*dest++=*src++, *dest++=*src++, *dest++=*src++,
				*dest++=*src++, *dest++=*src++;
			if (*src!=' ' && *src!='\t') 
				*dest++=*src; 
		}
		else *dest++=*src;
		src++;
	}
	*dest='\0';
}


/* silenceTick()
 * put an EOL in place of the tick, to exclude comment.
 * Note: it must be used on a copy of the program line. */
void silenceTick(char *str) {
	int j=1; // don't change!
	while (*str) {
		if (*str=='\"' && *(str-1)!='\\') j++;
		if (*str=='\'' && (j&1)) {
			*str='\0';
			str--;
			while (isblank(*str)) *str--='\0';
			break;
		}
		str++;
	}
}


/* makechar()
 * returns first character of string str as a string */
char *makechar(char* str) {
	static char onechar[2];

	onechar[0]=*str;
	onechar[1]='\0';
	return onechar;
}


/* spaces() 
 * return a pointer to a string of v spaces up to LIMIT+1 characters */
char *spaces(int v) {
	static char spacePad[LIMIT+1];
	char *sp;
	int n;

	/* set limits */
	sp=spacePad;
	if (v<0) n=0;
	else if (v>LIMIT) n=LIMIT;
	else n=v;
	
	/* build spaces string */
	while (n-->0) *sp++=32;
	*sp='\0';
	return spacePad;
}


/* turnToUpper()
 * turn a line to all upper characters */
void turnToUpper(char *str) {
	while (*str) *str=toupper(*str), str++;
}


/* turnToUpper()
 * turn a line to all upper characters outside double quotes*/
void turnToUpper_oq(char *str) {
	int t=1;
	while (*str) {
		if (*str=='\"') t++;
		if (t&1) *str=toupper(*str);
		str++;
	}
}


/* checkCommand()
 * check current against liner not considering the inner blanks, so that
 * "END WHILE" is equal to "END    WHILE" or to "END\tWHILE"
 * The 'current' string may be longer after the matching substring, while
 * liner must be complete
 * System function for preParse() */
int checkCommand(char *current, char *liner, char **final) {
	char *c=current, *l=liner;
	while (isblank(*c)) c++; 
	while (isblank(*l)) l++;
	while (*c && *l) {
		if (toupper(*c)!=toupper(*l)) break;
		c++; l++;
		while (isblank(*c)) c++; 
		while (isblank(*l)) l++;
	}
	/* if second string got to the end, they match! */
	if (!*l) {
		if (*final) *final=c;
		return TRUE;
	}
	return FALSE;
}


/* Note
 * The following strncpy_() and strncat_() are my own personal versions for 
 * strcpy/strncpy and strcat/strncat respectively.
 * I must use mine because strncpy/strncat standard functions in C (gcc) have 
 * erratic behaviors within different operating systems like Linux-Suse, 
 * OpenBSD and Mac OS X 10.4 (the one I use).
 * Since many reported strange things happening because of strncpy/strncat
 * (from error in compilation to completely wrong string functions output), I 
 * made up my mind and built these substitutes for both. */

/* strncpy_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus a width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is also good.)
 * The process will take care of never going past the limit of dst, and to fill 
 * the rest of the space (if any) with nulls; 
 * System function replacing strcpy/strncpy */
char *strncpy_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* check length of copy and source */
	if (dw<=1) *dst='\0';
	else {
		/* erase destination */
		*dst='\0';
		/* copy src onto dst but not past the end of dst */
		while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
		*dp++='\0';
		/* fill the rest with nulls */
		while ((int)(dp-dst)<(dw)) *dp++='\0';
	}
	/* Note: return the same value returned by strcpy/strncpy */
	return dst;
}


/* strncat_()
 * dst: the destination string (which must have its proper dimension)
 * src: the source to be copied onto dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst, and to fill 
 * the rest of the space (if any) with nulls; if dst is found not initialized 
 * (that is nowhere the terminator is found) it is initialized as void.
 * System function replacing strcat/strncat */
char *strncat_(char *dst, char *src, int dw) {
	char *dp=dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* copy src onto dst but not past the end of dst */
	while ((int)(dp-dst)<(dw-1) && *src) *dp++=*src++;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<(dw)) *dp++='\0';
	/* Note: return the same value returned by strcat/strncat */
	return dst;
}


/* chrcat_()
 * add character c to list dst, taking care of checks the limit
 * dst: the destination string (which must have its proper dimension)
 * c: the character to be appended to dst
 * dw:  the destination width, the unity used to declare dst (for the sake
 * of precision, if dst is declared as 10 characters wide, it means that text
 * goes from pos. 0 to pos 8, and in pos. 9 is the last terminator; thus width
 * equal to 10 means 9 characters at most for the string; dw must be put equal 
 * to the width, in this example 10; of course, any lower value is good.)
 * The process will take care of never going past the limit of dst, and to fill 
 * the rest of the space (if any) with nulls; if dst is found not initialized 
 * (that is no terminator is found) dst is initialized as void.
 * Note: this function is a complement of the strncat_ function
 * System function */
char *chrcat_(char *dst, int c, int dw) {
	char *dp=dst;
	/* search for current terminator */
	while (*dp && (int)(dp-dst)<dw) dp++;
	/* terminator not found: initialize destination */
	if ((int)(dp-dst)>=dw) dp=dst, *dp='\0';
	/* add c to dst but not past the end of dst */
	if (c && (int)(dp-dst)<(dw-1)) *dp++=c;
	*dp='\0';
	/* fill the rest with nulls */
	while ((int)(dp-dst)<(dw)) *dp++='\0';
	/* Note: return the same value returned by strncat_ */
	return dst;
}


/* Note
 * The following sprintw() is my own personal version wrapper for snprintf(), 
 * which appear to behave erratically on my system (is does not work with 
 * function return values, but works with real arrays) and probably the same 
 * (with inverse properties) on other systems.
 * This wrapper assures that only physical arrays are treated by sprintw() */

/* sprintw() 
 * the snprintf wrapper 
 * dest is the destination string,
 * len is the string width (including the terminator character)
 * format is the formatting string (with the same printf rules)
 * '...' is the printing string argument (it may be a function return value) 
 * return the number of characters written in the host string 
 * System function replacing sprintf/snprintf */
int sprintw(char *dest, int len, char* format, ...) {
	va_list ap;
	char base[COMPSTR];
	va_start(ap,format);
	vsnprintf(base,COMPSTR,format,ap);
	snprintf(dest,len,"%s",base);
	va_end(ap);
	return (int)strlen(base);
}


/* Note
 * The following strncasecmp_() is my own personal version of strncasecmp.
 * I must use mine because strncasecmp seems to cause some problems if tbas is
 * compiled under openSuse with gcc and or Linux/openBSD with gcc.
 * Since many reported errors in compiling when the standard strncasecmp is
 * used, I made up my mind and built this substitute. */

/* strncasecmp_()
 * the string compare function
 * dst and src are the strings to be compared;
 * N is the number of characters to be checked against;
 * return the flag for positive comparison result, 0 for match, -1 for failure.
 * Note: return values mimic the original return values, with the difference
 * that I don't check here for dst being greater or less than src, and in case
 * they differ, -1 is returned anyway; this is done for speed issues. */
int strncasecmp_(char *dst, char *src, int N) {
	if (N<=0) return -1;
	while (N && *dst && *src && toupper(*dst)==toupper(*src)) 
		src++, dst++, N--;
	if (!N) return 0;
	return -1;
}


/* Note
 * The following memcpy_() is my own personal version of memcpy and memmove.
 * I must use mine because memcpy seems to be sometimes rejected by openBSD.
 * Since many reported errors in compiling if the standard memcpy_/memmove is
 * used, I made up my mind and built this substitute. */

/* memcpy_()
 * copy a portion of memory from src to dst, using memmove (that takes care
 * of overlapping), for a number of characters as in size, checks before
 * if any of arrays are null, or size is zero */
void memcpy_(void *dst, void *src, int size) {
	if (src==NIL || dst==NIL || !size) return;
	memmove(dst,src,size);
}


/* Note
 * The following strcasestr_() is my own personal version of strcasestr().
 * I must use mine because strcasestr() in C has someway an erratic behavior
 * with Linux.
 * Since many reported errors in compiling if the standard strcasestr() is
 * used, I made up my mind and built this substitute. */

/* strcasestr_()
 * find the first occurrence of the substring 'little' in string 'big', 
 * ignoring the case of both arguments.
 * The terminating null bytes (i.e. '\0') are not compared. 
 * If 'little' is null, return NIL; if the substring is found, return the 
 * updated address in 'big', otherwise return NIL. */
char *strcasestr_(char *big, char *little) {
	int l=(int)strlen(little);

	if (!l) return NIL;
	while (*big) {
		if (!strncasecmp_(big,little,l)) return big;
		big++;
	}
	return NIL;
}


/* strcasestr_oq()
 * find the first occurrence of the substring string 'pr' into string 'pl'
 * this function has the same usage of strcasestr_(), but it works only if 
 * outside of a string, in BASIC normally surrounded by double quotes
 * (strcasestr_oq = strcasestr_ Out of Quotes) */
char *strcasestr_oq(char *pl, char* pr) {
	int valid=1, l=(int)strlen(pr);

	if (!l) return pl;
	while (*pl) {
		if (*pl=='\"') valid++;
		if (!strncasecmp_(pl,pr,l) && (valid&1)) return pl;
		pl++;
	}
	return NIL;
}


/* strcasestr_oq_div()
 * as strcasestr_oq but using two strings separated by one or more blanks 
 * return in 'distance' the width of the two strings */
char *strcasestr_oq_div(char *pl, char*pr1, char *pr2, int *distance) {
	int valid=1, l1=(int)strlen(pr1), l2=(int)strlen(pr2);
	char *q;

	if (!l1 && !l2) {
		*distance=0;
		return pl;
	}
	while (*pl) {
		if (*pl=='\"') valid++;
		if (!strncasecmp_(pl,pr1,l1) && (valid&1)) {
			q=pl+l1;
			while (isblank(*q)) q++;
			if (!strncasecmp_(q,pr2,l2) && valid&1) {
				*distance=(int)(q+l2-pl);
				return pl;
			}
		}
		pl++;
	}
	*distance=0;
	return NIL;
}


/* storeSingleLineToCore()
 * saves into core memory the line in argument, which must be constituted
 * by a line number lesser than 100000 (not required) and a BASIC statement;
 * return 0 on successful storing;
 * line holds the textual statements part
 * lnum holds the physical line number
 * a void line is transparent for this command
 * System function */ 
int storeSingleLineToCore(char* line, int lnum) {
	char *lp=line, *z, *sp=line;
	char linenum[10], label[COMPSCR], *lab=label;
	int row=0, lk=0;

	/* check NIL (empty line...) */
	if (!*line) return 0;

	if ((int)strlen(line)>0) lp=line+(int)strlen(line)-1;
	else lp=line;
	/* get rid of final blanks (to intercept alphalabels) */
	while ((int)(lp-line)>0 && isblank(*lp)) *lp--='\0';
	/* advance till first useful command (for colon and IMAGE) */
	while (isdigit(*sp)) sp++;
	while (isblank(*sp)) sp++;

	/* get line number 
	 * numbers must be in the range 0-99999 (any up-to-five digits) */
	lp=line;
	if (isdigit(*lp)) {
		row=0;
		/* get and check line number */
		while (row<5 && isdigit(*lp)) linenum[row++]=*lp++;
		linenum[row]='\0';
		row = strtol(linenum, NULL, 10);
		/* check label validity */
		if (row<0 || row > DATLIM) return 71; 
		/* set reference */
		ln[lnum]=row; // store label for debugging purposes
	}
	/* get label code number 
	 * labels must stand on their own line, terminated by colon and not
	 * be followed by a statement; labels are constituted by numbers, 
	 * letters and the underscore, but they must begin with a letter 
	 * or an underscore character */
	else if ((int)strlen(line)>0) {
		if (line[(int)strlen(line)-1]==':' && isbeginnamechar(lp)) {
			while (isnamechar(lp) && *lp) *lab++=*lp++;
			*lab='\0';
			row=setAddr(label,&lp);
			if (norow(row)) return 57; 
			ln[lnum]=row;
		}
	}
	
	/* remove trailing spaces ahead (after the line number) and behind */
	while ((int)(lp-line)<MAXSTRLEN && isblank(*lp)) lp++;
	if ((int)strlen(lp)>0) lk=(int)strlen(lp)-1;
	else lk=0;
	if ((int)(lp-line)+lk<MAXSTRLEN) {
		z=lp+lk;
		while ((int)(z-line)>0 && isblank(*z)) *z--='\0';
	}

	/* store line; if lp is void line with only spaces and/or tabs, it's 
	 * stored anyway, but it won't be executed (see up) */
	if (*lp && (int)strlen(lp)>0) {
		lk=((int)strlen(lp)+1)*sizeof(char);
		m[lnum]=xmalloc((size_t)lk);
		if (!m[lnum]) return 194; 
		strncpy_(m[lnum],lp,lk);
	}
	/* if line is void (i.e. with line number/label but without any
	 * statements), fill it with some spaces; this is done because some 
	 * programmers may GO TO lines with line number but void; a whim that I
	 * have got to circumvent! */
	else {
		lk=(5+1)*sizeof(char);
		m[lnum]=xmalloc((size_t)lk);
		if (!m[lnum]) return 194; 
		strncpy_(m[lnum],"     ",lk); // five spaces
	}

	/* normal behavior */
	return 0;
}


/* printHeader()
 * print Header in the DEC style */
void printHeader(void) {
	char hour[24], date[24];
	/* solve for null name */
	if ((int)strlen(filename)<1) strncpy_(longname,"<NONAME>",COMPSCR);
	else strncpy_(longname,filename,COMPSCR);
	turnToUpper(longname);
	/* cut extension in ANY CASE */
	if ((int)strlen(longname)>3) {
		if (!strcasecmp(longname+(int)strlen(longname)-4, EXTU))
			longname[(int)strlen(longname)-4]='\0';
	}
	sprintw(hour,24,"%02d:%02d", getHour(), getMin());
	sprintw(date,24,"%02d-%s-%02d",getDay(),getMonthString(),
			getYear()-2000);
	fprintf(stdout,"\n");
	fprintf(stdout,THISHEADER, basename(longname), hour, date);
	fprintf(stdout,"\n");
	fprintf(stdout,"\n\n\n");
}


/******************************************
 *                 PARSING                *
 ******************************************/


/* doVintage()
 * set Vintage properties 
 * if mode is VINTAGESET set vintage values
 * if mode is VINTAGERESET set default values */
void doVintage(int mode) {
	/* reset default parameters */
	isRadians=TRUE;
	BASE=0;
	isComparison=RELATIVE;
	ZEROEQUAL=1.0E-6;
	isEcho=TRUE;
	isExplicit=FALSE;
	isAmericanFormat=TRUE;
	PRECISION=-1;
	isPrompt=TRUE;
	isRawPrint=FALSE;
	isToReset=TRUE;
	isSpacing=FALSE;
	ZONE=ZONEBASE;
	isZeroLim=FALSE;
	ZEROLIM=0.0;
	phantomString=FALSE;
	/* set specific vintage output */
	if (mode==VINTAGESET) {
		isCap=TRUE;
		isCaseSensitive=FALSE;
		isRoute=FALSE;
		isTiming=TRUE;
		isHeader=TRUE;
	}
	/* reset to default */
	else {
		isCap=FALSE;
		isCaseSensitive=TRUE;
		isRoute=TRUE;
		isTiming=FALSE;
		isHeader=FALSE;
	}
}



/* preParse()
 * A fundamental subroutine to be run BEFORE each process.
 * Scan source in core memory and executes DATA and DEF recordings, sets DIM
 * (DIMENSION) arrays spaces, opens FILES files, and in general activates all 
 * commands that must be preprocessed before program execution.
 * Check also FOR-NEXT crossed references while GOTO, GOSUB and THEN addresses 
 * are checked into their relative functions.
 * Note for subsequent addons: This command is executed BEFORE stripblanks()
 * into parse(), so assure to do stripblanks() before processing the line,
 * or use isblank() to skip all blanks!!! 
 * m: the array of the string pointers containing the program lines to be
 * executed.
 * System basic function */
void preParse(char **m, int start, int end) {
	int l=start-1, thisisHeader=FALSE, i=0;
	char *q, *qq, *inlin=NULL;
	char g[endCore+2][COMPSTR];
	int  cn, ig[endCore+2];
	dc=dataLimit=0;

	/* copy original here (to be restored after) */
	for (i=1;i<=endCore;i++) {
		if (m[i] && *m[i] && strlen(m[i])) {
			strncpy_(g[i],m[i],COMPSTR);
			ig[i]=strlen(m[i])+1;
		}
		else {
			strncpy_(g[i],"",1);
			ig[i]=0;
		}
	}

	/* preset DEFFN values */
	isDefRun=FALSE;
	isDefCalc=FALSE;
	isDefVar=	0;
	isDefFor=FALSE;

	/* scan source */
	do {
		l++;
		if (!m[l]) continue;
		q=m[l];
		if (!q) continue;
		while (isblank(*q)) q++;
		/* image lines (for USING) are not checked */
		if (!strncasecmp_(q,"IMAGE",5)) continue;
		if (*q==':') continue;
		/* comments are not checked */
		if (*q=='\'') continue;
		if (!strncasecmp_(q,"REM",3)) continue;
		/* PRINT and WRITE may contain strings that shouldn't be 
		 * checked, but in any case, PRINT() and WRITE() and their
		 * coworkers can themselves detect all errors;
		 * so avoid checks here */
		if (!strncasecmp_(q,"PRINT",5)) continue;
		if (!strncasecmp_(q,"LIBRARY",7)) continue;
		if (!strncasecmp_(q,"WRITE",5)) continue;
		/* remove temporarily tick comments */
		if ((inlin=strcasestr_oq(q,"\'"))){
		       	*inlin='\0';
			inlin--;
			while (isblank(*inlin)) *inlin--='\0';
		}
		//while (isblank(*(q+strlen(q)-1))) *(q+strlen(q)-1)='\0';
		if (!q) continue;
		
		/* DATA Statement - saving elements 
		 * Note: this is the actual execution of the DATA instruction, 
		 * which in runtime is effectively a no-op */
		if (!strncasecmp_(q,"DATA",4)) {
			/* debug info */
			if (isDebug) {
				if (isInvDebug) printf(INVCOLOR);
				printf("Storing DATA line %d\n",ln[l]);
				if (isInvDebug) printf(RESETCOLOR);
			}
			/* check line length */
			if ((int)strlen(q)>SCREENLINE-7) perror_(__LINE__,75,l);
			q+=4;
			while (*q) {
				while (isblank(*q)) q++;
				/* store naked strings (comma separated) */
				if (isalpha(*q)) {
					char op[COMPSTR], *P1=op;
					int lk;
					/* check if DATA space is full */
					if (dcs>=DATLIM-1) 
						perror_(__LINE__,97,l);
					while (*q&&*q!=','&&*q!='\n') 
						*P1++=*q++;
					*P1='\0';
					++dcs;
					lk=((int)strlen(op)+1)*sizeof(char);
					if (DS[dcs]!=NIL) {
						free(DS[dcs]);
						DS[dcs]=NIL;
					}
					DS[dcs]=xmalloc((size_t)lk);
					if (!DS[dcs]) perror_(__LINE__,193,l);
					*DS[dcs]='\0';
					strncpy_(DS[dcs],op,lk);
					DSN[dcs]=l;
				}
				/* store quoted strings */
				else if (*q=='\"') {
					char op[COMPSTR], *P1=op;
					int lk;
					/* check if DATA space is full */
					if (dcs>=DATLIM-1) 
						perror_(__LINE__,97,l);
					q++;
					while (*q && *q!='\"') *P1++=*q++;
					*P1='\0';
					++dcs;
					lk=((int)strlen(op)+1)*sizeof(char);
					if (DS[dcs]!=NIL) {
						free(DS[dcs]);
						DS[dcs]=NIL;
					}
					DS[dcs]=xmalloc((size_t)lk);
					if (!DS[dcs]) perror_(__LINE__,193,l);
					*DS[dcs]='\0';
					strncpy_(DS[dcs],op,lk);
					DSN[dcs]=l;
					if (*q=='\"') q++;
				}
				/* store numbers; Note: in DATA statements 
				 * formulas are accepted (they must begin
				 * with a number in order to be recognized as
				 * "numbers" and not as "unquoted strings") */
				else if (*q) {
					/* check if space is over */
					if (dc>=DATLIM-1)perror_(__LINE__,97,l);
					while (isblank(*q)) q++;
					++dc;
					p=q, D[dc]=S(), q=p, DN[dc]=l;
				}
				while (isblank(*q)) q++;
				/* discard apostrophe comment */
				if (*q=='\'') while (*q) q++;
				/* check if datum is followed by
				 * something else than a comma */
				if (*q && *q==',') q++;
				else if (*q) perror_(__LINE__,144,l);
			}
			continue;
		}
		/* DECLARE must call SUB() */
		else if (bonecomp(q,"DECLARE")) {
			q+=8;
			while (isblank(*q)) q++;
			/* DECLARE SUB statements - delegate SUB() */
			if (bonecomp(q,"SUB")) {
				char *x=J;
				p=q+4;
				stripBlanks(p,x); p=J;
				SUB(l); 
				continue;
			}
		}
		/* PROGRAM/TITLE must be masked 
		 * Note: this is the only statement directly executed
		 * into preParse() */
		else if ((cn=recog(3,q,"PROGRAM","TITLE","_TITLE")) && l==1) {
			char text[COMPSTR], *t=text;
			q+=cn;
			while (isblank(*q)) q++;
			if (*q=='\"') q++;
			while (*q && *q!='\"') *t++=*q++;
			*t='\0';
			fprintf(stdout,"%s\n\n\n",text);
			fm[l]=TRUE;
		}
		/* SUB statements - delegate SUB() */
		else if (bonecomp(q,"SUB")) {
			char *x=J;
			p=q+4;
			stripBlanks(p,x); p=J;
			SUB(l); 
			continue;
		}
		/* DEF statements - delegate DEF() */
		else if (!strncasecmp_(q,"DEF",3)) {
			char *x=J;
			p=q+3;
			stripBlanks(p,x); p=J;
			DEF(l); 
			continue;
		}
		/* OPTION statements */
		else if (strcasestr_oq(q,"OPTION")) {
			q+=6;
			/* OPTION HEADER 
			 * option header must be detected before execution */
			if ((qq=strcasestr_oq(q,"HEADER"))) {
				thisisHeader=TRUE;
			}
			/* OPTION VINTAGE
			 * whimsical option for those who remember the dear old
			 * days...
			 * OPTION VINTAGE rends the behaviour and aspect of 
			 * programs in monitors of first Seventies; it sets the 
			 * following parameters:
			 * ANGLE RADIANS, BASE 0, CAPS ON, CASE OFF, DEBUG OFF,
			 * COMPARISON RELATIVE, HEADER ON, PRECISION OFF, 
			 * PROMPT ON, RESET TRUE, TIMING ON, ZERO OFF, 
			 * RAW PRINT OFF, SPACING OFF, ROUTING OFF,  
			 * EXPLICIT OFF, FORMAT AMERICAN
			 * Note: since the header should be written before any 
			 * output, this option is intercepted here, and may so 
			 * be written anywhere, but any other instance of 
			 * OPTION may alter the parameters, so you should avoid 
			 * them (unless this is what you want, of course...). 
			 * Note ECHO is executed directly by OPTION ECHO and 
			 * OPTION PAGING is executed directly by OPTION PAGING.
			 */
			if ((qq=strcasestr_oq(q,"VINTAGE"))) {
				doVintage(VINTAGESET);
				thisisHeader=TRUE;
			}
		}
		/* FILES statements - delegate FFILE() 
		 * Note: this is the actual execution of the FILES instruction, 
		 * which in runtime is effectively a no-op*/	
		else if (!strncasecmp_(q,"FILES",5)) {
			char *x=J;
			p=q+5;
			stripBlanks(p,x); p=J;
			FFILE(TRUE,l);
			continue;
		}
		/* FOR must correspond to a NEXT statement */
		else if (bonecomp(q,"FOR")) {
			int bl=l+1, wcount=0;
			while (bl<=end) {
				if (m[bl]==NIL) { bl++; continue; }
				q=m[bl];
				if (bonecomp(q,"FOR")) 
					wcount++;
				else if (wcount && !strncasecmp_(q,"NEXT",4)) {
					wcount--;
					/* count commas to know how many
					 * variables are in the same NEXT */
					while (*q && *q!='\'') 
						if (*q++==',') wcount--;
					if (wcount<0) wcount=0, bl--;
				}
				else if (!wcount && !strncasecmp_(q,"NEXT",4)){
					cAddr[l]=forAddr[l]=bl+1;
					cAddr[bl]=forAddr[bl]=l;
					break;
				}
				bl++;
			}
			if (bl>end) perror_(__LINE__,29,l);
			continue;
		}
		/* WHEN ERROR IN must correspond to a USE statement 
		 * Note: controls the missing END WHEN and delegate other
		 * error-catching to the WHEN ERROR functions */
		else if (checkCommand(q,"WHEN ERROR IN",&q)) {
			int cuse=0, bl=l+1;
			/* search for USE */
			while (bl<=end) {
				if (m[bl]!=NIL && !strncasecmp_(m[bl],"USE",3)){
					cAddr[l]=bl;
					whenAddr[l]=bl;
					cuse=bl;
					break;
				}
				bl++;
			}
		        if (!cuse) perror_(__LINE__,164,l);	
			/* search for END WHEN */
			bl++;
			while (bl<=end) {
				q=m[bl];
				if (m[bl]!=NIL&&checkCommand(q,"END WHEN",&q)){
					cAddr[cuse]=bl;
					whenAddr[cuse]=bl;
					cAddr[bl]=l;
					whenAddr[bl]=l;
					break;
				}
				bl++;
			}
		        if (bl>end) perror_(__LINE__,166,l);
			continue;
		}
		/* WHEN ERROR USE must correspond to a END WHEN statement 
		 * Note: controls the missing END WHEN and delegate other
		 * error-catching to the WHEN ERROR functions */
		else if (checkCommand(q,"WHEN ERROR USE",&q)) {
			int bl=l+1;
			while (bl<=end) {
				q=m[bl];
				if (m[bl]!=NIL&&checkCommand(q,"END WHEN",&q)){
					cAddr[l]=bl;
					whenAddr[l]=bl;
					cAddr[bl]=l;
					whenAddr[bl]=l;
					break;
				}
				bl++;
			} 
		        if (bl>end) perror_(__LINE__,166,l);	
			continue;
		}
		/* HANDLER must correspond to an END HANDLER statement;
		 * also, fill the handler data 
		 * Note: controls the missing END HANDLER and delegate other
		 * error-catching to the HANDLER function */
		else if (bonecomp(q,"HANDLER")) {
			int bl=l+1, hnlen;
			char hname[COMPSTR], *h=hname;
			q+=8; hnlen=0;
			/* get handler name */
			while (isblank(*q)) q++;
			while (*q) *h++=*q++;
			*h='\0';
			handlerTOS++;
			while (bl<=end) {
				if (m[bl]==NIL) {
					bl++;
					continue;
				}
				else if (!strncasecmp_(m[bl],"END",3) && (int)strlen(m[bl])>6 && !strcasecmp(m[bl]+(int)strlen(m[bl])-7,"HANDLER")) {
					cAddr[l]=handlerAddr[l]=bl;
					cAddr[bl]=handlerAddr[bl]=l;
					break;
				}
				bl++;
			}
		        if (bl>end) perror_(__LINE__,165,l);	
			handler[handlerTOS].pos=l;
			handler[handlerTOS].endwhenpos=bl;
			hnlen=((int)strlen(hname)+1)*sizeof(char);
			if (handler[handlerTOS].hname!=NIL) {
				free(handler[handlerTOS].hname);
				handler[handlerTOS].hname=NIL;
			}
			handler[handlerTOS].hname=xmalloc((size_t)hnlen);
			if (!handler[handlerTOS].hname) {
				perror_(__LINE__,174,l);
			}
			else strncpy_(handler[handlerTOS].hname,hname,hnlen);
			continue;
		}
		/* WHILE must correspond to an END WHILE statement
		 * Note: controls the missing END WHILE and delegate other 
		 * error-catching to the WHILE functions */
		else if (bonecomp(q,"WHILE")) {
			int bl=l+1, wcount=0;
			while (bl<=end) {
				if (m[bl]==NIL) { bl++; continue; }
				q=m[bl];
				if (bonecomp(q,"WHILE")) 
					wcount++;
				else if (wcount && checkCommand(q,"END WHILE",&q))
					wcount--;
				else if (wcount && !strncasecmp_(q,"WEND",4))
					wcount--;
				else if (!wcount && checkCommand(q,"END WHILE",&q)){
					cAddr[l]=whileAddr[l]=bl;
					cAddr[bl]=whileAddr[bl]=l;
					break;
				}
				else if (!wcount && !strncasecmp_(q,"WEND",4)) {
					cAddr[l]=whileAddr[l]=bl;
					cAddr[bl]=whileAddr[bl]=l;
					break;
				}
				bl++;
			}
			if (bl>end) perror_(__LINE__,28,l);
			continue;
		}
		/* DO WHILE/UNTIL must correspond to a LOOP statement
		 * Note: controls the missing UNTIL and  delegate other
		 * error-catching to the DO WHILE/UNTIL functions */
		else if (!strcasecmp(q,"DO") || bonecomp(q,"DO")) {
			int bl=l+1, wcount=0;
			while (bl<=end) {
				if (m[bl]==NIL) { bl++; continue; }
				if (!strcasecmp(m[bl],"DO") || bonecomp(m[bl],"DO"))
					wcount++;
				else if (wcount && !strncasecmp_(m[bl],"LOOP",4))
					wcount--;
				else if (!wcount && !strncasecmp_(m[bl],"LOOP",4)){
					cAddr[l]=doAddr[l]=bl;
					cAddr[bl]=doAddr[bl]=l;
					break;
				}
				bl++;
			}
			if (bl>end) perror_(__LINE__,28,l);
			continue;
		}
		/* SELECT and CASE must correspond to an END SELECT statement
		 * Note: controls the missing END SELECT and  delegate other 
		 * error-catching to the SELECT/CASE functions */
		else if (!strcasecmp(q,"SELECT") || bonecomp(q,"SELECT")) {
			int bl=l+1, wcount=0, endpos=0;
			/* look for end*/
			while (bl<=end) {
				if (m[bl]==NIL) {
					bl++;
					continue;
				}
				q=m[bl];
				if (bonecomp(q,"SELECT"))
					wcount++;
				else if (wcount && checkCommand(q,"END SELECT",&q))
					wcount--;
				else if (!wcount && checkCommand(q,"END SELECT",&q)){
					cAddr[l]=selectAddr[l]=bl;
					cAddr[bl]=selectAddr[bl]=l;
					break;
				}
				bl++;
			}
			endpos=bl;
			if (bl>end) perror_(__LINE__,27,l);
			bl=l+1; wcount=0;
			/* now bl is the END SELECT pos: set up CASE */
			while (bl<=end) {
				if (m[bl]==NIL) {
					bl++;
					continue;
				}
				q=m[bl];
				if (!strncasecmp_(q,"SELECT",6))
					wcount++;
				else if (wcount && checkCommand(q,"END SELECT",&q))
					wcount--;
				else if (!wcount && !strncasecmp_(q,"CASE",4))
					cAddr[bl]=selectAddr[bl]=endpos;
				else if (!wcount && checkCommand(q,"END SELECT",&q)){
					break;
				}
				bl++;
			}
			continue;
		}
		/* IF THEN must correspond to an END IF statement
		 * Note: controls the missing END IF and delegate other 
		 * error-catching to the IF THEN functions */
		else if (bonecomp(q,"IF") && (int)strlen(q)>4 && !strcasecmp(q+(int)strlen(q)-4,"THEN")) {
			/* only for clauses IF..THEN followed by spaces/EOL */
			int bl=l+1, wcount=0, endpos=0, elsepos=0;
			/* look for closing END IF */
			while (bl<=end) {
				if (m[bl]==NIL) {
					bl++;
					continue;
				}
				/* found another IF */
				if (bonecomp(m[bl],"IF") && (int)strlen(m[bl])>6 && !strcasecmp(m[bl]+(int)strlen(m[bl])-4,"THEN")) {
					wcount++;
				}
				/* found an END IF of an inner IF */
				else if (wcount && checkCommand(m[bl],"END IF",&q)) 
					wcount--;
				/* found the right END IF */
				else if (!wcount && checkCommand(m[bl],"END IF",&q)) {
					cAddr[bl]=ifAddr[bl]=l;
					break;
				}
				bl++;
			}
			endpos=bl;
			if (bl>end) perror_(__LINE__,26,l);
			bl=endpos-1;
			wcount=0; 
			elsepos=endpos;
			cAddr[endpos]=ifAddr[endpos]=l;
			/* now bl is the END IF pos: set up every ELSE 
			 * to point to next ELSE/END */
			while (bl>=l) {
				if (m[bl]==NIL) {
					bl--;
					continue;
				}
				if (checkCommand(m[bl],"END IF",&q)) {
					 wcount++;
				}
				if (wcount && bonecomp(m[bl],"IF") && (int)strlen(m[bl])>3 && !strcasecmp(m[bl]+(int)strlen(m[bl])-4,"THEN")) {
					wcount--;
				}
				else if (!wcount && !strncasecmp_(m[bl],"ELSE",4)) {
					cAddr[bl]=ifAddr[bl]=elsepos; 
					elsepos=bl;
				}
				else if (!wcount && bonecomp(m[bl],"IF") && (int)strlen(m[bl])>3 && !strcasecmp(m[bl]+(int)strlen(m[bl])-4,"THEN")){
					cAddr[bl]=ifAddr[bl]=elsepos;
				}
				bl--;
			}
			continue;
		}
		/* restore the tick comment */
		if (inlin) *inlin='\'';
	} while (l<=end+1);
	
	/* restore original lines */
	for (i=1;i<=endCore;i++) {
		if (ig[i]>1) {
			strncpy_(m[i],g[i],ig[i]);
		}
	}
	
	/* debug feature */
	if (isDebug) {
		int i,some=0;
		if (isInvDebug) printf(INVCOLOR);
		printf("\n");
		printf("debug: crossed references:");
		for (i=start;i<=end;i++) {
			if (cAddr[i]) {
				some++;
				if (!strncasecmp_(m[i],"FOR",3))
					printf("\nref.#%d = %s ==> #%d (%s)\n",i,m[i],cAddr[i]-1,m[cAddr[i]-1]);
				else 
					printf("\nref.#%d = %s ==> #%d (%s)\n",i,m[i],cAddr[i],m[cAddr[i]]);
			}
		}
		if (some) printf("\n\n");
		else printf(" none.\n\n");
		if (isInvDebug) printf(RESETCOLOR);
	}
	
	/* debug feature for handlers */
	if (isDebug && handlerTOS>0) {
		int i;
		if (isInvDebug) printf(INVCOLOR);
		for (i=1;i<=handlerTOS;i++) 
		printf("handler #%d has pos %d, end pos %d, and name %s.\n",
				i, handler[i].pos, handler[i].endwhenpos,
				handler[i].hname!=NIL?handler[i].hname:" ");
		printf("\n");
		if (isInvDebug) printf(RESETCOLOR);
	}

	/* set up starting parameters for READ */
	dataLimit=dc,   dc=1;
	dataLimitS=dcs, dcs=1;

	/* print header in after all option cases */
	if (!isHeader && thisisHeader) printHeader();
	if (!startInteractive) isHeader=thisisHeader;
}


/* recog() 
 * checks a command against a list of commands
 * num: the number of the list of arguments (after the source)
 * the first argument in the list must be a char* which is interpreted as
 * the source argument (variable length)
 * the following arguments are the list of commands 
 * return the number of characters in the selected command, or zero if
 * not found 
 * System command for the getFunc() function */
int recog(int num, ...) {
	va_list ap;
	int i=0, ret=0, l=0;
	char *c, *s;

	va_start(ap, num);
	s=va_arg(ap,char*); // source
	while (i<num) {
		c=va_arg(ap, char*); // next item
		l=(int)strlen(c);
		if (!strncasecmp_(s,c,l)) ret=l;
		i++;
	}
	va_end(ap);
	return ret;
}


/* parse()
 * The parser 
 * It's a general purpose routine that executes lines contained into the m 
 * line-memory buffer, from the 'start' line to the 'end' line 
 * System basic function */
void parse(char **m, int start, int end) {
	char BASESTR[COMPSCR]; // don't make it global, it must be local

	/* check/set starting parameters */
	if (!end) return;
	l=start;
	
	/* execute line by line */
	while(l<=end) {
		/* skip empty or masked lines in memory */
		if (m[l] && !fm[l] && *m[l]) {
			strncpy_(BASESTR,m[l],COMPSCR);
			if ((isInterrupt || isEndOfStatement)) 
				break;
			parseLine(BASESTR,l);
		}
		l++;
	}
}


/* parseLine()
 * The single line parser 
 * It's a general purpose routine that executes one line contained into s 
 * (a line-memory buffer), and using sline as current execution physical line 
 * number.
 * (Note for me: the stripBlanks (s,B) returns in B the stripped copy of s, 
 * which is the pad created in parse;
 * the strncpy_(s,B) returns in s the copy of B (which is a global pad); 
 * now, never change this, because tbas cannot work on B, since other uses it!)
 * System basic function */
int parseLine(char *s, int sline) {
	char base[COMPSTR], *B=base;
	/* skip formatting lines */
	while (isblank(*s)) s++;
	if (*s==':') return TRUE;
	/* skip starting tick comments */
	if (*s=='\'') return TRUE;

	/* skip void lines */
	if (!*s && !ln[sline]) return TRUE;

	/* strip blanks if out of string (checked into stripBlanks)
	 * buffer B will hold purged execution line */
	optoken(s);
	stripBlanks2(s,B);	// don't change!
	silenceTick(B);

	/* DEBUGGING PURPOSES - print pure/stripped line */
	if (isDebug && (m[sline]!=NIL && m[sline][0])) {
		if (isInvDebug) fprintf(stdout,INVCOLOR);
		if (!debugRaw) {
			if (ln[sline]) 
			   fprintf(stdout,"\n[%-5d %s] ",ln[sline],m[sline]);
			else fprintf(stdout,"\n[      %s] ",m[sline]);
		}
		else {
			if (ln[sline]) 
			   fprintf(stdout,"\n[%-5d %s] ",ln[sline],B);
			else fprintf(stdout,"\n[      %s] ",B);
		}
		if (isInvDebug) fprintf(stdout,RESETCOLOR);
		fprintf(stdout,"\n");
	}
	
	p=B;
	/* maybe it's a statement (or a SUB call): 
	 * process it through exec() */ 
	if (exec(p));
	/* maybe it's an (implicit) assignment: call multiLET() */
	else if (multiLET());
	/* otherwise it's an illegal instruction 
	 * Note: the return FALSE statements are called only if the 
	 * interactive session is active, to avoid printing the error 
	 * message by perror_() */
	else if (!isExplicit) {
		if (!isSingleBASICCommand) perror_(__LINE__,44,l);
		else perror_(__LINE__,163,l);
		return FALSE;
	}
	else {
		perror_(__LINE__,40,l);
		return FALSE;
	}
	/* OK. Sure result */
	return TRUE;
}


/* exec()
 * the statement execution subroutine (the core of the engine, which calls
 * all the statements references in order to execute the commands)
 * lpc is the address of the execution line (the first character after the
 * line number)
 * return TRUE if execution goes well, FALSE otherwise
 * Note: all statements executed in preParse, are here simple no-op, as well
 * as comment statements REM and ' (tick)
 * Note: in future versions, I'm thinking about a tokenization
 * of all instructions, that should make tbas faster 
 * System basic function */
int exec(char* lpc) {
	int ns, type, rettype;
	char *lpr;
	if (*lpc=='\0'); // nop for void lines
	/* check if statement is a SUB */
	else if ((ns=findSUB(lpc,&lpr,&type,&rettype))) {
		if (type!=PROC) perror_(__LINE__,211,l);
		execSUB(ns,lpr,&numRes,NIL);
	}
	else if (!strncasecmp_(lpc,"ABORT",5)) p=lpc+5, ABORT();
	else if (!strncasecmp_(lpc,"ACCEPT#",7)) p=lpc+7,FREADSHARP(1,1);
	else if (!strncasecmp_(lpc,"ACCEPT",6)) p=lpc+6, INPUT(0);
	else if (!strncasecmp_(lpc,"APPEND",6)) p=lpc+6, FAPPEND();
	else if (!strncasecmp_(lpc,"BREAK",5)) p=lpc+5, BREAK();
	else if (!strncasecmp_(lpc,"CALL",4)) p=lpc+4, DOCALL();
	else if (!strncasecmp_(lpc,"CASE",4)) {
		lpc+=4;
		if (isblank(*lpc)) lpc++; 
		if (!strcasecmp(lpc,"DEFAULT")) CASEDEFAULT();
		else if (!strcasecmp(lpc,"ELSE")) CASEDEFAULT();
		else p=lpc, CASE();
	}
	else if (!strncasecmp_(lpc,"CAUSEERROR",10)) p=lpc+10, CAUSEERROR();
	else if (!strncasecmp_(lpc,"CHAIN",5)) {
		p=lpc+5; 
		CHAIN(); 
		return TRUE; 
	}
	else if (!strncasecmp_(lpc,"CHANGE",6)) p=lpc+6, CHANGE(); 
	else if (!strncasecmp_(lpc,"CLEAR",5)) p=lpc+5,TCLEAR();
	else if (!strncasecmp_(lpc,"CLS",3)) p=lpc+2,CLS();
	else if (!strncasecmp_(lpc,"CLOSE",5)) p=lpc+5,FCLOSE();
	else if (!strncasecmp_(lpc,"COLOR",5)) p=lpc+5, COLOR();
	else if (!strncasecmp_(lpc,"COMMAND",7)) p=lpc+7, COMMAND(); 
	else if (!strncasecmp_(lpc,"COMMON",6)) p=lpc+6, TCOMMON(); 
	else if (!strncasecmp_(lpc,"CONSTANT",8)) p=lpc+8,DECLARE(TRUE);
	else if (!strncasecmp_(lpc,"CONST",5)) p=lpc+5,DECLARE(TRUE);
	else if (!strncasecmp_(lpc,"CONTINUE",8)) p=lpc+8, DOCONTINUE();
	else if (!strncasecmp_(lpc,"COPY",4)) p=lpc+4, COPY();
	else if (!strncasecmp_(lpc,"DATA",4)); //no-op
	else if (bonecomp(lpc,"DECLARE")) {
		lpc+=8;
		if (isblank(*lpc)) lpc++;
		if (!strncasecmp_(lpc,"SUB",3)); //no-op
		else p=lpc, DECLARE(FALSE);
	}
	else if (!strncasecmp_(lpc,"DEF",3)) {
		/* Multiple line DEFs cannot be nested */
		if (isDefRun) perror_(__LINE__,46,l);
	}
	else if (!strncasecmp_(lpc,"DIM",3)) {
		p=lpc=lpc+3;
		if (!strncasecmp_(lpc,"ENSION",6)) p=lpc=lpc+6;
		DECLARE(FALSE);
	}
	else if (!strncasecmp_(lpc,"DOUNTIL",7)) p=lpc+7, DOUNTIL();
	else if (!strncasecmp_(lpc,"DOWHILE",7)) p=lpc+7, DOWHILE();
	else if (!strncasecmp_(lpc,"DO",2)) {
		lpc+=2;
		if (isblank(*lpc)) lpc++; 
		if (!strncasecmp_(lpc,"UNTIL",5)) p=lpc+5, DOUNTIL();
		else if (!strncasecmp_(lpc,"WHILE",5)) p=lpc+5, DOWHILE();
		else if (!*lpc); // no-op;
		else return FALSE;
	}
	else if (bonecomp(lpc,"ELSEIF")) p=lpc+7, ELSEIF();
	else if (!strncasecmp_(lpc,"ELSE",4)) ELSE();
	else if (!strcasecmp(lpc,"ENDHANDLER")) ENDHANDLER();
	else if (!strcasecmp(lpc,"ENDIF")) ENDIF();
	else if (!strcasecmp(lpc,"ENDSELECT")) ENDSELECT();
	else if (!strcasecmp(lpc,"ENDSUB")); // no-op
	else if (!strcasecmp(lpc,"ENDWHEN")) ENDWHEN();
	else if (!strcasecmp(lpc,"ENDWHILE")) ENDWHILE();
	else if (!strcasecmp(lpc,"END")) END(EXIT_SUCCESS);
	else if (!strncasecmp_(lpc,"ENTER",5)) p=lpc+5, INPUT(1);
	else if (!strncasecmp_(lpc,"ERASE",5)) p=lpc+5,ERASE();
	else if (!strncasecmp_(lpc,"ERRPRINT",8)) {
		p=lpc+8;
		channel[CONSOLE].stream=stderr;
		PRINT(TRUE);
		channel[CONSOLE].stream=stdout;
	}
	else if (!strncasecmp_(lpc,"EXEC",4)) p=lpc+4,EXEC();
	else if (!strncasecmp_(lpc,"EXITSUB",7)) p=lpc+7, EXITSUB();
	else if (!strcasecmp(lpc,"EXITHANDLER")) EXITHANDLER();
	else if (!strcasecmp(lpc,"EXITWHEN")) EXITWHEN();
	else if (!strncasecmp_(lpc,"EXIT",4)) p=lpc+4, EXIT(0);
	else if (!strncasecmp_(lpc,"EXPORT",6)) p=lpc+6,EXPORT();
	else if (!strncasecmp_(lpc,"FILES",5)); //no-op
	else if (!strncasecmp_(lpc,"FILE",4)) p=lpc+4,FFILE(FALSE,l); 
	else if (!strncasecmp_(lpc,"FILLPAGE",8)) p=lpc+8,FFILLPAGE(); 
	else if (!strcasecmp(lpc,"FNEND")); // no-op
	else if (bonecomp(lpc,"FOR")) p=lpc+4,FOR();
	else if (!strncasecmp_(lpc,"FREE",4)) p=lpc+4, FSCRATCH();
	else if (!strncasecmp_(lpc,"GET",3)) p=lpc+3, DOGET();
	else if (!strncasecmp_(lpc,"GO",2)) {
		lpc+=2;
		if (isblank(*lpc)) lpc++;
		if (!strncasecmp_(lpc,"SUB",3)) {
			lpc+=3;
			if (isblank(*lpc)) lpc++;
			p=lpc; GOSUB();
		}
		else if (!strncasecmp_(lpc,"TO",2)) {
			lpc+=2;
			if (isblank(*lpc)) lpc++;
			p=lpc; GOTO();
		}
		else return FALSE;
	}
	else if (bonecomp(lpc,"HANDLER")) p=lpc+8,HANDLER();
	else if (bonecomp(lpc,"IF")) p=lpc+3, IFTHEN();
	else if (!strncasecmp_(lpc,"IMAGE",5)); // no-op
	else if (!strncasecmp_(lpc,"INCLUDE",7)) p=lpc+7, INCLUDE();
	else if (!strncasecmp_(lpc,"INPUT:",6)) p=lpc+6, FREADCOLON();
	else if (!strncasecmp_(lpc,"INPUT#",6)) p=lpc+6, FREADSHARP(1,0);
	else if (!strncasecmp_(lpc,"INPUT",5)) p=lpc+5, INPUT(1);
	else if (!strncasecmp_(lpc,"JUMP",4)) p=lpc+4, JUMP();
	else if (!strncasecmp_(p=lpc,"LET",3) && multiLET());
	else if (!strncasecmp_(lpc,"LIBRARY",7)) p=lpc+7, OPENASLIBRARY(p);
	//else if (!strncasecmp_(lpc,"LINEINPUT#",10)) p=lpc+10,FREADSHARP(1,1);
	else if (!strncasecmp_(lpc,"LINEINPUT#",10)) p=lpc+10,LINPUTSHARP();
	else if (!strncasecmp_(lpc,"LINEINPUT",9)) p=lpc+9, INPUT(0);
	else if (!strncasecmp_(lpc,"LINPUT#",7)) p=lpc+7,LINPUTSHARP();
	else if (!strncasecmp_(lpc,"LINPUT",6)) p=lpc+6, INPUT(0);
	else if (!strncasecmp_(lpc,"LINEPRINT",9)) p=lpc+9, LPRINT();
	else if (!strncasecmp_(lpc,"LOCATE",6)) p=lpc+6, LOCATE();
	else if (!strncasecmp_(lpc,"LPRINT",6)) p=lpc+6, LPRINT();
	else if (!strncasecmp_(lpc,"LOOPWHILE",9)) p=lpc+9,LOOPWHILE();
	else if (!strncasecmp_(lpc,"LOOPUNTIL",9)) p=lpc+9,LOOPUNTIL();
	else if (!strcasecmp(lpc,"LOOP")) p=lpc+4,LOOP();
	else if (!strncasecmp_(lpc,"LINEREAD#",9)) p=lpc+9,FREADSHARP(0,1);
	else if (!strncasecmp_(lpc,"LREAD#",6)) p=lpc+6,FREADSHARP(0,1);
	else if (!strncasecmp_(lpc,"MARGIN",6)) p=lpc+6, FMARGIN();
	else if (!strncasecmp_(lpc,"MATINPUT#",9)) p=lpc+9, MATFINPUT(FALSE);
	else if (!strncasecmp_(lpc,"MATINPUT",8)) p=lpc+8, MATINPUT(0,FALSE);
	else if (!strncasecmp_(lpc,"MATPRINT#",9)) p=lpc+9, MATFPRINT(FALSE);
	else if (!strncasecmp_(lpc,"MATPRINT",8)) p=lpc+8, MATPRINT(0,FALSE);
	else if (!strncasecmp_(lpc,"MATWRITE#",9)) p=lpc+9, MATFPRINT(TRUE);
	else if (!strncasecmp_(lpc,"MATINPUT",8)) p=lpc+8, MATINPUT(0,FALSE);
	else if (!strncasecmp_(lpc,"MATREAD#",8)) p=lpc+8, MATFINPUT(TRUE);
	else if (!strncasecmp_(lpc,"MATREAD",7)) p=lpc+7, MATREAD();
	else if (!strncasecmp_(lpc,"MAT",3)) p=lpc+3, MATtype();
	else if (!strncasecmp_(lpc,"NEXT",4)) p=lpc+4, NEXT();
	else if (!strncasecmp_(lpc,"NODATA",6)) p=lpc+6, NODATA();
	else if (!strncasecmp_(lpc,"NOMARGIN",8)) p=lpc+8, FNOMARGIN();
	else if (!strncasecmp_(lpc,"NOPAGENUM",9)) p=lpc+9, FPAGENUM(FALSE);
	else if (!strncasecmp_(lpc,"NOPAGE",6)) p=lpc+6, FNOPAGE();
	else if (!strncasecmp_(lpc,"NOQUOTE",7)) p=lpc+7,FQUOTE(NOQUOTE);
	else if (!strncasecmp_(lpc,"ONATTENTION",11)) p=lpc+11, ONATTENTION();
	else if (!strncasecmp_(lpc,"ONERROR",7)) p=lpc+7, ONERROR();
	else if (!strncasecmp_(lpc,"ON",2)) p=lpc+2, ONGOTO();
	else if (!strncasecmp_(lpc,"OPEN",4)) p=lpc+4, FOPEN();
	else if (!strncasecmp_(lpc,"OPTION",6)) p=lpc+6, OPTION();
	else if (!strncasecmp_(lpc,"PAGENUM",7)) p=lpc+7, FPAGENUM(TRUE);
	else if (!strncasecmp_(lpc,"PAGE",4)) p=lpc+4, FPAGE();
	else if (!strncasecmp_(lpc,"PIPE",4)) p=lpc+4, FPIPE();
	else if (!strncasecmp_(lpc,"PREPEND",7)) p=lpc+7, FPREPEND();
	else if (!strncasecmp_(lpc,"PRINTUSING#",11)) 
		p=lpc+11, FWRITEUSINGSHARP(TRUE,TRUE,0);
	else if (!strncasecmp_(lpc,"PRINTUSING",10)) 
		p=lpc+10, FWRITEUSINGSHARP(TRUE,FALSE,0);
	else if (!strncasecmp_(lpc,"PRINT",5)) p=lpc+5, PRINT(TRUE);
	else if (!strncasecmp_(lpc,"PUT",3)) p=lpc+3, DOPUT();
	else if (!strncasecmp_(lpc,"QUEUE",5)) p=lpc+5, QUEUE();
	else if (!strncasecmp_(lpc,"QUOTE",5)) p=lpc+5, FQUOTE(QUOTE);
	else if (!strncasecmp_(lpc,"RANDOMIZE",9)) p=lpc+9, RANDOMIZE();
	else if (!strncasecmp_(lpc,"READ:",5)) p=lpc+5, FREADCOLON();
	else if (!strncasecmp_(lpc,"READ#",5)) p=lpc+5, FREADSHARP(0,0);
	else if (!strncasecmp_(lpc,"READ",4)) p=lpc+4, READ();
	else if (!strncasecmp_(lpc,"REDIM",5)) p=lpc+5,REDIM();
	else if (!strncasecmp_(lpc,"REM",3)) {
		char *pragma=lpc+3;
		if (!strncasecmp_(pragma,"ARK",3)) pragma+=3;
		while (isblank(*pragma)) pragma++;
		/* execute PRAGMA line */
		if (!strncasecmp_(pragma,"PRAGMA",6) && !startInteractive) {
			pragma+=6;
			evalPragma(pragma);
		}
		/* no-op for any other REM commment */
	}
	else if (!strncasecmp_(lpc,"RESET",5)) p=lpc+5, RESTORE();
	else if (!strncasecmp_(lpc,"RESTORE#",8)) p=lpc+7, FRESTORE();
	else if (!strncasecmp_(lpc,"RESTORE:",8)) p=lpc+7, FRESTORE();
	else if (!strncasecmp_(lpc,"RESTORE",7)) p=lpc+7, RESTORE();
	else if (!strncasecmp_(lpc,"RESUME",6)) p=lpc+6, RESUME();
	else if (!strncasecmp_(lpc,"RETRY",5)) p=lpc+5, RETRY();
	else if (!strcasecmp(lpc,"RETURN")) _RETURN();
	else if (!strncasecmp_(lpc,"RETURN",6)) p=lpc+6,_RETURNTOSUB();
	else if (!strncasecmp_(lpc,"ROUTE",5)) p=lpc+5,ROUTE();
	else if (!strncasecmp_(lpc,"SCRATCH",7)) p=lpc+7, FSCRATCH();
	else if (!strncasecmp_(lpc,"SELECT",6)) {
		lpc+=6;
		if (isblank(*lpc)) lpc++;
		p=lpc;	SELECT();
	}
	else if (!strncasecmp_(lpc,"SETDIGITS",9)) p=lpc+9, SETDIGITS();
	else if (!strncasecmp_(lpc,"SET",3)) p=lpc+3, FSET();
	else if (!strncasecmp_(lpc,"STOP",4)) END(EXIT_STOP);
	else if (!strncasecmp_(lpc,"SUB",3)); // no-op
	else if (!strncasecmp_(lpc,"SWAP",4)) p=lpc+4, SWAP();
	else if (!strncasecmp_(lpc,"SYSTEM",6)) END(EXIT_SYSTEM);
	else if (!strncasecmp_(lpc,"UPDATE",6)) p=lpc+6, FUPDATE();
	else if (!strncasecmp_(lpc,"USE",3)) p=lpc+3, USE();
	else if (!strncasecmp_(lpc,"USING",5)) p=lpc+5, USING();
	else if (!strncasecmp_(lpc,"WAIT",4)) p=lpc+4, DOWAIT();
	else if (!strcasecmp(lpc,"WEND")) ENDWHILE();
	else if (!strncasecmp_(lpc,"WHENERROR",9)) p=lpc+9, WHENERROR();
	else if (bonecomp(lpc,"WHILE")) p=lpc+6, WHILE();
	else if (!strncasecmp_(lpc,"WRITEUSING#",11)) 
		p=lpc+11, FWRITEUSINGSHARP(FALSE,TRUE,0);
	else if (!strncasecmp_(lpc,"WRITEUSING",10)) 
		p=lpc+10, FWRITEUSINGSHARP(TRUE,FALSE,0);
	else if (!strncasecmp_(lpc,"WRITE",5)) p=lpc+5, PRINT(FALSE);
	else return FALSE;
	return TRUE;
}


/******************************************
 * INTERACTIVE SESSION functions 
 *****************************************/

/* Here follow algorithms and functions that make the interactive session work. 
 * Thanks to Tom Lake, who conceived the idea that started it all. */

/* reorder()
 * reorder numbered program lines using the quicksort algorithm
 * Watch out! This must be used only with startInteractive=TRUE */
void reorder(int first, int last){
	int i, j, pivot, temp;
	char *ep;

	if(first<last){
		pivot=first;
		i=first;
		j=last;

		while(i<j){
			while(ln[i]<=ln[pivot] && i<last) i++;
			while(ln[j]>ln[pivot]) j--;
			if(i<j){
				temp=ln[i];
				ep=m[i];
				ln[i]=ln[j];
				m[i]=m[j];
				ln[j]=temp;
				m[j]=ep;
			}
		}

		temp=ln[pivot];
		ep=m[pivot];
		ln[pivot]=ln[j];
		m[pivot]=m[j];
		ln[j]=temp;
		m[j]=ep;
      		reorder(first,j-1);
      		reorder(j+1,last);
	}
}


/* _clean()
 * clean memory ad-usum interactive session */
void _clean(void) {
	int i;
	for (i=0;i<MEMLIMIT;i++) {
		if (m[i]!=NIL && (int)strlen(m[i])>0) {
			free(m[i]);
			m[i]=NIL;
		}
		ln[i]=0;
	}
	removeLibs();
	endCore=libStart=0;
}


/* _addline()
 * add a line to memory, contained into comm, overwriting existing or
 * removing a line if the line number is alone 
 * Note: if addline_() returns FALSE, there is a memory problem. */
int _addline(char *text) {
	int i=0, num=0, was=0, len=0;
	char *p;

	if (!text && !*text) return TRUE;
	p=text;
	
	/* get line number */
	while (isblank(*p)) p++;
	num=strtol(p,&p,10);

	/* empty sharp-commented lines */
	while (isblank(*p)) p++;
	if (*p=='#') {
		*p++=' ';
		*p--='\0';
	}

	/* reject irregular lines */
	if (num<1) return FALSE;

	/* search if line with num already exists */
	for (i=1; i<=endCore; i++) {
		if (ln[i]==num) {
			was=i;
			break;
		}
	}

	/* get addition data */
	if (p && *p) len=strlen(p);

	/* substitute line */
	if (was && len>0) {
		if (m[was] && *m[was]) free(m[was]);
		m[was]=xmalloc(len+1);
		if (!m[was]) return FALSE;
		strncpy_(m[was],p,len+1);
		return TRUE;
	}

	/* erase line */
	if (was) {
		ln[was]=0;
		if (m[was] && *m[was]) free(m[was]);
		m[was]=NULL;
		/* exchange 'was' (which is now empty) and endCore
		 * but not if was==endCore */
		if (was!=endCore) {
			int temp=0;
			char *ep;
			temp=ln[was];
			ep=m[was];
			ln[was]=ln[endCore];
			m[was]=m[endCore];
			ln[endCore]=temp;
			m[endCore]=ep;
		}
		/* eclude last (void) line */
		endCore--;
		return TRUE;
	}

	/* none of the above: add line */
	endCore++;
	ln[endCore]=num;
	m[endCore]=xmalloc(len+1);
	if (!m[endCore]) return FALSE;
	strncpy_(m[endCore],p,len+1);
	return TRUE;
}


/* getExt()
 * cut buffer removing extension, and put extension in ext 
 * Used in the interactive session */
void getExt(char *buffer, char *ext) {
	char *p=buffer;
	int c=0;
	while (*p) c++, p++; // get the end of the string
	while (*p!='.' && c>0) c--,p--; // get to the extension dot
        if (c>0) {
		strcpy(ext,p+1);
		*p='\0';
	}
	else strcpy(ext,"");	
}	


/* isDirectory() 
 * TRUE if path is a directory
 * Used in the interactive sessions */
int isDirectory(const char *path) {
	struct stat statbuf;
	if (stat(path, &statbuf) != 0) return FALSE;
	return S_ISDIR(statbuf.st_mode);
}


/* bjoin()
 * file name manupulation:
 * - add UNIX or Windows dir separator
 * - join add to res 
 * - remove trailing blanks at the end */
void bjoin(char *res, char *add) {
	strncpy(res,basedir,4*COMPSTR-1);
	if (basedir[strlen(basedir)-1]!='/') strncat(res,"/",4*COMPSTR-1);
	strncat(res,add,4*COMPSTR-1);
	while (isblank(*(res+strlen(res)-1))) *(res+strlen(res)-1)='\0';
}


/* doCat()
 * perform the CAT command, basing on uext (user ext, which may be NULL) and
 * on isCaseSensitive;
 * Return FALSE in case of some error, TRUE otherwise */
int doCat(char *uext, int isCaseSensitive) {
	DIR* FD;
	struct dirent* in_file;
	struct stat info;
	char buffer[4*COMPSTR];
	char ext[4*COMPSTR];
	char lpath[4*COMPSTR];
	char fileout[4*COMPSTR];
	int isDire=FALSE;
	int isAll=FALSE;
	int l=strlen(uext);
	int screencount=0, maxlen=0, ck=0;

	/* setting for all files */
	if (!strlen(uext) && isCaseSensitive) isDire=isAll=TRUE;
	if (!strlen(uext) && !isCaseSensitive) isDire=TRUE;

	/* Checking base directory */
	if (NULL == (FD = opendir (basedir))) {
        	return FALSE;
    	}
	/* get maximum file length */
	while ((in_file = readdir(FD))) {
		if (maxlen<strlen(in_file->d_name))
			maxlen=strlen(in_file->d_name);
	}
	closedir(FD);

	/* for all directories in the directory */
	if (isDire) {
		int tp=0;
		/* Checking base directory (now we know the dir exists) */
		FD = opendir (basedir);
		fprintf(stdout,"\nCatalog of %s\n",basedir);
		fprintf(stdout,"- Selection of directories -\n\n");
		while ((in_file = readdir(FD))) {
        		/* Avoid current and parent directories */ 
			if (!strcmp(in_file->d_name, ".")) continue;
        		if (!strcmp(in_file->d_name, "..")) continue;
			bjoin(lpath,in_file->d_name);
			/* proceed only if it is a directory */
			if (stat(lpath, &info)==0) {
			       	if (info.st_mode & S_IFDIR) {
					sprintw(fileout,37,"%s/",in_file->d_name);
					fprintf(stdout,"%-36s",fileout);
					tp++; 
					if (!(tp&1)) fprintf(stdout,"\n");
				}
			}
		}
		closedir(FD);
		fprintf(stdout,"\n");
		if (!isAll) return TRUE;
	}

	/* determine cell width */
	ck=(int)(SCRLIM/maxlen);
	ck=(int)(SCRLIM/ck); // cell key

	/* for all files in the directory setup extension */
	if (!isCaseSensitive) {
		int i;
		strcat(uext,"/");
		for (i=l+1;i<2*l+1;i++)
			uext[i]=toupper(uext[i-l-1]);
		uext[2*l+1]='\0';
	}
	/* Checking base directory */
	FD = opendir (basedir);
	fprintf(stdout,"\nCatalog of %s\n",basedir);
	fprintf(stdout,"- Selection of %s files -\n\n",isAll?"all":uext);
	screencount=0;
	while ((in_file = readdir(FD))) {
        	/* Avoid current and parent directories */ 
		if (!strcmp(in_file->d_name, ".")) continue;
        	if (!strcmp(in_file->d_name, "..")) continue;
        	/* Avoid system hidden files */ 
        	if (!strncmp(in_file->d_name, ".",1)) continue;
		bjoin(lpath,in_file->d_name);
		/* proceed only if not a directory */
		if (stat(lpath, &info)==0) {
			if (!(info.st_mode & S_IFDIR)) {
				strncpy(buffer,in_file->d_name,4*COMPSTR-1);
				if (!buffer[0]) continue;
				getExt(buffer,ext);
				if (isAll) strcpy(uext,ext);
		        	/* print name if it matches the extension */
				if (strlen(ext)) {
					sprintw(fileout,ck-strlen(ext)-1,"%s",buffer);
					strcat(fileout,".");
					strcat(fileout,ext);
				}
				else sprintw(fileout,ck,"%s",in_file->d_name);
				strcat(fileout,spaces(ck-strlen(fileout)));
				if (isCaseSensitive) {
					if (!strncmp(uext,ext,l)) {
						fprintf(stdout,"%s",fileout);
						screencount+=ck;
						if (screencount>=SCRLIM) {
							fprintf(stdout,"\n");
							screencount=0;
						}
					}
				}
				else {
					if (!strncasecmp(uext,ext,l)) {
						fprintf(stdout,"%s",fileout);
						screencount+=ck;
						if (screencount>=SCRLIM) {
							fprintf(stdout,"\n");
							screencount=0;
						}
					}
				}
			}
		}
	}
	closedir(FD);
	fprintf(stdout,"\n");
	
	/* happy conclusion */
	return TRUE;
}


/* Exists()
 * TRUE if fn is a regular existing textual file
 * Used in the interactive session */
int Exists(char *fn) {
	FILE *f=fopen(fn,"r");
	if (f) {
		fclose(f);
		return TRUE;
	}
	return FALSE;
}


/* checkDir()
 * TRUE if dir is a directory and it exists
 * USed in the interactive session */
int checkDir(char *dir) {
	DIR* FD;
	if (NULL == (FD = opendir (dir))) {
        	return FALSE;
    	}
	closedir(FD);
	return TRUE;
}


/* unixCD()
 * perform the CD for the UNIX/Mac world 
 * System function for the shell command CD */
int unixCD(char *usercomm) {
	while (isblank(*usercomm)) usercomm++;
	/* go to original directory */
	if (!*usercomm) {
		strcpy(basedir,BASEDIR);
		chdir(basedir);
	}
	/* go back one place */
	else if (!strcmp(usercomm,"..")) {
		int c=strlen(basedir);
		char *q=basedir+c-1;
		if (*q=='/') q--;
		while (*q!='/' && c>0) q--, c--;
		/* the dir is consumed, use base */
		if (c==0) strcpy(basedir,"/");
		else *q='\0'; // remove last dir
		chdir(basedir);
	}
	/* go to $HOME */
	else if (!strcmp(usercomm,"~")) {
		struct passwd *pw = getpwuid(getuid());
		strcpy(basedir,pw->pw_dir);
		chdir(basedir);
	}
	/* user request begins with slash: substitute directory */
	else if (*usercomm=='/') {
		strcpy(basedir,usercomm);
		chdir(basedir);
		return checkDir(basedir);
	}
	/* user request is a plain path: add to current */
	else {
		char temp[4*COMPSTR];
		strcpy(temp,basedir);
		bjoin(temp,usercomm);
		if (checkDir(temp)) {
			strcpy(basedir,temp);
			chdir(basedir);
		}
		else return FALSE;
	}
	/* default true for the three basic types */
	return TRUE;
}


/* winCD()
 * perform the CD for the Windows� world 
 * System function for the shell command CD */
int winCD(char *usercomm) {
	/* go to original directory */
	if (!*usercomm) {
		strcpy(basedir,BASEDIR);
		chdir(basedir);
	}
	/* go back one place */
	else if (!strcmp(usercomm,"..")) {
		int c=strlen(basedir);
		char *q=basedir+c;
		while (*q!='\\' && c>0) q--, c--;
		/* the dir is consumed, use base */
		if (*(q-1)==':') *(q+1)='\0'; // if in C:\ remain there
		else *q='\0'; // remove last dir
		chdir(basedir);
	}
	/* go to main directory of current drive */
	else if (!strcmp(usercomm,"~")) {
		char *q=basedir;
		while (*q!=':') q++;
		*(q+1)='\\';
		*(q+2)='\0';
		chdir(basedir);
	}
	/* user request begins with drive letter + colon: substitute dir */
	else if (*(usercomm+1)==':') {
		strcpy(basedir,usercomm);
		chdir(basedir);
		return checkDir(basedir);
	}
	/* user request is a plain path: add to current */
	else {
		char temp[4*COMPSTR];
		strcpy(temp,basedir);
		bjoin(temp,usercomm);
		if (checkDir(temp)) {
			strcpy(basedir,temp);
			chdir(basedir);
		}
		else return FALSE;
	}
	/* default true for the three basic types */
	return TRUE;
}


/* setExt()
 * solve the missing extension; first check for fn existence;
 * if fn is not found, try appending bas, then try BAS.
 * if fn is found, don't append anything */
void setExt(char *fn) {
	char tf[4*COMPSTR];
	strcpy(tf,fn); // back copy
	if (Exists(fn)) {
		return;
	}
	strcat(fn,".bas");
	if (Exists(fn)) {
		return;
	}
	strcpy(fn,tf); // restore for retry
	strcat(fn,".BAS");
	if (Exists(fn)) {
		return;
	}
	strcpy(fn,tf); // restore for return
}


/* patch()
 * change first occurrence of string occ in string str, and patches
 * the content of subst as a line number, restoring what follows 
 * return updated position of str 
 * Used in the CONVERT/RENUM shell commands 
 * System function for convert() */
void patch(char *str, char *occ, int subst) {
	char temp[COMPSTR], dest[COMPSTR];
	char *p=strstr(str,occ)+strlen(occ);
	strcpy(temp,p); // copy rest
	p-=strlen(occ);
	*p='\0'; // erase from occurrence
	sprintw(dest,COMPSTR,"%d",subst);
	strcat(str,dest); // add subst
	strcat(str,temp);  // add rest
}


/* combine()
 * pass through the list of old references lb[] and search for the
 * label in q; if found, execute the patching (substituting the new
 * occurrence to text in memory m[]) 
 * return updated position of q */
void combine(char *q, char *lb[], int c) {
	int i=1;
	while (i<=endCore) {
		if (strlen(lb[i])>0 && !strncmp(lb[i],q,strlen(lb[i]))) {
			if (!isdigit(*(q+strlen(lb[i])))) {
				patch(m[c],lb[i],ln[i]);
				break;
			}
		}
		i++;
	}
}


/* convert()
 * load a program with unnumbered-lines and convert it in memory to a 
 * numbered-lines program; lines can thus be saved with SAVE into a 
 * regular numbered-lines program
 * Rules:
 * - output lines start from 100 and have step 10
 * - colon label are saved as tick comments (they must stand on their own line)
 * - existing line numbers are treated as alpha labels and converted
 * This procedure works also as a renumbering tool
 * fn is the file name id to load, fs is the file where to save
 * n and s are the starting line and the step for renumbering */
int convert(FILE *fn, int n, int s) {
	int c=0, i=0;
	/* reset reading */
	rewind(fn);

	/* count lines */
	while(fgets(B,SCREENLINE+9,fn)) i++;

	/* define the hosting structure */
	char *lb[i+1];

	/* reset reading */
	rewind(fn);
	endCore=c=0;

	/* FIRST STEP: find references and setup labels */
	/* load next line */
	while(fgets(B,SCREENLINE+9,fn)) {
		char *p;
		p=B;
		if (*p<32 && !isblank(*p)) continue;
		if (*(p+strlen(p)-1)=='\r') *(p+strlen(p)-1)='\0';
		if (*(p+strlen(p)-1)=='\n') *(p+strlen(p)-1)='\0';
		if (*(p+strlen(p)-1)=='\r') *(p+strlen(p)-1)='\0';
		c++;
		while (isblank(*p)) p++;
		/* remove trailing ending spaces */
		while (isblank(*(p+strlen(p)-1))) *(p+strlen(p)-1)='\0';
		/* empty sharp-commented lines */
		if (*p=='#') {
			*p++=' ';
			*p--='\0';
		}
		/* if line contains an alpha label, store the label name into
		 * m[] (as ' label) and into lb[] */
		if (*(p+strlen(p)-1)==':') {
			*(p+strlen(p)-1)='\0'; // remove colon
			lb[c]=xmalloc(strlen(p)+10);
			if (!lb[c]) return FALSE;
			strcpy(lb[c],p);
			if (m[c]!=NIL && (int)strlen(m[c])>0) free(m[c]);
			m[c]=xmalloc(strlen(p)+10);
			if (!m[c]) return FALSE;
			strcpy(m[c],"' ");
			while (isblank(*p)) p++;
			strcat(m[c],p);
		}
	       	/* if line begins with a digit, store it into lb[], 
		 * store the rest (trailing blanks excluded) into m[] 
		 * Note: if nothing or only blanks follow, 
		 * store a blanked line */
		else if (isdigit(*p)) {
			char *w;
			lb[c]=xmalloc(strlen(p)+10);
			if (!lb[c]) return FALSE;
			w=lb[c];
			while (isblank(*p)) p++;
			while (*p=='0') p++; // skip starting zeroes
			while (isdigit(*p)) *w++=*p++;
			*w='\0';
			if (m[c]!=NIL && (int)strlen(m[c])>0) free(m[c]);
			m[c]=xmalloc(strlen(p)+10);
			if (!m[c]) return FALSE;
			while (isblank(*p)) p++;
			if (!*p) strcpy(m[c],"     ");
			else strcpy(m[c],p);
		}
		/* else, store the null string in lb[], store line into m[] */	
		else {
			lb[c]=xmalloc(2);
			if (!lb[c]) return FALSE;
			strcpy(lb[c],"");
			if (m[c]!=NIL && (int)strlen(m[c])>0) free(m[c]);
			m[c]=xmalloc(strlen(p)+10);
			if (!m[c]) return FALSE;
			while (isblank(*p)) p++;
			strcpy(m[c],p);
		}
		/* put n in ln[], advance n by s */
		ln[c]=n;
		n+=s;
		endCore++;
	}

	/* SECOND STEP: update inner jumps in the source */
	c=1;
	while (c<=endCore) {
		char *q=m[c];
		int d=0;
		while (isblank(*q)) q++;
		/* avoid tick comments */
		if (*q=='\'') {
			c++;
			continue;
		}
		/* avoid REM comments */
		if (!strncasecmp_(q,"REM",3)) {
			c++;
			continue;
		}
		/* avoid OPTION comments */
		if (!strncasecmp_(q,"OPTION",6)) {
			c++;
			continue;
		}
		/* RESTORE occurrences */
		if ((q=strcasestr_oq(m[c],"RESTORE"))) {
			q+=7;
			/* ignore RESTORE #X */
			while (isblank(*q)) q++;
			if (*q=='#') {
				c++;
				continue;
			}
			while (isblank(*q)) q++;
			combine(q,lb,c);
		}
		/* THEN occurrences */
		else if ((q=strcasestr_oq(m[c],"THEN"))) {
			q+=4;
			while (isblank(*q)) q++;
			/* manage THEN GOTO */
			if (!strncasecmp(q,"GOTO",4)) {
				q+=4;
				while (isblank(*q)) q++;
			}
			combine(q,lb,c);
			/* ELSE occurrences after THEN in the same line */
			if ((q=strcasestr_oq(q,"ELSE"))) {
				q+=4;
				while (isblank(*q)) q++;
				/* manage THEN GOTO */
				if (!strncasecmp(q,"GOTO",4)) {
					q+=4;
					while (isblank(*q)) q++;
				}
				combine(q,lb,c);
			}
		}
		/* ON ATTENTION occurrences */
		else if ((q=strcasestr_oq_div(m[c],"ON","ATTENTION",&d))) {
			q+=d;
			while (isblank(*q)) q++;
			if (!strncasecmp_(q,"GOTO",4)) q+=4;
			else if (!strncasecmp_(q,"THEN",4)) q+=4;
			while (isblank(*q)) q++;
			combine(q,lb,c);
		}
		/* ON ERROR occurrences */
		else if ((q=strcasestr_oq_div(m[c],"ON","ERROR",&d))) {
			q+=d;
			while (isblank(*q)) q++;
			if (!strncasecmp_(q,"GOTO",4)) q+=4;
			else if (!strncasecmp_(q,"THEN",4)) q+=4;
			while (isblank(*q)) q++;
			combine(q,lb,c);
		}
		/* NO DATA occurrences */
		else if ((q=strcasestr_oq_div(m[c],"NO","DATA",&d))) {
			q+=d;
			while (isblank(*q)) q++;
			combine(q,lb,c);
		}
		/* PRINT USING / PRINT USING #X, occurrences */
		else if ((q=strcasestr_oq_div(m[c],"PRINT","USING",&d))) {
			q+=d;
			while (isblank(*q)) q++;
			if (*q=='#') {
				q++; // skip #
				while (isblank(*q)) q++;
				while (isdigit(*q)) q++;
				if (*q==',' || *q==';') q++;	
				while (isblank(*q)) q++;
			}
			combine(q,lb,c);
		}
		/* ON GOSUB/ON GOTO occurrences */
		else if (!strncmp(m[c],"ON",2)) {
			char *other=NULL;
			q=m[c]+2;
			while (isblank(*q)) q++;
			if ((q=strcasestr_oq(q,"GO"))) {
				q+=2;
				while (isblank(*q)) q++;
				if (!strncasecmp_(q,"TO",2)) q+=2;
				else if (!strncasecmp_(q,"SUB",3)) q+=3;
				else {
					c++;
					continue;
				}
			}
			while (isblank(*q)) q++;
			other=strcasestr_oq(m[c],"OTHERWISE");
			/* convert first value */
			combine(q,lb,c);
			/* OTHERWISE exists */
			if (other) {
				/* convert values up to otherwise */
				while (*q) {
					while (isblank(*q)) q++;
					while (*q && *q!=',') q++;
					q++; // skip comma
					while (isblank(*q)) q++;
					if (!*q || q>other) break;
					combine(q,lb,c);
				}
				/* convert the OTHERWISE label */
				while (isblank(*q)) q++;
				other+=9; // skip OTHERWISE
				combine(other,lb,c);
			}
			/* plain list without OTHERWISE */
			else  {
				/* convert values up to end of string */
				while (*q) {
					while (*q && *q!=',') q++;
					q++; // skip comma
					while (isblank(*q)) q++;
					if (!*q) break;
					combine(q,lb,c);
				}
			}
		}
		/* simple GOSUB occurrences */
		else if ((q=strcasestr_oq(m[c],"GOSUB"))) {
			q+=5;
			while (isblank(*q)) q++;
			combine(q,lb,c);
		}
		/* simple GOTO occurrences */
		else if ((q=strcasestr_oq_div(m[c],"GO","TO",&d))) {
			q+=d;
			while (isblank(*q)) q++;
			combine(q,lb,c);
		}
		c++;
	}
	libStart=endCore;
	return TRUE;
} // convert()


/* indent()
 * return a step forward or zero for LIST to indent forward of backward 
 * the listing with a step of 3 */
int indent(char *p, int mode) {
	/* stay on null line */
	if (p==NULL) return 0;
	if (!*p) return 0;
	if (strlen(p)<1) return 0;
	/* remove trailing spaces 
	 * Note: this is done in convert() and for LOAD but in any case... */
	while (isblank(*p)) p++;
	while (isblank(*(p+strlen(p)-1))) *(p+strlen(p)-1)='\0';
	/* forward move */
	if (mode) {
		if (!strncasecmp_(p,"WHILE",5)) return tind;
		if (!strncasecmp_(p,"WHEN",4)) return tind;
		if (!strncasecmp_(p,"DO",2)) return tind;
		if (!strncasecmp_(p,"SUB",3)) return tind;
		if (!strncasecmp_(p,"SELECT",6)) return tind;
		if (!strncasecmp_(p,"HANDLER",7)) return tind;
		if (!strncasecmp_(p,"ELSE",4)) return tind;
		if (!strncasecmp_(p,"USE",3)) return tind;
		if (!strncasecmp_(p,"CASE",4)) return tind;
		if (!strncasecmp_(p,"FOR",3)) return tind;
		if (!strncasecmp_(p,"DECLARE",7)) {
			p+=7;
			while (isblank(*p)) p++;
			if (!strncasecmp_(p,"SUB",3)) return tind;
		}
		if (!strncasecmp_(p,"IF",2)) {
			p+=2;
			while (*p && strncasecmp_(p,"THEN",4)) p++;
			if (!strncasecmp_(p,"THEN",4)) {
				p+=4;
				while (isblank(*p)) p++;
				if (!*p || *p=='\'') return tind;
			}
		}
	}
	/* backward move */
	else {
		if (!strncasecmp_(p,"END",3)) {
			p+=3;
			while (isblank(*p)) p++;
			if (!strncasecmp_(p,"HANDLER",7)) return tind;
			if (!strncasecmp_(p,"SELECT",6)) return 2*tind;
			if (!strncasecmp_(p,"WHILE",5)) return tind;
			if (!strncasecmp_(p,"WHEN",4)) return tind;
			if (!strncasecmp_(p,"SUB",3)) return tind;
			if (!strncasecmp_(p,"IF",2)) return tind;
		}
		if (!strncasecmp_(p,"USE",3)) {
			return tind;
		}
		if (!strncasecmp_(p,"ELSE",4)) {
			return tind;
		}
		if (!strncasecmp_(p,"NEXT",4)) {
			return tind;
		}
		if (!strncasecmp_(p,"LOOP",4)) {
			return tind;
		}
	}
	/* stay */
	return 0;
}


/* tf_completion()
 * readline completion function */
static char **tf_completion(const char *text, int start, int end) {
	rl_attempted_completion_over = 1;
	return rl_completion_matches(text, tf_generator);
}


/* _dupstr()
 * return a duplicate string of the shell command  */
char *_dupstr(char *name) {
        char *r, *br;
        r=xmalloc((strlen(name)+1)*sizeof(char)), br=r;
	while (*name) *br++=*name++;
	*br='\0';
	return r;
}


/* tf_generator()
 * readline generator function */
char* tf_generator(const char *text, int s) {
	static int h=-1;
	char com[COMPSTR];
	int len=strlen(text);
	strcpy(com,text);
	/* search string among commands and return all matches */
	while (h<=NAMESNUM) {
		h++;
		int res=(int)(!strncasecmp_(com,names[h],len));
		if (res) {
			rl_attempted_completion_function = NULL;
			return _dupstr(names[h]);
		}
	}
 	/* If no names matched, then return NULL. */
	h=-1;
	return ((char *)NULL);
}


/* pseg()
 * print segmented 
 * print string str in a space of 78 characters, 
 * taking care of not breaking words
 * System function for the APROPOS command */
void pseg(char *str) {
	char *b=str;
	char *pb, *pf;
	//char output[SEGLIM+2];
	int l=strlen(str);
	/* short circuit for small strings */
	if (l<=SEGLIM) {
		fprintf(stdout,"%s\n",str);
		return;
	}

	/* long strings */
	pf=pb=b;
	/* starting spaces must be printed */
	while (*pb && isblank(*pb)) fputc(*pb++,stdout), pf=pb;
	while (*pb) {
		if (*pb=='\n') {
			fputc('\n',stdout);
			b=pf=++pb;
			continue;
		}
		else {
			/* find next word */
			while (*pf && !isblank(*pf)) pf++;
			/* if limit was passed, reset to current word 
			 * as the starting word for the next line */
			if ((int)(pf-b)>SEGLIM) {
				fputc('\n',stdout);
				b=pf=pb;
			}
		}
		fputc(*pb++,stdout), pf=pb;
	}
}


/* list_indented()
 * list the program from start to end, to file ch
 * the range of lines to be considered is set by endCore (not to be confused
 * with the global endCore).
 * numbered specifies if the program is surely numbered;
 * mode specifies if zero-padded must be used (TRUE for zero-padded)*/
void list_indented(int numbered, int endCore, int start, int end, FILE *ch, int mode) {
	int i, offset=2;
	for (i=1; i<=endCore; i++) {
		int k;
		if (!m[i] || !*m[i]) continue;
		/* update backward offset */
		offset-=indent(m[i],0);
		/* manage backward offset for NEXT
		 * with multiple variables */
		if (!strncasecmp_(m[i],"NEXT",4)) {
			char *t=m[i]+4;
			/* scan line for commas */
			while (*t) {
				if (*t==',') offset-=tind;
				t++;
			}
		}
		/* manage backward offset for CASE */
		if (!strncasecmp_(m[i],"CASE",4)) {
			if (!selectDone) offset-=tind;
			selectDone=FALSE;
		}
		/* surely numbered line (this comes from an interactive 
		 * sessiion command LIST or SAVE */
		if(numbered){
			/* print the line only if in the required
			 * range specified by the user */
			if(ln[i]>=start && ln[i]<=end) {
				int isLib=FALSE;
				/* print label (which is a number) */
				if (mode) 
					fprintf(ch,"%05d",ln[i]);
				else 
					fprintf(ch,"% 5d",ln[i]);
				/* print current offset */
				for (k=0;k<offset;k++) fputc(' ',ch);
				/* print BASIC line */
				/* assure it's a LIBRARY line */
				if (!strncasecmp_(m[i],"LIBRARY",7))
					isLib=TRUE;
				else if (strcasestr_oq(m[i],"LIBRARY"))
					isLib=TRUE;
				if (isIncludingLibs && isLib)
					fprintf(ch, "REM %s\n",m[i]);
				else 
					fprintf(ch, "%s\n",m[i]);
			}
		}
		/* list indented; the label may or may not exist (it comes from
		 * option -L and may be used out of the interactive session */
		else {
			/* print label (which in this case is a number) */
			if (ln[i]) fprintf(ch,"% 5d",ln[i]);
			else fprintf(ch,"     ");
			/* print current offset */
			for (k=0;k<offset;k++) fputc(' ',ch);
			/* print BASIC line */
			if (isIncludingLibs && !strncasecmp_(m[i],"LIBRARY",7))
				fprintf(ch, "REM %s\n",m[i]);
			else 
				fprintf(ch, "%s\n",m[i]);
		}
		/* calculate the new forward offset */
		offset+=indent(m[i],1);
		/* manage the first CASE following SELECT 
		 * which sets an extra offset */
		if (!strncasecmp_(m[i],"SELECT",6)) 
		selectDone=TRUE;
	}
}


/* sessions_load()
 * file loader (whose name is in p) used by EDIT */
char *session_load(char *p) {
	char lpath[4*COMPSTR], *pb;
	char B[SCREENLINE+10];
	FILE *f;
	int regular=TRUE;
	/* find file name */
	while (isblank(*p)) p++;
	/* in case an argument is given, take it as the
	 * file name */
	if (*p) {
		/* remove final blanks and all quotes*/
		while (isblank(*(p+strlen(p)-1))) 
			*(p+strlen(p)-1)='\0';
		if (*p=='\"') p++;
		if (*(p+strlen(p)-1)=='\"') 
			*(p+strlen(p)-1)='\0';
		strncpy(filename,p,COMPSCR-1);
	}
	if (strlen(filename)<1) {
		fprintf(stderr,"\nError: Missing file name\n\n");
		printReady=FALSE;
		return NULL;
	}
	/* save following position */
	pb=p+strlen(filename);
	setExt(filename);
	bjoin(lpath,filename);
	/* clean memory */
	_clean();    // erases endCore
	/* open file (check if regular) */
	if (!(f=fopen(lpath,"r"))) {
		fprintf(stderr,"\nError: Couldn't find file %s\n\n",filename);
		printReady=FALSE;
		return NULL;
	}
	B[0]='\0';
	/* read lines and store them */
	while(fgets(B,SCREENLINE+9,f) && endCore<=MEMLIMIT) {
		if ((int)strlen(B)<1 || B[0]=='\n') continue;
		p=B;
		/* remove EOL */
		if (*(p+strlen(p)-1)=='\r') 
			*(p+strlen(p)-1)='\0';
		if (*(p+strlen(p)-1)=='\n') 
			*(p+strlen(p)-1)='\0';
		if (*(p+strlen(p)-1)=='\r') 
			*(p+strlen(p)-1)='\0';
		while (isblank(*p)) p++;
		while (isblank(*(p+strlen(p)-1))) 
			*(p+strlen(p)-1)='\0';
		/* check lines regularity (if they are all
		 * correctly numbered) */
		if ((int)strlen(p)>0 && *p!='\n') {
			if (*p<'0' || *p>'9') {
				regular=FALSE;
				break;
			}
		}
		/* delegate _addline() which updates endCore */
		if (!_addline(p)) {
			fprintf(stderr,"Error: memory exhausted.\n\n");
			printReady=FALSE;
			return NULL;
		}
		B[0]='\0';
	}
	if (!regular) {
		fprintf(stderr,"Error: not a numbered-lines BASIC file\n");
		fprintf(stderr,"Maybe you want CONVERT it, before loading?\n");
		printReady=FALSE;
		return NULL;
	}
	if (f) fclose(f);
	libStart=endCore;
	removeLibs();
	return p=pb;
} // session_load()


/* removeLibs()
 * erase libraries both from memory and from program */
void removeLibs(void) {
	int i;
	/* DEFFN functions*/
	for (i=0;i<LIMIT*2;i++) {
		fn[i].start=0;
		fn[i].end=0;
		fn[i].type=0;
		free(fn[i].def);
		fm[i]=0;
	}
	/* SUB */
	for (i=0;i<LIMIT*2;i++) {
		sn[i].number=0;
		sn[i].code=0;
		sn[i].type=0;
		sn[i].rettype=0;
		sn[i].start=0;
		sn[i].end=0;
		sn[i].name[0]='\0';
	}
	subCount=0;
	isDefCount=0;
	XCount=0;
	for (i=libStart+1;i<=endCore;i++) {
		if (m[i]!=NIL && (int)strlen(m[i])>0) {
			free(m[i]);
			m[i]=NIL;
		}
		ln[i]=0;
	}
	endCore=libStart;
}


/* goInt()
 * start a BASIC interactive session
 * Shell Commands / numbered lines as input / BASIC statements 
 * Note: in goInt() p must remain global! */
void goInt(void) {
	char cmd[COMPSTR], *comm;
	int cn=0;
	char prev[COMPSTR];
	double iBeginS=0, iEndS=0;
	/* set session defaults */
	gettimeofday(&tv, NULL);
       	iBeginS=((double)tv.tv_sec+tv.tv_usec/1000000.0);
	GETCWD(basedir,4*COMPSTR);
	strcpy(BASEDIR,basedir);
	prev[0]='\0';
	traceISval[0]='\0';
	/* readline stuff */
	read_history(HISTORY);
	/* read last history command */
	FILE* fd=fopen(HISTORY,"r");
	if (fd) while(fgets(prev,COMPSTR-1,fd)); // read all lines, keep last

	if (prev[strlen(prev)-1]=='\n') prev[strlen(prev)-1]=0;
	if (prev[strlen(prev)-1]=='\r') prev[strlen(prev)-1]=0;
	if (prev[strlen(prev)-1]=='\n') prev[strlen(prev)-1]=0;
	if (fd) fclose(fd);

	/* begin listening to user's requests */
	while (!isQuit) {
		/* reset interaction flags */
		printReady=TRUE;
		isSingleBASICCommand=FALSE;
		isEndOfStatement=FALSE;
		isInterrupt=FALSE;
		/* set readline completion to shell commands */
		if (implicitRUN) {
			strcpy(cmd,"RUN");
			implicitRUN=FALSE;
		}
		else {
			rl_attempted_completion_function = tf_completion;
	       		comm=readline(prompt);
			if (!comm) continue;
			if (!*comm) continue;
			if (*comm==EOF) continue;
			if (comm && *comm) {
				//rl_replace_line(comm,0);
				if (strncasecmp_(prev,comm,strlen(comm))) 
					add_history(comm);
				strncpy_(prev,comm,COMPSTR);
			}
			/* copy readline command into a safe memory 
			 * location (cmd) */
			while (isblank(*comm)) comm++;
			strncpy_(cmd,comm,COMPSTR);
		}
		comm=cmd;
		/*** ABBREVIATIONS ***/
		if (!strcasecmp(comm,"L")) strcpy(comm,"LIST");
		else if (!strcasecmp(comm,"LS")) strcpy(comm,"LIST"); // undoc
		else if (!strcasecmp(comm,"R")) strcpy(comm,"RUN");
		else if (!strcasecmp(comm,"S")) strcpy(comm,"SYSTEM");
		else if (!strcasecmp(comm,"Q")) strcpy(comm,"QUIT");
		else if (!strcasecmp(comm,"MEM")) strcpy(comm,"MEMORY");
		else if (!strcasecmp(comm,"MON")) strcpy(comm,"MONITOR");
		else if (!strcasecmp(comm,"SYS")) strcpy(comm,"SYSTEM");
		else if (!strcasecmp(comm,"LOGOFF")) strcpy(comm,"BYE");
		else if (!strcasecmp(comm,"GOODBYE")) strcpy(comm,"BYE");
		else if (!strncasecmp_(comm,"START",5)) strcpy(comm,"RUN");
		else if (!strncasecmp_(comm,"GSAVE",5)) {
			char temp[COMPSTR];
			strcpy(temp,comm+5);
			strcpy(comm,"SAVE WITH LIBS");
			strcat(comm,temp);
		}
		else if (!strcasecmp(comm,"GOO")) strcpy(comm,"BYE");
		else if (!strcasecmp(comm,"YE")) strcpy(comm,"BYE"); // undoc
		else if (!strcasecmp(comm,"B")) strcpy(comm,"BYE");
		else if (!strncasecmp_(comm,"HELP",4)) {
			char *pp=comm+4;
			while (isblank(*pp)) pp++;
			if (*pp) {
				char tcomm[COMPSTR];
				strcpy(tcomm,"APROPOS ");
				strcat(tcomm,pp);
				strcpy(comm,tcomm);
			}
			else strcpy(comm,"HELP");
		}
		/* mistyping */
		else if (!strncasecmp_(comm,"LSIT",4)) {
			comm[1]='I';
			comm[2]='S';
		}
		else if (!strncasecmp_(comm,"LAOD",4)) {
			comm[1]='O';
			comm[2]='A';
		}
		/*** COMMANDS ***/
		/* RESET (color) */
		if (!strncasecmp_(comm,"RESET",5)) fprintf(stderr,RESETCOLOR);
		/* SYSTEM */
		else if (!strncasecmp_(comm,"SYSTEM",6)) {
			char *t=comm+6, *q=sysqueue;
			*q='\0';
			if (*t) {
				while (isblank(*t)) t++;
				while (*t) *q++=*t++;
				*q='\0';
				isSystem=TRUE;
			}
			isQuit=TRUE;
		}
		/* BYE */
		else if (!strncasecmp_(comm,"BYE",3)) isQuit=TRUE;
		/* QUIT */
		else if (!strncasecmp_(comm,"QUIT",4)) isQuit=TRUE;
		/* ? (PRINT) */
		else if (*comm=='\?') {
			char despaced[COMPSTR];
			stripBlanks(comm+1, despaced);
			p=despaced;
			PRINT(TRUE);
		}
		/* HELP */
		else if (!strncasecmp_(comm,"HELP",4)) {
 			fprintf(stdout," Interactive session commands, NOT available as BASIC statements\n\n");
 			fprintf(stdout," %sn CCCC%s        - store CCCC at line n as a program line\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sAPROPOS CCCC%s  - print the manual content of the CCCC command\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sASPECT CCCC%s   - set up listing mode (arguments: SPACE,ZERO)\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sAUTO [n,s]%s    - start automated input from line n with step s\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sBYE%s           - end session\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sCAT [ext][*]%s  - list files in current working directory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sCD [name]%s     - change directory to \"name\" (.. and ~ are available)\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sCLEAN%s         - erase variables references\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sCONTINUE%s      - continue program after a user interrupt\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sCONVERT name%s  - convert unnumbered file \"name\" and load it\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sDELETE [n-m]%s  - delete lines in the program\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sDUMP%s          - dump the ASCII codes of the program lines\n",BLUECOLOR,RESETCOLOR);
			fprintf(stdout," %sFIND CCCC%s     - print program lines which contain CCCC\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sGLIST%s         - list zero-padded unindented the program and the libraries\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sGOTO n%s        - equivalent to RUN n, but without clearing variables\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sGSAVE [name]%s  - save program+libs to file \"name\" (with path)\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sHELP%s          - print this help page\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sINDENT [n]%s    - set the indentation level for LIST and SAVE\n",BLUECOLOR,RESETCOLOR);
			fprintf(stdout," %sLIBS%s          - list libraries in memory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sLIST [n-m]%s    - list the program in memory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sLIST0 [n-m]%s   - list unindented the program in memory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sLOAD name%s     - load file \"name\" (with path) erasing previous content \n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sMEMORY%s        - memory status report\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sMERGE name%s    - merge program \"name\" (with path) with current in memory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sMONITOR%s       - temporary exit to shell. Type exit to return to BASIC\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sNEW%s           - erase program memory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sPROMPT CCCC%s   - set CCCC as prompt\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sPWD%s           - print working directory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sQUIT%s          - end session\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sRELEASE%s       - erase current program file name\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sRENAME CCCC%s   - rename current program\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sRENUM [n,s]%s   - renumber all lines starting from n, using step s\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sRESET%s         - restore normal color (in case inversion as active)\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sRUN [n]%s       - run program in memory\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sRUNQ [n]%s      - run program in memory and exit tbas\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sSAVE [name]%s   - save program to file \"name\" (with path)\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sSHELL CCCC%s    - send CCCC to the underlying shell environment\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sSYSTEM%s        - end session\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sTRACE CCCC%s    - enable or disable debugging basing on CCCC\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %sTYPE name[*]%s  - print content of \"name\" (with path)\n",BLUECOLOR,RESETCOLOR);       
 			fprintf(stdout," %sUNTRACE%s       - disable debugging\n",BLUECOLOR,RESETCOLOR);
 			fprintf(stdout," %s?%s             - fast synonym of PRINT\n",BLUECOLOR,RESETCOLOR);       
 			fprintf(stdout,"\n Arguments enclosed in square brackets may be omitted in certain cases;\n");       
 			fprintf(stdout," 'name' is a file name, while 'CCCC' is a string; both can be enclosed\n in double quotes if needed;\n");       
 			fprintf(stdout," 'n', 'm' and 's' are numeric values identifying program lines;\n");       
 			fprintf(stdout," the asterisk '*' performs special operations on the arguments list;\n");       
 			fprintf(stdout," File arguments without any root path are searched in the current\n working directory. Happy programming with tbas!\n");
		}
		/* RUN */
		else if (!strncasecmp_(comm,"RUN",3)) {
			int start=ln[1], i;
			char *p=comm+3;
			int isQ=FALSE;
			startingLine=1;
			removeLibs();
			reorder(1,libStart);
			if (*p=='Q' || *p=='q') {
				p++;
				isQ=TRUE;
			}
			while (isblank(*p)) p++;
			if (*p) {
				/* if RUN is followed by a string different 
				 * from "--" and different from a literal
				 * number, use it as the argument for 
				 * the implicit LOAD */
				if (strcmp(p,"--") && !isdigit(*p)) {
					int status;
					char fn[COMPSTR], *fl=fn;
					while (*p && *p!=',' && !isblank(*p))
						*fl++=*p++;
					*fl='\0';
					status=LOAD(m,fn,0,ALL_LINES);
					if (status) {
						printReady=FALSE;
						continue;
					}
					strcpy(filename,fn);
					while (isblank(*p)) p++;
					if (*p==',') p++;
					while (isblank(*p)) p++;
					/* re-establish limits */
					start=ln[1];
					startingLine=1;
					reorder(1,libStart);
				}
				/* if RUN is followed by a number 
				 * take it as the starting line */
				if (isdigit(*p)) {
					start=strtol(p,&p,10);
					for (i=1;i<=endCore;i++)
						if (ln[i]>=start) break;
					startingLine=i;
				}
				/* if RUN is then followed by --, consider 
				 * what follows suitable for COMMANDS$ input */
				else if (!strncmp(p,"--",2)) {
					char *cm=command_string;
					p+=2;
					while (isblank(*p)) p++;
					while (*p) *cm++=*p++;
					*cm='\0';
				}
			}
			fprintf(stdout,"\n\n");
			isToReset=TRUE;
			if (isHeader) printHeader();
			RUN(); // clears variables and calls preParse()
			if (isTiming) {
				fprintf(stdout,"\n\n\n");
				timedString(endS);
				fprintf(stdout,"\n");
			}
			fprintf(stdout,"\n");
			if (isQ) isQuit=TRUE;
		}
		/* RELEASE  */
		else if (!strncasecmp_(comm,"RELEASE",7)) {
			strncpy(filename,"",COMPSCR-1);
		}
		/* RENAME  */
		else if (!strncasecmp_(comm,"RENAME",6)) {
			char *p=comm+6, lpath[4*COMPSTR];
			/* in case an argument is given, take it as the
			 * new system file name */
			while (isblank(*p)) p++;
			if (*p) {
				/* remove final blanks and all quotes*/
				while (isblank(*(p+strlen(p)-1))) 
					*(p+strlen(p)-1)='\0';
				if (*p=='\"') p++;
				if (*(p+strlen(p)-1)=='\"') 
					*(p+strlen(p)-1)='\0';
				strncpy(filename,p,COMPSCR-1);
				if (strncasecmp_(filename+strlen(filename)-4,".BAS",4) && strncasecmp_(filename+strlen(filename)-4,".TXT",4) && strncasecmp_(filename+strlen(filename)-4,".txt",4) && strncasecmp_(filename+strlen(filename)-4,".bas",4)) 
					strcat(filename,".bas");
				bjoin(lpath,filename);
			}
			else {
				fprintf(stderr,"\nError: Missing name for RENAME.\n\n");
				printReady=FALSE;
				continue;
			}
			fprintf(stdout,"\n");
		}
		/* LIBS  */
		else if (!strncasecmp_(comm,"LIBS",4)) {
			int i;
			int isDFlag=isInvDebug;
			isInvDebug=FALSE;
			fprintf(stdout,"\n");
			fprintf(stdout,"Total SUBs: %d\n\n",subCount);
			for (i=1; i<=subCount; i++) showSUB(i,FALSE);
			fprintf(stdout,"Total DEFs: %d\n",isDefCount);
			for (i=1; i<=isDefCount; i++) showDEF(i,FALSE);
			isInvDebug=isDFlag;
		}
		/* CONTINUE (session) */
		else if ((cn=recog(2,comm,"CONT","CONTINUE"))) {
			isCont=TRUE;
			fprintf(stdout,"\n");
			isToReset=isInterrupt=isEndOfStatement=FALSE;
			parse(m,l,endCore);
			fprintf(stdout,"\n");
			isCont=FALSE;
			continue;
		}
		/* GOTO */
		else if (!strncasecmp_(comm,"GOTO",4)) {
			int start=ln[1], i;
			char *p=comm+4;
			isToReset=FALSE;
			reorder(1,libStart);
			startingLine=0;
			while (isblank(*p)) p++;
			if (*p) {
				start=strtol(p,&p,10);
				/* Error: not a number */
				if (*p) {
					fprintf(stderr,"\nError: Wrong argument for GOTO!\n\n");
					printReady=FALSE;
					continue;
				}
				for (i=1;i<=endCore;i++)
					if (ln[i]>=start) break;
				startingLine=i;
			}
			else if (!startingLine) {
				fprintf(stderr,"\nError: Missing starting line for GOTO!\n\n");
				printReady=FALSE;
				continue;
			}
			fprintf(stdout,"\n");
			isToReset=FALSE;
			RUN(); // calls preParse() and doesn't clear variables
			fprintf(stdout,"\n");
		}
		/* RENUM(BER)/RES(EQUENCE) */
		else if ((cn=recog(2,comm,"RENUM","RES"))) {
			FILE *f;
			char *p=comm+cn;
			int i=0, n=100, s=10;
			if (cn==5 && !strncasecmp_(p,"BER",3)) p+=3;
			else if (cn==3 && !strncasecmp_(p,"EQUENCE",7)) p+=7;
			else if (*p && !isblank(*p)) {
				fprintf(stderr,"\n%s\n\n",error[163]);
				printReady=FALSE;
				continue;
			}
			while (isblank(*p)) p++;
			if (isdigit(*p)) {
				n=strtol(p,&p,10);
				if (n<1) n=100;
			}
			while (isblank(*p)) p++;
			if (*p==',') {
				p++;
				while (isblank(*p)) p++;
				s=strtol(p,NULL,10);
				if (s<1) s=10;
			}
			/* open file */
			if (!(f=fopen("tbas_temp.bas","w"))) {
				fprintf(stderr,"\nError: Couldn't save temporary file for RENUM\n\n");
				printReady=FALSE;
				continue;
			}
			/* store program lines in a temporary file */
			for (i=1;i<=libStart;i++) {
				if (m[i] && strlen(m[i])>0) {
					fprintf(f,"%05d %s\n",ln[i],m[i]);
				}
			}
			/* close file */
			fclose(f);
			/* reopen file */
			if (!(f=fopen("tbas_temp.bas","r"))) {
				fprintf(stderr,"\nError: Couldn't find temporary file for RENUM\n\n");
				printReady=FALSE;
				continue;
			}
			/* proceed with conversion */
			if (convert(f,n,s));
			else {
				fprintf(stderr,"\nError: Couldn't accomplish the renumbering\n\n");
				printReady=FALSE;
				continue;
			}
			fclose(f);
			/* remove temporary file */
			remove("tbas_temp.bas");
		}
		/* CONVERT */
		else if (!strncasecmp_(comm,"CONV",4)) {
			char *p=comm+4, lpath[4*COMPSTR];
			FILE *f;
			if (!strncasecmp(p,"ERT",3)) p+=3;
			/* find file name */
			while (isblank(*p)) p++;
			/* in case an argument is given, take it as the
			 * file name */
			if (*p) {
				/* remove final blanks and all quotes*/
				while (isblank(*(p+strlen(p)-1))) 
					*(p+strlen(p)-1)='\0';
				if (*p=='\"') p++;
				if (*(p+strlen(p)-1)=='\"') 
					*(p+strlen(p)-1)='\0';
				strncpy(filename,p,COMPSCR-1);
			}
			if (strlen(filename)<1) {
				fprintf(stderr,"\nError: Missing file name\n\n");
				printReady=FALSE;
				continue;
			}
			setExt(filename);
			bjoin(lpath,filename);
			/* clean memory */
			_clean();    // erases endCore
			removeLibs();
			/* open file */
			if (!(f=fopen(lpath,"r"))) {
				fprintf(stderr,"\nError: Couldn't find file %s\n\n",filename);
				printReady=FALSE;
				continue;
			}
			if (convert(f,100,10));
			else {
				fprintf(stderr,"\nError: Couldn't convert file %s\n\n",filename);
				printReady=FALSE;
				continue;
			}
			isIncludingLibs=FALSE;
			libStart=endCore;
			if (f) fclose(f);
		}
		/* INDENT */
		else if (!strncasecmp_(comm,"INDENT",6)) {
			p=comm+6;
			while (isblank(*p)) p++;
			if (!strcasecmp(p,"OFF")) tind=0;
			else if (*p && !isdigit(*p)) {
				fprintf(stderr,"\nError: Wrong indentation value %s\n\n",p);
				printReady=FALSE;
				continue;
			}
			else if (!*p) tind=INDLEVEL;
			else tind=strtol(p,NULL,10);
		}
		/* EDIT 
		 * (UNDOCUMENTED) */
		else if (!strncasecmp_(comm,"EDIT",4)) {
			char tnam[COMPSTR];
			char back[COMPSTR];
			char command[COMPSTR];
			FILE *fd;
			int ret=0;
			/* by default use the tbas temp file name */
			strcpy(tnam,"tbas_temp_edit.bas");
			strcpy(back,filename);
			p=comm+4;
			while (isblank(*p)) p++;
			/* use the file specified after EDIT */
			if (*p && isanystring(p)) {
				strcpy(tnam,SS());
				/* EDIT called upon a regular file, sets
				 * filename anew */
				strcpy(back,tnam);
			}
  			/* store program lines in the temp file
			 * delegates list_indented() */
			fd=fopen(tnam,"w");
			if (!fd) {
				fprintf(stdout,"Error: file not found or not loadable");
				printReady=FALSE;
				continue;
			}
			list_indented(TRUE,libStart,ln[1],ln[endCore],fd,TRUE);
			// no New Line here!
			if (fd) fclose(fd);
  			/* use gvim to modify */
			strcpy(command,TEDIT);
			strcat(command," ");
			strcat(command,tnam);
			ret=system(command); // editor, supposed to save
  			/* reload modified lines from temp file: 
			 * delegates session_load() */
			if (ret!=127) {
				session_load(tnam);
  				/* delete temp file */
				remove(tnam);
			}
			else {
				fprintf(stdout,"File not edited");
			}
			strcpy(filename,back);
		}
		/* TRACE */
		else if (!strncasecmp_(comm,"TRACE",5)) {
			p=comm+5;
			isSingleBASICCommand=TRUE;
			if (*p=='0') {
				p++;
				debugRaw=TRUE;
			}
			while (isblank(*p)) p++;
			if (!*p) isDebug=TRUE;
			else if (!strncasecmp_(p,"ON",2)) {
				isDebug=TRUE;
			}
			else if (!strncasecmp_(p,"OFF",3)) {
				isDebug=FALSE;
			}
			/* show variable type 
			 * TRACE n, where n is the variable index */
			else if (isdigit(*p)) {
				int var=0;
				var=S();
				if (var>0 && var<=decCount) {
					//showDEC(var,TRUE);
					if (isInvDebug) fprintf(stdout,INVCOLOR);
					fprintf(stdout,"%s [#%d], type %s, ",vn[var].name!=NIL?vn[var].name:"obj.",var,vn[var].rettype==NUM?"numeric":"string");
					if (vn[var].rettype==NUM) 
					fprintf(stdout,"value = %f\n",P[var]);
					else fprintf(stdout,"value = |%s|\n",PS[var]);
					if (isInvDebug) fprintf(stdout,RESETCOLOR);
				}
				else if (!decCount){ 
					fprintf(stdout,"Error: no variables instantiated yet\n");
					printReady=FALSE;
					continue;
				}
				else if (var > 0) { 
					fprintf(stdout,"Error: index out of scope (higher index is %d).\n",decCount);
					printReady=FALSE;
					continue;
				}
			}
			/* trace variable when it changes
			 * TRACE CCCC, where CCCC is the variable name */
			else {
				int var=0;
				var=searchDEC(p,decCount);
				if (var>0 && var<=decCount) {
					char *k=traceISval;
					while (isnamechar(p) || *p=='$') 
						*k++=*p++;
					*k='\0';
					fprintf(stdout,"\nVariable %s will be traced under execution.\n",traceISval);
				}
				else { 
					fprintf(stdout,"Error: variable %s not found.\n",p);
					printReady=FALSE;
					continue;
				}
			}
			//debugRaw=FALSE;
		}
		/* UNTRACE */
		else if (!strncasecmp_(comm,"UNTRACE",7)) {
			isDebug=FALSE;
			debugRaw=FALSE;
			traceISval[0]='\0';
		}
		/* CLEAN */
		else if (!strncasecmp_(comm,"CLEAN",5)) {
			resetVars();
		}
		/* NEW/SCRATCH */
		else if (!strncasecmp_(comm,"NEW",3) || !strncasecmp_(comm,"SCRATCH",7)) {
			/* Note: this forces the HEADER to print <NONAME>
			 * in place of the file name in case OPTION HEADER
			 * or OPTION VINTAGE is used */
			filename[0]='\0';
			_clean();
		}
		/* CORE
		 * (UNDOCUMENTED) */
		else if (!strncasecmp_(comm,"CORE",4)) {
			fprintf(stdout,"Total memory   = %d (program + libraries)\n",endCore);
			fprintf(stdout,"Program core   = %d\n",libStart);
			fprintf(stdout,"Libraries core = %d\n",endCore-libStart);
		}
		/* MEMORY */
		else if (!strncasecmp_(comm,"MEMORY",6)) {
			int i, total=0, atotal=0;
			fprintf(stdout,"\nMemory Status:\n");
			fprintf(stdout,"-------------\n\n");
			fprintf(stdout,"Program lines indices    = %d\n",libStart);
			fprintf(stdout,"Extern libraries indices = %d\n",endCore-libStart);
			fprintf(stdout,"Total indices            = %d\n",endCore);
			/* calculate program memory amount */
			for (i=0;i<=MEMLIMIT;i++) {
				if (m[i] && *m[i]) total+=strlen(m[i]);
			}
			fprintf(stdout,"Program bytes= %d\n",total);
			fprintf(stdout,"Available lines = %d\n",MEMLIMIT-endCore);
			fprintf(stdout,"Number of declared variables = %d\n",decCount);
			/* calculate numeric variables count */
			total=0;
			for (i=0;i<=decCount;i++) {
				if (vn[i].rettype==NUM) total++;
			}
			fprintf(stdout,"  Numeric variables = %d\n",total);
			fprintf(stdout,"  String variables = %d\n",decCount-total);
			/* calculate numeric arrays count */
			total=0;
			for (i=0;i<=decCount;i++) {
				if (vn[i].isArr) {
					total++;
					if (vn[i].rettype==NUM) atotal++;
				}
			}
			fprintf(stdout,"  Numeric arrays = %d\n",atotal);
			fprintf(stdout,"  String arrays = %d\n",total-atotal);
			fprintf(stdout,"Available variables indices = %d\n",VLIMIT-decCount);
		}
		/* CAT */
		else if ((cn=recog(3,comm,"CAT","CATALOG","DIR"))) {
			int isCaseSensitive=TRUE;
			char ext[BUFSIZ], *e=ext;
			char *p=comm+cn;
			while (isblank(*p)) p++;
			if (*p=='\"') p++;
			while (*p && *p!='*') *e++=*p++;
			*e='\0';
			if (*p=='*') isCaseSensitive=FALSE;
			if (!doCat(ext,isCaseSensitive)) {
				fprintf(stderr,"Error: cannot read the directory\n");
				printReady=FALSE;
				continue;
			}
		}
		/* SHELL */
		else if (!strncasecmp_(comm,"SHELL",5)) {
			char *p=comm+5;
			/* omit quotes */
			while (isblank(*p)) p++;
			if (*p=='\"') p++;
			if (*(p+strlen(p)-1)=='\"') *(p+strlen(p)-1)='\0';
			system(p);
		}
		/* MONITOR */
		else if (!strncasecmp_(comm,"MONITOR",7)) {
			system(TSHELL);
		}
		/* FIND */
		else if ((cn=recog(3,comm,"FIND","WHERE","SCAN"))) {
			char *p=comm+cn;
			int c=0;
			char match[COMPSTR];
			while (isblank(*p)) p++;
			if (*p=='\"') p++;
			strncpy(match,p,MAXSTRLEN);
			while (c<=endCore) {
				if (m[c] && strlen(m[c])>0) {
					if (strcasestr_(m[c],match)) { 
				   		/* print line number */
				   		if (fullLines) 
						 fprintf(stdout,"%05d  ",ln[c]);
				   		else 
						 fprintf(stdout,"% 5d  ",ln[c]);
				   		/* print BASIC line */
				   		fprintf(stdout, "%s\n",m[c]);
					}
				}
				c++;
			}
		}
		/* PROMPT */
		else if (!strncasecmp_(comm,"PROMPT",6)) {
			char *p=comm+6;
			while (isblank(*p)) p++;
			if (*p=='\"') p++;
			strncpy(prompt,p,MAXSTRLEN);
			if (*(prompt+strlen(prompt)-1)=='\"') 
				*(prompt+strlen(prompt)-1)='\0';
		}
		/* PWD */
		else if (!strncasecmp_(comm,"PWD",3)) {
			fprintf(stdout,"%s\n",basedir);
		}
		/* CD */
		else if (!strncasecmp_(comm,"CD",2)) {
			char *p=comm+2;
			while (isblank(*p)) p++;
			if (*p=='\"') p++;
			if (!unixCD(p))
			{	fprintf(stderr,"Error: specified directory does not exist\n");
				printReady=FALSE;
				continue;
			}
		}
		/* DEST 
		 * (UNDOCUMENTED) */
		else if (!strncasecmp_(comm,"DEST",4)) {
			if (strlen(filename)>0) 
				fprintf(stdout,"System file name =|%s|\n",filename);
			else
				fprintf(stdout,"File name not set yet.\n");
		}
		/* SAVE */
		else if (!strncasecmp_(comm,"SAVE",4)) {
			char *p=comm+4, lpath[4*COMPSTR], *pb;
			FILE *f;
			int termin=libStart;
			while (isblank(*p)) p++;
			/* if used with WITH LIBS set new terminator */
			if (checkCommand(p,"WITH LIBS",&pb)) {
				p=pb;
				while (isblank(*p)) p++;
				termin=endCore;
				isIncludingLibs=TRUE;
			}
			/* in case an argument is given, take it as the
			 * file name */
			if (*p) {
				/* remove final blanks and all quotes*/
				while (isblank(*(p+strlen(p)-1))) 
					*(p+strlen(p)-1)='\0';
				if (*p=='\"') p++;
				if (*(p+strlen(p)-1)=='\"') 
					*(p+strlen(p)-1)='\0';
				strncpy(filename,p,COMPSCR-1);
			}
			if (strlen(filename)<1) {
				fprintf(stderr,"\nError: Missing file name\n\n");
				printReady=FALSE;
				continue;
			}
			if (strncasecmp_(filename+strlen(filename)-4,".BAS",4) && strncasecmp_(filename+strlen(filename)-4,".TXT",4) && strncasecmp_(filename+strlen(filename)-4,".txt",4) && strncasecmp_(filename+strlen(filename)-4,".bas",4)) 
				strcat(filename,".bas");
			bjoin(lpath,filename);
			/* open file */
			if (!(f=fopen(lpath,"w"))) {
				fprintf(stderr,"\nError: Couldn't open file %s\n\n",filename);
				printReady=FALSE;
				continue;
			}

			/* write lines and store them */
			list_indented(TRUE,termin,ln[1],ln[termin],f,TRUE);
			fprintf(f, "\n");
			/* close file */
			fclose(f);
		}
		/* LOAD/OLD */
		else if ((cn=recog(2,comm,"LOAD","OLD"))) {
			int status;
			char fn[COMPSTR], *fl=fn;
			char *p=comm+cn;
			while (isblank(*p)) p++;
			while (*p && *p!=',' && !isblank(*p))
				*fl++=*p++;
			*fl='\0';
			/* remove libraries */
			removeLibs();
			isLOAD=TRUE;
			status=LOAD(m,fn,0,ALL_LINES);
			isLOAD=FALSE;
			libStart=endCore;
			isIncludingLibs=FALSE;
			if (status) {
				continue;
			}
			strcpy(filename,fn);
		}
		/* ASPECT */
		else if (!strncasecmp_(comm,"ASPECT",6)) {
			char *p=comm+6;
			while (isblank(*p)) p++;
			if (!strncasecmp_(p,"ZERO",4)) fullLines=TRUE;
			else if (!strncasecmp_(p,"ZEROES",6)) fullLines=TRUE;
			else if (!strncasecmp_(p,"SPACE",5)) fullLines=FALSE;
			else if (!strncasecmp_(p,"SPACES",6)) fullLines=FALSE;
			else if (!*p) fullLines=FALSE;
			else {
				fprintf(stderr,"\nError: Cannot set up aspect %s\n",p);
				printReady=FALSE;
				continue;
			}
		}
		/* MERGE */
		else if (!strncasecmp_(comm,"MERGE",5)) {
			char *p=comm+5, lpath[4*COMPSTR];
			FILE *f;
			int regular=TRUE;
			/* find file name */
			while (isblank(*p)) p++;
			/* in case an argument is given, take it as the
			 * file name */
			if (*p) {
				/* remove final blanks and all quotes*/
				while (isblank(*(p+strlen(p)-1))) 
					*(p+strlen(p)-1)='\0';
				if (*p=='\"') p++;
				if (*(p+strlen(p)-1)=='\"') 
					*(p+strlen(p)-1)='\0';
				strncpy(filename,p,COMPSCR-1);
			}
			if (strlen(filename)<1) {
				fprintf(stderr,"\nError: Missing file name\n\n");
				printReady=FALSE;
				continue;
			}
			setExt(filename);
			bjoin(lpath,filename);
			/* reset libraries */
			removeLibs();
			/* open file */
			if (!(f=fopen(lpath,"r"))) {
				fprintf(stderr,"\nError: Couldn't find file %s\n\n",filename);
				printReady=FALSE;
				continue;
			}

			/* read lines and store them */
			while(fgets(B,SCREENLINE+9,f) && endCore<=MEMLIMIT) {
				if ((int)strlen(B)>0 && B[0]!='\n') {
					p=B;
					/* remove trailing spaces and EOL */
					if (*(p+strlen(p)-1)=='\r')  
						*(p+strlen(p)-1)='\0';
					if (*(p+strlen(p)-1)=='\n')  
						*(p+strlen(p)-1)='\0';
					if (*(p+strlen(p)-1)=='\r')  
						*(p+strlen(p)-1)='\0';
					while (isblank(*p)) p++;
					while (isblank(*(p+strlen(p)-1))) 
						*(p+strlen(p)-1)='\0';
					while (isblank(*p)) p++;
					/* check also regularity */
					if ((int)strlen(p)>0 && *p!='\n') {
						if (*p<'0' || *p>'9') {
							regular=FALSE;
							break;
						}
					}
					if (!_addline(p)) {
						fprintf(stderr,"Error: memory exhausted while executing MERGE.\n\n");
						printReady=FALSE;
						continue;
					}
				}
			}
			isIncludingLibs=FALSE;
			/* close file */
			fclose(f);
			if (!regular) {
				fprintf(stderr,"Error: not a regular line-numbered BASIC file\n");
				fprintf(stderr,"(You should try to CONVERT it or you can run it out of the interactive mode.)\n\n");
				printReady=FALSE;
				continue;
			}
		}
		/* TYPE */
		else if (!strncasecmp_(comm,"TYPE",4)) {
			char *p=comm+4, lpath[4*COMPSTR];
			int isScreens=FALSE, count=0;
			FILE *f;
			char typeFile[COMPSTR];
			while (isblank(*p)) p++;
			if (*p=='\"') p++;
			if (!*p) {
				fprintf(stderr,"\nError: no file name given\n\n");
				printReady=FALSE;
				continue;
			}
			if (*(p+strlen(p)-1)=='\"') *(p+strlen(p)-1)='\0';
			if (*(p+strlen(p)-1)=='*') {  
				*(p+strlen(p)-1)='\0';
				isScreens=TRUE;
			}
			strncpy(typeFile,p,COMPSCR-1);
			bjoin(lpath,typeFile);
			setExt(lpath);
			/* open file */
			if (!(f=fopen(lpath,"r"))) {
				fprintf(stderr,"\nError: Couldn't find file %s\n\n",typeFile);
				printReady=FALSE;
				continue;
			}
			/* read lines and print them */
			fprintf(stdout,"\n");
			fprintf(stdout,"%s:\n",typeFile);
			while(fgets(B,SCREENLINE+9,f) && !isInterrupt) {
				char hhh[2], *p=B;
				/* get rid of file EOL and establish its own*/
				if (*(p+strlen(p)-1)=='\r')  
					*(p+strlen(p)-1)='\0';
				if (*(p+strlen(p)-1)=='\n')  
					*(p+strlen(p)-1)='\0';
				if (*(p+strlen(p)-1)=='\r')  
					*(p+strlen(p)-1)='\0';
				fprintf(stdout,"%s\n",B);
				if (isScreens) {
					count+=strlen(B)/80+1;
					if (count>21) {
						fprintf(stdout,"<PRESS ENTER>");
						strncpy(hhh,getString(),1);
						count=0;
					}
				}
			}
			/* close file */
			fclose(f);
		}
		/* AUTO */
		else if (!strncasecmp_(comm,"AUTO",4)) {
			char *p=comm+4;
			int n=100, s=10;
			char comp[COMPSTR], tcomp[COMPSTR];
			while (isblank(*p)) p++;
			if (isdigit(*p)) {
				n=strtol(p,&p,10);
				if (n<1) n=100;
			}
			while (isblank(*p)) p++;
			if (*p==',') {
				p++;
				while (isblank(*p)) p++;
				s=strtol(p,NULL,10);
				if (s<1) s=10;
			}
			/* perform automatic storing */
			while (TRUE) {
				fprintf(stdout,"% 5d\t",n);
				strcpy(tcomp,getString());
				if (!strcmp(tcomp,"_")) break;
				sprintw(comp,COMPSTR,"%d %s",n,tcomp);
				if (!_addline(comp)) {
					fprintf(stderr,"Error: memory exhausted  while executing AUTO.\n\n");
					printReady=FALSE;
					continue;
				}
				n+=s;
			}
		}
		/* DUMP 
		 * decode each line, printing ASCI codes and their 
		 * representations in order to see if there are extraneous 
		 * control characters, in the line, that confuses the parser *
		 * - debug purposes */
		else if (!strncasecmp_(comm,"DUMP",4)) {
			int i,j, start, end;
			char *p=comm+4;
			reorder(1,libStart);
			start=ln[1];
			end=ln[endCore];
			while (isblank(*p)) p++;
			/* detect user values (if any) */
			if (isdigit(*p)) {
				start=strtol(p,&p,10);
				if (!*p) end=start;
			}
			while (isblank(*p)) p++;
			if (*p=='-') {
				p++;
				while (isblank(*p)) p++;
				if (*p) end=strtol(p,NULL,10);
			}
			/* in case values are reversed...*/
			if (start>end) {
				int temp=start;
				start=end;
				end=temp;
			}
			for (i=1; i<=endCore; i++) {
				if (!m[i] || !*m[i]) continue;
				if (ln[i]<start || ln[i]>end) continue;
				fprintf(stdout,"--> Line %d {%d}\n",ln[i],i);
				for (j=0;j<strlen(m[i]);j++)
					fprintf(stdout, "%d ",m[i][j]);
				fprintf(stdout,"\n");
				for (j=0;j<strlen(m[i]);j++)
					fprintf(stdout, "%c",m[i][j]);
				fprintf(stdout,"\n");
			}
		}
		/* GLIST 
		 * list in bare mode with full zeroes including libraries
		 * debug purposes */
		else if (!strncasecmp_(comm,"GLIST",5)) {
			int i;
			int limit=endCore;
			/* list in bare mode */
			for (i=1; i<=limit; i++) {
				if (!m[i] || !*m[i]) continue;
				/* print BASIC line */
				if (ln[i]>0) 
				      fprintf(stdout, "%05d  %s\n",ln[i],m[i]);
				else  
				      fprintf(stdout, "       %s\n",m[i]);
			}
		}
		/* DELETE */
		else if (!strncasecmp_(comm,"DEL",3)) {
			int i, start, end;
			char *p=comm+3;
			if (!strncasecmp_(p,"ETE",3)) p+=3;
			if (!*p) {
				fprintf(stderr,"Error: missing argument.\n\n");
				printReady=FALSE;
				continue;
			}
			reorder(1,libStart);
			start=ln[1];
			end=ln[libStart];
			while (isblank(*p)) p++;
			/* detect user values (if any) */
			if (isdigit(*p)) {
				start=strtol(p,&p,10);
				if (!*p) end=start;
			}
			while (isblank(*p)) p++;
			if (*p=='-') {
				p++;
				while (isblank(*p)) p++;
				if (*p) end=strtol(p,NULL,10);
			}
			/* in case values are reversed...*/
			if (start>end) {
				int temp=start;
				start=end;
				end=temp;
			}
			/* erase lines in the interval */
			for (i=1; i<=libStart; i++) {
				if (!m[i] || !*m[i]) continue;
				if (!ln[i]) continue;
				if (end==libStart) {
					free(m[libStart]);
					ln[libStart]=0;
				}
				/* delete the line only if in the required
				 * range specified by the user by passing
				 * to _addline() a line with the sole line
				 * number, so that _addline() removes it */
				if(ln[i]>=start && ln[i]<=end) {
					char temp[COMPSTR];
					sprintw(temp,COMPSTR,"%d",ln[i]);
					_addline(temp);
				}
			}
			if (ln[libStart]==end) {
				char temp[COMPSTR];
				sprintw(temp,COMPSTR,"%d",end);
				_addline(temp);
			}
		}
		/* LIST */
		else if (!strncasecmp_(comm,"LIST",4)) {
			int i, start, end;
			int bare=FALSE;
			char *p=comm+4;
			reorder(1,libStart);
			start=ln[1];
			end=ln[libStart];
			if (*p=='0') {
				bare=TRUE;
				p++;
			}
			while (isblank(*p)) p++;
			/* detect user values (if any) */
			if (isdigit(*p)) {
				start=strtol(p,&p,10);
				if (!*p) end=start;
			}
			while (isblank(*p)) p++;
			if (*p=='-') {
				p++;
				while (isblank(*p)) p++;
				if (*p) end=strtol(p,NULL,10);
			}
			/* in case values are reversed...*/
			if (start>end) {
				int temp=start;
				start=end;
				end=temp;
			}
			/* list in bare mode */
			if (bare) for (i=1; i<=libStart; i++) {
				if (!m[i] || !*m[i]) continue;
				if (!ln[i]) continue;
				/* print the line only if in the required
				 * range specified by the user */
				if(ln[i]>=start && ln[i]<=end) {
					/* print line number */
					if (fullLines) 
						fprintf(stdout,"%05d",ln[i]);
					else 
						fprintf(stdout,"% 5d",ln[i]);
					/* print BASIC line */
					fprintf(stdout, "  %s\n",m[i]);
				}
			}
			/* list indenting */
			else {
				list_indented(TRUE,libStart,start,end,stdout,fullLines);
				fprintf(stdout,"\n");
			}
		}
		/* APROPOS */
		else if (!strncasecmp_(comm,"APROPOS",7)) {
			char *p=comm+7;
			char tcomm[COMPSTR];
			int i=0;
			while (isblank(*p)) p++;
			while (isblank(*(p+strlen(p)-1))) *(p+strlen(p)-1)='\0';
			strcpy(tcomm,p);
			fprintf(stdout, "\n%s",REDCOLOR);
			while (i<APROPOSCOUNT) {
				if (!strcasecmp(tcomm,apropos_[i])) {
					pseg(apropos_[i+1]);
					break;
				}
				i+=2;
			}
			if (i>=APROPOSCOUNT) {
			       fprintf(stdout,"What?\n");
		       	       printReady=FALSE;
			}
			fprintf(stdout,"%s",RESETCOLOR);
		}
		/* line number: store in line */
		else if (comm[0]>='0' && comm[0]<='9') {
			/* erase libraries */
			removeLibs();
			if (!_addline(comm)) {
				fprintf(stderr,"Error: memory exhausted.\n\n");
				printReady=FALSE;
				continue;
			}
			printReady=FALSE;
			libStart=endCore;
			/* do reordering */
			reorder(1,endCore);
			continue;
		}
		/* empty command is ignored */
		else if (!strlen(comm)) {
			printReady=FALSE;
			continue;
		}
		/* execute a BASIC statement */
		else {
			isSingleBASICCommand=TRUE;
			parseLine(comm,0);
			/* otherwise it's an unrecognized/malformed command */
			if (isEndOfStatement) {
				printReady=FALSE;
			}
			isEndOfStatement=FALSE;
		}
		/* print the READY. string and dispose for next command... */
		if (!isQuit && printReady) fprintf(stdout,"\n\nREADY.");
		/* ...or print the closing sequence
		 * Note: isSystem=TRUE supresses the closing sequence
		 * in order not to clutter the output of the program
		 * passed to the shell by SYSTEM */
		else if (isQuit && !isSystem) {
			time_t result;
			char output[COMPSTR];
			gettimeofday(&tv, NULL);
       			iEndS=((double)tv.tv_sec+tv.tv_usec/1000000.0);
			iEndS-=iBeginS;
			fprintf(stdout,"\n  JOB #1 FOR USER %s\n",LOGAS);
			result = time(NULL);
			strcpy(output,asctime(localtime(&now)));
			turnToUpper(output);
			printf("  LOGGED ON : %s",output);
			strcpy(output,asctime(localtime(&result)));
			turnToUpper(output);
		       	fprintf(stdout,"  LOGGED OFF: %s",output);
			fprintf(stdout,"  RUN");
			timedString(iEndS);
			fprintf(stdout,"  BASIC DETACHED. GOOD BYE.");
			isTiming=FALSE;
		}
		fprintf(stdout,"\n\n");
	}
	write_history(HISTORY);
}


/*****************************************
 *      SIGNALS & ERROR TREATMENT        *
 *****************************************/

/* PERROR_()
 * print a string message based upon the following information data:
 * - errNum is the error code number defined in errors.h and must always be
 *   given as first argument 
 * - ll is the line number in which the error is occurred; if null, the 
 *   line reference is not printed (general errors); this must always be given 
 *   as the second argument
 * - all the other parameters should be the ones needed in the error strings,
 *   to fill the data in the % specifiers, according to their type.
 * If an error-catching technique is in use, set codes and exit.
 * The file name is added only in a CHAINed process, and only from the second
 * file on; the first file run has no file name reference*/
int perror_(int line,int errNum, int ll, ...) {
	va_list ap;
	int diff=0, delay=0;

	/* avoid multiple occurrences of error messages in the 
	 * interactive sessions */
	if (isEndOfStatement || syserr) {
		if (syserr) syserr=FALSE;
		return TRUE;
	}

	/* if USE or HANDLER are in action, their error messages must be
	 * printed and the program stopped,  because an error in the handler
	 * must not be re-catched. So redirect message to syserr_() */
	if ((isUseActive || isHandlerActive) && error[errNum][0]!='%') {
		va_start(ap, ll);
		syserr_(line,errNum, ll, ap);
		va_end(ap);
	}

	/* intercept the WHEN ERROR USE feature first; this is conceived as the
	 * inner WHEN ERROR error catching technique  */
	if (isWhenErrorUsePos && error[errNum][0]!='%') {
		errValue=errNum;
		errLine=l;
		l=handler[isHandlerNum].pos-1;
		return TRUE;
	}
	/* intercept the WHEN ERROR IN feature then; this is conceived as the
	 * outer WHEN ERROR error catching technique */
	else if (isWhenErrorInPos && error[errNum][0]!='%') {
		errValue=errNum;
		errLine=l;
		l=isUsePos-1;
		return TRUE;
	}
	/* intercept the NO DATA error catching technique */
	else if (isNoDataPos && error[errNum][0]!='%' && errNum==110) {
		errValue=errNum;
		errLine=l;
		l=isNoDataPos-1;
		return TRUE;
	}
	/* intercept the ON ERROR <code> error catching technique; this
	 * responds only if a specific error has to be trapped  */
	else if (isOnErrorPos && isOnErrorTrap && error[errNum][0]!='%') {
		if (errNum==isOnErrorTrap) {
			errValue=errNum;
			errLine=l;
			l=isOnErrorPos-1;
			return TRUE;
		}
	}	
	/* intercept the ON ERROR error catching technique; this is conceived
	 * as the most general error catching technique, which should be
	 * set as the outer of all possible error catching features */
	else if (isOnErrorPos && error[errNum][0]!='%') {
		errValue=errNum;
		errLine=l;
		l=isOnErrorPos-1;
		return TRUE;
	}

	/* print error message */
	if (isDebug) {
		if (isInvDebug) fprintf(stdout,"%s",RESETCOLOR);
	}
	if (channel[0].fcounter || isRawPrint) fprintf(stderr,"\n");
	va_start(ap, ll);
	/* real error: print regular error message with arguments */
	if (ll!=ERRORCODE) {
		/* print warning... */
		if (error[errNum][0]=='%') {
			/* ...only if required */
			if (warnState==ONWARN) 
				vfprintf(stderr,error[errNum], ap);
			/* otherwise stop */
			else return TRUE;
		}
		/* print error message */
		else vfprintf(stderr,error[errNum], ap);
	}
	/* treat CAUSE ERROR */
	else {
		/* print string as-is; if error message string is void, print 
		 * default string at position 0; this is the case of CAUSE 
		 * ERROR called with a reference to a not-used code error */
		if (!(int)strlen(error[errNum])) fprintf(stderr,"%s",error[0]);
		else fprintf(stderr,"%s",error[errNum]);
	}

	/* add other data (line number, label, things like that) */
	if (!isSingleBASICCommand) {
		if (ll==ERRORCODE) ll=l;
		if (ll>=0) {
			if (!isSubRun) fprintf(stderr," in line %d",ll);
			else {
				int i=0, newll=ll;
				while (i<=libTOS) {
					if (ll>=tlib[i].start && ll<=tlib[i].end) {
						newll=ll-tlib[i].start;
						break;
					}
					i++;
				}
				fprintf(stderr," in sub %s at line %d",\
			   sn[isSubVar].name[0]?sn[isSubVar].name:"\b",newll);
			}
			if (ln[ll]) fprintf(stderr," (labelled as %d)",ln[ll]);
		}
		if (isChain && strlen(filename)>0) {
			fprintf(stderr," into chained file %s", filename);
		}
		va_end(ap);
		fprintf(stderr,".");
		if (isPrintSourceCode) fprintf(stderr," #%d#\n",line);
		else fprintf(stderr,"\n");
	}

	/* print line and indicator for errors (not for warnings) */
	if (!isSingleBASICCommand && isRunOn && error[errNum][0]!='%' && m[ll]){
		char *qq;
		int diff=0;
		if (p!=NIL) {
			qq=p;
			while (*qq) qq++; // find end of p
			diff=(int)(qq-p);
		}
		fprintf(stderr,"%s\n",m[ll]);
		if (m[ll] && (int)strlen(m[ll])>diff-1) 
			delay=(int)((int)strlen(m[ll])-diff);
		else delay=0;
		/* 'here' improvement */
		if (delay>0) while (delay>0) fputc(' ',stderr), delay--;
		fprintf(stderr,"^\n");
	}

	/* rebuild cursor position in case of a warning */
	if (error[errNum][0]=='%') {
		while (diff++ < channel[0].fcounter) fputc(' ',stderr);
		if(startInteractive) fputc('\n',stderr);
	}
	/* otherwise, stop execution */
	else {
		if (!startInteractive) {
			END(EXIT_FAILURE);
		}
		else isEndOfStatement=TRUE;
	}
	return TRUE;
}


/* syserr_()
 * print a system string message based upon the following information data:
 * - errNum is the error code number defined in errors.h and must always be
 *   given as first argument 
 * - all the other parameters should be the ones needed in the error strings,
 *   to fill the data in the % specifiers, according to their type 
 * No interception is done, here, so the printing of the error force 
 * program end. 
 * If ll=-1 then print Usage */
void syserr_(int line ,int errNum, int ll, ...) {
	va_list ap;

	/* print error message */
	if (channel[0].fcounter) fprintf(stderr,"\n");
	va_start(ap, ll);
	vfprintf(stderr,error[errNum], ap);
	if (ll>=0) {
		if (!isSubRun) fprintf(stderr," in line %d",ll);
		else fprintf(stderr," in sub %s at line %d",\
				sn[isSubVar].name[0]?sn[isSubVar].name:"\b",\
				ll);
		if (ln[ll]) fprintf(stderr," (labelled as %d)",ln[ll]);
	}
	if (isChain) fprintf(stderr," into chained file %s", filename);
	va_end(ap);
	fprintf(stderr,".");
	if (isPrintSourceCode) fprintf(stderr," #%d#\n",line);
	else fprintf(stderr,"\n");

	/* reset color */
	if (isDebug) {
		if (isInvDebug) fprintf(stderr,RESETCOLOR);
	}

	/* quit printing usage and emitting failure exit code */
	if (ll==-1) printUsage();
	if (!startInteractive) END(EXIT_FAILURE);
	else {
		isEndOfStatement=TRUE;
		printReady=FALSE;
	}
	syserr=TRUE;
}


/* sigtrap()
 * trap procedure for ON ATTENTION when an interrupt has been trapped */
void sigtrap(int sig) {
	/* reassign user destination SIGINT */
	if (isOnAttentionPos) {
		signal(SIGINT, sigint);
		signal(SIGHUP, sigint);
		arrLine=l;
		arrValue=ERRLIM;
		FCR(CONSOLE);
		parse(m,isOnAttentionPos,endCore);
	}
	else sigint(sig);
}


/* sigquit()
 * end procedure for stopping when a SIGBUS or a SIGSEGV signal 
 * has been trapped */
void sigquit(int sig) {
	/* reassign the normal behavior to SIGINT */
	signal(SIGBUS, SIG_DFL);
	signal(SIGSEGV, SIG_DFL);
	signal(SIGABRT, SIG_DFL);
	closeFiles();
	syserr_(__LINE__,6,-1);
}


/* sigint()
 * end procedure if a SIGHUP or a SIGINT signal was trapped */
void sigint(int sig) {
	/* reassign the normal behavior to signals */
	isInterrupt=TRUE;
	/* end only in case of direct execution */
	if (!startInteractive) {
		signal(SIGHUP, SIG_DFL);
		signal(SIGINT, SIG_DFL);
		END(EXIT_STOP);
	}
	/* CTRL-C was pressed in the session: print line */
	else {
		fprintf(stdout, "\n\nCTRL-C stop at line %d",ln[l]);
		fprintf(stdout,"\n\n");
		isEndOfStatement=TRUE;
	}
}


/* xmalloc()
 * create a memory space for strings
 * size is the size of the string (included the terminator) 
 * Note: this function was created to be portable among all UNIX systems
 * with gcc installed. */
void *xmalloc(size_t size) {
	void *value = malloc(size);
	if (value == NIL) perror_(__LINE__,5,l);
	return value;
}


/***************************************
 *      DOCUMENTATION AND LICENSE      *
 ***************************************/

/* printHelp()
 * help message */
void printHelp(void) {
	printExistence();
	fprintf(stdout,"Usage: tbas [options] [filename]\n\n");
	fprintf(stdout,"Options:\n");
	fprintf(stdout,"      --conditions  Print GPL3 redistribution conditions and exit\n");
	fprintf(stdout,"  -d                Normal debug mode (print full lines)\n");
	fprintf(stdout,"  -D                Debug flag to avoid color inversion\n");
	fprintf(stdout,"  -e, --exec        Start immediately the program in interactive mode\n");
	fprintf(stdout,"      --errors-list Print a complete errors list and exit\n");
	fprintf(stdout,"  -h, --help        Display this information and exit\n");
	fprintf(stdout,"  -H                Set Header display (DEC-20 mode)\n");
	fprintf(stdout,"  -i, --interactive Start an interactive session (using only numbered lines)\n");
	fprintf(stdout,"  -L                List [filename] indented and exit\n");
	fprintf(stdout,"  -N                Set the phantom string mask as the empty string\n");
	fprintf(stdout,"      --prompt=<s>  In interactive mode, set string <s> as prompt\n");
	fprintf(stdout,"  -p <s>            Parse string <s> as BASIC linear commands and exit\n");
	fprintf(stdout,"  -r                Raw debug mode (print preprocessed lines)\n");
	fprintf(stdout,"  -T                Set Timing display (DEC-20 mode)\n");
	fprintf(stdout,"  -v, --version     Display version and exit\n");
	fprintf(stdout,"      --warranty    Print warranty conditions from GPL3 and exit\n");
	fprintf(stdout,"\nYou should have received a copy of the GNU General Public License\n");
	fprintf(stdout,"along with this program. If not, see <http:/www.gnu.org/licenses/>.\n\n");
	fprintf(stdout,"Consult the man or the info page to know about tbas more in detail.\n\n");
	fprintf(stdout,"Email bugs reports to <tbin at libero dot it>.\n\n"); 
}

/* printHiddenHelp()
 * help on hiddend options */
void printHiddenHelp(void) {
	printExistence();
	fprintf(stdout,"Usage: tbas [options] [filename]\n\n");
	fprintf(stdout,"Options (included hidden ones):\n");
	fprintf(stdout,"      --conditions  Print GPL3 redistribution conditions and exit\n");
	fprintf(stdout,"  -d                Normal debug mode (print full lines)\n");
	fprintf(stdout,"  -D                Debug flag to avoid color inversion\n");
	fprintf(stdout,"  -e, --exec        Start immediately the program in interactive mode\n");
	fprintf(stdout,"      --errors-list Print a complete errors list and exit\n");
	fprintf(stdout,"  -h, --help        Display the standard help and exit\n");
	fprintf(stdout,"      --hidden      Display this extended help and exit\n");
	fprintf(stdout,"  -H                Set Header display (DEC-20 mode)\n");
	fprintf(stdout,"  -i, --interactive Start an interactive session (using only numbered lines)\n");
	fprintf(stdout,"  -l                list the program bare and exit (see what tbas sees)\n");
	fprintf(stdout,"  -L                List [filename] indented and exit\n");
	fprintf(stdout,"  -N                Set the phantom string mask as the empty string\n");
	fprintf(stdout,"      --prompt=<s>  In interactive mode, set string <s> as prompt\n");
	fprintf(stdout,"  -p <s>            Parse string <s> as BASIC linear commands and exit\n");
	fprintf(stdout,"  -r                Raw debug mode (print preprocessed lines)\n");
	fprintf(stdout,"  -R                Set raw print mode (testing purposes)\n");
	fprintf(stdout,"  -S                Print error source position (debug purposes)\n");
	fprintf(stdout,"  -T                Set Timing display (DEC-20 mode)\n");
	fprintf(stdout,"  -v, --version     Display version and exit\n");
	fprintf(stdout,"  -V                Print version and exit (versioning purposes)\n");
	fprintf(stdout,"      --warranty    Print warranty conditions from GPL3 and exit\n");
	fprintf(stdout,"  -X                Exit after preprocessing (debug purposes)\n");
	fprintf(stdout,"  -z                Set OPTION ZERO 6 (testing purposes)\n");
	fprintf(stdout,"\nYou should have received a copy of the GNU General Public License\n");
	fprintf(stdout,"along with this program. If not, see <http:/www.gnu.org/licenses/>.\n\n");
	fprintf(stdout,"Consult the man or the info page to know about tbas more in detail.\n\n");
	fprintf(stdout,"Email bugs reports to <tbin at libero dot it>.\n\n"); 
}

/* printUsage()
 * usage message */
void printUsage(void) {
	fprintf(stdout,"Usage: tbas [options] [filename]\n");
	fprintf(stdout,"Type tbas -h for help\n");
	s_exit(EXIT_FAILURE);
}

/* printExistence()
 * existence message */
void printExistence(void) {
	fprintf(stdout,"tbas BASIC interpreter\n");
}

/* printVersion()
 * help banner */
void printVersion(void) {
	printExistence();
	fprintf(stdout,"version %s", VERSION);
	fprintf(stdout," - compiled %s", __DATE__);
	fprintf(stdout," - Copyleft (C) %s\n%s <%s>. \n", CY, AU, EM);
}

/* printHelpBanner()
 * version message */
void printHelpBanner(void) {
	fprintf(stdout,"This free software comes with ABSOLUTELY NO WARRANTY; for details about this,\ntype 'tbas --warranty'.  You are welcome to redistribute it under certain\nconditions; type 'tbas --conditions' for details.\nThis software is released under the terms of the GNU General Public License 3.\n\n");
}

/* printWarranty()
 * warranty message (required by GPL3) */
void printWarranty(void) {
	fprintf(stdout,"THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY\nAPPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT\nHOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM \"AS IS\" WITHOUT\nWARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT\nLIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A\nPARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF\nTHE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME\nTHE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION.\n\n");
}

/* printConditions()
 * conditions message (required by GPL3) */
void printConditions(void) {
	fprintf(stdout,"You may make, run and propagate covered works that you do not convey,\nwithout conditions so long as your license otherwise remains in force.\nYou may convey covered works to others for the sole purpose of having\nthem make modifications exclusively for you, or provide you with\nfacilities for running those works, provided that you comply with the\nterms of this License in conveying all material for which you do not\ncontrol copyright. Those thus making or running the covered works for\nyou must do so exclusively on your behalf, under your direction and\ncontrol, on terms that prohibit them from making any copies of your\ncopyrighted material outside their relationship with you.\n\n");
}


/* inputAvailable()
 * check if some piped text has been thrown after tbas */
int inputAvailable() {
	struct timeval tv;
	fd_set fds;
	tv.tv_sec = 0;
	tv.tv_usec = 0;
	FD_ZERO(&fds);
	FD_SET(STDIN_FILENO, &fds);
	select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
	return (FD_ISSET(0, &fds));
}


/******************************************************************************
 * MAIN SECTION
 ******************************************************************************/

/* main() 
 * parse options, get file name, setup environment and perform, at request, 
 * the following actions:
 * OLD to create the file in memory
 * RUN to execute the file
 * Here is where it all begins... and where it all ends */
int main(int argc, char **argv) {
	int c, ac=0;
	char command[COMPSTR];
	prompt[0]='\0';

	/* set up login string */
	getlogin_r(LOGAS,COMPSTR-1);
	if (strlen(LOGAS)<1) strncpy_(LOGAS,"GUEST",COMPSTR);
	turnToUpper(LOGAS);

	/* set up console channels data (which is the terminal, in tbas) 
	 * Note: only meaningful data for sequential output are set 
	 * Note: this is done here because every tbas functions must find
	 * CONSOLE set up and running for error messages printing */
	CONSOLEIN=stdin;
	channel[CONSOLE].stream=stdout;
	channel[CONSOLE].isopen=TRUE;
	channel[CONSOLE].type=SEQ;
	channel[CONSOLE].fcounter=0;
	channel[CONSOLE].wayout=VWRITE;
	channel[CONSOLE].quote=NOQUOTE;
	channel[CONSOLE].page=1;
	channel[CONSOLE].height=PAGEHEIGHT;
	channel[CONSOLE].pagerow=1;
	channel[CONSOLE].pagenumber=FALSE;
	channel[CONSOLE].margin=SCRLIM;
	channel[CONSOLE].fprintn=1;
	channel[CONSOLE].isReadonly=FALSE;
	channel[CONSOLE].isPrepend=FALSE;
	for (c=1; c<=STREAMS; c++) 
		channel[c].isopen=FALSE, channel[c].stream=NIL;

	/* check if there's some piped text */
	command[0]='\0';
	if (inputAvailable()) {
		strncpy_(command,getString(),COMPSTR);
	}

	/* parse options; double and single dash options may be alternated,
	 * options requiring an argument may or not be attached (but must
	 * be the last options of that group);
	 * ~Antonio Maschio - March 2014 for the decb project */
	while (++ac < argc) {
		/* do not parse the rest of the command-line */
		if (!strcasecmp(argv[ac], "--")) { 
			ac++;
			break;
		}
		if (*argv[ac]=='-') {
			/* parse double-dash options */
			if (!strcasecmp(argv[ac], "--help")) { 
			        fputc('\n',stdout);	
				printHelp(); 
				exit(EXIT_SUCCESS); 
			}
			else if (!strcasecmp(argv[ac], "--hidden")) { 
			        fputc('\n',stdout);	
				printHiddenHelp(); 
				exit(EXIT_SUCCESS); 
			}
			else if (!strcasecmp(argv[ac], "--errors-list") ||\
				!strcasecmp(argv[ac], "--errorslist") ||\
				!strcasecmp(argv[ac], "--errors")) { 
				int i;
				char *y;
				fprintf(stdout,"\nErrors list for tbas ");
				fprintf(stdout,"version %s\n\n",VERSION);
				for (i=0;i<ERRLIM;i++) {
				    char n='\0';
				    y=error[i];
				    if (*y) {
					while (*y=='\n') y++;
				    	if (!strrchr(y,'\n')) n='\n';
				        if (!strncasecmp_(y,"%%%%",2))	
				    	    fprintf(stdout,"%3d %s%c",i,y+1,n);
					else
					    fprintf(stdout,"%3d %s%c",i,y,n);
				    }
				}
				fprintf(stdout,"\n");
				exit(EXIT_SUCCESS); 
			}
			/* option --interactive */
			else if (!strncasecmp(argv[ac], "--interactive",13)) {
				startInteractive=TRUE;
				continue;
			}
			/* option --exec */
			else if (!strncasecmp(argv[ac], "--exec",6)) {
				implicitRUN=TRUE;
				continue;
			}
			/* option --prompt */
			else if (!strncasecmp(argv[ac], "--prompt=",9)) {
				char *p=argv[ac]+9;
				if (*p=='\"') p++;
				strcpy(prompt, p);
				if (prompt[strlen(prompt)]=='\"')
					prompt[strlen(prompt)]='\0';
				continue;
			}
			else if (!strcasecmp(argv[ac], "--version")) {
			        fputc('\n',stdout);	
				printVersion();
				printHelpBanner();
				exit(EXIT_SUCCESS); 
			}
			else if (!strcasecmp(argv[ac], "--warranty")) {
			        fputc('\n',stdout);	
				printWarranty();
				exit(EXIT_SUCCESS);
			}
			else if (!strcasecmp(argv[ac], "--conditions")) {
			        fputc('\n',stdout);	
				printConditions();
				exit(EXIT_SUCCESS);
			}
			/* this feature is intentionally undocumented 
			 * I use it to generate the README file */
			else if (!strcasecmp(argv[ac], "--greetings")) {
				fprintf(stdout,"tbas README page\n");
				fprintf(stdout,WELCOME);
				printVersion();
				printHelpBanner();
				printHelp();
				fprintf(stdout,GREET);
				printWarranty();
				printConditions();
				fprintf(stdout,"It's GPL. Enjoy!\n\n");
				exit(EXIT_SUCCESS);
			}
			/* Ignore unrecognized options */
			else if (!strncmp(argv[ac],"--",2)) {
				fprintf(stdout,"(%s%s)\n",argv[ac],error[8]);
				continue;
			}
			
			/* parse single-dash options */
			while (*++argv[ac]) {
				c=*argv[ac];
				/* option -h
				 * print help*/
				if (c=='h') {
			        	fputc('\n',stdout);	
					printHelp();
					exit(EXIT_SUCCESS); 
				}
				/* option -v 
				 * print version */
				else if (c=='v') {
			        	fputc('\n',stdout);	
					printVersion();
					printHelpBanner(); 
					exit(EXIT_SUCCESS); 
				}
				/* option -d
				 * set normal Debug mode */
				else if (c=='d') {
					isDebug=TRUE;
					debugRaw=FALSE;
				}
				/* option -N
				 * set the null string as an spaced string */
				else if (c=='N') {
					phantomString=TRUE;
				}
				/* option -e
				 * set execute implicit RUN with -i */
				else if (c=='e') {
					implicitRUN=TRUE;
				}
				/* option -r
				 * set raw Debug mode */
				else if (c=='r') {
					isDebug=debugRaw=TRUE;
				}
				/* option -T 
				 * set timing (DEC-20) */
				else if (c=='T') {
					isTiming=TRUE;
				}
				/* option -S  
				 * (UNDOCUMENTED)
				 * print source code line number inside the 
				 * error message */
				else if (c=='S') {
					isPrintSourceCode=TRUE;
				}
				/* option -H
				 * set DEC-20 screen mode */
				else if (c=='H') {
					isHeader=TRUE;
				}
				/* option -D
				 * debug flag: avoid inverted colors */
				else if (c=='D') {
					isInvDebug=FALSE;
				}
				/* option -i
				 * set interactive mode */
				else if (c=='i') {
					startInteractive=TRUE;
				}

				/* option -p 
				 * parse BASIC command and exit */
				else if (c=='p') {
					char commandLine[(PSTRINGS+1)*COMPSTR+1];
					char command[PSTRINGS+1][COMPSTR];
					char *c, *l;
					int curr=0;
					argv++;
					if (ac+1>=argc) {
						strncpy_(commandLine,argv[ac-1]+1,(PSTRINGS+1)*COMPSTR+1);
					}
					else { 
						strncpy_(commandLine,argv[ac],(PSTRINGS+1)*COMPSTR+1);
					}
					if (!strlen(commandLine)) {
						fprintf(stdout,"? Error: null string for option -p.\n");
						exit(EXIT_FAILURE);
					}
					/* copy strings */
					curr=0;
					c=commandLine;
					l=command[curr];
					while (*c) {
						if (*c=='\\' && *(c+1)=='n') {
							c+=2;
							*l='\0'; // close curr
							curr++;
							if (curr>PSTRINGS) {
								fprintf(stdout,"? Error: too much strings for option -p.\n");
								exit(EXIT_FAILURE);
							}
							l=command[curr];
						}
						else *l++=*c++;
					}
					*l='\0'; // close last
					/* run strings */
					curr=0;
					while (curr<=PSTRINGS) {
						if (command[curr][0]) parseLine(command[curr],0);
						curr++;
					}
					exit(EXIT_SUCCESS);
				}
				/* option -R 
				 * (UNDOCUMENTED)
				 * set raw print mode (testing purposes) */
				else if (c=='R') {
					isRawPrint=TRUE;
				}
				/* option -l 
				 * (UNDOCUMENTED)
				 * list bare program when loaded and exit */
				else if (c=='l') {
					listingDo=BARE;
				}
				/* option -L 
				 * list program indented when loaded and exit */
				else if (c=='L') {
					listingDo=INDENT;
				}
				/* option -X 
				 * (UNDOCUMENTED)
				 * don't execute; exit after preprocessing
				 * in debug mode */
				else if (c=='X') {
					isNoExecute=TRUE;
					isDebug=TRUE;
				}
				/* option -z 
				 * (UNDOCUMENTED)
				 * set ZEROLIM to 10^-6 for rough execution */
				else if (c=='z') {
					ZEROLIM=1.0E-6;
					isZeroLim=TRUE;
				}
				/* option -V 
				 * (UNDOCUMENTED)
				 * print only version id */
				else if (c=='V') {
					fprintf(stdout,"%s",VERSION);
					exit(EXIT_SUCCESS); 
				}
				/* Ignore unrecognized options */
				else fprintf(stdout,"(-%c%s)\n",c,error[8]);
			}
		}
		else break;
	}

	/* if there is piped text following, parse it and exit */
	if (inputAvailable()) {
		parseLine(command,0);
		exit(EXIT_SUCCESS);
	}

	/* Widen resources for recursion (*rlim are defined into tbas.h)*/
	getrlimit(RLIMIT_STACK,&origrlim);
	setrlimit(RLIMIT_STACK,&tbasrlim);

	/* OK; now, if after any option no file name was given
	 * (or if tbas was launched with no parameters), issue an error */
	filename[0]='\0';
	if (((ac==argc)||(1==argc))) {
		if (!startInteractive) perror_(__LINE__,4,-1); 
	}
	else {
		int ern;
		/* get input file name (discard following arguments) 
		 * and setup name, attaching extension if not present */ 
		strncpy_(filename, argv[ac], COMPSCR);
		ern=setupName(filename,&c ,&c);
		if (ern>0) {
			startInteractive=FALSE;
			perror_(__LINE__,ern,-1);
		}
	}

	/* print banner */
	rl_display_prompt=FALSE;
	if (startInteractive && !isQuit) {
		fprintf(stdout, "\ntbas %s - Copyleft (C) Antonio Maschio - %s - GPL3 license\n",VERSION,CY);
		fprintf(stdout, "tbas comes free, with sources, and with ABSOLUTELY NO WARRANTY.\n");
		fprintf(stdout, "Interactive mode - Watch out: this mode uses numbered lines only!\n");
		fprintf(stdout, "Type SYSTEM or BYE to exit the interactive mode.\n");
		fprintf(stdout, "Type HELP for a short commands list.  Enjoy! It's GPL!\n\n");
	}
	

	/* assign COMMAND$ */
	command_string[0]='\0';
	ac++;
	while (ac<argc) {
		strncat_(command_string, argv[ac], COMPSTR);
		if (ac<argc-1) strncat_(command_string, " ", COMPSTR);
		ac++;
	}
	
	/* set features that depend on starting time */
	now=time(NULL);

	/* search for existing routefile */
	while (TRUE) {
		FILE *f;
		char fn[COMPSTR];
		sprintw(fn,COMPSTR,"%s%d.txt",TEMPROUTE,queueFileCount);
		f=fopen(fn,"r");
		if (f) {
			queueFileCount++;
			fclose(f);
		}
		else break;
	}
	
	/* Trap overflow error */
	signal(SIGABRT, sigquit);
	signal(SIGSEGV, sigquit);
	signal(SIGBUS, sigquit);
	/* Trap interrupts */
	signal(SIGHUP, sigint);
	signal(SIGINT, sigint);

	/* Store tcgetattr values */
	tcgetattr(0, &modes);
	savemodes = modes;

	/* if interactive mode was invoked, start a cycle to perform
	 * interaction until SYSTEM is typed */
	if (startInteractive) {
		 /* store program in memory */
		if (strlen(filename) > 0) {
			OLD();
		}
		/* disable -X option */
		isNoExecute=FALSE;
		/* start interactive cycle */
		goInt(); 
		startInteractive=FALSE;
	}

	/* console RUN
	 * Note: RUN records also starting timer */
	else {

		/* store program in memory */
		OLD();

		if (isHeader) printHeader();
		RUN();
	}
    	
	/* END (implicit!) */
	END(EXIT_SUCCESS);

	/* this is here only for C! */
	return EXIT_SUCCESS; 


} /* end main */

/* end of tbas.c */

