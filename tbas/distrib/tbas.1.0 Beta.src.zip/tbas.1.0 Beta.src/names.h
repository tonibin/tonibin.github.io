/* names.h 
 * tbas BASIC interpreter - Copyleft (C) 2015-2019 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 14 September 2019
 *
 * This header contains the names of the commands in the interactive session
 * 
 * This is tbas, a BASIC interpreter written in c99 for the UNIX world.
 * You must have gcc 4.X to compile (I suppose, though even 3.X may suffice).
 * 
 * tbas is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) 
 * any later version.
 *
 * tbas is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with 
 * tbas. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

char* names[]= {
/* 000 */ "auto",
/* 001 */ "bye",
/* 002 */ "cat",
/* 003 */ "cd",
/* 004 */ "clean",
/* 005 */ "continue",
/* 006 */ "convert",
/* 007 */ "core",
/* 008 */ "dest",
/* 009 */ "dump",
/* 010 */ "find",
/* 011 */ "goto",
/* 012 */ "glist",
/* 013 */ "help",
/* 014 */ "libs",
/* 015 */ "list",
/* 016 */ "list0",
/* 017 */ "load",
/* 018 */ "memory",
/* 019 */ "merge",
/* 020 */ "new",
/* 021 */ "old",
/* 022 */ "prompt",
/* 023 */ "pwd",
/* 024 */ "quit",
/* 025 */ "renumber",
/* 026 */ "resequence",
/* 027 */ "reset",
/* 028 */ "run",
/* 029 */ "save",
/* 030 */ "shell",
/* 031 */ "system",
/* 032 */ "trace",
/* 033 */ "type", 
/* 034 */ "aspect",
/* 035 */ "apropos",
/* 036 */ "untrace",
/* 037 */ "indent",
/* 038 */ "delete",
/* 039 */ "dir",
/* 040 */ "catalog",
/* 041 */ "edit",
/* 042 */ "monitor",
/* 043 */ "goodbye",
/* 044 */ "rename",
/* 045 */ "scratch",
/* 046 */ "runq",
/* 047 */ "gsave",
/* 048 */ "logoff",
/* 049 */ "release",
/* 050 */ "scan",
/* 051 */ "start",
/* 052 */ "where",
/* 053 */ "ls",
/* L+1 */ ""					/* last + 1 */
};

#define NAMESNUM 53				/* last useful */
