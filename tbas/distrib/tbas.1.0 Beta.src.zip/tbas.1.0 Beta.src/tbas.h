/* tbas.h 
 * tbas BASIC interpreter - Copyleft (C) 2015-2019 Antonio Maschio 
 * @ <ing dot antonio dot maschio at gmail dot com>
 * Update: 14 September 2019
 *
 * This is the main header
 * 
 * This is tbas, a BASIC interpreter written in c99 for the UNIX world.
 * You must have gcc 4.X to compile (I suppose, though even 3.X may suffice).
 * 
 * tbas is free software: you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by the Free 
 * Software Foundation, either version 3 of the License, or (at your option) 
 * any later version.
 *
 * tbas is distributed in the hope that it will be useful, but WITHOUT 
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for 
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with 
 * tbas. If not, see <http:/www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy!
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stddef.h>
#include <dirent.h>
#include <sys/dir.h>
#include <sys/param.h>
#include <errno.h>
#include "errors.h"
#include "names.h"
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <fnmatch.h>
#include <stdarg.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <libgen.h>
#include <pwd.h>
#include <readline/readline.h>
#include <readline/history.h>
#include <termios.h>
#include "apropos.h"

/* customizable values - 
 * Note: on an average system, MEMLIMIT=10000 builds a memory space of around 
 * 7 MB, MEMLIMIT=50000 builds a memory space of around 25 MB, MEMLIMIT=100000 
 * builds a memory space of 40 MB; if your system suffers of low memory, or is 
 * an embedded one (say openBSD as a virtual instance on Linux), you can change
 * this constant and reduce the memory space, reducing also the limits of
 * the program. If you on the contrary need more space, increase and recompile. 
 * Note: normally, the variables number VLIMIT is sufficient for any program.
 * Should you need more variable indices (in the assumption the memory of
 * your PC can stand it) you can increase and recompile. */
#define DEFPAGEHEIGHT 54         /* my printer value; use your own, if any */
#define MAXPAGEHEIGHT 162        /* a reasonable sufficient limit 3x54 */
#define MEMLIMIT      15000      /* tbas's memory magnitude */
#define VLIMIT        200000     /* variables number limit */
#define TEMPROUTE "./tbas_temp"  /* temporary name prefix for file printing */
#define INDLEVEL      3          /* indentation level for the int. session */
#define TSHELL        "bash"     /* user's preferred shell */
#define TEDIT         "vim"      /* user's preferred non-graphic editor */
/* Watch out! It must be a console editor (no gvim or xemacs) */

/* Hardwired versioning strings (dont' change!) */
#define VERSION "1.0 Beta (1)"
#define AU "Antonio Maschio"		                  /* Author */
#define EM "ing dot antonio dot maschio at gmail dot com" /* Email */
#define CY "2015-2019"		  	                  /* Years */

/* Hardwired constants (don't change!) */
#define TRUE        -1
#define FALSE        0
#define NIL          0
#define CONSOLE      0			// terminal id channel
#define SCREENLINE 255			// length of input line
#define COMPSCR    256			// length of c-string input line
#define FILELINE   255			// length of string-file-input line
#define COMPFIL    256			// length of c-string-file-input line
#define LIMIT      999			// tbas's core extension chunk length
#define RUNSTACK  1024			// running stack (for SUBs and DEFs)
#define SCRLIM      72 			// screen limit
#define MAXSTRLEN  255			// maximum length of a string
#define COMPSTR    256			// maximum length of a C-string
#define MAXARGS     16			// max arguments for commands
#define FORLIM    4096			// FOR and WHILE limit
#define IFLIM     4096			// IF limit
#define HANDLIM     16			// Handlers limit (WHEN ERROR USE)
#define DATLIM        99999		// DATA limit
#define ERRORCODE    100009		// flag for CAUSE ERROR
#define LABELMAX 2147483647		// alphanumeric labels code limit
#define STACKLIM       4096		// recursion stack limit (FN self call)
#define SUBSTACKLIM    4096		// recursion stack limit (SUB self call)
#define ONLIM            35		// the ON.GOTO/GOSUB address limit
#define TEMPVAR           0		// temp MAT var (don't change!)
#define MINFF -5.7896044482E76		// greatest negative real (-2^255)
#define INFF 5.7896044482E76	 	// greatest positive real (2^255)
#define ZERO 8.6361685763E-78 		// smallest real not zero (2^-256)
#define HALFPI  1.570796326795		// pi/2
#define TBASPI  3.14159265358979	// pi
#define RATIO 57.295779513082		// 180/pi 
#define LOG276 5.620400866		// log(276)=log(184x1.5)
#define ZEROCALC 2E-13			// adder value for trig checks
#define PSTACK     256			// dimension of the inner RPN stack
#define CORELIM 100000 	 		// limit for invalid line number
#define STREAMS      9			// max number of file channels
#define SEQ        100			// sequential file id
#define RANDOM     200			// random file id
#define NUMBER     300			// random file number sub-id
#define STRING    4000			// random file string sub-id
#define NUMRECLEN   64			// default random number record length
#define STRRECMAX  256			// default longest string record field
#define STRRECLEN   34			// default random string record length
#define FIRSTLEN     8			// length of first random sector
#define FORINPUT    10			// OPEN id for reading files
#define FOROUTPUT   20			// OPEN id for writing on files
#define NOUSE       -1			// quote modes
#define QUOTE        1
#define NOQUOTE      0
#define MARGINDEF   72			// 1..72 = 72 characters
#define MARGINMAX  132			// 1..132 = 132 characters
#define MARGINMIN    3			// 1..3 = 3 characters
#define ZONEBASE    14			// standard zone system (DEC-10 her.)
#define VREAD        1			// read/write modes
#define VWRITE       2
#define VINPUT       3
#define VPRINT       4
#define NUMID     -127			// USING number id
#define STRID     -126			// USING string id
#define CENTERED    10			// USING string output
#define LEFTJUST    20
#define RIGHTJUST   30
#define EXTENDED    40
#define FORMATLINE  64			// (arbitrary): output format = 64*4+1
#define SINGLE      10			// identifiers for DEF
#define MULTI       99
#define PROC   	   100			// SUB/DECLARE constants
#define FUNC       200
#define VAR        300
#define STR        400
#define NUM        800
#define NUMINT     900
#define STRNUMARR 5000
#define CASEVALUE  100
#define CASEEND    200
#define EXIT_STOP    2
#define EXIT_SYSTEM  3
#define EXIT_ABORT   4
#define PRECLIM     16
#define TERMINAT "A LINE TERMINATOR OR APOSTROPHE" 	// system strings
#define FFLFVT "A FF,LF,VT, OR CR"
#define EXTL    ".bas"
#define EXTU    ".BAS"
#define INPUTS   " ? "
#define CONTINUE  -100
#define NULLSTR   "\0"
#define DECADD   10000			// DEC and string management in SUB
#define BITS        32			// for fprintb (binary printer)
#define RELATIVE  1000			// for OPTION COMPARISON
#define ABSOLUTE  9999		
#define NAMEDIM     56			// limit for SUB, DECLARE, length names
#define NOTAFILE    -4			// codes for EXISTS() return values
#define NOEXIST     -8
#define NOACCESS     0
#define DOREAD       1
#define ALL_LINES   10
#define ONLY_SUBS   99
#define DOWRITE      2
#define TIMEOFFSET  15			// setYear() offset, forward time
#define PROCNAMEMAX 65			// max length of a sub's name
#define THISHEADER "%-13s %-14s%-13s"	// header formatter
#define GREET "Notes:\n- to compile type \'make\' as user in tbas\' source directory.\n- to install type \'make install\' as root after compiling.\n  (but I'm sure you know better than me what to do!)\n\n"
#define WELCOME "\nWelcome, user! I hope you\'ll like this program.\nHere\'s some information about it and its license...\n"
#define INVCOLOR   "[7;37;40m"
#define RESETCOLOR "[1;m"
#define BLUECOLOR  "[1;34m"
#define REDCOLOR  "[1;31m"
#define _CR '\n'
#define YEARLIMIT 1583
#define HISTORY	"./.tbas_history"	// readline facility
#define VINTAGESET   10
#define VINTAGERESET 20
#define SEGLIM  78			// apropos screen limit
#define BARE    10
#define INDENT  20
#define NULLS   "|           |"
#define PSTRINGS     15
#define ONWARN       10
#define OFFWARN      99

/* Detect Windows */
#ifdef _WIN16 
    #define NOUNIX
#endif
#ifdef _WIN32 
    #define NOUNIX
#endif
#ifdef _WIN64 
    #define NOUNIX
#endif

/* current directory detection*/
#ifndef NOUNIX
    /* UNIX and Linux */
    #define GETCWD getcwd
    #include <unistd.h>
#else
    /* Windows */
    #define GETCWD _getcwd
    #include <direct.h>
#endif

int selectDone=FALSE;
int syserr=FALSE;
int listingDo=FALSE;
int phantomString=FALSE;

/* system struct entities (absolutely don't change!) */
/* SUB structure */
struct t_subroutine {
	int vars[LIMIT];	// variables as arguments holder 
				//    vars[0] holds variable number
				//    numeric vars are stored with their index
				//    string vars are stored with index+1000
	int number;		// sub number
	int code;		// sub hash name-code
	char name[PROCNAMEMAX];	// sub name
	int type;		// = PROC|FUNC/VAR
	int rettype;		// = STR|NUM
	int start;		// start and end hold line numbers
	int end;		// limits of the SUB multiline structure
	double numres;		// result of a numeric sub function
	char *strres;   	// result of a string sub function
};
typedef struct t_subroutine TSub;

/* DECLARE structure */
struct t_declare {
	char *name;		// declaration name
	int rettype;		// = STR|NUM
	int isInt;		// NUM is integer
	int isArr;		// name is an array
	int isConst;		// num is CONST
	int isCommon;		// pass to CHAINed/MODULE program
};
typedef struct t_declare TDeclare;

/* system struct entities */
/* DEF FN structure */
struct t_definition {
	int vars[LIMIT];	// variables as arguments holder 
				//    vars[0] holds variable number
	char *def;		// pointer to the single line DEF string
	int type;		// 1=single line, 2=multi line
	int start;		// start and end hold line numbers
	int end;		//    limits of the DEF FN multiline structure
	double res;		// result of a multiline structure
	char *lines[LIMIT];	// storing of the multilines structure
};
typedef struct t_definition Tdef;

/* DIM structure for numeric arrays */
struct t_array {
	int brow;		// base row and column define the memory usage
	int bcol;		///   and hold the declared dimension
	int row;		// row and col are used into calculation
	int col;		//    and hold the current dimension
	int type; 		// type 0=undeclared, 1=vector, 2=matrix
	double *elem;		// pointer to the array base
};
typedef struct t_array Tarray;

/* DIM structure for string arrays */
struct ts_array {
	int brow;		// base row and column define the memory usage
	int bcol;
	int row;		// row and col are used into calculation
	int col;
	int type; 		// type 0=undeclared, 1=vector, 2=matrix
	char *elem;		// pointer to the array string
};
typedef struct ts_array TSarray;

/* stream structure for I/O channels */
struct t_iostream {
	/* general parameters */
	FILE * stream;		// file descriptor
	char ioname[COMPSTR];	// file name
	int isopen;		// file open flag
	int type;		// NOUSE | SEQ | RANDOM
	int mode;		// NOUSE | STRING | NUMBER (rand)
	int fcounter;		// printing position in the file (seq)
	int fprintn;		// flag TRUE | FALSE for printing CR
	int wayout;		// VREAD | VWRITE (seq)
	int reclen;		// length of record (for seek advancing) (rand)
	int currseek;		// holds current pos for random files (rand)
	int randomaccessed;	// TRUE or FALSE; if FALSE, read line 0 (rand)
	int quote;		// QUOTE | NOQUOTE (seq)
	int margin;		// NOUSE | int from 1 to MARGIN (seq)
	int page;		// page number (seq)
	int pagerow;		// current position in page (seq)
	int height;		// current max page height (seq)
	int pagenumber;		// print bottom page number TRUE | FALSE
	int reader;		// NOUSE | VREAD  | VINPUT
	int writer;		// NOUSE | VWRITE | VPRINT
	int isReadonly;		// TRUE | FALSE
	char queuename[COMPSTR];// queue file name (for PREPEND)
	int isPrepend;		// TRUE | FALSE
};
typedef struct t_iostream Tiostream;

/* USING structure for storing parameters of strings & numbers */
struct t_using {
	/* numbers */
	int ic;			// integer digits count
	int dc;			// decimals digits count
	int isInt;		// flag for integer (TRUE) or float
	int isExp;		// flag for Exponential
	int isMin;		// flag for minus at the end
	int isCom;		// flag for thousands separators
	char com;		// character for thousands separator
	int isDol;		// flag for preprinting the dollar sign
	char fill;		// character to be used for filler (' '|'*')
	int isZer;		// in case isInt is TRUE and |num| < 1.0
	/* strings */
	int len;		// string length
	int type;		// justification type: C,R,L,E
};
typedef struct t_using TUsing;

/* HANDLER ministructure for the WHEN ERROR USE error catching structure */
struct t_handler {
	int pos;		// address of the handler
	int endwhenpos;		// address of the END WHEN (for resume)
	char *hname;		// the name of the handler 
};
typedef struct t_handler THandler;

/* EXIT SUB stack-based backup */
struct t_sub_backup {
	int ifTOS;
	int selectTOS;
	int selectcount;
	int whileTOS;
	int whilecount;
	int doTOS;
	int docount;
	int forTOS;
	int forcount;
};
typedef struct t_sub_backup TSubBackup;

/* LIBRARY sections structure */
struct t_lib {
	char libname[COMPSTR];
	int start;
	int end;
};
typedef struct t_lib TLib;


/* Functions prototypes (decidedly don't change!)*/
/* USING statements */
int FWRITEUSINGSHARP(int isWrite, int isChan, int ch) ;
int printFormatted(char* BForm, char* list, int isWrite, double val) ;
void printFormattedString(char *str, TUsing us, char *dest) ;
int printFormattedNumber(double num, TUsing us, char *dest) ;
int intLen(double num) ;
void outNum(double num, TUsing us, char *dest) ;
int checkNames(int c, char *fname) ;
void WFCR(int ch, int i);
/* FILE and PRINT statements */
int FOPEN(void);
int FPIPE(void);
int FCLOSE(void);
int FUPDATE(void);
int FFILE(int isFiles, int l) ;
int setupName(char *fn, int *m, int *l);
int testEOF(int ch) ;
int getEOF(int ch) ;
int FMARGIN(void) ;	
int FNOMARGIN(void);
int FPAGE(void) ;
int FPAGENUM(int s) ;
int FNOPAGE(void) ;
int FQUOTE(int quotemode) ;
int FWRITESHARP(int flag) ;
void fillGap(int ch, int actualIndex) ;
int doesExist(char *fnam) ;
int FWRITECOLON(void) ;
int FREADSHARP(int flag, int mode) ;
int FREADCOLON(void) ;
int FRESTORE(void) ;
int FAPPEND(void) ;
int FSCRATCH(void) ;
int FSET(void);
int FFILLPAGE(void) ;
void printContained(int ch, char *string, int margin);
void printContainedPlain(int ch, char *string, int margin);
void printContainedRaw(int ch, char *string);
/* CHAIN and CHANGE statements */
int CHAIN(void) ;
int CHANGE(void) ;
/* MAT statements */
double MATDOT(void);
int MATbyK(int varr);
int MATTRN(int varr);
void matinvert(int varr, int var1) ;
int MATINV(int varr);
int MATIDN(int var);
int MATZER(int var, double op);
int MATNUL(int var);
int MATsum(int varr, int var1, int var2, int op);
int MATmul(int varr, int var1, int var2);
int MATtype(void) ;
int matCopy(int dst, int src);
int matStrCopy(int dst, int src);
int matReadAssign(int var, int t, int m, int n);
int matStrReadAssign(int var, int t, int m, int n);
int MATINPUT(int ch, int flag) ;
int MATFINPUT(int flag) ;
int MATPRINT(int ch, int flag);
int MATFPRINT(int flag);
int MATREAD(void);
/* DECLARE statements */
int issaa(char *p) ;
int isstrvar(char *p) ;
int isnumvar(char *p) ;
int isfn(char *p) ;
int dimArray(int var, int T, int M, int N) ;
double getArrayVal(int var, int t, int m, int n) ;
void setArrayVal(int var, int t, int m, int n, double val);
void setArrayValFast(int var, int t, int m, int n, double val);
int dimStrArray(int var, int T, int M, int N) ;
char *getArrayStr(int var, int t, int m, int n) ;
void setArrayStr(int var, int t, int m, int n, char *str);
void setArrayStrFast(int var, int t, int m, int n, char *str);
int getBound(int l);
int DECLARE(int i) ;
int ERASE(void);
int REDIM(void);
/* INPUT statements */
int INPUT(int m) ;
/* BASIC statements */
double getRandom(void);
int DEF(int l) ;
int SUB(int l) ;
int _RETURNTOSUB(void);
int END(int s) ;
int ABORT(void) ;
int FOR(void);
int EXITSUB(void);
int EXIT(int m); // wrapper
int BREAK(void);
int DOCONTINUE(void);
int EXPORT(void);
int COMMON(void);
int DO(void);
int DOWHILE(void);
int DOUNTIL(void);
int LOOP(void);
int LOOPWHILE(void);
int LOOPUNTIL(void);
int WHILE(void);
int ENDWHILE(void);
int GOSUB(void);
int GOTO(void);
int IFTHEN(void);
int IF(void);
int ELSE(void);
int ELSEIF(void);
int ENDIF(void);
int NEXT(void) ;
int ONGOTO(void) ;
int PRINT(int flag) ;
int RANDOMIZE(void) ;
int READ(void) ;
int RESTORE(void);
int _RETURN(void);
int SELECT(void);
int CASE(void);
int CASEDEFAULT(void);
int ENDSELECT(void);
int OPTION(void);
int SETDIGITS(void);
int DOWAIT(void);
int DOGET(void);
int DOPUT(void);
/* LET statements */
int LET(void) ;
int multiLET(void);
int assign(void) ;
char *assignLeft(void);
char *assignRight(void);
char *assignMid(void);
/* System parser statements */
char *strcasestr_oq(char *pl, char *pr);
char *strcasestr_(char *big, char *little);
int strncasecmp_(char *d, char *s, int N);
char *strncpy_(char *dst, char *src, int dw);
char *strncat_(char *dst, char *src, int dw);
char *chrcat_(char *dst, int c, int dw);
int sprintw(char *dest, int len, char *format, ...);
char *SS(void) ;
double S(void) ;
char *_dupstr(char *str);
double getFunc(void);
double getVal(void);
int priority(const int op) ;
int strRel(void);
void doVintage(int f);
void timedString(double i);
void optoken(char *q);
char *dotrim(char *s, int d);
/* System functions */
char *calcDEF(void) ;
char *execSUB(int n, char*p, double *nr, char *sr);
int findSUB(char *p, char** p2, int* t, int* r);
int findDEC(char *p);
int searchDEC(char *p, int l);
char *getMonthString(void) ;
char *getString(void) ;
char *makechar(char *str) ;
char *spaces(int v);
double power(double base, double expon) ;
int exec(char *lpc) ;
void s_exit(int state);
int getDay(void) ;
int getWDay(void) ;
int getHour(void) ;
int getMin(void) ;
int getMonth(void) ;
int getSec(void) ;
int getYear(void) ;
int setYear(int y) ;
int sign(double h);
int gregDayNumber(int y, int m, int d);
int isSingleDEF(char *d) ;
int storeSingleLineToCore(char *line, int l) ;
struct tm *getTime(void) ;
void FAC(int ch) ;
void FCR(int ch) ;
void fillPage(int ch) ;
void printFooter(int ch);
void doExp(char *pos, double *base, int *exp) ;
int emitNUM(int ch, char minus, char *num, int flag, char *dest) ;
int printNUM(int ch, double num, int flag, char *dest) ;
void parse(char**m, int s, int e) ;
int recog(int num, ...);
int parseLine(char *s, int l);
void printHeader(void);
void popRUN(void) ;
void preParse(char**m, int s, int e) ;
int checkCommand(char *c, char *l, char**q);
void pushRUN(void) ;
int bcomp(char *src, char *dest);
int bonecomp(char *src, char *dest);
int bthencomp(char *src);
void removeLibs(void);
void stripBlanks(char *src, char *dest) ;
void stripBlanks2(char *src, char *dest) ;
int isARing(int num);
void turnToUpper(char *str) ;
void sigquit(int sig);
void sigint(int sig);
void sigtrap(int sig);
void *xmalloc(size_t size);
int getAddr(int v);
int setAddr(char *l, char **p);
int getLabelAddr(char *l, char **p);
void swapDEC (int v1, int v2);
int fprintb(char *res, int n, int mode);
void modulo(int A, int B, int *d, int *m, int f);
void erase(char *d, int s);
void memcpy_(void *dst, void *src, int size);
void showDEC(int decCount, int flag);
void showDEF(int i, int m);
void showSUB(int i, int m);
void includeLibs(char * u);
int closeFiles(void);
int closePrepend(int ch);
int fullLines=FALSE;
char basedir[4*COMPSTR];
char BASEDIR[4*COMPSTR];
/* QUEUE and ROUTE */
int QUEUE(void);
int ROUTE(void);
int LPRINT(void);
int openRoute(void);
/* BASIC Interface emulator shell commands */
void OLD(void) ;
int LOAD(char **m, char *f, int s, int w);
int RUN(void) ;
int convert(FILE *fn, int n, int s);
/* Error messaging system */
int perror_(int line, int errNum, int l, ...) ;
void syserr_(int line, int errNum, int l, ...) ;
/* Info messaging collection */
void printConditions(void) ;
void printExistence(void);
void printHelp(void) ;
void printVersion(void) ;
void printHelpBanner(void) ;
void printUsage(void) ;
void printWarranty(void) ;
int _addline(char *text) ;
void silenceTick(char *str);
void list_indented(int n, int l, int s, int e, FILE *c, int m);
char *session_load(char *p);

/* Inspective macros (imperatively don't change!) */ 
#define isand(p) ((*(p)=='&' && *(p+1)=='&'))
#define is_or(p) ((*(p)=='|' && *(p+1)=='|'))
#define isxor(p) ((*(p)=='!' && *(p+1)=='!'))
#define iseqv(p) ((*(p)=='#' && *(p+1)=='#'))
#define isimp(p) ((*(p)=='-' && *(p+1)=='>'))
#define isdif(p) ((*(p)=='<' && *(p+1)=='>') || (*(p)=='>' && *(p+1)=='<'))
#define isleq(p) ((*(p)=='<' && *(p+1)=='=') || (*(p)=='=' && *(p+1)=='<'))
#define isgeq(p) ((*(p)=='>' && *(p+1)=='=') || (*(p)=='=' && *(p+1)=='>'))
#define issri(p) ((*(p)=='>' && *(p+1)=='>'))
#define issle(p) ((*(p)=='<' && *(p+1)=='<'))
#define istim(p) ((*(p)=='*' && *(p+1)=='*'))
#define ispro(p) ((*(p)=='=' && *(p+1)=='='))
#define isqua(p) ((*(p)=='|' && *(p+1)=='='))
#define ismod(p) ((*(p)=='%' && *(p+1)=='%'))
/* isnm check if entity pointed by p is a literal number
 * ismo checks if p is a math operator
 * isro checks if p is a relational operator
 * islo checks if p is a logical operator
 * isop checks if p is an operator (that is math, relational or logical)
 * iscs checks if p is a comma or a semicolon
 * isanystring checks if p points to any string format
 * isanynumber checks if p points to any number format
 * isblankcommatab checks if p points to a space, a tab or a comma 
 * isnamechar checks if p points to a character suitable for SUBs names */
#define isnm(p) (isdigit(*(p)) || *(p)=='.' || *(p)=='-')
#define ismo(p) (*(p)=='+' || *(p)=='-' || *(p)=='*' || *(p)=='/' || *(p)=='^' || (istim(p)) || *(p)=='\\' || ismod(p) || (issle(p)) || (issri(p)))
#define isro(p) (*(p)=='<' || *(p)=='>' || *(p)=='=' || (isdif(p)) || (isleq(p)) || (isgeq(p)))
#define islo(p) ((isand(p)) || (is_or(p)) || (isxor(p)) || (iseqv(p)) || (isimp(p)) || *(p)=='{' || *(p)=='}' || *(p)=='&' || *(p)=='|' || *(p)=='#')
#define isop(p) ((ismo(p)) || (isro(p)) || (islo(p)))
#define iscs(p) (*(p)==',' || *(p)==';')
#define isanystring(p) ((isstrvar(p)) || (issaa(p)) || *p=='\"')
#define isanynumber(p) ((isnumvar(p)) || (isnm(p)))
#define isblankcommatab(p) (strchr((p),' ')||strchr((p),'\t')||strchr((p),','))
#define isnamechar(p) (*(p)=='_' || (isalnum(*(p))) || *(p)=='.' || *(p)=='?')
#define isbeginnamechar(p) (*(p)=='_' || (isalpha(*(p))))
#define is_pa(p) (*(p)=='<' && toupper(*(p+1))=='P' && toupper(*(p+2))=='A'&& *(p+3)=='>')
#define norow(row) ((row)<0 || (row) > LABELMAX)
#define isante(p) (*((p)-1)==')' || isblank(*((p)-1)))
#define ispost(p) (*((p)+1)=='(' || isblank(*((p)+1)))
#define currcentury (((int)(getYear()/100))*100)
/* Lotsa global variables! */
/* System variables (Don't change at all!) */
char LOGAS[COMPSTR];	 /* Login String (returned by USR$) */
char filename[COMPSCR];
char line[COMPSCR];
char longname[COMPSCR];
char includename[COMPSCR];
FILE *CONSOLEIN;
char _FORMAT[COMPSTR];
double ZEROEQUAL=1.0E-6;
double ZEROLIM=0.0;
int ZONE=ZONEBASE;
int PAGEHEIGHT=DEFPAGEHEIGHT;	// value of my printer
int PRECISION=-1;
int debugRaw=FALSE;
int endCore=0;
int isIncludingLibs=FALSE;
int isIgnoreEmptyLines=FALSE;
int isLOAD=FALSE;
int libStart=0;
int libCount=0;
int isCap=FALSE;
int isCaseSensitive=TRUE;
int isDebug=FALSE;
int isInvDebug=TRUE;
int isEcho=TRUE;
int isHeader=FALSE;
int isQuit=FALSE; // goInt()
int isSystem=FALSE; // goInt()
char sysqueue[COMPSTR];
int isInterrupt=FALSE;
int isNoExecute=FALSE;
int isPrompt=TRUE;
int isRadians=TRUE; // RADIANS default; when FALSE, DEGREES are default
int isRawPrint=FALSE;
int isTiming=FALSE;
int isCont=FALSE;
int isToReset=TRUE;
int isZeroLim=FALSE;
int isSpacing=FALSE;
int isComparison=RELATIVE;
int isExplicit=FALSE;
int isPrintSourceCode=FALSE;
int isAmericanFormat=TRUE;	// if FALSE, go for European number format
int termiosHasOccurred=FALSE;
int forceArray=FALSE;
int isPrepend=FALSE;
int isCommon=FALSE;
int futureDecCount=0;
int numEval=FALSE;
int isValOn=FALSE;
int vmaxLast=0;
int vminLast=0;
int vsumLast=0;
struct stat statbuf;
struct termios modes, savemodes;
/* interactive session */
int startInteractive=FALSE;
int implicitRUN=FALSE;
int isSingleBASICCommand=FALSE;
int printReady=TRUE;
int isRunOn=TRUE;
int isEndOfStatement=FALSE;
int warnState=ONWARN;
/* readline setup */
char* tf_generator(const char *text, int state); 
/* System strings */
char sep=','; // comma option in PRINT USING feature
static char *month[]=
{"", "JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEPT","OCT","NOV","DEC" };
static char *monthlabel[]=
{"", "January","February","March","April","May","June","July","August","September","October","November","December" };
static char *daylabel[]=
{"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday" };
char Tcommand[COMPSTR];
char *comout;
int comlen=0, Tslice=0, chread=0;

/* Program flow and var variables
 * l holds the current program line number
 * P is an double array holding variables contents 
 * PS is a character-pointers-array holding references to strings
 * startingLine holds user specified starting line (for RUN)
 * pads are temporary string buffers */
int l;
double P[VLIMIT];
char PS[VLIMIT][COMPSTR];
int startingLine = 1;
char sspad[COMPSTR], pad[COMPSTR], *PAD=pad, *MYPAD=sspad;
char prompt[COMPSTR];

/* findDEC aid 
 * _len holds complete name length 
 * _rettype hold return type code
 * _arr hold array flag */
int _len,_rettype,_arr;

/* DIM arrays data management 
 * dim is the numerical array 
 * dimS is the string array 
 * BASE is the OPTION BASE code */
Tarray dim[VLIMIT];
TSarray dimS[VLIMIT];
int BASE=0;	// 0|1

/* Memory system
 * m is an array holding pointers to program lines 
 * p is the main char pointer to the current buffer position
 * s and d are various char pointer helpers used into RUN 
 * fm is a flag mask of all file lines; if TRUE, the corresponding line
 *    is marked as not available for addressing 
 * ln holds the addresses of a line number labels (ln[line]=linenum) */
char *m[MEMLIMIT+10], *p,*s,*d;
int  fm[MEMLIMIT+10];
int  ln[MEMLIMIT+10];
/* parseSpace is a temporary pad for holding direct calls in IFTHEN() */ 
char parseSpace[COMPSTR];
/* pagerow is the current next printing row on the screen line  */
int pagerow=5; // don't change
/* parser variable - TRUE when an operator is expected */
int opturn=0;	// don't change!
/* the flag for exp overflow */
/* the CHAIN flag - TRUE if into a program CHAIN - from second file on */
int isChain=FALSE;
/* string of COMMAND$ */
char command_string[COMPSTR];
char valRest[COMPSTR];
char evalRest[COMPSTR];
char exprRest[COMPSTR];

/* Process helpers
 * B is the general input buffer;
 * J is a general purpose buffer used in preParse()
 * F is a character-holder used by the blank stripper 
 * cAddr holds the program inner references for cycles and decision structure 
 * valcol, valrow are the screen coordinates for LOCATE */
char B[SCREENLINE+10], J[SCREENLINE+10], F[2];
int cAddr[MEMLIMIT+10];
int valcol=1,valrow=1;
int red,green,blue;

/* DATA management
 * D is an array holding DATA numbers
 * DS is an array of pointer to char holding DATA strings
 * dc (data counter) yields current pointer to numeric data
 * dcs (data counter for strings) yields current pointer to string data
 * dataLimit is the total of DATA numbers found into the listing 
 * dataLimitS is the total of DATA strings found into the listing */
double D[DATLIM];
char *DS[DATLIM];
int DN[DATLIM],DSN[DATLIM];
int dc=0, dcs=0;
int dataLimit=0, dataLimitS=0;

/* DECLARE management
 * vn holds the DECLARE definitions in a proper struct
 * decCount holds current number of declared variables */ 
TDeclare vn[VLIMIT];
int decCount=0;

/* SUB management
 * sn holds the SUB definitions in a proper struct
 * isSubRun is TRUE during a SUB evaluation
 * isSubVar holds var code during a SUB evaluation 
 * isSubCalc flag is set into LET() if a correct assignment is done 
 * isSubFor is incremented into FOR() during a SUB evaluation
 * subCount holds number of SUB currently declared
 * numRes holds numerical SUB return value
 * strRes holds string SUB return value
 * XCount holds index of SUB calls level during execution
 * saveSubCount holds subCount code in intercalling SUBs
 * rememberCode and rememberName are used in findSUB as a means to return
 * immediately SUB var code in case it is called a second time afterwards
 * Note: SUBs can call themselves */ 
TSub sn[LIMIT*2];
int isSubRun, isSubVar, isSubCalc, isSubFor, subCount=0;
double numRes=0.0;
char strRes[COMPSTR];
int XCount=0;
int saveSubCount[VLIMIT];
int rememberCode;
char rememberName[COMPSTR];
struct rlimit tbasrlim={RLIM_INFINITY,-1};
struct rlimit origrlim;

/* DEF FN management
 * fn holds the DEF FN definitions in a proper struct
 * isDefRun is TRUE during a Multiline DEF evaluation
 * isDefVar holds var code during a Multiline DEF evaluation 
 * isDefCalc flag is set into LET() if a correct assignment is done 
 * isDefFor is incremented into FOR() during a Multiline DEF evaluation
 * isDefWhile is incremented into WHILE() during a Multiline DEF evaluation
 * isDefCount holds number of multiline DEFs currently open 
 * FNXlist holds value of variables in the FN, to check a self call
 * FNXTOS holds last FN value 
 * currentExecSub hold the sub number of currently SUB under execution */ 
Tdef fn[LIMIT*2];
int isDefRun, isDefVar, isDefCalc, isDefFor, isDefWhile, isDefDo, isDefCount=0;
int FNXlist[LIMIT];
int FNXTOS=0;
double calcres=0.0;
int currentExecSub=0;

/* GOSUB data management and storing
 * gosubStack holds the jump data for RETURN
 * gosubTOS is the pointer to gosubStack */
int gosubStack[LIMIT*2];
int gosubTOS = 0;

/* FOR..NEXT data management 
 * forStack holds data for cycles
 * forAddr holds addresses of relative NEXT for each FOR statement
 * forTOS is the pointer to forStack
 * forcount is a counter for nested FOR cycles */
double forStack[6*FORLIM+6];
int forAddr[MEMLIMIT+10];
int forTOS = 0;
int forcount=0;

/* WHILE..END WHILE data management 
 * whileStack holds data for cycles
 * whileAddr holds addresses of relative END WHILE for each WHILE statement
 * whileTOS is the pointer to whileStack
 * whilecount is a counter for nested cycles */
double whileStack[2*FORLIM+2];
int whileAddr[MEMLIMIT+10];
int whileTOS = 0;
int whilecount=0;

/* DOWHILE..LOOP and DOUNTIL..LOOP data management 
 * doStack holds data for cycles
 * doAddr holds addresses of relative LOOP/WHILE for each DO statement
 * doTOS is the pointer to doStack
 * docount is a counter for nested cycles */
double doStack[2*FORLIM+2];
int doAddr[MEMLIMIT+10];
int doTOS = 0;
int docount=0;

/* SELECT management 
 * numformula holds the result of numeric computation of SELECT clause
 * strformula holds the result of string computation of SELECT clause
 * selectStack holds data for jumps
 * selectAddr holds addresses of relative CASE/END for each SELECT statement
 * selectTOS is the pointer to selectStack
 * selectcount is a counter for nested SELECT
 * isMuteSelect holds flag of SELECT case without computation*/
double numformula[LIMIT*2];
char *strformula[LIMIT*2];
int selectStack[LIMIT*2];
int selectAddr[MEMLIMIT+10];
int selectTOS=0;
int selectcount=0;
int isMuteSelect[LIMIT*2];

/* IF THEN management 
 * ifStack holds data for jumps
 * ifAddr holds addresses of relative ELSE/END IF for each IF statement
 * ifTOS is the pointer to ifStack */
int ifStack[IFLIM];
int ifAddr[MEMLIMIT+10];
long long int ifTOS=0;

/* DEF/SUB back variables */
TSubBackup subBackup[SUBSTACKLIM+1];

/* MAT variables management
 * detValue is a placeholder for DET (MAT INV determinant)
 * isSingular is set in case of singular matrix (for the ELSE case of MATINV)
 * numValue is a placeholder for NUM (MAT INPUT entries) */
double detValue=0.0;
int invElseCase=FALSE;
int unresCase=FALSE;
int numValue=0;

/* Timing variables 
 * tv is used for time calculations 
 * beginS is calculated at start for the TIM() function and the timer
 * now contains seed for current number generator */
struct timeval tv;  
double beginS=-1.0, endS=0.0;
time_t now;

/* running-state backup arrays 
 * - lb for l (line numbers)
 * - sb for startingLine
 * - pb for printn
 * - cb for counter
 * - eCb for endCore
 * - runTOS is a pointer to the stacks in case of runtime
 *   calls events
 * - nowb for the random generator */
int lb[RUNSTACK], sb[RUNSTACK], pb[RUNSTACK],cb[RUNSTACK], eCb[RUNSTACK];
int runTOS=0;
time_t nowb;

/* I/O variables 
 * channel contains the channel 0-9 data (0 = console, 10 = route channel) 
 * currChan yields current channel id (used into FILES) 
 * writeSeqStart and writeSeqStep contains data for WRITE# 
 * isSingleUSING is the flag for USING
 * singleUSING is the pad for USING */
Tiostream channel[STREAMS+2];		// BASIC channels 1-9
int writeSeqStart=1000;			// used into WRITE#
int writeSeqStep=10;			// used into WRITE#
int isSingleUSING=FALSE;
char singleUSING[COMPSTR];
int lastChannel=0;

/* Random number generator algorithm variables 
 * Rand2Seed contains first seed (recalculated each time)
 * randDivi contains the divisor value
 * randSeed contains first seed (recalculated each time) */
int randDivi=32768; // should always be even
int randSeed=7139;
double rand2Seed=16.45790082;

/* ROUTE and QUEUE statements 
 * routefile contains the name of the temporary file
 * isQueued is the flag that defines the enabling of the QUEUE feature
 * isRoute is the flag that determines if the file is effectively printed
 * isLPrint is the flag that defines the enabling of the single LPRINT feature
 * isLPrint is the flag that defines the enabling of the LPRINT feature 
 * fileStays is a flag determining if the tempororary file should be removed */
char routefile[COMPSTR];
int isQueued=FALSE;
int isRoute=TRUE;
int isLPrint=FALSE;
int isLPrintEnabled=FALSE;
int fileStays=FALSE;
int queueFileCount=1;
#define ROUTECHANNEL 10
#define ROUTESTRING "lpr"

/* error detection management 
 * errLine contains the line number where the error occurred 
 * errValue contains the error code (always greater than zero)
 * isOnErrorPos contains zero or the label of the ON ERROR handler 
 * isOnErrorTrap contains zero or the code of the ON ERROR <code> 
 * isNoDataPos contains zero or the label of the NO DATA handler 
 * isWhenErrorInPos is TRUE when the WHEN ERROR IN structure is enabled
 * isWhenErrorUsePos is TRUE when the WHEN ERROR USE structure is enabled
 * isUsePos contains zero or the address of the WHEN ERROR IN handler in USE 
 * THandler handler contains the handlers database (up to HANDLIM) 
 * whenAddr keeps track of the mutual references of WHEN/END WHEN */
int errLine=0, arrLine=0;
int errValue=0, arrValue=0;
int isOnErrorPos=0;
int isOnErrorTrap=0;
int isNoDataPos=0;
int isWhenErrorInPos=0;
int isWhenErrorUsePos=0;
int isUsePos=0;
int isUseActive=FALSE;
int isHandlerNum=0;
int isHandlerActive=FALSE;
int endWhenIn=0;
int endWhenUse=0;
THandler handler[HANDLIM+1];
int whenAddr[LIMIT*2];
int handlerAddr[LIMIT*2];
int handlerTOS=0;
int isOnAttentionPos=0;
int tind=3; // indentation value for the Interactive session
char traceISval[COMPSTR]; // trace name for TRACE in the Interactive session

/* Library sections database */
TLib tlib[SUBSTACKLIM];
int libTOS=0;

/* end of tbas.h */

