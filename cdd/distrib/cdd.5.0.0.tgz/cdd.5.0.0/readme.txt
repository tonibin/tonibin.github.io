cdd - compact disc database manager, version 5.0.0
Antonio Maschio, 2006-2012 <tbin at libero dot it>

cdd is a compact disc database manager for your musical cd collection.

Usage: cdd [OPTIONS] [pat1] [+|- pat2]

cdd reads all the content of a textual database (by default $HOME/.cdd/cd.db) 
and selects, for screen output, all lines matching pattern 'pat1' (which may 
contain spaces), formatting output in various friendly views.
'pat2' (which may contain spaces too) refines search, selecting only lines 
containing pat2 if + is used, or excluding those containing pat2 if - is used.
Options are input in any order, provided arguments follow those needing them.
The first time cdd is invoked, it creates its own working directory, .cdd/, in
the user $HOME directory; this folder will contain the default database, all
temporary files created by cdd and the file cdd_profile, which contains user 
preferences; customize it at pleasure once it has been created after first run.

Options (<mandatory arguments>, [facultative arguments]):

 -@            output only alternative-position pattern-matching records
 -a --all      print all the database entries
 -A            align output in fixed-size columns (may trim fields)
 --add [db]    add records to current or [db] database
 -b            output only box-set pattern-matching records
 -B            in aligned mode (-A), print the country's field in place of notes
 -c            report total number of records in the current database
 -C            print a complete report of the search results
 --copy <db>   copy pattern-matching records from current to <db> database
 -d            disable exporting textual files after --add (enabled by default)
 --delete      delete pattern-matching records from current database
 -e            search for the exact term in the field (use with option -x)
 -E            extracompact output for wider notes (may trim fields)
 -f <file>     set <file> as current database file
 -F            framed output (may end in a long listing)
 --file        print current database path
 -G            group operas output (pat1 is searched among artists names)
 -h --help     print this help and exit
 -i            output only irregular pattern-matching records 
 -I            output only pattern-matching records with no issue date
 -J            output only pattern-matching records with the 'unknown' mark
 -k            disable the alternative search mechanism that extends search
 -l<c> [n]     list last [n] records from log file; lc for compact output
 -L            list the entire log file
 -m --modify   modify pattern-matching records in the current database
 --move <db>   move pattern-matching records from current to <db> database
 --multi <db>  add database <db> to current pattern-matching search; iterable;
 -n            prefix each line with database order-number (-N) or quantity (-o)
 -N            normal (plain) output (may give uneasy listing)
 -o<artyilpnc> output selected field only, unifying and sorting alphabetically
 -P            in aligned mode (-A), print the label field in place of notes
 -q            start modifying procedures over all records with 'unknown' marks
 -r            reverse sorting for both primary and secondary keys (see -s/-S)
 -R <y1-y2>    select pattern-matching records in the years between y1 and y2 
 -s<artyilpnc> sort output according to selected field as primary key
 -S<artyilpnc> sort output according to selected field as secondary key
 -t            export aligned (-A) and compact titles (-T) text databases
 -T            Titles output (compact) to enhance long titles
 -u --usage    print a fast usage help and exit
 -U            print output in upper case (may slower listing)
 -v --version  print version and exit
 -w --when     list pattern-matching records logging date
 -W            wide notes output (compact) to report complete notes
 -x<artyilpnc> limit matching to selected field (see option -e)
 -X            enable appending [alt-pos] / [box-set] (disabled by default)
 -y            print a note about my personal database input rules and exit
 -z            silent mode; perform search without printing out matching lines
 -Z <char>     use <char> as separator for current file instead of '|'

Remember: in general, double-dash options show cdd info or alter database, 
upper case options change output views, lower case options influence search.

Notes:
1. if no pattern is given cdd silently quits, unless an option operating
   on the entire database is required (-@, -b, -i, -I, -J, etc)
2. options -s, -S, -x and -o must be followed by a selector char for a field:
     	a    for the artist's name,
     	c    for the artist's country
     	r|t  for the record title,
     	y    for the original record's year,
     	i    for the CD issue year, if found onto the CD (type cdd -y for info),
     	l|p  for the label or publisher's name
     	n    for notes about the recordings (if you've got any);
   e.g.; -sy -S p -xa -o l; spaces don't count
3. the default selector for primary sort is the artist's name (a), the default 
   selector for secondary sort is the original record's year (y)
4. option -x has effect only on primary search, while secondary search (the one
   introduced by +|-) is a simple select/exclude engine
5. options --delete, --modify, --move, --copy, --when, --add don't use pat2
6. option -o (selected output) takes precedence over -A,-E,-F,-G,-N,-W and -T;
   since the report is a list of the content of one field only, sorting options
   -s and -S have no effect here: the report is always sorted alphabetically.
7. if set together in the user input command, the last among -A,-E,-F,-G,-N,-W 
   and -T is used as view
8. the country and label fields appear only within framed and plain modes; to 
   see these in -A aligned mode (in place of notes) option -P should be used 
   for label/publisher and option -B for country; -E, -G and -T modes don't 
   show the publisher or the country label in any case; -W mode prints author, 
   record and year on one line, and the whole packet of notes (if any)
9. option -G needs an artist name as pattern, because search is implicitely set
   to artist (-xa); secondary search (using +|- pat2) is also available
10.option -X enables adding information about alternate position or box-set
   records to the final report: if the record entry is an item of a box-set 
   (notes field begins with ~), the string "[box-set]" is appended to the 
   title; analogously, if the record entry is placed in an alternative position
   (notes field begins with @ or ~@), the string "[alt-pos]" is appended to 
   the title; see options -@ and -b. These data are managed by -add.
11.if set together in the user input command, the last among options that don't
   do any search in the database (double-dash options, -l, -L, -t, -w for 
   instance), is applied.
12.the alternative search mechanism, when the pattern is not a single word,
   splits it into single words and replicates the search over each word. To 
   disable this feature use option -k.

It's GPL! Enjoy!

THE SPECIAL MARKERS AND THE SYMBOLS OF THE DATABASE

To enhance cdd usage, I adopted a small number of conventions used during the
data input (through option --add).
The main conventions I use, to be put manually, are explained in the following:

   v.v.   means 'various years' - the record is typically a collection;
          it appears on the record year field, meaning that songs have been 
	  recorded in various, different (unspecified) years;

   ^^^^   the 'unknown' mark; it means 'unknown data'; it may appear in any 
          field (excluding 'Author', of course). It also serves as a memo 
	  placeholder for subsequent insertions;

Other symbols are inserted automatically by --add following your input:

   ----   means that no issue year has been found onto the cd; this symbol
          is put automatically by --add when you leave the 'CD date' field
	  empty, hitting Return on the empty 'CD date' input line.

    x     Usually, a CD may be issued in the same epoch of its recording, or be
          a rather recent reprint, maybe from an older CD or from a much older 
	  LP. In case of a reprint, if the track listing matches the original 
	  (with possibly some bonus tracks), nothing remarkable happens: the 
	  two dates (whatever they are) stand for themselves. 
	  If some change arises (some tracks left off because they don't fit 
	  into the CD, or the record is a re-recording or a bootleg version 
	  with a different listing or whatever), put any extra character 
	  after the issue year, e.g. 2007N; --add performs this operation 
	  automatically, inserting a lower 'x - e.g. 2007x - answering 'no' to 
	  the regular disc question. When cdd finds this extra character(s), 
	  an asterisk (*) is printed after the issue year, highlighting the 
	  'irregularity' of discs.
	  
    ~     at the start of the notes field indicates that the record is 
     	  contained into a boxed-set, with (possibly) other indipendent titles;
	  a multi-cd anthology doesn't use this symbol, but e.g. the Beatles 
	  mono collection (all mono complete cds in one box) sets this symbol 
	  for each title; this symbol is put automatically by --add answering 
	  'yes' to the box set question.

    @     at the start of the notes, but following the ~ symbol if present,
          indicates that the record is stored elsewhere (in an @lternative
          position), and not within the collection itself; this symbol is put 
	  automatically by --add answering 'yes' to the alternative position
	  question.
	  
You're free to use your own coding, of course.
This is only my point of view.

It's GPL! Enjoy!

