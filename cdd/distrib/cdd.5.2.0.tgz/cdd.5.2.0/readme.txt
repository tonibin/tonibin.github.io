cdd - compact disc database manager, version 5.2.0
Antonio Maschio, 2006-2012 <tbin at libero dot it>

Welcome in the cdd world!
cdd is a compact disc database manager for your musical cd collection.

Usage: cdd [OPTIONS] [pat1] [+|- pat2]

cdd reads all the content of a textual database (by default $HOME/.cdd/cd.db) 
and selects, for screen output, all lines matching pattern 'pat1' (which may 
contain spaces), formatting output in various friendly views. The matching is
by default extended to the whole record, but a single field may be chosen for
matching (see option -x).

[pat2] (which may contain spaces too) refines search, selecting only records 
containing [pat2] if + is used, or excluding those containing [pat2] if - is 
used instead. Blanks must be typed before and after the +|-.

If no match occurs, and if pattern may be split into two or more words, the
search is repeated over each word (to avoid extended search use option --keep).

Options are input in any order, provided arguments follow those needing them.
There is an internal order, in evaluating options that don't do any search  
(-@, -b, -l, -L, -t, -w, -h, -v for instance) so, if set together in the user 
input command, only a specific option is applied, not always the last in the
input line.

The first time cdd is invoked, its own working directory .cdd/ is created in
the user $HOME directory; this directory will contain the default database, 
all temporary files created by cdd and the file cdd_profile, which contains 
user preferences; customize it at pleasure after first run (cdd --help, for
instance...).

Options (<mandatory arguments>, [facultative arguments]):

 -@            select alternative position (pattern-matching or not) records
 -a --all      print all database entries, ignoring patterns
 --add [db]    add records to current or [db] database
 -b            select box-set (pattern-matching or not) records
 -B            in aligned mode (-A), print the country's field instead of notes
 -c --count    report total number of records in the current database
 --capitalized print output in capitalized words (may slower listing) 
 --copy <db>   copy pattern-matching records from current to <db> database
 --change <field> <oldpattern> <newpattern> change oldpattern-matching fields
 -C --verbose  print a complete report of the search results
 -d            disable exporting textual files after --add (enabled by default)
 --delete      delete pattern-matching records from current database
 -e            search for the exact term in the field (use with option -x)
 -f <file>     set <file> as current database file
 --file <file> set <file> as current database file
 -h --help     print this help and exit
 --heal [db]   start correction of 'unknown' marks in current or [db] database
 -i            select (pattern-matching or not) irregular records 
 --invert <f>  f=box|pos, invert flag on (pattern-matching or not) records
 -I            select (pattern-matching or not) records without issue date
 -J            select (pattern-matching or not) records with 'unknown' marks
 -k --keep     disable the alternative search mechanism and keep last search
 -l[c] [num]   list last [num] records from log file; lc for compact output
 --lower       print output in lower case (faster and default) 
 -L            list the entire current log file
 -m --modify   modify pattern-matching records in current database
 --move <db>   move pattern-matching records from current to <db> database
 --multi <db>  add database <db> to current pattern-matching search; iterable;
 -n            prefix each line with database order-number (-N) or quantity (-o)
 --no-color    disable color effects (useful for --text)
 --no-keep     enable the alternative search mechanism
 --no-verbose  disable printing a complete report of the search results 
 -o<artyilpnc> print selected field only, unifying and sorting alphabetically
 --path        print path of current database
 -P            in aligned mode (-A), print the label field in place of notes
 -q --quiet    quiet mode; print only the complete report (sets --verbose)
 -r --reverse  reverse sorting for both primary and secondary keys (see -s/-S)
 -R <y1>[-y2]  select pattern-matching records in the years between y1 and y2 
 -s<artyilpnc> sort output according to selected field as primary key
 -S<artyilpnc> sort output according to selected field as secondary key
 -t --text     export current database in -A and -T view modes to text files
 -u --usage    print a fast usage help and exit
 -U --upper    print output in upper case (may slower listing)
 -v --version  print version and exit
 -w --when     list pattern-matching records logging date
 -x<artyilpnc> limit matching to selected field (see option -e)
 -X            enable appending [alt-pos] / [box-set] (disabled by default)
 -y --notes    print my personal database input rules and exit
 -z <num>      set <num> as the width of notes for framed and wide views
 -Z <char>     set <char> as separator for current database instead of '|'

View options:

-A --aligned  aligned: main info in fixed-size columns (may trim fields)
-E --extra    extra: artist, title and extralarge-field notes (may trim fields)
-F --framed   framed: full output (may end in a long listing)
-G --group    group: artist's name header, all titles and years (-P add labels)
-N --normal   normal: full unaligned output (may give uneasy listing)
-O --open     open: aligned, full and 160 characters wide (may trim fields)
-T --titles   title: artist, year and large-field titles (may trim fields)
-W --wide     wide: artist, year, issue date, title and indented full notes

Notes:

1. if no pattern is given, cdd silently quits, unless -C/--verbose, or an 
   option implicitly operating on the entire database (-@, -b, -i, -I, -J) or 
   an informative option (-h, -v, etc) is used; should some name include a 
   peculiar character, suitable to special interpretation by the shell, use 
   the dot in its place; the output listing will contain the right character.

2. options -s, -S, -x and -o must be followed by a selector char for a field:
     	a    for the artist's name,
     	c    for the artist's country
     	r|t  for the record title,
     	y    for the original record's year,
     	i    for the CD issue year, if found (type cdd -y for info),
     	l|p  for the label or publisher's name
     	n    for notes about the recordings (if you've got any);
   option -Z must be followed by a word, whose first letter is set as the 
   new separator, and option -l must be followed by a number, which will be set
   as the number of printed log lines, preceded by character 'c' for compact
   output (the character 'c' must be tight to -l, i.e. -lc); if the number is
   absent or illegal (e.g. negative), the default 10 is used;
   e.g. -sy -S p -xa -o l -Z% -Z over, -l23, -lc 4; 
   spaces before argument don't count
   
3. single dash options may be cumulated, provided options needing an argument 
   are put in the last position of each group:
   e.g. -aFkSc -ATot -ABexa -UaZ% -Csi
   double dash options and their arguments, instead, must be divided by blanks:
   e.g. --multi my_cd --move pop --heal jazz

4. the default selector for primary sort is the artist's name (a), the default 
   selector for secondary sort is the original record's year (y);

5. option -x has effect only on the primary search, while secondary search 
   (the one introduced by +|-) is a simple select/exclude engine; beware that
   this option works with awk, which badly parse pat1 if it contains special 
   characters such as the open parenthesis; in this case don't use -x and try 
   to limit the search using + pat2;

6. option --when/-w doesn't use [pat2], and interprets everything that follows 
   as the pattern to search in the log file;

7. option -o (selected output) takes precedence over -A,-E,-F,-G,-N,-W,-O,-T;
   and since the report is a one-field-only list, sorting options -s and -S 
   have no effect here: the report is always sorted alphabetically, unless -n
   is used, by which the sorting is driven by the frequency number, which is
   printed before each output; option --reverse/-r is also meaningful here;

8. if set together in the user input command, the last among -A,-E,-F,-G,-N,-W,
   -O and -T is used as the chosen view;

9. the country and label fields appear only within -F, -N, -O view modes; to 
   see these in -A aligned mode (in place of notes) option -P should be used 
   for seeing the label/publisher and option -B for the country; -E, -G and -T 
   modes don't show the publisher or the country field in any case; -W mode 
   prints year, issue date in parentheses, author and title on one line, and 
   the whole notes, if any, in subsequent lines; option -G needs an artist name
   as pattern (the search is implicitly set to artist: -xa); secondary search 
   (using +|- pat2) is also available; option -GP adds labels in parentheses
   after the titles, as in aligned mode, someway.

10. option -X enables the printing of labels for alternative position or 
   box-set records: if the record entry is declared as part of a box-set, the 
   string "[box-set]" is appended to the title; analogously, if the record 
   entry is declared as placed in an alternative position than the main cd 
   collection, the string "[alt-pos]" is appended to the title; see options 
   -@, -b and --notes. These data are managed by --add and may be changed by 
   --modify and --invert;

11. option -R requires two years which define the range into which the search
   will be contained, including the limits; there must be no spaces before and
   after the dash, like in -R 1970-1974; if one year only is typed (like in 
   -R 1970) the search will be limited to that year; this feature is a simple
   select engine, which frees -x option for other scopes;

12. all options requiring a file name (--file, -f, --move, --copy, --add, 
   --multi, --heal), evaluate the given file name according to the following 
   rules: if it's an absolute reference, it's taken as it is; otherwise, it's 
   searched in cdd home directory (by default $HOME/.cdd/), adding the default 
   database extension (by default .db) if necessary; then it's searched in 
   the current directory, adding again the default extension, if necessary; 
   eventually, the name is taken as it is; for options dedicated to search (-f,
   (--file, --multi, --heal) the file name is then carefully tested: it must be 
   a not-empty regular file (i.e. not a directory nor a device), or you'll be 
   warned about; for options dedicated to manipulating records (--add, --copy,
   --move) the file must not be a directory, but can be an empty or unexisting
   file: it will be populated/created at need;

13. option --capitalized prints all words in the artist and title fields as
   capitalized, while, for efficiency reasons, the notes and the label fields
   remain in lower case; option --upper/-U, instead, prints every character 
   of the record in upper case, and option --lower, conversely, prints every
   character of the record in lower case (just the way it's stored).

14. to temporarily restore to default all features you changed in cdd_profile, 
   you can use: 
   --lower, --upper/-U, --capitalized to readdress the font case; 
   --keep/-k, --no-keep to readdress the alternative search mechanism; 
   --verbose/-C, --no-verbose to readdress verbosity;

15. you can use --no-color to disable coloring, or alternatively you can set to
   $WHITE or to a void string "" all color variables in cdd_profile, but if 
   you want to export your search to a textual file, you must use --no-color, 
   to avoid weird characters sets in the output file, e.g.:
   $ cdd --no-color <pattern> > search.txt

16. if you have a database with fields separated by a special character (not
   usual textual separators like the bar, the colon, the semicolon, such as \t,
   \v, \\), once you have ordered your fields according to cdd (see below), 
   you can consult your database with option -Z; for instance, if your 
   separator is the tab (\t):
   $ cdd -Z\\t -f <yourdb> <pattern>
   notice that, to pass the single \ character you have to type it twice;
   the order of fields in a record is: artist's name, cd title, original year, 
   cd issue year, notes, label, country (this order reflects cdd upgrading 
   through the years);

17. to ease searches, the special characters ^ and $ may be used in the pattern
   (in conjunction with option -x) meaning respectively 'starting with' and 
   'ending with'; e.g.:
   $ cdd -xt ^if
   searches all titles beginning with 'if';
   $ cdd -xa ng$
   searches all authors whose name ends with 'ng';
   obviously, if you use both, you are replicating the exact search, and cdd
   gets aware of this (try with the --verbose option, and see).

Advanced database editing and consulting facilities

Beware: 
- <these> are mandatory arguments, [these] are facultative arguments; 
- [options] is a dummy word to show where other options should be typed (in 
  particular where you can use -f/--file to change current database file); 
- the last typed among the following commands will be the one executed by cdd;

1. adding records:
   $ cdd [options] --add [file]
   this command will start the adding procedure; if [file] is given, additions 
   will be made to this file, otherwise they will be made to current database;
   please take note: --add doesn't use any pattern and interprets the first
   following argument as the target database name, ignoring other arguments.

2. deleting records:
   $ cdd [options] --delete [options] <pattern>
   this command will print in turn any record matching <pattern> in the current 
   database: hitting 'd' will delete it from current database, 'a' will delete 
   all matches, 'x' will quit, any other key will print next match.
   please take note: --delete does not parse [pat2], so that <pattern> is 
   everything following, and <pattern> must not be null.

3. moving records:
   $ cdd [options] --move <file> [options] [pattern]
   this command will print in turn any record matching [pattern] in the current 
   database: hitting 'm' will move the matching record to database <file>, 
   removing it from current database, 'a' will move all matches, 'x' will quit, 
   any other key will print next match; if [pattern] is null, this command 
   moves all records; please take note: --move does not parse [pat2].

4. copying records:
   $ cdd [options] --copy <file> [options] [pattern]
   this command will print in turn any record matching [pattern] in the current 
   database: hitting 'c' will copy the matching record from current database to 
   <file>, 'a' will copy all matches, 'x' will quit, any other key will print 
   next match; if [pattern] is null, this command copies all records; 
   please take note: --copy does not parse [pat2].

5. modifying records in all fields:
   $ cdd [options] --modify [options] <pattern>
   $ cdd [options] -m [options] <pattern>
   this command, in either form, will print in turn any record matching 
   <pattern> in the current database: hitting 'm' will start the modifying 
   procedure over the matching record, 'x' will quit, any other key will print 
   next match; the modifying procedure asks, for each field, the text to be 
   replaced (which is printed in brackets), under the following conventions:
   - the (new) typed text will substitute the original string, but
   - if typed text begins with '&', it will be added to the original string
   - if typed text ends with ':', it will be put before the original string
   - typing '-' (dash) will clear the original text
   - typing '^' (circumflex) will set original text as the 'unknown' mark ^^^^
   - typing '_' (underscore) as the new Title, will set it equal to Artist;
   please take note: --modify does not parse [pat2].

6. changing a record's field content:
   $ cdd [options] --change <field> "<oldpattern>" "<newpattern>"
   this command will print in turn any record matching <oldpattern> in the 
   current database, where <field> may be artist|a|name, country|c, 
   title|record|t|r, year|y, issue|i, notes|n, publisher|label|p|l (if pattern 
   should include spaces or other special characters, enclose them in double or
   single quotes, to ensure they will be interpreted correctly); hitting 'c' 
   will apply the substitution on all occurrences in the field, 'x' will quit, 
   'a' will apply the substitution on all occurrences for all matches, any 
   other key will print next match; the metacharacter '*' may be used into 
   <oldpattern> to match part of or the entire content of any field, e.g.:
   $ cdd --change year "*" "1980"
   will set any record year's field to 1980, whatever it is; the report count, 
   of course, won't include records whose year is already equal to 1980.
   please take note: --change does not use anything beyond <newpattern>.

7. healing records:
   $ cdd [options] --heal [file] [options]
   this command will start a special modifying procedure over each match 
   containing the symbol ^^^^ (the 'unknown' mark); if [file] is given, the 
   procedure will modify this file, otherwise it will modify the current 
   database; I use to place ^^^^, during the adding procedure, in fields for 
   which I don't have any datum, reserving to 'heal' all records in a single 
   pass at a later time, by invoking this option; the 'unknown' mark may be
   written in fields using ^ during a modifying procedure (see --modify/-m)
   please take note: --heal does not use any pattern.

8. inverting alternative position or box-set status flag:
   $ cdd [options] --invert <type> [options] [pattern]
   this command will print in turn any record matching [pattern] in the current 
   database; <type> must be 'pos' for the alternative position status and 'box' 
   for the box-set status; hitting 'i' will invert the correspondent status 
   flag, 'a' will invert all matches, 'x' will quit, any other key will print 
   next match; if [pattern] is null, inverts all <type> records status flag; 
   please take note: --invert does not parse [pat2].

9. widening the search range:
   $ cdd [options] --multi <file> [options] pattern>
   this command will add database <file> to the search for <pattern>; this 
   option is iterable, thus
   $ cdd [options] --multi <file1> --multi <file2> [options] <pattern>
   will search over current database plus <file1> plus <file2>, and so on;
   the original databases will not be affected by this command;
   please take note: the searching file created by cdd is a temporary file, 
   holding records of all specified added files plus the current database; this 
   means that there's no use in healing, deleting, changing fields or modifying 
   records in conjunction with the --multi option, because any change will be 
   applied to this temporary file and then lost; on the contrary, with the 
   --multi option, you can move or copy records to other databases, since 
   records are faithful copies from the original files.

Now stop reading and start using cdd!
It's GPL! Enjoy!

THE SPECIAL MARKERS AND THE SYMBOLS OF THE DATABASE

To enhance cdd usage, I adopted a small number of conventions to be used during 
data input (option --add). The main conventions I use are explained here:

   v.v.   means 'various years' - the record is typically a collection;
          it appears on the record year field, meaning that songs have been 
	  recorded in various, different (unspecified) years;

   ^^^^   the 'unknown' mark; it means 'unknown data'; it may appear in any 
          field (excluding 'Author', of course). It also serves as a memo 
	  placeholder for subsequent insertions (see option --heal)

Other symbols are inserted automatically by --add following your input:

   ----   means that no issue year has been found onto the cd; this symbol
          is put automatically by --add when you leave the 'CD date' field
	  empty, hitting Return on the empty 'CD date' input line.

    x     Usually, a CD may be issued in the same epoch of its recording, or be
          a rather recent reprint, maybe from an older CD or from a much older 
	  LP. In case of a reprint, if the track listing matches the original 
	  (with possibly some bonus tracks), nothing remarkable happens: the 
	  two dates (whatever they are) stand for themselves. 
	  If some change arises (some tracks left off because they don't fit 
	  into the CD, or the record is a re-recording or a bootleg version 
	  with a different listing or whatever), put any extra character 
	  after the issue year, e.g. 2007N; --add performs this operation 
	  automatically, inserting a lower 'x - e.g. 2007x - answering 'no' to 
	  the regular disc question. When cdd finds this extra character(s), 
	  an asterisk (*) is printed after the issue year, highlighting the 
	  'irregularity' of discs.
	  
    ~     the tilde at the start of the notes field indicates that the record 
    	  is contained into a boxed-set, with (possibly) other independent 
	  titles; for a multi-cd anthology don't use this symbol, but e.g. for 
	  the Beatles mono collection (all mono complete cds in one box) use 
	  this symbol for each title; this symbol is put automatically by --add
	   answering 'yes' to the box set question.

    @     the 'at' at the start of the notes (possibly following the ~ symbol)
          indicates that the record is stored elsewhere (in an @lternative
          position), and not within the collection itself; this symbol is put 
	  automatically by --add answering 'yes' to the alternative position
	  question.
	  
You're free to use your own coding, of course. This is only my point of view.
It's GPL! Enjoy!

