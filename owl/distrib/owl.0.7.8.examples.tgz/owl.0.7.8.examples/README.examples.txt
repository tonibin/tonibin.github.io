Read these examples carefully before executing them: 
you will learn a lot about owl.

And don't forget to send your own owl sources!

-------------------------------
Antonio <tbin at libero dot it>
