To execute these tests (whose name begins with "lang test"), launch:

  $ owl [options] testfile

where option may be -i or -r (they won't influence the unrelated testing).

Some tests are autoexplicative, other must be confronted to source. 
To confront source with output, follow these steps; digit:

  $ owl testfile > testfile.out

and then do:

  $ cat testfile testfile.out

and see the results on the terminal screen.

Enjoy.
