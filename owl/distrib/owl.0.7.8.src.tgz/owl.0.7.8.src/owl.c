/* owl.c
 * Copyright 2005-2013 Antonio Maschio <tbin at libero dot it>
 *
 * owl - obfuscated weird language
 * 
 * (source code optimized for 80 columns with 8 chars tab stops)
 * (source code edited and maintained with gvim)
 *
 * termios statement:
 * termios features for command '(' are taken from file term2.c 
 * under the following copyright:
 * Copyright (C) 2000 Kyle R. Burton, All Rights Reserved
 * mortis@voicenet.com
 * http://www.voicenet.com/~mortis
 * 
 * owl statement:
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * It's GPL! Enjoy! */
// TODO. inserire un messaggio di Memory error per segmentation e il resto
// come in tbas, intercettando SIGSEGV e il resto
#include "owl.h"

/* ***************************
 *        FUNCTIONS         *
 ****************************/

/* printHelp()
 * execute -h/--help options. */
void printHelp(void) {
	fprintf(stdout, "\nWelcome to the programming world of the Obfuscated Weird Language!\n\n");
	fprintf(stdout, "Usage: owl <options> <filename> <commands>\n\n");
	fprintf(stdout, "Options are:\n");

#ifdef LEAVESEXE
	fprintf(stdout, "  -c               compile source an leave an executable\n");
#endif
	
	fprintf(stdout, "      --conditions print redistribution conditions from GPL3\n");

#ifdef OWL_DEBUG
	fprintf(stdout, "  -d               execute program in debug mode\n");
	fprintf(stdout, "  -D               if in debug mode, print var contents\n");
#endif

	fprintf(stdout, "  -e               toggle PAD's erasure before string initialization\n");

#ifdef OWL_DEBUG
	fprintf(stdout, "  -F               if in debug mode, print functions buffers contents\n");
#endif

	fprintf(stdout, "  -h, --help       display this information\n");
	fprintf(stdout, "  -i               toggle integer division mode (default: standard)\n");
	fprintf(stdout, "  -p \'<string>\'    Parse <string> enclosed in quotes and exit\n");
	fprintf(stdout, "  -r               toggle rounding mode (default: cut)\n");

#ifdef LEAVESASM
	fprintf(stdout, "  -s               compile source and leave an assembly file\n");
#endif

#ifndef OWL_REMOVE
	fprintf(stdout, "  -S               if in debug mode, enable single-step running\n");
	fprintf(stdout, "  -t               print a timer report after execution\n");
#endif

	fprintf(stdout, "  -v, --version    display version, license and warranty\n");
	fprintf(stdout, "      --warranty   print warranty conditions from GPL3\n\n");
	fprintf(stdout, "<filename> is a source text file containing owl code lines to  be  executed.\nUsually,  such  sources  have extension \".owl\",  but this can be omitted in\n<filename>.\n\nOption  -p <string>  is used to execute  portions of code  (contained  into\n<string>)  without a file to process.  If no filename is given or option -p\nis not used, owl will complain.\n\nCode contained  into the facultative  <commands>  will be  executed  before\nprogram   start  (unless option -p is used,  in which  case  <commands> are\nappended to <string>).\n\nIn <commands> and <string> all characters that have a  special  meaning for\nthe  shell  you use  should  be escaped, and double/single quotes should be\nused.\n\n");
	fprintf(stdout, "For language features, read the file 'owl_manual.txt' within the package or\n"); 
	fprintf(stdout, "type 'man owl' for a quick reference.\n"); 
	fprintf(stdout, "\nFor bug reporting, please write to <tbin at libero dot it>.\n\n"); 
}


/* printVersion()
 * execute -v/--version options. */
void printVersion(int flag) {
	fprintf(stdout, "\nowl (obfuscated weird language) interpreter\n");
	fprintf(stdout, "version %d.%d.%d (built %s, %s)\n", MAJOR, MINOR, RELEASE, __DATE__, __TIME__);
	fprintf(stdout, "Copyleft (C) %s %s <%s>.\n", CY, AU, EM);
#ifdef OWL_REMOVE
	fprintf(stdout, "Version compiled without termios features.\n");
#endif
#ifndef OWL_DEBUG
	fprintf(stdout, "Version compiled without debug features.\n");
#endif
	if (flag)fprintf(stdout, "This free program comes with  ABSOLUTELY NO WARRANTY;  type 'owl --warranty'\nfor details. You may redistribute the program under certain conditions;type\n'owl --conditions' for details.\n");
	fprintf(stdout, "\nSoftware released  under the terms of  GNU General Public License version 3.\n");
	fprintf(stdout, "\n");
}


/* printWarranty()
 * execute --warranty option (required by GPL3). */
void printWarranty(int flag) {
	if (flag) printVersion(0);
	fprintf(stdout, "THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE\nLAW.  EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS  AND/OR\nOTHER  PARTIES  PROVIDE THE PROGRAM  \"AS IS\"  WITHOUT  WARRANTY OF ANY KIND,\nEITHER  EXPRESSED OR IMPLIED,  INCLUDING,  BUT NOT LIMITED TO,  THE IMPLIED\nWARRANTIES OF  MERCHANTABILITY AND  FITNESS FOR A  PARTICULAR PURPOSE.  THE\nENTIRE  RISK AS TO THE  QUALITY AND  PERFORMANCE OF THE PROGRAM IS WITH YOU.\nSHOULD THE  PROGRAM PROVE DEFECTIVE,  YOU ASSUME THE  COST OF ALL NECESSARY\nSERVICING, REPAIR OR CORRECTION.\n\n");
}


/* printConditions()
 * execute --conditions option (required by GPL3). */
void printConditions(int flag) {
	if (flag) printVersion(0);
	fprintf(stdout, "You may make,  run and  propagate  covered  works  that you  do not  convey,\nwithout conditions so long as your license otherwise remains in force.  You\nmay convey covered works to others for the sole purpose of having them make\nmodifications  exclusively  for  you,  or  provide  you with facilities for\nrunning those works, provided that you comply with terms of this License in\nconveying  all material for which you do not control copyright.  Those thus\nmaking or running the  covered works for you must do so exclusively on your\nbehalf,  under your direction and control, on terms that prohibit them from\nmaking any copies  of your copyrighted material  outside their relationship\nwith you.\n\n");
}


/* erase_buffer()
 * erase buffer up to LIMIT.
 * WARNING: only to be used for owl char buffers (sized with 'LIMIT'). */
void erase_buffer(char *buffer) {
	int i;
	for (i = 0; i < LIMIT; i++) *buffer++ = '\0';
}


/* pop()
 * pop TOS 
 * return integer or error if TOS is void */
long long int pop(void) {
	if (TOS <= 0) {
		fprintf(stderr,UNDERFLOWERROR);
		quit();
	}
	else return Stack[TOS--];
}


/* push()
 * push integer 'n' to TOS 
 * return error if stack is full */
void push(long long int n) {
	if (TOS > (STACKLIMIT - 1)) {
		fprintf(stderr, OVERFLOWERROR);
		quit();
	}
	else Stack[++TOS] = n;
}


/* getVar()
 * subroutine for variables management: if a letter, identifying all kind
 * of variables, is followed by a special operator, then execute appropriate 
 * function, otherwise push back letter's ASCII value; 
 * some parts of the dynamic binding commands are managed here, 
 * as well as some underscore _commands; 
 * 'input' is the current input stream at the evaluable position
 * return updated position in the input stream, used into parse(). 
 * Note: the return value does not change here in case no function is used,
 * because 'input' is advanced into parse() */
char* getVar(char *input) {
	int vtype = *input;     // var type: a-z:functions, A-Z:numbers 
	int done  = 0;		// offset from current input stream position 

	switch(*(input + 1)) {
		case '_':
			/* a_, dynamic binding - store PAD to function 
			 *     as function; this is the first half of _, */
			if ((',' == *(input + 2)) && islow(vtype)) {
				strncpy((VarFBuffer[vtype-'a']), PAD, LIMIT);
				done = 2;
			}
			/* a_' dynamic binding - store PAD to function 
			 *     as string; this is the first half of _' 
			 *     here we must escape inner double quotes */
			else if (('\'' == *(input + 2)) && islow(vtype)) {
				char *l, *p=PAD;
				l=VarFBuffer[vtype-'a'];
				*l++='\"';	
				while (*p) {
					if (*p=='\"') *l++='\\';
					*l++=*p++;
				}
				*l++='\"';
				*l='\0';
				done = 2;
			}
			/* a_~ substring search 
			 *     this is the first half of _~ */
			else if (('~' == *(input + 2)) && islow(vtype)) {
				char *r;
				r=strstr(PAD,VarFBuffer[vtype-'a']);
				push((long long int)(r-PAD));
				done=2;
			}
			/* a_ or A_
			 *    push ASCII value of character before underscore; 
			 *    in next iteration, the underscore will be 
			 *    treated into parse() */
			else push(vtype);
			break;
		case ',':
			/* ,, dynamic binding - copies var into PAD 
			 *    this is the first half of ,, */
			if ((',' == *(input + 2)) && islow(vtype)) {
				strncpy(PAD, VarFBuffer[vtype - 'a'], LIMIT);
				done = 2;
			}
			/* A, store number */
			else if (iscap(vtype)) {
				VarIBuffer[vtype - 'A'] = pop();
				UsedVars[vtype]=TRUE;
				done = 1;
			}
			/* a, store function */
			else if (islow(vtype)) {
				strncpy((VarFBuffer[vtype - 'a']),\
						FuncBuffer, LIMIT);
				erase_buffer(FuncBuffer);
				erase_buffer(BackFuncBuffer);
				UsedVars[vtype]=TRUE;
				done = 1;
			}
			break;	
		case '@':
			/* a@, dynamic binding - store function index 
			 *     This is the first half @, */
			if ((',' == *(input + 2)) && islow(vtype)) {
				fIndex = vtype;
				done = 2;
			}
			/* A@ fetch number */
			else if (iscap(vtype)) {
				push(VarIBuffer[vtype - 'A']);
				done = 1;
			}
			/* a@ execute function */
			else if (islow(vtype)) {
				parse(VarFBuffer[vtype - 'a']);
				done = 1;
			}
			break;
		case 'a'...'z':
			/* ab_= compare string functions 
			 *    this is the first half of _= */
			if (*(input+2)=='_' && *(input+3)=='='&&islow(vtype)){
				push(strcmp(VarFBuffer[(int)*(input)-'a'],\
					VarFBuffer[(int)*(input+1)-'a']));
				done=3;
			}
			/* if it's not a compare, or if any variable is 
			 *    uppercase, push ASCII value */
			else push(vtype);
			break;
		/* a or A  push ASCII value */
		default:
			push(vtype);
			break;
	}
	return (input + done);
}
/* end getVar */


/* ensureCloseFile() 
 * ensure that read-file and write-file are closed; 
 * Note: this routine is called before exiting by quit() and main */
void ensureCloseFile(void) {
	/* for read-files streams discard any input not yet read; 
	 * this includes any text pushed back via _U, then force closing */
	if (chR) { 
		__fpurge(chR); 
		fclose(chR); 
	}
	/* force a write of all buffered data for the given output or update 
	 * stream on the write-file stream, then force closing */
	if (chW) { 
		fflush(chW); 
		fclose(chW); 
	}
}


/* quit()
 * quit program, in case of abnormal termination, emitting TOS or EXIT_FAILURE 
 * as error/status code; value on TOS may be a user code. */
void quit(void) {
	fprintf(stdout, "\n");
	ensureCloseFile();
	if (TOS) exit(pop());
	else exit(EXIT_FAILURE);
}


/* fprintb() - used with base=BIN
 * print an integer in binary format according to the following format:
 *   - bit 0 appears on the right (e.g. 13 => B1101);
 *   - negative numbers occupy all 64 bits;
 * 'file' is the output stream;
 * 'n' is the long long integer to be converted. */
void fprintb(FILE *file, long long int n) {
	int num[BITS], c = -1;
	if (!n) fprintf(file, "0");
	while (n && (c < (BITS - 1))) num[++c] = n & 1, n >>= 1;
	while (c >= 0) fprintf(file, "%d", num[c--]);
}


/* fprintany() - use with any base different from DEC,BIN,OCT,HEX
 * print an integer in 'nbase' format
 * 'file' is the output stream;
 * 'n' is the long long integer to be converted in base 'nbase'. 
 * Note: I use divide() here because it also treats special cases */
void fprintany(FILE*file, long long int n, int nbase) {
	long long int i=0;
	int num[BITS], c = -1, IDIV=isNTDiv, sign=1;
	/* store integer division flag and setup sign, 
	 * the division with 'cut' is needed here */
	isNTDiv=FALSE;
	if (n<0) n=-n, sign=-1; 
	/* divide */
	i=divide(n,nbase);
	while (i && (c < (BITS - 1))) 
		num[++c]=n-nbase*i, n=i, i=divide(n,nbase); 
	num[++c]=n;
	fprintf(file, "!");		// ! peculiar base identification
	if (sign<0) fprintf(file, "-");	// - the minus sign
	while (c >= 0) fprintf(file, "%c", digits[num[c--]]);
	isNTDiv=IDIV;
}


/* printNumber()
 * wizard to select correct destination for printing a number to current 
 * channel, according to base format 
 * 'file' is current channel
 * 'n' is the number to be printed */
void printNumber(FILE*file, long long int n) {
	switch (base) {
		case DEC:
			fprintf(file, "%lld", n);
			break;
		case BIN:
			if (isPrependAmp) fputc('B',file);
			fprintb(file, n);
			break;
		case OCT:
			if (isPrependAmp) fputc('O',file);
			fprintf(file, "%llo", n);
			break;
		/* I prefer capital letters in hex */
		case HEX:
			if (isPrependAmp) fputc('&',file);
			fprintf(file,"%llX",n);
			break;
		default:
			fprintany(file, n, base);
	}
	fflush(file);
}


/* isDigit()
 * check if ASCII character 'd' belongs to the digits range of the specific 
 * numbering base 'nbase'; 
 * return TRUE if yes, FALSE otherwise */
int isDigit(char d, int nbase) {
	int i;
	/* short-circuit for known values */
	if (d==32) return FALSE;
	if (d=='\n') return FALSE;

	/* convert lower letters to upper */
	if (d >= 'a' && d <= 'z') d-='a'-'A'; 

	/* search d in digits */
	for (i=0; i<nbase; i++) if (d==digits[i]) return TRUE;
	return FALSE;
}


/* convertNumber()
 * convert a number in string, starting from position start; check if special 
 * characters & (hexadecimal), ! (peculiar base) and - (negative picture), O 
 * (octal) and B (binary) are present, and take appropriate decisions
 * 'num' will yield the converted number up to the first not suitable digit
 * 'string' is the passed string to be converted
 * 'start' is where to start conversion (if negative is converted to positive)
 * return the position of first not suitable digit in string or zero in 
 * case string is over or no number was converted */
long long int convertNumber(char* string, long long int start, long long int *num) {
	char line[BITS], *l=line, *s;
	int sign=1, thisBase=base;
	s=(string+(start >= 0 ? start : -start));

	/* skip blanks */ 
	while (*s == ' ' || *s == '\t') s++;
	if (!*s || *s=='\n') return 0;

	/* discard possible garbage characters interposed and check for
	 * starting prefixes !&BO and the minus sign */
	while (*s && !isDigit(*s,thisBase)) {
		if (*s=='!') s++;
		else if (*s=='&' && *(s+1)=='-' && isDigit(*(s+2),HEX)) 
			thisBase=HEX, sign=-1, s++, s++;
		else if (*s=='&' && isDigit(*(s+1), HEX)) thisBase=HEX, s++;
		else if (*s=='-' && *(s+1)=='&' && isDigit(*(s+2), HEX)) 
			thisBase=HEX, sign=-1, s++;
		else if (*s=='B' && isDigit(*(s+1), BIN)) thisBase=BIN, s++;
		else if (*s=='O' && isDigit(*(s+1), OCT)) thisBase=OCT, s++;
		else if (*s=='-' && !isDigit(*(s+1), thisBase)) s++;
		else if (*s=='-') sign=-1, s++;
		else s++;
	}
	
	/* grab digits and put to string*/
	while (*s && isDigit(*s,thisBase)) *l++=*s++;
	*l='\0';
	/* convert string to number */
	switch (thisBase) {
		case BIN:
		case OCT:
		case HEX:
			*num=sign*toNUM(line, thisBase);
			break;
		default:
			*num=sign*strtoll(line, NULL, thisBase);
			break;
	}

	if(!strlen(line)) return 0LL; // no number to convert
	else return (long long int)(s-string);
}


/* toVAL()
 * convert an ASCII digit 'digit' to its proper value in base 'base' */
long long int toVAL(char digit, int base) {
	int i=0;
	while (i<base) { if (digits[i]==digit) return i; i++; }
	return 0L;
}


/* toNUM() - to be used only for bases 2/8/16
 * wizard for strtoll to convert a string 'string' into number, in base 'base',
 * taking care of special cases for a better functioning of strtoll();
 * return converted number */
long long int toNUM(char* string, int base) {
	int len, sign=1, bit=0;
	long long int num=0LL;

	/* setup for special bases */
	if (base==2) len=64;
	else if (base==8) len=22;
	else if (base==16) len=16, bit=7;

	/* if number is full length, and first letter has first bit set
	 * the number is negative; 
	 * Note: the number 9223372036854775808LL is illegal, so I decrease
	 * it by 1, adding 1 afterwards */
	if (strlen(string)>=len && (toVAL(*string, base)&1)) {
		sign=-1;
		*string=digits[toVAL(*string, base)&bit];
		num=sign*(9223372036854775807LL-(strtoll(string,NULL,base))+1);
	}
	/* positive regular number */
	else num=strtoll(string,NULL,base);
	return num;
}


/* fileopen()
 * open a file for input, trying adding extension .owl if not found;
 * 'original' is the given file name;
 * return file descriptor of opened file, or NULL if neither is found.*/ 
FILE* fileopen(char* original) {
	char fname[LIMIT], *fn=fname;
	FILE * ff = fopen(original, "r");

	if (!ff) {
		strncpy(fname,original,LIMIT-1);
		fn+=strlen(fname)-1;
		while (strlen(fname) > LIMIT-5) *fn--='\0';
		strcat(fname, ".owl");
		ff=fopen(fname, "r");
		if (!ff) return NULL;
	}
	return ff;
}


/* include_file()
 * load and execute an entire file, retrieving its name from input stream
 * enclosed by '_][' or '_[]'; the file is read and executed as a standalone 
 * program, with current stack and current variables;
 * the starting characters _[ or _] are detected into parse(), so they don't 
 * appear here; the memory management as well (module or inclusion) is treated
 * into parse();
 * 'input' is the current input stream at the evaluable position.
 * return file name length, used by parse() to update the input line position, 
 * or exit with EXIT_FAILURE if file is not found; that's why the closing 
 * characters ] or [ are discarded in parse(), and not here. */
int include_file(char *input) {
	char bufn[LIMIT], *b = bufn; 
	int ret = 0;
	FILE *f;	

	while (*(input) != '[' && *(input)!= ']') *b++ = *input++;
	*b = '\0';

	if (bufn[0]) {
		f = fileopen(bufn);
		if (!f) {
			fprintf(stderr, OPENFILEERROR, bufn);
			exit(EXIT_FAILURE);
		}
		else {
			ret = strlen(bufn);
			/* here bufn is reused for fgets */
			while (fgets(bufn, LIMIT, f) && !parse(bufn));
			fclose(f);
		}
	}
	return ret;
}


/* cat() 
 * at the change of a restore _R from start to end, or close _C,  or erase _E, 
 * copy content of original file onto the temporary file (which holds lines 
 * written so far) and close both, remove original file, and rename temporary
 * file (which now holds the entire buffer) to old name; 
 * return TRUE on success, FALSE if any passage fails */
int cat(void) {
	char buffer[4096];
	size_t bytesRead;
	memset(buffer, 0, sizeof(buffer));
	
	/* open original file for reading */
	chT=fopen(WriteFileName, "r");
	if (!chT) return FALSE;

	/* copy onto temporary file */
	while(!feof(chT)) {
		bytesRead = fread(&buffer, 1, sizeof(buffer), chT);
		fwrite(&buffer, 1, bytesRead, chW);
	}

	/* close files and perform exchange */
	fflush(chW);
	fflush(chT);
	if (fclose(chW)) return FALSE;
	if (fclose(chT)) return FALSE;
	if (remove(WriteFileName)) return FALSE;
	if (rename(TempFileName, WriteFileName)) return FALSE;
	isRestoreStart=FALSE;
	return TRUE;
}


/* printvars()
 * print already used or not null variables in the debug function. */ 
void printvars(void) {
	int i;
	int c=0;
	long long int s=0LL;
	/* is there any used or not null numeric variable? */
	for(i=0; i<MAXVARS; i++) s+=VarIBuffer[i]+UsedVars['A'+i];
	/* if so, print each with name and numeric content */
	fprintf(stdout, "\nVars : ");
	if (s) {
		for(i=0; i<MAXVARS; i++) {
			if(VarIBuffer[i] || UsedVars['A'+i]) {
  				c++;
				if (c!=1) fprintf(stdout, ", ");
				fprintf(stdout,"%c=%lld",'A'+i,VarIBuffer[i]);
			}
		}
	}
	s=0LL;
	/* is there any used or not null string/function variable? */
	for(i=0; i<MAXVARS; i++) s += VarFBuffer[i][0] + UsedVars['a'+i];
	/* if so, print each with name and string content */
	if (s) {
		for(i=0; i<MAXVARS; i++) {
			if(VarFBuffer[i][0] || UsedVars['a'+i]) {
				c++;
			  	if (c!=1) fprintf(stdout, ", ");
				fprintf(stdout,"%c=[%s]",'a'+i,VarFBuffer[i]);
			}
		}
	}
}


/* printbuffers()
 * print function buffers in the debug function. */ 
void printbuffers(void) {
	fprintf(stdout, "\nBuf#F: [%s]\n",FuncBuffer);
	fprintf(stdout, "Buf#B: [%s]",BackFuncBuffer);
}


/* divide()
 * calculate division according either to the classic mode or to the Number 
 * Theory mode, from long long int arguments to long long int result. 
 * 'dividend' is the number to divide
 * 'divisor' is the divisor
 * return result of division */
long long int divide(long long int dividend, long long int divisor) {
	long long int res;	  // temporary integer result
	short k;		  // k: add/subtract 1 to res (NT mode)
	long double resd;	  // double result to be rounded 
	/* predetermined results for special cases 
	 * the dividend is returned in case of null divisor */
	if (!divisor) return dividend;
	/* calculate division: */
	resd = (long double)dividend/(long double)divisor;
	res = (long long int)resd;
	k = dividend - divisor * res != 0 ? 1 : 0;
	/* integer division according to Number Theory */
	if (isNTDiv) return (dividend<0)?((res<=0)?res-k:res+k):_round(resd);
	/* classic integer division according to _round */
	else return _round(resd);
}


/* nroot()
 * calculate nth root with an iterative algorithm from a long long int input
 * parameter to a long long int result; 
 * see: http://gmplib.org/manual/Nth-Root-Algorithm.html
 * result is the greatest integer whose nth power is not larger than base. 
 * 'base' is number to root
 * 'root' is the root index
 * return the calculated root */
long long int nroot(long long int base, long long int root) {
	long double a=0.0L, a1=1.0L;
	long double dbase, droot;
	short sign=1;
	/* predetermined results for special cases: 
	 * 0 is a safe result for impossible roots; 
	 * see J.W. Crenshaw, "Math tool-kit for Real Time Programming", 
	 * CMP books, 2000, page 62, listing 4.3 (for square root) */
	if (root == 1LL) return base;
	else if (root < 0LL) return 0LL; // always zero in integer
	else if (base < 0LL && !(root % 2LL)) return 0LL; // impossible root
	
	/* calculate nth positive root of a positive base (sign retained) */
	if (base < 0LL) sign = -1, base = -base;
	dbase=(long double)base, droot=(long double)root;
	while (fabsl(a-a1) > EPSILON) {
		a=a1;
		a1=(dbase/powl(a,droot-1.0L)+(droot-1.0L)*a)/droot;
	}
	/* note: we don't round here, since a rounding toward the nearer 
	 * integer for decimals >= 0.5 would return a square larger than 
	 * original base 
	 * e.g. 981 3: is 9.9363, 10 rounded, whose cube is 1000 > 981 */ 
	return (long long int)(a1*sign);
}

 
/* power()
 * calculate power from long long int parameters to long long int result. 
 * 'base' is the base number
 * 'exp' is the exponent
 * return the calculated power */
long long int power(long long int base, long long int exp) {
	long long int res = 1LL;
	/* predetermined results for special cases */
	if (exp == 0LL) return res;
	else if (exp == -1LL) return _round(1.0/base);
	else if (exp == 1LL || base == 1LL) return base;
	/* calculate nth power */
	else if (exp > 0LL) while (exp--) res*=base;
	else return 0LL;
	return res;
}


/* calcASCIIoffset()
 * compute, from a long long integer 'n' the right offset to a precise 
 * ASCII code, to obtain 97=a, 98=b, ..., 122=z, cycling around to be 
 * reconducted to this 26 characters range (96=z, 123=a and so on). 
 * return the calculated offset as ASCII char 
 * Note: this is used for variables, as to obtain a precise variable code
 * from ANY number */ 
char calcASCIIoffset(long long int n) {
	long long int op1=n;
	op1 = (op1 - 97) % 26 + 97;
	while (op1 < 97) op1 += 26;
	return (char) op1;
}

#ifdef OWL_DEBUG

/* debug()
 * The DEBUGGER; for each command execution print instruction in execution,
 * stack content enclosed into square brackets, PAD and (if required) the
 * list of already used or not null variables and function buffers content; 
 * debug masks are independent on the program output. 
 * 'input' is current input character before its parsing */
void debug(char *input) {
	int u, le=0;
	char c = *input, c1 = *(input+1), c2=*(input+2), c3=*(input+3);
	char tos[10]="<--TOS";
	/* debug: skip control characters and sharp comments */
	if (!c || (c > ' ' && (c!='#' || (c=='#' && c1==',') || (c=='#' && c1=='@')))) {
#ifndef OWL_REMOVE
		/* debug: single step execution in debug mode */
		if (singleStep) {
			// thanks to Kyle R. Burton for this routine. 
			// See initial GPL banner for his credits
			struct termios modes, savemodes;
			int opg;
			tcgetattr(0, &modes);
			savemodes = modes;
			modes.c_lflag &= ~ICANON;
			modes.c_lflag &= ~ECHO;
			tcsetattr(0, 0, &modes);
			opg = fgetc(stdin);
			if (opg == 'S' || opg == 's') 
				singleStep=FALSE, overRideStep=FALSE;
			else if (opg == 'G' || opg == 'g') 
				overRideStep=TRUE;
			else overRideStep=FALSE;
			tcsetattr(0, 0, &savemodes);
		}
#endif
		/* debug: CRs for schemes separation */
		fprintf(stdout, "\n\n");
		/* debug: complete any I/O procedure */
		if (isFileComplete==1) {
			if (Stack[TOS]) 
				fprintf(stdout, "I/O  : (file opened)\n");
			else fprintf(stdout, "I/O  : (failed opening)\n");
			isFileComplete=0;
		}
		else if (isFileComplete==2) {
			if (Stack[TOS]) 
				fprintf(stdout, "I/O  : (file closed)\n");
			else fprintf(stdout, "I/O  : (failed closing)\n");
			isFileComplete=0;
		}
		else if (isFileComplete==3) {
			if (Stack[TOS]) {
				fprintf(stdout, "I/O  : (restore file write-point ");
				if (isRestoreStart) fprintf(stdout," - insert)\n");
				else fprintf(stdout," - append)\n");
			}
			else fprintf(stdout, "I/O  : (failed restoring write-point)\n");
			isFileComplete=0;
		}
		else if (isFileComplete==4) {
			if (Stack[TOS]) 
				fprintf(stdout, "I/O  : (file erased)\n");
			else fprintf(stdout, "I/O  : (failed erasing)\n");
			isFileComplete=0;
		}
		else if (isFileComplete==5) {
			if (Stack[TOS]) {
				fprintf(stdout, "I/O  : (set file seek ");
				if (isSeekStart) fprintf(stdout," - start)\n");
				else fprintf(stdout," - end)\n");
			}
			else fprintf(stdout, "I/O  : (failed setting seek)\n");
			isFileComplete=0;
		}

		/* debug: complete any I/O inclusion procedure */
		if (isDebugInclude==1) {
			fprintf(stdout, "I/O  : (inclusion completed)\n");
			isDebugInclude=0;
		}
		else if (isDebugInclude==2) {
			fprintf(stdout, "I/O  : (module discarded)\n");
			isDebugInclude=0;
		}
		/* debug: print stack content */
		fprintf(stdout, "Stack: [ ");
		for (u = 1; u <= TOS; u++) 
			fprintf(stdout, "%lld ", Stack[u]);
		if (TOS < 2) *tos='\0';
		fprintf(stdout, "]%s #%d\n",tos,TOS);
		/* debug: print PAD content */
		fprintf(stdout, "Pad  : |");
		le=strlen(PAD);
		if (*PAD) {
		   	if (le >= 60) {
			   	int i=0;
				for (i=0; i<57; i++) {
					if (PAD[i]==10 || PAD[i]==13) 
						fprintf(stdout, "\\n");
					else fprintf(stdout, "%c",PAD[i]);
				}
				fprintf(stdout, "..."); // ellipsis
		   	}
		   	else {
				int i=0;
				for (i=0; i<le; i++) {
					if (PAD[i]==10 || PAD[i]==13) 
						fprintf(stdout, "\\n");
					else fprintf(stdout, "%c",PAD[i]);
		   		}
			} 
		}
		fprintf(stdout, "| #%d",le); // end print PAD content
		/* debug: print variables and/or function buffers if required */
		if (printVars) printvars();
		if (printFBuf) printbuffers();
		/* debug: print current command to be executed */
		fprintf(stdout, "\nNext : %c",c);
		/* intercept !xNNN for numbers in bases 2÷36 */
		if (ispecprefix(input)) {
			char *p=input+1;
			fputc(*p++,stdout);
			while (isDigit(*p, base)) fputc(*p++,stdout);
		}
		else switch (c) {
			/* debug: format numbers */
			case '0'...'9':
			case 'B':
			case 'O':
				/* numbers in bases 2/8/10/16 */
				if ((c1 != ',' && c1 != '@')) {	
					char *p=input+1;
					/* hex number */
					if (ishexprefix(p-1)) {
						fputc(*p++,stdout);
						while (isDigit(*p, HEX)) 
							fputc(*p++,stdout);
					}
					/* binary number  */
					else if (c=='B' && isDigit(*p, BIN)) {
						while (isDigit(*p, BIN))
							fputc(*p++,stdout);
					}
					/* literal B */
					else if (c=='B')
						fprintf(stdout, " (literal)");
					/* octal number  */
					else if (c=='O' && isDigit(*p, OCT)) {
						while (isDigit(*p, OCT))
							fputc(*p++,stdout);
					}
					/* literal O */
					else if (c=='O')
						fprintf(stdout, " (literal)");
					else if (isDigit(c, DEC)){
						p=input+1;
						while (isDigit(*p,DEC)) {
							fputc(*p++,stdout);
						}
					}
				}
				/* it's a storing fetching over B,O */
				else if (!isDigit(c,base)) 
					fprintf(stdout, "%c", c1);
				break;
			/* debug: >> right shift */
			case '>':
				if (c1 == c) 
					fprintf(stdout, ">  (right shift)");
				break;
			/* debug: << left shift */
			case '<':
				if (c1 == c) 
					fprintf(stdout, "<  (left shift)");
				break;
			case '@':
				/* debug: @@ */
				if (c1 == c) 
					fprintf(stdout, "@  (executing index function %c)",fIndex);
				/* debug: @, 
				 * index command in the form @, */
				else if (c1 == ',') 
					fprintf(stdout, ",  (storing function %c at index)",calcASCIIoffset(Stack[TOS]));
				break;
			/* debug: ] command to get next char ascii and push */
			case ']':
				fprintf(stdout, "  (push next char '%c')",c1);
				break;	
			/* debug: format ,, command */
			case ',': 
				if (c1 == ',')
				       fprintf(stdout, ",  (copy function %c into PAD)",calcASCIIoffset(Stack[TOS]));
				break;
			/* debug: format #, or #@ commands */
			case '#': // comment # is skipped into parse()
				if (c1 == ',')
				       fprintf(stdout, ",  (array: storing value)");
				else if (c1 == '@')
			 		fprintf(stdout, "@  (array: fetching value)");
				break;
			/* debug: underscore commands or _commands */
			case '_': {
				/* _, command */
			        if (c1== ',')
					fprintf(stdout, ", (put PAD into var %c as function)",calcASCIIoffset(Stack[TOS]));
				/* _' command */
				else if (c1 == '\'')
					fprintf(stdout, "' (put PAD into var %c as string)",calcASCIIoffset(Stack[TOS]));
				/* inclusion */ 
				else if (c1 == ']') {
					char *p=input+2;
					fputc(c1, stdout);
					while (*p && *p!= '[') 
						fputc(*p++, stdout);
					fprintf(stdout,"[ (inclusion)");
				}
				/* module */ 
				else if (c1 == '[') {
					char *p=input+2;
					fputc(c1, stdout);
					while (*p && *p!=']') 
						fputc(*p++, stdout);
					fprintf(stdout,"] (module)");
				}
				/* _tX time functions */
				else if (c1 == 't' && strchr("dhmnsyM",c2)) {
					fputc(c1,stdout);
					fputc(c2,stdout);
					switch (c2) {
						case 'd': 
						   fprintf(stdout, "  (push day)"); 
						    break;
						case 'h': 
						   fprintf(stdout, "  (push hour)"); 
						    break;
						case 'm': 
						   fprintf(stdout, "  (push minute)"); 
						    break;
						case 'n': 
						  fprintf(stdout, "  (push millisec)"); 
						    break;
						case 's': 
						   fprintf(stdout, "  (push seconds)"); 
						    break;
						case 'y': 
						   fprintf(stdout, "  (push year)"); 
						    break;
						case 'M': 
						   fprintf(stdout, "  (push month)"); 
						    break;
					}
				}
				/* general _t command*/
				else if (c1 == 't') {
					fputc(c1,stdout);
					fprintf(stdout, "  (push #6 time values)");
				}
				/* the _OS command */
				else if (c1 == 'O' && c2=='S')
					fprintf(stdout, "OS  (push OS type)");
				/* the _# command */
				else if (c1 == '#') 
					fprintf(stdout, "#  (break outer parsing)");
				/* the _D command */
				else if (c1 == 'D') 
					fprintf(stdout, "D  (debug mode disabled)");
				/* the _r command */
				else if (c1 == 'r') {
					if (ROUND == 0.0) 
						fprintf(stdout, "r  (set rounding to nearest integer)");
					else fprintf(stdout, "r  (set rounding to cut)");
				}
				/* the _i command */
				else if (c1 == 'i') {
					if (isNTDiv) 
						fprintf(stdout, "i  (set normal division)");
					else fprintf(stdout, "i  (set integer division)");
				}
				/* the _+ command */
				else if (c1 == '+') {
					if (DelTermin) 
						fprintf(stdout, "+  (set retain terminator)");
					else fprintf(stdout, "+  (set delete terminator)");
				}
				/* the _& command */
				else if (c1 == '&') {
					if (isPrependAmp) 
						fprintf(stdout, "&  (unset prefix before hex, octal and binary)");
					else fprintf(stdout, "&  (set prefix before hex, octal and binary)");
				}
				/* the _A command */
				else if (c1 == 'A') 
					fprintf(stdout, "A  (push highest integer array index)");
				/* the _P command */
				else if (c1 == 'P') 
					fprintf(stdout, "P  (push highest PAD index)");
				/* the _v command */
				else if (c1 == 'v') 
					fprintf(stdout, "v  (push version)");
				/* the _b command */
				else if (c1 == 'b') 
					fprintf(stdout, "b  (set binary output)");
				/* the _B command */
				else if (c1 == 'B') 
					fprintf(stdout, "B  (set base to %lld)",Stack[TOS]);
				/* the _c command */
				else if (c1 == 'c') 
					fprintf(stdout, "c  (timer call)");
				/* the _d command */
				else if (c1 == 'd') 
					fprintf(stdout, "d  (set decimal output)");
				/* the _o command */
				else if (c1 == 'o') 
					fprintf(stdout, "o  (set octal output)");
				/* the _h/_x command */
				else if (c1 == 'x' || c1 == 'h') 
					fprintf(stdout, "%c  (set hexadecimal output)",c1);
				/* the _s command */
				else if (c1 == 's') 
					fprintf(stdout, "s  send \'%s\' to shell)",PAD);
				/* the _e command */
				else if (c1 == 'e') 
					fprintf(stdout, "e  (clear both PAD and array)");
				/* the _q command */
				else if (c1 == 'q') 
					fprintf(stdout, "q  (push stack depth)");
				/* the _@ command (not an underscore) */
				else if (c1 == '@')
				       fprintf(stdout, "@  (execute PAD as function)"); 
				/* all others */
				else if (strchr(":<OCER({FUS+.)}",c1))
					fputc(c1, stdout);
				/* if not an underscore command, nor
				 * another command, print 'no op' */
				else fprintf(stdout, "  (no op)");
			} // end case '_'
			break;
			/* debug: format function loading */
			case '[':
				fprintf(stdout, "  (loading function)");
				break;
			/* debug: skipping 'pascal' comments */
			case '(':
				if (c1 == '*') 
					fprintf(stdout, "*..*)  (skipping 'pascal' comment)");
				break;
			/* debug: format choice (if) */
			case '\?': {
				if (c1 == '!') fprintf(stdout, "!  (abort)");
				else if (BackFuncBuffer[0]!='\0') {
					if (!Stack[TOS]) 
						fprintf(stdout,"\b[%s]?  (two-functions if)", FuncBuffer);
					else 
						fprintf(stdout,"\b[%s]?  (two-functions if)", BackFuncBuffer);
				}
				else {
					if(Stack[TOS]) 
						fprintf(stdout,"\b[%s]?  (one-function if)", FuncBuffer);
				}
			}
			break;
			/* debug: format cycle (repeat and while) */
			case '!': {
				if (c1 == '\?') fprintf(stdout, "?  (abort)");
				else if (BackFuncBuffer[0]!='\0') 
					fprintf(stdout, "\b[%s][%s]!  (two-functions cycle)", BackFuncBuffer, FuncBuffer);
				else fprintf(stdout, "\b[%s]!  (one-function cycle)", FuncBuffer);
			}
			break;
			/* debug: format strings, highlighting also token ""
			 * warning: only one-line strings will be printed in 
			 * full; if a string continues on next line the rest is
			 * substituted by an ellipsis (...) */
			case '\"':
				/* unfinished void string */
				if (!c1) fprintf(stdout, "<\">");
				/* void double double quotes */
				else if (c1=='\"') fprintf(stdout, "\"  (CR)");
				/* normal string */
				else {
					char *p=input+1;
					int i=0;
					/* print until a closing char */
					while(*p && *p!='\"' && *p!='\n'&&i<57){
						if (*p=='\\' && *p=='\"') {
							fprintf(stdout,"\\\"");
							p+=2;
							i++;
						}
						else fputc(*p++,stdout);
					}
					/* string too long */
					if (i>=57) fprintf(stdout,"...");
					/* check if closing double double 
					 * quotes are present */
					else if (!strncmp(p,"\"\"",2)) 
						fprintf(stdout,"\"\"");
					/* string completed */
					else if (*p=='\"') 
						fputc(*p,stdout);
					/* string goes on next line */
					else if (*p=='\n' && *(p+1)) 
						fprintf(stdout,"...\"");
					/* unfinished string */
					else if (!*p || *p=='\n') 
						fprintf(stdout,"<\">");
				}
				break;
			/* debug: format storing/fetching over variables
			 * Note: B and O have already been treated */
			case 'A':	//B
			case 'C'...'N':	//O
			case 'P'...'Z':
			case 'a'...'z': { 
				/* debug: @, index command in the form a@, */
				if (c1=='@' && c2==',') 
					fprintf(stdout, "@,  (storing function %c at index)",c);
				/* debug: show content of current variable */
				else if (c1 == '@') {
					fputc(c1, stdout);
					if (c >= 'a' && c <= 'z')
						fprintf(stdout, " = [%s]", VarFBuffer[c-'a']);
					else if (c >= 'A' && c <= 'Z')	
						fprintf(stdout, " = %lld", VarIBuffer[c-'A']);
					else fprintf(stdout, "  (irregular fetching)");
				}
				/* debug: format ,, command */
				else if (islow(c) && c1 == ',' && c2 == ',')
					fprintf(stdout, ",, (copy function %c into PAD)",c);
				/* debug: format _, command */
				else if (islow(c) && c1 == '_' && c2 == ',')
					fprintf(stdout, "_, (put PAD into var %c as function)",c);
				/* debug: format _' command */
				else if (islow(c) && c1 == '_' && c2 == '\'')
					fprintf(stdout, "_' (put PAD into var %c as string)",c);
				/* debug: format _= compare operator */
				else if (islow(c) && islow(c1) &&\
						c2=='_' && c3=='=') {
					fprintf(stdout, "%c_=  (compare string functions)",c1);
				}
				/* debug: simple storing */
				else if (c1 == ',') fputc(c1, stdout); 
				else fprintf(stdout, " (literal)");
				break;
			}
		}
	fprintf(stdout, "\n");
	}
}
/* end debug */
#endif


/* parse()
 * the PARSER ENGINE; I analyze each line as a whole entity, for easy parsing 
 * and to make the -p option and include_file() easier to implement;
 * 'input' is the evaluable string containing owl code;
 * return EXIT_SUCCESS if everything went OK; if something went wrong, this 
 * may only be due to underflow or overflow errors treated into pop() and 
 * push(), so the exit procedure into parse() is only destined to errorless
 * programs; abort functions ?! and !?, which call in turn quit(), also 
 * don't reach parse() end; in all these cases, the timing feature cannot 
 * be reached and performed. */
int parse(char *input) {
	long long int op1, op2, op3; 	// all-purposes stack-values vars
#ifdef OWL_DEBUG
	static int printDebug=0;	// Debug flag for debug start
#endif
	long long int TempIBuffer[MAXVARS];	// for local variables copy
	char TempFBuffer[MAXVARS][LIMIT];	// in _[] and _][
	int i;
	struct tm *st_ptr;			// for timing functions _t
	time_t st_lt;				// and family, independent
	long long int hour, min, sec;		// of option -t
	long long int msec, day, month, year; 
	struct timeval tv;

	/* if we get here, the file is not void - set execution flag */
	hasExecuted = TRUE;

	/* parse char by char until input line is over */
	while (*input) {
#ifdef OWL_DEBUG
		/* the debug function if required; 
		 * print message here because debug() cannot catch it */
		if (isDebug && !printDebug) {
			fprintf(stdout,"Debugging of program %s\n",FileName);
			printDebug++;
		}
		if (isDebug && !isFunc && !isString && !isComment) 
			debug(input);
#endif

		/* The number parser
		 * parse number (binary, octal, decimal, hex, any base);
		 * all valid strings are converted to 64 bits numbers */

		/* get a number 
		 * get a binary number and push it */
		if ('B' == *input && isDigit(*(input+1),BIN)\
				&& !(isString + isComment + isFunc)) {
			char numb[LIMIT], *num = numb;
			input++;
			while (isDigit(*input, BIN)) *num++ = *input++; 
			*num = '\0';
			push(toNUM(numb, BIN));
			continue;
		}
		/* get an octal number and push it */
		else if ('O' == *input && isDigit(*(input+1),OCT)\
				&& !(isString + isComment + isFunc)) {
			char numb[LIMIT], *num = numb;
			input++;
			while (isDigit(*input, OCT)) *num++ = *input++; 
			*num = '\0';
			push(toNUM(numb, OCT));
			continue;
		}
		/* get a hexadecimal number and push it */
		else if (ishexprefix(input) &&!(isString+isComment+isFunc)) {
			char numb[LIMIT], *num = numb;
			input += 2;
			while(isDigit(*input, HEX)) *num++ = *input++; 
			*num = '\0';
			push(toNUM(numb, HEX));
			continue;
		}
		/* get a peculiar base number and push it */
		else if (ispecprefix(input) &&!(isString+isComment+isFunc)) {
			char numb[LIMIT], *num = numb;
			input += 2;
			while(isDigit(*input, base)) *num++ = *input++; 
			*num = '\0';
			push(strtoll(numb, NULL, base));
			continue;
		}
		/* get a decimal number and push it  */
		else if (isDigit(*input, DEC)&&!(isString+isComment+isFunc)) {
			char numb[LIMIT], *num = numb;
			while(isDigit(*input, DEC)) *num++=*input++;
			*num = '\0';
			push(strtoll(numb, NULL, DEC));
			continue;
		}
		
		/* the functions parser
		 * get a function and store it into the function buffer; 
		 * skip inclusion commands into function */

		/* init: initialize function buffer, copying its content to 
		 * the back-buffer, resetting function buffer and pointer */
		if (('[' == *input) && (!isFunc) && !(isComment + isString)) {
			int i;
			FBuffer = FuncBuffer;
			BFBuffer = BackFuncBuffer;
			for (i = 0; i < LIMIT; i++) *BFBuffer++ = *FBuffer++;
			isFunc = TRUE;
			erase_buffer(FuncBuffer);
			FBuffer = FuncBuffer;
			input++;
			continue;
		}
		/* treat function inner strings */
		else if (isFunc && '\"' == *input && !isInnerString) {
			isInnerString=TRUE;
			*FBuffer++ = *input++;
			continue;
		}
		/* treat "" (CR) */
		else if (isFunc && '\"' == *input &&\
				'\"' == *(input+1) && isInnerString) {
			isInnerString=FALSE;
			*FBuffer++ = *input++;
			*FBuffer++ = *input++;
			continue;
		}
		/* store last inner string double quote */
		else if (isFunc && '\"' == *input && isInnerString) {
			isInnerString=FALSE;
			*FBuffer++ = *input++;
			continue;
		}
		/* get inner string escapes */
		else if (isFunc && '\\' == *input && isInnerString) {
			*FBuffer++ = *input++;
			*FBuffer++ = *input++;
			continue;
		}
		/* store inner string characters */
		else if (isFunc && isInnerString) {
			*FBuffer++ = *input++;
			continue;
		}
		/* check end of function */
		else if ((TRUE==isFunc) && !(isComment+isString) &&\
			       	!isInclude && ((']' == *input) ||\
				 ((FBuffer - FuncBuffer) >= LIMIT - 1))) {
			*FBuffer = '\0';
			isFunc = 0;
			if (*input==']') input++;
			/* execute function directly */
			if (*input=='@') {
				input++;
#ifdef OWL_DEBUG
				/* message here 'cause debug() can't catch it */
				if (isDebug)
					fprintf(stdout, "Next : [%s]@ (direct execution)\n", FuncBuffer);
				/* set debug override flag */
				if (overRideStep) isDebug=FALSE;
#endif					
				parse(FuncBuffer);
#ifdef OWL_DEBUG				
				/* reset debug override flag */
				if (overRideStep) isDebug=TRUE;
#endif					
			}
			continue;
		}
		/* store function */
		else if (isFunc && !(isComment + isString + isInnerString)) {
			if ('[' == *input && !isInclude) isFunc++;
			else if ('[' == *input &&  isInclude) isInclude=FALSE;
			else if (']' == *input && !isInclude) isFunc--;
			else if (']' == *input &&  isInclude) isInclude=FALSE;
			/* skip inclusion command */
			else if(('_'==*input)&&('['==*(input+1)||\
						']'==*(input+1))){
				isInclude=TRUE;
				*FBuffer++ = *input++;
			}
			*FBuffer++ = *input++;
			continue;
		} 

		/* the string parser
		 * get a string and store it into PAD;
		 * parse also all implemented escape chars */

		/* detect double double-quotes token on its own */
		if ((!isString) && ('\"' == *input) && ('\"' == *(input+1)) &&\
			       	!(isComment + isFunc)) {
			fprintf(stdout, "\n");
			input+=2;
			continue;
		}
		/* init: initialize erasing PAD (if required) */
		if ((!isString) && ('\"' == *input) && !(isComment + isFunc)) {
			isString = TRUE;
			/* use -e option at start for erasing strings before 
			 * instantiating; this prevents the use of PAD as an 
			 * array, because any string would blank the array when 
			 * instantiated */
			if (isBlank) erase_buffer(PAD);
			Pad = PAD;
			input++;
			/* unfinished void string */
			if (!*input) {
				*Pad = '\0';
				isString = FALSE;
			}
			continue;
		}
		/* check end of string */
		else if (isString && !(isComment + isFunc)&&(('\"' == *input)\
					|| ((Pad - PAD) >= LIMIT - 1))) {
			*Pad = '\0';
			/* the double closing quotes prevent printing */
			if ('\"' == *(input+1)) input++;
			/* print directly the string */
			else {
				fprintf(stdout, "%s", PAD);
				fflush(NULL);
			}
			isString = FALSE;
			if (*input=='\"') input++;
			continue;
		}
		/* store string */
		else if (isString && !(isComment+isFunc)) {
			/* parse escape chars */
			if ('\\' == *input) {
				switch(*(input + 1)) {
					/* normal escape chars */
					/* end of string */
					case '0': *Pad++ = '\0'; break;
					/* backspace */
					case 'b': *Pad++ = '\b'; break; 
					/* horizontal tab */
					case 't': *Pad++ = '\t'; break; 
					/* newline */
					case 'n': *Pad++ = '\n'; break; 
					/* vertical tab */
					case 'v': *Pad++ = '\v'; break; 
					/* form feed */
					case 'f': *Pad++ = '\f'; break; 
					/* carriage return */
					case 'r': *Pad++ = '\r'; break; 
					/* double quote */
					case '\"':*Pad++ = '\"'; break;
					/* single quote */
					case '\'':*Pad++ = '\''; break; 
					/* question mark */
					case '\?':*Pad++ = '\?'; break; 
					/* backslash */
					case '\\':*Pad++ = '\\'; break; 
					/* extended escape chars according 
					 * to Latin1 extended table */
					case '!': *Pad++ = 161; break;
					case 'c': *Pad++ = 162; break;
					case 'L': *Pad++ = 163; break;
					case 'Q': *Pad++ = 164; break;
					case 'Y': *Pad++ = 165; break;
					case '|': *Pad++ = 166; break;
					case 'S': *Pad++ = 167; break;
					case 'P': *Pad++ = 168; break;
					case 'C': *Pad++ = 169; break;
					case '<': *Pad++ = 171; break;
					case 'm': *Pad++ = 172; break;
					case 'R': *Pad++ = 174; break;
					case 's': *Pad++ = 175; break;
					case 'o': *Pad++ = 176; break;
					case '+': *Pad++ = 177; break;
					case '2': *Pad++ = 178; break;
					case '3': *Pad++ = 179; break;
					case 'M': *Pad++ = 180; break;
					case 'u': *Pad++ = 181; break;
					case 'x': *Pad++ = 183; break;
					case '1': *Pad++ = 185; break;
					case 'd': *Pad++ = 186; break;
					case '>': *Pad++ = 187; break;
					case 'I': *Pad++ = 191; break;
					case 'A': *Pad++ = 198; break;
					case 'p': *Pad++ = 215; break;
					case 'B': *Pad++ = 223; break;
					case 'a': *Pad++ = 230; break;
					case '-': *Pad++ = 247; break;
					case 'O': *Pad++ = 248; break;
					case 'T': *Pad++ = 254; break;
					default:  
						*Pad++ = '\\'; 
						*Pad++ = *(input + 1);
				}
				input++;
			}
			else *Pad++ = *input;
			input++;
			continue;
		}
		
		/* multiline comment parsing 
		 * parse all characters until a closing token found, doing 
		 * nothing in between; Note: the single line comment is 
		 * detected into the language process routine */

		/* check where comment begins */
		if ('(' == *input && '*' == *(input+1) && !isComment\
				&& !(isString + isFunc)) {
			isComment = TRUE;
			input += 2;
			continue;
		}
		/* check where comment ends */
		else if ('*' == *input && ')' == *(input+1) && isComment\
				&& !(isString + isFunc)) {
			isComment = FALSE;
			input += 2;
			continue;
		}
		/* discard inner chars */
		else if (isComment && !(isString + isFunc)) {
			input++;
			continue;
		} 
		
		/* language process routine: parse char by char and 
		 * execute code; cases are in ASCII order */
		switch (*input) {
			/* for now, we discard any blank or control char... */
			case 1 ... 32: break;
			/* ! cycles and abort */
			case '!': 
#ifdef OWL_DEBUG				
				/* set debug override flag */
				if (overRideStep) isDebug=FALSE;
#endif					
				{
					char fun[LIMIT], bfun[LIMIT];
					/* !? abort */
					if ('?' == *(input+1)) { quit(); }
					/* ! cycles */
					strncpy(fun, FuncBuffer, LIMIT);
					strncpy(bfun, BackFuncBuffer, LIMIT); 
					erase_buffer(FuncBuffer);
					erase_buffer(BackFuncBuffer);
					/* []! begin until */
					if ('\0' == bfun[0]) {
						do {
							parse(fun);
							op1 = pop();
						}
						while (!op1);
					}
					/* [][]! begin while repeat */
					else {
						parse(bfun);
						op1 = pop();
						while (op1) {
							parse(fun);
							parse(bfun);
							op1 = pop();
						}
					}
				}
#ifdef OWL_DEBUG				
				/* reset debug override flag */
				if (overRideStep) isDebug=TRUE;
#endif					
				break;
			/* $ swap */
			case '$': 
				op1 = pop();
				op2 = pop();
				push(op1);
				push(op2);
				break;
			/* % dup */
			case '%': 
				op1 = pop();
				push(op1);
				push(op1);
				break;
			/* & bitwise and */
			case '&': 
				op1 = pop();
				op2 = pop();
				push(op1 & op2);
				break;
			/* ' roll */ 
			case '\'': 
				op2 = pop();
				if (TOS-op2>0) op3 = Stack[TOS - op2];
				else break;
				for (op1 = 1; op1 <= op2; op1++)
					Stack[TOS-op2+op1-1]=Stack[TOS-op2+op1];
				Stack[TOS] = op3;
				break;
			/* ( input char - one char only */
			case '(': 
#ifndef OWL_REMOVE
				{
					// thanks to Kyle R. Burton
					// for this routine. See initial
					// GPL banner for credits
					struct termios modes, savemodes;
					tcgetattr(0, &modes);
					savemodes = modes;
					modes.c_lflag &= ~ICANON;
					modes.c_lflag &= ~ECHO;
					tcsetattr(0, 0, &modes);
#endif
					op1 = fgetc(stdin);
					push(op1);
#ifndef OWL_REMOVE
					tcsetattr(0, 0, &savemodes);
				}
#endif
				break;
			/* ) emit as char */
			case ')': 
				op1 = pop();
				/* this piece of code makes any CR/NL 
				 * output portable on any Operating System. 
				 * In ASCII, 13 is CR, 10 is NL */
				if (13==op1 || 10==op1) fputc('\n', stdout);
				else fputc((char)op1, stdout);
				fflush(NULL);
				break;
			/* * multiplication */
			case '*': 
				op1 = pop();
				op2 = pop();
				push(op1 * op2);
				break;
			/* + addition */
			case '+': 
				op1 = pop();
				op2 = pop();
				push(op1 + op2);
				break;
			case ',': 
				/* ,, dynamic binding - copy var into PAD 
				 *    this is the second half of ,, */
				if (*(input+1)==',') {
					op1=calcASCIIoffset(pop());
					strncpy(PAD,VarFBuffer[op1-'a'],LIMIT);
					input++;
				}
				/* store a value into PAD */
				else {
					op1 = pop();
					op2 = pop();
					PAD[(int)llabs(op1)%LIMIT]=(char)op2;
				}
				break;
			/* - subtraction */
			case '-': 
				op1 = pop();
				op2 = pop();
				push(op2 - op1);
				break;
			/* . print number (according to base) */
			case '.': 
				op1 = pop();
				printNumber(stdout,op1);
				break;
			/* / division */
			case '/': 
				op1 = pop();
				op2 = pop();
				push(divide(op2,op1));
				break;
			/* : root */
			case ':': 
				op1 = pop();
				op2 = pop();
				push(nroot(op2,op1));
				break;
			/* ; drop */
			case ';': 
				pop();
				break;
			case '<':
				/* << shift left */
				if (*(input+1) == '<') {
					input++;
					op1 = pop();
					op2 = pop();
					push(op2 << op1);
				}
				/* < input a number */
				else {
					char NUM[LIMIT], *nn=NUM;
					fgets(NUM, LIMIT, stdin);
					NUM[strlen(NUM)-1]='\0';
					if ('B'==*nn)
						push(toNUM(nn+1,BIN));
					else if ('O'==*nn)
						push(toNUM(nn+1,OCT));
					else if (ishexprefix(nn))
						push(toNUM(nn+2,HEX));
					else if (ispecprefix(nn))
						push(strtoll(nn+2,NULL,base));
					else push(strtoll(nn,NULL,DEC));
				}
				break;
			/* = equality test */
			case '=': 
				op1 = pop();
				op2 = pop();
				push(-(op1==op2));
				break;
			case '>': 
				op1 = pop();
				op2 = pop();
				/* >> shift right */
				if (*(input+1) == '>') {
					input++;
					op3 = op2 >> op1;
				}
				/* > greater than test */
				else op3 = -(op2 > op1);
				push(op3);
				break;
			/* ? choices and abort */
			case '\?': 
#ifdef OWL_DEBUG				
				/* set debug override flag */
				if (overRideStep) isDebug=FALSE;
#endif					
				{
					char fun[LIMIT], bfun[LIMIT];
					/* ?! abort */
					if ('!' == *(input+1)) { quit(); }
					/* ? choices */
					strncpy(fun, FuncBuffer, LIMIT);
					strncpy(bfun,BackFuncBuffer, LIMIT); 
					erase_buffer(FuncBuffer);
					erase_buffer(BackFuncBuffer);
					op1 = pop();
					/* []? if then */
					if ('\0' == bfun[0]) {
						if (op1) parse(fun);
					}
					/* [][]? if else then */
					else {
						if (op1) parse(bfun);
						else parse(fun);
					}
				}
#ifdef OWL_DEBUG				
				/* reset debug override flag */
				if (overRideStep) isDebug=TRUE;
#endif					
				break;
			case '@':
				/* @@ dynamic binding
				 *    execute indexed function */
				if ('@' == *(input+1)) {
					parse(VarFBuffer[fIndex - 'a']);
					input++;
				}
				/* @, dynamic binding - store to index function 
				 *    pointed by TOS; this is the second half 
				 *    of @,*/
				else if (',' == *(input+1)) {
					fIndex=calcASCIIoffset(pop());
					input++;
				}
				/* @  fetch a value from PAD */ 
				else {
					op1 = pop();
					push((long long int)PAD[(int)llabs(op1)%LIMIT]);
				}
				break;
			/* ] push ASCII value of next character
			 *   Note: program gets here only outside functions; 
			 *   so to insert ] into a function, use PAD and copy 
			 *   then into a function */
			case ']':
				input++;
				op1 = *input;
				if (op1) push(op1);
				else push('\0');
				break;
			case '#':
				/* #, store a value into integer array */
				if (*(input+1)==',') {
					op1 = pop();
					op2 = pop();
					ARRAY[(int)llabs(op1)%ARRAYLIM] = op2;
					input++;
				}
				/* #@ fetch a value from integer array */ 
				else if (*(input+1)=='@') {
					op1 = pop();
					push(ARRAY[(int)llabs(op1)%ARRAYLIM]);		
					input++;
				}
				/* #  single line comment: break immediately */
				else return EXIT_SUCCESS;
				break;
			/* A..Z numeric variables */
			case 'A' ... 'Z':
				input = getVar(input);
				break;
			/* \ negate */
			case '\\': 
				op1 = pop();
				push(-op1);
				break;
			/* ^ power */
			case '^': 
				op1 = pop();
				op2 = pop();
				push(power(op2, op1));
				break;
			/* _ underscore (system) commands or commands 
			 *   also beginning with underscore, 
			 *   which perform tasks in very special cases */
			case '_': switch (*(++input)) {
				/* a_, dynamic binding - store PAD to function 
				 *     as function; this is the second 
				 *     half of _, */
				case ',': {
					op1=calcASCIIoffset(pop());
					strncpy(VarFBuffer[op1-'a'],PAD,LIMIT);
					break;
				}
				/* a_' dynamic binding - store PAD to function
				 *     as string; this is the second half of _'
				 *     here we must escape double quotes*/
				case '\'': {
					char *l, *p=PAD;
					op1=calcASCIIoffset(pop());
					l=VarFBuffer[op1-'a'];
					*l++='\"';	
					while (*p) {
						if (*p=='\"') *l++='\\';
						*l++=*p++;
					}
					*l++='\"';	
					*l='\0';
					break;
				}
				/* ab_= compare string functions 
				 *      this is the second half of _= */
				case '=': 
					op2=calcASCIIoffset(pop());
					op1=calcASCIIoffset(pop());
					push(strcmp(VarFBuffer[op1-'a'],\
					VarFBuffer[op2-'a']));
					break;
				/* _~ substring search
				 *    this is the second half of _~ */
				case '~': {
					char *r;
					int i=calcASCIIoffset(pop());
					r=strstr(PAD,VarFBuffer[i-'a']);
					push((long long int)(r-PAD));
					break;
				}
				/* _( read a character from read-file */
				case '(':
					if (chR) {
						char c=fgetc(chR);
						if (feof(chR))
							push('\0');
						else push(c);
					}
					break;

				/* _U unget */ 
				case 'U':
					if (chR) {
						op1=pop();
						ungetc(op1, chR);
					}
					break;
				/* _< convert-number-in-PAD */
				case '<':
					/* get starting position from TOS */
					op3=llabs(pop());
					/* convert number*/
					op2=convertNumber(PAD,op3,&op1);
					/* no numbers if position is null */
					if (!op2) { 
						push(0);
					}
					else {
						push(op1);
						push(op2);
				  	}
					break;
				/* _F check EOF for read-file */
				case 'F': 
					  if (chR) {
						  op1=feof(chR);
						  if (!op1) push(FALSE);
						  else push(TRUE);
					  }
					  else push(FALSE);
					  break;
		    		/* _S restore seek read-file position*/
		    		case 'S': 
			    		/* read-file channel exists */
				    	if (chR) {
						op1=TOS?pop():-1; 
						/* set seek start on TOS = 0*/
						if (!op1) {
							fseek(chR,0L,SEEK_SET);
							isSeekStart=TRUE;
						}
						/* set seek end on TOS empty
						 * or TOS true */
						else {
							fseek(chR,0L,SEEK_END);
							isSeekStart=FALSE;
						}
						push(TRUE);
					}
					else push(FALSE);
#ifdef OWL_DEBUG
					isFileComplete=5;
#endif
					break;
		    		/* _R restore write-file position*/
		    		case 'R':
			    		/* write-file channel exists */
				    	if (chW) {
						op1=TOS?pop():-1;
						/* set seek start on TOS = 0 */
					    	if (!op1) {
							fflush(chW);
							fclose(chW);
							chW=fopen(TempFileName, "w");
							if (chW) {
								push(TRUE);
								isRestoreStart=TRUE;
							}
							else push(FALSE);
						}
						/* set seek end on TOS empty
						 * or TOS true */
						else {
							long long res=TRUE;
							/* resolve previous 
							 * seek start*/
							if (isRestoreStart)
								res=cat();
							/* reopen */
							chW=fopen(WriteFileName, "a");
							/* return cat status */
							if (!res) push(FALSE);
							else if(chW)push(TRUE);
							else push(FALSE);
						}
			    		}
					/* file was not open, cannot reset */
			    		else push(FALSE);
#ifdef OWL_DEBUG
					isFileComplete=3;
#endif
					break;
				/* _E erase write-file content */
				case 'E':
					/* file channel exists */
					if (chW) {
						long long int res=TRUE;
						/* resolve seek start */
						if (isRestoreStart) res=cat();
						else fclose(chW);
				      		/* reopen forcing write and so 
						 * erasing it */
				       		chW=fopen(WriteFileName, "w");
						/* return cat status if wrong */
						if (!res) push(FALSE);
						/* return fopen status */
						else if (chW) push(TRUE);
						else push(FALSE);
					}
					/* file channel not open, cannot erase*/

					else push(FALSE);
#ifdef OWL_DEBUG
					isFileComplete=4;
#endif
					break;
				/* _C close file */
				case 'C':
					/* close write-file*/
					if (!TOS || Stack[TOS]) {
						if (TOS) pop();
						/* file channel exists */
						if (chW) {
							long long int res=TRUE;
							/* resolve seek start */
							if (isRestoreStart) {
								res=cat();
								push(res);
							}
							/* resolve seek end */
							else {
								if(!fclose(chW)) 	 							 push(TRUE);
					      			else push(FALSE);
							}	
						}
						/* file channel was closed */
				       		else push(TRUE);
					}
					/* close read-file */
					else {
						if (TOS) pop();
						/* file channel exists */
						if (chR) {	
							if (!fclose(chR)) 
								push(TRUE);
							else push(FALSE);
						}
						/* file channel was closed */
						else push(TRUE);
					}
#ifdef OWL_DEBUG
					isFileComplete=2;
#endif
					break;
		    		/* _+ toggle remove terminal character */
			    	case '+':
					DelTermin=DelTermin?FALSE:TRUE;
					break;
		    		/* _{ read a string from a read-file */
			    	case '{':
					/* erase PAD in advance */
					for (op1=0;op1<LIMIT;op1++) 
						PAD[op1]='\0';
					if (chR) {
						char temp[LIMIT+2];
						if(fgets(temp, LIMIT, chR)) {
							if (temp[strlen(temp)-1]=='\n' && DelTermin) temp[strlen(temp)-1]='\0';
							strncpy(PAD,temp,LIMIT);
							for(op1=0;op1<LIMIT;op1++) 
								temp[op1]='\0';
							fflush(chR);
			    			}
					}
					break;
		    		/* _. write a number to a write-file */
		    		case '.':
					op1=pop();
					if (chW) printNumber(chW,op1);
					break;
		    		/* _. write a character to a write-file */
		    		case ')':
					if (chW) fputc((char)pop(),chW); 
					break;
		    		/* _} write a line to a write-file */
		    		case '}':
					if (chW) {
			    			if(fputs(PAD,chW)!=EOF) 
							fflush(chW);
					}
					break;
				/* _] include file whose name is in the 
				 *    form _]inc.owl[ in the stream */
				case ']':
					input+=include_file(input+1)+1;
#ifdef OWL_DEBUG
					isDebugInclude=1;
#endif
					break;
				/* _[ execute file whose name is in the
				 *    form _[inc.owl] in the stream, 
				 *    making a local-variables copy */
				case '[': 
					/* copy caller vars into buffers */
					for (i = 0; i < MAXVARS; i++) {
						TempIBuffer[i] = VarIBuffer[i];
						strncpy(TempFBuffer[i], VarFBuffer[i], LIMIT);
					}
					/* execute file with vars copy */
					input+=include_file(input+1)+1;
					/* restore caller vars */
					for (i = 0; i < MAXVARS; i++) {
						VarIBuffer[i] = TempIBuffer[i];
						strncpy(VarFBuffer[i], TempFBuffer[i], LIMIT);
					}
#ifdef OWL_DEBUG
					isDebugInclude=2;
#endif
					break;
#ifndef OWL_REMOVE
				/* _c chronometer command */
				case 'c':
					/* odd call: reset chronometer */
					if (chrono & 1) {
						gettimeofday(&tvChrono, NULL);
						begChrono = ((double)tvChrono.tv_sec + tvChrono.tv_usec / 1000000.0);
		 			 }
		 			/* even call: push execution interval */
					else {
						gettimeofday(&tvChrono, NULL);
						endChrono = ((double)tvChrono.tv_sec + tvChrono.tv_usec / 1000000.0);
						push((int)((endChrono - begChrono) * 1000));
				  	}
					chrono++;
					break;
#endif
				/* _@ dynamic binding: 
				 *    execute PAD as function */
				case '@':
					parse(PAD);
					break;
				/* _B set/get user base */
				case 'B':
					op1=(int)pop();
					if (op1)
						base=op1<2?2:(op1>36?36:op1);
					else push(base);
					break;
				/* _A push array upper limit */
				case 'A':
					push((long long int)ARRAYLIM);
					break;
				/* _P push PAD upper limit */
				case 'P':
					push((long long int)LIMIT);
					break;
#ifdef OWL_DEBUG
				/* _D toggle debug mode */
				case 'D':
					isDebug=(isDebug==1?0:1);
					if (isDebug) {
						fprintf(stdout, "\n\nDebug: _D  (debug mode enabled)");
						printDebug++;
					}
					break;
#endif
				case 'O':
					/* _OS push OS type; 0=UNIX; 1=WIN */
					if ('S' == *(input + 1)) {
#ifndef OWL_REMOVE
						push(0ll); 
#else
						push(1ll); 
#endif
						++input;
					}
                       			/* _O open file
					 *    name must reside in PAD */
		                        else {
						/* open read-file */
						if (!TOS || !Stack[TOS]) {
							if (!chR && PAD[0]) {
                               					if (TOS) pop();
							       	chR=fopen(PAD,"r");
								if (chR) {
                               						/* store name */
			                                		strncpy(ReadFileName,PAD,LIMIT);
									push(TRUE);
								}
								else push(FALSE);
							}
							else push(FALSE);
						}
						/* open write-file */
			                        else {
							if (!chW && PAD[0]) {
								pop();
								chW=fopen(PAD,"a");
								if (chW) {
	                               					/* store name */
				                                	strncpy(WriteFileName,PAD,LIMIT);
	                               					strncpy(TempFileName,PAD,LIMIT);
									strcat(TempFileName,".~copy");
									push(TRUE);
								}
			                                	else push(FALSE);
							}
                       				}
                       			}
#ifdef OWL_DEBUG
					isFileComplete=1;
#endif
					break;
				/* _v push version numbers */
				case 'v':
					push((long long int)RELEASE);
					push((long long int)MINOR);
					push((long long int)MAJOR);
					break;
				/* _b set binary base for output */
				case 'b':
					base = BIN;
					break;
				/* _d set base decimal for output */
				case 'd':
					base = DEC; 
					break;
				/* _o set octal base for output */
				case 'o':
					base = OCT; 
					break;
				/* _h _x set hex base for output */
				case 'h': 
				case 'x': 
					base = HEX; 
					break;
				/* _s execute PAD as shell command */
				case 's':
					system(PAD);
					break;
				/* _e clear both PAD and array */
				case 'e':
					erase_buffer(PAD);
					for(op1=0; op1<ARRAYLIM; op1++)
					       ARRAY[op1]=0LL;
					break;
				/* _i toggle integer division mode */
				case 'i':
					isNTDiv= (isNTDiv ? FALSE : TRUE); 
					break;
				/* _r toggle rounding mode */
				case 'r':
					ROUND=(0.0L==ROUND?0.5L:0.0L);
					break;
				/* _& toggle & in hex output */
				case '&':
					isPrependAmp=(isPrependAmp?0:1);
					break;
				/* _q return stack depth */
				case 'q':
					push(TOS);
					break;
#ifndef OWL_REMOVE
				/* _t time values */
				case 't': 
					st_lt  = time(NULL);
					st_ptr = localtime(&st_lt); 
					gettimeofday(&tv, NULL);
					hour = st_ptr->tm_hour;
					min  = st_ptr->tm_min;
					sec  = st_ptr->tm_sec;
					msec = tv.tv_usec;
					year =st_ptr->tm_year + 1900;
					month= st_ptr->tm_mon + 1;
					day  = st_ptr->tm_mday;
					/* _tn push microseconds */
					if ('n' == *(input+1)) {
						push(msec);
						input++;
					}
					/* _th push hour */
					else if ('h' == *(input+1)){
						push(hour);
						input++;
					}
					/* _tm push minutes */
					else if ('m' == *(input+1)){
						push(min);
						input++;
					}
					/* _ts push seconds */
					else if ('s' == *(input+1)){
						push(sec);
						input++;
					}
					/* _td push day */
					else if ('d' == *(input+1)){
						push(day);
						input++;
					}
					/* _tM push month */
					else if ('M' == *(input+1)){
						push(month);
						input++;
					}
					/* _ty push year */
					else if ('y' == *(input+1)){
						push(year);
						input++;
					}
					/* _t push year,month,day,sec,min,hour*/
					else {
						push(year);
						push(month);
						push(day);
						push(sec);
						push(min);
						push(hour);
					}
					break;
#endif
					/* ignore all the rest */
				default:
					input--;
					break;
				} // end switch underscore commands
				break;
			/* ` pick */
			case '`': 
				op1 = pop();
				if (TOS - op1 > 0) push(Stack[TOS - op1]);
				break;
			/* a..z function variables */
			case 'a' ... 'z': 
				input = getVar(input);
				break;
			/* { input a string; also get rid of 
			 *   terminating return key left by fgets() */
			case '{':
				fgets(PAD, LIMIT, stdin);
				PAD[strlen(PAD) - 1] = '\0';
				break;
			/* | bitwise or */
			case '|': 
				op1 = pop();
				op2 = pop();
				push(op1 | op2);
				break;
			/* } print string in PAD; 
			 *   Note: no control is done to check if string is 
			 *   terminated by '\0' (but PAD is erased at start, 
			 *   as a safety measure) */
			case '}': 
				fprintf(stdout, "%s", PAD);
				fflush(NULL);
				break;
			/* ~ logical not */
			case '~': 
				op1 = pop();
				push(-(!op1));
				break;
		}
		input++;
	}
	/* input line is over */
	return EXIT_SUCCESS;
} 
/* end parse */


/* ************************
 *	   MAIN		 *
 *************************/ 
/* hic sunt leones */
int main(int argc, char **argv) {
	
	FILE *f = NULL;
	int c, ac = argc;
	char line[LIMIT];
#ifndef OWL_REMOVE
	struct timeval tv;		/* time values		*/
	double beginS, endS;		/* reports in seconds	*/
	boolean isTiming = FALSE;	/* timer flag		*/
#endif
	/* initialize all variables, reset stack, initialize arrays and
	 * erase functions/strings buffers */
	for (c = 0; c <= MAXVARS; c++) {
		VarIBuffer[c] = 0LL;
		erase_buffer(VarFBuffer[c]);
	}
	for(c = 0; c < LIMIT; c++) Stack[c] = 0LL;  
	for(c = 0; c<ARRAYLIM; c++) ARRAY[c]=0LL;
	for(c = 0; c<ASCIILEN; c++) UsedVars[c] = FALSE;
	erase_buffer(BackFuncBuffer);
	erase_buffer(FuncBuffer);
	erase_buffer(PAD);
	
	/* parse arguments */
	while (--ac > 0 && '-' == (*++argv)[0]) {
		/* parse double-dash options */
		if (!strcmp(*argv, "--help")) {
			printHelp();
			exit(EXIT_SUCCESS);	
		}
		else if (!strcmp(*argv, "--version")) {
			printVersion(1);
			exit(EXIT_SUCCESS);	
		}
		else if (!strcmp(*argv, "--conditions")) {
			printConditions(1);
			exit(EXIT_SUCCESS);	
		}
		else if (!strcmp(*argv, "--warranty")) {
			printWarranty(1);
			exit(EXIT_SUCCESS);	
		}
		// this feature is intentionally undocumented 
		// I use it to generate the README file
		else if (!strcmp(*argv, "--greetings")) {
		fprintf(stdout, "Welcome, owl user! I hope you\'ll like this program.\n");
		fprintf(stdout, "Here\'s some information about it and its license...\n\n");
		fprintf(stdout, "To compile, go into owl source directory,  type 'make' as user to build the\nprogram ,  and 'make install'  as root to install  in the predefined system\ndirectory.\n");
		printVersion(0);
		fprintf(stdout, "				* * *\n");
		printHelp();
		printWarranty(0);
		printConditions(0);
		fprintf(stdout, "It's GPL. Enjoy!\n");
			exit(EXIT_SUCCESS);
		}
		/* stop evaluating options! */
		else if (!strcmp(*argv,"--")) {
			argv++;
			goto pstart;
		}
		/* wrong double-dash option */
		else if (!strncmp(*argv,"--",2)) {
			fprintf(stderr, WRONGOPTDERROR, *argv);
			fprintf(stderr, USEHELP);
			exit(EXIT_FAILURE);
		}
		
		/* parse single-dash options */ 
		while ((c = *++argv[0])) {
			switch(c) {
#ifdef LEAVESEXE
				/* -c leave executable (not implemented) */
				case 'c': leavesEXE = TRUE; break;
#endif
#ifdef OWL_DEBUG
				/* debug flag: -d start debug */
				case 'd': isDebug = TRUE; break;
				/* debug flag: -D print vars */
				case 'D': printVars = TRUE; break;
				/* debug flag: -F print buffers */
				case 'F': printFBuf = TRUE; break;
#endif
				/* -e erase buffers/PAD/arrays */
				case 'e': isBlank = (isBlank ? FALSE : TRUE); break;
				/* -h print help and exit */
				case 'h': printHelp(); exit(EXIT_SUCCESS);
				/* -i toggle integer division type */
				case 'i': isNTDiv = (isNTDiv ? FALSE : TRUE); break;
				/* -p parse string and exit */
				case 'p':
#ifdef OWL_DEBUG
					FileName="of option -p";  
#endif
#ifndef OWL_REMOVE
					if (isTiming) {
						gettimeofday(&tv, NULL);
						beginS=((double)tv.tv_sec+
							tv.tv_usec/1000000.0);
					}
#endif
					if ('\0' == (*argv)[1]) {
						if (!*(argv+1)) {
						  fprintf(stderr, NOSTRING);
						  fprintf(stderr, USEHELP);
						  exit(EXIT_FAILURE);
						}
						else parse(*(argv+1));
					}
					else parse(*argv+1);
					goto pexit;
					break; // end of option -p
				/* -r toggle rounding feature */
				case 'r': ROUND = (0.0L == ROUND ? 0.5L : 0.0L); 					break;
#ifdef LEAVESASM
				/* -s leave asm file (not implemented) */
				case 's': leavesASM = TRUE; break;
#endif
#ifndef OWL_REMOVE
#ifdef OWL_DEBUG
				/* debug flag: -S single step */
				case 'S': singleStep = TRUE; break;
#endif
				/* -t calculate timing */
				case 't': isTiming = TRUE; break;
#endif
				/* -v print version and exit */
				case 'v': printVersion(1); exit(EXIT_SUCCESS);
				/* wrong single-dash option */
				default:
					fprintf(stderr, WRONGOPTSERROR, **argv);
					fprintf(stderr, USEHELP);
					exit(EXIT_FAILURE);
			}
		}
	}

pstart:
	/* get input file name (discard following names) */ 
	FileName = *argv;

	/* OK; now, if after any option there's no file name left or if owl has 
	 * been launched with no parameters, issue an error and exit */
	if ((!*FileName) || (1 == argc)) {
		fprintf(stderr, NOFILE);
		fprintf(stderr, USEHELP);
		exit(EXIT_FAILURE);
	}

	/* if file cannot be read/open, issue an error and exit */
	if (FileName) {
		f = fileopen(FileName);
		if (!f) {	
			fprintf(stderr, OPENFILEERROR, FileName);
			fprintf(stderr, USEHELP); 
			exit(EXIT_FAILURE);
		}
	}

	/* data (numbers and instructions) after file name, are passed to 
	 * owl programs as parameters; particularly useful for scripts 
	 * (provided you escape characters with some meaning for the shell) 
	 * Note: they will be executed BEFORE any program line! */
	for (argc = 1; argc < ac; argc++) parse(*(argv + argc));

#ifndef OWL_REMOVE
	/* record start timer data if required */
	if (isTiming) {
		gettimeofday(&tv, NULL);
		beginS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
	}
#endif
	
	/* process file lines and close after EOF; this is the heart 
	 * of the process, and see how slim and terse it is! */
	while (fgets(line, LIMIT, f) && !parse(line));
	fclose(f);

pexit:
  
	/* print last unfinished string in the program, getting rid of \n
	 * indicating EOF if line is the last from a file
	 * Note: this part is not activated within -p option, because
	 * it does not bear a closing EOF as in files */
	if (isString) {
		if (PAD[strlen(PAD) - 1] == '\n') PAD[strlen(PAD) - 1] = '\0';
		if (!PAD[0]) fprintf(stdout, "\n");
		else fprintf(stdout, "%s", PAD);
	}

#ifdef OWL_DEBUG
	/* print last debug scheme to show stack/PAD status after last command*/
	if(isDebug) debug("\0");
#endif

#ifndef OWL_REMOVE

	/* record end timer data if required, and print time report */
	if (isTiming) {
		int ptime;
		gettimeofday(&tv, NULL);
		endS = ((double)tv.tv_sec + tv.tv_usec / 1000000.0);
		ptime = (int)((endS - beginS) * 1000);
		if (ptime < 1000) {
			/* time report in milliseconds... */
			fprintf(stdout, TIMES, ptime);
		}
		else {
			/* ...or time report in seconds */
			fprintf(stdout, TIMESS, ((double)ptime / 1000));
		}
	}
#endif

	/* print an advice if no char was processed  (i.e. if execution flag 
	 * is not set - see parse), and exit */
	if (!hasExecuted) fprintf(stdout, "(no code executed)\n");
	else fputc('\n', stdout);
	ensureCloseFile();
	return EXIT_SUCCESS;

} 
/* end main */

/* end of owl.c */
