" Vim syntax file
" Language   : owl version 0.8.0
" Maintainer : Antonio Maschio <tbin@libero.it>
" Last change: March 06, 2009

" Thanks to...
" Christian V. J. Br�ssow <cvjb@epost.de> for forth.vim

" For version 5.x: Clear all syntax items
" For version 6.x: Quit when a syntax file was already loaded
if version < 600
        syntax clear
elseif exists("b:current_syntax")
        finish
endif

" Characters allowed in keywords
if version >= 600
        setlocal iskeyword=33-64,A-Z,91-96,a-z,123-126
else
        set iskeyword=33-64,A-Z,91-96,a-z,123-126
endif

" Matching case
syn case match

" Keywords
syn keyword owlTODO contained TODO FIXME XXX

" stack
syn match owlStack  /%/
syn match owlStack  /;/
syn match owlStack  /\$/
syn match owlStack  /'/
syn match owlStack  /`/

" cycling and decisioning
syn match owlRepeat /!/
syn match owlIf     /?/

" input/output
syn match owlIO    /(/
syn match owlIO    /)/
syn match owlIO    /</
syn match owlIO    /\./
syn match owlIO    /{/
syn match owlIO    /}/

" Comments
syn region owlComment start=/#/ end=/$/ contains=owlTODO
syn region owlComment start=/(\*/ end=/\*)/ contains=owlTODO

" math, logical and bitwise
syn match owlMath   /+/
syn match owlMath   /*/
syn match owlMath   /-/
syn match owlMath   /\\/
syn match owlMath   '/'
syn match owlMath   /\^/
syn match owlMath   /:/
syn match owlMath   /=/
syn match owlMath   />/
syn match owlMath   /&/
syn match owlMath   /|/
syn match owlMath   /\~/
syn match owlMath   />>/
syn match owlMath   /<</
syn match owlMath   /#,/
syn match owlMath   /#@/


" underscore commands
syn match owlun    /_t/
syn match owlun    /_td/
syn match owlun    /_th/
syn match owlun    /_tm/
syn match owlun    /_tn/
syn match owlun    /_ts/
syn match owlun    /_ty/
syn match owlun    /_tM/
syn match owlun    /_&/
syn match owlun    /_b/
syn match owlun    /_c/
syn match owlun    /_d/
syn match owlun    /_e/
syn match owlun    /_h/
syn match owlun    /_i/
syn match owlun    /_o/
syn match owlStack /_q/
syn match owlun    /_r/
syn match owlun    /_s/
syn match owlun    /_v/
syn match owlun    /_x/
syn match owlun    /_D/
syn match owlun    /_A/
syn match owlun    /_P/
syn match owlun    /_B/
syn match owlFile  /_O/
syn match owlun    /_OS/
syn match owlFile  /_E/
syn match owlFile  /_F/
syn match owlFile  /_R/
syn match owlFile  /_S/
syn match owlFile  /_U/
syn match owlFile  /_C/
syn match owlFile  /_{/
syn match owlFile  /_}/
syn match owlFile  /_)/
syn match owlFile  /_(/
syn match owlFile  /_\./
syn match owlFile  /_+/
syn match owlStore /_:/
syn match owlStore /_</

" The following lines for owlSpecial and owlFormat are taken from c.vim
" String and Character constants
" Highlight special characters (those which have a backslash) differently
syn match owlSpecial display contained "\\\(x\x\+\|\o\{1,3}\|.\|$\)"
syn match owlFormat display "%\(\d\+\$\)\=[-+' #0*]*\(\d*\|\*\|\*\d\+\$\)\(\.\(\d*\|\*\|\*\d\+\$\)\)\=\([hlL]\|ll\)\=\([bdiuoxXDOUfeEgGcCsSpn]\|\[\^\=.[^]]*\]\)" contained
syn match owlFormat display "%%" contained
syn match owlFormat display "%%" contained
syn match  owlString /\a/
syn region owlString start=/"/ skip=/\\"/ end=/""\=/ contains=owlSpecial,owlFormat

" Inclusion
syn match owlInclude /_\[\f\+\]/
syn match owlInclude /_\]\f\+\[/

" storing/fetching
syn match owlStore /\a@,/
syn match owlStore /\a,/
syn match owlStore /\a,,/
syn match owlFetch /\a@/
syn match owlStore /@,/
syn match owlStore /,,/
syn match owlFetch /@@/
syn match owlStore /_,/
syn match owlStore /\a_,/
syn match owlFetch /_@/
syn match owlFetch /_'/
syn match owlFetch /\a_'/
syn match owlFetch /_=/
syn match owlFetch /[a-z][a-z]_=/
syn match owlFetch /_\~/
syn match owlFetch /[a-z]_\~/

" numbers
syn match owlNumber /\d\+/
syn match owlNumber /B[01]\+/
syn match owlNumber /O\o\+/
syn match owlNumber /[0x]\{1}\x\+/
syn match owlNumber /[0X]\{1}\x\+/

" Define the default highlighting.
" For version 5.7 and earlier: only when not done already
" For version 5.8 and later: only when an item doesn't have highlighting yet
if version >= 508 || !exists("did_owl_syn_inits")
        if version < 508
                let did_owl_syn_inits = 1
                command -nargs=+ HiLink hi link <args>
        else
                command -nargs=+ HiLink hi def link <args>
        endif

" The default methods for highlighting. Can be overriden later.

" math, logical and bitwise
	HiLink owlMath   Type
	HiLink owlNumber Type

" stack
	HiLink owlStack Identifier

" cycling and decisioning
	HiLink owlRepeat  Statement
        HiLink owlIf      Statement

" input/output
	HiLink owlIO      Constant
	HiLink owlFile    Constant

" storing/fetching
        HiLink owlStore   PreProc
        HiLink owlFetch   PreProc

" underscore commands
	HiLink owlun      Special
	HiLink owlInclude Special

" Strings
        HiLink owlString  Boolean
        HiLink owlStrin   Boolean
	HiLink owlSpecial SpecialChar
	HiLink owlFormat  Special

" Comments
        HiLink owlComment Comment
        HiLink owlTODO    Todo

	delcommand HiLink
endif

let b:current_syntax = "owl"

