/* owl.h
 * Copyleft 2005-2009 Antonio Maschio <tbin at libero dot it>
 *
 * owl - Obfuscated Weird Language
 * 
 * (source code optimized for 80 columns with 4 chars tab stops)
 * (source code edited and maintained with gvim)
 *
 * termios statement:
 * termios features for command '(' are taken from file term2.c 
 * under the following copyright:
 * Copyright (C) 2000 Kyle R. Burton, All Rights Reserved
 * mortis@voicenet.com
 * http://www.voicenet.com/~mortis
 * http://www.bgw.org
 * 
 * owl statement:
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>
#include <stdio_ext.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

#ifdef _WIN16 
    #define OWL_REMOVE
#endif
#ifdef _WIN32 
    #define OWL_REMOVE
#endif
#ifdef _WIN64 
    #define OWL_REMOVE
#endif

#ifndef OWL_REMOVE
    #include <termios.h>
#endif

/* to remove manually termios features, uncomment */
//#define OWL_REMOVE

/* this lets me define a flag in a clearer way */
#define boolean int           
 
/* owl version data */
#define MAJOR   0
#define MINOR   7
#define RELEASE 9
#define AU      "Antonio Maschio"        /* Author                    */
#define EM      "tbin at libero dot it"  /* Email                     */
#define CY      "2005-2013"              /* Copyright Year(s)         */
    
/* standard constants */
#define STACKLIMIT 1024                  /* stack capacity limit      */
#define LIMIT      1024                  /* PAD and strings length    */
#define ARRAYLIM  32768                  /* integer array depth       */
#define MAXVARS      26                  /* variable number [0-25]    */
#define BITS         64                  /* integer number depth      */
#define EPSILON 1.0E-2L                  /* nth root algorithm limit  */
#define ASCIILEN    256                  /* used vars vector limit    */
            
/* system strings */
#define OVERFLOWERROR  "\nowl: overflow error.\n"
#define UNDERFLOWERROR "\nowl: underflow error.\n"
#define TIMES          "\nowl: execution completed in %d ms.\n"
#define TIMESS         "\nowl: execution completed in %.3f s.\n"
#define WRONGOPTDERROR "owl: %s is not a valid option.\n"
#define WRONGOPTSERROR "owl: -%c is not a valid option.\n"
#define NOSTRING       "owl: no string given to option -p.\n"
#define OPENFILEERROR  "owl: unable to open file %s\n"
#define NOFILE         "owl: no input file.\n"
#define USEHELP        "Use \'owl --help\' for help.\n"
#define SPACEPAD       "                                   "

/* system macros */
#define iscap(x)       (((x) >= 'A') && ((x) <= 'Z'))
#define islow(x)       (((x) >= 'a') && ((x) <= 'z'))
#define is_x(x)        (((x) == 'x') || ((x) == 'X'))
#define ishexprefix(s) ((*(s)=='0') && (is_x(*(s+1))))
#define ispecprefix(s) ((*(s)=='!') && (is_x(*(s+1))))

/* truth values and numerical type definitions */
#define FALSE 0
#define TRUE  1
#define BIN   2
#define OCT   8
#define DEC  10
#define HEX  16
#define BINLEN 64
#define OCTLEN 22
#define HEXLEN 16

/* debug mode 
 * the debug option is a useful feature for looking 'into' an owl program 
 * execution; of course, as any debugging feature, it slows down and confuses 
 * output; you may want to have a smaller binary not containing it:
 * if so, use second line and comment first */
#define OWL_DEBUG
//#undef OWL_DEBUG

/* flags for executables and assembler files
 * I plan to enable these features in future versions but... 
 * ... don't expect too much from me, anyway! */
//#define LEAVESEXE
//#define LEAVESASM

/* function prototypes - don't change */

/* system */
void quit(void) __attribute__ ((noreturn));
void ensureCloseFile(void);
void debug(char *input);
char* getVar(char *input);
void erase_buffer(char *buffer);
void printHelp(void);
void printVersion(int f);
void printConditions(int f);
void printWarranty(int f);
int  parse(char *input);
void fprintb(FILE *file, long long int n);
int  include_file(char *input);
void printvars(void);
void printbuffers(void);
char* convertToNumbers(char *string);
long long int power(long long int base, long long int exp);
long long int nroot(long long int arg, long long int root);
long long int divide(long long int dividend, long long int divisor);
FILE * fileopen(char * filename);
char calcASCIIoffset(long long int n);
int cat(void);
void fprintany(FILE*file, long long int n, int base);
void printNumber(FILE*file, long long int n);
int isDigit(char d, int base);
long long int convertNumber(char* s, long long int st, long long int *n);
long long int toVAL(char digit, int base);
long long int toNUM(char* string, int base);

/* stack */
long long int  pop(void);
void push(long long int value);

/* global variables - don't change */

long long int Stack[STACKLIMIT+9];/* The integers stack                      */
long long int VarIBuffer[MAXVARS];/* A-Z variables for integers              */
char VarFBuffer[MAXVARS][LIMIT+9];/* a-z variables to hold functions         */
char FuncBuffer[LIMIT+9];         /* buffer for first streamed function      */
char *FBuffer = FuncBuffer;       /*   if there's another function, the      */
char BackFuncBuffer[LIMIT+9];     /*   first is copied into BackFuncBuffer   */
char *BFBuffer=BackFuncBuffer;    /*   the second (newer) into Funcbuffer    */
int  UsedVars[ASCIILEN];	  /* setting the 'used' flag for vars        */
char PAD[LIMIT+9];                /* string pad (a characters container)    */
char *Pad = PAD;                  /*   it may also be used as a char array   */
long long int ARRAY[ARRAYLIM+9];  /* array of integers                       */
int  TOS = 0;                     /* stack index (0 means no values)         */
char fIndex = 'a';                /* default value for function indexing     */
char *FileName = NULL;            /* pointer to the name of the input file   */
int  base = 10;                   /* default number base (may be 2÷36)       */
char WriteFileName[LIMIT+9];      /* the write-file name container;          */
FILE *chW=NULL;			  /* the write-file channel                  */
char TempFileName[LIMIT+9];       /* the write-file temporary container;     */
FILE *chT=NULL;                   /* the write-file temporary channel        */
char ReadFileName[LIMIT+9];       /* the read-file name container;           */
FILE *chR=NULL;                   /* the read-file channel                   */


/* ROUND = 0.0 (cut) sets rounding toward the lower integer, where 2.1 and 
 * 2.9 are both 2; this is the default option
 * ROUND = 0.5 (round) sets rounding toward the nearest integer, where 2.4 
 * is 2 and 2.5 is 3;
 * see J.W. Crenshaw, "Math tool-kit for Real Time Programming", 
 * CMP books, year 2000, p. 28. */
long double ROUND = 0.0L;         /* default rounding type                   */

/* flags */
boolean isBlank = FALSE;          /* PAD erasure flag after initialization   */
                                  /*   NOTE: setting this to TRUE prevents   */
                                  /*   using PAD as a numeric array          */
boolean isDebug = FALSE;          /* debug activation flag                   */
boolean isNTDiv = FALSE;          /* Number Theory integer division flag     */
int     isFunc = 0;               /* functions counter                       */
boolean isString = FALSE;         /* multiline strings flag                  */
boolean isInnerString = FALSE;    /* strings inner fucntion flag             */
boolean isComment = FALSE;        /* multiline comments flag                 */
boolean hasPrinted = FALSE;	  /* flag for the last CR                    */
#ifdef LEAVESEXE
boolean leavesEXE = FALSE;        /* leave exe file flag (not yet!)          */
#endif
#ifdef LEAVESASM
boolean leavesASM = FALSE;        /* leave asm file flag (not yet!)          */
#endif
boolean isPrependAmp = FALSE;     /* prepend char '&' to hex numbers flag    */
boolean printVars = FALSE;        /* print variables flag (debug mode)       */
boolean printFBuf = FALSE;        /* print function buffers flag (debug mode)*/
boolean singleStep = FALSE;       /* single step execution flag (debug mode) */
boolean overRideStep = FALSE;     /* override inner cycles flag (debug mode) */
boolean isInclude = FALSE;        /* skips include into functions flag       */
boolean hasExecuted = FALSE;      /* flag to signal if no code has been run  */ 
boolean EXEC = TRUE;              /* execution flag: undocumented            */
boolean isSeekStart=FALSE;	  /* flag for _S command                     */
boolean isRestoreStart=FALSE;	  /* flag for _R command                     */
boolean DelTermin=TRUE;           /* flag for _+ and _{ commands             */
int isDebugInclude=0;		  /* for debugging inclusions                */
int isFileComplete=0;		  /* for debugging, _O=1 _C=2 _R=3 _E=4      */
char digits[BITS]="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

/* round macro */
#define _round(x) (long long int)((long double)(x) + ((x) > 0 ? (ROUND) : -(ROUND)))

/* chronometer entities */
int chrono = 1;	// don't change!
double begChrono = 0.0, endChrono = 0.0;
struct timeval tvChrono;

/* end of dib.h */
